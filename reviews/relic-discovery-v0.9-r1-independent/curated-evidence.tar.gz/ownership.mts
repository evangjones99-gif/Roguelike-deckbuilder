import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import {createGame,validateState} from '/tmp/hollowpact-scene-jaw-v09-root-r1/src/engine.ts';
import fs from 'node:fs';import assert from 'node:assert/strict';
const O='/workspace/scratch/relic-discovery-independent-v09-r1',rows:any[]=[],browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{for(const owned of [[],['brass-bell']]){
 const state=createGame(741,1);state.relics=owned;assert(validateState(state));const c=await browser.newContext({viewport:{width:390,height:844},reducedMotion:'reduce'}),p=await c.newPage();
 await p.addInitScript(({save})=>{localStorage.setItem('hollowpact.run.v2',save);localStorage.setItem('hollowpact.settings.v2','{"mute":true,"motion":false,"volume":0}');localStorage.setItem('hollowpact.tutorial.v2','yes');},{save:JSON.stringify(state)});
 await p.goto('http://127.0.0.1:4597/');await p.locator('[data-ui="resume"]').click();const before=await p.evaluate(()=>JSON.stringify({...localStorage}));assert.equal(await p.locator('[data-ui="relic"]').count(),owned.length);
 await p.evaluate(()=>{const n=document.createElement('button');n.dataset.ui='relic';n.dataset.relic='moon-charm';n.id='review-forged-known-unowned';n.textContent='Synthetic known-unowned control';document.querySelector('#scene-ui')!.append(n);});
 await p.locator('#review-forged-known-unowned').click();assert.equal(await p.locator('dialog[open]').count(),0);assert.equal(await p.evaluate(()=>JSON.stringify({...localStorage})),before);
 await p.locator('#review-forged-known-unowned').evaluate(n=>{n.setAttribute('data-relic','toString');});await p.locator('#review-forged-known-unowned').click();assert.equal(await p.locator('dialog[open]').count(),0);assert.equal(await p.evaluate(()=>JSON.stringify({...localStorage})),before);
 rows.push({owned,knownUnownedRefused:true,prototypeKeyRefused:true,allStorageUnchanged:true,diagnosticDOMMutationOnly:true});await c.close();
}fs.writeFileSync(O+'/OWNERSHIP.json',JSON.stringify({contexts:2,rows},null,2)+'\n');}finally{await browser.close();}
