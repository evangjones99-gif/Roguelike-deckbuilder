from pathlib import Path
import json,hashlib,urllib.request,sys
A=Path('/workspace/scratch/relic-discovery-author-v09-r1');O=Path('/workspace/scratch/relic-discovery-independent-v09-r1');H=lambda b:hashlib.sha256(b).hexdigest()
assert H((A/'FROZEN-FILES.json').read_bytes())=='08b71ed83ded96e3aea3a2fcf45f3a39013948ecb19aae0a300de1b3ce92a680'
for p,r in json.loads((A/'FROZEN-FILES.json').read_text())['files'].items():
 b=(A/p).read_bytes();assert H(b)==r['sha256'] and len(b)==r['bytes'],p
d=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());rows=[]
for label,stage,port in [('baseline',Path('/tmp/hollowpact-scene-jaw-v09-root-r1'),4173),('candidate',Path(d['stage']),4597)]:
 declared=d[label];actual=json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/build-provenance.json'));assert actual==declared
 for p,h in declared['hashes'].items():assert H((stage/p).read_bytes())==h,p
 assert len(declared['hashes'])==77 and H(json.dumps(declared['hashes'],separators=(',',':')).encode())==declared['sourceDigest']
 outputs={}
 for p in sorted((stage/'dist').rglob('*')):
  if p.is_file():
   name=p.relative_to(stage/'dist').as_posix();b=p.read_bytes();web=urllib.request.urlopen(f'http://127.0.0.1:{port}/{name}').read();assert b==web,name;outputs[name]={'bytes':len(b),'sha256':H(b)}
 assert len(outputs)==55
 if label=='candidate':assert outputs==d['outputs']
 rows.append({'label':label,'stage':str(stage),'port':port,'provenance':actual,'outputs':outputs})
assert [p for p,h in d['baseline']['hashes'].items() if d['candidate']['hashes'][p]!=h]==['src/main.ts']
(O/(sys.argv[1]+'-identity.json')).write_text(json.dumps({'authorFilesVerified':26,'sourceBodiesPerBuild':77,'HTTPBodiesPerBuild':55,'onlySourceDelta':'src/main.ts','rows':rows},indent=2)+'\n')
print('Verified both77-input/55-output builds and26 frozen author files: '+sys.argv[1])
