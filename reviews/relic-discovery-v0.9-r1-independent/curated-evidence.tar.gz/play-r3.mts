import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import {createGame,applyAction,legalActions,validateState} from '/tmp/hollowpact-scene-jaw-v09-root-r1/src/engine.ts';
import {CARDS,RELICS} from '/tmp/hollowpact-scene-jaw-v09-root-r1/src/content.ts';
import fs from 'node:fs';import assert from 'node:assert/strict';
const O='/workspace/scratch/relic-discovery-independent-v09-r1',ids=Object.keys(RELICS),rows:any[]=[],errors:any[]=[];
function fixtures(kind:1|2){
 const map=createGame(917,1,{engineKind:kind});map.relics=ids.slice();assert(validateState(map));
 let battle=applyAction(map,{type:'travel',choice:'battle'});
 const summon=legalActions(battle).find(a=>a.type==='play'&&CARDS[battle.hand[a.index]].type==='summon');assert(summon);battle=applyAction(battle,summon);
 battle.enemies=battle.enemies.slice(0,1);battle.enemies[0].hp=1;const unit=battle.allies.find(u=>!u.acted)!;assert(unit);unit.attack=20;assert(validateState(battle));
 const action={type:'attack' as const,unit:unit.uid,target:battle.enemies[0].uid};assert(legalActions(battle).some(a=>JSON.stringify(a)===JSON.stringify(action)));
 const reward=applyAction(battle,action);assert.equal(reward.phase,'reward');assert(validateState(reward));
 const boss=structuredClone(battle);boss.floor=10;boss.route=['boss'];assert(validateState(boss));const victory=applyAction(boss,action);assert.equal(victory.phase,'victory');assert(validateState(victory));
 const loss=structuredClone(battle);loss.hp=1;loss.block=0;loss.discard.push(...loss.allies.map(u=>u.cardId));loss.allies=[];loss.enemies[0].attack=99;loss.enemies[0].intent={damage:99,target:'hunter',label:'Diagnostic lethal strike'};loss.enemies[0].block=0;loss.enemies[0].hp=loss.enemies[0].maxHp;assert(validateState(loss));
 const defeat=applyAction(loss,{type:'endTurn'});assert.equal(defeat.phase,'defeat');assert(validateState(defeat));
 return {map,reward,victory,defeat};
}
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{
 for(const kind of [1,2] as const)for(const width of [1280,390])for(const phase of ['map','reward','victory','defeat'] as const)for(const build of ['baseline','candidate']){
  const initial=fixtures(kind)[phase],ctx=await browser.newContext({viewport:{width,height:844},reducedMotion:'reduce'}),page=await ctx.newPage();
  const pageErrors:string[]=[];page.on('pageerror',e=>pageErrors.push(e.message));
  await page.addInitScript(({save})=>{localStorage.setItem('hollowpact.run.v2',save);localStorage.setItem('hollowpact.settings.v2',JSON.stringify({mute:true,motion:false,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');},{save:JSON.stringify(initial)});
  await page.goto('http://127.0.0.1:'+(build==='baseline'?4173:4597)+'/');await page.locator('[data-ui="resume"]').click();
  const before=await page.evaluate(()=>JSON.stringify({...localStorage}));assert.deepEqual(JSON.parse(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2'))!),initial);
  const row:any={kind,width,phase,build,diagnosticFixture:true,inspections:[],controls:[]};
  if(build==='candidate'){
   const buttons=page.locator('.relic-strip button');assert.equal(await buttons.count(),6);
   for(let i=0;i<ids.length;i++){
    const id=ids[i],button=page.locator(`[data-relic="${id}"]`);await button.scrollIntoViewIfNeeded();await button.focus();
    const control=await button.evaluate(n=>{const c=getComputedStyle(n),r=n.getBoundingClientRect();return {text:n.textContent,aria:n.getAttribute('aria-label'),fontSize:c.fontSize,color:c.color,background:c.backgroundColor,outline:c.outline,rect:{x:r.x,y:r.y,width:r.width,height:r.height}};});row.controls.push(control);
    assert.equal(control.aria,`Inspect ${RELICS[id].name} relic effect`);
    await page.keyboard.press(i%2?'Space':'Enter');const dialog=page.getByRole('dialog',{name:RELICS[id].name,exact:true});await dialog.waitFor();
    assert.equal(await page.locator('.dossier-rule p').textContent(),RELICS[id].text);
    const activeInside=await page.evaluate(()=>document.activeElement?.closest('dialog')?.id==='dialog');assert(activeInside);
    await page.keyboard.press('Tab');assert(await page.evaluate(()=>document.activeElement?.closest('dialog')?.id==='dialog'));
    await page.keyboard.press('Shift+Tab');assert(await page.evaluate(()=>document.activeElement?.closest('dialog')?.id==='dialog'));
    if(i%2)await page.locator('dialog [data-ui="close"]').last().click();else await page.keyboard.press('Escape');
    assert(await button.evaluate(n=>n===document.activeElement));assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),before);
    row.inspections.push({id,effect:RELICS[id].text,focusReturned:true,allStorageUnchanged:true,activation:i%2?'Space':'Enter'});
   }
   // A forged DOM control is a hostile diagnostic, not owned campaign content.
   const button=buttons.first();await button.evaluate(n=>{n.setAttribute('data-relic','not-owned');});await button.click();assert.equal(await page.locator('dialog[open]').count(),0);assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),before);row.unownedDOMRefused=true;
   await button.evaluate((n,id)=>{n.setAttribute('data-relic',id);},ids[0]);
   if(kind===2&&width===390){await page.locator('.relic-strip').scrollIntoViewIfNeeded();await page.screenshot({path:O+`/candidate-mobile-${phase}.png`});
    if(phase==='reward'){await page.locator(`[data-relic="grave-coin"]`).click();await page.screenshot({path:O+'/candidate-mobile-dossier.png'});await page.keyboard.press('Escape');}}
   if(kind===2&&width===1280&&phase==='reward'){await page.locator('.relic-strip').scrollIntoViewIfNeeded();await page.screenshot({path:O+'/candidate-desktop-reward.png'});}
   if(kind===2&&phase==='reward'){
    // Synthetic standard-pad state exercises real renderer adapter only; no hardware claim.
    await page.evaluate("window.__reviewPad={index:0,connected:true,mapping:'standard',axes:[0,0],buttons:Array.from({length:17},()=>({pressed:false,value:0}))};Object.defineProperty(navigator,'getGamepads',{configurable:true,value:()=>[window.__reviewPad]});window.dispatchEvent(new Event('focus'));window.dispatchEvent(new Event('gamepadconnected'));");
    await page.waitForTimeout(100);const origin=page.locator('[data-relic="war-brand"]');await origin.focus();
    async function edge(index:number){await page.evaluate((i)=>{(window as any).__reviewPad.buttons[i]={pressed:true,value:1};},index);await page.waitForTimeout(80);await page.evaluate((i)=>{(window as any).__reviewPad.buttons[i]={pressed:false,value:0};},index);await page.waitForTimeout(80);}
    await edge(0);await page.getByRole('dialog',{name:RELICS['war-brand'].name,exact:true}).waitFor();await edge(1);assert(await origin.evaluate(n=>document.activeElement===n));assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),before);row.syntheticPadABAndReturn=true;
    await edge(15);row.syntheticPadDirectionalDestination=await page.evaluate(()=>document.activeElement?.getAttribute('data-relic')||document.activeElement?.getAttribute('data-action'));assert(row.syntheticPadDirectionalDestination);assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),before);
   }
  }else{
   assert.equal(await page.locator('[data-ui="relic"]').count(),0);
   if(kind===2&&width===390&&phase==='reward'){await page.locator('[data-action="reward"][data-card=""]').scrollIntoViewIfNeeded();await page.screenshot({path:O+'/baseline-mobile-reward.png'});}
  }
  const control=page.locator(phase==='reward'?'[data-action="reward"][data-card=""]':phase==='map'?'.route-card':'.outcome-actions button').first();assert(await control.isEnabled());await control.scrollIntoViewIfNeeded();
  row.layout=await page.evaluate(()=>({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,sceneHeight:document.querySelector('#scene-ui')?.scrollHeight,relicHeight:document.querySelector('.relic-strip')?.getBoundingClientRect().height,salvageTop:document.querySelector('[data-action="reward"][data-card=""]')?.getBoundingClientRect().top}));assert.equal(row.layout.documentWidth,width);
  await page.reload();await page.locator('[data-ui="resume"]').click();assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),before);assert.deepEqual(pageErrors,[]);row.pageErrors=pageErrors;row.allStorageExactOnReload=true;rows.push(row);await ctx.close();
 }
 fs.writeFileSync(O+'/RESULTS.json',JSON.stringify({scope:'Fresh diagnostic UI A/B review, injected validator-valid fixtures. Keyboard/browser synthetic pad; no hardware/human enjoyment/native/audio listening.',contexts:rows.length,rows},null,2)+'\n');
}catch(e){fs.writeFileSync(O+'/FAILURE-r3.json',JSON.stringify({error:String(e),stack:(e as Error).stack,completed:rows},null,2)+'\n');throw e;}
finally{await browser.close();}
