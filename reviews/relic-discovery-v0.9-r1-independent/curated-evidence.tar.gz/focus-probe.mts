import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import {createGame} from '/tmp/hollowpact-scene-jaw-v09-root-r1/src/engine.ts';
import fs from 'node:fs';
const O='/workspace/scratch/relic-discovery-independent-v09-r1',rows:any[]=[],browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{for(const port of [4173,4597]){
 const c=await browser.newContext({viewport:{width:1280,height:844},reducedMotion:'reduce'}),p=await c.newPage(),s=createGame(917,1);s.relics=['moon-charm'];
 await p.addInitScript(({save})=>{localStorage.setItem('hollowpact.run.v2',save);localStorage.setItem('hollowpact.settings.v2','{"mute":true,"motion":false,"volume":0}');localStorage.setItem('hollowpact.tutorial.v2','yes');},{save:JSON.stringify(s)});
 await p.goto(`http://127.0.0.1:${port}/`);await p.locator('[data-ui="resume"]').click();
 const origin=p.locator(port===4597?'[data-relic="moon-charm"]':'[data-ui="inspect-quarry"]');await origin.focus();await p.keyboard.press('Enter');
 const row:any={port,steps:[]};for(const key of ['initial','Tab','Shift+Tab','Tab','Tab','Shift+Tab','Escape']){
  if(key!=='initial')await p.keyboard.press(key);
  row.steps.push({key,...await p.evaluate(()=>({focused:document.hasFocus(),dialogOpen:!!document.querySelector('dialog[open]'),activeTag:document.activeElement?.tagName,activeText:document.activeElement?.textContent?.slice(0,120),activeUI:document.activeElement?.getAttribute('data-ui'),activeRelic:document.activeElement?.getAttribute('data-relic'),inside:!!document.activeElement?.closest('dialog')}))});
 }rows.push(row);await c.close();
}fs.writeFileSync(O+'/FOCUS-PROBE.json',JSON.stringify(rows,null,2)+'\n');}finally{await browser.close();}
