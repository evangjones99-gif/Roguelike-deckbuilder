from pathlib import Path
import gzip,json
P=Path.cwd();rows=[json.load(gzip.open(f))for f in sorted(P.glob('*case-*.json.gz'))];assert len(rows)==12
by={(r['variant'],r['mode'],r['width']):r for r in rows};result={'completedContexts':len(rows),'openedContexts':13,'failedZeroEngineActionContexts':1,'engineActions':sum(len(r['actions'])for r in rows),'actionReloads':sum(r['actionReloads']for r in rows),'capturesCompleted':sum(len(r['captures'])for r in rows),'capturesAll':len(list(P.glob('*.jpg'))),'errors':[e for r in rows for e in r['errors']],'sourceBeforeAfterExact':json.loads((P/'AUDIT-before.json').read_text())==json.loads((P/'AUDIT-after.json').read_text()),'noticeGeometry':[],'fallbackGeometry':[],'heldReadouts':[],'pairedTextFontsExact':True,'normalHandAndUnitGeometryExact':True,'candidateLargeCardDefects':0,'baselineLargeCardDefects':0,'candidateNoticeClipping':[],'candidateFallbackClipping':[],'normalCanvas':[],'relicInspections':sum('relic'in r for r in rows)}
def textClipped(n):
 if n is None or not n['text']:return[]
 b=n['box'];return[g for g in n['glyphs']if g[0]<b[0]-.5 or g[1]<b[1]-.5 or g[2]>b[4]+.5 or g[3]>b[5]+.5]
for mode,width in [('normal',390),('choices',360),('choices',1440),('missing',390),('noCanvas',360),('late',1440)]:
 a=by['baseline',mode,width];b=by['candidate',mode,width]
 if mode=='choices':
  for label in ['reward','shop','deck','ember-inspector']:
   x=next(s for s in a['steps']if s['label']==label);y=next(s for s in b['steps']if s['label']==label)
   assert[{ 'id':c['id'],'nodes':[(n['text'],n['font'])for n in c['nodes']]}for c in x['cards']]==[{ 'id':c['id'],'nodes':[(n['text'],n['font'])for n in c['nodes']]}for c in y['cards']]
  for name in ['rewardDefects','shopDefects','deckDefects']:
   result['baselineLargeCardDefects']+=len(a[name]);result['candidateLargeCardDefects']+=len(b[name])
 if mode=='normal':
  x=next(s for s in a['steps']if s['label']=='battle');y=next(s for s in b['steps']if s['label']=='battle');assert x['hand']==y['hand'];assert x['units']==y['units'];assert x['canvas']==y['canvas'];result['normalCanvas']=[x['canvas'],y['canvas']]
 for r in [a,b]:
  for s in r['steps']:
   if s.get('held'):
    result['heldReadouts'].append({'variant':r['variant'],'mode':mode,'width':width,'label':s['label'],'enabled':len(s['enabled']),'units':[(u['uid'],u['stats'],u['status'],u['bar'],u['disabled'])for u in s['units']]})
   if s['label']in ['battle','final-hold','missing-reload-recovered','late-recovered']:
    if s['notice']and s['notice']['text']:
     result['noticeGeometry'].append({'variant':r['variant'],'mode':mode,'label':s['label'],'canvas':s['canvas'],'wrap':s['wrap'],'notice':s['notice']})
     if r['variant']=='candidate':
      result['candidateNoticeClipping']+=textClipped(s['notice']);assert s['canvas']['box'][5]<=s['notice']['box'][1]+.5;assert s['notice']['box'][5]<=s['wrap'][5]+.5
    if s['fallback']:
     result['fallbackGeometry'].append({'variant':r['variant'],'label':s['label'],'canvas':s['canvas'],'wrap':s['wrap'],'fallback':s['fallback']})
     if r['variant']=='candidate':result['candidateFallbackClipping']+=textClipped(s['fallback']);assert s['canvas']['hidden']and s['canvas']['box'][3]==0;assert s['fallback']['box'][5]<=s['wrap'][5]+.5
assert not result['candidateNoticeClipping']and not result['candidateFallbackClipping'];assert not result['errors']and result['engineActions']==38 and result['actionReloads']==38;assert result['candidateLargeCardDefects']==0
(P/'ANALYSIS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['noticeGeometry','fallbackGeometry','heldReadouts','normalCanvas']}))
