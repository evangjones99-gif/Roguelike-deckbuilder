from pathlib import Path
import json,gzip,hashlib,urllib.request,datetime,math
P=Path('/workspace/scratch/hound-jaw-r5-independent-visual-v08-r1');A=Path('/workspace/scratch/hound-jaw-hinge-author-v08-r5');h=lambda b:hashlib.sha256(b).hexdigest();raw=gzip.decompress((P/'results.json.gz').read_bytes());receipt=json.loads((P/'RESULTS-RECEIPT.json').read_text());assert h(raw)==receipt['decodedSHA256']and len(raw)==receipt['decodedBytes'];rows=json.loads(raw)['rows'];groups={};audit={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':len(rows),'actions':len(rows),'paired':[],'source':[]}
for r in rows:
 assert not r['errors'];groups.setdefault((r['natural'],r['mode'],r['vp']['width']),[]).append(r)
for key,rs in groups.items():
 b=next(r for r in rs if r['variant']=='baseline');c=next(r for r in rs if r['variant']=='candidate');assert b['initial']==c['initial']and b['action']==c['action']and b['expected']==c['expected'];record={'natural':key[0],'mode':key[1],'width':key[2],'initialActionStateEventsExact':True,'frames':[]}
 for f,z in zip(b['frames'],c['frames']):
  assert f['label']==z['label']and f['save']==z['save'];frame={'label':f['label'],'saveExact':True}
  if not key[0]:
   assert f['at']==z['at']and f['size']==z['size'];equal=f['pngSHA256']==z['pngSHA256'];frame.update({'sameClockAndCanvasSize':True,'arenaPixelsExact':equal})
   if key[1]in ['death','reduced']or f['label']in ['idle','140','370','500','1500']:assert equal,(key,f['label'])
   if key[1]in ['reverse','resize']and f['label']in ['200','240','280']:
    bd=[d for d in f['draws']if d['at']==f['at']and len(d['args'])==8 and d['args'][0]==1056 and d['args'][1]==96]
    cd=[d for d in z['draws']if d['at']==z['at']and len(d['args'])==8 and d['args'][0]==1024 and d['args'][1]==0 and d['args'][2]==512]
    assert bd and len(cd)>=2,(key,f['label'])
    def pt(d,x,y):
     sx,sy,sw,sh,dx,dy,dw,dh=d['args'];lx=dx+(1024+x-sx)/sw*dw;ly=dy+(y-sy)/sh*dh;a,b,c,e,tx,ty=d['matrix'];return(a*lx+c*ly+tx,b*lx+e*ly+ty)
    old=pt(bd[-1],432,255);new=pt(cd[-2],432,255);dist=math.dist(old,new);assert dist<.001
    frame.update({'upperNosePaintPositionBaseline':old,'upperNosePaintPositionCandidate':new,'upperNoseDifferencePx':dist,'candidateBaseDeterminant':cd[-2]['matrix'][0]*cd[-2]['matrix'][3]-cd[-2]['matrix'][1]*cd[-2]['matrix'][2]})
  else:frame.update({'baselineObservedWallAge':f.get('observedWallAge'),'candidateObservedWallAge':z.get('observedWallAge'),'timingNotAnEqualAgePixelComparison':True})
  record['frames'].append(frame)
 audit['paired'].append(record)
identity=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());mf=(A/'FROZEN-FILES.json').read_bytes();assert h(mf)=='6c3a80e75036ac1378e82c66a115eebd38806b1f4b36f61b5bf4b592ac5da94e'
for name,obj in json.loads(mf)['files'].items():d=(A/name).read_bytes();assert len(d)==obj['bytes']and h(d)==obj['sha256']
for v,port in [('baseline',4490),('candidate',4494)]:
 for name,obj in identity['runtimeInputs'][v].items():d=Path(obj['input']).read_bytes();assert h(d)==obj['sha256']and len(d)==obj['bytes'];assert (A/v/name).read_bytes()==d
 for name,obj in identity['outputs'][v].items():d=urllib.request.urlopen(f'http://127.0.0.1:{port}/'+name).read();assert h(d)==obj['sha256']and len(d)==obj['bytes'];assert(A/v/'dist'/name).read_bytes()==d
 audit['source'].append({'variant':v,'inputFiles':len(identity['runtimeInputs'][v]),'actualServedOutputs':len(identity['outputs'][v]),'sourceDigest':identity[v+'Digest']})
base=identity['runtimeInputs']['baseline'];new=identity['runtimeInputs']['candidate'];changed=[k for k in base if base[k]['sha256']!=new[k]['sha256']];added=sorted(set(new)-set(base));assert changed==['src/arena.ts']and added==['src/hound-jaw.ts'];audit.update({'originalFrozenAuthorFilesFinalExact':len(json.loads(mf)['files']),'changedRuntimeInputs':changed,'addedRuntimeInputs':added,'finalUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()});(P/'AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n');print('14 cases/actions, 7 paired canonical sequences, original source/media/served outputs exact; controlled rest/death/reduced/afterclosure pixels exact; six upper-nose positions within .001px.')
