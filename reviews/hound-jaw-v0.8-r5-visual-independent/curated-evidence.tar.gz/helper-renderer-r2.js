var independentJaw = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var stdin_exports = {};
  __export(stdin_exports, {
    drawHoundJaw: () => drawHoundJaw,
    houndJawClosure: () => houndJawClosure,
    houndJawPoint: () => houndJawPoint
  });
  const contour = [
    [378, 278],
    [389, 280],
    [398, 287],
    [408, 295],
    [417, 300],
    [425, 306],
    [421, 324],
    [412, 337],
    [397, 335],
    [392, 318],
    [386, 302],
    [375, 289]
  ];
  const hinge = { x: 379, y: 278 };
  const smooth = (v) => {
    const t = Math.max(0, Math.min(1, v));
    return t * t * (3 - 2 * t);
  };
  function houndJawClosure(age) {
    if (age < 0.18 || age >= 0.36) return 0;
    return age < 0.24 ? smooth((age - 0.18) / 0.06) : age < 0.28 ? 1 : 1 - smooth((age - 0.28) / 0.08);
  }
  function houndJawPoint(x, y, closure) {
    const angle = -0.62 * closure, c = Math.cos(angle), s = Math.sin(angle), dx = x - hinge.x, dy = y - hinge.y;
    return { x: hinge.x + dx * c - dy * s, y: hinge.y + dx * s + dy * c };
  }
  let surface;
  let sourceImage;
  let sourceCellX = -1;
  let sourceCellY = -1;
  let anatomyPath;
  function sourceJawPath() {
    if (!anatomyPath) {
      anatomyPath = new Path2D();
      anatomyPath.moveTo(contour[0][0], contour[0][1]);
      for (const point of contour.slice(1)) anatomyPath.lineTo(point[0], point[1]);
      anatomyPath.closePath();
    }
    return anatomyPath;
  }
  function drawHoundJaw(ctx, image, closure, sourceX, sourceY, cropX, cropY, cropWidth, cropHeight, destinationX, destinationY, destinationWidth, destinationHeight) {
    if (ctx.globalAlpha === 1) {
      ctx.save();
      ctx.translate(destinationX, destinationY);
      ctx.scale(destinationWidth / cropWidth, destinationHeight / cropHeight);
      ctx.translate(-cropX, -cropY);
      const jaw = sourceJawPath(), base = new Path2D();
      base.rect(cropX, cropY, cropWidth, cropHeight);
      base.addPath(jaw);
      ctx.save();
      ctx.clip(base, "evenodd");
      ctx.drawImage(image, sourceX, sourceY, 512, 512, 0, 0, 512, 512);
      ctx.restore();
      ctx.save();
      ctx.translate(hinge.x, hinge.y);
      ctx.rotate(-0.62 * closure);
      ctx.translate(-hinge.x, -hinge.y);
      ctx.clip(jaw);
      ctx.drawImage(image, sourceX, sourceY, 512, 512, 0, 0, 512, 512);
      ctx.restore();
      ctx.restore();
      return;
    }
    const texture = surface ??= document.createElement("canvas");
    if (texture.width !== 512) {
      texture.width = 512;
      texture.height = 512;
    }
    const ink = texture.getContext("2d");
    if (!ink) {
      ctx.drawImage(image, sourceX + cropX, sourceY + cropY, cropWidth, cropHeight, destinationX, destinationY, destinationWidth, destinationHeight);
      return;
    }
    const jawPath = () => {
      ink.beginPath();
      ink.moveTo(contour[0][0], contour[0][1]);
      for (const point of contour.slice(1)) ink.lineTo(point[0], point[1]);
      ink.closePath();
    };
    if (sourceImage !== image || sourceCellX !== sourceX || sourceCellY !== sourceY) {
      ink.clearRect(0, 0, 512, 512);
      ink.drawImage(image, sourceX, sourceY, 512, 512, 0, 0, 512, 512);
      sourceImage = image;
      sourceCellX = sourceX;
      sourceCellY = sourceY;
    }
    ink.clearRect(373, 272, 80, 68);
    ink.drawImage(image, sourceX + 373, sourceY + 272, 80, 68, 373, 272, 80, 68);
    ink.save();
    ink.globalCompositeOperation = "destination-out";
    jawPath();
    ink.fill();
    ink.restore();
    ink.save();
    ink.translate(hinge.x, hinge.y);
    ink.rotate(-0.62 * closure);
    ink.translate(-hinge.x, -hinge.y);
    jawPath();
    ink.clip();
    ink.drawImage(image, sourceX, sourceY, 512, 512, 0, 0, 512, 512);
    ink.restore();
    ctx.drawImage(texture, cropX, cropY, cropWidth, cropHeight, destinationX, destinationY, destinationWidth, destinationHeight);
  }
  return __toCommonJS(stdin_exports);
})();
