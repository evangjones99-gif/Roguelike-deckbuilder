from pathlib import Path
import hashlib,json,urllib.request,datetime
A=Path('/workspace/scratch/hound-jaw-hinge-author-v08-r5');P=Path('/workspace/scratch/hound-jaw-r5-independent-visual-v08-r1');h=lambda b:hashlib.sha256(b).hexdigest();manifest=(A/'FROZEN-FILES.json').read_bytes();assert h(manifest)=='6c3a80e75036ac1378e82c66a115eebd38806b1f4b36f61b5bf4b592ac5da94e'
m=json.loads(manifest)
for name,obj in m['files'].items():d=(A/name).read_bytes();assert len(d)==obj['bytes']and h(d)==obj['sha256'],name
identity=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorManifestSHA':h(manifest),'authorFiles':len(m['files']),'variants':{}}
(P/'source').mkdir()
for variant,port in [('baseline',4490),('candidate',4494)]:
 root=A/variant;prov=json.loads(urllib.request.urlopen(f'http://127.0.0.1:{port}/build-provenance.json').read());assert prov['sourceDigest']==identity[variant+'Digest']
 for name,obj in identity['runtimeInputs'][variant].items():
  d=Path(obj['input']).read_bytes();assert len(d)==obj['bytes']and h(d)==obj['sha256']
  assert (root/name).read_bytes()==d
  if name.startswith('src/') and name.endswith(('.ts','.css','.mjs')) and 'audio'not in name:
   if name in ['src/arena.ts','src/hound-jaw.ts','src/art.ts','src/engine.ts','src/world-rng.ts','src/content.ts','src/encounter-environment.ts']:(P/'source'/f'{variant}-{Path(name).name}').write_bytes(d)
 for name,obj in identity['outputs'][variant].items():
  d=urllib.request.urlopen(f'http://127.0.0.1:{port}/'+name).read();assert len(d)==obj['bytes']and h(d)==obj['sha256'];assert(root/'dist'/name).read_bytes()==d
 record['variants'][variant]={'sourceRoot':str(root.resolve()),'port':port,'provenance':prov,'inputs':identity['runtimeInputs'][variant],'outputs':identity['outputs'][variant]}
(P/'SOURCE-INTAKE.json').write_text(json.dumps(record,indent=2)+'\n');print('119 frozen author files, all 76/77 inputs, all 55/55 served outputs exact')
