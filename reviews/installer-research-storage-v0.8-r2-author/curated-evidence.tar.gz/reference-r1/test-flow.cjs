const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict');
const {spawnSync}=require('node:child_process');
const base=__dirname,source=fs.readFileSync(path.join(base,'candidate-script.js'),'utf8');
const pins=JSON.parse(fs.readFileSync(path.join(base,'pins.json'))),results=[];
const cases=['foreign-context','list-cap','foreign-head','foreign-tag','published-draft','foreign-body','all-three-preflight-before-bad-download','artifact-count','sdk-error-sanitized'];
for(const name of cases){
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'hollowpact-preserve-flow-'));
 const data={name,base,pins,source};fs.writeFileSync(path.join(tmp,'input.json'),JSON.stringify(data));
 const runner=`
 const fs=require('node:fs'),path=require('node:path');const input=JSON.parse(fs.readFileSync('input.json'));let writes=0,downloads=0,origins=0,failed='';
 const owner='evangjones99-gif',repo='Roguelike-deckbuilder';
 const readonly=fn=>async p=>({data:fn(p)});const write=async()=>{writes++;throw new Error('UNEXPECTED WRITE');};
 const pins=input.pins;const first=pins[0];
 const release={id:1,tag_name:first.tag,target_commitish:first.headSHA,draft:true,prerelease:true,name:'foreign',body:'foreign'};
 const core={getInput:()=> 'fixture-credential',setFailed:x=>{failed=x;},notice(){}};
 const context={repo:{owner,repo},ref:'refs/heads/codex/lanternbound-production',eventName:'push'};
 if(input.name==='foreign-context')context.repo.owner='foreign';
 const github={rest:{actions:{getWorkflowRun:readonly(p=>{origins++;if(input.name==='sdk-error-sanitized')throw new Error('fixture-credential https://signed.example.invalid/secret');const d=JSON.parse(fs.readFileSync(path.join(input.base,'live-run-'+p.run_id+'.json')));if(input.name==='foreign-head')d.head_sha='0'.repeat(40);return d;}),listWorkflowRunArtifacts:readonly(p=>{const d=JSON.parse(fs.readFileSync(path.join(input.base,'live-artifacts-'+p.run_id+'.json')));if(input.name==='artifact-count')d.total_count=7;return d;}),getArtifact:readonly(p=>{for(const pin of pins){const d=JSON.parse(fs.readFileSync(path.join(input.base,'live-artifacts-'+pin.runId+'.json')));const match=d.artifacts.find(a=>a.id===p.artifact_id);if(match)return match;}throw new Error('unknown pinned id');})},git:{getRef:readonly(()=>{if(input.name==='foreign-tag')return {ref:'refs/tags/'+first.tag,object:{type:'commit',sha:first.headSHA}};const e=new Error('missing');e.status=404;throw e;}),createRef:write},repos:{listReleases:readonly(()=>input.name==='list-cap'?Array.from({length:100},()=>({})):input.name==='published-draft'?[{...release,draft:false}]:input.name==='foreign-body'?[release]:[]),getRelease:write,listReleaseAssets:write,createRelease:write,uploadReleaseAsset:write}}};
 const fetch=async()=>{downloads++;return new Response('bad');};
 const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
 new AsyncFunction('require','core','context','github','fetch',input.source)(require,core,context,github,fetch).then(()=>{fs.writeFileSync('result.json',JSON.stringify({writes,downloads,origins,failed,report:fs.existsSync('installer-research-preservation/report.json')?JSON.parse(fs.readFileSync('installer-research-preservation/report.json')):null}));}).catch(()=>process.exitCode=1);
 `;
 const run=spawnSync(process.execPath,['-e',runner],{cwd:tmp,encoding:'utf8',timeout:30000});
 assert.equal(run.status,0,`${name}: ${run.stderr}`);const result=JSON.parse(fs.readFileSync(path.join(tmp,'result.json')));
 assert.equal(result.writes,0,name);assert(result.failed,name);
 if(name==='all-three-preflight-before-bad-download'){assert.equal(result.origins,3);assert.equal(result.downloads,1);assert.equal(result.report.phase,'reconstruct-all-three-without-remote-writes');}
 else assert.equal(result.downloads,0,name);
 if(name==='sdk-error-sanitized'){assert(!result.failed.includes('fixture-credential'));assert(!result.failed.includes('signed.example'));}
 results.push({name,passed:true,temporaryDerivedFixture:tmp,...result});
}
fs.writeFileSync(path.join(base,'flow-tests-results.json'),JSON.stringify({passed:results.length,failures:0,scope:'Actual full embedded workflow executed with in-process synthetic read-only API/response fixtures; write methods instrumented and all remained uncalled. No live GitHub write, artifact code execution or successful preservation claimed.',tests:results},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({passed:results.length,failures:0}));
