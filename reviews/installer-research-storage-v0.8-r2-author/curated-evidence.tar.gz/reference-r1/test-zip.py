import hashlib,json,os,struct,subprocess,tempfile,warnings,zipfile
from pathlib import Path
base=Path(__file__).parent;fixtures=base/'zip-fixtures';fixtures.mkdir()
tmp=Path(tempfile.mkdtemp(prefix='hollowpact-installer-preserve-zip-test-'))
pins=json.loads((base/'pins.json').read_text())
script=(base/'candidate-script.js').read_text().split('const ZIP_VERIFIER = ',1)[1].split(';\nconst fs',1)[0]
verifier=json.loads(script);assert verifier==(base/'zip-verifier.py').read_text()
results=[]
def run(name,mode,archive,spec,accepted):
 request=fixtures/(name+'-spec.json');request.write_text(json.dumps(spec))
 output=tmp/(name+'.bin');p=subprocess.run(['python3','-c',verifier,mode,str(archive),str(request),str(output)],capture_output=True,text=True)
 assert (p.returncode==0)==accepted,(name,p.stderr)
 r={'name':name,'acceptedAsExpected':accepted,'actualExit':p.returncode,'archiveBytes':archive.stat().st_size,'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'outputCreated':output.exists()}
 if p.returncode==0:r['verifierResult']=json.loads(p.stdout)
 else:r['qualifiedFailure']=p.stderr.splitlines()[-1] if p.stderr else 'nonzero exit'
 results.append(r)
for pin in pins:
 archive=base/'input-receipts'/str(pin['runId'])/'original-native-evidence.zip'
 assert archive.stat().st_size==pin['evidence']['bytes'] and hashlib.sha256(archive.read_bytes()).hexdigest()==pin['evidence']['sha256']
 run('actual-evidence-'+str(pin['runId']),'evidence',archive,pin,True)
payload=b'fixture part bytes';spec={'filename':'part-01.bin','bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
def make(name,entries,compression=zipfile.ZIP_STORED,symlink=False):
 p=fixtures/(name+'.zip')
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',UserWarning)
  with zipfile.ZipFile(p,'w',compression=compression) as z:
   for filename,data in entries:
    if symlink:
     i=zipfile.ZipInfo(filename);i.create_system=3;i.external_attr=0o120777<<16;z.writestr(i,data)
    else:z.writestr(filename,data)
 return p
valid=make('valid-stored',[(spec['filename'],payload)]);run('valid-stored','part',valid,spec,True)
run('valid-deflated','part',make('valid-deflated',[(spec['filename'],payload)],zipfile.ZIP_DEFLATED),spec,True)
run('duplicate-member','part',make('duplicate-member',[(spec['filename'],payload),(spec['filename'],payload)]),spec,False)
run('extra-member','part',make('extra-member',[(spec['filename'],payload),('extra.bin',b'extra')]),spec,False)
run('unsafe-parent','part',make('unsafe-parent',[('../part-01.bin',payload)]),spec,False)
run('unsafe-backslash','part',make('unsafe-backslash',[('sub\\part-01.bin',payload)]),spec,False)
run('symlink-member','part',make('symlink-member',[(spec['filename'],payload)],symlink=True),spec,False)
run('unsupported-compression','part',make('unsupported-compression',[(spec['filename'],payload)],zipfile.ZIP_BZIP2),spec,False)
run('wrong-part-hash','part',valid,{**spec,'sha256':'0'*64},False)
run('wrong-declared-size','part',valid,{**spec,'bytes':len(payload)+1},False)
bad=bytearray(valid.read_bytes());offset=bad.find(payload);assert offset>=0;bad[offset]^=1;p=fixtures/'bad-crc.zip';p.write_bytes(bad);run('bad-crc','part',p,spec,False)
bad=bytearray(valid.read_bytes());local=bad.find(b'PK\x03\x04');central=bad.find(b'PK\x01\x02');assert local>=0 and central>=0
for at in (local+6,central+8):struct.pack_into('<H',bad,at,struct.unpack_from('<H',bad,at)[0]|1)
p=fixtures/'encrypted-flag.zip';p.write_bytes(bad);run('encrypted-flag','part',p,spec,False)
payload2=b'x'*1048576;spec2={'filename':'part-01.bin','bytes':len(payload2),'sha256':hashlib.sha256(payload2).hexdigest()}
run('bounded-one-MiB-deflate','part',make('bounded-one-MiB-deflate',[(spec2['filename'],payload2)],zipfile.ZIP_DEFLATED),spec2,True)
(base/'zip-tests-results.json').write_text(json.dumps({'passed':len(results),'failures':0,'scope':'Actual embedded fixed verifier; three exact original small CI ZIPs and safe synthetic part/CRC/adversarial fixtures. No full installer reconstruction or execution.','temporaryDerivedOutputs':str(tmp),'tests':results},indent=2)+'\n')
print(json.dumps({'passed':len(results),'failures':0}))
