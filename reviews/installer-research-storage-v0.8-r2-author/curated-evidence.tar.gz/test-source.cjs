const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const {createRequire} = require('node:module');
const req = createRequire('/workspace/Roguelike-deckbuilder/package.json');
const yaml = req('js-yaml');
const base = __dirname, source = fs.readFileSync(path.join(base, 'candidate-script.js'), 'utf8');
const workflow = yaml.load(fs.readFileSync(path.join(base, 'preserve-installer-research.yml'), 'utf8'));
const results = [];
const test = async (name, fn) => { await fn(); results.push({name, passed: true}); };
const safeReject = fn => assert.throws(fn, e => typeof e.safeMessage === 'string');
const context = {require, Buffer, URL, Response, AbortSignal, console,
  core: {getInput: () => 'fixture-credential', notice() {}, setFailed() {}},
  github: {rest: {}}, context: {repo: {owner: 'invalid', repo: 'invalid'}}};
vm.createContext(context);
vm.runInContext(source.split('// BEGIN EXECUTION:')[0] + '\nglobalThis.testExports = {PINS, validateRun, validateArtifact, validRedirect, validateEndpoint, binaryResponse, consumeBinary, validateRelease, releaseIdentity, validateTag, coverage, api};', context);
const t = context.testExports, clone = x => JSON.parse(JSON.stringify(x));
(async () => {
  await test('YAML embeds exact reviewed JS bytes', () => assert.equal(workflow.jobs['preserve-failed-research'].steps[0].with.script, source));
  await test('Only fixed production push and parameterless dispatch', () => {
    assert.deepEqual(Object.keys(workflow.on).sort(), ['push', 'workflow_dispatch']);
    assert.equal(workflow.on.workflow_dispatch, null);
    assert.deepEqual(workflow.on.push.branches, ['codex/lanternbound-production']);
    assert.deepEqual(workflow.on.push.paths, ['.github/workflows/preserve-installer-research.yml']);
  });
  await test('Isolated content-write/actions-read permissions only', () => {
    assert.deepEqual(workflow.permissions, {});
    assert.deepEqual(workflow.jobs['preserve-failed-research'].permissions, {contents: 'write', actions: 'read'});
    assert.equal(workflow.jobs['preserve-failed-research']['timeout-minutes'], 45);
    assert.equal(workflow.concurrency['cancel-in-progress'], false);
  });
  await test('Only exact pinned actions; no checkout/install/publish/delete/update', () => {
    const steps = workflow.jobs['preserve-failed-research'].steps;
    assert.deepEqual(steps.map(x => x.uses), ['actions/github-script@f28e40c7f34bde8b3046d885e986cb6290c5673b','actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02']);
    assert(!/\b(updateRelease|deleteRelease|updateRef|deleteRef|deleteReleaseAsset|updateReleaseAsset)\b/.test(source));
    assert(!/pull_request_target|actions\/checkout|npm ci|npm install|execFileSync\([^']|execFileSync\('(?!python3')/.test(source));
  });
  for (const pin of t.PINS) {
    const run = JSON.parse(fs.readFileSync(path.join(base, `live-run-${pin.runId}.json`)));
    const artifacts = JSON.parse(fs.readFileSync(path.join(base, `live-artifacts-${pin.runId}.json`))).artifacts;
    await test(`Actual read-only API run+six artifact metadata ${pin.runId}`, () => {
      t.validateRun(run, pin);
      assert.equal(artifacts.length, 6);
      for (const e of [...pin.parts, pin.evidence]) t.validateArtifact(artifacts.find(a => a.id === e.artifactId), pin, e);
      assert.equal(pin.parts.reduce((n,x) => n + x.bytes,0), pin.bytes);
    });
    for (const [field,value] of [['conclusion',pin.nativeQAStatus==='passed'?'failure':'success'],['head_sha','0'.repeat(40)],['head_branch','main'],['run_attempt',2],['path','.github/workflows/foreign.yml'],['event','pull_request']])
      await test(`Reject altered run ${pin.runId}/${field}`, () => { const x=clone(run);x[field]=value;safeReject(() => t.validateRun(x,pin)); });
    const expected=pin.parts[0], original=artifacts.find(a=>a.id===expected.artifactId);
    for (const [field,value] of [['expired',true],['id',1],['name','foreign'],['digest','sha256:'+'0'.repeat(64)],['size_in_bytes',1]])
      await test(`Reject altered artifact ${pin.runId}/${field}`, () => {const x=clone(original);x[field]=value;safeReject(()=>t.validateArtifact(x,pin,expected));});
    await test(`Reject foreign artifact repository ${pin.runId}`,()=>{const x=clone(original);x.workflow_run.head_repository_id=1;safeReject(()=>t.validateArtifact(x,pin,expected));});
    const release={id:123,tag_name:pin.tag,target_commitish:pin.headSHA,draft:true,prerelease:true,...t.releaseIdentity(pin)};
    await test(`Matching failed research draft ${pin.runId}`,()=>t.validateRelease(release,pin));
    for(const [field,value] of [['draft',false],['prerelease',false],['target_commitish','main'],['body','foreign'],['tag_name','v0.7.0']])
      await test(`Reject existing draft mutation ${pin.runId}/${field}`,()=>{const x=clone(release);x[field]=value;safeReject(()=>t.validateRelease(x,pin));});
    await test(`Exact lightweight tag ${pin.runId}`,()=>t.validateTag({ref:`refs/tags/${pin.tag}`,object:{type:'commit',sha:pin.headSHA}},pin));
    await test(`Reject foreign tag target/type ${pin.runId}`,()=>safeReject(()=>t.validateTag({ref:`refs/tags/${pin.tag}`,object:{type:'tag',sha:pin.headSHA}},pin)));
  }
  for (const u of ['http://productionresultssa1.blob.core.windows.net/a','https://productionresultssa1.blob.core.windows.net.evil.test/a','https://attacker.blob.core.windows.net/a','https://user:pass@release-assets.githubusercontent.com/a','https://release-assets.githubusercontent.com:444/a','https://evil.github.com/a'])
    await test(`Reject redirect ${u.split('/')[2]}`,()=>assert.equal(t.validRedirect(u),false));
  await test('Redirect exact official download hosts accepted',()=>{
    assert(t.validRedirect('https://productionresultssa20.blob.core.windows.net/a'));
    assert(t.validRedirect('https://release-assets.githubusercontent.com/a'));
  });
  await test('Reject foreign binary endpoints before network',()=>{
    safeReject(()=>t.validateEndpoint('/repos/foreign/repo/actions/artifacts/1/zip','actions-artifact'));
    safeReject(()=>t.validateEndpoint('/repos/evangjones99-gif/Roguelike-deckbuilder/actions/artifacts/1/zip?other','actions-artifact'));
  });
  await test('Signed redirect drops credentials and follows exactly once',async()=>{
    const calls=[];context.fetch=async(url,options)=>{calls.push({url,options});return calls.length===1?new Response(null,{status:302,headers:{location:'https://productionresultssa20.blob.core.windows.net/fixture'}}):new Response('abc');};
    await t.binaryResponse('/repos/evangjones99-gif/Roguelike-deckbuilder/actions/artifacts/1/zip','actions-artifact',3);
    assert.equal(calls.length,2);assert.equal(calls[0].options.headers.Authorization,'Bearer fixture-credential');assert.equal(calls[1].options.headers,undefined);
    assert.equal(calls[1].options.redirect,'manual');
  });
  await test('Second redirect rejected, never followed',async()=>{
    let n=0;context.fetch=async()=>{n++;return new Response(null,{status:302,headers:{location:'https://release-assets.githubusercontent.com/fixture'}});};
    await assert.rejects(()=>t.binaryResponse('/repos/evangjones99-gif/Roguelike-deckbuilder/releases/assets/1','release-asset',3));assert.equal(n,2);
  });
  await test('Content-Length over bound rejected',async()=>{
    context.fetch=async()=>new Response('abcd',{headers:{'content-length':'4'}});
    await assert.rejects(()=>t.binaryResponse('/repos/evangjones99-gif/Roguelike-deckbuilder/releases/assets/1','release-asset',3));
  });
  const sha = require('node:crypto').createHash('sha256').update('abc').digest('hex');
  await test('Full readback SHA/count verified from stream',()=>t.consumeBinary(new Response('abc'),3,sha));
  await test('Oversize stream rejected independently of Content-Length',()=>assert.rejects(()=>t.consumeBinary(new Response('abcd'),3,sha)));
  await test('Truncated stream rejected',()=>assert.rejects(()=>t.consumeBinary(new Response('ab'),3,sha)));
  await test('Equal-size wrong SHA rejected',()=>assert.rejects(()=>t.consumeBinary(new Response('abd'),3,sha)));
  await test('SDK exception details never serialized',async()=>{
    await assert.rejects(()=>t.api('fixture operation',async()=>{throw new Error('fixture-credential signed-URL-fixture');},{}),e=>e.safeMessage==='Fixed GitHub API operation failed: fixture operation'&&!e.message.includes('fixture-credential'));
  });
  fs.writeFileSync(path.join(base,'source-tests-results.json'),JSON.stringify({passed:results.length,failures:0,scope:'Actual embedded workflow helpers + saved actual readonly API metadata; mocked binary/API refusal paths, no live writes or full remote preservation executed.',tests:results},null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({passed:results.length,failures:0}));
})().catch(e=>{console.error(e);process.exitCode=1;});
