const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {execFileSync} = require('node:child_process');
const owner = 'evangjones99-gif', repo = 'Roguelike-deckbuilder';
const branch = 'codex/lanternbound-production';
const directory = path.resolve('installer-research-preservation');
const token = core.getInput('github-token', {required: true});
const report = {schema: 1, status: 'running', scope: 'four-installer-research-drafts-three-failed-one-isolated-QA-pass',
  officialGameRelease: false, newNativeGameplayVerificationPerformed: false, newUninstallVerificationPerformed: false,
  commercialQualityAccepted: false, steamPublished: false, phase: 'context', cases: []};
function fail(message) { const e = new Error(message); e.safeMessage = message; throw e; }
function check(condition, message) { if (!condition) fail(message); }
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
function digestFile(filename) {
  const h = crypto.createHash('sha256'), fd = fs.openSync(filename, 'r'), b = Buffer.alloc(1048576);
  try { for (;;) { const n = fs.readSync(fd, b, 0, b.length, null); if (!n) break; h.update(b.subarray(0, n)); } }
  finally { fs.closeSync(fd); }
  return h.digest('hex');
}
async function api(label, method, params, allowMissing = false) {
  try { return (await method({...params, request: {timeout: 180000}})).data; }
  catch (error) { if (allowMissing && error.status === 404) return null; fail(`Fixed GitHub API operation failed: ${label}`); }
}
function validateRun(data, pin) {
  check(data.id === pin.runId && data.head_sha === pin.headSHA && data.head_branch === branch &&
    data.status === 'completed' && data.conclusion === (pin.nativeQAStatus === 'passed' ? 'success' : 'failure') && data.run_attempt === 1 &&
    data.event === 'push' && data.path === '.github/workflows/windows-installer-validation.yml' &&
    data.repository?.full_name === `${owner}/${repo}` && data.head_repository?.full_name === `${owner}/${repo}`,
    'Pinned installer research run identity/status mismatch');
}
function validateArtifact(data, pin, expected) {
  check(data.id === expected.artifactId && data.name === expected.artifactName &&
    data.size_in_bytes === (expected.wrapperBytes ?? expected.bytes) && data.expired === false &&
    data.digest === `sha256:${expected.wrapperSHA256 ?? expected.sha256}` &&
    data.workflow_run?.id === pin.runId && data.workflow_run.head_sha === pin.headSHA &&
    data.workflow_run.head_branch === branch && data.workflow_run.repository_id === 1398513166 &&
    data.workflow_run.head_repository_id === 1398513166, 'Pinned artifact identity/digest/expiry mismatch');
}
function validRedirect(raw) {
  let url; try { url = new URL(raw); } catch { return false; }
  return url.protocol === 'https:' && !url.username && !url.password && (!url.port || url.port === '443') &&
    (/^productionresults[a-z0-9]*\.blob\.core\.windows\.net$/.test(url.hostname) ||
     ['release-assets.githubusercontent.com', 'objects.githubusercontent.com'].includes(url.hostname));
}
function validateEndpoint(endpoint, purpose) {
  const prefix = `/repos/${owner}/${repo}`;
  const ok = purpose === 'actions-artifact'
    ? new RegExp(`^${prefix}/actions/artifacts/[1-9][0-9]*/zip$`).test(endpoint)
    : purpose === 'release-asset' && new RegExp(`^${prefix}/releases/assets/[1-9][0-9]*$`).test(endpoint);
  check(ok, 'Unsupported fixed binary-download endpoint');
}
async function binaryResponse(endpoint, purpose, bytes) {
  validateEndpoint(endpoint, purpose);
  check(Number.isSafeInteger(bytes) && bytes > 0 && bytes <= 128 * 1024 * 1024, 'Invalid bounded download size');
  let response;
  try { response = await fetch(`https://api.github.com${endpoint}`, {redirect: 'manual',
    headers: {Authorization: `Bearer ${token}`, Accept: purpose === 'actions-artifact' ? 'application/vnd.github+json' : 'application/octet-stream',
      'X-GitHub-Api-Version': '2022-11-28'}, signal: AbortSignal.timeout(180000)}); }
  catch { fail('Fixed binary API request failed'); }
  if (response.status === 302) {
    const location = response.headers.get('location');
    check(validRedirect(location), 'Refused binary redirect host/protocol');
    // The token is sent ONLY to the fixed API origin. The signed GET has no headers.
    try { response = await fetch(location, {redirect: 'manual', signal: AbortSignal.timeout(180000)}); }
    catch { fail('Allowed signed binary GET failed'); }
  }
  check(response.status === 200 && response.body, 'Binary response status/body mismatch');
  const declared = response.headers.get('content-length');
  check(declared === null || (/^[0-9]+$/.test(declared) && Number(declared) <= bytes), 'Binary Content-Length exceeds pin');
  return response;
}
async function consumeBinary(response, bytes, expectedSHA, destination = null) {
  const reader = response.body.getReader(), digest = crypto.createHash('sha256');
  let total = 0, fd = destination ? fs.openSync(destination, 'wx', 0o600) : null;
  try {
    for (;;) {
      const {done, value} = await reader.read(); if (done) break;
      total += value.length;
      if (total > bytes) { await reader.cancel(); fail('Binary exceeded exact byte bound'); }
      digest.update(value);
      if (fd !== null) { let offset = 0; while (offset < value.length) offset += fs.writeSync(fd, value, offset, value.length - offset); }
    }
    check(total === bytes && digest.digest('hex') === expectedSHA, 'Binary complete size/SHA mismatch');
  } finally { if (fd !== null) fs.closeSync(fd); reader.releaseLock(); }
}
async function downloadArtifact(pin, expected, destination) {
  const data = await api('get pinned artifact', github.rest.actions.getArtifact,
    {owner, repo, artifact_id: expected.artifactId});
  validateArtifact(data, pin, expected);
  const bytes = expected.wrapperBytes ?? expected.bytes, sha = expected.wrapperSHA256 ?? expected.sha256;
  const response = await binaryResponse(`/repos/${owner}/${repo}/actions/artifacts/${expected.artifactId}/zip`, 'actions-artifact', bytes);
  await consumeBinary(response, bytes, sha, destination);
}
function verifyZIP(purpose, archive, spec, output, work) {
  const specPath = path.join(work, `spec-${purpose}-${path.basename(archive)}.json`);
  fs.writeFileSync(specPath, JSON.stringify(spec), {flag: 'wx', mode: 0o600});
  try {
    const data = execFileSync('python3', ['-c', ZIP_VERIFIER, purpose, archive, specPath, output],
      {timeout: 120000, maxBuffer: 128 * 1024, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe']});
    check(JSON.parse(data).allExactMembersCRCSizeSHAPass === true, 'Fixed ZIP verifier refused members');
  } catch { fail('Exact ZIP member/CRC/size/SHA verifier failed'); }
}
function concatenate(pin, work, output) {
  const fd = fs.openSync(output, 'wx', 0o600), digest = crypto.createHash('sha256'); let total = 0;
  try {
    for (const part of pin.parts) {
      const input = fs.openSync(path.join(work, part.filename), 'r'), partDigest = crypto.createHash('sha256');
      const buffer = Buffer.alloc(1048576); let partTotal = 0;
      try {
        for (;;) {
          const n = fs.readSync(input, buffer, 0, buffer.length, null); if (!n) break;
          partTotal += n; total += n;
          check(partTotal <= part.bytes && total <= pin.bytes, 'Concatenation exceeded fixed byte cap');
          const chunk = buffer.subarray(0, n); partDigest.update(chunk); digest.update(chunk);
          let offset = 0; while (offset < n) offset += fs.writeSync(fd, chunk, offset, n - offset);
        }
      } finally { fs.closeSync(input); }
      check(partTotal === part.bytes && partDigest.digest('hex') === part.sha256, 'Part changed before concatenation');
    }
    check(total === pin.bytes && digest.digest('hex') === pin.sha256, 'Whole original NSIS size/SHA mismatch');
  } finally { fs.closeSync(fd); }
}
function coverage(pin) {
  return {schema: 1, researchTag: pin.tag, sourceCommit: pin.headSHA, nativeRunId: pin.runId,
    nativeRunAttempt: 1, originalGameVersionLabel: '0.7.0', runtimeSourceDigest: pin.sourceDigest,
    runtimeInputCount: 29, statusOfOriginalNativeQA: pin.nativeQAStatus, officialGameRelease: false,
    newNativeGameplayVerificationPerformed: false, newUninstallVerificationPerformed: false, consumerGameQualityAccepted: false, commercialQualityAccepted: false, steamPublished: false,
    requestedDurableAssets: [{name: pin.installerAssetName, originalFilename: pin.originalFilename, bytes: pin.bytes, sha256: pin.sha256},
      {name: pin.evidenceAssetName, bytes: pin.evidence.bytes, sha256: pin.evidence.sha256},
      {name: 'preservation-coverage.json', purpose: 'this deterministic coverage/identity receipt'}],
    originalCIInputs: {parts: pin.parts, evidence: pin.evidence},
    notMirroredByThisWorkflow: ['the five original Actions ZIP part wrappers', 'the five numbered raw part files',
      'full job logs', 'all other game release/source/Linux/web archives', 'review discussions or unrelated datasets'],
    readBackPolicy: 'Every stored asset requires complete byte-count/SHA read-back; actual asset IDs/results appear in the separate workflow diagnostic.',
    limitations: pin.nativeQAStatus === 'passed' ? 'The original isolated QA lifecycle passed on a hosted Windows runner; this storage job performs no new install/gameplay/uninstall test. Original embedded game label is preserved. No consumer install, human enjoyment, physical controller/Deck, signing, store/rights, AAA or Steam publication acceptance.' : 'Original native QA failed. The original embedded game label is preserved; no complete lifecycle acceptance. No consumer install, human enjoyment, physical controller/Deck, signing, store/rights, AAA or Steam publication acceptance.'};
}
function releaseIdentity(pin) {
  const marker = `Pinned failed research inputs SHA256: ${hash(Buffer.from(JSON.stringify(pin)))}`;
  return {name: `Hollowpact installer research — ${pin.nativeQAStatus === 'passed' ? 'isolated QA pass' : 'FAILED QA'} — run ${pin.runId}`,
    body: [pin.nativeQAStatus === 'passed' ? 'Isolated installer QA lifecycle passed; research preservation only, not consumer release acceptance.' : 'FAILED installer QA research; retained for diagnosis, not a playable release endorsement.',
      `Run ${pin.runId}, attempt 1, source ${pin.headSHA}, runtime ${pin.sourceDigest} (29 inputs).`,
      'This draft prerelease preserves the exact original NSIS installer, the original small CI evidence ZIP, and a deterministic partial-coverage receipt.',
      'The five input artifact wrappers/raw parts and full job logs are NOT mirrored here. Three selected origins failed; one passed a scoped isolated hosted-Windows QA lifecycle. This storage workflow runs no new gameplay/uninstall checks. No consumer release, commercial quality, rights/store/signing or Steam publication acceptance.', marker].join('\n\n')};
}
function validateRelease(data, pin) {
  const identity = releaseIdentity(pin);
  check(data && Number.isSafeInteger(data.id) && data.id > 0 && data.tag_name === pin.tag &&
    data.target_commitish === pin.headSHA && data.draft === true && data.prerelease === true &&
    data.name === identity.name && data.body === identity.body, 'Existing research release is not the exact pinned draft');
}
function validateTag(data, pin) {
  check(data?.ref === `refs/tags/${pin.tag}` && data.object?.type === 'commit' && data.object.sha === pin.headSHA,
    'Existing research tag type/target differs');
}
async function refFor(pin) {
  return api('get fixed research tag', github.rest.git.getRef, {owner, repo, ref: `tags/${pin.tag}`}, true);
}
async function assertCurrentDraft(plan) {
  const data = await api('read current research draft', github.rest.repos.getRelease,
    {owner, repo, release_id: plan.release.id}); validateRelease(data, plan.pin);
  validateTag(await refFor(plan.pin), plan.pin);
}
async function verifyStored(asset, expected) {
  check(Number.isSafeInteger(asset.id) && asset.id > 0 && asset.name === expected.name && asset.size === expected.bytes &&
    asset.state === 'uploaded', 'Existing/stored research asset identity/size/state differs');
  const response = await binaryResponse(`/repos/${owner}/${repo}/releases/assets/${asset.id}`, 'release-asset', expected.bytes);
  await consumeBinary(response, expected.bytes, expected.sha256);
}
// BEGIN EXECUTION: no test branch, downloaded code execution, checkout or dependency install.
try {
  check(context.repo.owner === owner && context.repo.repo === repo && context.ref === `refs/heads/${branch}` &&
    ['push', 'workflow_dispatch'].includes(context.eventName), 'Fixed repository/branch/trigger mismatch');
  check(PINS.length === 4 && PINS.filter(p => p.nativeQAStatus === 'failed').length === 3 && PINS.filter(p => p.nativeQAStatus === 'passed').length === 1 && PINS.every(p => p.parts.length === 5 && ['failed', 'passed'].includes(p.nativeQAStatus) &&
    p.parts.every((x, i) => x.index === i + 1 && x.filename === `part-${String(i + 1).padStart(2, '0')}.bin`) &&
    p.bytes > 120000000 && p.bytes < 128 * 1024 * 1024 && p.sourceDigest === '0be4f01d416e6fc4cca3f19b6916b5b65993b9fd426a926a1ede6d8487834a35'), 'Fixed research pin schema/caps mismatch');
  fs.mkdirSync(directory, {mode: 0o700});
  const storage = fs.statfsSync(directory); check(storage.bavail * storage.bsize >= 2048 * 1024 * 1024, 'Insufficient bounded runner capacity');
  report.phase = 'readonly-identity-preflight';
  const releases = await api('bounded release listing', github.rest.repos.listReleases, {owner, repo, per_page: 100, page: 1});
  check(Array.isArray(releases) && releases.length < 100, 'Release listing cap reached; refuse ambiguity');
  const plans = [];
  // Check every pinned origin and every existing draft before any remote write.
  for (const pin of PINS) {
    const run = await api('get fixed research run', github.rest.actions.getWorkflowRun, {owner, repo, run_id: pin.runId}); validateRun(run, pin);
    const list = await api('list fixed run artifacts', github.rest.actions.listWorkflowRunArtifacts,
      {owner, repo, run_id: pin.runId, per_page: 100, page: 1});
    const expected = [...pin.parts, pin.evidence];
    check(list.total_count === 6 && list.artifacts?.length === 6, 'Fixed run artifact count differs');
    for (const e of expected) { const matches = list.artifacts.filter(x => x.id === e.artifactId); check(matches.length === 1, 'Missing/duplicate fixed artifact'); validateArtifact(matches[0], pin, e); }
    const matches = releases.filter(x => x.tag_name === pin.tag); check(matches.length <= 1, 'Multiple releases on fixed research tag');
    const release = matches[0] || null, reference = await refFor(pin);
    if (release) { validateRelease(release, pin); validateTag(reference, pin); }
    else check(reference === null, 'Foreign/orphan existing research tag; refuse adoption');
    const work = path.join(directory, String(pin.runId)); fs.mkdirSync(work, {mode: 0o700});
    plans.push({pin, release, work, assets: [], expected: []});
  }
  report.phase = 'reconstruct-all-four-without-remote-writes';
  for (const plan of plans) {
    const {pin, work} = plan;
    for (const part of pin.parts) {
      const wrapper = path.join(work, `original-wrapper-${part.index}.zip`);
      await downloadArtifact(pin, part, wrapper);
      verifyZIP('part', wrapper, part, path.join(work, part.filename), work);
    }
    const original = path.join(work, pin.installerAssetName); concatenate(pin, work, original);
    const evidence = path.join(work, pin.evidenceAssetName); await downloadArtifact(pin, pin.evidence, evidence);
    verifyZIP('evidence', evidence, pin, '-', work);
    const receipt = path.join(work, 'preservation-coverage.json'); fs.writeFileSync(receipt, JSON.stringify(coverage(pin), null, 2) + '\n', {flag: 'wx', mode: 0o600});
    plan.expected = [{name: pin.installerAssetName, path: original, bytes: pin.bytes, sha256: pin.sha256},
      {name: pin.evidenceAssetName, path: evidence, bytes: pin.evidence.bytes, sha256: pin.evidence.sha256},
      {name: 'preservation-coverage.json', path: receipt, bytes: fs.statSync(receipt).size, sha256: digestFile(receipt)}];
    if (plan.release) {
      plan.assets = await api('bounded existing draft assets', github.rest.repos.listReleaseAssets,
        {owner, repo, release_id: plan.release.id, per_page: 10, page: 1});
      check(Array.isArray(plan.assets) && plan.assets.length <= 3 && plan.assets.every(a => plan.expected.some(e => e.name === a.name)) &&
        new Set(plan.assets.map(a => a.name)).size === plan.assets.length, 'Unexpected/duplicate existing research assets');
      for (const asset of plan.assets) await verifyStored(asset, plan.expected.find(e => e.name === asset.name));
      await assertCurrentDraft(plan);
    }
  }
  report.phase = 'draft-only-storage';
  for (const plan of plans) {
    const {pin} = plan;
    const caseReport = {runId: pin.runId, sourceCommit: pin.headSHA, runtimeSourceDigest: pin.sourceDigest,
      originalNativeQAStatus: 'failed', status: 'storing', tag: pin.tag, assets: []}; report.cases.push(caseReport);
    if (!plan.release) {
      check(await refFor(pin) === null, 'Research tag appeared since preflight; refuse adoption');
      await api('create fixed research ref', github.rest.git.createRef, {owner, repo, ref: `refs/tags/${pin.tag}`, sha: pin.headSHA});
      caseReport.newResearchTagCreated = true; validateTag(await refFor(pin), pin);
      plan.release = await api('create fixed research draft', github.rest.repos.createRelease,
        {owner, repo, tag_name: pin.tag, target_commitish: pin.headSHA, ...releaseIdentity(pin), draft: true,
          prerelease: true, generate_release_notes: false, make_latest: 'false'});
      validateRelease(plan.release, pin);
    }
    caseReport.releaseId = plan.release.id;
    for (const expected of plan.expected) {
      await assertCurrentDraft(plan);
      let asset = plan.assets.find(a => a.name === expected.name);
      if (!asset) {
        check(fs.statSync(expected.path).size === expected.bytes && digestFile(expected.path) === expected.sha256, 'Local exact original changed before upload');
        asset = await api('upload exact research asset', github.rest.repos.uploadReleaseAsset,
          {owner, repo, release_id: plan.release.id, name: expected.name, data: fs.readFileSync(expected.path),
            headers: {'content-type': 'application/octet-stream', 'content-length': expected.bytes}});
      }
      await verifyStored(asset, expected); await assertCurrentDraft(plan);
      caseReport.assets.push({name: expected.name, assetId: asset.id, bytes: expected.bytes, sha256: expected.sha256, fullReadBackVerified: true});
    }
    await assertCurrentDraft(plan);
    const finalAssets = await api('bounded final research assets', github.rest.repos.listReleaseAssets,
      {owner, repo, release_id: plan.release.id, per_page: 10, page: 1});
    check(Array.isArray(finalAssets) && finalAssets.length === 3 &&
      caseReport.assets.every(expected => finalAssets.filter(a => a.id === expected.assetId && a.name === expected.name &&
        a.size === expected.bytes && a.state === 'uploaded').length === 1), 'Final draft asset set changed');
    await assertCurrentDraft(plan); caseReport.status = 'passed-research-partial-preservation';
  }
  check(report.cases.length === 4 && report.cases.every(x => x.assets.length === 3), 'Final fixed coverage differs');
  report.status = 'passed-four-installer-research-draft-preservation'; report.phase = 'complete';
  core.notice('Verified four installer research drafts: three failed origins, one scoped isolated-QA pass; partial coverage, no consumer game release acceptance.');
} catch (error) {
  report.status = 'failed';
  // Do not serialize arbitrary SDK/fetch exception messages, credentials or signed URLs.
  report.error = error.safeMessage || `Unexpected operation failure in fixed phase ${report.phase}`;
  core.setFailed(report.error);
} finally {
  if (fs.existsSync(directory)) fs.writeFileSync(path.join(directory, 'report.json'), JSON.stringify(report, null, 2) + '\n', {flag: 'wx', mode: 0o600});
}
