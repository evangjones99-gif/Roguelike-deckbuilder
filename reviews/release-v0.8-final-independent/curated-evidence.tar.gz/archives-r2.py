from pathlib import Path,PurePosixPath
import hashlib,json,datetime,zipfile,tarfile,stat,struct,subprocess,gzip,os
R=Path('/workspace/Roguelike-deckbuilder');D=R/'releases/0.8.0';P=Path('/workspace/scratch/release-v08-final-independent-r1');COMMIT='58efb01f4815d8b542711582b87f50168dabde81';RUNTIME='23477f68c99d6d60b0b3f82b286a8d33bb6da6f2ca92c103fbecf5663634959f';ASAR='c383c4437ac5467146174c6ea039b2a8b28af43d609701379e8cf695f59d530c'
def stream(f):
 d=hashlib.sha256();n=0
 while b:=f.read(1024*1024):d.update(b);n+=len(b)
 return {'bytes':n,'sha256':d.hexdigest()}
def file(p):
 with p.open('rb')as f:return stream(f)
def safe(name,tar=False,directory=False):
 assert '\\'not in name and '\x00'not in name and not name.startswith('/')and ':'not in name
 if tar and name.startswith('./'):name=name[2:]
 if directory:name=name.rstrip('/')
 if tar and directory and name in['','.']:return '.'
 assert name and all(p not in['','..','.']for p in name.split('/'))
 assert not PurePosixPath(name).is_absolute();return name
result={'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':{},'linux':{},'linuxDirs':{},'windows':{},'web':{},'webDirs':{},'nativeEvidence':{},'oldArchives':[]};inputs={}
def save(stage):
 (P/'ARCHIVE-CHECKPOINT-r2.json').write_text(json.dumps({'stage':stage,**result},indent=2)+'\n')
try:
 m=json.loads((D/'manifest.json').read_text());receipt=json.loads((R/'reviews/root-v0.8-release-verification/root-verification.json').read_text());assert m['sourceCommit']==COMMIT and m['runtimeSourceDigest']==RUNTIME and m['version']=='0.8.0'and m['status']=='development-prerelease'and m['steamPublished']is False;assert m['platforms']==['web','linux-x64','windows-x64'];assert m['sourceArchiveFormat']=='git-bundle-v2';assert not (R/'.release-lock').exists()and not (D/'INCOMPLETE.txt').exists()and not (D/'NATIVE-SEAL-IN-PROGRESS.json').exists()
 expected={'hollowpact-0.8.0-linux-x64.tar.gz','hollowpact-0.8.0-native-evidence-36806506465-1.zip','hollowpact-0.8.0-source.bundle','hollowpact-0.8.0-web.zip','hollowpact-0.8.0-windows-native-x64.zip'};actual={p.name for p in D.iterdir()if p.name.endswith(('.bundle','.zip','.tar.gz'))};assert set(m['artifacts'])==actual==expected;hashlines=(D/'SHA256SUMS').read_text().splitlines();parsed={}
 for line in hashlines:
  sha,name=line.split('  ');assert name not in parsed and len(sha)==64;parsed[name]=sha
 assert parsed==m['artifacts'];assert receipt['sourceCommit']==COMMIT and receipt['runtimeSourceDigest']==RUNTIME
 for name in sorted(expected):
  obj=file(D/name);assert obj['sha256']==m['artifacts'][name]and obj==receipt['artifacts'][name];result['archives'][name]=obj;save('whole-'+name)
 assert result['archives']['hollowpact-0.8.0-source.bundle']=={'bytes':1711151088,'sha256':'fd1310a36be0931bb81537004f87ef751481ca0daa349e58f1576a3c34640b3d'}
 assert file(Path('/workspace/retained-native-experiments/windows-run-36806506465/hollowpact-0.8.0-windows-native-x64.zip'))==result['archives']['hollowpact-0.8.0-windows-native-x64.zip']
 assert file(Path('/workspace/scratch/windows-native-independent-v08-run-36806506465/original-native-evidence.zip'))==result['archives']['hollowpact-0.8.0-native-evidence-36806506465-1.zip']
 with zipfile.ZipFile(D/'hollowpact-0.8.0-native-evidence-36806506465-1.zip')as z, zipfile.ZipFile('/workspace/scratch/windows-native-independent-v08-run-36806506465/original-native-evidence.zip')as originalCI:
  names=set();fold=set()
  for entry in z.infolist():
   name=safe(entry.filename);assert name not in names and name.casefold()not in fold and not entry.is_dir()and not entry.flag_bits&1 and entry.compress_type in[0,8];names.add(name);fold.add(name.casefold());mode=entry.external_attr>>16;assert stat.S_IFMT(mode)in[0,stat.S_IFREG]
   with z.open(entry)as f:obj=stream(f)
   assert obj['bytes']==entry.file_size
   with originalCI.open(name)as f:assert obj==stream(f)
   rawPath=Path('/workspace/scratch/windows-native-independent-v08-run-36806506465/raw-small-members')/name
   if rawPath.is_file():assert obj==file(rawPath)
   result['nativeEvidence'][name]={**obj,'storedUnixMode':oct(mode),'CRC':entry.CRC,'exactOriginalCIZIPMember':True,'extractedRawCounterpartPresent':rawPath.is_file()}
  assert len(names)==64 and names==set(originalCI.namelist())
  smoke=json.loads(z.read('reviews/windows-native/0.8.0/run-36806506465-1/smoke.json'));nativeReport=json.loads(z.read('reviews/windows-native/0.8.0/run-36806506465-1/native-package.json'));transfer=json.loads(z.read('build-desktop/windows-transfer/manifest.json'));nativeProvenance=json.loads(z.read('dist/build-provenance.json'))
 assert smoke['status']=='passed'and smoke['runtimeSourceDigest']==RUNTIME and smoke['asarSHA256']==ASAR and smoke['commit']=='7c460a706d6e5bfd8c98d5886b3d1d5cab679cef'and smoke['runId']=='36806506465'and len(smoke['steps'])==13 and not smoke['errors'];assert nativeReport['commit']==smoke['commit']and nativeReport['signatureStatus']=='NotSigned'and transfer['commit']==smoke['commit']and transfer['bytes']==191814688 and transfer['sha256']==m['artifacts']['hollowpact-0.8.0-windows-native-x64.zip']
 assert m['nativeWindows']['actualPRMergeCheckout']==smoke['commit']and m['nativeWindows']['headSourceCheckpoint']=='2e93c2dab38c513a6f43e1dc4e31307f0866db14'and m['nativeWindows']['attempt']==1 and m['nativeWindows']['jobId']==110191925032
 windowsAsar=None
 with zipfile.ZipFile(D/'hollowpact-0.8.0-windows-native-x64.zip')as z:
  fold=set()
  for entry in z.infolist():
   name=safe(entry.filename);assert name not in result['windows']and name.casefold()not in fold and not entry.is_dir()and not entry.flag_bits&1 and entry.compress_type in[0,8];fold.add(name.casefold());mode=entry.external_attr>>16;assert stat.S_IFMT(mode)in[0,stat.S_IFREG]
   with z.open(entry)as f:obj=stream(f)
   assert obj['bytes']==entry.file_size and obj['sha256']==smoke['packageFiles'][name];result['windows'][name]={**obj,'storedUnixMode':oct(mode),'CRC':entry.CRC}
   if name=='resources/app.asar':windowsAsar=z.read(entry)
  assert set(result['windows'])==set(smoke['packageFiles'])and len(result['windows'])==72
 assert result['windows']['Hollowpact.exe']['sha256']==smoke['executableSHA256']==nativeReport['executableSHA256'];assert len(windowsAsar)==31444419 and hashlib.sha256(windowsAsar).hexdigest()==ASAR
 li=json.loads((R/'reviews/root-v0.8-hunter-width-integration/LINUX-PACKAGE-IDENTITY-r2.json').read_text());linuxExpected={x['path']:x for x in li['packrecords']};dirs={str(p)for name in linuxExpected for p in PurePosixPath(name).parents};linuxAsar=None
 with tarfile.open(D/'hollowpact-0.8.0-linux-x64.tar.gz','r:gz')as t:
  seen=set();fold=set()
  for entry in t:
   name=safe(entry.name,tar=True,directory=entry.isdir());assert name not in seen and name.casefold()not in fold;seen.add(name);fold.add(name.casefold())
   if entry.isdir():assert name in dirs;result['linuxDirs'][name]={'mode':entry.mode,'uid':entry.uid,'gid':entry.gid};continue
   assert entry.isfile()and name in linuxExpected
   with t.extractfile(entry)as f:obj=stream(f)
   assert obj['bytes']==entry.size and obj['sha256']==linuxExpected[name]['sha256']and entry.size==linuxExpected[name]['bytes']and entry.mode==linuxExpected[name]['mode'];result['linux'][name]={**obj,'mode':entry.mode,'uid':entry.uid,'gid':entry.gid}
   if name=='resources/app.asar':linuxAsar=t.extractfile(entry).read()
  assert set(result['linux'])==set(linuxExpected)and len(result['linux'])==74 and set(result['linuxDirs'])==dirs
 assert linuxAsar==windowsAsar;assert result['linux']['hollowpact']['sha256']==m['nativeLinux']['executableSHA256']and li['sourceDigest']==RUNTIME and li['asarSHA256']==ASAR
 dist={str(p.relative_to(R/'dist')):file(p)for p in(R/'dist').rglob('*')if p.is_file()};assert len(dist)==55;expectedDirs={'dist'}|{'dist/'+str(p.relative_to(R/'dist'))for p in(R/'dist').rglob('*')if p.is_dir()}
 with zipfile.ZipFile(D/'hollowpact-0.8.0-web.zip')as z:
  seen=set();fold=set()
  for entry in z.infolist():
   name=safe(entry.filename,directory=entry.is_dir());assert name not in seen and name.casefold()not in fold and not entry.flag_bits&1 and entry.compress_type in[0,8];seen.add(name);fold.add(name.casefold());mode=entry.external_attr>>16
   if entry.is_dir():assert stat.S_IFMT(mode)==stat.S_IFDIR and name in expectedDirs;assert stat.S_IMODE(mode)==stat.S_IMODE((R/name).stat().st_mode);result['webDirs'][name]={'mode':oct(mode)};continue
   assert stat.S_IFMT(mode)in[0,stat.S_IFREG]and name.startswith('dist/');rel=name[5:];assert rel not in result['web']
   with z.open(entry)as f:obj=stream(f)
   assert obj==dist[rel]==file(D/'web'/rel)and obj['bytes']==entry.file_size;assert stat.S_IMODE(mode)==stat.S_IMODE((R/name).stat().st_mode);result['web'][rel]={**obj,'storedUnixMode':oct(mode),'CRC':entry.CRC}
  assert set(result['web'])==set(dist)and set(result['webDirs'])==expectedDirs
 assert {str(p.relative_to(D/'web'))for p in(D/'web').rglob('*')if p.is_file()}==set(dist)
 # Interpret the identical actual ASAR in memory only, without another package tree.
 data=windowsAsar;assert struct.unpack_from('<I',data,0)[0]==4;headerSize=struct.unpack_from('<I',data,4)[0];jsonSize=struct.unpack_from('<I',data,12)[0];header=json.loads(data[16:16+jsonSize]);bodyStart=8+headerSize;leaves={}
 def walk(tree,prefix=''):
  for name,node in tree.items():
   path=prefix+name;safe(path)
   if 'files'in node:assert 'link'not in node and not node.get('unpacked');walk(node['files'],path+'/')
   else:assert 'link'not in node and not node.get('unpacked');leaves[path]=node
 walk(header['files']);assert len(leaves)==59
 expectedLeaves={**{'dist/'+name:obj for name,obj in dist.items()},**{name:file(R/name)for name in['desktop/main.cjs','desktop/audio-lifecycle.cjs','desktop/icon.png']}};assert set(leaves)==set(expectedLeaves)|{'package.json'};spans=[];asarRecords={}
 for name,node in leaves.items():
  start=bodyStart+int(node['offset']);end=start+node['size'];assert bodyStart<=start<=end<=len(data);payload=memoryview(data)[start:end];obj={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()};assert node['integrity']['algorithm']=='SHA256'and node['integrity']['hash']==obj['sha256'];assert [hashlib.sha256(payload[i:i+node['integrity']['blockSize']]).hexdigest()for i in range(0,len(payload),node['integrity']['blockSize'])]==node['integrity']['blocks'];spans.append((start,end,name));asarRecords[name]=obj
  if name!='package.json':assert obj==expectedLeaves[name]
  else:
   actualPackage=json.loads(bytes(payload));expectedPackage=json.loads((R/'package.json').read_text());[expectedPackage.pop(k,None)for k in['scripts','keywords','devDependencies','build']];assert actualPackage==expectedPackage
 spans.sort();assert spans[0][0]==bodyStart and spans[-1][1]==len(data)and all(a[1]==b[0]for a,b in zip(spans,spans[1:]));provenance=json.loads(bytes(memoryview(data)[bodyStart+int(leaves['dist/build-provenance.json']['offset']):bodyStart+int(leaves['dist/build-provenance.json']['offset'])+leaves['dist/build-provenance.json']['size']]));assert provenance==nativeProvenance==json.loads((R/'dist/build-provenance.json').read_text());assert len(provenance['hashes'])==76 and provenance['sourceDigest']==RUNTIME;assert hashlib.sha256(json.dumps(provenance['hashes'],separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==RUNTIME
 for name,sha in provenance['hashes'].items():assert file(R/name)['sha256']==sha
 result['asar']={'sha256':ASAR,'bytes':len(data),'identicalLinuxWindowsActualBytes':True,'headerRegularLeaves':len(leaves),'all58PayloadsExact':True,'normalizedPackageExactSemanticOnly':True,'contiguousWholeDataSpans':True,'sourceInputs':76,'recomputedRuntimeDigest':RUNTIME,'leaves':asarRecords}
 save('all-current-archives-and-asar')
 for path in sorted((R/'releases').glob('*/manifest.json')):
  if path.parent==D or(path.parent/'INCOMPLETE.txt').exists():continue
  rel=str(path.relative_to(R));old=json.loads(path.read_text());canonical=subprocess.check_output(['git','show',COMMIT+':'+rel],cwd=R);assert json.loads(canonical)==old
  for name,sha in old['artifacts'].items():
   assert Path(name).name==name;archive=path.parent/name;obj=file(archive);assert obj['sha256']==sha;result['oldArchives'].append({'path':str(archive.relative_to(R)),**obj,'expectedFromCurrentCanonicalSourceManifest':True})
 assert len(result['oldArchives'])==35 and {x['path']:x['sha256']for x in result['oldArchives']}=={x['path']:x['sha256']for x in receipt['oldSealedArchives']}
 for kind,our in [('linuxFiles',result['linux']),('windowsFiles',result['windows']),('webFiles',result['web'])]:
  assert set(our)==set(receipt[kind]);assert all({k:v for k,v in our[n].items()if k in receipt[kind][n]}==receipt[kind][n]for n in our)
 for field in['manifest.json','SHA256SUMS','source-bundle-verification.json','reviews/INDEX.json']:inputs[field]=file(D/field)
 result.update({'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'PASS':True,'sourceCommit':COMMIT,'nativeActualMerge':smoke['commit'],'nativeBranchCheckpoint':m['nativeWindows']['headSourceCheckpoint'],'nativeStepCount':len(smoke['steps']),'releaseMetadataInputs':inputs,'scope':'Independent actual archive bytes and member/type/CRC/mode preservation, original CI identities and matching actual Linux/Windows ASAR/source. No new gameplay/native process/PE query/hearing/hardware/consumer install/Steam or AAA claim.'});raw=(json.dumps(result,indent=2)+'\n').encode();gz=gzip.compress(raw);(P/'ARCHIVES-RESULT-r2.json.gz').write_bytes(gz);(P/'ARCHIVES-RECEIPT-r2.json').write_text(json.dumps({'decodedBytes':len(raw),'decodedSHA256':hashlib.sha256(raw).hexdigest(),'gzipBytes':len(gz),'gzipSHA256':hashlib.sha256(gz).hexdigest(),'fiveArchives':len(result['archives']),'linux':len(result['linux']),'linuxDirs':len(result['linuxDirs']),'windows':len(result['windows']),'web':len(result['web']),'webDirs':len(result['webDirs']),'ci':len(result['nativeEvidence']),'asarLeaves':len(leaves),'oldArchives':len(result['oldArchives'])},indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k in['PASS','sourceCommit','finishedUTC','nativeActualMerge','nativeBranchCheckpoint','nativeStepCount']}))
except BaseException as e:
 save('FAILURE-preserved');(P/'ARCHIVE-FAILURE-r2.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':repr(e),'scope':'Actual failure preserved; no official/source writes'},indent=2)+'\n');raise
