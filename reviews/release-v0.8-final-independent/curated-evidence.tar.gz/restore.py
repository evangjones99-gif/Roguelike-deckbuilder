from pathlib import Path
import hashlib,json,datetime,subprocess,tempfile,os,gzip,zlib,shutil
R=Path('/workspace/Roguelike-deckbuilder');D=R/'releases/0.8.0';P=Path('/workspace/scratch/release-v08-final-independent-r1');commit='58efb01f4815d8b542711582b87f50168dabde81';bundle=D/'hollowpact-0.8.0-source.bundle';h=lambda b:hashlib.sha256(b).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,stderr=subprocess.PIPE)
cap=json.loads((P/'CAPACITY-PREFLIGHT.json').read_text());v=os.statvfs('/tmp');free=v.f_bavail*v.f_frsize;assert free>=bundle.stat().st_size+32*1024*1024+256*1024*1024
with bundle.open('rb')as f:
 header=[]
 while True:
  line=f.readline(1024);assert line and len(line)<1024
  if line==b'\n':break
  header.append(line)
assert header[0]==b'# v2 git bundle\n';expected=[commit+' HEAD',commit+' refs/heads/codex/lanternbound-production'];assert sorted(x.decode().strip()for x in header[1:])==sorted(expected)
base=Path(tempfile.mkdtemp(prefix='hollowpact-v08-independent-archive-'));bare=base/'restored.git';(base/'OWNED-DERIVED-RESTORE.txt').write_text('Independent derived restore only; original source bundle remains durable and unchanged.\n');(P/'RESTORE-START.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':str(base),'bare':str(bare),'tmpFreeBytesBeforeRestore':free,'capacityRequiredBytes':bundle.stat().st_size+32*1024*1024+256*1024*1024,'sourceCommit':commit,'sourceBundleBytes':bundle.stat().st_size,'scope':'Fresh independent TMP bare; no producer repository/alternates reused. Large file is derived inspection data, not an official version or original dataset.'},indent=2)+'\n')
logs=[]
def run(*args):
 result=subprocess.run(['git',*args],cwd=bare if bare.exists()else base,stdout=subprocess.PIPE,stderr=subprocess.PIPE);logs.append({'args':args,'returncode':result.returncode,'stdout':result.stdout.decode(errors='replace'),'stderr':result.stderr.decode(errors='replace')});(P/'RESTORE-COMMANDS.json').write_text(json.dumps(logs,indent=2)+'\n');assert result.returncode==0,args;return result.stdout
try:
 run('init','--bare',str(bare));run('bundle','verify',str(bundle));assert sorted(run('bundle','list-heads',str(bundle)).decode().strip().splitlines())==sorted(expected);assert sorted(run('bundle','unbundle',str(bundle)).decode().strip().splitlines())==sorted(expected)
 run('update-ref','refs/heads/codex/lanternbound-production',commit);run('symbolic-ref','HEAD','refs/heads/codex/lanternbound-production');assert run('rev-parse','HEAD').decode().strip()==commit;assert not (bare/'objects/info/alternates').exists();run('fsck','--full','--strict')
 sourceClosure=sorted(git(R,'rev-list','--objects','--no-object-names',commit).decode().splitlines());restoredClosure=sorted(run('rev-list','--objects','--no-object-names',commit).decode().splitlines());allObjects=sorted(run('cat-file','--batch-all-objects','--batch-check=%(objectname)').decode().splitlines());assert sourceClosure==restoredClosure==allObjects
 assert git(R,'cat-file','commit',commit)==run('cat-file','commit',commit)
 sourceTree=git(R,'ls-tree','-r','-z',commit);restoredTree=run('ls-tree','-r','-z',commit);assert sourceTree==restoredTree;treeid=run('rev-parse',commit+'^{tree}').decode().strip();entries=[]
 for item in sourceTree.split(b'\0'):
  if not item:continue
  info,name=item.split(b'\t',1);mode,kind,oid=info.split();assert kind==b'blob';entries.append((name.decode(),mode.decode(),oid.decode()))
 blobs={};readers=[subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)for root in[R,bare]]
 try:
  for name,mode,oid in entries:
   if oid in blobs:continue
   samples=[]
   for proc in readers:
    proc.stdin.write((oid+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip().split();assert len(header)==3 and header[:2]==[oid,'blob'];size=int(header[2]);remain=size;sha=hashlib.sha256();blob=hashlib.sha1(('blob '+str(size)+'\0').encode())
    while remain:
     chunk=proc.stdout.read(min(1024*1024,remain));assert chunk;remain-=len(chunk);sha.update(chunk);blob.update(chunk)
    assert proc.stdout.read(1)==b'\n'and blob.hexdigest()==oid;samples.append({'bytes':size,'sha256':sha.hexdigest()})
   assert samples[0]==samples[1];blobs[oid]=samples[0]
 finally:
  for proc in readers:proc.stdin.close();assert proc.wait(timeout=30)==0
 records=[{'path':name,'mode':mode,'gitBlob':oid,**blobs[oid]}for name,mode,oid in entries];byPath={r['path']:r for r in records};index=json.loads((D/'reviews/INDEX.json').read_text());assert index['sourceCommit']==commit and index['sourceArchive']=='hollowpact-0.8.0-source.bundle'and index['sourceArchiveFormat']=='git-bundle-v2';declared={f['path']:f for f in index['files']};canonical={r['path']:r for r in records if r['path'].startswith('reviews/')};assert len(declared)==len(index['files'])and set(declared)==set(canonical)
 for name,obj in declared.items():assert obj=={k:v for k,v in canonical[name].items()if k!='mode'}and canonical[name]['mode']in['100644','100755']
 pairs=[]
 for pair in index['rawGzipPairs']:
  compressed=pair['compressedPath'];rawPath=pair['rawPath'];assert compressed==rawPath+'.gz'and compressed in canonical
  # Read canonical gzip as a blob; retain no large decompressed/whole input copy.
  proc=subprocess.Popen(['git','cat-file','blob',canonical[compressed]['gitBlob']],cwd=bare,stdout=subprocess.PIPE,stderr=subprocess.PIPE);digest=hashlib.sha256();count=0
  try:
   with gzip.GzipFile(fileobj=proc.stdout,mode='rb')as zin:
    while chunk:=zin.read(1024*1024):count+=len(chunk);assert count<=pair['rawBytes'];digest.update(chunk)
   assert proc.wait(timeout=30)==0
  finally:
   if proc.poll()is None:proc.kill();proc.wait()
  assert count==pair['rawBytes']and digest.hexdigest()==pair['rawSHA256'];original=R/rawPath;assert original.is_file()and original.stat().st_size==count
  with original.open('rb')as f:
   d=hashlib.sha256()
   while chunk:=f.read(1024*1024):d.update(chunk)
  assert d.hexdigest()==pair['rawSHA256'];pairs.append({**pair,'canonicalGzipGitBlob':canonical[compressed]['gitBlob'],'decodedOriginalRetainedRawExact':True,'originalRawResolvedPath':str(original.resolve())})
 available=[r['path']for r in records if r['path'].startswith('reviews/')and r['path'].endswith('.json.gz')and (R/r['path'][:-3]).is_file()];assert set(available)=={x['compressedPath']for x in pairs}
 provenance=json.loads((R/'dist/build-provenance.json').read_text());assert provenance['sourceDigest']=='23477f68c99d6d60b0b3f82b286a8d33bb6da6f2ca92c103fbecf5663634959f'and len(provenance['hashes'])==76
 for name,sha in provenance['hashes'].items():
  assert byPath[name]['sha256']==sha
  with (R/name).open('rb')as f:
   d=hashlib.sha256()
   while chunk:=f.read(1024*1024):d.update(chunk)
  assert d.hexdigest()==sha
 raw= (json.dumps({'sourceCommit':commit,'tree':treeid,'files':records},separators=(',',':'))+'\n').encode();(P/'CURRENT-TREE-BLOBS.json.gz').write_bytes(gzip.compress(raw));(P/'TREE-BLOBS-RECEIPT.json').write_text(json.dumps({'decodedBytes':len(raw),'decodedSHA256':h(raw),'gzipSHA256':h((P/'CURRENT-TREE-BLOBS.json.gz').read_bytes()),'entries':len(records),'uniqueCurrentBlobsFullyStreamedFromEachRepo':len(blobs)},indent=2)+'\n');(P/'RAW-GZIP-PAIRS.json').write_text(json.dumps(pairs,indent=2)+'\n');(P/'REACHABLE-OBJECTS.json.gz').write_bytes(gzip.compress(('\n'.join(sourceClosure)+'\n').encode()))
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'PASS':True,'sourceCommit':commit,'tree':treeid,'refs':expected,'noPrerequisites':True,'newBare':str(bare),'noAlternates':True,'fsckFullStrict':True,'reachableObjects':len(allObjects),'exactSourceReachableClosureAndNoExtras':True,'completeCurrentTreeEntries':len(records),'uniqueCurrentBlobBodiesCompared':len(blobs),'canonicalReviewFiles':len(canonical),'rawGzipPairs':len(pairs),'all76RuntimeInputSHAExactCanonicalAndWorking':True,'qualification':'Only fresh source archive restoration and exact preservation; no new gameplay, native install, hearing/hardware, consumer or Steam qualification.'};(P/'RESTORE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));
except BaseException as e:
 (P/'RESTORE-FAILURE.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':repr(e),'freshBareRetained':str(bare),'scope':'Failure preserved; no official archive/source edited.'},indent=2)+'\n');raise
