from pathlib import Path
from PIL import Image
import gzip,json,hashlib
p=Path('/workspace/scratch/bone-thrall-art-visual-independent-v09-r1');image=Image.open('/workspace/scratch/bone-thrall-art-author-v09-r1/generated-original-r1.png');alpha=image.getchannel('A');thresholds={str(k):alpha.point(lambda v:255 if v>=k else 0).getbbox()for k in [1,8,32,128]};atlas=Image.open('/workspace/Roguelike-deckbuilder/public/art/adversaries-atlas.png').getchannel('A').crop((0,627,627,1254));ab=atlas.point(lambda v:255 if v>=8 else 0).getbbox();samples=[];frames=[]
for case in sorted((p/'run-r2').glob('case-*.json.gz')):
 r=json.loads(gzip.decompress(case.read_bytes()))
 for g in r['probe']['groups']:
  for d in g['draws']:
   bone='bone-thrall' in d['url'];wraith='adversaries-atlas' in d['url']and d['args'][:4]==[0,627,627,627]
   if not(bone or wraith)or d['alpha']<.05:continue
   sx,sy,sw,sh,dx,dy,w,h=d['args'];a,b,c,e,tx,ty=d['matrix'];bbox=thresholds['8']if bone else ab;corners=[]
   for u,v in [(bbox[0],bbox[1]),(bbox[2],bbox[1]),(bbox[0],bbox[3]),(bbox[2],bbox[3])]:
    x,y=dx+u/sw*w,dy+v/sh*h;corners.append((a*x+c*y+tx,b*x+e*y+ty))
   box=[min(q[0]for q in corners),min(q[1]for q in corners),max(q[0]for q in corners),max(q[1]for q in corners)];within=box[0]>=0 and box[1]>=0 and box[2]<=d['w']and box[3]<=d['h']
   samples.append({'case':r['number'],'variant':r['v'],'mode':r['mode'],'viewportWidth':r['width'],'group':g['id'],'at':g['at'],'image':'bone'if bone else 'wraith','actualCanvas':[d['w'],d['h']],'groupRect':g['rect'],'bounds':box,'within':within,'alpha':d['alpha']})
 for i,f in enumerate(r['probe']['frames'],1):frames.append({'case':r['number'],'variant':r['v'],'mode':r['mode'],'viewportWidth':r['width'],'frame':i,'group':f['group']['id'],'actualCanvas':[f['w'],f['h']],'rect':f['group']['rect']})
result={'scope':'Read-only alpha8 affine source hulls compared against actual Canvas dimensions recorded at each same draw, not final viewport dimensions. Captured RAF images are actual complete Canvas contents, software-browser presentation samples, not OS/hardware video proof.','originalPngSha256':hashlib.sha256(Path('/workspace/scratch/bone-thrall-art-author-v09-r1/generated-original-r1.png').read_bytes()).hexdigest(),'alphaBounds':thresholds,'wraithCellAlpha8Bounds':ab,'samples':samples,'earlyFrames':frames,'counts':{v:{'observations':sum(x['variant']==v for x in samples),'outside':sum(x['variant']==v and not x['within']for x in samples)}for v in ['baseline','candidate']}}
with(p/'DRAW-ANALYSIS.json').open('x')as f:json.dump(result,f,indent=2)
print(result['counts']);print('actualoutside',[(x['case'],x['mode'],x['viewportWidth'],x['bounds'],x['actualCanvas'])for x in samples if not x['within']][:10])
