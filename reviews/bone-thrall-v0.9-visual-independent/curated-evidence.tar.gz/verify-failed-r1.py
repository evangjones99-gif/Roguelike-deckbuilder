from pathlib import Path
import hashlib,json,urllib.request,sys
p=Path('/workspace/scratch/bone-thrall-art-author-v09-r1-supplement-r2');orig=Path('/workspace/scratch/bone-thrall-art-author-v09-r1');out=Path('/workspace/scratch/bone-thrall-art-visual-independent-v09-r1');sha=lambda b:hashlib.sha256(b).hexdigest();assert sha((p/'MANIFEST.json').read_bytes())=='1bc9fce3c8da0c56a8fbd00d9683e48ff3630027f03c7eb076ea61d92d080ecb'
m=json.loads((p/'MANIFEST.json').read_text())
for x in m['files']:
 b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],x['path']
old=json.loads((p/'ORIGINAL-BEFORE.json').read_text())
for x in old:
 f=orig/x['path'];b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],x['path']
 if x['symlink'] is not None:assert str(f.readlink())==x['symlink']
ident=json.loads((p/'SOURCE-BUILD-IDENTITY.json').read_text());base=json.loads((p/'BASELINE-INPUTS.json').read_text());result={}
for v,sources,root,port in [('baseline',[dict(path=n,**x)for n,x in base.items()],Path('/workspace/scratch/hound-jaw-hinge-author-v08-r5/baseline/dist'),4599),('candidate',ident['sources'],orig/'prototype/dist',4598)]:
 hashes={};inputs={}
 for x in sources:
  b=Path(x['input']).read_bytes();assert len(b)==x['bytes']and sha(b)==x['sha256'];hashes[x['path']]=x['sha256'];inputs[x['path']]={'bytes':len(b),'sha256':sha(b),'input':x['input']}
 digest=sha(json.dumps(hashes,separators=(',',':')).encode());prov=json.loads(urllib.request.urlopen(f'http://127.0.0.1:{port}/build-provenance.json').read());assert prov['sourceDigest']==digest
 builds={}
 for f in sorted(root.rglob('*')):
  if f.is_file():
   n=str(f.relative_to(root));b=f.read_bytes();h=urllib.request.urlopen(f'http://127.0.0.1:{port}/{n}').read();assert h==b;builds[n]={'bytes':len(b),'sha256':sha(b)}
 assert len(inputs)==(76 if v=='baseline'else77)and len(builds)==(55 if v=='baseline'else56);result[v]={'digest':digest,'inputs':inputs,'outputs':builds}
with(out/sys.argv[1]).open('x')as f:json.dump({'supplementFiles':len(m['files']),'originalRows':len(old),'variants':result},f,indent=2)
print('Verified original174, complete supplement, candidate77/56, baseline76/55, full HTTP')
