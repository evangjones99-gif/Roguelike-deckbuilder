import json,gzip,pathlib,collections
root=pathlib.Path('/workspace/scratch/preparation-v08');runs=json.loads((root/'results/outcomes.json').read_text());lost=[r for r in runs if not r['win']];ids=set(r['id']for r in lost);context={id:collections.deque(maxlen=12)for id in ids}
for line in gzip.open(root/'results/full-state-transitions.jsonl.gz','rt'):
 row=json.loads(line)
 if row['id']in ids:context[row['id']].append(row)
out=root/'negative-context';out.mkdir()
for r in lost:
 (out/(r['kit']+'-introduced-loss.json')).write_text(json.dumps({'outcome':r,'last12FullStateRecords':list(context[r['id']]),'limits':'Actuallegal diagnosticcustominitialdeck trajectory, notearnedstartercollection; legacycomparisonworld can differ.'},indent=2)+'\n')
