import {readFileSync,writeFileSync,mkdirSync,createWriteStream,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';import {createGzip} from 'node:zlib';import {once} from 'node:events';
import {createGame,applyAction,applyActionWithEvents,legalActions,validateState,CARDS,type GameState,type Action} from './src/engine';
import {STARTER_DECK} from './src/content';import {heuristicScore} from './scripts/simulate';
import {chooseFrozen,chooseOutside} from './scripts/policy-adapter';
const root='/workspace/scratch/preparation-v08',repo='/workspace/Roguelike-deckbuilder',plan=JSON.parse(readFileSync(root+'/plan.json','utf8')),policy=JSON.parse(readFileSync(root+'/source/reviews/ml-policy-0.5-r1/policy.json','utf8'));
const hash=(x:string|Buffer)=>createHash('sha256').update(x).digest('hex');const json=(x:unknown)=>JSON.stringify(x);
function guard(){for(const [p,h]of Object.entries(plan.sourceHashes)){if(hash(readFileSync(root+'/source/'+p))!==h||hash(readFileSync(repo+'/'+p))!==h)throw Error('Source changed '+p);}}
guard();if(existsSync(root+'/results'))throw Error('Refusing previous/partial output');mkdirSync(root+'/results');
writeFileSync(root+'/results/execution-started.json',json({planSha256:hash(readFileSync(root+'/plan.json')),harnessSha256:hash(readFileSync(root+'/source/matrix.ts')),node:process.version,policySha256:hash(readFileSync(root+'/source/reviews/ml-policy-0.5-r1/policy.json')),sourceHashes:plan.sourceHashes})+'\n',{flag:'wx'});
const stream=createGzip({level:6}),file=createWriteStream(root+'/results/full-state-transitions.jsonl.gz',{flags:'wx'});stream.pipe(file);let stateRecords=0;
async function record(x:unknown){stateRecords++;if(!stream.write(json(x)+'\n'))await once(stream,'drain');}
const outcomes:any[]=[];let failure:any=null;
try {
 for(const generation of plan.worldGenerations)for(const policyName of plan.policies)for(const acquisition of plan.acquisitionArms)for(const seed of plan.seeds)for(const kit of plan.kits){
  const id=`g${generation}-${policyName}-${acquisition}-${seed}-${kit.id}`;let s=createGame(seed,plan.difficulty,{engineKind:generation}),steps=0;
  if(json(s.deck)!==json(STARTER_DECK)||!validateState(s))throw Error('Default construction changed');
  const initialDefault=json(s);if(kit.id!=='default'){s={...s,deck:kit.deck.slice()};const expected=JSON.parse(initialDefault);expected.deck=kit.deck.slice();if(json(expected)!==json(s))throw Error('Nondeck construction change');}
  if(!validateState(s)||s.deck.length!==12||s.deck.some((c:string)=>!CARDS[c]))throw Error('Invalid diagnostic initial');
  const initialStateSha256=hash(json(s)),trajectory=createHash('sha256').update(json(s));
  let minLivingHp=s.hp,received=0,enemyHpLost=0,companionHpLost=0,blockedHunter=0,healedHunter=0,deaths=0,commandHpLost=0,spellHpLost=0;
  const played:Record<string,number>={},actionsCount:Record<string,number>={},world:any[]=[],battles:any[]=[];let active:any=null;
  await record({id,step:-1,diagnosticKit:kit.id!=='default',state:s});
  while(!['victory','defeat'].includes(s.phase)&&steps<plan.maxAcceptedActions){
   const legal=legalActions(s);if(!legal.length)break;let action:Action;
   if(s.phase!=='battle')action=s.phase==='reward'&&acquisition==='skip-rewards'?legal.find(a=>a.type==='reward'&&a.card===null)!:chooseOutside(s,legal);
   else if(policyName==='existing-heuristic-combat')action=legal.reduce((best,a)=>heuristicScore(s,a)>heuristicScore(s,best)?a:best,legal[0]);
   else action=chooseFrozen(s,policy.weights,null);
   if(!legal.some(a=>json(a)===json(action)))throw Error('Nonlegal choice '+id);
   const before=json(s),ordinary=applyAction(s,action),result=applyActionWithEvents(s,action),next=result.state,events=result.events;
   if(next===s||json(s)!==before||!validateState(next)||json(ordinary)!==json(next)||json(applyAction(JSON.parse(before),action))!==json(next)||!validateState(JSON.parse(json(next))))throw Error('Accepted action/state/save/event equivalence fail '+id+' '+steps);
   if((next.schema===2?1:next.engineKind)!==generation)throw Error('Generation changed');
   actionsCount[action.type]=(actionsCount[action.type]||0)+1;
   if(action.type==='play'){const c=s.hand[action.index];played[c]=(played[c]||0)+1;}
   if(action.type==='travel'&&next.phase==='battle'){world.push({kind:'encounter',floor:next.floor,route:action.choice,formation:next.enemies.map(u=>u.cardId)});active={floor:next.floor,encounter:next.enemies.map(u=>u.cardId),startHp:next.hp,startActions:steps,startTurns:next.stats.turns};}
   if(next.phase==='reward'&&s.phase==='battle')world.push({kind:'reward',floor:next.floor,offer:next.rewards.slice()});
   if(next.phase==='shop'&&s.phase==='map')world.push({kind:'shop',floor:next.floor,offer:next.rewards.slice()});
   if(action.type==='reward')world.push({kind:'acquire',floor:s.floor,card:action.card});
   for(const e of events){if(e.type==='hit'){
    if(e.target==='hunter'){received+=e.hpLost;blockedHunter+=e.blocked;if(active)active.received=(active.received||0)+e.hpLost;}
    else if(e.target.startsWith('a'))companionHpLost+=e.hpLost;
    else if(e.target.startsWith('e')){enemyHpLost+=e.hpLost;if(e.kind==='command')commandHpLost+=e.hpLost;if(e.kind==='spell')spellHpLost+=e.hpLost;}
   }else if(e.type==='heal'&&e.target==='hunter')healedHunter+=e.amount;else if(e.type==='death'&&e.target.startsWith('a'))deaths++;}
   if(next.hp>0)minLivingHp=Math.min(minLivingHp,next.hp);
   if(active&&s.phase==='battle'&&next.phase!=='battle'){battles.push({...active,endHp:next.hp,turns:s.turn,acceptedActions:steps-active.startActions+1,result:next.phase});active=null;}
   trajectory.update(json({action,state:next,events}));await record({id,step:steps,action,state:next,events});s=next;steps++;
  }
  if(active)battles.push({...active,endHp:s.hp,turns:s.turn,acceptedActions:steps-active.startActions,result:s.phase});
  outcomes.push({id,kit:kit.id,generation,policy:policyName,acquisition,seed,difficulty:plan.difficulty,phase:s.phase,win:s.phase==='victory',floor:s.floor,hp:s.hp,minLivingHp,steps,turns:s.stats.turns,cardsPlayed:s.stats.cardsPlayed,damageDealtStat:s.stats.damageDealt,enemyHpLost,commandHpLost,spellHpLost,hunterHpLost:received,hunterHealEvents:healedHunter,hunterBlocked:blockedHunter,companionHpLost,companionDeaths:deaths,played,actionsCount,world,battles,initialStateSha256,finalStateSha256:hash(json(s)),trajectorySha256:trajectory.digest('hex'),stalled:!['victory','defeat'].includes(s.phase)});
  if(outcomes.length%24===0)console.log('Finished '+outcomes.length+'/'+plan.episodeCount);
 }
 guard();
}catch(e){failure=String(e);writeFileSync(root+'/results/failure.json',json({failure,completed:outcomes.length})+'\n',{flag:'wx'});}
stream.end();await once(file,'finish');writeFileSync(root+'/results/outcomes.json',JSON.stringify(outcomes,null,2)+'\n',{flag:'wx'});writeFileSync(root+'/results/completion.json',JSON.stringify({completed:outcomes.length,stateRecords,failure,sourceHashes:plan.sourceHashes,fullDatasetSha256:hash(readFileSync(root+'/results/full-state-transitions.jsonl.gz'))},null,2)+'\n',{flag:'wx'});if(failure)throw Error(failure);console.log('Completed all '+outcomes.length+'; fullstate records '+stateRecords);
