import {applyAction,legalActions,validateState,CARDS,type GameState,type Action} from '../src/engine';
const sum = (s: GameState, field: 'hp' | 'attack') => s.allies.reduce((n, u) => n + u[field], 0);
const enemyHp = (s: GameState) => s.enemies.reduce((n, u) => n + u.hp, 0);
const incoming = (s: GameState) => s.enemies.reduce((n, u) => n +
  (u.intent?.target === 'hunter' || u.intent?.target === 'all' ? u.intent.damage : 0), 0);
function features(s: GameState, a: Action, n: GameState): number[] {
  const remainsBattle = n.phase === 'battle';
  return [(enemyHp(s) - (remainsBattle ? enemyHp(n) : 0)) / 10, (n.hp - s.hp) / 10,
    remainsBattle ? (sum(n, 'attack') - sum(s, 'attack')) / 5 : 0,
    remainsBattle ? (sum(n, 'hp') - sum(s, 'hp')) / 15 : 0,
    remainsBattle ? (Math.min(n.block, incoming(s)) - Math.min(s.block, incoming(s))) / 10 : 0,
    remainsBattle ? (n.energy - s.energy) / 5 : 0, a.type === 'endTurn' ? 1 : 0,
    n.phase === 'reward' || n.phase === 'victory' ? 1 : n.phase === 'defeat' ? -2 : 0];
}
function cardValue(a: Action): number {
  if (a.type !== 'reward' || a.card === null) return 0;
  const c = CARDS[a.card];
  return c.type === 'summon' ? (c.attack ?? 0) * 2 + (c.hp ?? 0) * 0.25 - c.cost * 0.5 :
    ({ rally: 15, communion: 14, ready: 13, pack: 11, siphon: 10, aoe: 8, draw: 7,
      block: 4, damage: 5, energy: 1, heal: 3, shelter: 5 }[c.effect as 'rally'] ?? 4);
}
function outside(s: GameState, actions: Action[]): Action {
  if (s.phase === 'map') return actions.find(a => a.type === 'travel' && a.choice === 'camp') ??
    actions.find(a => a.type === 'travel' && a.choice === 'battle') ?? actions[0];
  if (s.phase === 'camp') return actions.find(a => a.type === 'camp' &&
    a.choice === (s.hp < s.maxHp - 14 ? 'rest' : 'train')) ?? actions[0];
  if (s.phase === 'event') return actions.find(a => a.type === 'event' && a.choice === 'forage') ?? actions[0];
  if (s.phase === 'shop') return actions.find(a => a.type === 'leave') ?? actions[0];
  if (s.phase === 'reward') {
    if (s.deck.length >= 19) return actions.find(a => a.type === 'reward' && a.card === null)!;
    return actions.slice().sort((a, b) => cardValue(b) - cardValue(a))[0];
  }
  return actions[0];
}
function choose(s: GameState, w: readonly number[], random: (() => number) | null): Action {
  const actions = legalActions(s);
  if (random) return actions[Math.floor(random() * actions.length)];
  if (s.phase !== 'battle') return outside(s, actions);
  let chosen = actions[0], best = -Infinity;
  for (const a of actions) {
    const n = applyAction(s, a);
    if (n === s || !validateState(n)) throw Error('Invalid legal preview');
    const f = features(s, a, n);
    let score = f.reduce((value, x, i) => value + x * w[i], 0);
    if (a.type === 'attack') score += 0.15;
    if (score > best) { best = score; chosen = a; }
  }
  return chosen;
}

export {choose as chooseFrozen, outside as chooseOutside};
