import json,pathlib,statistics,collections,gzip,hashlib
root=pathlib.Path('/workspace/scratch/preparation-v08');runs=json.loads((root/'results/outcomes.json').read_text());plan=json.loads((root/'plan.json').read_text());index={(x['generation'],x['policy'],x['acquisition'],x['seed'],x['kit']):x for x in runs}
summaries=[];pairs=[];world=[];negatives=[]
for gen in plan['worldGenerations']:
 for policy in plan['policies']:
  for acq in plan['acquisitionArms']:
   for kit in [x['id'] for x in plan['kits']]:
    xs=[x for x in runs if (x['generation'],x['policy'],x['acquisition'],x['kit'])==(gen,policy,acq,kit)]
    summaries.append({'generation':gen,'policy':policy,'acquisition':acq,'kit':kit,'n':len(xs),'wins':sum(x['win'] for x in xs),'incomplete':sum(x['stalled'] for x in xs),'mean':{m:statistics.mean(x[m] for x in xs) for m in ['hp','floor','steps','turns','hunterHpLost','companionDeaths','enemyHpLost','commandHpLost','spellHpLost']},'playedTotal':dict(sum((collections.Counter(x['played']) for x in xs),collections.Counter()))})
   for seed in plan['seeds']:
    b=index[(gen,policy,acq,seed,'default')]
    for kit in ['pursuit','vigil','ash']:
     c=index[(gen,policy,acq,seed,kit)];row={'generation':gen,'policy':policy,'acquisition':acq,'seed':seed,'kit':kit,'baselineId':b['id'],'candidateId':c['id'],'baselineWin':b['win'],'candidateWin':c['win'],'introducedLoss':b['win'] and not c['win'],'rescue':not b['win'] and c['win'],'deltas':{m:c[m]-b[m] for m in ['hp','steps','turns','hunterHpLost','companionDeaths','enemyHpLost']}}
     pairs.append(row)
     if row['introducedLoss']or(row['deltas']['hp']<0 and row['deltas']['steps']>0):negatives.append(row)
     bw={(x['kind'],x['floor']):x for x in b['world'] if x['kind']!='acquire'};cw={(x['kind'],x['floor']):x for x in c['world'] if x['kind']!='acquire'}
     for key in sorted(bw.keys()&cw.keys()):
      if bw[key]!=cw[key]:world.append({'generation':gen,'policy':policy,'acquisition':acq,'seed':seed,'kit':kit,'key':key,'baseline':bw[key],'candidate':cw[key]})
# Reaggregate actual completegzip records; no episode rerun/learning. Detached duplicate checks, retained stages.
seen={};event_min={};tracehash={};records=0;max_step={};default_initial_equal=0;damage_by_source=collections.defaultdict(collections.Counter)
for line in gzip.open(root/'results/full-state-transitions.jsonl.gz','rt'):
 x=json.loads(line);records+=1;id=x['id'];s=x['state']
 if x['step']==-1:
  if id in seen:raise RuntimeError('Duplicate episode initial')
  seen[id]=s;tracehash[id]=hashlib.sha256(json.dumps(s,separators=(',',':'),ensure_ascii=False).encode());event_min[id]=65;max_step[id]=-1
 else:
  if x['step']!=max_step[id]+1:raise RuntimeError('Stepsequence')
  max_step[id]=x['step'];seen[id]=s
  # Trajectory bytes must match JSJSON numeric/string conventions (no floatingnumeric states).
  tracehash[id].update(json.dumps({'action':x['action'],'state':s,'events':x['events']},separators=(',',':'),ensure_ascii=False).encode())
  for e in x['events']:
   if e['type']=='hit'and e['target']=='hunter'and e['afterHp']>0:event_min[id]=min(event_min[id],e['afterHp'])
   if e['type']=='hit'and e['target'].startswith('e'):damage_by_source[id][e['kind']]+=e['hpLost']
checks=[]
for x in runs:
 s=seen[x['id']];checks.append({'id':x['id'],'finalHashMatch':hashlib.sha256(json.dumps(s,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==x['finalStateSha256'],'trajectoryHashMatch':tracehash[x['id']].hexdigest()==x['trajectorySha256'],'recordedStepsMatch':max_step[x['id']]+1==x['steps'],'minResolvedPositiveHunterHP':event_min[x['id']],'enemyDamageByKind':dict(damage_by_source[x['id']])})
if not all(c['finalHashMatch']and c['trajectoryHashMatch']and c['recordedStepsMatch']for c in checks):raise RuntimeError('Tracehash mismatch')
report={'method':'Separate implementingauthor reaggregation, NOT independent agentreview; no episodes rerun. All defaultbaseline episodes preserved; all candidates synthetic diagnosticdeck replacement beforefirsttravel.','episodes':len(runs),'stateRecords':records,'failures':json.loads((root/'results/completion.json').read_text())['failure'],'summaries':summaries,'pairCount':len(pairs),'perKitPaired':{kit:{'n':len([p for p in pairs if p['kit']==kit]),'introducedLosses':[p for p in pairs if p['kit']==kit and p['introducedLoss']],'rescues':[p for p in pairs if p['kit']==kit and p['rescue']],'lowerHpPairs':sum(p['deltas']['hp']<0 for p in pairs if p['kit']==kit),'moreActionPairs':sum(p['deltas']['steps']>0 for p in pairs if p['kit']==kit),'moreTurnPairs':sum(p['deltas']['turns']>0 for p in pairs if p['kit']==kit),'largestHpDrop':min(p['deltas']['hp']for p in pairs if p['kit']==kit),'meanDelta':{m:statistics.mean(p['deltas'][m]for p in pairs if p['kit']==kit)for m in ['hp','steps','turns','hunterHpLost','companionDeaths']}}for kit in ['pursuit','vigil','ash']},'commonWorldDiscrepancies':{'generation1':sum(w['generation']==1 for w in world),'generation2':sum(w['generation']==2 for w in world)},'recordChecks':'All384 final/trajectoryhashes and stepcounts matched full dataset; purity/legal/save/actualeventstateequality performed in episodeharness. PositiveacceptedHP metric differs from eventresolvedHP; actualevent minima separatelyretained.'}
for name,value in [('summary.json',report),('paired-all.json',pairs),('negatives.json',negatives),('world-discrepancies.json',world),('full-trace-verification.json',checks)]:
 p=root/'results'/name
 if p.exists():raise RuntimeError('Refusing existing derivative '+name)
 p.write_text(json.dumps(value,indent=2)+'\n')
print('verified',len(checks),'stateRecords',records,'worlddiffs',report['commonWorldDiscrepancies'])
for k,v in report['perKitPaired'].items():print(k,'newlosses',[(x['seed'],x['generation'],x['policy'],x['acquisition'])for x in v['introducedLosses']],'deltas',v['meanDelta'],'lowerHP',v['lowerHpPairs'],'moreActions',v['moreActionPairs'])
