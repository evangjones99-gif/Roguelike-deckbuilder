"""One-shot bounded R4 source/art seal, never JS/browser evaluation."""
import os,pathlib,hashlib,json,time,stat
ROOT=pathlib.Path(__file__).resolve().parent;WORK=24*1024*1024;RESERVE=512*1024*1024
def memory():return int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text()),int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
INITIAL,MAXIMUM=memory()
if MAXIMUM-INITIAL<WORK+RESERVE:raise SystemExit(f'Seal initial refused current={INITIAL},maximum={MAXIMUM},work={WORK},reserve={RESERVE}')
def guard():
 current,maximum=memory();hwm=int(next(l.split()[1] for l in pathlib.Path('/proc/self/status').read_text().splitlines() if l.startswith('VmHWM:')))*1024
 spent=max(0,current-INITIAL)
 if maximum!=MAXIMUM or hwm>WORK or spent>WORK or maximum-current<RESERVE+max(0,WORK-spent):raise RuntimeError(f'Seal refused current={current},maximum={maximum},initial={INITIAL},VmHWM={hwm},work={WORK},reserve={RESERVE}')
 return current,hwm
def body(path,keep=False):
 fd=os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd)
  if not stat.S_ISREG(before.st_mode) or before.st_size>4*1024*1024:raise RuntimeError('Nonregular/oversized source')
  digest=hashlib.sha256();parts=[]
  while chunk:=os.read(fd,32768):
   digest.update(chunk)
   if keep:parts.append(chunk)
   guard()
  after=os.fstat(fd)
  if any(getattr(before,k)!=getattr(after,k) for k in ['st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_atime_ns']):raise RuntimeError('Moving source')
  return {'bytes':before.st_size,'sha256':digest.hexdigest()},b''.join(parts)
 finally:os.close(fd)
def write(name,data):
 with os.fdopen(os.open(ROOT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'w') as file:json.dump(data,file,indent=2);file.write('\n')
retained={}
for name,expected in [('r1','ee2d57c54d509c13979719dbf3ddb10e3e7700527757014b9703a0cf06529f53'),('r2','b20d27a609a5209cc1773e7f67ccaeb1139a22bd644412f78cf9818074a3e2b6'),('r3','b05122fbd39d0c61a1e3518b562b5276682e417b6368de4cd52d2edc066fd977')]:
 folder=ROOT.with_name('standard-sol-pixel-foundation-author-'+name);pin,data=body(folder/'MANIFEST.json',True)
 if pin['sha256']!=expected:raise RuntimeError('Retained manifest changed')
 old=json.loads(data)
 for file,record in old['files'].items():
  if body(folder/file)[0]!=record:raise RuntimeError('Retained body changed')
 retained[name]={'manifest':pin,'all_bodies_match':True,'body_count':len(old['files'])}
refpin,refdata=body(ROOT/'ANATOMY-REFERENCE.json',True);ref=json.loads(refdata)
if body(ref['path'])[0]!={'bytes':ref['bytes'],'sha256':ref['sha256']}:raise RuntimeError('Root reference changed')
write('SOURCE-PINS.json',{'retained':retained,'anatomy_reference_record':refpin,'anatomy_reference_body':{'bytes':ref['bytes'],'sha256':ref['sha256']},'reference_body_in_packet':False,
 'scope':'Original native R4 gravehound/adult hunter, retained skeletal masks, compact source scene and repaired full cell/readout union. Root generated nonshipping reference viewed only; no raster-input editing/sampling.',
 'execution':'Two Python indexed exports and author native/static composition inspection only. No JS/Node/server/browser/build/live game mutation or acceptance.'})
current,hwm=guard();write('SEAL-RESOURCE.json',{'admitted':True,'initial_current':INITIAL,'maximum':MAXIMUM,'current_at_report':current,'actual_VmHWM_bytes':hwm,'work':WORK,'reserve':RESERVE,'time_ns':time.time_ns(),'scope':'This32KiBsource seal only; actual/proc VmHWM. Source copy/export records separate.'})
files={}
for path in sorted(ROOT.rglob('*')):
 if path.is_symlink():raise RuntimeError('Symlink')
 if path.is_file():files[str(path.relative_to(ROOT))]=body(path)[0]
total=sum(x['bytes'] for x in files.values())
if total>512*1024:raise RuntimeError('Small source packet exceeded512KiB')
write('MANIFEST.json',{'kind':'Original pixel R4 SOURCE freeze','scope':'Static gravehound/adult hunter/compact hand-readout lab, repaired exported full union; no browser/engine/art/fun acceptance. Earlier source freezes untouched.', 'files':files,'body_count':len(files),'body_bytes':total})
print(json.dumps({'manifest':body(ROOT/'MANIFEST.json')[0],'body_count':len(files),'body_bytes':total,'final_actual_VmHWM_bytes':guard()[1]},indent=2))
