"""Original R4 adult hunter and gravehound indexed perspective study.
Root's nonshipping anatomy reference was viewed, never sampled/filtered/imported.
"""
import json,pathlib,struct,zlib,hashlib,os,time
ROOT=pathlib.Path(__file__).resolve().parent
W=H=64;WORK=24*1024*1024;RESERVE=512*1024*1024
PALETTE=[None,'#14171b','#26333c','#43535d','#6b7c80','#6e6552','#b3aa89','#e0d9b0','#626967','#969d92','#795a41','#64393f','#92565b','#e9a25b','#514840','#8a8170'];KEYS='0123456789ABCDEF'
FRAMES=['idle0','idle1','bind','anticipate','contact','hit','death']
INITIAL=MAXIMUM=None
def guard():
 current=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());maximum=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
 hwm=int(next(l.split()[1] for l in pathlib.Path('/proc/self/status').read_text().splitlines() if l.startswith('VmHWM:')))*1024
 spent=max(0,current-INITIAL)
 if maximum!=MAXIMUM or hwm>WORK or spent>WORK or maximum-current<RESERVE+max(0,WORK-spent):raise RuntimeError(f'Source refusal current={current},maximum={maximum},initial={INITIAL},VmHWM={hwm},work={WORK},reserve={RESERVE}')
 return current,hwm
def grid():return [['0']*W for _ in range(H)]
def pixel(g,x,y,c):
 assert isinstance(x,int) and isinstance(y,int) and 0<=x<W and 0<=y<H,(x,y,c)
 assert c in KEYS;g[y][x]=c
def rect(g,x,y,w,h,c):
 for py in range(y,y+h):
  for px in range(x,x+w):pixel(g,px,py,c)
def poly(g,points,c):
 for y in range(min(p[1] for p in points),max(p[1] for p in points)+1):
  for x in range(min(p[0] for p in points),max(p[0] for p in points)+1):
   inside=False;j=len(points)-1
   for i in range(len(points)):
    a,b=points[i],points[j]
    if (a[1]>y+.5)!=(b[1]>y+.5) and x+.5<(b[0]-a[0])*(y+.5-a[1])/(b[1]-a[1])+a[0]:inside=not inside
    j=i
   if inside:pixel(g,x,y,c)
def line(g,a,b,c,width=1):
 x,y=a;tx,ty=b;dx=abs(tx-x);dy=-abs(ty-y);sx=1 if x<tx else -1;sy=1 if y<ty else -1;err=dx+dy;r=width//2
 while True:
  for yy in range(y-r,y+r+1):
   for xx in range(x-r,x+r+1):pixel(g,xx,yy,c)
  if x==tx and y==ty:break
  twice=2*err
  if twice>=dy:err+=dy;x+=sx
  if twice<=dx:err+=dx;y+=sy
def limb(g,a,j,b,c='3',width=3):
 line(g,a,j,'1',width+2);line(g,j,b,'1',width+2);line(g,a,j,c,width);line(g,j,b,c,width)
def mask(g,x,y,rows):
 for dy,row in enumerate(rows):
  for dx,c in enumerate(row):
   if c!='0':pixel(g,x+dx,y+dy,c)
def paw(g,x,y,c='4'):
 poly(g,[(x-2,y-4),(x+2,y-4),(x+4,y-2),(x+6,y-1),(x+6,y+1),(x-3,y+1),(x-3,y-2)],'1')
 rect(g,x-1,y-2,4,2,c);rect(g,x-1,y,6,1,c);pixel(g,x+4,y,'6')
def rear_head(g,x,y,opened=False):
 # Low, long canine cranium. Cropped ears stay small behind the cheek plane.
 poly(g,[(x-5,y+1),(x-2,y-4),(x+6,y-5),(x+12,y-5),(x+21,y-8),(x+25,y-5),(x+25,y-1),(x+17,y+4),(x+7,y+7),(x-1,y+8),(x-5,y+4)],'1')
 poly(g,[(x-3,y+1),(x,y-2),(x+7,y-3),(x+13,y-3),(x+20,y-6),(x+22,y-4),(x+22,y-1),(x+15,y+2),(x+6,y+5),(x,y+5)],'E')
 poly(g,[(x,y-1),(x+6,y-3),(x+12,y-3),(x+16,y-4),(x+16,y-1),(x+10,y+1),(x+4,y+3),(x-1,y+2)],'F')
 poly(g,[(x-4,y),(x-3,y-5),(x+1,y-3),(x+2,y)],'1')
 line(g,(x-2,y-3),(x,y-2),'F');pixel(g,x-3,y-1,'B')
 poly(g,[(x+3,y-3),(x+6,y-6),(x+9,y-4),(x+7,y-1)],'1');line(g,(x+6,y-4),(x+7,y-3),'E')
 poly(g,[(x+12,y-2),(x+20,y-5),(x+23,y-3),(x+22,y),(x+15,y+3),(x+10,y+3)],'F')
 rect(g,x+22,y-5,3,3,'1');line(g,(x+8,y-1),(x+11,y-2),'F');pixel(g,x+10,y,'1')
 if opened:
  # Negative mouth cavity and distinct lower mandible; no floating contact ray.
  poly(g,[(x+9,y+5),(x+22,y+1),(x+21,y+7),(x+12,y+11),(x+6,y+8)],'1')
  line(g,(x+10,y+8),(x+19,y+5),'E',3);line(g,(x+11,y+8),(x+20,y+5),'F')
  pixel(g,x+18,y+2,'7');pixel(g,x+14,y+4,'7');pixel(g,x+16,y+6,'7')
 else:line(g,(x+11,y+4),(x+20,y+1),'5')
def rear_hound(name):
 g=grid()
 if name=='death':
  # Rear folded hip and paw; skull still recedes, no side-view mirror.
  poly(g,[(10,48),(13,41),(22,36),(31,38),(37,44),(44,45),(46,53),(39,60),(16,60)],'1')
  poly(g,[(14,48),(17,43),(23,39),(29,41),(34,47),(41,48),(42,53),(36,57),(19,57)],'E')
  poly(g,[(18,43),(23,41),(30,46),(32,49),(25,53),(18,53),(15,49)],'F')
  limb(g,(25,50),(17,53),(19,58),'E');paw(g,20,60,'F')
  limb(g,(34,51),(39,54),(40,56),'E');paw(g,41,58,'F')
  rear_head(g,34,45);line(g,(14,49),(8,54),'E',3);line(g,(8,54),(9,58),'F')
  return g
 shift={'idle0':(0,0),'idle1':(0,-1),'bind':(-2,5),'anticipate':(-2,3),'contact':(2,-3),'hit':(-3,4)}[name]
 dx,dy=shift
 # The forequarters carry weight; receding paws sit higher than hind paws.
 limb(g,(37+dx,36+dy),(41+dx,41),(46,47),'E',3);paw(g,47,49,'F')
 limb(g,(43+dx,33+dy),(47+dx,39),(52,45),'E',1);paw(g,53,47,'F')
 # Tail grows from the rump facing the viewer; an organic bent taper.
 line(g,(19+dx,42+dy),(12+dx,46+dy),'1',5);line(g,(12+dx,46+dy),(7,53),'1',3)
 line(g,(19+dx,42+dy),(12+dx,46+dy),'E',3);line(g,(12+dx,46+dy),(7,53),'F')
 # The back recedes diagonally toward the shoulder; belly/neck have negative space.
 poly(g,[(13+dx,40+dy),(15+dx,33+dy),(22+dx,29+dy),(28+dx,31+dy),(33+dx,25+dy),(38+dx,23+dy),(45+dx,27+dy),(47+dx,34+dy),(42+dx,41+dy),(34+dx,42+dy),(29+dx,47+dy),(20+dx,49+dy),(14+dx,46+dy)],'1')
 poly(g,[(17+dx,39+dy),(18+dx,35+dy),(23+dx,32+dy),(28+dx,34+dy),(34+dx,28+dy),(38+dx,27+dy),(42+dx,29+dy),(43+dx,34+dy),(39+dx,38+dy),(33+dx,39+dy),(27+dx,44+dy),(21+dx,46+dy),(17+dx,43+dy)],'E')
 # Long angled planes, not two circular rocks.
 poly(g,[(17+dx,36+dy),(21+dx,33+dy),(26+dx,32+dy),(32+dx,29+dy),(38+dx,28+dy),(41+dx,30+dy),(38+dx,33+dy),(32+dx,33+dy),(26+dx,36+dy),(21+dx,40+dy),(17+dx,41+dy),(15+dx,39+dy)],'F')
 poly(g,[(31+dx,39+dy),(37+dx,34+dy),(39+dx,32+dy),(40+dx,35+dy),(36+dx,39+dy),(32+dx,41+dy)],'5')
 # Near hind thigh overlays the receding body; hock bends back into large paw.
 limb(g,(20+dx,44+dy),(14+dx,53),(13,57),'E',3);paw(g,14,60,'F')
 limb(g,(29+dx,43+dy),(30+dx,52),(29,56),'E',3);paw(g,30,59,'F')
 poly(g,[(18+dx,44+dy),(22+dx,42+dy),(24+dx,47+dy),(18+dx,53),(15+dx,50)],'E');line(g,(19+dx,45+dy),(17+dx,50),'F')
 # Neck comes out beyond the shoulders, with its underside open to the floor.
 poly(g,[(35+dx,28+dy),(36+dx,22+dy),(40+dx,19+dy),(44+dx,21+dy),(45+dx,28+dy),(42+dx,32+dy),(38+dx,32+dy)],'1')
 poly(g,[(38+dx,27+dy),(38+dx,23+dy),(41+dx,22+dy),(43+dx,25+dy),(41+dx,29+dy)],'E')
 hx,hy=(31,24) if name=='contact' else (31+dx,24+dy)
 rear_head(g,hx,hy,name in ['anticipate','contact'])
 if name=='contact':pixel(g,52,18,'6')
 return g

HUNTER_HOOD=['00011110000','001BBBB1000','01BCCBB2100','1BBCC222100','1BBC1888210','1BC21188210','1BB21898210','01B21888210','001B2182100','0001BB22100','00001111000']
HUNTER_POSES={
 'idle0':(25,3,28,36,(36,29),(42,34),(46,24),(51,43)),
 'idle1':(25,4,28,36,(36,30),(42,35),(46,25),(51,44)),
 'bind':(24,5,27,38,(30,24),(25,21),(18,9),(20,25)),
 'anticipate':(23,5,26,38,(29,25),(24,19),(14,6),(18,23)),
 'contact':(28,4,32,37,(42,26),(51,29),(58,23),(63,42)),
 'hit':(21,7,25,39,(28,30),(34,35),(38,29),(43,48))}
def hunter_cleaver(g,hand,top,bottom):
 line(g,hand,(top[0]-3,top[1]+6),'1',3);line(g,hand,(top[0]-3,top[1]+6),'A')
 x,y=top;bx,by=bottom
 poly(g,[(x,y),(x+5,y),(bx,by),(bx-6,by),(x-2,y+5)],'1')
 poly(g,[(x+1,y+1),(x+4,y+1),(bx-1,by-1),(bx-5,by-1),(x-1,y+5)],'8')
 line(g,(x+4,y+2),(bx-1,by-2),'9');rect(g,hand[0]-1,hand[1]-1,3,3,'A')
def masked_hunter(name):
 g=grid()
 if name=='death':
  # A folded adult coat, bent near knee, braced wrist and closed mask.
  limb(g,(25,45),(18,53),(19,58),'2',3);rect(g,15,59,10,2,'8')
  poly(g,[(19,38),(30,34),(40,42),(45,52),(39,60),(17,60),(14,52)],'1')
  poly(g,[(22,40),(30,37),(37,44),(41,51),(35,57),(19,57),(17,52)],'B')
  poly(g,[(22,43),(27,39),(29,47),(25,55),(19,56)],'C')
  limb(g,(34,45),(42,50),(44,56),'8',3)
  mask(g,42,45,['0011111100','01BB222210','1BC2188821','1BB2118821','01B2188210','001BB22100','0001111000'])
  hunter_cleaver(g,(44,57),(54,46),(61,60));return g
 hx,hy,hpx,hpy,elbow,fist,top,bottom=HUNTER_POSES[name]
 # Long adult shin/torso proportions; both boots supported at the y60 plane.
 right=40 if name=='contact' else 34
 limb(g,(hpx-4,hpy),(20,48),(18,57),'2',3)
 limb(g,(hpx+3,hpy),(right,49),(right,57),'3',3)
 rect(g,14,59,10,2,'1');rect(g,15,59,8,1,'8')
 rect(g,right-3,59,11,2,'1');rect(g,right-2,59,9,1,'8')
 poly(g,[(hx-6,hy+15),(hx+13,hy+15),(hpx+7,hpy-4),(hpx+11,50),(hpx+2,53),(hpx-1,45),(hpx-7,54),(hpx-13,51),(hpx-8,hpy-4)],'1')
 poly(g,[(hx-4,hy+17),(hx+10,hy+17),(hpx+5,hpy-3),(hpx+8,48),(hpx+3,50),(hpx,41),(hpx-7,51),(hpx-10,49),(hpx-6,hpy-3)],'B')
 poly(g,[(hx-3,hy+18),(hx+1,hy+17),(hpx-2,34),(hpx-5,45),(hpx-8,50),(hpx-10,48),(hpx-5,31)],'C')
 rect(g,hpx-7,hpy-2,14,3,'A');rect(g,hpx+1,hpy-2,3,3,'9')
 line(g,(hx+2,hy+13),(hx+5,hy+17),'2',3)
 limb(g,(hx-4,hy+19),(hx-7,hy+27),(hpx-7,hpy+2),'3',3)
 shoulder=(hx+10,hy+19);limb(g,shoulder,elbow,fist,'8',3)
 rect(g,shoulder[0]-2,shoulder[1]-2,6,3,'8');line(g,(shoulder[0]-2,shoulder[1]-2),(shoulder[0]+2,shoulder[1]-2),'9')
 hunter_cleaver(g,fist,top,bottom);mask(g,hx,hy,HUNTER_HOOD);return g

FRONT_SKULL=['000166661000','001677776100','016777776510','167711776551','167111776551','167711716551','167777776651','016776676510','001671165100','001676665100','000166651000','000011110000']
SIDE_FALL_SKULL=['0016666100','0167777610','1677117651','1671117651','1677117651','0167766510','0016716510','0001666100']
def front_cage(g,cx,cy,lean=0):
 line(g,(cx,cy),(cx+lean,cy+13),'5',3);line(g,(cx,cy),(cx+lean,cy+13),'7')
 for i in range(4):
  x=cx+(lean*i)//4;y=cy+i*3
  line(g,(x-1,y),(x-7,y+1),'1',3);line(g,(x-7,y+1),(x-5,y+3),'1',3)
  line(g,(x+1,y),(x+5,y+1),'1',3);line(g,(x+5,y+1),(x+4,y+3),'1',3)
  line(g,(x-1,y),(x-6,y+1),'7');line(g,(x-6,y+1),(x-5,y+2),'6')
  line(g,(x+1,y),(x+4,y+1),'6');line(g,(x+4,y+1),(x+3,y+2),'5')
def forward_spear(g,hand,tip):
 butt=(hand[0]+15,max(8,hand[1]-18))
 line(g,butt,tip,'1',3);line(g,butt,tip,'A')
 poly(g,[(tip[0]+2,tip[1]-7),(tip[0]-2,tip[1]-5),(tip[0]-3,tip[1]+1),(tip[0]+3,tip[1]-1)],'8')
 line(g,(tip[0]+1,tip[1]-5),(tip[0]-2,tip[1]),'9');rect(g,hand[0]-1,hand[1]-1,3,3,'6')
def front_skeleton(name):
 g=grid()
 if name=='death':
  # Cage tilted toward the viewer, crossed shin and skull in a grounded heap.
  front_cage(g,28,40,4);mask(g,38,47,SIDE_FALL_SKULL)
  limb(g,(24,49),(16,53),(22,58),'6',1);limb(g,(32,50),(35,58),(40,57),'6',1)
  rect(g,18,59,7,2,'5');rect(g,37,58,7,2,'6');forward_spear(g,(39,53),(28,60))
  return g
 dx,dy,lean={'idle0':(0,0,1),'idle1':(0,1,1),'bind':(-1,2,-1),'anticipate':(-2,3,-1),'contact':(-3,4,-2),'hit':(2,3,3)}[name]
 hip=(27+dx,40+dy)
 # Far right leg is shorter/higher; near left foot faces the viewer.
 limb(g,(hip[0]+3,hip[1]),(36+dx,48),(36,54),'5',1);rect(g,34,55,6,2,'5')
 limb(g,(hip[0]-4,hip[1]),(22+dx,51),(22,58),'6',1);rect(g,18,59,9,2,'6');pixel(g,20,59,'7')
 poly(g,[(hip[0]-7,hip[1]-3),(hip[0]+5,hip[1]-3),(hip[0]+6,hip[1]+1),(hip[0]+2,hip[1]+4),(hip[0]-1,hip[1]),(hip[0]-5,hip[1]+4),(hip[0]-8,hip[1]+1)],'1')
 poly(g,[(hip[0]-6,hip[1]-2),(hip[0]+4,hip[1]-2),(hip[0]+4,hip[1]),(hip[0]+2,hip[1]+2),(hip[0]-1,hip[1]-1),(hip[0]-5,hip[1]+2)],'6')
 cx=27+dx;cy=22+dy;front_cage(g,cx,cy,lean)
 line(g,(cx-8,cy-1),(cx+5,cy),'6',3);line(g,(cx-7,cy-1),(cx-1,cy-1),'7')
 # Near forearm and spear point aim down-left, into the battlefield/player.
 hand=(20+dx,35+dy);elbow=(16+dx,30+dy)
 limb(g,(cx-8,cy),elbow,hand,'6',1)
 limb(g,(cx+5,cy),(36+dx,29+dy),(31+dx,36+dy),'5',1)
 tip=(14,49) if name!='contact' else (11,52)
 forward_spear(g,hand,tip)
 mask(g,21+dx,6+dy,FRONT_SKULL)
 poly(g,[(21+dx,9+dy),(22+dx,4+dy),(30+dx,4+dy),(33+dx,7+dy),(27+dx,6+dy),(24+dx,9+dy)],'8')
 line(g,(23+dx,5+dy),(28+dx,5+dy),'9')
 if name=='hit':pixel(g,26,45,'6')
 return g

SCENE={'width':384,'height':240,'scale':2,'floorSeams':[[40,146,230],[112,104,270],[181,42,350],[230,10,374]],'units':{
 'hunter':{'home':[38,100],'labelWidth':104,'labelHeight':52,'labelSide':'below','name':'Contract hunter','orientation':'Adult masked hunter flank','health':'Health 20/20 · Block 0','intent':'Research: holds the flank'},
 'hound':{'home':[226,108],'labelWidth':104,'labelHeight':52,'labelSide':'below','name':'Pact hound','orientation':'Rear three-quarter gravehound ally','health':'Health 8/8 · Block 0','intent':'Research: Bite 4 → Skeleton'},
 'skeleton':{'home':[182,64],'labelWidth':104,'labelHeight':52,'labelSide':'above','name':'Skeletal adversary','orientation':'Front three-quarter enemy','health':'Health 12/12 · Block 0','intent':'Research: Spear 5 → Hunter'}},'contactTarget':[26,45],'contactActor':[52,18]}
def png_chunk(name,data):return struct.pack('!I',len(data))+name+data+struct.pack('!I',zlib.crc32(name+data)&0xffffffff)
def png(rows,scale=1):
 width=len(rows[0])*scale;height=len(rows)*scale;raw=bytearray()
 for row in rows:
  expanded=bytes(KEYS.index(c) for c in row for _ in range(scale))
  for _ in range(scale):raw.extend(b'\x00');raw.extend(expanded)
 plte=b''.join(bytes.fromhex(c[1:]) if c else bytes([0,0,0]) for c in PALETTE)
 return b'\x89PNG\r\n\x1a\n'+png_chunk(b'IHDR',struct.pack('!IIBBBBB',width,height,8,3,0,0,0))+png_chunk(b'PLTE',plte)+png_chunk(b'tRNS',bytes([0]+[255]*(len(PALETTE)-1)))+png_chunk(b'IDAT',zlib.compress(raw,9))+png_chunk(b'IEND',b'')
def sheet(actor):
 rows=[['0']*(W*4) for _ in range(H*2)]
 for i,name in enumerate(FRAMES):
  for y,row in enumerate(actor['frames'][name]):
   for x,c in enumerate(row):rows[(i//4)*H+y][(i%4)*W+x]=c
 body=png(rows);(ROOT/'assets'/f"{actor['id']}-sheet.png").write_bytes(body)
 return {'width':W*4,'height':H*2,'columns':4,'frameOrder':FRAMES,'sha256':hashlib.sha256(body).hexdigest()}
def scene_export(actors,phase):
 sw,sh=SCENE['width'],SCENE['height'];rows=[['1']*sw for _ in range(sh)]
 # Four broad quiet angled stone seams, not a full high-contrast grid.
 for y,x1,x2 in SCENE['floorSeams']:
  for x in range(x1,x2):rows[y][x]='2'
 # The same published homes/contact arithmetic as the lab, with no text raster.
 for name in ['hunter','skeleton','hound']:
  origin=SCENE['units'][name]['home'];frame='idle0'
  if name=='hound':frame={'bind':'bind','ready':'idle0','command':'anticipate','contact':'contact'}[phase]
  if name=='skeleton' and phase=='contact':frame='hit'
  if name=='hound' and phase=='contact':
   enemy=SCENE['units']['skeleton']['home'];target=SCENE['contactTarget'];point=SCENE['contactActor']
   origin=[enemy[0]+target[0]-point[0],enemy[1]+target[1]-point[1]]
  for y,row in enumerate(actors[name]['frames'][frame]):
   for x,c in enumerate(row):
    if c!='0':rows[origin[1]+y][origin[0]+x]=c
 body=png(rows,2);(ROOT/'assets'/f'{phase}-composition-2x.png').write_bytes(body);guard()
 return {'width':sw*2,'height':sh*2,'scale':2,'sha256':hashlib.sha256(body).hexdigest(),'kind':'Authored indexed static art only; live hand/readouts are not rasterized; not browser capture'}
def export():
 global INITIAL,MAXIMUM
 INITIAL=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());MAXIMUM=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
 if MAXIMUM-INITIAL<WORK+RESERVE:raise SystemExit(f'Fresh24+512 export refused: current={INITIAL},maximum={MAXIMUM}')
 guard();(ROOT/'assets').mkdir(exist_ok=True)
 hunter={f:[''.join(row) for row in masked_hunter(f)] for f in FRAMES}
 actors={}
 for name,frames,orientation,feet in [('hunter',hunter,'New original adult masked hunter body/hood/coat/weapon silhouette',[27,60]),('hound',{f:[''.join(row) for row in rear_hound(f)] for f in FRAMES},'New original rear-three-quarter gravehound anatomy; never mirrored',[27,60]),('skeleton',{f:[''.join(row) for row in front_skeleton(f)] for f in FRAMES},'Retained original front-three-quarter skeletal drawing; never mirrored',[27,60])]:
  assert len({''.join(rows) for rows in frames.values()})==len(FRAMES)
  bounds={}
  for f,rows in frames.items():
   assert len(rows)==H and all(len(r)==W for r in rows)
   pts=[(x,y) for y,row in enumerate(rows) for x,c in enumerate(row) if c!='0']
   bounds[f]={'left':min(x for x,y in pts),'top':min(y for x,y in pts),'right':max(x for x,y in pts)+1,'bottom':max(y for x,y in pts)+1}
  actor={'id':name,'width':W,'height':H,'orientation':orientation,'feet':feet,'frameBounds':bounds,'frames':frames}
  actor['unionBounds']={k:(min if k in ['left','top'] else max)(b[k] for b in bounds.values()) for k in ['left','top','right','bottom']}
  actor['sheet']=sheet(actor);actors[name]=actor;guard()
 assert actors['hound']['frames']['contact'][18][52]!='0' and actors['skeleton']['frames']['hit'][45][26]!='0'
 previews={phase:scene_export(actors,phase) for phase in ['ready','contact']}
 payload={'palette':PALETTE,'keys':KEYS,'cell':[W,H],'frameOrder':FRAMES,'actors':actors,'scene':SCENE,'staticExports':previews}
 (ROOT/'sprites.js').write_text('// Original R4 indexed gravehound/adult hunter plus retained skeletal perspective; no image input.\nexport const ART = '+json.dumps(payload,separators=(',',':'))+';\n')
 current,hwm=guard();report={'admitted':True,'initial_current':INITIAL,'maximum':MAXIMUM,'current_at_report':current,'actual_VmHWM_bytes':hwm,'work':WORK,'reserve':RESERVE,'time_ns':time.time_ns(),'scope':'Source/indexed art export only, no JS/Node/browser/server/build.'}
 (ROOT/'EXPORT-RESOURCE.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':export()
