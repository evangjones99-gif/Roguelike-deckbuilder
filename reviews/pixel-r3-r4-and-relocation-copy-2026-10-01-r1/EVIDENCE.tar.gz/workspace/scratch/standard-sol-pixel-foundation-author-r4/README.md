# Pixel anatomy and compact ownership study r4

**ART / LAYOUT RESEARCH ONLY.** R4 corrects R3's exported slot geometry and revises its two rejected silhouettes. It remains a static synthetic lab with three live-text study cards, complete illustrative health/Block/intents and inspection controls. No real engine adapter, arrival animation, action resolution, saved state, cost payment or first-five-minute enjoyment is implemented or tested.

R3 remains exact rejection evidence: manifest `b05122fbd39d0c61a1e3518b562b5276682e417b6368de4cd52d2edc066fd977`. Independent technical and visual reviewers found an above-label slot that excluded 56 source pixels of its cell, and rejected the fox/bunny head, segmented/rock-like hound and small schematic hunter. Painting and alpha point selection did not use the malformed slot, so no observed mis-target is claimed. `GEOMETRY-REJECTION.txt` records the defect and repair; `DRAFT-BASELINE.json` pins the six old source files copied into this new draft under a fresh small admission.

## Original anatomy and reference scope

Root supplied a generated **nonshipping anatomy reference**, which this author viewed: `/workspace/generated_images/exec-f482a419-cb8c-4289-b997-932470a0825b.png`, SHA256 `baf52df650231bdb9166d79d4080833313c87febc24b7bf53ea76b6d017315fc`. `ANATOMY-REFERENCE.json` records the exact body pin and provenance boundary. It is a high-frequency illustration, not native pixel art. Root owns its generation/prompt provenance. Its texture, pixels, palette and full shapes were not imported, sampled, downsampled, filtered or copied as a shipping asset. The original remains untouched.

The author translated anatomy advice into inspectable low-resolution indexed masks: a low long canine skull, cropped/scarred ears, an explicit mouth cavity and lower jaw, continuous warm-gray fur planes, forward shoulder weight, receding front paws, bent rear hocks and a descending tail. R4 adds two restrained fur values to the prior palette for **16 entries including transparency**; bright ember remains a lab binding/contact mark. An earlier cream-colored upper jaw and more segmented body plane were revised after native inspection; the first code, PNGs and export observations remain in this packet, outside the server's final asset allowlist.

The hunter is **newly drawn**, no longer the short R2 body shifted into a larger cell: long adult torso/shins, broad shoulders, split coat, planted armored boots, closed angular hood/mask and a weighted broad cleaver. Its seven poses alter stance, shoulder/elbow/hand, coat and weapon; its death drawing folds coat and joints into a supported fall. The original front-three-quarter skeleton from R3 is retained. Near hound and far skeleton remain genuinely rear/front drawings, never mirrored substitutes. These source decisions do not prove a convincing or threatening creature/person; independent aesthetic rejection remains possible.

All actors use one native 64×64 cell and common integer 2×/3× display. Actual source READY opaque height is **58px hunter**, **57px skeleton**, **45px low-posture quadruped**; at 2× these are 116/114/90 CSS pixels. Full union bounds are published per actor, including all seven static drawings. These counts establish source extents, not browser presence, anatomy quality or animation. Three indexed transparent native sheets and two authored 2× composition PNGs contain only original art. They are not browser captures and omit the separate live DOM hand/readouts.

## Compact scene and full union

The default native field is 384×240, displayed at 2× as **768×480**. Homes are skeleton `(182,64)`, hunter `(38,100)`, hound `(226,108)`. The default 52-source-pixel readout reservations end by y228; the source field keeps y240 as its base, with natural text measurement allowed to demand more height. Four quiet broad ground seams replace unused floor and the old taller scene. At 3× the art field alone is 1152×720; that option is explicitly a larger scroll study. No one-screen guarantee or mobile acceptance is claimed.

The short header/toolbar, full natural-height bottom hand and initially collapsed supplemental inspector aim to keep the default PC hand reachable on 1440×900. Those are layout choices, not an actual viewport observation. Click/keyboard Inspect opens the dossier without forcing focus or scrolling; phase changes do not automatically open it. Essential identity, complete intent type/number/target, health and Block remain permanently visible in the field at ≥12px, with readout width bounded by the source allocation and capped at 240 CSS pixels. Costs are explicitly **not modeled**, rather than pretending the study controls are legal game cards. No essential readout is clipped or deliberately hidden to achieve the height target; actual browser wrapping/visibility still need review.

`geometry.js` now publishes the complete rectangle union: left/top minima of cell/readout extents, right/bottom maxima, then width=`right-left`, height=`bottom-top`. With default reservations, the enemy union top8/bottom128/height120 includes its full cell64..128 and readout8..60. The cell rectangle, opaque body rectangle, full extent and point ownership remain distinct. The extent rectangle is not gameplay hit authority and may overlap another transparent cell during contact.

Canvas painting and optional point inspection consume the same published pose/origin. Point inspection searches actual nontransparent indices in reverse painter order and yields one visible owner; it never targets or dispatches an action. Keyboard users have separate live Inspect buttons. The hound's static contact point `(52,18)` aligns with the enemy knee `(26,45)` by integer placement. This endpoint is neither a swept-volume proof nor an attack timeline. Source painter geometry and natural-height readouts are the only scope; real formation, queue, corpse/newborn, legal authority and audio/contact semantics belong to a later reviewed engine adapter.

## Viewing and execution limits

After exact independent source review and Root's explicit exclusive runtime grant:

```sh
node /absolute/path/to/this/packet/serve.mjs
```

Open `http://127.0.0.1:5176`. Built-in Node only, ten allowed lab/art files, no installation/framework, arbitrary repository routing, fetch, telemetry, storage or game import. Port/HTTP/server stop, browser text layout and actual interaction remain unassessed. The whole lab is static: no RAF, motion clock, timed contact callback or pretend real binding/order resolution. Dispose removes the readout observer/listeners; unavailable canvas provides truthful normal-flow live readouts and native PNG links.

The author ran two guarded Python original-indexed exports and inspected the three native sheets plus initial/final art compositions. `EXPORT-RESOURCE*.json` and raw run outputs distinguish those operations from the bounded source seal. Each uses unchanged 24 MiB source work plus 512 MiB reserve and actual `/proc/self/status` VmHWM. No JavaScript evaluation, Node/server/browser, game build or live repository/stage mutation occurred. R1/R2/R3 and reference bodies must remain retained. Root owns subsequent visual/runtime comparison, original engine-backed first-five-minute play and promotion. R4 supplies no motion, game, fun, AAA, native/Steam or retirement approval.
