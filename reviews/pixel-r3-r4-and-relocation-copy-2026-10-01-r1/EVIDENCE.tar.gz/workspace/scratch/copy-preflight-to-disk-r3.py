"""Preserve the complete original ZIP encoding on disk; NEVER removes source.

One explicitly admitted copy under the unchanged external64+512 guard.
New target ranges are fsynced before advisory DONTNEED; no global advice.
Partial target/proofs remain on failure. This grants no cleanup or Git coverage.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

OLD = Path('/tmp/hollowpact-native-v07/source-preflight-bdf27374358eb176e62f832cb50261cb3334d8df.zip')
DEST = Path('/workspace/scratch/retained-original-archives/preflight-bdf273-original-r3.zip')
OUT = Path('/workspace/scratch/preflight-to-disk-copy-r3')
PINS = Path('/workspace/scratch/v07-preflight-budget-accounting-root-author-r6/PINS-r6.json')
PINS_SHA = '7fa2e81b66a04009aff92b736a33e4316df8166d9fbbf3914edbdd2f68f17b89'
WORK, RESERVE, CHUNK, RANGE = 64*1048576,512*1048576,65536,4*1048576
START = time.monotonic()
CG = Path('/sys/fs/cgroup')
MAXIMUM = int((CG/'memory.max').read_text())
ADMISSION = Path('/workspace/scratch/preflight-to-disk-copy-guard-r3/ADMISSION.json')
admission_bytes = ADMISSION.read_bytes()
admission = json.loads(admission_bytes)
assert admission['admitted'] and admission['work']==WORK and admission['reserve']==RESERVE
assert admission['stage']=='/workspace/scratch'
assert admission['command']==['python3','-I',str(Path(__file__).absolute()),'--copy-original-encoding-only']
assert admission['initial']['maximum']==MAXIMUM and admission['initial']['headroom']>=WORK+RESERVE
assert admission['initial']['free']>=64*1048576
assert 0 <= time.time_ns()-admission['initial']['time_ns'] < 10*1000000000
INITIAL = admission['initial']['current']
record = {'status':'NOT COPIED', 'old':str(OLD), 'destination':str(DEST),
          'originalRetained':True,'scope':'Exact encoding relocation copy only; no deletion or Git coverage',
          'advisedCopiedBytes':0, 'advisedVerifiedBytes':0}

def guard():
    assert ADMISSION.read_bytes()==admission_bytes
    assert int((CG/'memory.max').read_text())==MAXIMUM
    current = int((CG/'memory.current').read_text())
    assert MAXIMUM-current >= RESERVE and current-INITIAL <= WORK
    assert time.monotonic()-START < 120
    assert os.statvfs(DEST.parent).f_bavail*os.statvfs(DEST.parent).f_frsize >= 64*1048576

def metadata(p, fd):
    s = os.fstat(fd)
    return {'path':str(p),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,
            'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'bytes':s.st_size,
            'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,
            'ctimeNs':s.st_ctime_ns,'xattrs':{k:os.getxattr(fd,k).hex() for k in os.listxattr(fd)}}

held=[]
def directory(path):
    fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);held.append(fd)
    chain=[]
    for name in path.parts[1:]:
        parent=fd
        fd=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
        held.append(fd);s=os.fstat(fd)
        identity={'name':name,'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid}
        chain.append((parent,name,fd,identity))
    return fd,chain

def check_chain(chain):
    for parent,name,fd,expected in chain:
        s=os.stat(name,dir_fd=parent,follow_symlinks=False);actual=os.fstat(fd)
        assert (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)==(actual.st_dev,actual.st_ino,actual.st_mode,actual.st_uid,actual.st_gid)
        assert {'name':name,'dev':actual.st_dev,'ino':actual.st_ino,'mode':actual.st_mode,'uid':actual.st_uid,'gid':actual.st_gid}==expected

def check_file(parent,name,fd):
    assert os.stat(name,dir_fd=parent,follow_symlinks=False)==os.fstat(fd)

def save():
    body=(json.dumps(record,indent=2)+'\n').encode()
    with (OUT/'RESULT.json').open('xb') as f:
        f.write(body);f.flush();os.fsync(f.fileno())
    for p in [OUT,DEST.parent,OUT.parent]:
        fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)

assert sys.argv[1:] == ['--copy-original-encoding-only']
assert not OUT.exists() and not DEST.exists()
OUT.mkdir(mode=0o700)
source_fd=target_fd=verify_fd=None
try:
    pinfd=os.open(PINS,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    with os.fdopen(pinfd,'rb') as f: pinbody=f.read(65537)
    assert hashlib.sha256(pinbody).hexdigest()==PINS_SHA
    pins=json.loads(pinbody);expected=pins['archiveMetadata'][str(OLD)]
    old_parent,old_chain=directory(OLD.parent)
    assert [item[3] for item in old_chain]==pins['archiveParents'][str(OLD)]
    scratch,scratch_chain=directory(DEST.parent.parent)
    try:os.mkdir(DEST.parent.name,mode=0o700,dir_fd=scratch)
    except FileExistsError:pass
    dest_parent,dest_chain=directory(DEST.parent)
    ds=os.fstat(dest_parent);assert ds.st_uid==os.geteuid() and stat.S_IMODE(ds.st_mode)==0o700
    check_chain(old_chain);check_chain(scratch_chain);check_chain(dest_chain)
    source_fd=os.open(OLD.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=old_parent)
    check_file(old_parent,OLD.name,source_fd)
    before=metadata(OLD,source_fd);assert before==expected
    assert stat.S_ISREG(before['mode']) and before['uid']==os.geteuid() and before['nlink']==1
    assert DEST.parent.stat().st_dev != before['dev']
    free=os.statvfs(DEST.parent).f_bavail*os.statvfs(DEST.parent).f_frsize
    assert free >= before['bytes']+256*1048576
    record['before']=before;record['workspaceFreeBefore']=free
    target_fd=os.open(DEST.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=dest_parent)
    created=os.fstat(target_fd)
    assert stat.S_ISREG(created.st_mode) and created.st_nlink==1 and created.st_uid==os.geteuid() and stat.S_IMODE(created.st_mode)==0o600
    check_file(dest_parent,DEST.name,target_fd)
    total=advised=0; source_hash=hashlib.sha256()
    while True:
        guard();body=os.read(source_fd,CHUNK)
        if not body:break
        source_hash.update(body)
        remaining=memoryview(body)
        while remaining:
            n=os.write(target_fd,remaining);assert n>0;remaining=remaining[n:]
        total+=len(body)
        end=total//RANGE*RANGE
        if end>advised:
            os.fsync(target_fd)
            os.posix_fadvise(target_fd,advised,end-advised,os.POSIX_FADV_DONTNEED)
            advised=end;record['advisedCopiedBytes']=advised
    assert total==before['bytes']
    os.fsync(target_fd)
    os.posix_fadvise(target_fd,advised,total-advised,os.POSIX_FADV_DONTNEED)
    record['advisedCopiedBytes']=total
    assert metadata(OLD,source_fd)==before
    check_file(old_parent,OLD.name,source_fd);check_file(dest_parent,DEST.name,target_fd)
    assert (os.fstat(target_fd).st_dev,os.fstat(target_fd).st_ino)==(created.st_dev,created.st_ino)
    os.close(target_fd);target_fd=None
    os.utime(DEST.name,ns=(before['atimeNs'],before['mtimeNs']),follow_symlinks=False,dir_fd=dest_parent)
    verify_fd=os.open(DEST.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=dest_parent)
    check_file(dest_parent,DEST.name,verify_fd)
    target_before=metadata(DEST,verify_fd)
    assert (target_before['dev'],target_before['ino'])==(created.st_dev,created.st_ino)
    assert target_before['uid']==os.geteuid() and target_before['mode']==0o100600 and target_before['nlink']==1
    verified=advised=0;target_hash=hashlib.sha256()
    while True:
        guard();body=os.read(verify_fd,CHUNK)
        if not body:break
        target_hash.update(body);verified+=len(body);end=verified//RANGE*RANGE
        if end>advised:
            os.posix_fadvise(verify_fd,advised,end-advised,os.POSIX_FADV_DONTNEED)
            advised=end;record['advisedVerifiedBytes']=advised
    os.posix_fadvise(verify_fd,advised,verified-advised,os.POSIX_FADV_DONTNEED)
    record['advisedVerifiedBytes']=verified
    assert verified==total and source_hash.digest()==target_hash.digest()
    assert metadata(DEST,verify_fd)==target_before and metadata(OLD,source_fd)==before
    check_file(dest_parent,DEST.name,verify_fd);check_file(old_parent,OLD.name,source_fd)
    check_chain(old_chain);check_chain(scratch_chain);check_chain(dest_chain)
    os.fsync(verify_fd)
    os.fsync(dest_parent);os.fsync(scratch)
    guard()
    record.update(status='BYTE-EXACT COPY VERIFIED; ORIGINAL STILL RETAINED',
                  bytes=total,sha256=source_hash.hexdigest(),destinationMetadata=target_before,
                  oldParents=[item[3] for item in old_chain],destinationParents=[item[3] for item in dest_chain],
                  freshOriginalHash=True,historicalGoldenHashClaim=False,
                  qualification='DONTNEED is advisory; no reclaim guarantee. Original ZIP encoding retained exactly, not validated as game source.',
                  elapsedSeconds=time.monotonic()-START)
except BaseException as e:
    record.update(status='COPY FAILED; PARTIAL FILES RETAINED',error=repr(e),elapsedSeconds=time.monotonic()-START)
    raise
finally:
    for fd in [verify_fd,target_fd,source_fd]:
        if fd is not None:os.close(fd)
    for fd in reversed(held):os.close(fd)
    record['ownArchiveFDsClosed']=True
    save()
print(json.dumps({'status':record['status'],'bytes':record.get('bytes'),'sha256':record.get('sha256')}))
