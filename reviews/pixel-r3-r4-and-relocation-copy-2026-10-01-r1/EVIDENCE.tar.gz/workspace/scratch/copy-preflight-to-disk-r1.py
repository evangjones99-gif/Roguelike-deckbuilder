"""Preserve the complete original ZIP encoding on disk; NEVER removes source.

One explicitly admitted copy under the unchanged external64+512 guard.
New target ranges are fsynced before advisory DONTNEED; no global advice.
Partial target/proofs remain on failure. This grants no cleanup or Git coverage.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

OLD = Path('/tmp/hollowpact-native-v07/source-preflight-bdf27374358eb176e62f832cb50261cb3334d8df.zip')
DEST = Path('/workspace/scratch/retained-original-archives/preflight-bdf273-original-r1.zip')
OUT = Path('/workspace/scratch/preflight-to-disk-copy-r1')
PINS = Path('/workspace/scratch/v07-preflight-budget-accounting-root-author-r6/PINS-r6.json')
PINS_SHA = '7fa2e81b66a04009aff92b736a33e4316df8166d9fbbf3914edbdd2f68f17b89'
WORK, RESERVE, CHUNK, RANGE = 64*1048576,512*1048576,65536,4*1048576
START = time.monotonic()
CG = Path('/sys/fs/cgroup')
INITIAL = int((CG/'memory.current').read_text())
MAXIMUM = int((CG/'memory.max').read_text())
record = {'status':'NOT COPIED', 'old':str(OLD), 'destination':str(DEST),
          'originalRetained':True,'scope':'Exact encoding relocation copy only; no deletion or Git coverage',
          'advisedCopiedBytes':0, 'advisedVerifiedBytes':0}

def guard():
    current = int((CG/'memory.current').read_text())
    assert MAXIMUM-current >= RESERVE and current-INITIAL <= WORK
    assert time.monotonic()-START < 120
    assert os.statvfs(DEST.parent).f_bavail*os.statvfs(DEST.parent).f_frsize >= 64*1048576

def metadata(p, st=None):
    s = st or p.lstat()
    return {'path':str(p),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,
            'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'bytes':s.st_size,
            'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,
            'ctimeNs':s.st_ctime_ns,'xattrs':{k:os.getxattr(p,k).hex() for k in os.listxattr(p)}}

def save():
    body=(json.dumps(record,indent=2)+'\n').encode()
    with (OUT/'RESULT.json').open('xb') as f:
        f.write(body);f.flush();os.fsync(f.fileno())
    for p in [OUT,DEST.parent,OUT.parent]:
        fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)

assert sys.argv[1:] == ['--copy-original-encoding-only']
assert MAXIMUM-INITIAL >= WORK+RESERVE
assert not OUT.exists() and not DEST.exists()
assert not DEST.parent.is_symlink()
DEST.parent.mkdir(mode=0o700,exist_ok=True)
OUT.mkdir(mode=0o700)
source_fd=target_fd=verify_fd=None
try:
    pinfd=os.open(PINS,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    with os.fdopen(pinfd,'rb') as f: pinbody=f.read(65537)
    assert hashlib.sha256(pinbody).hexdigest()==PINS_SHA
    expected=json.loads(pinbody)['archiveMetadata'][str(OLD)]
    before=metadata(OLD);assert before==expected
    assert stat.S_ISREG(before['mode']) and before['uid']==os.geteuid() and before['nlink']==1
    assert DEST.parent.stat().st_dev != before['dev']
    free=os.statvfs(DEST.parent).f_bavail*os.statvfs(DEST.parent).f_frsize
    assert free >= before['bytes']+256*1048576
    record['before']=before;record['workspaceFreeBefore']=free
    source_fd=os.open(OLD,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    assert metadata(OLD,os.fstat(source_fd))==before
    target_fd=os.open(DEST,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    assert stat.S_ISREG(os.fstat(target_fd).st_mode) and os.fstat(target_fd).st_nlink==1
    total=advised=0; source_hash=hashlib.sha256()
    while True:
        guard();body=os.read(source_fd,CHUNK)
        if not body:break
        source_hash.update(body)
        remaining=memoryview(body)
        while remaining:
            n=os.write(target_fd,remaining);assert n>0;remaining=remaining[n:]
        total+=len(body)
        end=total//RANGE*RANGE
        if end>advised:
            os.fsync(target_fd)
            os.posix_fadvise(target_fd,advised,end-advised,os.POSIX_FADV_DONTNEED)
            advised=end;record['advisedCopiedBytes']=advised
    assert total==before['bytes']
    os.fsync(target_fd)
    os.posix_fadvise(target_fd,advised,total-advised,os.POSIX_FADV_DONTNEED)
    record['advisedCopiedBytes']=total
    assert metadata(OLD,os.fstat(source_fd))==before and metadata(OLD)==before
    os.close(target_fd);target_fd=None
    os.utime(DEST,ns=(before['atimeNs'],before['mtimeNs']),follow_symlinks=False)
    target_before=metadata(DEST)
    verify_fd=os.open(DEST,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    assert metadata(DEST,os.fstat(verify_fd))==target_before
    verified=advised=0;target_hash=hashlib.sha256()
    while True:
        guard();body=os.read(verify_fd,CHUNK)
        if not body:break
        target_hash.update(body);verified+=len(body);end=verified//RANGE*RANGE
        if end>advised:
            os.posix_fadvise(verify_fd,advised,end-advised,os.POSIX_FADV_DONTNEED)
            advised=end;record['advisedVerifiedBytes']=advised
    os.posix_fadvise(verify_fd,advised,verified-advised,os.POSIX_FADV_DONTNEED)
    record['advisedVerifiedBytes']=verified
    assert verified==total and source_hash.digest()==target_hash.digest()
    assert metadata(DEST,os.fstat(verify_fd))==target_before and metadata(DEST)==target_before
    assert metadata(OLD,os.fstat(source_fd))==before and metadata(OLD)==before
    os.fsync(verify_fd)
    record.update(status='BYTE-EXACT COPY VERIFIED; ORIGINAL STILL RETAINED',
                  bytes=total,sha256=source_hash.hexdigest(),destinationMetadata=target_before,
                  freshOriginalHash=True,historicalGoldenHashClaim=False,
                  qualification='DONTNEED is advisory; no reclaim guarantee. Original ZIP encoding retained exactly, not validated as game source.',
                  elapsedSeconds=time.monotonic()-START)
except BaseException as e:
    record.update(status='COPY FAILED; PARTIAL FILES RETAINED',error=repr(e),elapsedSeconds=time.monotonic()-START)
    raise
finally:
    for fd in [verify_fd,target_fd,source_fd]:
        if fd is not None:os.close(fd)
    record['ownArchiveFDsClosed']=True
    save()
print(json.dumps({'status':record['status'],'bytes':record.get('bytes'),'sha256':record.get('sha256')}))
