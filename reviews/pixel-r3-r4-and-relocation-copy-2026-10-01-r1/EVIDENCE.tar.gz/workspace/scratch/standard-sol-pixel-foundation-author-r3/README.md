# Original near/far pixel perspective study r3

**ART / LAYOUT RESEARCH ONLY.** A small static browser lab places an original rear-three-quarter allied hound near the bottom hand, an original front-three-quarter skeletal adversary farther up the field and the hunter on a flank. It is not a game replacement, animation host, accepted art, engine adapter or first-five-minute fun evidence. R1 and r2 remain exact independent packets. R2's anatomy improved enough to warrant perspective research, but no source gate approved game or aesthetic quality.

The owner's intended direction is a bottom hand with summoned allies facing into the battlefield and far-side threats facing the player. A card should eventually come alive through arrival, READY and intentional command. **This packet implements only selectable static study stages**, including an absent-in-hand drawing, crouched binding drawing, READY composition, command preview and aligned contact/reaction drawing. No arrival motion, attack clock, contact callback, resolved damage, save, cost payment or real legal action is present. The bottom three live-text cards are study controls, explicitly labelled without modeled rule costs. All displayed health, Block and type/number/target intent values are illustrative display data.

## Original drawing decisions

All art uses a 64×64 native cell and the restrained 14-entry indexed palette, displayed at common integer 2× or 3× source scale. No generated image, painted art, franchise character, downsample, blur or raster-input editing is used. Seven individually different static masks per actor expose idle0, idle1, bind, anticipate, contact, hit and death; this set is not a complete timed attack animation.

The hound is newly drawn from the rear at three-quarter angle: a near rump and bent hind hocks, larger foreground paws, descending tail, diagonally receding back, shorter far forelegs and a neck/skull that lead toward the upper right. One cheek and wedge jaw remain visible. Long fur/body planes replace r2's similar circular shoulder/haunch highlights. It is not a flipped side sprite. The adversary is newly drawn front/three-quarter: uneven socket/cheek values, near shoulder and thigh, smaller far leg, open ribs/pelvis and a spear directed down-left toward the player. Its mask is also never mirrored. These are deliberate source decisions, not proof that viewers perceive the intended anatomy or threat.

Hunter coat/weapon/body indices come from the author's exact original r2 source, offset downward by 16 source pixels into the larger cell. A new narrower angular closed-mask hood replaces the exposed rounded face in six poses. `HUNTER-REFERENCE.json` contains the exact pinned original body source for portable reproduction; nothing reads or samples a PNG. The source/reference distinction is explicit. A fuller grim hunter identity still needs independent visual judgment; reusing that body is not a claimed final character design.

The floor has four quiet broad seams and wide dark negative space rather than the dense high-contrast brick grid. Original transparent indexed sheets are 256×128 with four columns and seven poses. Original READY/contact compositions are integer 2× exports at 768×608. They contain only authored art; hand/readouts are live HTML in the lab. These PNGs are **not browser captures** and do not prove real text wrapping, browser paint or interaction quality.

## Shared geometry and readable ownership

`sprites.js` publishes the one scene model: actor masks and opaque frame/union bounds, native homes, foot anchors, bounded readout allocation, names, illustrative readouts and contact anchors. `geometry.js` derives the actual pose/body rectangle, source cell, readout rectangle and alpha-based point owner. Painting and point inspection consume that same published layout. Source cell rectangles are not legal gameplay hitboxes. Optional canvas point inspection scans nontransparent pose indices in reverse painter order and returns only one visible owner, so a crossing strike cannot dispatch to two overlapping DOM hit regions. Keyboard users use the separate live Inspect buttons; neither path targets or resolves a game action.

At contact, the rear hound's source point `(52,18)` shares the front skeleton's knee point `(26,45)` after explicit integer placement. The attacker layers in front at knee height to retain the victim's head/rib outline; alpha overlap is still a real art/layout inspection question. Readouts follow each unit's current published position. The hound's static travel endpoint is not an interpolation, swept-volume proof or actual action animation. No all-phase collision or engine geometry claim is made.

Live readouts retain full identity, health and Block, and complete intent type/amount/target. Each width is bounded by its scene allocation and capped at 240 CSS pixels; its natural browser height is measured and included in layout. Upper enemy readouts are placed above the body, near-side readouts below their foot anchors; a browser reviewer must still check wrapping, extents and reach at both scales. Scene scrolling exposes full source pixels and labels, and the hand stays beneath it. This lab does not claim one-screen game fit or mobile acceptance. Orientation is stated in the header/native sheet captions, title, full accessible Inspect label and inspector rather than adding another persistent rail row. Essential intent/health text uses at least 12px live type.

The study has no RAF or timed motion, so reduced motion is already static. Text assignments are compared before replacing status content. A readout ResizeObserver recalculates natural heights; disposal disconnects it, removes registered listeners and disables controls. On unavailable canvas, the fallback gives live readouts in normal flow and original PNG links with a truthful painting-unassessed message. These are source contracts until actual runtime inspection; no browser or Node execution is implied.

## Future viewing and scope

The author personally inspected the three native sheets and both authored 2× art compositions after the guarded export. They expose the mask/layout decisions without live DOM text; the figures remain schematic and must survive independent critique. No live hand/readout, 3× browser, motion or interaction observation is claimed.

After independent exact source review and Root's explicit exclusive runtime window:

```sh
node /absolute/path/to/this/packet/serve.mjs
```

Open `http://127.0.0.1:5176`. The small built-in Node server permits only ten lab/art files, installs nothing and does not expose arbitrary repository files. No telemetry, fetch, storage, game import or engine clone is present. Port/HTTP/closure and actual static browser layout remain runtime gates.

`author-perspectives.py` is the inspectable original indexed source exporter. It enforces fresh 24 MiB source work plus 512 MiB reserve and measures actual `/proc/self/status` VmHWM. Export observations are separate from the source seal. The old r2 and r1 source freezes must stay retained as comparison/rejection evidence. A later engine-backed host must preserve real accepted-event identities, held corpse/newborn semantics, current saves/rules/tactile cards, legal authority, complete readouts and exact real audio/contact allocation. Root owns that host and actual first-five-minute pacing/play comparisons after perspective/layout acceptance. This static packet earns no motion, game, fun, AAA, Steam/native, promotion or retirement approval.
