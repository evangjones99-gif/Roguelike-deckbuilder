"""Bounded source/art freeze; does not evaluate JS or run a browser."""
import pathlib,os,hashlib,json,time,stat
ROOT=pathlib.Path(__file__).resolve().parent;WORK=24*1024*1024;RESERVE=512*1024*1024
def memory():return int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text()),int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
INITIAL,MAXIMUM=memory()
if MAXIMUM-INITIAL<WORK+RESERVE:raise SystemExit(f'Seal initial admission refused: current={INITIAL},maximum={MAXIMUM},work={WORK},reserve={RESERVE}')
def guard():
 current,maximum=memory();hwm=int(next(l.split()[1] for l in pathlib.Path('/proc/self/status').read_text().splitlines() if l.startswith('VmHWM:')))*1024
 spent=max(0,current-INITIAL)
 if maximum!=MAXIMUM or hwm>WORK or spent>WORK or maximum-current<RESERVE+max(0,WORK-spent):raise RuntimeError(f'Seal refusal current={current},maximum={maximum},initial={INITIAL},VmHWM={hwm},work={WORK},reserve={RESERVE}')
 return current,hwm
def body(path,keep=False):
 fd=os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd)
  if not stat.S_ISREG(before.st_mode) or before.st_size>1024*1024:raise RuntimeError('Nonregular/oversized source')
  digest=hashlib.sha256();parts=[]
  while chunk:=os.read(fd,32768):
   digest.update(chunk)
   if keep:parts.append(chunk)
   guard()
  after=os.fstat(fd)
  if any(getattr(before,k)!=getattr(after,k) for k in ['st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_atime_ns']):raise RuntimeError('Moving source')
  return {'bytes':before.st_size,'sha256':digest.hexdigest()},b''.join(parts)
 finally:os.close(fd)
def write(name,data):
 with os.fdopen(os.open(ROOT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'w') as file:json.dump(data,file,indent=2);file.write('\n')
retained={}
for packet,expected in [('standard-sol-pixel-foundation-author-r1','ee2d57c54d509c13979719dbf3ddb10e3e7700527757014b9703a0cf06529f53'),('standard-sol-pixel-foundation-author-r2','b20d27a609a5209cc1773e7f67ccaeb1139a22bd644412f78cf9818074a3e2b6')]:
 folder=ROOT.with_name(packet);pin,data=body(folder/'MANIFEST.json',True)
 if pin['sha256']!=expected:raise RuntimeError('Retained manifest changed')
 old=json.loads(data)
 for name,record in old['files'].items():
  if body(folder/name)[0]!=record:raise RuntimeError('Retained body changed: '+name)
 retained[packet]={'manifest':pin,'all_bodies_match':True,'body_count':len(old['files'])}
referencepin,referencebody=body(ROOT/'HUNTER-REFERENCE.json',True)
reference=json.loads(referencebody)
if reference['source_sha256']!='54f64b6f66a81f6d1d061e106f11468fdee425340b610fde88e3595c62b555db':raise RuntimeError('Reference source pin mismatch')
write('SOURCE-PINS.json',{'retained':retained,'portable_hunter_reference':referencepin,'reference_scope':'R2 original coat/weapon/body with new R3 angular closed-mask hood;16source-pixel vertical offset. No PNG image input. Near/far hound and skeleton are newly drawn.',
 'scope':'Static synthetic art/layout research only; no real engine adapter, main/renderer/guard/game mutation or evaluation. Latest intended near/far perspective is a design trial, not acceptance.',
 'execution':'One guarded original indexed Python export; author inspected three native sheets and two static2x art compositions. No JS/Node/server/browser/game build or real UI observation.'})
current,hwm=guard();write('SEAL-RESOURCE.json',{'admitted':True,'initial_current':INITIAL,'maximum':MAXIMUM,'current_at_report':current,'actual_VmHWM_bytes':hwm,'work':WORK,'reserve':RESERVE,'time_ns':time.time_ns(),'scope':'This32KiBstream source seal only; actual/proc VmHWM. Original exporter has separate guard record.'})
files={}
for path in sorted(ROOT.rglob('*')):
 if path.is_symlink():raise RuntimeError('Symlink in packet')
 if path.is_file():files[str(path.relative_to(ROOT))]=body(path)[0]
total=sum(x['bytes'] for x in files.values())
if total>512*1024:raise RuntimeError('Small packet ceiling exceeded')
write('MANIFEST.json',{'kind':'Original pixel perspective r3 SOURCE freeze','scope':'Static original near/far art and live-text hand/readout lab; no browser execution, engine integration or art/fun acceptance.', 'files':files,'body_bytes':total,'body_count':len(files)})
print(json.dumps({'manifest':body(ROOT/'MANIFEST.json')[0],'body_bytes':total,'body_count':len(files),'final_actual_VmHWM_bytes':guard()[1]},indent=2))
