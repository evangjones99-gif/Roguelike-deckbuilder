import { ART } from './sprites.js';
import { layoutScene,ownerAt } from './geometry.js';
const get=id=>document.getElementById(id);
const canvas=get('field'),ctx=canvas.getContext('2d'),scene=get('scene');
let phase='ready',scale=2,selected='hound',disposed=false,layout;
const listeners=[],readouts={};
function listen(target,event,callback){target.addEventListener(event,callback);listeners.push([target,event,callback]);}
function text(node,value){if(node.textContent!==value)node.textContent=value;}
for(const [id,spec] of Object.entries(ART.scene.units)){
 const article=document.createElement('article');article.className='unit-readout';article.dataset.unit=id;
 const name=document.createElement('strong'),intent=document.createElement('span'),health=document.createElement('span'),inspect=document.createElement('button');
 name.textContent=spec.name;
 intent.textContent=spec.intent;intent.className='intent';health.textContent=spec.health;
 inspect.textContent='Inspect';inspect.setAttribute('aria-label',`Inspect ${spec.name}, ${spec.orientation}, illustrative ${spec.health}, ${spec.intent}`);
 article.title=spec.orientation;article.append(name,intent,health,inspect);scene.append(article);readouts[id]=article;
 listen(inspect,'click',()=>inspectUnit(id));
}
function inspectUnit(id){
 selected=id;const spec=ART.scene.units[id];
 text(get('inspector'),`${spec.name} — ${spec.orientation}. ${spec.health}. ${spec.intent}. All values are illustrative research display data, not game state. ${id==='hound'&&phase==='hand'?'Its figure is still absent in the static hand study.':''}`);
 for(const [name,node] of Object.entries(readouts))node.classList.toggle('selected',name===selected);
}
function drawIndices(context,rows,x0,y0){
 context.imageSmoothingEnabled=false;
 for(let y=0;y<rows.length;y++)for(let x=0;x<rows[y].length;x++){
  const index=ART.keys.indexOf(rows[y][x]);if(index===0)continue;
  context.fillStyle=ART.palette[index];context.fillRect(x0+x,y0+y,1,1);
 }
}
function draw(){
 if(!ctx)return;
 ctx.fillStyle=ART.palette[1];ctx.fillRect(0,0,canvas.width,canvas.height);
 ctx.fillStyle=ART.palette[2];
 for(const [y,x1,x2] of [[55,146,230],[131,104,270],[217,42,350],[276,10,374]])ctx.fillRect(x1,y,x2-x1,1);
 if(phase==='bind'){
  const home=ART.scene.units.hound.home;
  ctx.fillStyle=ART.palette[13];
  for(const [x,y] of [[10,59],[14,61],[20,62],[28,62],[36,60],[42,57],[44,53],[40,51],[32,50],[23,50],[15,53],[10,56]])ctx.fillRect(home[0]+x,home[1]+y,1,1);
 }
 for(const unit of layout.units)if(unit.visible)drawIndices(ctx,ART.actors[unit.id].frames[unit.frame],...unit.origin);
 if(phase==='command'){
  // Preview path only: it is never a resolved strike, target or damage event.
  const start=[ART.scene.units.hound.home[0]+27,ART.scene.units.hound.home[1]+25];
  const end=[ART.scene.units.skeleton.home[0]+26,ART.scene.units.skeleton.home[1]+45];
  ctx.fillStyle=ART.palette[9];
  for(let i=1;i<9;i+=2)ctx.fillRect(Math.round(start[0]+(end[0]-start[0])*i/9),Math.round(start[1]+(end[1]-start[1])*i/9),1,1);
 }
 if(layout.contact){ctx.fillStyle=ART.palette[13];ctx.fillRect(...layout.contact.point,1,1);}
}
function place(){
 for(const unit of layout.units){
  const node=readouts[unit.id],r=unit.readout;node.hidden=!unit.visible;
  const rules={left:`${r.left*scale}px`,top:`${r.top*scale}px`,width:`${r.width*scale}px`};
  for(const [name,value] of Object.entries(rules))if(node.style[name]!==value)node.style[name]=value;
 }
 const width=`${ART.scene.width*scale}px`;if(scene.style.width!==width)scene.style.width=width;
 canvas.style.width=width;canvas.style.height=`${ART.scene.height*scale}px`;
 scene.style.height=`${Math.ceil(layout.height*scale)}px`;
}
function settle(){
 if(disposed)return;
 layout=layoutScene(phase,scale);place();
 const measured={};for(const [id,node] of Object.entries(readouts))if(!node.hidden)measured[id]=node.getBoundingClientRect().height;
 layout=layoutScene(phase,scale,measured);place();draw();
 text(get('geometry'),`Native ${ART.scene.width}×${ART.scene.height}, common ${scale}× integer art display. Readouts ≤240 CSS px; natural text height measured. ${layout.contact?`Static hound/target source anchor shares (${layout.contact.point.join(',')}); no callback.`:'Readouts belong to the same published home/pose geometry as painted units.'}`);
 get('phase').value=phase;
 text(get('status'),`${phase.toUpperCase()} static art study. No animation, rule resolution, damage or game action occurred.`);
}
function setPhase(next){phase=next;settle();inspectUnit(selected);}
listen(get('phase'),'change',event=>setPhase(event.target.value));
listen(get('scale'),'change',event=>{scale=Number(event.target.value);settle();});
for(const button of document.querySelectorAll('[data-stage]'))listen(button,'click',()=>setPhase(button.dataset.stage));
listen(canvas,'pointerdown',event=>{
 if(!ctx||disposed)return;const rect=canvas.getBoundingClientRect();
 const id=ownerAt(layout,(event.clientX-rect.left)*canvas.width/rect.width,(event.clientY-rect.top)*canvas.height/rect.height);
 if(id)inspectUnit(id);
});
const observer=new ResizeObserver(()=>settle());for(const node of Object.values(readouts))observer.observe(node);
function dispose(){
 if(disposed)return;disposed=true;observer.disconnect();
 for(const [target,event,callback] of listeners)target.removeEventListener(event,callback);listeners.length=0;
 for(const node of document.querySelectorAll('button,select'))node.disabled=true;
 text(get('status'),'Disposed. Readout observer and registered listeners removed; static study remains. Reload to restart.');
}
listen(get('dispose'),'click',dispose);listen(window,'pagehide',dispose);
if(!ctx){scene.classList.add('fallback');text(get('fallback'),'2D canvas unavailable. Live readouts and original native PNGs remain; perspective/contact painting is unassessed.');}
settle();inspectUnit(selected);
