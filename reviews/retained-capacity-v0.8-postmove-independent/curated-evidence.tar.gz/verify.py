import hashlib,json,os,stat,collections,datetime
from pathlib import Path
OUT=Path(__file__).parent
OLD=Path('/workspace/scratch/retained-capacity-independent-v08-r1')
ROOT=Path('/workspace/Roguelike-deckbuilder/reviews/root-retained-capacity-v0.8')
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
inputs=[]
def input_record(p):
 inputs.append({'path':str(p),'size':p.stat().st_size,'sha256':sha(p)})
post=json.loads((ROOT/'POST-TRANSFER.json').read_text())
metadata=json.loads((ROOT/'ORIGINAL-METADATA.json').read_text())
for n in ('POST-TRANSFER.json','PRE-TRANSFER.json','ORIGINAL-METADATA.json'):input_record(ROOT/n)
assert len(metadata)==504
meta={x['path']:x for x in metadata};assert len(meta)==504
moves={x['sourcePath']:x for x in post['moves']};assert len(moves)==7
groups=collections.defaultdict(list);observed=[];archives=[];paths=[]
for i in range(1,8):
 p=OLD/f'case-{i:02d}.json';input_record(p);old=json.loads(p.read_text());root=Path(old['working_directory']);move=moves[str(root)]
 assert root.is_symlink()
 target=Path(move['temporaryTarget']);assert root.resolve()==target.resolve()
 assert target.is_dir() and not target.is_symlink()
 actual_names={'.',*(x.relative_to(target).as_posix() for x in target.rglob('*'))}
 assert actual_names==set(old['working_inventory']),('tree membership',i)
 current=[]
 for name,f in old['working_inventory'].items():
  p=target/name;s=p.lstat()
  assert not p.is_symlink()
  mode=oct(stat.S_IMODE(s.st_mode));assert mode==f['mode'],(i,name,'mode')
  typ='file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'other';assert typ==f['type']
  row={'case':i,'original_path':str(root/name),'current_path':str(p),'type':typ,'mode':mode,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'size':s.st_size}
  if typ=='file':
   assert s.st_size==f['size'];h=sha(p);assert h==f['sha256'],(i,name,'sha')
   row['sha256']=h;groups[(f['size'],h,mode)].append(row)
   prior=meta[str(root/name)]
   assert all(prior[k]==f[k] for k in ('inode','device','nlink'))
   row['preserved_original_metadata']=prior
  current.append(row)
 observed.extend(current)
 paths.append({'original_path':str(root),'symlink_text':os.readlink(root),'resolved_target':str(target.resolve()),'original_directory_mode':old['working_inventory']['.']['mode'],'current_directory_mode':oct(stat.S_IMODE(target.stat().st_mode)),'regular_files':sum(x['type']=='file' for x in current),'all_content_modes_directory_membership_pass':True})
 archive=Path(old['official_archive']);ledger=Path(old['official_ledger']);expected=dict(line.split(None,1)[::-1] for line in ledger.read_text().strip().splitlines())[archive.name]
 actual=sha(archive);assert actual==expected==old['archive_sha256_before']==old['archive_sha256_after']
 archives.append({'path':str(archive),'size':archive.stat().st_size,'sha256':actual,'ledger_path':str(ledger),'ledger_sha256':sha(ledger),'unchanged_R1':True})
 print(json.dumps({'case':i,'files':72,'directory_modes':3,'all_content_modes_pass':True,'archive_sha256':actual}),flush=True)
seen_inodes={};group_rows=[]
for key,rows in groups.items():
 ids={(x['device'],x['inode']) for x in rows};assert len(ids)==1
 identity=next(iter(ids));assert identity not in seen_inodes;seen_inodes[identity]=key
 assert all(x['nlink']==len(rows) for x in rows)
 group_rows.append({'size':key[0],'sha256':key[1],'mode':key[2],'current_device_inode':list(identity),'alias_count':len(rows),'all_nlinks_equal_alias_count':True,'paths':[x['current_path'] for x in rows]})
assert len(groups)==217 and sum(len(x) for x in groups.values())==504
assert sum(k[0] for k in groups)==1364999109
for x in inputs:assert sha(Path(x['path']))==x['sha256'],'input evidence changed'
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_records':inputs,'all504_file_hashes_sizes_modes_pass':True,'all21_directory_modes_memberships_pass':True,'all7_original_paths_are_symlinks_to_own_target':True,'all7_official_archives_and_ledger_sha_entries_pass':True,'217_equal_content_equal_mode_hardlink_groups_pass':True,'original_metadata_sidecar_all504_identity_rows_match_R1':True,'ctime_not_recorded_not_claimed':True,'paths':paths,'archives':archives,'current_inventory':observed,'hardlink_groups':group_rows,'actual_free_bytes_at_check':{str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ('/workspace','/tmp')},'tmp_is_durable_backup':False,'mutations_by_reviewer':False}
(OUT/'RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
