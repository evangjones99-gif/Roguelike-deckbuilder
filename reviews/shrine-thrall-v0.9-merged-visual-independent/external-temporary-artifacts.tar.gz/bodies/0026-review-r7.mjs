// scratch/shrine-thrall-visual-independent-v09-r1/review-r7.mts
import fs from "node:fs/promises";
import assert from "node:assert/strict";
import { gzipSync } from "node:zlib";
import { createHash } from "node:crypto";
import { chromium } from "/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs";

// scratch/shrine-thrall-visual-independent-v09-r1/source/content.ts
var summon = (id, name, species, cost, hp, attack, effect, passive, text, color) => ({
  id,
  name,
  species,
  type: "summon",
  cost,
  hp,
  attack,
  effect,
  passive,
  text,
  color
});
var spell = (id, name, cost, effect, value, text, color = "#bda580") => ({ id, name, type: "spell", cost, effect, value, text, color });
var HOUND = "Commands deal 2 extra damage to enemies with no block.";
var STALKER = "After a command deals damage, heal this creature 2 HP.";
var COLOSSUS = "After commanding this creature, gain 2 hunter block.";
var WIDOW = "Your targeted damaging spells deal 2 extra damage while this creature lives.";
var base = [
  summon(
    "cairnhound",
    "Cairn Hound",
    "hound",
    1,
    7,
    3,
    "hunter-ward",
    HOUND,
    "Bind a spectral hound. On binding: gain 2 hunter block.",
    "#c4c6b5"
  ),
  summon(
    "gravehound",
    "Grave Hound",
    "hound",
    2,
    11,
    4,
    "draw",
    HOUND,
    "Bind a scarred grave hound. On binding: draw 1 card.",
    "#adaf9b"
  ),
  summon(
    "fenstalker",
    "Fen Stalker",
    "stalker",
    2,
    10,
    4,
    "none",
    STALKER,
    "Bind an amphibious corpse-stalker.",
    "#7f9386"
  ),
  summon(
    "fenraker",
    "Fen Raker",
    "stalker",
    3,
    14,
    6,
    "hunter-heal",
    STALKER,
    "Bind a veteran stalker. On binding: heal the hunter 2 HP.",
    "#79887a"
  ),
  summon(
    "briarcolossus",
    "Briar Colossus",
    "colossus",
    3,
    18,
    4,
    "none",
    COLOSSUS,
    "Bind a giant of bark, bone and iron.",
    "#8d8776"
  ),
  summon(
    "ossuarycolossus",
    "Ossuary Colossus",
    "colossus",
    4,
    24,
    6,
    "pack-ward",
    COLOSSUS,
    "Bind an ossuary giant. On binding: all creatures gain 3 block.",
    "#a39b88"
  ),
  summon(
    "ashwidow",
    "Ash Widow",
    "spider",
    2,
    7,
    2,
    "none",
    WIDOW,
    "Bind an ash-veined spider.",
    "#af816f"
  ),
  summon(
    "emberwidow",
    "Ember Widow",
    "spider",
    3,
    11,
    3,
    "enemy-burn",
    WIDOW,
    "Bind an ember-veined widow. On binding: deal 2 damage to every enemy.",
    "#bc8267"
  ),
  spell("scour", "Scour", 1, "damage", 6, "Deal 6 damage to an enemy."),
  spell(
    "ironward",
    "Iron Ward",
    1,
    "block",
    7,
    "Gain 7 hunter block.",
    "#aaaeb0"
  ),
  spell(
    "sutures",
    "Blood Sutures",
    1,
    "heal",
    6,
    "Heal a creature 6 HP and give it 2 block.",
    "#ac7367"
  ),
  spell(
    "edict",
    "Pack Edict",
    2,
    "rally",
    2,
    "All bound creatures gain 2 attack this battle.",
    "#a098b3"
  ),
  spell(
    "witchfire",
    "Witchfire",
    2,
    "aoe",
    4,
    "Deal 4 damage to every enemy.",
    "#b58463"
  ),
  spell(
    "killcommand",
    "Kill Command",
    1,
    "ready",
    2,
    "Ready a creature to command again; give it 2 block.",
    "#bda580"
  ),
  spell(
    "gravetithe",
    "Grave Tithe",
    2,
    "siphon",
    7,
    "Deal 7 damage to an enemy. Heal the hunter 3 HP.",
    "#a098b3"
  ),
  spell("survey", "Forbidden Survey", 1, "draw", 2, "Draw 2 cards.", "#bab8a6"),
  spell(
    "bloodprice",
    "Blood Price",
    0,
    "energy",
    1,
    "Gain 1 energy. Lose 3 hunter HP.",
    "#ac7367"
  ),
  spell(
    "aegis",
    "Black Aegis",
    2,
    "shelter",
    5,
    "Hunter and all bound creatures gain 5 block.",
    "#929e9b"
  ),
  spell(
    "harpoon",
    "Chain Harpoon",
    2,
    "pack",
    4,
    "Deal 4 damage plus 2 per bound creature to an enemy.",
    "#bab8a6"
  ),
  spell(
    "covenant",
    "Flesh Covenant",
    2,
    "communion",
    2,
    "Heal the hunter 2 HP per bound creature.",
    "#ac7367"
  ),
  spell(
    "sunder",
    "Sundering Hex",
    1,
    "shred",
    3,
    "Remove all block from an enemy, then deal 3 damage.",
    "#aaaeb0"
  ),
  spell(
    "silence",
    "Silence the Dead",
    2,
    "control",
    0,
    "Cancel an enemy's announced damage and reinforcements this turn. Armor still resolves.",
    "#a098b3"
  ),
  spell(
    "resonance",
    "Grave Resonance",
    2,
    "solo",
    10,
    "Deal 10 damage to an enemy. Deal 4 extra if you have no bound creatures.",
    "#a098b3"
  ),
  spell(
    "draught",
    "Bleak Draught",
    2,
    "hunterheal",
    7,
    "Heal the hunter 7 HP.",
    "#ac7367"
  )
];
function upgradeText(c) {
  const v = (c.value ?? 0) + 2;
  const text = {
    damage: `Deal ${v} damage to an enemy.`,
    block: `Gain ${v} hunter block.`,
    heal: `Heal a creature ${v} HP and give it 2 block.`,
    rally: `All bound creatures gain ${v} attack this battle.`,
    aoe: `Deal ${v} damage to every enemy.`,
    ready: `Ready a creature to command again; give it ${v} block.`,
    siphon: `Deal ${v} damage to an enemy. Heal the hunter 3 HP.`,
    draw: `Draw ${v} cards.`,
    energy: `Gain ${v} energy. Lose 3 hunter HP.`,
    shelter: `Hunter and all bound creatures gain ${v} block.`,
    pack: `Deal ${v} damage plus 2 per bound creature to an enemy.`,
    communion: `Heal the hunter ${v} HP per bound creature.`,
    shred: `Remove all block from an enemy, then deal ${v} damage.`,
    control: c.text + " Enhanced: costs 1 energy.",
    solo: `Deal ${v} damage to an enemy. Deal 4 extra if you have no bound creatures.`,
    hunterheal: `Heal the hunter ${v} HP.`
  };
  return text[c.effect];
}
var CARDS = Object.fromEntries(
  base.flatMap((c) => [
    [c.id, c],
    [
      c.id + "+",
      {
        ...c,
        id: c.id + "+",
        name: c.name + " +",
        cost: c.effect === "control" ? 1 : c.cost,
        hp: c.hp === void 0 ? void 0 : c.hp + 3,
        attack: c.attack === void 0 ? void 0 : c.attack + 1,
        value: c.value === void 0 ? void 0 : c.value + 2,
        text: c.type === "summon" ? c.text + " Enhanced: +3 HP, +1 attack." : upgradeText(c)
      }
    ]
  ])
);
var BASE_CARD_IDS = base.map((c) => c.id);
var STARTER_DECK = [
  "cairnhound",
  "cairnhound",
  "fenstalker",
  "ashwidow",
  "briarcolossus",
  "scour",
  "scour",
  "ironward",
  "ironward",
  "sutures",
  "sunder",
  "survey"
];
var SHOP_PRICES = { summon: 55, spell: 40, remove: 35 };
var RELICS = {
  "moon-charm": {
    name: "Wraithglass Shard",
    text: "All spell damage increases by 1."
  },
  "ember-seed": {
    name: "Ossuary Nail",
    text: "Your bound creatures have 2 additional HP."
  },
  "brass-bell": {
    name: "Black Contract Seal",
    text: "Gain 1 additional energy on the first turn of each battle."
  },
  "blood-vial": {
    name: "Surgeon's Reliquary",
    text: "Heal the hunter 2 HP after every victory."
  },
  "war-brand": {
    name: "Iron War Brand",
    text: "Your bound creatures gain 1 attack on binding."
  },
  "grave-coin": {
    name: "Dead Man's Coin",
    text: "Gain 1 extra energy each turn that begins without bound creatures."
  }
};
var ENEMIES = {
  raider: {
    name: "Ironjaw Reaver",
    species: "warlord",
    hp: 16,
    attack: 4,
    color: "#a6a59c",
    passive: "While armored, commands reflect 1 damage through creature block. Spells never trigger retaliation."
  },
  revenant: {
    name: "Gloam Revenant",
    species: "wraith",
    hp: 15,
    attack: 5,
    color: "#8f9aab",
    passive: "Strikes ignore block. Targeted damaging spells deal 2 less damage to this enemy."
  },
  acolyte: {
    name: "Hollow Acolyte",
    species: "necromancer",
    hp: 24,
    attack: 5,
    color: "#929085",
    passive: "Alternates raising one Bone Thrall and cursing the hunter. Six enemy slots limit reinforcements."
  },
  brood: {
    name: "Cindermaw Brood",
    species: "dragon",
    hp: 28,
    attack: 6,
    color: "#ac7862",
    passive: "Alternates a bite at the front creature and a breath attack against all targets."
  },
  thrall: {
    name: "Bone Thrall",
    species: "thrall",
    hp: 7,
    attack: 3,
    color: "#b2ac95",
    passive: "Attacks the weakest bound creature, or the hunter if none remain."
  },
  ironjaw: {
    name: "Ironjaw Warlord",
    species: "warlord",
    hp: 112,
    attack: 9,
    color: "#a6a59c",
    passive: "While armored, commands reflect 2 damage through creature block. Use Sundering Hex or spells to break armor safely."
  },
  cantor: {
    name: "Hollow Cantor",
    species: "necromancer",
    hp: 92,
    attack: 9,
    color: "#929085",
    passive: "Raises two Bone Thralls, curses the hunter, then assaults all targets. Silence cancels announced reinforcements."
  },
  cindermaw: {
    name: "Cindermaw",
    species: "dragon",
    hp: 125,
    attack: 10,
    color: "#ac7862",
    passive: "Cycles armored wings, breath against all targets, then a heavy hunter strike. Prepare block before the breath."
  }
};
var BOSS_IDS = ["ironjaw", "cantor", "cindermaw"];
function bossForSeed(seed) {
  return BOSS_IDS[(seed >>> 0) % BOSS_IDS.length];
}

// scratch/shrine-thrall-visual-independent-v09-r1/source/world-rng.ts
function worldRank(purpose, context, identity = "") {
  const key = ["hollowpact", 2, context.seed, purpose, context.node, context.kind, identity];
  const mask = (1n << 64n) - 1n;
  let h = 14695981039346656037n;
  for (const byte of new TextEncoder().encode(JSON.stringify(key)))
    h = (h ^ BigInt(byte)) * 1099511628211n & mask;
  h = (h ^ h >> 30n) * 0xbf58476d1ce4e5b9n & mask;
  h = (h ^ h >> 27n) * 0x94d049bb133111ebn & mask;
  return h ^ h >> 31n;
}
function worldOrder(ids, purpose, context) {
  return ids.map((id) => ({ id, rank: worldRank(purpose, context, id) })).sort((a, b) => a.rank < b.rank ? -1 : a.rank > b.rank ? 1 : a.id < b.id ? -1 : a.id > b.id ? 1 : 0).map((entry) => entry.id);
}
function worldDrawSeed(context) {
  return Number(worldRank("battle-deck", context) & 0xffffffffn) || 1;
}
var EARLY = {
  "normal.raider-revenant": ["raider", "revenant"],
  "normal.raider-thrall": ["raider", "thrall"]
};
var NORMAL = {
  "normal.brood-thrall": ["brood", "thrall"],
  "normal.raider-revenant": ["raider", "revenant"],
  "normal.acolyte-thrall": ["acolyte", "thrall"],
  "normal.revenant-thrall-thrall": ["revenant", "thrall", "thrall"]
};
var ELITE = {
  "elite.raider-revenant-acolyte": ["raider", "revenant", "acolyte"],
  "elite.brood-acolyte": ["brood", "acolyte"],
  "elite.raider-raider-revenant": ["raider", "raider", "revenant"],
  "elite.acolyte-revenant-revenant": ["acolyte", "revenant", "revenant"]
};
function worldFormation(context) {
  if (context.kind !== "battle" && context.kind !== "elite")
    throw new RangeError("Only battle and elite nodes sample a world formation");
  const pool = context.kind === "elite" ? ELITE : context.node <= 2 ? EARLY : NORMAL;
  const id = worldOrder(Object.keys(pool), "encounter", context)[0];
  return [...pool[id]];
}

// scratch/shrine-thrall-visual-independent-v09-r1/source/engine.ts
function trace(events, source, kind, cardId) {
  return events ? { events, source, kind, ...cardId ? { cardId } : {} } : void 0;
}
var ROUTES = [
  ["battle"],
  ["battle", "event"],
  ["camp", "shop"],
  ["battle", "elite"],
  ["event", "shop"],
  ["battle", "elite"],
  ["camp", "shop"],
  ["elite", "battle"],
  ["camp", "event"],
  ["boss"]
];
var count = (xs) => xs.reduce(
  (m, id) => (m[id] = (m[id] ?? 0) + 1, m),
  {}
);
function random(s) {
  let x = s.rng;
  x ^= x << 13;
  x ^= x >>> 17;
  x ^= x << 5;
  s.rng = x >>> 0;
  return s.rng / 4294967296;
}
function shuffle(s, cards) {
  const a = cards.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(random(s) * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function note(s, t) {
  s.log.push(t);
  s.log = s.log.slice(-60);
}
function map(s) {
  s.phase = "map";
  s.route = ROUTES[s.floor]?.slice() ?? [];
  s.rewards = [];
}
function createGame(seed, difficulty = 0, options = { engineKind: 2 }) {
  if (options.engineKind !== 1 && options.engineKind !== 2)
    throw new RangeError("Unsupported rules generation");
  const value = Number.isFinite(seed) ? Math.trunc(seed) >>> 0 : 1;
  return {
    ...options.engineKind === 1 ? { schema: 2 } : { schema: 3, engineKind: 2 },
    seed: value,
    rng: value || 2654435769,
    phase: "map",
    hp: 65,
    maxHp: 65,
    block: 0,
    energy: 0,
    gold: 65,
    floor: 0,
    turn: 0,
    deck: STARTER_DECK.slice(),
    draw: [],
    discard: [],
    hand: [],
    allies: [],
    enemies: [],
    rewards: [],
    relics: [],
    route: ROUTES[0].slice(),
    log: ["A scarred hunter. One final contract. No pact is harmless."],
    nextUid: 1,
    difficulty: Math.max(
      0,
      Math.min(2, Math.trunc(Number.isFinite(difficulty) ? difficulty : 0))
    ),
    stats: { cardsPlayed: 0, damageDealt: 0, turns: 0, battles: 0 }
  };
}
function cardTarget(id) {
  const c = CARDS[id];
  return !c || c.type === "summon" ? "none" : ["damage", "siphon", "pack", "shred", "control", "solo"].includes(
    c.effect
  ) ? "enemy" : ["heal", "ready"].includes(c.effect) ? "ally" : "none";
}
function draw(s, n) {
  for (let i = 0; i < n && s.hand.length < 12; i++) {
    if (!s.draw.length) {
      s.draw = shuffle(s, s.discard);
      s.discard = [];
    }
    const id = s.draw.pop();
    if (!id) break;
    s.hand.push(id);
  }
}
function enemy(s, id) {
  const e = ENEMIES[id];
  const boss = ["ironjaw", "cantor", "cindermaw"].includes(id);
  const scale = id === "thrall" ? Math.floor(s.floor / 3) + s.difficulty : Math.max(0, s.floor - 1) + s.difficulty * (boss ? 12 : 2);
  return {
    uid: "e" + s.nextUid++,
    cardId: id,
    ...e,
    hp: e.hp + scale,
    maxHp: e.hp + scale,
    attack: e.attack + Math.floor(Math.max(0, s.floor - 1) / 4) + s.difficulty,
    block: 0,
    acted: false
  };
}
function intentions(s) {
  for (const e of s.enemies) {
    const weakest = s.allies.slice().sort((a, b) => a.hp - b.hp)[0];
    let target = "hunter", damage = e.attack, label = "Strike", summon2;
    switch (e.cardId) {
      case "thrall":
        target = weakest?.uid ?? "hunter";
        label = "Claw weakest creature";
        break;
      case "raider":
      case "ironjaw":
        if (s.turn % 2 === 1) {
          damage = 0;
          target = e.uid;
          label = e.cardId === "ironjaw" ? "Raise plated shield \xB7 gain 14 block" : "Raise shield \xB7 gain 4 block";
        } else {
          damage += e.cardId === "ironjaw" ? 3 : 1;
          label = "Iron cleaver";
        }
        break;
      case "revenant":
        label = "Spectral rend \xB7 ignores block";
        break;
      case "acolyte":
        if (s.turn % 2 === 1) {
          damage = 0;
          target = e.uid;
          summon2 = ["thrall"];
          label = "Raise 1 Bone Thrall";
        } else {
          label = "Grave curse";
        }
        break;
      case "brood":
        if (s.turn % 2 === 0) {
          target = "all";
          damage = 3 + s.difficulty;
          label = "Cinder breath \xB7 all targets";
        } else {
          target = s.allies[0]?.uid ?? "hunter";
          label = "Rending bite";
        }
        break;
      case "cantor":
        if (s.turn % 3 === 1) {
          damage = 0;
          target = e.uid;
          summon2 = ["thrall", "thrall"];
          label = "Raise 2 Bone Thralls";
        } else if (s.turn % 3 === 2) {
          label = "Death litany";
        } else {
          target = "all";
          damage = 5 + s.difficulty;
          label = "Grave tempest \xB7 all targets";
        }
        break;
      case "cindermaw":
        if (s.turn % 3 === 1) {
          damage = 0;
          target = e.uid;
          label = "Fold armored wings \xB7 gain 10 block";
        } else if (s.turn % 3 === 2) {
          target = "all";
          damage = 7 + s.difficulty;
          label = "Ashen breath \xB7 all targets";
        } else {
          damage += 4;
          label = "Crushing maw";
        }
        break;
    }
    e.intent = { target, damage, label, ...summon2 ? { summon: summon2 } : {} };
  }
}
function beginBattle(s, kind, events) {
  s.phase = "battle";
  s.route = [kind];
  s.block = 0;
  s.energy = 5 + (s.relics.includes("brass-bell") ? 1 : 0) + (s.relics.includes("grave-coin") ? 1 : 0);
  s.turn = 1;
  s.allies = [];
  s.hand = [];
  s.discard = [];
  if (s.schema === 3)
    s.rng = worldDrawSeed({ seed: s.seed, node: s.floor, kind });
  s.draw = shuffle(s, s.deck);
  s.stats.battles++;
  s.stats.turns++;
  const boss = bossForSeed(s.seed);
  const sets = kind === "boss" ? [[boss]] : kind === "elite" ? [
    ["raider", "revenant", "acolyte"],
    ["brood", "acolyte"],
    ["raider", "raider", "revenant"],
    ["acolyte", "revenant", "revenant"]
  ] : s.floor <= 2 ? [
    ["raider", "revenant"],
    ["raider", "thrall"]
  ] : [
    ["brood", "thrall"],
    ["raider", "revenant"],
    ["acolyte", "thrall"],
    ["revenant", "thrall", "thrall"]
  ];
  const formation = s.schema === 3 ? kind === "boss" ? [boss] : worldFormation({ seed: s.seed, node: s.floor, kind }) : sets[Math.floor(random(s) * sets.length)];
  s.enemies = formation.map(
    (id) => enemy(s, id)
  );
  for (const e of s.enemies)
    events?.push({
      type: "summon",
      source: "world",
      target: e.uid,
      cardId: e.cardId,
      unit: structuredClone(e),
      side: "enemy"
    });
  draw(s, 5);
  intentions(s);
  note(
    s,
    kind === "boss" ? "Final contract: " + ENEMIES[boss].name + "." : kind === "elite" ? "An elder contract waits in the ruins." : "The keep has teeth."
  );
}
function hitUnit(s, u, damage, source, pierce = false, resolution) {
  const beforeHp = u.hp, blocked = pierce ? 0 : Math.min(u.block, damage);
  const dealt = Math.min(u.hp, Math.max(0, damage - (pierce ? 0 : u.block)));
  if (!pierce) u.block = Math.max(0, u.block - damage);
  u.hp -= dealt;
  if (source) s.stats.damageDealt += dealt;
  if (resolution) {
    const { events, ...from } = resolution;
    events.push({
      type: "hit",
      ...from,
      target: u.uid,
      damage,
      blocked,
      hpLost: dealt,
      beforeHp,
      afterHp: u.hp
    });
    if (beforeHp > 0 && u.hp <= 0)
      events.push({
        type: "death",
        source: resolution.source,
        target: u.uid,
        cardId: u.cardId
      });
  }
}
function hitHunter(s, damage, pierce = false, resolution) {
  const beforeHp = s.hp, blocked = pierce ? 0 : Math.min(s.block, damage);
  const dealt = Math.max(0, damage - (pierce ? 0 : s.block));
  if (!pierce) s.block = Math.max(0, s.block - damage);
  s.hp = Math.max(0, s.hp - dealt);
  if (resolution) {
    const { events, ...from } = resolution;
    events.push({
      type: "hit",
      ...from,
      target: "hunter",
      damage,
      blocked,
      hpLost: beforeHp - s.hp,
      beforeHp,
      afterHp: s.hp
    });
    if (beforeHp > 0 && s.hp <= 0)
      events.push({
        type: "death",
        source: resolution.source,
        target: "hunter"
      });
  }
}
function heal(s, n, events, source = "hunter") {
  const beforeHp = s.hp;
  s.hp = Math.min(s.maxHp, s.hp + n);
  if (s.hp > beforeHp)
    events?.push({
      type: "heal",
      source,
      target: "hunter",
      amount: s.hp - beforeHp,
      beforeHp,
      afterHp: s.hp
    });
}
function healUnit(u, n, events, source = "hunter") {
  const beforeHp = u.hp;
  u.hp = Math.min(u.maxHp, u.hp + n);
  if (u.hp > beforeHp)
    events?.push({
      type: "heal",
      source,
      target: u.uid,
      amount: u.hp - beforeHp,
      beforeHp,
      afterHp: u.hp
    });
}
function ward(s, u, n, events, source = "hunter") {
  if (u) u.block += n;
  else s.block += n;
  if (n > 0)
    events?.push({
      type: "ward",
      source,
      target: u?.uid ?? "hunter",
      amount: n
    });
}
function clean(s) {
  for (const a of s.allies)
    if (a.hp <= 0) {
      s.discard.push(a.cardId);
      note(s, a.name + " returns to the deck.");
    }
  s.allies = s.allies.filter((a) => a.hp > 0);
  s.enemies = s.enemies.filter((e) => e.hp > 0);
}
function finish(s, events) {
  clean(s);
  if (s.hp <= 0) {
    s.phase = "defeat";
    note(s, "The pact breaks. The ruins keep another name.");
    return;
  }
  if (s.enemies.length) return;
  const kind = s.route[0];
  s.hand = [];
  s.draw = [];
  s.discard = [];
  s.allies = [];
  s.block = 0;
  s.energy = 0;
  s.gold += kind === "elite" ? 40 : 25;
  heal(
    s,
    (kind === "elite" ? 3 : 2) + (s.relics.includes("blood-vial") ? 2 : 0),
    events
  );
  if (kind === "boss") {
    s.phase = "victory";
    s.route = [];
    note(
      s,
      "Contract fulfilled. You leave the ruins scarred, alive, and paid."
    );
  } else {
    if (kind === "elite") {
      const available = Object.keys(RELICS).filter(
        (id) => !s.relics.includes(id)
      );
      if (available.length) {
        const id = s.schema === 3 ? worldOrder(available, "relic", { seed: s.seed, node: s.floor, kind })[0] : available[Math.floor(random(s) * available.length)];
        s.relics.push(id);
        note(s, "Relic found: " + RELICS[id].name);
      }
    }
    s.phase = "reward";
    s.rewards = (s.schema === 3 ? worldOrder(BASE_CARD_IDS, "reward", { seed: s.seed, node: s.floor, kind }) : shuffle(s, BASE_CARD_IDS)).slice(0, 3);
    note(s, "Contract complete. Choose one new card or travel light.");
  }
}
function targetedSpell(s, target, damage, resolution) {
  const widow = s.allies.filter((u) => u.species === "spider").length * 2;
  const relic = s.relics.includes("moon-charm") ? 1 : 0;
  const resistance = target.cardId === "revenant" ? 2 : 0;
  hitUnit(
    s,
    target,
    Math.max(0, damage + widow + relic - resistance),
    true,
    false,
    resolution
  );
}
function play(s, a, events) {
  const id = s.hand.splice(a.index, 1)[0], c = CARDS[id];
  s.energy -= c.cost;
  s.stats.cardsPlayed++;
  if (c.type === "summon") {
    const hpBonus = s.relics.includes("ember-seed") ? 2 : 0;
    const u = {
      uid: "a" + s.nextUid++,
      cardId: id,
      name: c.name,
      species: c.species,
      hp: c.hp + hpBonus,
      maxHp: c.hp + hpBonus,
      attack: c.attack + (s.relics.includes("war-brand") ? 1 : 0),
      block: 0,
      acted: false,
      color: c.color,
      passive: c.passive
    };
    s.allies.push(u);
    events?.push({
      type: "summon",
      source: "hunter",
      target: u.uid,
      cardId: id,
      unit: structuredClone(u),
      side: "ally"
    });
    switch (c.effect) {
      case "hunter-ward":
        ward(s, void 0, 2, events, u.uid);
        break;
      case "draw":
        draw(s, 1);
        break;
      case "hunter-heal":
        heal(s, 2, events, u.uid);
        break;
      case "pack-ward":
        for (const a2 of s.allies) ward(s, a2, 3, events, u.uid);
        break;
      case "enemy-burn":
        for (const e of s.enemies)
          hitUnit(s, e, 2, true, false, trace(events, u.uid, "summon", id));
        break;
    }
    note(s, "Bound " + c.name + ".");
  } else {
    const v = c.value ?? 0, target = s.enemies.find((e) => e.uid === a.target), ally = s.allies.find((u) => u.uid === a.target);
    const spellTrace = trace(events, "hunter", "spell", id);
    switch (c.effect) {
      case "damage":
        targetedSpell(s, target, v, spellTrace);
        break;
      case "block":
        ward(s, void 0, v, events);
        break;
      case "heal":
        healUnit(ally, v, events);
        ward(s, ally, 2, events);
        break;
      case "rally":
        for (const u of s.allies) {
          const before = u.attack;
          u.attack += v;
          if (u.attack !== before)
            events?.push({
              type: "buff",
              source: "hunter",
              target: u.uid,
              cardId: id,
              stat: "attack",
              before,
              after: u.attack,
              amount: u.attack - before
            });
        }
        break;
      case "aoe":
        for (const e of s.enemies)
          hitUnit(
            s,
            e,
            v + (s.relics.includes("moon-charm") ? 1 : 0),
            true,
            false,
            spellTrace
          );
        break;
      case "ready":
        ally.acted = false;
        ward(s, ally, v, events);
        break;
      case "siphon":
        targetedSpell(s, target, v, spellTrace);
        heal(s, 3, events);
        break;
      case "draw":
        draw(s, v);
        break;
      case "energy":
        s.energy += v;
        hitHunter(s, 3, true, trace(events, "hunter", "self", id));
        break;
      case "shelter":
        ward(s, void 0, v, events);
        for (const u of s.allies) ward(s, u, v, events);
        break;
      case "pack":
        targetedSpell(s, target, v + s.allies.length * 2, spellTrace);
        break;
      case "communion":
        heal(s, v * s.allies.length, events);
        break;
      case "shred":
        target.block = 0;
        targetedSpell(s, target, v, spellTrace);
        break;
      case "control":
        const beforeIntent = structuredClone(target.intent);
        target.intent = {
          ...target.intent,
          damage: 0,
          label: !(s.schema === 3 && target.cardId === "revenant") && target.intent.label.includes("block") ? canonicalSilenceGuardLabel(target.intent.label) : "Silenced \xB7 damage and reinforcements canceled",
          summon: []
        };
        if (JSON.stringify(beforeIntent) !== JSON.stringify(target.intent))
          events?.push({
            type: "control",
            source: "hunter",
            target: target.uid,
            cardId: id,
            before: beforeIntent,
            after: structuredClone(target.intent)
          });
        break;
      case "solo":
        targetedSpell(
          s,
          target,
          v + (s.allies.length === 0 ? 4 : 0),
          spellTrace
        );
        break;
      case "hunterheal":
        heal(s, v, events);
        break;
    }
    s.discard.push(id);
    note(s, "Cast " + c.name + ".");
  }
  finish(s, events);
}
function endTurn(s, events) {
  for (const e of s.enemies) e.block = 0;
  const reinforcements = [];
  for (const e of s.enemies.slice()) {
    const i = e.intent;
    if (i.summon?.length)
      reinforcements.push(...i.summon.map((id) => ({ id, source: e.uid })));
    const enemyTrace = trace(events, e.uid, "enemy", e.cardId);
    if (i.damage === 0) {
      if (e.cardId === "ironjaw" && s.turn % 2 === 1)
        ward(s, e, 14, events, e.uid);
      else if (e.cardId === "cindermaw" && s.turn % 3 === 1)
        ward(s, e, 10, events, e.uid);
      else if (e.cardId === "raider" && s.turn % 2 === 1)
        ward(s, e, 4, events, e.uid);
    } else if (i.target === "all") {
      hitHunter(s, i.damage, false, enemyTrace);
      for (const u of s.allies)
        hitUnit(s, u, i.damage, false, false, enemyTrace);
    } else {
      const u = s.allies.find((u2) => u2.uid === i.target && u2.hp > 0);
      if (u)
        hitUnit(s, u, i.damage, false, e.cardId === "revenant", enemyTrace);
      else hitHunter(s, i.damage, e.cardId === "revenant", enemyTrace);
    }
    note(s, e.name + ": " + i.label + ".");
    clean(s);
    if (s.hp <= 0) break;
  }
  if (s.hp > 0) {
    for (const raisedPlan of reinforcements)
      if (s.enemies.length < 6) {
        const raised = enemy(s, raisedPlan.id);
        s.enemies.push(raised);
        events?.push({
          type: "summon",
          source: raisedPlan.source,
          target: raised.uid,
          cardId: raised.cardId,
          unit: structuredClone(raised),
          side: "enemy"
        });
        note(s, raised.name + " rises. It will act next turn.");
      }
  }
  finish(s, events);
  if (s.phase !== "battle") return;
  s.discard.push(...s.hand);
  s.hand = [];
  s.block = 0;
  for (const u of s.allies) {
    u.block = 0;
    u.acted = false;
  }
  s.turn++;
  s.stats.turns++;
  s.energy = 5 + (s.relics.includes("grave-coin") && s.allies.length === 0 ? 1 : 0);
  draw(s, 5);
  intentions(s);
  note(s, "Turn " + s.turn + ".");
}
function legalActions(s) {
  if (s.phase === "map")
    return s.route.map((choice) => ({ type: "travel", choice }));
  if (s.phase === "battle") {
    const actions = [];
    s.hand.forEach((id, index) => {
      const c = CARDS[id];
      if (c.cost > s.energy || c.type === "summon" && s.allies.length >= 6)
        return;
      const t = cardTarget(id);
      if (t === "none") actions.push({ type: "play", index });
      else
        for (const u of t === "enemy" ? s.enemies : s.allies)
          actions.push({ type: "play", index, target: u.uid });
    });
    for (const u of s.allies)
      if (!u.acted)
        for (const e of s.enemies)
          actions.push({ type: "attack", unit: u.uid, target: e.uid });
    actions.push({ type: "endTurn" });
    return actions;
  }
  if (s.phase === "reward")
    return [
      ...s.deck.length < 60 ? s.rewards.map((card) => ({ type: "reward", card })) : [],
      { type: "reward", card: null }
    ];
  if (s.phase === "camp")
    return [
      { type: "camp", choice: "rest" },
      ...s.deck.flatMap(
        (id, index) => id.endsWith("+") ? [] : [{ type: "camp", choice: "train", index }]
      )
    ];
  if (s.phase === "shop")
    return [
      ...s.deck.length < 60 ? s.rewards.filter((id) => s.gold >= SHOP_PRICES[CARDS[id].type]).map((card) => ({ type: "buy", card })) : [],
      ...s.gold >= SHOP_PRICES.remove && s.deck.length > 5 ? s.deck.map((_, index) => ({ type: "remove", index })) : [],
      { type: "leave" }
    ];
  if (s.phase === "event")
    return [
      ...s.hp > 8 && !s.relics.includes("moon-charm") ? [{ type: "event", choice: "offering" }] : [],
      ...s.hp > 4 && s.deck.length > 5 && s.deck.includes("scour") ? [{ type: "event", choice: "purge" }] : [],
      ...s.gold >= 30 && s.hp < s.maxHp ? [{ type: "event", choice: "bargain" }] : [],
      { type: "event", choice: "forage" },
      { type: "event", choice: "leave" }
    ];
  return [];
}
function matches(a, b) {
  if (!a || typeof a !== "object" || a.type !== b.type) return false;
  switch (b.type) {
    case "play":
      return a.type === "play" && a.index === b.index && a.target === b.target;
    case "attack":
      return a.type === "attack" && a.unit === b.unit && a.target === b.target;
    case "camp":
      return a.type === "camp" && a.choice === b.choice && a.index === b.index;
    case "travel":
    case "event":
      return "choice" in a && a.choice === b.choice;
    case "reward":
    case "buy":
      return "card" in a && a.card === b.card;
    case "remove":
      return a.type === "remove" && a.index === b.index;
    default:
      return true;
  }
}
function reduceAction(state, action, events) {
  if (action?.type === "start") {
    if (!Number.isFinite(action.seed)) return state;
    return createGame(action.seed, action.difficulty);
  }
  if (!legalActions(state).some((a) => matches(action, a))) return state;
  const s = structuredClone(state);
  switch (action.type) {
    case "travel":
      s.floor++;
      if (["battle", "elite", "boss"].includes(action.choice))
        beginBattle(s, action.choice, events);
      else {
        s.phase = action.choice;
        s.route = [action.choice];
        if (action.choice === "shop")
          s.rewards = (s.schema === 3 ? worldOrder(BASE_CARD_IDS, "shop", {
            seed: s.seed,
            node: s.floor,
            kind: "shop"
          }) : shuffle(s, BASE_CARD_IDS)).slice(0, 5);
        note(s, "Reached the " + action.choice + ".");
      }
      break;
    case "play":
      play(s, action, events);
      break;
    case "attack": {
      const u = s.allies.find((u2) => u2.uid === action.unit), e = s.enemies.find((e2) => e2.uid === action.target);
      u.acted = true;
      const wasArmored = e.block > 0;
      const hp = e.hp;
      hitUnit(
        s,
        e,
        u.attack + (u.species === "hound" && !wasArmored ? 2 : 0),
        true,
        false,
        trace(events, u.uid, "command", u.cardId)
      );
      if (u.species === "stalker" && e.hp < hp) healUnit(u, 2, events, u.uid);
      if (u.species === "colossus") ward(s, void 0, 2, events, u.uid);
      if (wasArmored && (e.cardId === "raider" || e.cardId === "ironjaw")) {
        hitUnit(
          s,
          u,
          e.cardId === "ironjaw" ? 2 : 1,
          false,
          true,
          trace(events, e.uid, "retaliation", e.cardId)
        );
        note(s, e.name + " retaliates against " + u.name + ".");
      }
      note(s, u.name + " strikes " + e.name + ".");
      finish(s, events);
      break;
    }
    case "endTurn":
      endTurn(s, events);
      break;
    case "reward":
      if (action.card) s.deck.push(action.card);
      map(s);
      break;
    case "camp":
      if (action.choice === "rest") {
        heal(s, 18, events);
        note(s, "Restored 18 HP beside the contract fire.");
      } else {
        const id = s.deck[action.index];
        s.deck[action.index] = id + "+";
        note(s, "Trained " + CARDS[id].name + ".");
      }
      map(s);
      break;
    case "buy":
      s.gold -= SHOP_PRICES[CARDS[action.card].type];
      s.deck.push(action.card);
      s.rewards.splice(s.rewards.indexOf(action.card), 1);
      note(s, "Purchased " + CARDS[action.card].name + ".");
      break;
    case "remove":
      s.gold -= SHOP_PRICES.remove;
      note(s, "Released " + CARDS[s.deck[action.index]].name + ".");
      s.deck.splice(action.index, 1);
      break;
    case "leave":
      map(s);
      break;
    case "event":
      if (action.choice === "offering") {
        hitHunter(s, 8, true, trace(events, "hunter", "self"));
        s.relics.push("moon-charm");
        note(s, "The wraithglass oath is sealed in blood.");
      } else if (action.choice === "purge") {
        hitHunter(s, 4, true, trace(events, "hunter", "self"));
        s.deck.splice(s.deck.indexOf("scour"), 1);
        note(s, "An old Scour contract burns.");
      } else if (action.choice === "bargain") {
        s.gold -= 30;
        heal(s, 16, events);
        note(s, "The surgeon closes your wounds.");
      } else if (action.choice === "forage") {
        s.gold += 25;
        note(s, "Found 25 gold beneath the roots.");
      }
      map(s);
      break;
  }
  return s;
}
var SILENCE_GUARD_SUFFIX = " \xB7 silenced (armor remains)";
function canonicalSilenceGuardLabel(label) {
  while (label.endsWith(SILENCE_GUARD_SUFFIX))
    label = label.slice(0, -SILENCE_GUARD_SUFFIX.length);
  return label + SILENCE_GUARD_SUFFIX;
}
function applyActionWithEvents(state, action) {
  const events = [];
  return { state: reduceAction(state, action, events), events };
}
function validateState(value) {
  try {
    if (!value || typeof value !== "object" || Array.isArray(value))
      return false;
    const s = value;
    const integer = (v, min = 0, max = 1e6) => typeof v === "number" && Number.isInteger(v) && v >= min && v <= max;
    const strings = (v, max) => Array.isArray(v) && v.length <= max && v.every((x) => typeof x === "string" && x.length < 400);
    if (!(s.schema === 2 && !Object.hasOwn(s, "engineKind") || s.schema === 3 && s.engineKind === 2 && Object.hasOwn(s, "engineKind")) || ![
      "map",
      "battle",
      "reward",
      "camp",
      "shop",
      "event",
      "victory",
      "defeat"
    ].includes(s.phase))
      return false;
    if (!integer(s.seed, 0, 4294967295) || !integer(s.rng, 1, 4294967295) || !integer(s.hp, 0, 1e3) || !integer(s.maxHp, 1, 1e3) || s.hp > s.maxHp || !integer(s.block) || !integer(s.energy, 0, 1e3) || !integer(s.gold) || !integer(s.floor, 0, 10) || !integer(s.turn, 0, 1e4) || !integer(s.nextUid, 1, 1e6) || !integer(s.difficulty, 0, 2))
      return false;
    for (const [key, max] of [
      ["deck", 60],
      ["draw", 60],
      ["discard", 60],
      ["hand", 12],
      ["rewards", 5]
    ])
      if (!strings(s[key], max) || s[key].some((id) => !Object.hasOwn(CARDS, id)))
        return false;
    if (s.deck.length < 5 || !strings(s.log, 60) || !strings(s.relics, 6) || new Set(s.relics).size !== s.relics.length || s.relics.some((id) => !Object.hasOwn(RELICS, id)) || !strings(s.route, 3) || s.route.some(
      (id) => !["battle", "elite", "camp", "shop", "event", "boss"].includes(id)
    ))
      return false;
    if (!s.stats || typeof s.stats !== "object" || !["cardsPlayed", "damageDealt", "turns", "battles"].every(
      (k) => integer(s.stats[k])
    ))
      return false;
    if (!Array.isArray(s.allies) || !Array.isArray(s.enemies) || s.allies.length > 6 || s.enemies.length > 6)
      return false;
    const ids = /* @__PURE__ */ new Set();
    for (const [list, ally] of [
      [s.allies, true],
      [s.enemies, false]
    ])
      for (const u of list) {
        if (!u || typeof u !== "object" || typeof u.uid !== "string" || !new RegExp(ally ? "^a[1-9][0-9]*$" : "^e[1-9][0-9]*$").test(u.uid) || ids.has(u.uid) || Number(u.uid.slice(1)) >= s.nextUid)
          return false;
        ids.add(u.uid);
        const def = ally ? CARDS[u.cardId] : ENEMIES[u.cardId];
        if (!Object.hasOwn(ally ? CARDS : ENEMIES, u.cardId) || !def || ally && CARDS[u.cardId].type !== "summon" || typeof u.name !== "string" || u.name.length > 100 || typeof u.species !== "string" || u.species !== def.species || typeof u.color !== "string" || !/^#[\da-fA-F]{6}$/.test(u.color) || !integer(u.hp, 1, 1e3) || !integer(u.maxHp, 1, 1e3) || u.hp > u.maxHp || !integer(u.attack, 0, 1e4) || !integer(u.block) || typeof u.acted !== "boolean")
          return false;
        if (u.passive !== def.passive) return false;
        if (!ally && (s.phase === "battle" || s.phase === "defeat")) {
          const i = u.intent;
          if (!i || !integer(i.damage, 0, 1e4) || typeof i.target !== "string" || !(i.target === "hunter" || i.target === "all" || i.target === u.uid || /^a[1-9][0-9]*$/.test(i.target)) || typeof i.label !== "string" || i.label.length > 100 || i.summon !== void 0 && (!strings(
            i.summon,
            u.cardId === "cantor" ? 2 : u.cardId === "acolyte" ? 1 : 0
          ) || i.summon.some((id) => id !== "thrall") || i.damage !== 0))
            return false;
        }
      }
    if (s.phase === "battle" || s.phase === "defeat") {
      if (s.phase === "battle" && (s.hp === 0 || s.enemies.length === 0) || s.phase === "defeat" && s.hp !== 0 || s.turn < 1 || s.floor < 1 || s.route.length !== 1 || !["battle", "elite", "boss"].includes(s.route[0]))
        return false;
      const actual = count([
        ...s.draw,
        ...s.discard,
        ...s.hand,
        ...s.allies.map((a) => a.cardId)
      ]), expected = count(s.deck);
      if (Object.keys(actual).length !== Object.keys(expected).length || Object.keys(expected).some((id) => actual[id] !== expected[id]))
        return false;
    } else if (s.allies.length || s.enemies.length || s.hand.length || s.draw.length || s.discard.length || s.hp === 0)
      return false;
    if (s.phase === "map" && s.floor >= 10) return false;
    if (s.phase === "map" && JSON.stringify(s.route) !== JSON.stringify(ROUTES[s.floor] ?? []))
      return false;
    if (s.phase === "victory" && (s.floor !== 10 || s.route.length))
      return false;
    if (["battle", "defeat", "reward", "camp", "shop", "event"].includes(
      s.phase
    ) && (s.route.length !== 1 || !ROUTES[s.floor - 1]?.includes(s.route[0])))
      return false;
    if (s.phase === "reward" && (s.rewards.length !== 3 || s.floor < 1 || s.floor >= 10 || s.route.length !== 1 || !["battle", "elite"].includes(s.route[0])))
      return false;
    if (["camp", "shop", "event"].includes(s.phase) && (s.floor < 1 || s.floor >= 10 || s.route.length !== 1))
      return false;
    if (s.phase === "camp" && s.route[0] !== "camp" || s.phase === "shop" && s.route[0] !== "shop" || s.phase === "event" && s.route[0] !== "event")
      return false;
    return true;
  } catch {
    return false;
  }
}

// scratch/shrine-thrall-visual-independent-v09-r1/review-r7.mts
var P = "/workspace/scratch/shrine-thrall-visual-independent-v09-r1";
var H = (s) => createHash("sha256").update(s).digest("hex");
var T = "/dev/shm/shrine-thrall-visual-independent-r7";
var LIMIT = 17179869184;
var RESERVE = 512 * 1024 * 1024;
var ALLOWANCE = 640 * 1024 * 1024;
var admission = [];
async function guard(stage, launch = false) {
  const current = Number(await fs.readFile("/sys/fs/cgroup/memory.current", "utf8")), events = await fs.readFile("/sys/fs/cgroup/memory.events", "utf8");
  admission.push({ stage, current, headroom: LIMIT - current, events });
  await fs.writeFile(T + "/MEMORY.json", JSON.stringify(admission, null, 2) + "\n");
  assert(LIMIT - current >= RESERVE + (launch ? ALLOWANCE : 0), "Measured memory headroom below conservative " + stage + " gate");
}
var browser;
var active;
var pendingRow;
var pendingPage;
var rows = [];
var profiles = [{ width: 1440, height: 900, kind: 1, mode: "reduced" }];
function battle(mode, kind) {
  const s = applyActionWithEvents(createGame(145307, 1, { engineKind: kind }), { type: "travel", choice: "battle" }).state;
  const ids = mode === "dense" ? ["cairnhound", "gravehound", "fenstalker", "fenraker", "briarcolossus", "ossuarycolossus"] : mode === "late" ? [] : ["cairnhound"];
  s.floor = 4;
  s.route = ["elite"];
  s.allies = ids.map((id) => {
    const c = CARDS[id];
    return { uid: "a" + s.nextUid++, cardId: id, name: c.name, species: c.species, hp: c.hp, maxHp: c.hp, attack: c.attack, color: c.color, passive: c.passive, block: 0, acted: false };
  });
  s.hand = ["scour", "sunder", "ironward", "survey", "scour"];
  s.deck = [...ids, ...s.hand];
  s.draw = [];
  s.discard = [];
  s.energy = 3;
  s.relics = ["moon-charm"];
  s.block = 0;
  const enemyIds = mode === "dense" ? ["thrall", "revenant", "acolyte", "thrall", "raider", "thrall"] : ["thrall"];
  s.enemies = enemyIds.map((id) => ({ uid: "e" + s.nextUid++, cardId: id, ...ENEMIES[id], maxHp: ENEMIES[id].hp, block: 0, acted: false, intent: { target: "hunter", damage: 0, label: "Independent merged diagnostic" } }));
  for (const e of s.enemies) if (e.cardId === "thrall") e.intent = { target: s.allies[0]?.uid ?? "hunter", damage: 1, label: "Independent merged Thrall claw" };
  if (mode === "kill") s.enemies[0].hp = 1;
  if (mode === "dense") s.enemies[0].hp = s.enemies[0].maxHp = 20;
  assert(validateState(s));
  return s;
}
function event(kind) {
  const s = { ...createGame(145307, 1, { engineKind: kind }), phase: "event", floor: 2, route: ["event"], hp: 64, gold: 30, relics: ["moon-charm"] };
  assert(validateState(s));
  return s;
}
try {
  await guard("pre-launch", true);
  browser = await chromium.launch({ executablePath: "/usr/bin/chromium", ignoreDefaultArgs: ["--disable-dev-shm-usage"], env: { ...process.env, TMPDIR: T + "/profiles", XDG_CACHE_HOME: T + "/cache" }, args: ["--no-sandbox"] });
  for (const profile of profiles) for (const variant of ["candidate"]) {
    await guard("pre-context-" + profile.mode + "-" + variant);
    active = { profile, variant };
    const reduced = profile.mode === "reduced", ctx = await browser.newContext({ viewport: { width: profile.width, height: profile.height }, deviceScaleFactor: 1, hasTouch: profile.width < 760, reducedMotion: reduced ? "reduce" : "no-preference" });
    await ctx.addInitScript({ content: `globalThis.__name=f=>f;localStorage.setItem('hollowpact.tutorial.v2','yes');localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion:${!reduced},mute:true,volume:0}));let n=0;const callbacks=new Map();window.__clock=1000;window.__draws=[];performance.now=()=>window.__clock;requestAnimationFrame=f=>{callbacks.set(++n,f);return n};cancelAnimationFrame=id=>callbacks.delete(id);window.__step=ms=>{while(ms>0){const dt=Math.min(ms,10);ms-=dt;window.__clock+=dt;const work=[...callbacks.values()];callbacks.clear();work.forEach(f=>f(window.__clock))}};const original=CanvasRenderingContext2D.prototype.drawImage;CanvasRenderingContext2D.prototype.drawImage=function(...args){const img=args[0];if(this.canvas.id==='arena'&&img instanceof HTMLImageElement&&/bone-thrall|hunter-marek/.test(img.src)){const m=this.getTransform();window.__draws.push({at:performance.now(),url:img.src.split('/').pop(),canvas:[this.canvas.width,this.canvas.height],css:[this.canvas.clientWidth,this.canvas.clientHeight],source:args.slice(1,5),dest:args.slice(5),matrix:{a:m.a,b:m.b,c:m.c,d:m.d,e:m.e,f:m.f},alpha:this.globalAlpha})}return original.apply(this,args)};` });
    let release, released = variant === "baseline" || profile.mode !== "late";
    const gate = new Promise((r) => release = r);
    if (!released) await ctx.route("**/bone-thrall-poses-v09-r2.png", async (r) => {
      await gate;
      await r.continue();
    });
    const page = await ctx.newPage(), row = { ...active, epochs: [], actions: [], reloads: 0, captures: [], errors: [], failures: [] };
    pendingRow = row;
    pendingPage = page;
    page.on("pageerror", (e) => row.errors.push(e.message));
    page.on("requestfailed", (r) => row.failures.push({ url: r.url(), failure: r.failure() }));
    await page.goto("http://127.0.0.1:" + (variant === "candidate" ? 4670 : 4632));
    let current, epoch;
    async function load(state, label) {
      current = state;
      epoch = { label, initial: state, steps: [] };
      row.epochs.push(epoch);
      await page.evaluate((s) => localStorage.setItem("hollowpact.run.v2", s), JSON.stringify(state));
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator("[data-ui=resume]").click();
      await page.waitForTimeout(100);
      await page.evaluate(() => window.__step(1210));
      await page.waitForTimeout(20);
    }
    async function snap(label) {
      const data = await page.evaluate(() => {
        const box = (e) => {
          const r = e.getBoundingClientRect();
          return { x: r.x + scrollX, y: r.y + scrollY, right: r.right + scrollX, bottom: r.bottom + scrollY, width: r.width, height: r.height };
        };
        const text = (e) => {
          const range = document.createRange();
          range.selectNodeContents(e);
          const s = getComputedStyle(e);
          return { value: e.textContent, font: s.font, color: s.color, box: box(e), glyphs: [...range.getClientRects()].filter((r) => r.width > 0 && r.height > 0).map((r) => ({ x: r.x + scrollX, y: r.y + scrollY, right: r.right + scrollX, bottom: r.bottom + scrollY })), scrollWidth: e.scrollWidth, clientWidth: e.clientWidth };
        };
        const canvas = document.querySelector("#arena");
        return { at: window.__clock, save: localStorage.getItem("hollowpact.run.v2"), body: { width: innerWidth, scrollWidth: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight }, canvas: { pixels: [canvas.width, canvas.height], css: [canvas.clientWidth, canvas.clientHeight], box: box(canvas) }, draws: window.__draws.filter((x) => x.at === window.__clock), notice: text(document.querySelector(".arena-art-status")), held: document.querySelector("#app")?.classList.contains("settling-combat"), units: [...document.querySelectorAll(".unit[data-unit]")].map((e) => ({ label: e.getAttribute("aria-label"), text: e.textContent, box: box(e), status: e.querySelector(".unit-status")?.textContent, bar: e.querySelector(".health-track i")?.style.width, disabled: e.disabled, portrait: e.querySelector(".portrait")?.getAttribute("style") })), hand: [...document.querySelectorAll(".hand-cards .game-card")].map((e) => ({ box: box(e), nodes: [...e.querySelectorAll(".card-name,.card-description,.card-stats,.card-kind,.card-cost")].map(text) })), choices: [...document.querySelectorAll("[data-choice]")].map((e) => ({ id: e.dataset.choice, disabled: e.disabled, box: box(e), opacity: getComputedStyle(e).opacity, background: getComputedStyle(e).backgroundColor, nodes: [...e.querySelectorAll("h2,p,span")].map(text) })), enabled: [...document.querySelectorAll("#scene-ui button,#dock button")].filter((e) => !e.disabled).map((e) => e.textContent) };
      });
      assert.equal(data.save, JSON.stringify(current));
      assert(data.body.scrollWidth <= profile.width);
      delete data.save;
      epoch.steps.push({ label, ...data, saveSHA: H(JSON.stringify(current)) });
      return data;
    }
    async function capture(label, arena = false) {
      if (variant !== "candidate") return;
      const target = arena ? page.locator("#arena") : profile.mode === "dense" && label === "owned-shrine" ? page.locator("[data-choice=offering]") : page.locator("#arena");
      if (label.includes("shrine")) await page.locator("[data-choice=" + (profile.mode === "dense" ? "offering" : "bargain") + "]").scrollIntoViewIfNeeded();
      else await target.scrollIntoViewIfNeeded();
      const name = "r7-" + profile.mode + "-" + profile.width + "x" + profile.height + "-" + label + ".jpg";
      if (arena) await page.locator("#arena").screenshot({ path: T + "/" + name, type: "jpeg", quality: 67 });
      else await page.screenshot({ path: T + "/" + name, type: "jpeg", quality: 60 });
      row.captures.push(name);
    }
    async function act(a, label) {
      assert(legalActions(current).some((x) => JSON.stringify(x) === JSON.stringify(a)));
      const before = current, expected = applyActionWithEvents(current, a);
      if (a.type === "endTurn") {
        await page.locator("[data-action=endTurn]").click();
        if (await page.locator("[data-ui=confirm-end]").count()) await page.locator("[data-ui=confirm-end]").click();
      } else if (a.type === "attack") {
        await page.locator(".unit[data-unit=" + a.unit + "]").click();
        await page.locator(".valid-target[data-unit=" + a.target + "]").click();
      } else if (a.type === "play") {
        await page.locator('[data-ui=play-card][data-index="' + a.index + '"]').click();
        await page.locator(".valid-target[data-unit=" + a.target + "]").click();
      } else {
        const button = page.locator("[data-choice=" + a.choice + "]");
        await button.scrollIntoViewIfNeeded();
        await button.focus();
        if (profile.width < 760) await button.tap();
        else await page.keyboard.press("Enter");
      }
      current = expected.state;
      assert(validateState(current));
      assert.equal(await page.evaluate(() => localStorage.getItem("hollowpact.run.v2")), JSON.stringify(current));
      row.actions.push({ epoch: epoch.label, label, action: a, before, expected });
      await snap(label + "-0");
      if (a.type === "event") return;
      let prior = 0;
      for (const age of [70, 140, 220, 240, 280, 370, 700, 1500]) {
        if (age === 220 && profile.mode === "late" && !released) {
          released = true;
          release();
          await page.waitForTimeout(100);
        }
        await page.evaluate((dt) => window.__step(dt), age - prior);
        prior = age;
        const x = await snap(label + "-" + age);
        if (variant === "candidate" && (profile.mode === "dense" && (label === "strike" && age === 240 || label === "reaction" && age === 280) || profile.mode === "late" && age === 240 || profile.mode === "kill" && age === 280)) {
          if (profile.mode === "kill") {
            assert(x.held);
            assert.deepEqual(x.enabled, []);
            assert(x.units.some((u) => u.bar === "0%" && u.status === "Quarry down"));
          }
          await capture(label + "-" + age, profile.mode === "late");
        }
      }
      epoch.drawEpoch = await page.evaluate(() => window.__draws);
      await page.waitForTimeout(30);
    }
    async function reload() {
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator("[data-ui=resume]").click();
      assert.equal(await page.evaluate(() => localStorage.getItem("hollowpact.run.v2")), JSON.stringify(current));
      row.reloads++;
    }
    await load(battle(profile.mode, profile.kind), "battle-" + profile.mode);
    const initial = await snap("initial");
    await page.locator(".enemy-roster [data-ui=inspect-unit]").last().click();
    row.dossier = await page.locator("dialog[open]").evaluate((e) => ({ text: e.innerText, font: getComputedStyle(e).font, portrait: e.querySelector(".portrait")?.getAttribute("style") }));
    assert(row.dossier.text.includes("Bone Thrall"));
    assert(row.dossier.portrait.includes("bone-thrall-v09-r1.png"));
    await page.getByRole("button", { name: "Close dialog", exact: true }).click();
    if (profile.mode === "dense") await act({ type: "play", index: 0, target: current.enemies[0].uid }, "reaction");
    await act(profile.mode === "kill" ? { type: "attack", unit: current.allies[0].uid, target: current.enemies[0].uid } : { type: "endTurn" }, "strike");
    await reload();
    if (profile.mode === "reduced") {
      if (variant === "candidate") await ctx.route("**/bone-thrall-poses-v09-r2.png", (r) => r.abort("failed"));
      await load(battle("reduced", profile.kind), "failed-sheet-reduced");
      const x = await snap("original-fallback");
      if (variant === "candidate") {
        assert(x.notice.value?.includes("Some artwork is missing"));
        const painted = await page.evaluate(() => window.__draws);
        epoch.fallbackLastPaintSamples = painted;
        assert(painted.some((d) => d.url === "bone-thrall-v09-r1.png" && d.canvas[0] === x.canvas.pixels[0] && d.canvas[1] === x.canvas.pixels[1]));
        assert(!painted.some((d) => d.url === "bone-thrall-poses-v09-r2.png"));
        await capture("original-fallback");
      }
      await act({ type: "endTurn" }, "fallback-strike");
      await reload();
    }
    await load(event(profile.kind), "shrine-owned-cap");
    const shrine = await snap("choices");
    assert(shrine.choices.find((x) => x.id === "offering")?.disabled);
    assert(shrine.choices.find((x) => x.id === "offering")?.nodes.at(-1)?.value === "Wraithglass Shard already owned");
    assert(shrine.choices.find((x) => x.id === "bargain")?.nodes.at(-1)?.value === "30 \u2192 0 gold \xB7 +1 health");
    for (const card of shrine.choices) for (const n of card.nodes) {
      assert(n.scrollWidth <= n.clientWidth + 1);
      assert(n.glyphs.every((g) => g.x >= card.box.x - 1 && g.y >= card.box.y - 1 && g.right <= card.box.right + 1 && g.bottom <= card.box.bottom + 1));
    }
    if (variant === "candidate" && profile.mode === "kill") await capture(profile.mode === "dense" ? "owned-shrine" : "capped-shrine");
    await act({ type: "event", choice: "bargain" }, "bargain");
    await reload();
    await page.locator("[data-ui=relic][data-relic=moon-charm]").click();
    row.relic = await page.locator("dialog[open]").evaluate((e) => ({ text: e.innerText, font: getComputedStyle(e).font }));
    assert(row.relic.text.includes(RELICS["moon-charm"].name));
    await page.getByRole("button", { name: "Return", exact: true }).click();
    assert.equal(await page.evaluate(() => document.activeElement.dataset.relic), "moon-charm");
    assert.deepEqual(row.errors, []);
    await ctx.close();
    rows.push(row);
    await fs.writeFile(T + "/r7-context-" + rows.length + ".json.gz", gzipSync(JSON.stringify(row), { level: 9 }), { flag: "wx" });
    pendingRow = null;
    pendingPage = null;
    console.log("PASS", variant, profile.mode, profile.width, profile.height, row.actions.length, row.reloads);
  }
  for (const b of rows.filter((r) => r.variant === "baseline")) {
    const c = rows.find((r) => r.variant === "candidate" && r.profile.mode === b.profile.mode);
    assert.deepEqual(b.actions, c.actions);
    assert.deepEqual(b.dossier, c.dossier);
    assert.deepEqual(b.relic, c.relic);
  }
  await fs.writeFile(P + "/RESULT-r7.json", JSON.stringify({ contexts: rows.length, actualPairs: 0, unpairedContext: "reduced candidate compared separately to retained R5 reduced baseline", fixtureEpochs: rows.reduce((n, r) => n + r.epochs.length, 0), actions: rows.reduce((n, r) => n + r.actions.length, 0), reloads: rows.reduce((n, r) => n + r.reloads, 0), captures: rows.flatMap((r) => r.captures), pageErrors: rows.flatMap((r) => r.errors) }, null, 2) + "\n", { flag: "wx" });
} catch (e) {
  if (pendingPage) try {
    pendingRow.partialDraws = await pendingPage.evaluate(() => window.__draws);
  } catch {
  }
  await fs.writeFile(T + "/FAILURE-PARTIAL-r7.json.gz", gzipSync(JSON.stringify({ pendingRow, completedRows: rows }), { level: 9 }), { flag: "wx" });
  await fs.writeFile(P + "/FAILURE-r7.json", JSON.stringify({ active, completed: rows.length, error: e.stack }, null, 2) + "\n", { flag: "wx" });
  throw e;
} finally {
  await browser?.close();
  await guard("post-browser-closed");
}
