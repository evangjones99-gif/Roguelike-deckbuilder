import pathlib,json,gzip,math,hashlib
from PIL import Image
P=pathlib.Path('/workspace/scratch/shrine-thrall-visual-independent-v09-r1');rows=[]
for globroot,pattern in [(P,'r2-context-*.json.gz'),(pathlib.Path('/dev/shm/shrine-thrall-visual-independent-r4'),'r4-context-*.json.gz'),(pathlib.Path('/dev/shm/shrine-thrall-visual-independent-r5'),'r5-context-*.json.gz'),(pathlib.Path('/dev/shm/shrine-thrall-visual-independent-r7'),'r7-context-*.json.gz')]:
 for f in sorted(globroot.glob(pattern)):rows.append(json.loads(gzip.decompress(f.read_bytes())))
assert len(rows)==8
translations=[]
def close(a,b,epsilon=.002):
 if isinstance(a,(int,float))and isinstance(b,(int,float)):return abs(a-b)<=epsilon
 if isinstance(a,dict)and isinstance(b,dict):return a.keys()==b.keys()and all(close(a[k],b[k],epsilon)for k in a)
 if isinstance(a,list)and isinstance(b,list):return len(a)==len(b)and all(close(x,y,epsilon)for x,y in zip(a,b))
 return a==b
def intrinsic(card):
 c=json.loads(json.dumps(card));ox,oy=c['box']['x'],c['box']['y'];
 for n in c['nodes']:
  for box in [n['box']]+n['glyphs']:
   for k in ['x','right']:box[k]-=ox
   for k in ['y','bottom']:box[k]-=oy
 for k in ['x','right']:c['box'][k]-=ox
 for k in ['y','bottom']:c['box'][k]-=oy
 return c
hulls=json.loads((P/'SOURCE-HULLS.json').read_text())['rows'];records=[];pairs=[];handbounds=[];drawcounts={};epochcount=0
for b in [r for r in rows if r['variant']=='baseline']:
 c=next(r for r in rows if r['variant']=='candidate'and r['profile']==b['profile']);assert b['actions']==c['actions'] and b['dossier']==c['dossier'] and b['relic']==c['relic'];same=0;faultdiff=[]
 for be,ce in zip(b['epochs'],c['epochs']):
  assert be['label']==ce['label'] and be['initial']==ce['initial']
  for bs,cs in zip(be['steps'],ce['steps']):
   assert bs['label']==cs['label']
   for key in ['saveSHA','body','canvas','held','hand','choices','units','enabled']:
    if be['label']=='failed-sheet-reduced'and key in ['body','canvas','hand','units','enabled']:
     if bs[key]!=cs[key]:faultdiff.append({'sample':bs['label'],'field':key})
    elif key in ['hand','choices']:
     assert len(bs[key])==len(cs[key])
     for bc,cc in zip(bs[key],cs[key]):
      assert close(intrinsic(bc),intrinsic(cc)),(b['profile'],be['label'],bs['label'],key,'intrinsic')
      assert abs(bc['box']['x']-cc['box']['x'])<=.002
      dy=cc['box']['y']-bc['box']['y'];assert abs(dy)<=3.002
      if abs(dy)>.002:translations.append({'mode':b['profile']['mode'],'sample':bs['label'],'field':key,'dy':dy})
    else:assert bs[key]==cs[key],(b['profile'],be['label'],bs['label'],key)
   same+=1
 pairs.append({'profile':b['profile'],'exactCanonicalActions':len(b['actions']),'exactPairedPresentationSamples':same,'dossierAndRelicExact':True,'candidateOnlyFaultPresentationDifferences':faultdiff})
def transform(d,xy):
 sx,sy,sw,sh=d['source'];dx,dy,dw,dh=d['dest'];m=d['matrix'];x=dx+(xy[0]-sx)/sw*dw;y=dy+(xy[1]-sy)/sh*dh;return[m['a']*x+m['c']*y+m['e'],m['b']*x+m['d']*y+m['f']]
for row in rows:
 epochcount+=len(row['epochs'])
 for e in row['epochs']:
  for snap in e['steps']:
   for card in snap['hand']:
    for n in card['nodes']:
     for glyph in n['glyphs']:
      over=max(0,card['box']['x']-glyph['x'],card['box']['y']-glyph['y'],glyph['right']-card['box']['right'],glyph['bottom']-card['box']['bottom']);handbounds.append(over)
  if row['variant']!='candidate':continue
  draws=e.get('drawEpoch',[]);drawcounts[e['label']]=drawcounts.get(e['label'],0)+len(draws)
  for d in draws:
   if d['url']!='bone-thrall-poses-v09-r2.png':continue
   h=next(h for h in hulls if abs(h['rect'][0]-d['source'][0])<.01 and abs(h['rect'][1]-d['source'][1])<.01);ps=[transform(d,xy)for xy in h['hullAlpha8']];xs=[x[0]for x in ps];ys=[x[1]for x in ps];over=max(0,-min(xs),-min(ys),max(xs)-d['canvas'][0],max(ys)-d['canvas'][1]);ground=transform(d,h['plantarPlane']);m=d['matrix'];error=math.dist(ground,[m['e'],m['f']]);dx,dy,dw,dh=d['dest'];sx,sy,sw,sh=d['source'];records.append({'mode':row['profile']['mode'],'pose':h['pose'],'overshoot':over,'groundAnchorArithmeticError':error,'sourceAxisScaleError':abs(dw/sw-dh/sh),'pixelScale':dw/sw,'canvas':d['canvas'],'alpha':d['alpha']})
assert max(r['overshoot']for r in records)<.001;assert max(r['sourceAxisScaleError']for r in records)<1e-10
late=next(r for r in rows if r['variant']=='candidate'and r['profile']['mode']=='late');steps=late['epochs'][0]['steps'];at=next(s for s in steps if s['label']=='strike-240');thrall=next(d for d in at['draws']if d['url']=='bone-thrall-poses-v09-r2.png');hunter=next(d for d in at['draws']if d['url'].startswith('hunter-'));tip=transform(thrall,[1513,209]);m=hunter['matrix'];det=m['a']*m['d']-m['b']*m['c'];x=tip[0]-m['e'];y=tip[1]-m['f'];lx=(m['d']*x-m['c']*y)/det;ly=(-m['b']*x+m['a']*y)/det;sx,sy,sw,sh=hunter['source'];dx,dy,dw,dh=hunter['dest'];source=[sx+(lx-dx)*sw/dw,sy+(ly-dy)*sh/dh];root=pathlib.Path('/dev/shm/hollowpact-shrine-thrall-v09-root-r1/public/art');im=Image.open(root/hunter['url']);rgba=im.getpixel(tuple(math.floor(x)for x in source));claw=Image.open(root/'bone-thrall-poses-v09-r2.png').getpixel((1513,209));draws=late['epochs'][0]['drawEpoch'];handoff={'oldPortraitDrawsBeforeAtlas':sum(d['url']=='bone-thrall-v09-r1.png' and d['at']<at['at']-20 for d in draws),'originalDrawsTotal':sum(d['url']=='bone-thrall-v09-r1.png'for d in draws),'atlasDraws':sum(d['url']=='bone-thrall-poses-v09-r2.png'for d in draws)}
result={'contexts':len(rows),'preservedExactGeometryRefusal':'PAIRED-COMPARISON-FIRST-REFUSAL.json','uniformCardTranslations':translations,'pairs':pairs,'fixtureEpochs':epochcount,'actualActions':sum(len(r['actions'])for r in rows),'successfulReloads':sum(r['reloads']for r in rows),'sameDrawHullSamples':len(records),'poses':sorted(set(r['pose']for r in records)),'maximumPaintedHullOvershootPx':max(r['overshoot']for r in records),'maximumGroundAnchorArithmeticErrorPx':max(r['groundAnchorArithmeticError']for r in records),'maximumSourceAxisScaleError':max(r['sourceAxisScaleError']for r in records),'actualCanvasSizes':sorted(set(tuple(r['canvas'])for r in records)),'handTextGlyphBounds':{'observations':len(handbounds),'maximumOvershootPx':max(handbounds),'scope':'Only actual five tool cards in diagnostic epochs; not entire card catalogue'},'hunterContact':{'tipActualCanvas':tip,'inverseHunterSource':source,'hunterPixelRGBA':rgba,'clawSourceRGBA':claw,'scope':'One actual late390x900 strike240; painted forearm overlap, not torso-center or all frames'},'delayedAtlas':handoff,'deathToIdleCropHeightRatio':222/452,'drawCounts':drawcounts}
(P/'ANALYSIS.json').write_text(json.dumps(result,indent=2)+'\n');pathlib.Path('/dev/shm/shrine-thrall-visual-independent-r7/GEOMETRY.json.gz').write_bytes(gzip.compress(json.dumps(records).encode(),compresslevel=9));print(json.dumps(result,indent=2))
