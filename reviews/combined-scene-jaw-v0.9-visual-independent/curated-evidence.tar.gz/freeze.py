import pathlib,json,hashlib
p=pathlib.Path('/workspace/scratch/combined-scene-jaw-visual-independent-v09-r1');records={}
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='FROZEN-FILES.json':
  assert not f.is_symlink();b=f.read_bytes();records[f.relative_to(p).as_posix()]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
size=sum(x['bytes']for x in records.values());assert size<10*1024*1024
obj={'scope':'Fresh independent exact efef combined visual browser gate, 23477 retained baseline; all own browsers and baseline server closed. Every own failure and selected source copy preserved. Original art external and unchanged, full source/HTTP ledgers retained. No root writes or native/hardware/humanfun qualification.','regularFiles':len(records),'regularBytes':size,'files':records}
(p/'FROZEN-FILES.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({'files':len(records),'bytes':size,'reviewSHA256':records['REVIEW.md']['sha256'],'manifestSHA256':hashlib.sha256((p/'FROZEN-FILES.json').read_bytes()).hexdigest()}))
