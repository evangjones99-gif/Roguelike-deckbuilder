import pathlib,json,gzip,hashlib
P=pathlib.Path('/workspace/scratch/combined-scene-jaw-visual-independent-v09-r1')
j=json.loads(gzip.decompress((P/'results.json.gz').read_bytes()))['rows'];s=json.loads(gzip.decompress((P/'SCENE-FAILURE.json.gz').read_bytes()))['rows']
comparisons=[]
for c in j:
 if c['variant']!='candidate' or c['natural']:continue
 b=next(x for x in j if x['variant']=='baseline' and x['mode']==c['mode'] and x['vp']==c['vp'] and x['natural']==c['natural'])
 for f in c['frames']:
  bf=next(x for x in b['frames'] if x['label']==f['label']);eq=f['pngSHA256']==bf['pngSHA256'];comparisons.append({'mode':c['mode'],'viewport':c['vp'],'age':f['label'],'PNGByteEqual':eq})
  if c['mode'] in ['reduced','death'] or f['label'] in ['idle','140','370','500','1500']:assert eq,(c['mode'],f['label'])
# The resize200 observation precedes asynchronous viewport layout, so no false equality guarantee is imposed for its active samples.
for c in s:
 assert not c['errors']
for r in j:assert not r['errors']
out={'jawContexts':len(j),'jawActions':len(j),'sceneR1ClosedContexts':len(s),'sceneR1Actions':sum(sum('action'in st for st in r['steps'])for r in s),'sceneR1Reloads':sum(sum(st.get('stage')=='after-reload' for st in r['steps'])for r in s),'controlledCanvasComparisons':comparisons,'equalComparisons':sum(x['PNGByteEqual']for x in comparisons),'changedComparisons':sum(not x['PNGByteEqual']for x in comparisons),'expectedCryptRequestFailures':[{'name':x['variant']+'-'+x['name'],'URLs':x['failed']}for x in s if x['failed']]}
(P/'ANALYSIS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['controlledCanvasComparisons','expectedCryptRequestFailures']}))
