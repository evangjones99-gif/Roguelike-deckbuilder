from pathlib import Path
p=Path('/workspace/scratch/combined-scene-jaw-visual-independent-v09-r1')
s=(p/'scene-review.mts').read_text()
a=s.index('try{\nfor(const vp');b=s.index('const raw=Buffer.from',a)
body="""try{
for(const baseline of[false,true]){const h=await open('boss-victory-fixed',oneHit(entered(1,10,'boss')),{width:1440,height:900},baseline,{motion:true});await h.resume();await h.act({type:'play',index:0,target:h.current().enemies[0].uid});assert.equal(h.current().phase,'victory');await h.page.waitForTimeout(1600);await h.read('settled-victory');await h.capture('settled-victory');await h.home();await h.page.reload({waitUntil:'load'});await h.read('terminal-reload-title');assert.equal(await h.page.locator('[data-ui=resume]').count(),0);await h.capture('terminal-reload-title');await h.close()}
"""
s=s[:a]+body+s[b:]
s=s.replace("O+'/scene-checkpoint.json'","O+'/scene-r2-checkpoint.json'").replace("O+'/scene-results.json.gz'","O+'/scene-r2-results.json.gz'").replace("O+'/SCENE-RESULTS-RECEIPT.json'","O+'/SCENE-R2-RESULTS-RECEIPT.json'").replace("O+'/SCENE-FAILURE.json.gz'","O+'/SCENE-R2-FAILURE.json.gz'")
(p/'scene-review-r2.mts').write_text(s)
