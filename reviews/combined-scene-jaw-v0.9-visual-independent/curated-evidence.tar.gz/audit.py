import hashlib,json, pathlib, urllib.request,sys
P=pathlib.Path('/workspace/scratch/combined-scene-jaw-visual-independent-v09-r1')
h=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for label,root,url,digest in [('baseline',pathlib.Path('/tmp/hollowpact-hound-jaw-v08-r1-baseline'),'http://127.0.0.1:4513/','23477f68c99d6d60b0b3f82b286a8d33bb6da6f2ca92c103fbecf5663634959f'),('candidate',pathlib.Path('/tmp/hollowpact-scene-jaw-v09-root-r1'),'http://127.0.0.1:4173/','efef7131d1c0cbb5cc0420c70e3d2afd9c9dfaf3013dfb8761e6bb8b00d3b525')]:
 prov=json.loads((root/'dist/build-provenance.json').read_text());assert prov['sourceDigest']==digest
 src={k:h((root/k).read_bytes()) for k in prov['hashes']};assert src==prov['hashes'];assert h(json.dumps(src,separators=(',',':'),ensure_ascii=False).encode())==digest
 outputs=[]
 for f in sorted((root/'dist').rglob('*')):
  if f.is_file():
   rel=f.relative_to(root/'dist').as_posix();b=f.read_bytes();r=urllib.request.urlopen(url+rel);remote=r.read();assert r.status==200 and remote==b
   outputs.append({'path':rel,'bytes':len(b),'sha256':h(b),'HTTPMatch':True})
 assert len(outputs)==55
 rows.append({'variant':label,'root':str(root),'url':url,'provenance':prov,'verifiedSources':len(src),'outputs':outputs})
(P/('AUDIT-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{'variant':x['variant'],'source':x['verifiedSources'],'HTTPOutputs':len(x['outputs'])} for x in rows]))
