import hashlib,json,pathlib,urllib.request
A=pathlib.Path('/workspace/scratch/hound-jaw-hinge-author-v08-r5');O=pathlib.Path('/workspace/scratch/hound-jaw-r5-independent-technical-v08-r1');H=lambda b:hashlib.sha256(b).hexdigest()
i=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());f=json.loads((A/'FROZEN-FILES.json').read_text());rows={};out={}
assert H((A/'FROZEN-FILES.json').read_bytes())=='6c3a80e75036ac1378e82c66a115eebd38806b1f4b36f61b5bf4b592ac5da94e'
for rel,r in f['files'].items():
 b=(A/rel).read_bytes();assert H(b)==r['sha256'] and len(b)==r['bytes'],rel
for v,port in [('baseline',4490),('candidate',4494)]:
 records=i['runtimeInputs'][v]; hashes={}
 for rel,r in records.items():
  b=pathlib.Path(r['input']).read_bytes();assert H(b)==r['sha256'] and len(b)==r['bytes'],rel;hashes[rel]=H(b)
 digest=H(json.dumps(hashes,separators=(',',':')).encode());assert digest==i[v+'Digest'];rows[v]={'digest':digest,'files':hashes}
 for rel,r in i['outputs'][v].items():
  b=urllib.request.urlopen(f'http://127.0.0.1:{port}/{rel}').read();assert H(b)==r['sha256'] and len(b)==r['bytes'],(v,rel)
 out[v]=i['outputs'][v]
b,c=rows['baseline']['files'],rows['candidate']['files'];changed=[k for k in b if b[k]!=c.get(k)];added=[k for k in c if k not in b];assert changed==['src/arena.ts'] and added==['src/hound-jaw.ts'];assert sum(b[k]==c.get(k) for k in b)==75
(O/'source-intake.json').write_text(json.dumps({'scope':'Own readback of every declared author input/output and all frozen files; HTTP body hashes actual; no author test reused','authorFrozenSHA256':H((A/'FROZEN-FILES.json').read_bytes()),'authorFrozenFiles':len(f['files']),'sources':rows,'outputs':out,'changed':changed,'added':added,'unchanged':75},indent=2)+'\n')
print(json.dumps({'sourceInputs':[len(b),len(c)],'outputs':[len(out['baseline']),len(out['candidate'])],'authorFrozen':len(f['files']),'changed':changed,'added':added}))
