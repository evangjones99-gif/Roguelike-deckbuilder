import gzip,json,pathlib
O=pathlib.Path('/workspace/scratch/hound-jaw-r5-independent-technical-v08-r1');rows=json.loads(gzip.decompress((O/'browser-results-r4.json.gz').read_bytes()))['rows'];pairs=[]
for b in rows[::2]:
 c=next(r for r in rows if r['variant']=='candidate' and r['mode']==b['mode']);assert b['initial']==c['initial'] and b['expected']==c['expected'] and b['reloadCanonical']==c['reloadCanonical'];assert b['errors']==c['errors']==[]
 same=[x['age'] for x,y in zip(b['frames'],c['frames']) if x['pngSHA256']==y['pngSHA256']];different=[x['age'] for x,y in zip(b['frames'],c['frames']) if x['pngSHA256']!=y['pngSHA256']]
 if b['mode'] in ['reaction','death','reduced','missing','canvasfault','cancel']:assert not different,(b['mode'],different)
 pairs.append({'mode':b['mode'],'canonicalResultsExact':True,'reloadBytesExact':True,'framesPixelSHAIdentical':same,'framesPixelSHADifferent':different,'heldParity':all(x['held']==y['held'] for x,y in zip(b['frames'],c['frames']))})
assert all(p['heldParity'] for p in pairs)
(O/'control-pairs.json').write_text(json.dumps({'pairs':pairs,'contexts':len(rows),'actions':len(rows),'reloads':len(rows)},indent=2)+'\n');print(json.dumps(pairs,indent=2))
