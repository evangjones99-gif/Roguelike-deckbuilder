import gzip,json,pathlib,statistics,math
O=pathlib.Path('/workspace/scratch/hound-jaw-r5-independent-technical-v08-r1');perf=json.loads(gzip.decompress((O/'performance-results-r3.json.gz').read_bytes()))['rows'];controls=json.loads(gzip.decompress((O/'browser-results-r4.json.gz').read_bytes()))['rows'];pairs=[];contact=[]
def projected(d):
 sx,sy,sw,sh,dx,dy,dw,dh=d['args'];a,b,c,e,x,y=d['matrix'];lx=dx+(1024+432-sx)*dw/sw;ly=dy+(255-sy)*dh/sh;return[a*lx+c*ly+x,b*lx+e*ly+y]
def upperBase(f):
 if not f['draws']:return None
 at=f['draws'][-1]['at'];draws=[d for d in f['draws'] if d['at']==at and d['args'][0] in [1056,1024] and d['args'][1] in [96,0]]
 return draws[0] if draws else None
for group in [perf,controls]:
 for b in [r for r in group if r['variant']=='baseline']:
  c=next(r for r in group if r['variant']=='candidate' and r['mode']==b['mode'] and r['vp']==b['vp'] and r['occupancy']==b['occupancy'] and r.get('round')==b.get('round'))
  assert b['initial']==c['initial'] and b['expected']==c['expected'] and b['reloadCanonical']==c['reloadCanonical'];assert b['errors']==c['errors']==[]
  for bf,cf in zip(b['frames'],c['frames']):
   assert bf['canonical']==cf['canonical'] and bf['held']==cf['held']
   bd,cd=upperBase(bf),upperBase(cf)
   if bd and cd:
    bp,cp=projected(bd),projected(cd);err=math.dist(bp,cp);assert err<.001,(b['mode'],bf['age'],bp,cp)
    contact.append({'mode':b['mode'],'width':b['vp']['width'],'occupancy':b['occupancy'],'round':b.get('round'),'age':bf['age'],'baselineUpperNose':bp,'candidateUpperNose':cp,'errorPx':err})
for width in [1920,390]:
 for n in [1,6]:
  selectedB=[];selectedC=[];allB=[];allC=[];details=[]
  for rnd in [0,1]:
   b=next(r for r in perf if r['variant']=='baseline' and r['vp']['width']==width and r['occupancy']==n and r['round']==rnd);c=next(r for r in perf if r['variant']=='candidate' and r['vp']['width']==width and r['occupancy']==n and r['round']==rnd)
   for bp,cp in zip(b['performance'],c['performance']):
    assert bp['age']==cp['age'];bs=[x['wallMs']/100 for x in bp['batches'] if x['callbackCount']==100];cs=[x['wallMs']/100 for x in cp['batches'] if x['callbackCount']==100];count=min(len(bs),len(cs));assert count>=4
    selectedB+=bs[:count];selectedC+=cs[:count];allB += [x['wallMs']/100 for x in bp['batches']];allC += [x['wallMs']/100 for x in cp['batches']];details.append({'round':rnd,'age':bp['age'],'baselineExact100':len(bs),'candidateExact100':len(cs),'matchedCountPerVariant':count,'baselineMedian':statistics.median(bs[:count]),'candidateMedian':statistics.median(cs[:count])})
  p95=lambda arr:sorted(arr)[math.ceil(.95*len(arr))-1]
  pairs.append({'width':width,'occupancyPerSide':n,'matchedBatchesPerVariant':len(selectedB),'frameCyclesPerVariant':100*len(selectedB),'baselineMedianBatchMeanMs':statistics.median(selectedB),'candidateMedianBatchMeanMs':statistics.median(selectedC),'baselineP95BatchMeanMs':p95(selectedB),'candidateP95BatchMeanMs':p95(selectedC),'baselineAllBatchMedianMs':statistics.median(allB),'candidateAllBatchMedianMs':statistics.median(allC),'ageRoundDetails':details})
result={'scope':'Wall time of actual aggregate RAF callbacks submitted to Canvas at fixed real production animation ages, not GPU finish/display FPS or per-frame percentiles. 30 warmup cycles then eight100-cycle batches per age. Exact100-callback batches matched by age/round and equal sample count; auxiliary-callback batches retained with all-in medians. Shared headless host, reverse-order rounds; trace allocations disabled inside measured batches. No source edit.','contexts':len(perf),'canonicalActions':len(perf),'reloads':len(perf),'totalMeasuredFrameCycles':len(perf)*6*8*100,'totalBatches':len(perf)*6*8,'pairs':pairs,'basePaintNoseChecks':len(contact),'maxUpperNoseErrorPx':max(x['errorPx'] for x in contact),'contact':contact}
(O/'independent-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='contact'},indent=2))
