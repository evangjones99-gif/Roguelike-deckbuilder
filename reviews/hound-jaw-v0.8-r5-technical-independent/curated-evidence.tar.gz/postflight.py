import pathlib,json,hashlib,gzip
O=pathlib.Path('/workspace/scratch/hound-jaw-r5-independent-technical-v08-r1');A=pathlib.Path('/workspace/scratch/hound-jaw-hinge-author-v08-r5');P=pathlib.Path('/tmp/hollowpact-hound-jaw-r5-independent-tech-source');H=lambda b:hashlib.sha256(b).hexdigest();i=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());f=json.loads((A/'FROZEN-FILES.json').read_text());sources={}
for v in ['baseline','candidate']:
 h={}
 for rel,r in i['runtimeInputs'][v].items():
  b=pathlib.Path(r['input']).read_bytes();assert len(b)==r['bytes'] and H(b)==r['sha256'],(v,rel);h[rel]=H(b)
 digest=H(json.dumps(h,separators=(',',':')).encode());assert digest==i[v+'Digest'];sources[v]={'digest':digest,'files':len(h)}
for rel,r in f['files'].items():
 b=(A/rel).read_bytes();assert H(b)==r['sha256'] and len(b)==r['bytes'],rel
for rel,r in i['runtimeInputs']['candidate'].items():assert H((P/rel).read_bytes())==r['sha256'],rel
for rel,r in i['outputs']['candidate'].items():assert H((P/'dist'/rel).read_bytes())==r['sha256'],rel
receipts=[]
for name,receipt in [('browser-results-r4.json.gz','browser-receipt-r4.json'),('performance-results-r3.json.gz','performance-receipt-r3.json'),('kind2-results-r1.json.gz','kind2-receipt-r1.json')]:
 b=(O/name).read_bytes();raw=gzip.decompress(b);r=json.loads((O/receipt).read_text());assert H(raw)==r['decodedSHA256'] and H(b)==r['gzipSHA256'] and len(raw)==r['decodedBytes'];receipts.append({'gzip':name,**r})
kind2=json.loads(gzip.decompress((O/'kind2-results-r1.json.gz').read_bytes()))['rows'];pairs=[]
for b in kind2[::2]:
 c=next(r for r in kind2 if r['mode']==b['mode'] and r['variant']=='candidate');assert b['initial']['schema']==c['initial']['schema']==3 and b['initial']['engineKind']==2;assert b['initial']==c['initial'] and b['expected']==c['expected'] and b['reloadCanonical']==c['reloadCanonical'];assert b['errors']==c['errors']==[]
 pairs.append({'mode':b['mode'],'schema':3,'engineKind':2,'canonicalStateEventsExact':True,'reloadBytesExact':True,'heldParity':all(x['held']==y['held'] for x,y in zip(b['frames'],c['frames']))})
assert all(r['heldParity'] for r in pairs)
(O/'postflight.json').write_text(json.dumps({'authorFrozenSHA256':H((A/'FROZEN-FILES.json').read_bytes()),'authorFilesUnchanged':len(f['files']),'sourcesUnchanged':sources,'ownReconstructionInputsUnchanged':77,'ownRebuiltOutputsUnchanged':55,'receipts':receipts,'kind2Pairs':pairs,'browsers':'All own scripts await browser.close in finally; timing and kind2 child sessions exited0. No own hosts were launched.'},indent=2)+'\n');print({'authorFrozen':len(f['files']),'ownCases':sum(r['cases'] for r in receipts),'ownActions':sum(r['actions'] for r in receipts),'ownReloads':sum(r['reloads'] for r in receipts)})
