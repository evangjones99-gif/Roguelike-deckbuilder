import json,gzip,hashlib,collections
from pathlib import Path
p=Path('.');rows=[json.load(gzip.open(f))for f in sorted(p.glob('r2-profile-*.json.gz'))];assert len(rows)==8
catalogue=json.loads((p/'CATALOGUE.json').read_text());summary={'profiles':len(rows),'renderedStates':sum(len(r['states'])for r in rows),'acceptedActions':sum(len(r['actions'])for r in rows),'actionReloads':sum(len(r['actions'])for r in rows),'captures':sum(len(r['captures'])for r in rows),'candidateCardObservations':0,'baselineCardObservations':0,'candidatePrintedDefects':0,'baselinePrintedDefects':0,'candidateOverlapObservations':[],'coverage':{},'heightComparisons':[],'maximumHeights':{},'focusOutlines':sorted(set(a['focused']['outline']for r in rows for a in r['actions']))}
for r in rows:
 variant=r['variant'];key=f"{r['width']}x{r['height']}/{variant}"
 summary['maximumHeights'][key]={}
 for phase in ['reward','shop','deck']:
  states=[s for s in r['states']if s['label']==phase or s['label'].startswith(phase+'-')];seen=set(c['id']for s in states for c in s['snap']['cards']);assert seen==set(catalogue);summary['coverage'][key+'/'+phase]=sorted(seen)
 for s in r['states']:
  assert s['snap']['body'][0]==s['snap']['body'][1];summary[variant+'CardObservations']+=len(s['snap']['cards']);summary[variant+'PrintedDefects']+=len(s['defects'])
  phase=s['label'].split('-')[0];summary['maximumHeights'][key][phase]=max([summary['maximumHeights'][key].get(phase,0)]+[c['box'][3]for c in s['snap']['cards']])
  for c in s['snap']['cards']:
   previous=None
   for n in c['nodes']:
    if not n['glyphs']:continue
    bounds=[min(g[0]for g in n['glyphs']),min(g[1]for g in n['glyphs']),max(g[2]for g in n['glyphs']),max(g[3]for g in n['glyphs'])]
    if previous and previous[1][3]>bounds[1]+.5 and variant=='candidate':summary['candidateOverlapObservations'].append({'profile':key,'state':s['label'],'id':c['id'],'before':previous,'after':[n['part'],bounds]})
    previous=[n['part'],bounds]
for width,height in [(390,900),(1440,900),(390,720),(1440,720)]:
 a=next(r for r in rows if r['width']==width and r['height']==height and r['variant']=='baseline');b=next(r for r in rows if r['width']==width and r['height']==height and r['variant']=='candidate')
 for old,new in zip(a['states'],b['states']):
  assert old['label']==new['label']
  for ca,cb in zip(old['snap']['cards'],new['snap']['cards']):
   if ca['id']=='fenraker' or ca['id']=='emberwidow+':summary['heightComparisons'].append({'width':width,'height':height,'state':old['label'],'id':ca['id'],'old':ca['box'][3],'new':cb['box'][3]})
summary['sourceAuditExact']=json.loads((p/'AUDIT-before.json').read_text())==json.loads((p/'AUDIT-after.json').read_text());assert summary['sourceAuditExact'];assert not summary['candidateOverlapObservations'];assert summary['candidatePrintedDefects']==0
(p/'ANALYSIS.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in ['coverage','heightComparisons','maximumHeights']}))
