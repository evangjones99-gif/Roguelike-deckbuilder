from pathlib import Path
import json,gzip,collections
p=Path('/workspace/scratch/large-card-layout-author-v09-r1');a=Path.cwd();states=[]
for d in ['r2','r5','r6','short-height']:
 for f in (p/d).glob('case-*.json.gz'):states.append((str(f),json.load(gzip.open(f))))
keys=[(s['width'],720 if Path(f).parent.name=='short-height' else 900,s['variant'],s['phase'],s['batch'])for f,s in states]
uniqueCoverage={}
for f,s in states:
 k=str((s['width'],720 if Path(f).parent.name=='short-height' else 900,s['variant'],s['phase']));g=uniqueCoverage.setdefault(k,set());g.update(c['id']for c in s['before']['cards'])
r={'heightFieldMissingInRawRows':True,'heightInferredFromExactPreservedShortHarnessConstant':720,'states':len(states),'uniqueStatesWithDeclaredSourceHeight':len(set(keys)),'duplicatesWithDeclaredSourceHeight':[k for k,c in collections.Counter(keys).items()if c>1],'coverage':{k:sorted(v)for k,v in sorted(uniqueCoverage.items())},'erratum':'Earlier own AUTHOR-READBACK treated missing heights as900 and falsely duplicated116 short-height states; retained original. This additive correction does not edit author originals. First correction invocation also had Python else900 SyntaxError before writing any correction; current script uses spaced else 900. Product source unchanged.'};(a/'AUTHOR-READBACK-HEIGHT-ERRATUM.json').write_text(json.dumps(r,indent=2)+'\n');print(len(states),len(set(keys)),r['duplicatesWithDeclaredSourceHeight'])
