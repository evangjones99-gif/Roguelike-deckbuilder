import pathlib,json,hashlib,urllib.request,urllib.parse,sys,os
P=pathlib.Path('/workspace/scratch/large-card-layout-visual-independent-v09-r1');H=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for name,root,port,digest,count,outcount in [('baseline',pathlib.Path('/tmp/hollowpact-relic-bone-v09-root-r1'),4626,'4bfa417ad790dd88a18868e10e7574666ae8bfc3187bdab1df4947c31231de61',78,56),('candidate',pathlib.Path('/tmp/hollowpact-large-card-v09-author-r1'),4625,'2a266dca586e535e58aa80e559b8e2eac3df2453f5964450431e8d0448ddde5f',78,56)]:
 prov=json.loads((root/'dist/build-provenance.json').read_text());assert prov['sourceDigest']==digest
 files=[]
 for d in ['src','desktop','public']:
  for folder,dirs,names in os.walk(root/d,followlinks=True):
   files.extend((pathlib.Path(folder)/n).relative_to(root).as_posix()for n in names)
 files+=['index.html','THIRD-PARTY.md','package.json','package-lock.json','tsconfig.json','vite.config.ts','scripts/build.mjs'];files.sort();assert len(files)==count and files==list(prov['hashes']),name
 sources={k:H((root/k).read_bytes())for k in files};assert sources==prov['hashes'];assert H(json.dumps(sources,separators=(',',':'),ensure_ascii=False).encode())==digest
 outputs=[]
 for f in sorted((root/'dist').rglob('*')):
  if f.is_file():
   rel=f.relative_to(root/'dist').as_posix();b=f.read_bytes();r=urllib.request.urlopen(f'http://127.0.0.1:{port}/'+urllib.parse.quote(rel));assert r.status==200 and r.read()==b
   outputs.append({'path':rel,'bytes':len(b),'sha256':H(b),'HTTPExact':True})
 assert len(outputs)==outcount
 rows.append({'variant':name,'sourceRoot':str(root),'port':port,'provenance':prov,'sourceFiles':files,'outputs':outputs})
(P/('AUDIT-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{'variant':r['variant'],'inputs':len(r['sourceFiles']),'outputs':len(r['outputs'])}for r in rows]))
