import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {gzipSync} from 'node:zlib';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import {CARDS} from './source/content.ts';
import {validateState,applyAction,legalActions} from './source/engine.ts';
const out='/workspace/scratch/large-card-layout-visual-independent-v09-r1';
const original=JSON.parse(await fs.readFile(out+'/source/fixture.json','utf8'));
const ids=Object.keys(CARDS);assert.equal(ids.length,48);
await fs.writeFile(out+'/CATALOGUE.json',JSON.stringify(CARDS,null,2)+'\n',{flag:'wx'});
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const profiles:any[]=[];let active:any;let stateCount=0;
function fixture(phase:string,stock=ids.slice(0,3)){
 const s=structuredClone(original);s.schema=3;s.engineKind=2;s.phase=phase;s.floor=phase==='shop'?3:1;s.route=[phase==='shop'?'shop':'battle'];s.deck=[...ids];s.hand=[];s.draw=[];s.discard=[];s.enemies=[];s.allies=[];s.rewards=stock;s.gold=1000;assert(validateState(s));return s;
}
async function sample(page:any){return page.evaluate(()=>{
 const rect=(e:any)=>{const r=e.getBoundingClientRect();return [r.x,r.y,r.width,r.height,r.right,r.bottom]};
 const dialog=document.querySelector<HTMLDialogElement>('#dialog')!;
 const root=dialog.open?dialog:document.querySelector('#scene-ui')!;
 const cards=[...root.querySelectorAll<HTMLElement>('.game-card.large-card')].map(c=>{
  const box=rect(c);const nodes=[...c.querySelectorAll<HTMLElement>('.card-name,.card-kind,.card-description,.card-stats,.card-choose')].map(e=>{const range=document.createRange();range.selectNodeContents(e);return {part:e.className,text:e.textContent,font:getComputedStyle(e).font,lineHeight:getComputedStyle(e).lineHeight,rect:rect(e),glyphs:[...range.getClientRects()].filter(r=>r.width>0&&r.height>0).map(r=>[r.x,r.y,r.right,r.bottom]),scrollWidth:e.scrollWidth,clientWidth:e.clientWidth}});
  return {id:c.dataset.card,box,nodes};
 });return{cards,save:localStorage.getItem('hollowpact.run.v2'),body:[document.body.scrollWidth,innerWidth],page:[scrollX,scrollY],dialog:dialog.open?rect(dialog):null};
 });}
function defects(s:any){const result:any[]=[];for(const c of s.cards)for(const n of c.nodes){if(n.scrollWidth>n.clientWidth+1)result.push({id:c.id,part:n.part,kind:'internal horizontal overflow',scrollWidth:n.scrollWidth,clientWidth:n.clientWidth});for(const g of n.glyphs)if(g[0]<c.box[0]-.5||g[1]<c.box[1]-.5||g[2]>c.box[4]+.5||g[3]>c.box[5]+.5)result.push({id:c.id,part:n.part,kind:'printed text beyond card',glyph:g,box:c.box});}return result;}
try{
 for(const [width,height]of [[390,900],[1440,900],[390,720],[1440,720]])for(const variant of ['baseline','candidate']){
  active={width,height,variant};const ctx=await browser.newContext({viewport:{width,height},deviceScaleFactor:1,hasTouch:width===390});
  await ctx.addInitScript({content:"localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion:false,mute:true,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');"});
  const page=await ctx.newPage();const errors:string[]=[];page.on('pageerror',(e:any)=>errors.push(e.message));await page.goto('http://127.0.0.1:'+(variant==='candidate'?4625:4626)+'/',{waitUntil:'load'});
  const profile:any={...active,states:[],actions:[],captures:[],errors};
  async function load(s:any){await page.evaluate((v:string)=>localStorage.setItem('hollowpact.run.v2',v),JSON.stringify(s));await page.reload({waitUntil:'load'});await page.locator('[data-ui=resume]').click();}
  async function record(label:string,s:any,stock:string[]){active={width,height,variant,label};const snap=await sample(page);assert.equal(snap.save,JSON.stringify(s));assert.deepEqual(snap.cards.map((c:any)=>c.id),stock);const row:any={label,stock,snap,defects:defects(snap),hits:[]};
   for(const id of stock){const loc=page.locator((snap.dialog?'#dialog ':'#scene-ui ')+'.game-card.large-card[data-card="'+id+'"]');await loc.scrollIntoViewIfNeeded();const hit=await loc.evaluate((e:HTMLElement)=>{const b=e.getBoundingClientRect();const x=Math.max(1,Math.min(innerWidth-1,b.x+b.width/2)),y=Math.max(1,Math.min(innerHeight-1,b.y+b.height/2));const h=document.elementFromPoint(x,y);return{hit:!!h&&(h===e||e.contains(h)),rect:[b.x,b.y,b.width,b.height],at:[x,y]}});row.hits.push({id,...hit});assert(hit.hit,JSON.stringify({active,id,hit}));}
   assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),JSON.stringify(s));profile.states.push(row);stateCount++;return row;
  }
  async function capture(label:string){const file=`${width}x${height}-${variant}-${label}.jpg`;await page.screenshot({path:out+'/'+file,type:'jpeg',quality:63,fullPage:false});profile.captures.push(file);}
  for(const phase of ['reward','shop']){
   const size=phase==='reward'?3:5;
   for(let i=0;i<ids.length;i+=size){const stock=ids.slice(i,i+size),s=fixture(phase,stock);await load(s);const row=await record(phase+'-'+i,s,stock);
    if(stock.includes('fenraker')){const loc=page.locator('#scene-ui [data-card="fenraker"]');await loc.scrollIntoViewIfNeeded();await capture(phase+'-fenraker');row.capture=profile.captures.at(-1);}
   }
  }
  let s=fixture('reward');await load(s);await page.locator('[data-ui=deck]').click();await record('deck',s,ids);
  const long=ids.slice().sort((a,b)=>((CARDS[b].text+('passive'in CARDS[b]?CARDS[b].passive:'')).length)-((CARDS[a].text+('passive'in CARDS[a]?CARDS[a].passive:'')).length)).slice(0,3);
  for(const id of long){const loc=page.locator('#dialog .game-card[data-card="'+id+'"]');await loc.scrollIntoViewIfNeeded();await loc.click();assert.equal(await page.locator('#dialog-title').textContent(),CARDS[id].name);await record('inspect-'+id,s,[id]);if(id===long[0])await capture('longest-inspect');await page.locator('#dialog [data-ui=deck]').click();}
  await page.getByRole('button',{name:'Close dialog',exact:true}).click();
  const battle=structuredClone(original);battle.schema=3;battle.engineKind=2;assert(validateState(battle));await load(battle);profile.hand=await page.locator('.hand-cards').evaluate((e:HTMLElement)=>[...e.querySelectorAll<HTMLElement>('.game-card')].map(c=>{const b=c.getBoundingClientRect();return{id:c.dataset.card,rect:[b.x,b.y,b.width,b.height],nodes:[...c.querySelectorAll<HTMLElement>('.card-name,.card-description,.card-kind,.card-stats')].map(n=>({text:n.textContent,font:getComputedStyle(n).font}))}}));profile.normalBattleBody=await page.evaluate(()=>[document.body.scrollWidth,innerWidth]);assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),JSON.stringify(battle));
  async function action(s:any,a:any,loc:any,clickLoc=loc){assert(legalActions(s).some((x:any)=>JSON.stringify(x)===JSON.stringify(a)));await loc.scrollIntoViewIfNeeded();await loc.focus();await page.keyboard.press('Tab');await page.keyboard.press('Shift+Tab');const focused=await loc.evaluate((e:HTMLElement)=>({active:document.activeElement===e,outline:getComputedStyle(e).outline}));assert(focused.active);await clickLoc.scrollIntoViewIfNeeded();if(width===390)await clickLoc.tap();else await clickLoc.click();const expected=applyAction(s,a),save=await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2'));assert.equal(save,JSON.stringify(expected));await page.reload({waitUntil:'load'});await page.locator('[data-ui=resume]').click();assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),save);profile.actions.push({initial:s,action:a,expected,save,focused,reloadExact:true});}
  s=fixture('reward',['fenraker','fenraker+','ossuarycolossus+']);await load(s);await action(s,{type:'reward',card:'fenraker'},page.locator('[data-action=reward][data-card=fenraker]'));
  await load(s);await action(s,{type:'reward',card:null},page.locator('[data-action=reward][data-card=""]'));
  s=fixture('shop',['fenraker','fenraker+','ossuarycolossus','ossuarycolossus+','covenant']);await load(s);const buy=page.locator('[data-action=buy][data-card="fenraker+"]');await action(s,{type:'buy',card:'fenraker+'},buy,buy.locator('.card-choose'));
  await load(s);await action(s,{type:'leave'},page.locator('[data-action=leave]'));
  await load(s);await page.locator('[data-ui=remove]').click();await action(s,{type:'remove',index:0},page.locator('.remove-card[data-index="0"]'));
  assert.deepEqual(errors,[]);await ctx.close();profiles.push(profile);await fs.writeFile(out+`/profile-${profiles.length}.json.gz`,gzipSync(JSON.stringify(profile),{level:9}),{flag:'wx'});console.log('PASS',width,height,variant,'states',profile.states.length,'actions',profile.actions.length);
 }
 for(const[width,height]of [[390,900],[1440,900],[390,720],[1440,720]]){const a=profiles.find(p=>p.width===width&&p.height===height&&p.variant==='baseline'),b=profiles.find(p=>p.width===width&&p.height===height&&p.variant==='candidate');assert.deepEqual(a.hand,b.hand);assert.deepEqual(a.normalBattleBody,b.normalBattleBody);for(let i=0;i<a.states.length;i++){assert.equal(a.states[i].label,b.states[i].label);assert.deepEqual(a.states[i].snap.cards.map((c:any)=>({id:c.id,nodes:c.nodes.map((n:any)=>({part:n.part,text:n.text,font:n.font,lineHeight:n.lineHeight}))})),b.states[i].snap.cards.map((c:any)=>({id:c.id,nodes:c.nodes.map((n:any)=>({part:n.part,text:n.text,font:n.font,lineHeight:n.lineHeight}))})));}}
 const result={profiles:profiles.length,states:stateCount,cards:profiles.flatMap(p=>p.states.flatMap((s:any)=>s.snap.cards)).length,candidateDefects:profiles.filter(p=>p.variant==='candidate').flatMap(p=>p.states.flatMap((s:any)=>s.defects)),baselineDefects:profiles.filter(p=>p.variant==='baseline').flatMap(p=>p.states.flatMap((s:any)=>s.defects)),actions:profiles.reduce((n,p)=>n+p.actions.length,0),reloads:profiles.reduce((n,p)=>n+p.actions.length,0),captures:profiles.reduce((n,p)=>n+p.captures.length,0),handPairExact:true,textAndFontsPairExact:true};await fs.writeFile(out+'/PASS.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
}catch(e){await fs.writeFile(out+'/FAILURE.json',JSON.stringify({error:String(e),stack:(e as Error).stack,active,completedProfiles:profiles.length,states:stateCount},null,2)+'\n',{flag:'wx'});throw e;}finally{await browser.close();}
