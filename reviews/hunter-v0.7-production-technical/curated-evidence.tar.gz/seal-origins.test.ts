import test from 'node:test';import assert from 'node:assert/strict';
import {createGame} from './src/engine';import{observeHunter,hunterPose,hunterGeometry,hunterSourcePoint,HUNTER_R3_FRAMES,HUNTER_R3_SEAL}from './src/hunter-presence';
(globalThis as any).location=new URL('http://localhost/?hunter=midgap&fit=wholecell');
test('independent R2 approved seal annotations survive R3; both mirrored directions and motion modes use actual helper geometry',()=>{
const approved={idle:{x:323,y:235},anticipation:{x:268,y:219},attack:{x:222,y:221},recovery:{x:283,y:172},reaction:{x:250,y:180},death:{x:244,y:290}};
assert.deepEqual(HUNTER_R3_SEAL,approved);let count=0;
for(const[w,height]of[[390,220],[502,277],[758,277],[1398,277],[1398,328]])for(const pose of Object.keys(approved) as (keyof typeof approved)[])for(const facing of[-1,1]as const)for(const reduced of[false,true]){
const h=observeHunter({...createGame(999),phase:'battle'});h.facing=facing;h.dead=pose==='death';
if(pose==='anticipation')h.cues=[{kind:'ritual',start:0,end:.58,source:'hunter',target:'enemy'}];
if(pose==='attack')h.cues=[{kind:'ritual',start:-.2,end:.38,source:'hunter',target:'enemy'}];
if(pose==='recovery')h.cues=[{kind:'ritual',start:-.4,end:.18,source:'hunter',target:'enemy'}];
if(pose==='reaction')h.cues=[{kind:'reaction',start:0,end:.22,source:'enemy',target:'hunter'}];
const before=JSON.stringify(h),effective=reduced?(h.dead?'death':'idle'):hunterPose(h,0);assert.equal(effective,reduced?(h.dead?'death':'idle'):pose);
const g=hunterGeometry(w,height,'midgap','wholecell'),s=g.bodyHeight*512/418,annotation=approved[effective],frame=HUNTER_R3_FRAMES[effective];
assert.deepEqual(hunterSourcePoint(h,w,height,0,reduced),{x:g.feet.x+(annotation.x-256)/512*s*facing,y:g.feet.y+(annotation.y-frame.groundY)/512*s});assert.equal(JSON.stringify(h),before);count++;
}console.log(JSON.stringify({annotationFormulaChecks:count,annotationScope:'Six root-reviewed ring centers, +/-3 source pixels estimation, unchanged source art; verifies math and literals, not visual approval.'}));
});
