import test from 'node:test';
import assert from 'node:assert/strict';
import {applyActionWithEvents,createGame,legalActions,validateState} from './src/engine';
import {observeHunter,hunterEventCues,hunterPose,HUNTER_R3_FRAMES,hunterGeometry,hunterSourcePoint} from './src/hunter-presence';
function freeze(v:any):any {if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}return v;}
test('independent legal campaigns: deeply frozen canonical inputs, deterministic next rule state, finite queues',()=>{
 let transitions=0,death=0,maxEnd=0;const kinds=new Set<string>();
 for(let seed=89000;seed<89032;seed++){
  let s=createGame(seed,seed%3);let h=observeHunter(s);let chooser=(seed^0x647a)>>>0;
  for(let n=0;n<450;n++){
   const actions=legalActions(s);if(!actions.length)break;chooser=(Math.imul(chooser,1103515245)+12345)>>>0;const action=actions[chooser%actions.length];
   freeze(s);const before=JSON.stringify(s),one=applyActionWithEvents(s,action),again=applyActionWithEvents(s,action);assert.deepEqual(one,again);freeze(one.events);
   const delays=new Map<string,number>();const terminal=one.state.phase!=='battle';
   const delayFor=(source:string,retaliation:boolean)=>{if(retaliation)return .04;if(action.type!=='endTurn'||!s.enemies.some(u=>u.uid===source))return 0;if(!delays.has(source))delays.set(source,delays.size*(terminal?.009:.05));return delays.get(source)!;};
   const trace=JSON.stringify(one.events);h=observeHunter(one.state,h);h.cues=hunterEventCues(one.events,0,delayFor);
   for(const cue of h.cues){kinds.add(cue.kind);assert.ok(Number.isFinite(cue.start)&&cue.start>=0&&cue.end>cue.start);maxEnd=Math.max(maxEnd,cue.end);if(terminal)assert.ok(cue.end<=1.2);}
   for(const t of [0,.139,.14,.24,.32,.579,.58,1,2]){hunterPose(h,t);hunterSourcePoint(h,512,277,t,false);}
   assert.equal(JSON.stringify(s),before);assert.equal(JSON.stringify(one.events),trace);assert.deepEqual(applyActionWithEvents(s,action),again);assert.ok(validateState(one.state));assert.equal(h.hp,one.state.hp);assert.equal(h.block,one.state.block);
   if(one.state.phase==='defeat'){death++;assert.equal(hunterPose({...h,cues:[]},0),'death');}
   s=one.state;transitions++;
  }
 }
 console.log(JSON.stringify({independentTransitions:transitions,seeds:'89000..89031',defeats:death,maxCueEndSeconds:maxEnd,cueKinds:[...kinds],deepFrozenCanonical:true}));assert.ok(transitions>1000);
});
test('all pose cells plus mirrored seal geometry: 30 legal viewport-shaped dimensions, deterministic inputs',()=>{
 const h=observeHunter(createGame(999));
 for(const w of [250,390,502,700,1398,2000])for(const height of [150,220,277,328,400]){
  const g=hunterGeometry(w,height,'midgap','wholecell'),cell=g.bodyHeight*512/418;
  for(const f of Object.values(HUNTER_R3_FRAMES)){
   assert.ok(g.feet.x-cell/2>=2&&g.feet.x+cell/2<=w-2);assert.ok(g.feet.y-cell*f.groundY/512>=2);assert.ok(g.feet.y+cell*(512-f.groundY)/512<=height-2+1e-9);
  }
  for(const facing of [-1,1] as const){h.facing=facing;const a=hunterSourcePoint(h,w,height,0,false),b=hunterSourcePoint(h,w,height,0,false);assert.deepEqual(a,b);assert.ok(Number.isFinite(a.x)&&Number.isFinite(a.y));}
 }
});
test('visibility lifecycle uses prior battle context only; canonical observer stays private',()=>{
 const s=createGame(3),battle={...s,phase:'battle' as const},r={...s,phase:'reward' as const},v={...s,phase:'victory' as const};
 assert.equal(observeHunter(s).visible,false);assert.equal(observeHunter(r).visible,false);assert.equal(observeHunter(v).visible,false);
 const seen=observeHunter(battle);assert.equal(observeHunter(r,seen).visible,true);assert.equal(observeHunter(v,seen).visible,true);assert.equal(observeHunter(s,seen).visible,false);
 const snapshot=JSON.stringify(battle);seen.hp=0;seen.cues.push({kind:'death',start:0,end:1,source:'world',target:'hunter'});assert.equal(JSON.stringify(battle),snapshot);
});
