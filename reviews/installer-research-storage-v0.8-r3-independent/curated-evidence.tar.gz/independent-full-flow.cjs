// Independent reviewer harness. Never invokes live APIs or large binary transfers.
// Actual candidate main/API/identity/draft/storage logic runs unchanged; large
// wrapper reconstruction and original binary read-back are explicit simulations.
const fs = require('node:fs'), path = require('node:path'), os = require('node:os');
const assert = require('node:assert/strict'), crypto = require('node:crypto');
const {spawnSync} = require('node:child_process');
if (process.argv[2] === '--worker') {
  worker().catch(error => { console.error(error.stack); process.exitCode = 1; });
} else main();
function main() {
  const base = path.resolve(process.argv[2]), output = path.resolve(process.argv[3]);
  const candidate = fs.readFileSync(path.join(base, 'candidate-script.js'), 'utf8');
  const cases = ['fresh-success', 'matching-complete', 'matching-partial', 'fourth-evidence-refused',
    'foreign-existing-asset', 'existing-corrupt-readback', 'published-after-first-upload',
    'tag-appeared-after-preflight', 'draft-create-failed-after-tag', 'uploaded-asset-wrong-size',
    'fourth-origin-foreign-head'];
  const results = [];
  fs.mkdirSync(output, {recursive: false});
  for (const scenario of cases) {
    const work = fs.mkdtempSync(path.join(os.tmpdir(), 'hollowpact-independent-storage-'));
    const resultPath = path.join(output, scenario + '.json');
    const proc = spawnSync(process.execPath, [__filename, '--worker', base, scenario, resultPath],
      {cwd: work, encoding: 'utf8', timeout: 30000});
    fs.writeFileSync(path.join(output, scenario + '.stdout.txt'), proc.stdout, {flag: 'wx'});
    fs.writeFileSync(path.join(output, scenario + '.stderr.txt'), proc.stderr, {flag: 'wx'});
    assert.equal(proc.status, 0, `${scenario}: ${proc.stderr}`);
    const result = JSON.parse(fs.readFileSync(resultPath));
    const success = ['fresh-success', 'matching-complete', 'matching-partial'].includes(scenario);
    assert.equal(result.report.status, success ? 'passed-four-installer-research-draft-preservation' : 'failed', scenario);
    if (success) {
      assert.deepEqual(result.report.cases.map(c => c.originalNativeQAStatus), ['failed','failed','failed','passed'], scenario);
      assert.deepEqual(result.coverageStatuses, ['failed','failed','failed','passed'], scenario);
      assert.equal(result.report.cases.length, 4, scenario);
      assert(result.report.cases.every(c => c.assets.length === 3 && c.assets.every(a => a.fullReadBackVerified)), scenario);
      assert(result.releaseBodies.every((body, i) => i === 3 ? body.includes('Isolated installer QA lifecycle passed') : body.includes('FAILED installer QA research')), scenario);
      assert(result.releaseBodies.every(body => !body.includes('Pinned failed research inputs')), scenario);
      assert.equal(result.writes.createRef, scenario === 'fresh-success' ? 4 : 0, scenario);
      assert.equal(result.writes.createRelease, scenario === 'fresh-success' ? 4 : 0, scenario);
      assert.equal(result.writes.upload, scenario === 'fresh-success' ? 12 : scenario === 'matching-partial' ? 6 : 0, scenario);
      assert.equal(result.reconstructed, 4, scenario);
      assert.equal(result.evidenceValidated, 4, scenario);
    } else {
      assert(result.failed && result.failed === result.report.error, scenario);
      const total = Object.values(result.writes).reduce((a,b) => a+b, 0);
      if (scenario === 'draft-create-failed-after-tag') {
        assert.equal(total, 2); assert.equal(result.writes.createRef, 1); assert.equal(result.writes.createRelease, 1);
        assert.equal(result.refs.length, 1); assert.equal(result.report.cases[0].newResearchTagCreated, true);
      } else if (['published-after-first-upload', 'uploaded-asset-wrong-size'].includes(scenario)) {
        assert.equal(total, 3); assert.equal(result.writes.upload, 1);
      } else assert.equal(total, 0, scenario);
      if (scenario === 'fourth-evidence-refused') { assert.equal(result.reconstructed, 4); assert.equal(result.evidenceValidated, 3); }
      if (scenario === 'fourth-origin-foreign-head') assert.equal(result.reconstructed, 0);
    }
    results.push({scenario, passed: true, result: path.basename(resultPath), ...result.writes});
  }
  const summary = {schema: 1, candidateSHA256: crypto.createHash('sha256').update(candidate).digest('hex'),
    passed: results.length, failed: 0, scope: 'Independent execution of unchanged candidate storage/API/identity/main logic with mocked network and 4-GiB capacity. Original small evidence ZIP parsing/CRC/member hashes and small stored asset byte/SHA read-back run actual candidate helpers. Five large wrapper downloads, concatenated original installer byte/SHA and original installer read-back explicitly mocked. No live storage, native installer execution or independent large-original proof.', results};
  fs.writeFileSync(path.join(output, 'SUMMARY.json'), JSON.stringify(summary, null, 2)+'\n', {flag:'wx'});
  console.log(JSON.stringify({passed:results.length,failed:0,candidateSHA256:summary.candidateSHA256}));
}
async function worker() {
  const base = path.resolve(process.argv[3]), scenario = process.argv[4], resultPath = path.resolve(process.argv[5]);
  const source = fs.readFileSync(path.join(base, 'candidate-script.js'), 'utf8');
  const pins = JSON.parse(fs.readFileSync(path.join(base, 'pins.json')));
  const marker = '// BEGIN EXECUTION:';
  assert(source.includes(marker));
  const prefix = source.slice(0, source.indexOf(marker));
  const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
  const state = {writes:{createRef:0,createRelease:0,upload:0}, origins:0, reconstructed:0,
    evidenceValidated:0, realSmallReadbacks:0, mockedLargeReadbacks:0, downloads:0, failed:'',
    refs: new Map(), releases: new Map(), assets: new Map(), originalPaths: new Map(), storedBodies: new Map(), allProofBeforeWrite:true};
  const core = {getInput:()=> 'independent-fixture-secret-never-sent', notice:()=>{}, setFailed: message => {state.failed=message;}};
  const context = {repo:{owner:'evangjones99-gif',repo:'Roguelike-deckbuilder'},ref:'refs/heads/codex/lanternbound-production',eventName:'push'};
  const definitions = await new AsyncFunction('require','core', prefix+'\nreturn {coverage,releaseIdentity};')(require,core);
  const owner='evangjones99-gif', repo='Roguelike-deckbuilder';
  let nextAssetId=300, nextReleaseId=100;
  const pinForRelease = id => pins.find(pin=>state.releases.get(pin.tag)?.id===id);
  const expectedFor = (pin,name) => name===pin.installerAssetName ? {bytes:pin.bytes,sha256:pin.sha256} :
    name===pin.evidenceAssetName ? {bytes:pin.evidence.bytes,sha256:pin.evidence.sha256} : (()=>{
      assert.equal(name,'preservation-coverage.json'); const b=Buffer.from(JSON.stringify(definitions.coverage(pin),null,2)+'\n');
      return {bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),body:b};})();
  const addAsset=(pin,name)=>{
    const e=expectedFor(pin,name), asset={id:++nextAssetId,name,size:e.bytes,state:'uploaded'};
    state.assets.get(state.releases.get(pin.tag).id).push(asset);
    const body = name===pin.installerAssetName ? Buffer.from('MOCK LARGE ORIGINAL') :
      name===pin.evidenceAssetName ? fs.readFileSync(path.join(base,'input-receipts',String(pin.runId),'original-native-evidence.zip')) : e.body;
    state.storedBodies.set(asset.id,{body,sha256:e.sha256,pin,large:name===pin.installerAssetName});
    return asset;
  };
  const preexisting=['matching-complete','matching-partial','foreign-existing-asset','existing-corrupt-readback'].includes(scenario);
  if(preexisting) for(const pin of pins){
    const release={id:++nextReleaseId,tag_name:pin.tag,target_commitish:pin.headSHA,draft:true,prerelease:true,...definitions.releaseIdentity(pin)};
    state.releases.set(pin.tag,release);state.refs.set(pin.tag,{ref:'refs/tags/'+pin.tag,object:{type:'commit',sha:pin.headSHA}});state.assets.set(release.id,[]);
    const selected=scenario==='matching-partial'?[pin.installerAssetName,...(pin.runId===pins[0].runId||pin.runId===pins[3].runId?[pin.evidenceAssetName]:[])]:[pin.installerAssetName,pin.evidenceAssetName,'preservation-coverage.json'];
    selected.forEach(name=>addAsset(pin,name));
  }
  if(scenario==='foreign-existing-asset')state.assets.get(state.releases.get(pins[0].tag).id).push({id:999,name:'foreign.bin',size:1,state:'uploaded'});
  if(scenario==='existing-corrupt-readback'){
    const asset=state.assets.get(state.releases.get(pins[0].tag).id).find(a=>a.name===pins[0].evidenceAssetName);
    state.storedBodies.get(asset.id).body=Buffer.from('bad');
  }
  const readonly=fn=>async args=>({data:fn(args)});
  const missing=()=>{const e=new Error('missing');e.status=404;throw e;};
  const write=(name,fn)=>async args=>{
    assert.equal(state.origins,4,'all origins before any write');assert.equal(state.reconstructed,4,'all originals before any write');
    assert.equal(state.evidenceValidated,4,'all evidence before any write');state.writes[name]++;return {data:fn(args)};
  };
  const github={rest:{actions:{
    getWorkflowRun:readonly(args=>{state.origins++;const data=JSON.parse(fs.readFileSync(path.join(base,'live-run-'+args.run_id+'.json')));if(scenario==='fourth-origin-foreign-head'&&args.run_id===pins[3].runId)data.head_sha='f'.repeat(40);return data;}),
    listWorkflowRunArtifacts:readonly(args=>JSON.parse(fs.readFileSync(path.join(base,'live-artifacts-'+args.run_id+'.json')))),
    getArtifact:readonly(args=>{for(const pin of pins){const data=JSON.parse(fs.readFileSync(path.join(base,'live-artifacts-'+pin.runId+'.json')));const match=data.artifacts.find(a=>a.id===args.artifact_id);if(match)return match;}throw new Error('unknown fixture artifact');})
  },git:{getRef:readonly(args=>{
    const tag=args.ref.replace(/^tags\//,'');
    if(scenario==='tag-appeared-after-preflight'&&state.evidenceValidated===4&&!state.refs.has(tag))state.refs.set(tag,{ref:'refs/tags/'+tag,object:{type:'commit',sha:pins.find(p=>p.tag===tag).headSHA}});
    return state.refs.get(tag)||missing();
  }),createRef:write('createRef',args=>{const tag=args.ref.replace(/^refs\/tags\//,'');assert(!state.refs.has(tag));const ref={ref:args.ref,object:{type:'commit',sha:args.sha}};state.refs.set(tag,ref);return ref;})},repos:{
    listReleases:readonly(()=>[...state.releases.values()]),
    getRelease:readonly(args=>{const pin=pinForRelease(args.release_id);assert(pin);return state.releases.get(pin.tag);}),
    listReleaseAssets:readonly(args=>state.assets.get(args.release_id)||[]),
    createRelease:write('createRelease',args=>{if(scenario==='draft-create-failed-after-tag')throw new Error('fixture-token https://signed.invalid/secret');assert.equal(args.draft,true);assert.equal(args.prerelease,true);assert.equal(args.make_latest,'false');assert.equal(args.generate_release_notes,false);const release={id:++nextReleaseId,...args};state.releases.set(args.tag_name,release);state.assets.set(release.id,[]);return release;}),
    uploadReleaseAsset:write('upload',args=>{const pin=pinForRelease(args.release_id);assert(pin);const e=expectedFor(pin,args.name);assert.equal(args.headers['content-length'],e.bytes);assert(!state.assets.get(args.release_id).some(a=>a.name===args.name));const asset=addAsset(pin,args.name);if(args.name!==pin.installerAssetName)assert(Buffer.from(args.data).equals(state.storedBodies.get(asset.id).body));else assert(Buffer.from(args.data).equals(Buffer.from('MOCK LARGE ORIGINAL')));if(scenario==='published-after-first-upload')state.releases.get(pin.tag).draft=false;if(scenario==='uploaded-asset-wrong-size')asset.size--;return asset;})
  }}};
  const fixtureRequire=name=>name==='node:fs'?{...fs,
    statfsSync:()=>({bavail:4096,bsize:1048576}),
    statSync: filename=>state.originalPaths.has(String(filename))?{size:state.originalPaths.get(String(filename)).bytes}:fs.statSync(filename)
  }:require(name);
  const fetch=async(url,options)=>{
    assert.equal(options.redirect,'manual');assert.equal(new URL(url).origin,'https://api.github.com');
    assert.equal(options.headers.Authorization,'Bearer independent-fixture-secret-never-sent');
    const id=Number(new URL(url).pathname.match(/\/releases\/assets\/([0-9]+)$/)?.[1]);
    const stored=state.storedBodies.get(id);assert(stored&&!stored.large);state.realSmallReadbacks++;
    return new Response(stored.body,{status:200,headers:{'content-length':String(stored.body.length)}});
  };
  const overrides=String.raw`
const actualVerifyZIP = verifyZIP, actualDigestFile = digestFile, actualVerifyStored = verifyStored;
downloadArtifact = async function(pin, expected, destination) {
  const data=await api('mock boundary still validates fixed artifact',github.rest.actions.getArtifact,{owner,repo,artifact_id:expected.artifactId});
  validateArtifact(data,pin,expected); fixtureState.downloads++;
  if(expected.artifactId===pin.evidence.artifactId) {
    const original=fs.readFileSync(require('node:path').join(fixtureBase,'input-receipts',String(pin.runId),'original-native-evidence.zip'));
    check(original.length===expected.bytes&&hash(original)===expected.sha256,'Actual small fixture differs');
    fs.writeFileSync(destination,original,{flag:'wx'});
  } else fs.writeFileSync(destination,'MOCK LARGE WRAPPER',{flag:'wx'});
};
verifyZIP = function(purpose,archive,spec,output,work) {
  if(purpose==='part')fs.writeFileSync(output,'MOCK LARGE PART',{flag:'wx'});
  else {
    if(fixtureScenario==='fourth-evidence-refused'&&spec.runId===PINS[3].runId)fail('Independent late fourth evidence refusal');
    actualVerifyZIP(purpose,archive,spec,output,work); fixtureState.evidenceValidated++;
  }
};
concatenate = function(pin,work,output) {
  for(const part of pin.parts)check(fs.existsSync(path.join(work,part.filename)),'Mock part missing');
  fs.writeFileSync(output,'MOCK LARGE ORIGINAL',{flag:'wx'});fixtureState.originalPaths.set(output,pin);fixtureState.reconstructed++;
};
digestFile = function(filename) {return fixtureState.originalPaths.has(filename)?fixtureState.originalPaths.get(filename).sha256:actualDigestFile(filename);};
verifyStored = async function(asset,expected) {
  const mock=fixtureState.storedBodies.get(asset.id);
  if(mock?.large) {
    check(Number.isSafeInteger(asset.id)&&asset.id>0&&asset.name===expected.name&&asset.size===expected.bytes&&asset.state==='uploaded','Existing/stored research asset identity/size/state differs');
    check(mock.sha256===expected.sha256&&mock.pin.bytes===expected.bytes,'Mock original descriptor mismatch'); fixtureState.mockedLargeReadbacks++;
  } else await actualVerifyStored(asset,expected);
};
`;
  const modified = prefix + overrides + source.slice(source.indexOf(marker));
  await new AsyncFunction('require','core','context','github','fetch','fixtureState','fixtureBase','fixtureScenario', modified)
    (fixtureRequire,core,context,github,fetch,state,base,scenario);
  const report=JSON.parse(fs.readFileSync('installer-research-preservation/report.json'));
  const coverageStatuses=pins.map(pin=>{const f=path.join('installer-research-preservation',String(pin.runId),'preservation-coverage.json');return fs.existsSync(f)?JSON.parse(fs.readFileSync(f)).statusOfOriginalNativeQA:null;});
  fs.writeFileSync(resultPath,JSON.stringify({scenario,report,writes:state.writes,origins:state.origins,
    reconstructed:state.reconstructed,evidenceValidated:state.evidenceValidated,realSmallReadbacks:state.realSmallReadbacks,
    mockedLargeReadbacks:state.mockedLargeReadbacks,failed:state.failed,coverageStatuses,
    releaseBodies:pins.map(pin=>state.releases.get(pin.tag)?.body||''),refs:[...state.refs.keys()],
    limitation:'No live API, native execution or actual large original binary proof. Explicit mocked 4-GiB capacity, five large wrappers and original installer/hash/read-back; actual small evidence parsing and small stored read-back.'},null,2)+'\n',{flag:'wx'});
}
