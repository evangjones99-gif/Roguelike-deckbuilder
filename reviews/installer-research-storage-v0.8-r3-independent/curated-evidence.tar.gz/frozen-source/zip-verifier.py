import hashlib,json,stat,sys,zipfile

# This fixed source is embedded verbatim in the no-checkout workflow. No archive
# member is treated as executable code or extracted via an arbitrary path.
mode,archive_path,request_path,output_path=sys.argv[1:]
spec=json.load(open(request_path,encoding='utf-8'))
with zipfile.ZipFile(archive_path) as archive:
 entries=archive.infolist()
 if mode=='part':
  expected=[{'path':spec['filename'],'bytes':spec['bytes'],'sha256':spec['sha256']}]
 elif mode=='evidence':
  expected=spec['evidence']['members']
 else:raise AssertionError('unsupported fixed verifier purpose')
 assert 1<=len(expected)<=9 and len(entries)==len(expected)
 declared={x['path']:x for x in expected}
 assert len(declared)==len(expected)
 assert set(e.filename for e in entries)==set(declared)
 read_json={};summary=[]
 for entry in entries:
  request=declared[entry.filename]
  assert not entry.is_dir() and not entry.flag_bits&1
  assert entry.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)
  assert entry.filename==request['path'] and not entry.filename.startswith('/')
  assert '\\' not in entry.filename and '..' not in entry.filename.split('/')
  unixmode=entry.external_attr>>16
  assert not unixmode or stat.S_IFMT(unixmode) in (0,stat.S_IFREG)
  assert entry.file_size==request['bytes'] and 0<entry.file_size<=25165824
  assert 0<=entry.compress_size<=33554432
  output=open(output_path,'xb') if mode=='part' else None
  chunks=[];total=0;digest=hashlib.sha256()
  try:
   with archive.open(entry) as source:
    while True:
     chunk=source.read(min(1048576,request['bytes']-total+1))
     if not chunk:break
     total+=len(chunk);assert total<=request['bytes'];digest.update(chunk)
     if output:output.write(chunk)
     elif entry.filename.endswith('.json'):
      assert total<=262144;chunks.append(chunk)
   assert total==request['bytes'] and digest.hexdigest()==request['sha256']
  finally:
   if output:output.close()
  if mode=='evidence' and entry.filename.endswith('.json'):
   read_json[entry.filename]=json.loads(b''.join(chunks).decode('utf-8-sig'))
  summary.append({'path':entry.filename,'bytes':total,'sha256':digest.hexdigest(),'crcVerified':True})
 if mode=='evidence':
  manifest=read_json['build-installer/installer-transfer/manifest.json']
  assert manifest['schema']==1 and manifest['nativeQAStatus']==spec['nativeQAStatus']
  for field,key in [('commit','headSHA'),('version','version'),('sourceDigest','sourceDigest'),('filename','originalFilename'),('bytes','bytes'),('sha256','sha256')]:assert manifest[field]==spec[key]
  assert manifest['ref']=='refs/heads/codex/lanternbound-production'
  assert manifest['runId']==str(spec['runId']) and manifest['attempt']=='1'
  assert manifest['partBytes']==25165824
  assert manifest['parts']==[{k:p[k] for k in ('index','filename','bytes','sha256')} for p in spec['parts']]
  smoke=read_json[f"reviews/windows-installer/0.7.0/run-{spec['runId']}-1/installer-smoke.json"]
  assert smoke['status']==spec['nativeQAStatus'] and smoke['installerSHA256']==spec['sha256']
  provenance=read_json['dist/build-provenance.json']
  assert provenance['version']=='0.7.0' and provenance['sourceDigest']==spec['sourceDigest']
  assert len(provenance['hashes'])==29
print(json.dumps({'purpose':mode,'allExactMembersCRCSizeSHAPass':True,'members':summary}))
