from pathlib import Path
import json,hashlib,yaml,subprocess,re,datetime
base=Path('/workspace/scratch/installer-research-remote-preservation-author-v08-r3')
old=Path('/workspace/scratch/installer-research-remote-preservation-author-v08-r2')
out=Path(__file__).parent
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(base/'MANIFEST.json')=='1bf8b10cb92d0061b62f8bd4bd95c0b5db42af23f8b42da3d863eab9ce23243a'
manifest=json.loads((base/'MANIFEST.json').read_text())
for row in manifest['files']:
 p=base/row['path'];assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],row['path']
assert len(manifest['files'])==263
for p in sorted(old.rglob('*')):
 if p.is_file(): assert (base/'reference-r2'/p.relative_to(old)).read_bytes()==p.read_bytes(),str(p)
for name in ['pins.json','zip-verifier.py']:
 assert (base/name).read_bytes()==(old/name).read_bytes(),name
before=(old/'candidate-script.js').read_text();after=(base/'candidate-script.js').read_text()
expected=before.replace('Pinned failed research inputs SHA256:','Pinned research inputs SHA256:').replace("originalNativeQAStatus: 'failed', status: 'storing'","originalNativeQAStatus: pin.nativeQAStatus, status: 'storing'")
assert after==expected
assert digest(base/'candidate-script.js')=='53c6b7ad8867274ff217790b82a88ff4630f9b19241ed14fa7ae28f7a0a7aea1'
assert digest(base/'preserve-installer-research.yml')=='fbc0afde71858071fa35ff5d582d886d3aaff009997b2d644decb961cb32a9a7'
w=yaml.load((base/'preserve-installer-research.yml').read_text(),Loader=yaml.BaseLoader)
assert w['permissions']=={} and w['concurrency']['cancel-in-progress']=='false'
assert set(w['on'])=={'push','workflow_dispatch'} and w['on']['workflow_dispatch'] is None or w['on']['workflow_dispatch']==''
assert w['on']['push']['branches']==['codex/lanternbound-production']
job=w['jobs']['preserve-installer-research'];assert job['permissions']=={'contents':'write','actions':'read'}
assert job['runs-on']=='ubuntu-latest' and job['timeout-minutes']=='45'
steps=job['steps'];assert len(steps)==2
assert steps[0]['uses']=='actions/github-script@f28e40c7f34bde8b3046d885e986cb6290c5673b'
assert steps[1]['uses']=='actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02'
assert steps[0]['with']['script'].rstrip()==after.rstrip()
for bad in ['deleteRelease','deleteRef','deleteReleaseAsset','updateRelease','updateRef','actions/checkout','npm install']:
 assert bad not in (base/'preserve-installer-research.yml').read_text(),bad
pins=json.loads((base/'pins.json').read_text());assert [p['nativeQAStatus'] for p in pins]==['failed','failed','failed','passed']
tests=[];fixtures=out/'parser-fixtures';fixtures.mkdir()
for pin in pins:
 actual=base/'input-receipts'/str(pin['runId'])/'original-native-evidence.zip'
 independently_retained=Path('/workspace/scratch/installer-native-independent-run-'+str(pin['runId']))/'original-native-evidence.zip'
 # Earlier reviewer folder uses exact original artifact evidence ZIP under a preserved name.
 if not independently_retained.exists():
  candidates=list(independently_retained.parent.rglob('*.zip'))
  independently_retained=next(p for p in candidates if digest(p)==pin['evidence']['sha256'])
 assert actual.read_bytes()==independently_retained.read_bytes()
 assert actual.stat().st_size==pin['evidence']['bytes'] and digest(actual)==pin['evidence']['sha256']
 for exact in [True,False]:
  spec=dict(pin)
  if not exact:spec['nativeQAStatus']='passed' if pin['nativeQAStatus']=='failed' else 'failed'
  name=str(pin['runId'])+('-exact' if exact else '-wrong-status');request=fixtures/(name+'.json')
  request.write_text(json.dumps(spec))
  run=subprocess.run(['python3',str(base/'zip-verifier.py'),'evidence',str(actual),str(request),'-'],capture_output=True)
  (fixtures/(name+'.stdout.txt')).write_bytes(run.stdout);(fixtures/(name+'.stderr.txt')).write_bytes(run.stderr)
  assert (run.returncode==0)==exact,name
  tests.append({'runId':pin['runId'],'exact':exact,'returncode':run.returncode,'passed':True})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorFilesFullyHashed':263,'allR2InputsRetainedExact':True,'candidateOnlyTwoLineFixes':True,'allFourPinsAndZIPParserUnchanged':True,'embeddedYAMLExact':True,'permissionAndPinnedActionGate':True,'actualFourOriginalZIPStatusCases':tests,'scope':'Read-only source/manifest audit and exact original small-ZIP parser execution. No live storage or large original download.'}
with (out/'STATIC-PARSER-AUDIT.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'all263ManifestFilesPass':True,'embeddedYAMLExact':True,'actualParserTests':len(tests)}))
