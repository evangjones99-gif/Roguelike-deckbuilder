import os,json,time,pathlib,hashlib,stat
base=pathlib.Path('/workspace/scratch')
pin=json.loads((base/'git-immutable-pack-cache-hint-author-r1/METADATA-INTAKE.json').read_text())
target=pathlib.Path(pin['path']); fds=[]; fd=None
try:
 flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
 fds.append(os.open('/',flags)); chain=[]
 for name in str(target.parent).split('/')[1:]:
  fds.append(os.open(name,flags,dir_fd=fds[-1])); s=os.fstat(fds[-1]); chain.append({'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid})
 assert chain==pin['parentChain']
 fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC,dir_fd=fds[-1]); s=os.fstat(fd)
 assert {k:getattr(s,k) for k in pin['metadata']}==pin['metadata']
 assert {n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)}==pin['xattrs']
 assert s==os.stat(target.name,dir_fd=fds[-1],follow_symlinks=False)
finally:
 if fd is not None:os.close(fd)
 for fd in reversed(fds):os.close(fd)
source=base/'standard-sol-pc-immutable-pack-cache-advice-author-r1/immutable_pack_hint.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='899b7e4696f759361897c888e0ceb0a4969632e9ff9190a178bb5e9a848f71b3'
d=json.loads((base/'standard-sol-pc-immutable-pack-cache-advice-author-r1/DECLARATION-TEMPLATE-NOT-A-GRANT.json').read_text())
d['issuedUnixSeconds']=time.time()
for k in ('priorPushConfirmed','exclusiveKnownRepoWritersHeld','repositoryMaintenanceHeld','noUnknownAffectedWriter','noUnknownAffectedLockOwner','noHeavyRuntimeConcurrent'):d[k]=True
d['confirmedPush']='496c60fd6f8a75307986de28d7e56c80a18c9b87'
d['coordination']='ROOT known affected quiet window: all game source writers closed; active agents instructed no Git/pack/maintenance/Node/browser/build; proc non-zombie observation found no active heavy/pack workers. Existing confirmed remote496c60f receipt; no new Git call. Current anchored parent and target metadata exact, FD closed. Known coordination only, not global reader absence or lock exclusivity. One sampled24+512 guarded hint; all samples/final must pass and complete durable receipts before any separate640+512 browser admission. No deletion.'
p=base/'git-immutable-pack-cache-hint-pc-ROOT-DECLARATION-r1.json'
with p.open('x') as f:f.write(json.dumps(d,indent=2)+'\n');f.flush();os.fsync(f.fileno())
fd=os.open(base,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print('fresh declaration written; pinned metadata exact; target FD closed')
