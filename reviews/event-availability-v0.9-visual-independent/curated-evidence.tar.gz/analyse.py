import pathlib,json,gzip,math
p=pathlib.Path('/workspace/scratch/event-availability-visual-independent-v09-r1');rows=[json.loads(gzip.decompress(f.read_bytes()))for f in sorted(p.glob('r2-context-*.json.gz'))];pairs=[];count=0
for w in [360,390,760,1440]:
 b=next(r for r in rows if r['width']==w and r['variant']=='baseline');c=next(r for r in rows if r['width']==w and r['variant']=='candidate');normalb=b['states'][-1];normalc=c['states'][-1]
 assert all(normalb[k]==normalc[k]for k in ['hand','units','canvas']);assert b['dossier']==c['dossier'] and b['relic']==c['relic'];deltas=[]
 for sb,sc in zip(b['states'][:2],c['states'][:2]):
  for cb,cc in zip(sb['choices'],sc['choices']):
   assert cb['id']==cc['id'] and cb['disabled']==cc['disabled'];count+=1
   for i in [0,1]:assert cb['nodes'][i]['value']==cc['nodes'][i]['value'] and cb['nodes'][i]['font']==cc['nodes'][i]['font']
   if not cc['disabled']:
    assert cb['opacity']==cc['opacity'] and cb['background']==cc['background'];assert cb['nodes'][2]['font']==cc['nodes'][2]['font']
    if cb['box']!=cc['box']:deltas.append({'state':sb['name'],'id':cc['id'],'baseline':cb['box'],'candidate':cc['box'],'deltaY':cc['box']['y']-cb['box']['y'],'deltaHeight':cc['box']['height']-cb['box']['height']})
  labels={x['id']:x['nodes'][-1]['value']for x in sc['choices']};name=sc['name'];expected={'owned-cap':{'offering':'Wraithglass Shard already owned','bargain':'30 → 0 gold · +1 health'},'health8':{'offering':'Requires at least 9 health'},'multiple':{'offering':'Wraithglass Shard already owned','purge':'Requires at least 5 health','bargain':'Requires 30 gold'},'five':{'purge':'Keep at least 5 cards'},'full-no-scour':{'purge':'No unenhanced Scour to remove','bargain':'Already at full health'},'poor':{'bargain':'Requires 30 gold'},'heal16':{'bargain':'65 → 35 gold · +16 health'},'missing-scour':{'purge':'No unenhanced Scour to remove'}}[name]
  for k,v in expected.items():assert labels[k]==v,(name,k,labels[k],v)
 pairs.append({'width':w,'normalBattleGeometryExact':True,'dossierRelicTextFontPortraitExact':True,'enabledBoxDeltas':deltas})
def lum(rgb):
 c=[x/255 for x in rgb];c=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in c];return sum(x*y for x,y in zip(c,[.2126,.7152,.0722]))
bg=lum([16,25,29]);contrasts={k:(lum(v)+.05)/(bg+.05)for k,v in [('reason',[226,216,189]),('description',[157,165,161])]}
r={'pairs':pairs,'pairedChoiceObservations':count,'candidateChoiceObservations':count,'actualActions':sum(len(r['actions'])for r in rows),'contrastComputedOpaqueStaticOnly':contrasts,'allReasonsMatch':True,'candidateGlyphContainmentAndParagraphFooterChecks':'All5choices×8eventstates=40candidatecards, source range-rects inside actualcards, no paragraph-footer overlap, no horizontal document overflow. Browser may hover inherited baseline cards by residual pointer; displayedgeometry deltas record that fact, not CSS regression.'};(p/'ANALYSIS.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
