// Source prepared only. All decisions come from observed public UI, never engine imports.
import fs from 'node:fs/promises';
import path from 'node:path';
import readline from 'node:readline';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const HERE=path.dirname(fileURLToPath(import.meta.url));
assert.equal(process.argv[2],'--root-browser-grant');
const [variant,mode,checkpointPath]=process.argv.slice(3);
assert(['candidate','baseline'].includes(variant)&&['new','resume'].includes(mode));
assert.equal(process.argv.length,mode==='new'?5:6);
const intake=JSON.parse(await fs.readFile(path.join(HERE,'INTAKE.json'),'utf8'));
const spec=intake[variant],run=process.env.HP_PHASE_DIR;
const initial=Number(process.env.HP_PHASE_INITIAL),maximum=Number(process.env.HP_PHASE_MAX);
assert(Number.isSafeInteger(initial)&&Number.isSafeInteger(maximum)&&run&&path.dirname(run)===HERE,'outer guard required');
const M=1048576,work=640*M,reserve=512*M,evidenceLimit=16*M;
const H=b=>crypto.createHash('sha256').update(b).digest('hex');
const profile=path.join(HERE,'profile-'+variant+'-104729-hunter');
const checkpoint=mode==='resume'?JSON.parse(await fs.readFile(checkpointPath,'utf8')):null;
if(checkpoint){
  assert.equal(checkpoint.variant,variant);assert.equal(checkpoint.profile,profile);
  assert.equal(checkpoint.sourceDigest,spec.sourceDigest);assert.equal(checkpoint.orderlyContextClosed,true);
  assert.equal(checkpoint.seed,104729);assert.equal(checkpoint.difficulty,'Hunter');
  assert(/^[a-f0-9]{64}$/.test(checkpoint.saveSHA256),'resume requires exact opaque hash');
  assert((await fs.stat(profile)).isDirectory());
}else await fs.mkdir(profile,{recursive:false});
const audit=JSON.parse(await fs.readFile(path.join(HERE,'AUDIT-before.json'),'utf8'));
assert.equal(audit.variants[variant].sourceDigest,spec.sourceDigest,'fresh before audit required');
const log=await fs.open(path.join(run,'ACTIONS.jsonl'),'wx');
let bytes=0,sequence=0,context,page,lines,pointerHeld=false,stopping=false,finished=false,proposedCheckpoint;
let logTail=Promise.resolve(),observerFailure=null;
function record(row){
  logTail=logTail.then(async()=>{
    const b=Buffer.from(JSON.stringify({sequence:sequence++,wallUTC:new Date().toISOString(),monotonicMs:performance.now(),...row})+'\n');
    assert(bytes+b.length<=evidenceLimit,'evidence budget');await log.write(b);await log.sync();bytes+=b.length;
  });
  return logTail;
}
async function sample(label){
  const current=Number(await fs.readFile('/sys/fs/cgroup/memory.current','utf8'));
  const observedMax=Number(await fs.readFile('/sys/fs/cgroup/memory.max','utf8'));
  const v=await fs.statfs(HERE);
  const row={label,current,maximum:observedMax,initial,delta:current-initial,headroom:observedMax-current,diskFree:v.bavail*v.bsize};
  assert(observedMax===maximum&&row.delta<=work&&row.headroom>=reserve&&row.diskFree>=M,'active whole-phase resource guard '+JSON.stringify(row));
  return row;
}
async function observation(){
  return page.evaluate(async()=>{
    const shown=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
    const detail=e=>({tag:e.tagName,text:(e.innerText||'').slice(0,1500),label:e.getAttribute('aria-label'),dataset:{...e.dataset},disabled:e.disabled,ariaDisabled:e.getAttribute('aria-disabled'),type:e.getAttribute('type'),name:e.getAttribute('name'),value:e instanceof HTMLInputElement?e.value:undefined,classes:e.className,box:(()=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height}})()});
    const raw=localStorage.getItem('hollowpact.run.v2');
    if(raw!==null&&raw.length>1048576)throw Error('opaque save observation bound');
    const saveSHA256=raw===null?null:[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(raw)))].map(n=>n.toString(16).padStart(2,'0')).join('');
    return{viewport:{width:innerWidth,height:innerHeight},visibleText:document.body.innerText.slice(0,22000),controls:[...document.querySelectorAll('button,input,label,[data-tactile-drop-zone]')].filter(shown).slice(0,200).map(detail),preview:document.querySelector('#consequence-preview')?.textContent||null,tactilePreview:document.querySelector('.tactile-preview')?.textContent||null,ghosts:[...document.querySelectorAll('.tactile-ghost')].map(detail),announcer:document.querySelector('#announcer')?.textContent||null,dialog:document.querySelector('dialog[open]')?.innerText||null,focus:document.activeElement?detail(document.activeElement):null,saveSHA256,saveCharacters:raw?.length??0,events:window.__independentPCEvents.splice(0)};
  });
}
async function locate(c,{hover=true}={}){
  assert(typeof c.selector==='string'&&c.selector.length<=500);
  assert(Number.isInteger(c.index??0)&&(c.index??0)>=0&&(c.index??0)<200);
  const loc=page.locator(c.selector).nth(c.index??0);
  assert(await loc.isVisible()&&!await loc.isDisabled(),'visible enabled control required');
  const identity=await loc.evaluate(e=>Object.fromEntries(['card','index','revision','unit','uid'].filter(k=>e.dataset[k]!==undefined).map(k=>[k,e.dataset[k]])));
  if(c.occurrence)assert.deepEqual(identity,c.occurrence,'public occurrence mismatch');
  let box=await loc.boundingBox();assert(box&&box.width&&box.height);
  const viewport=page.viewportSize();
  assert(box.x>=0&&box.y>=0&&box.x+box.width<=viewport.width&&box.y+box.height<=viewport.height,'control offscreen; use actual wheel separately');
  if(hover){await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.waitForTimeout(220);box=await loc.boundingBox();assert(box);}
  assert.deepEqual(await loc.evaluate(e=>Object.fromEntries(['card','index','revision','unit','uid'].filter(k=>e.dataset[k]!==undefined).map(k=>[k,e.dataset[k]]))),identity,'occurrence changed while hovering');
  const x=box.x+box.width/2,y=box.y+box.height/2;
  assert(x>=0&&y>=0&&x<viewport.width&&y<viewport.height);
  assert(await loc.evaluate((e,p)=>{const hit=document.elementFromPoint(p.x,p.y);return e===hit||e.contains(hit)},{x,y}),'center obstructed; stop rather than force');
  return{loc,x,y,identity};
}
async function shutdown(signal){
  stopping=true;observerFailure=observerFailure||new Error('external stop '+signal);lines?.close();
  await record({kind:'EXTERNAL_STOP',signal}).catch(()=>{});
  await context?.close().catch(()=>{});
}
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{void shutdown(signal)});
try{
  await record({kind:'ADMISSION-active-outer-budget',variant,mode,seed:104729,difficulty:'Hunter',sourceDigest:spec.sourceDigest,profile,checkpointPath,initial,maximum,work,reserve,harnessSHA256:H(await fs.readFile(fileURLToPath(import.meta.url))),resource:await sample('before-playwright-import'),independence:intake.independence});
  const {chromium}=await import('/workspace/Roguelike-deckbuilder/node_modules/playwright/index.mjs');
  await record({kind:'IMPORTS_ACCOUNTED',resource:await sample('after-playwright-import')});
  assert(!stopping);
  context=await chromium.launchPersistentContext(profile,{executablePath:'/usr/bin/chromium',args:['--no-sandbox'],viewport:{width:1440,height:900},deviceScaleFactor:1,handleSIGINT:false,handleSIGTERM:false});
  await context.addInitScript(()=>{
    window.__independentPCEvents=[];
    for(const type of ['pointerdown','pointerup','pointercancel','click','keydown','keyup','input','change','focusin'])document.addEventListener(type,e=>{
      const t=e.target;
      window.__independentPCEvents.push({type,isTrusted:e.isTrusted,key:e.key,x:e.clientX,y:e.clientY,ui:t.closest?.('[data-ui]')?.dataset.ui,action:t.closest?.('[data-action]')?.dataset.action,unit:t.closest?.('[data-unit]')?.dataset.unit,card:t.closest?.('[data-card]')?.dataset.card,index:t.closest?.('[data-index]')?.dataset.index,at:performance.now()});
      if(window.__independentPCEvents.length>1000)window.__independentPCEvents.splice(0,500);
    },true);
  });
  page=context.pages()[0]||await context.newPage();
  page.on('pageerror',e=>{observerFailure=e;void record({kind:'PAGE_ERROR',error:e.stack}).catch(()=>{})});
  page.on('requestfailed',r=>{void record({kind:'REQUEST_FAILED',URL:r.url(),failure:r.failure()}).catch(()=>{})});
  const served=await page.request.get(spec.URL+'/build-provenance.json');assert(served.ok());
  assert.equal((await served.json()).sourceDigest,spec.sourceDigest,'served source digest mismatch');
  await page.goto(spec.URL,{waitUntil:'domcontentloaded'});
  await page.locator('[data-ui="new"]').first().waitFor({timeout:15000});
  const ready=await observation();
  if(checkpoint)assert.equal(ready.saveSHA256,checkpoint.saveSHA256,'orderly saved opaque bytes changed before actual Continue');
  else assert.equal(ready.saveSHA256,null,'new profile must not contain a preexisting run');
  await record({kind:'READY',observation:ready,resource:await sample('browser-ready')});
  console.log(JSON.stringify({ready:true,variant,mode,run,observation:ready}));
  lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
  for await(const line of lines){
    if(!line.trim())continue;
    let c;
    try{
      c=JSON.parse(line);assert(typeof c.command==='string');
      assert(!stopping&&!observerFailure,'previous observer failure; stop');
      const before=await observation();
      const active=['click','hover','key','type','wheel','dragBegin','dragMove','dragEnd','reload'].includes(c.command);
      if(active){
        assert(Object.hasOwn(c,'expectedSaveSHA256'),'action requires exact prior opaque save hash, including null');
        assert.equal(before.saveSHA256,c.expectedSaveSHA256,'save changed since decision; stop batch');
        assert(typeof c.rationale==='string'&&c.rationale.length>=8&&c.rationale.length<=1800,'visible-evidence rationale required');
      }
      await record({kind:'BEFORE',command:c,observation:before,resource:await sample('before-command')});
      const start=performance.now();
      if(c.command==='click'){
        assert(!pointerHeld);const {x,y}=await locate(c);await page.mouse.move(x,y);await page.mouse.down();await page.waitForTimeout(60);await page.mouse.up();
      }else if(c.command==='hover'){
        assert(!pointerHeld);await locate(c);
      }else if(c.command==='key'){
        assert(typeof c.key==='string'&&c.key.length<=50);await page.keyboard.press(c.key);
      }else if(c.command==='type'){
        assert(!pointerHeld&&typeof c.text==='string'&&c.text.length<=100);await page.keyboard.type(c.text,{delay:35});
      }else if(c.command==='wheel'){
        assert(!pointerHeld&&Number.isFinite(c.x)&&Number.isFinite(c.y)&&Math.abs(c.x)<=1500&&Math.abs(c.y)<=1500);await page.mouse.wheel(c.x,c.y);
      }else if(c.command==='dragBegin'){
        assert(!pointerHeld);const {loc,x,y}=await locate(c);
        assert(await loc.evaluate(e=>!!e.closest('.hand-cards')&&e.dataset.ui==='play-card'),'visible hand card required');
        await page.mouse.move(x,y);await page.mouse.down();pointerHeld=true;
        await page.mouse.move(x+14,y-14,{steps:4});await page.waitForTimeout(120);
      }else if(c.command==='dragMove'){
        assert(pointerHeld);let point;
        if(c.selector){const {x,y}=await locate(c,{hover:false});point={x,y};}
        else{assert(Number.isFinite(c.x)&&Number.isFinite(c.y)&&c.x>=0&&c.x<1440&&c.y>=0&&c.y<900);point={x:c.x,y:c.y};}
        await page.mouse.move(point.x,point.y,{steps:16});await page.waitForTimeout(180);
      }else if(c.command==='dragEnd'){
        assert(pointerHeld);await page.mouse.up();pointerHeld=false;
      }else if(c.command==='wait'){
        assert(Number.isInteger(c.ms)&&c.ms>=0&&c.ms<=2000);await page.waitForTimeout(c.ms);
      }else if(c.command==='reload'){
        assert(!pointerHeld);await page.reload({waitUntil:'domcontentloaded'});
      }else if(c.command==='shot'){
        assert(/^[a-z0-9-]{1,50}$/.test(c.label));
        const image=await page.screenshot({type:'jpeg',quality:78,fullPage:false});
        assert(bytes+image.length<=evidenceLimit);const file=path.join(run,sequence+'-'+c.label+'.jpg');
        await fs.writeFile(file,image,{flag:'wx'});bytes+=image.length;
        await record({kind:'CAPTURE',file,bytes:image.length,sha256:H(image),viewportOnly:true,duringHeldPointer:pointerHeld,personallyViewed:false,diagnostic:'Capture may perturb timing; no full-page resize'});
      }else if(c.command==='note'){
        assert(typeof c.text==='string'&&c.text.length<=3000);
      }else if(c.command==='finish'){
        assert(!pointerHeld,'finish only after actual release/cancel');
      }else assert.equal(c.command,'observe','unknown command');
      const after=await observation();
      if(c.expectUnchanged===true)assert.equal(after.saveSHA256,before.saveSHA256,'cancel/inspect altered opaque save unexpectedly');
      await record({kind:'AFTER',command:c,elapsedMs:performance.now()-start,observation:after,resource:await sample('after-command')});
      console.log(JSON.stringify({completed:c.command,sequence,observation:after}));
      if(c.command==='finish'){
        assert(/^[a-f0-9]{64}$/.test(after.saveSHA256),'orderly campaign checkpoint needs saved run');
        proposedCheckpoint={variant,profile,sourceDigest:spec.sourceDigest,seed:104729,difficulty:'Hunter',saveSHA256:after.saveSHA256,saveCharacters:after.saveCharacters,viewport:after.viewport,lastSequence:sequence,run};
        finished=true;lines.close();break;
      }
    }catch(e){
      await record({kind:'COMMAND_FAILED',command:c||line.slice(0,1800),error:e.stack}).catch(()=>{});
      console.log(JSON.stringify({commandFailed:true,error:e.message,stopped:true}));lines.close();throw e;
    }
  }
  assert(finished&&!stopping&&!observerFailure,'EOF/stop without orderly finish; retain partial phase');
}catch(e){
  stopping=true;process.exitCode=1;await record({kind:'RUN_FAILED',error:e.stack}).catch(()=>{});
}finally{
  lines?.close();
  let closeError=null;
  try{await context?.close();}catch(e){closeError=e;process.exitCode=1;}
  await record({kind:'CONTEXT_CLOSED',closeError:closeError?.stack||null,orderly:finished&&!stopping&&!closeError}).catch(()=>{});
  if(proposedCheckpoint&&finished&&!stopping&&!closeError){
    const data=Buffer.from(JSON.stringify({...proposedCheckpoint,orderlyContextClosed:true,closedWallUTC:new Date().toISOString()},null,2)+'\n');
    const file=await fs.open(path.join(run,'CHECKPOINT.json'),'wx');try{await file.writeFile(data);await file.sync();}finally{await file.close();}
    console.log(JSON.stringify({orderlyCheckpoint:path.join(run,'CHECKPOINT.json'),sha256:H(data)}));
  }
  await logTail.catch(()=>{});await log.close();
}
