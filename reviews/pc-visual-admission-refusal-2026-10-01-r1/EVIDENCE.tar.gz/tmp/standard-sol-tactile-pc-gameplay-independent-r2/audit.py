"""Future readonly streamed game identity check; no game import or execution."""
import os,sys,pathlib,json,hashlib,stat,resource
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
HERE=pathlib.Path(__file__).resolve().parent
assert len(sys.argv)==2 and sys.argv[1] in ('before','after')
phase=sys.argv[1]
def guard():
    cg=pathlib.Path('/sys/fs/cgroup');maximum=int((cg/'memory.max').read_text());current=int((cg/'memory.current').read_text())
    status={x.split(':')[0]:int(x.split()[1])*1024 for x in pathlib.Path('/proc/self/status').read_text().splitlines() if x.startswith(('VmRSS:','VmHWM:'))}
    assert maximum-current>=536*1048576 and max(status.values())<=24*1048576
    return dict(current=current,maximum=maximum,ownMemory=status)
def stamp(s):return {k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns')}
def read(p,small=False):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC)
    try:
        before=os.fstat(fd);assert stat.S_ISREG(before.st_mode)
        assert not small or before.st_size<=131072
        h=hashlib.sha256();parts=[];length=0
        while chunk:=os.read(fd,32768):
            h.update(chunk);length+=len(chunk)
            if small:parts.append(chunk)
        after=os.fstat(fd)
        assert length==before.st_size and stamp(before)==stamp(after)==stamp(os.stat(p,follow_symlinks=False))
        result=dict(bytes=length,sha256=h.hexdigest(),metadata=stamp(after))
        return (result,b''.join(parts)) if small else result
    finally:os.close(fd)
def list_files(root,sub):
    result=[]
    for p in sorted((root/sub).rglob('*')):
        mode=p.lstat().st_mode;assert not stat.S_ISLNK(mode)
        if stat.S_ISREG(mode):result.append(str(p.relative_to(root)))
        else:assert stat.S_ISDIR(mode)
    return result
initial=guard();intake=json.loads(read(HERE/'INTAKE.json',True)[1]);result={}
for variant in ('candidate','baseline'):
    spec=intake[variant];root=pathlib.Path(spec['root'])
    provenance=json.loads(read(root/'dist/build-provenance.json',True)[1])
    assert provenance['sourceDigest']==spec['sourceDigest']
    hashes=spec['inputs'] if variant=='candidate' else provenance['hashes']
    assert len(hashes)==(87 if variant=='candidate' else 78)
    inputs={name:read(root/name) for name in sorted(hashes)}
    actual={name:row['sha256'] for name,row in inputs.items()}
    digest=hashlib.sha256(json.dumps(actual,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    assert actual==hashes==provenance['hashes'] and digest==spec['sourceDigest']
    outputs={name[5:]:read(root/name) for name in list_files(root,'dist')}
    assert len(outputs)==56
    if variant=='candidate':assert {name:row['sha256'] for name,row in outputs.items()}==spec['outputs']
    result[variant]=dict(root=str(root),sourceDigest=digest,inputs=inputs,outputs=outputs)
    guard()
if phase=='after':
    prior=json.loads(read(HERE/'AUDIT-before.json',True)[1])
    # HTTP may legitimately update atime during earned play; compare exact bytes and all other metadata.
    for variant in result:
        for group in ('inputs','outputs'):
            for name,row in result[variant][group].items():
                old=prior['variants'][variant][group][name]
                assert row['bytes']==old['bytes'] and row['sha256']==old['sha256']
                assert {k:v for k,v in row['metadata'].items() if k!='st_atime_ns'}=={k:v for k,v in old['metadata'].items() if k!='st_atime_ns'}
report=dict(phase=phase,variants=result,initialGuard=initial,finalGuard=guard(),packBodiesRead=False,GitCommands=0)
data=(json.dumps(report,separators=(',',':'))+'\n').encode();assert len(data)<=131072
v=os.statvfs(HERE);assert v.f_bavail*v.f_frsize>=1048576+len(data)
with (HERE/('AUDIT-'+phase+'.json')).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
print(json.dumps({'phase':phase,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}))
