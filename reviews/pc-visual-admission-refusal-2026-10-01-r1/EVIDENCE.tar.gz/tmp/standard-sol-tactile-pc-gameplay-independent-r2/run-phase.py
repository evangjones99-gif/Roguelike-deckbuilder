"""Prepared outer live guard. Run only after ROOT's explicit exclusive grant."""
import os, sys, json, time, pathlib, subprocess, signal, resource

HERE = pathlib.Path(__file__).resolve().parent
M = 1048576
WORK, RESERVE = 640*M, 512*M
assert len(sys.argv) in (5, 6), 'grant variant new|resume [checkpoint]'
assert sys.argv[1] == '--root-browser-grant'
variant, mode, phase = sys.argv[2:5]
assert variant in ('candidate', 'baseline') and mode in ('new', 'resume')
assert phase.isascii() and phase.replace('-', '').isalnum() and len(phase) <= 50
assert (mode == 'resume') == (len(sys.argv) == 6)
cg = pathlib.Path('/sys/fs/cgroup')
raw_initial = int((cg/'memory.current').read_text())
maximum = int((cg/'memory.max').read_text())
own_rss = int(next(x.split()[1] for x in pathlib.Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024
# Conservatively charge existing wrapper RSS to phase work as well as all Node imports.
initial = raw_initial-own_rss
out = HERE/('phase-'+variant+'-'+phase)
out.mkdir(mode=0o700)
receipts = (out/'RESOURCE.jsonl').open('xb', buffering=0)
used = 0
def emit(row):
    global used
    b = (json.dumps({'wallUnixSeconds':time.time(), **row}, separators=(',', ':'))+'\n').encode()
    assert used+len(b) <= 4*M, 'resource receipt budget'
    receipts.write(b); os.fsync(receipts.fileno()); used += len(b)
def sample(label):
    current = int((cg/'memory.current').read_text())
    observed_max = int((cg/'memory.max').read_text())
    v = os.statvfs(HERE)
    row = dict(label=label, current=current, maximum=observed_max, initial=initial,
               rawInitial=raw_initial, initialWrapperRSS=own_rss, delta=current-initial,
               headroom=observed_max-current, work=WORK, reserve=RESERVE,
               diskFree=v.f_bavail*v.f_frsize)
    row['ok'] = observed_max == maximum and row['delta'] <= WORK and row['headroom'] >= RESERVE and row['diskFree'] >= M
    return row

child = None
owned = {}
def identity(pid):
    # Only this phase's descendants; never a global process enumeration.
    text = pathlib.Path('/proc', str(pid), 'stat').read_text()
    return text[text.rfind(')')+2:].split()[19]
def remember_tree(pid):
    try:
        owned[pid] = identity(pid)
        children = pathlib.Path('/proc', str(pid), 'task', str(pid), 'children').read_text().split()
        for item in children: remember_tree(int(item))
    except (FileNotFoundError, ProcessLookupError): pass
def live_owned():
    result = []
    for pid, start in list(owned.items()):
        try:
            state_text = pathlib.Path('/proc', str(pid), 'stat').read_text()
            state = state_text[state_text.rfind(')')+2:].split()[0]
            if identity(pid) == start and state != 'Z': result.append(pid)
        except (FileNotFoundError, ProcessLookupError): pass
    return result
def close_owned():
    if child is None: return
    remember_tree(child.pid)
    if child.poll() is None:
        child.send_signal(signal.SIGTERM)
        until = time.monotonic()+2
        while child.poll() is None and time.monotonic() < until: time.sleep(.05)
    for signum in (signal.SIGTERM, signal.SIGKILL):
        for pid in reversed(live_owned()):
            try: os.kill(pid, signum)
            except ProcessLookupError: pass
        if signum == signal.SIGTERM: time.sleep(.25)
    if child.poll() is None: child.wait(timeout=2)
    return live_owned()

failed = None
stdout = stderr = None
try:
    admission = sample('ADMISSION-before-Node-imports')
    emit(admission)
    assert maximum-raw_initial >= WORK+RESERVE and admission['ok'], 'fresh whole-phase640+512 admission refused'
    assert admission['diskFree'] >= 64*M+M, 'bounded evidence/free disk admission refused'
    env = dict(os.environ, HP_PHASE_INITIAL=str(initial), HP_PHASE_MAX=str(maximum), HP_PHASE_DIR=str(out))
    command = ['node', str(HERE/'observe.mjs'), '--root-browser-grant', variant, mode]
    if mode == 'resume': command.append(str(pathlib.Path(sys.argv[5]).resolve()))
    stdout = (out/'stdout.jsonl').open('xb', buffering=0)
    stderr = (out/'stderr.log').open('xb', buffering=0)
    # Preserve interactive feedback and exact stdout concurrently without a runner or trace.
    child = subprocess.Popen(command, stdin=None, stdout=subprocess.PIPE, stderr=stderr, env=env,
                             start_new_session=True, bufsize=0)
    os.set_blocking(child.stdout.fileno(), False)
    output_bytes = 0
    def drain():
        global output_bytes
        while True:
            try: data = os.read(child.stdout.fileno(), 32768)
            except BlockingIOError: return
            if not data: return
            output_bytes += len(data)
            assert output_bytes <= 16*M, 'stdout budget'
            stdout.write(data); sys.stdout.buffer.write(data); sys.stdout.buffer.flush()
    tick = 0
    while child.poll() is None:
        remember_tree(child.pid)
        row = sample('LIVE')
        if not row['ok']:
            emit({'kind':'GUARD_FAILURE', **row})
            raise RuntimeError('whole-phase guard breached: '+json.dumps(row))
        if tick % 10 == 0: emit(row)
        assert os.fstat(stderr.fileno()).st_size <= 2*M, 'stderr budget'
        drain(); tick += 1; time.sleep(.1)
    drain()
    emit({'kind':'NODE_EXIT', 'exitCode':child.returncode, **sample('after-node-exit')})
    assert child.returncode == 0, 'Node observer failed; preserve phase and stop'
except BaseException as e:
    failed = {'type':type(e).__name__, 'error':str(e), 'nodeStarted':child is not None}
    try: emit({'kind':'FAILURE', **failed})
    except BaseException: pass
finally:
    try:
        remaining = close_owned() if child is not None else []
        emit({'kind':'OWNED_READERS_CLOSED', 'remainingSameIdentityPIDs':remaining,
              'orderlyNodeExit':child is not None and child.returncode == 0, 'failure':failed})
        if remaining: failed = failed or {'type':'RemainingDescendants','error':str(remaining)}
    finally:
        for file in (stdout, stderr, receipts):
            if file is not None: file.close()
if failed: raise SystemExit(1)
