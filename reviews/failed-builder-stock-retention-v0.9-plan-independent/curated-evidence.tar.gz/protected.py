from pathlib import Path
import hashlib,json,os
O=Path('/workspace/scratch/failed-builder-stock-retention-independent-r1');stage=Path('/tmp/hollowpact-final-kill-v09-root-r1');proof=Path('/workspace/Roguelike-deckbuilder/reviews/root-v0.9-asar-builder-investigation');sha=lambda b:hashlib.sha256(b).hexdigest();runtime=json.load(open(stage/'dist/build-provenance.json'));assert runtime['sourceDigest']=='8a33f950ed57093a222baf9b7883a5c1ccf2deb2e8412429ef0fe05d370467cb';assert len(runtime['hashes'])==77;assert sha(json.dumps(runtime['hashes'],separators=(',',':')).encode())==runtime['sourceDigest'];rows=[]
for n,h in runtime['hashes'].items():
 p=stage/n;b=p.read_bytes();assert sha(b)==h;rows.append({'path':str(p),'bytes':len(b),'sha256':h,'symlink':str(p.readlink())if p.is_symlink()else None})
outputs=[]
for p in sorted((stage/'dist').rglob('*')):
 if p.is_file():
  b=p.read_bytes();outputs.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
assert len(outputs)==55
logs=[]
for n in ['PREBUILD.json','BUILDER-r1.log','FAILED-STOCK-RETENTION-PROPOSAL.json','FAILED-STOCK-RETENTION-PROPOSAL-R2.json']:
 p=proof/n
 if p.exists():
  b=p.read_bytes();logs.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
(O/'PROTECTED.json').open('x').write(json.dumps({'sourceRuntime':runtime['sourceDigest'],'sourceInputs':rows,'buildOutputs':outputs,'rawLogsProposals':logs,'sourceDesktopAncestorSymlink':{'path':str(stage/'desktop'),'target':str((stage/'desktop').readlink())if(stage/'desktop').is_symlink()else None},'cacheQualification':'Build/dependency caches, art/research/archives/source trees are outside69failedPath replacement scope; no full global cache audit or backup claimed.'},indent=2)+'\n');print(json.dumps({'sourceInputs':len(rows),'outputs':len(outputs),'rawLogsAndProposals':len(logs),'sourceDesktopSymlink':str((stage/'desktop').readlink())if(stage/'desktop').is_symlink()else None}))
