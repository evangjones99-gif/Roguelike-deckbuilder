from pathlib import Path
import hashlib,json,os,stat,time
O=Path('/workspace/scratch/failed-builder-stock-retention-independent-r1');Q=Path('/workspace/Roguelike-deckbuilder/reviews/root-v0.9-asar-builder-investigation/FAILED-STOCK-RETENTION-PROPOSAL-R2.json');raw=Q.read_bytes();q=json.loads(raw);failed=Path('/tmp/hollowpact-asar-builder-order-v09-root-r1/linux-unpacked');reference=Path('/tmp/hollowpact-relic-bone-native-v09-r1/linux-unpacked');H=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
fields=['st_dev','st_ino','st_nlink','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_blocks'];recorded=[k for k in fields if k not in ['st_size','st_blocks']]
def metadata(p):
 s=p.lstat();return {k:getattr(s,k)for k in fields}|{'atimeNs':s.st_atime_ns,'xattrs':{n:os.getxattr(p,n).hex()for n in os.listxattr(p)}}
def regularAncestors(p,root):
 assert p.is_relative_to(root);assert p.absolute()==p and '..'not in p.parts
 for d in [root,*p.relative_to(root).parents]:
  actual=root/d if not d.is_absolute()else d
  if actual==p:continue
  s=actual.lstat();assert stat.S_ISDIR(s.st_mode)and not actual.is_symlink(),str(actual)
 return True
assert len(q['pairs'])==69;assert len({r['failedPath']for r in q['pairs']})==69;assert len({r['dependencyReference']for r in q['pairs']})==69
rows=[]
for r in q['pairs']:
 f=Path(r['failedPath']);t=Path(r['dependencyReference']);regularAncestors(f,failed);regularAncestors(t,reference);assert f.relative_to(failed)==t.relative_to(reference);assert not str(f.relative_to(failed)).startswith('resources/');assert f.name!='LICENSE.electron.txt';a=metadata(f);b=metadata(t);assert stat.S_ISREG(a['st_mode'])and stat.S_ISREG(b['st_mode']);assert a['st_nlink']==1;assert a['st_ino']!=b['st_ino'];assert a['st_dev']==b['st_dev'];assert a['st_uid']==b['st_uid']==os.getuid();assert a['st_gid']==b['st_gid']==os.getgid();assert a['st_mode']==b['st_mode'];assert a['st_size']==b['st_size']==r['bytes'];assert a['xattrs']==b['xattrs'];assert not a['xattrs'],f
 for n in recorded:assert a[n]==r['failedMetadata'][n]and b[n]==r['referenceMetadata'][n],(f,n)
 ah=H(f);bh=H(t);assert ah==bh==r['sha256'];afterA=metadata(f);afterB=metadata(t);assert {k:v for k,v in afterA.items()if k!='atimeNs'}=={k:v for k,v in a.items()if k!='atimeNs'};assert {k:v for k,v in afterB.items()if k!='atimeNs'}=={k:v for k,v in b.items()if k!='atimeNs'};rows.append({'path':str(f.relative_to(failed)),'failed':{'path':str(f),'sha256':ah,'metadata':a,'atimeAfterRead':afterA['atimeNs']},'reference':{'path':str(t),'sha256':bh,'metadata':b,'atimeAfterRead':afterB['atimeNs']}})
assert sum(r['failed']['metadata']['st_size']for r in rows)==q['recoverableBytes']==296216836
allfiles={str(p.relative_to(failed)):p for p in failed.rglob('*')if p.is_file()or p.is_symlink()};excluded=[];assert set(allfiles)=={r['path']for r in rows}|{r['path']for r in q['excluded']}
for n in sorted(set(allfiles)-{r['path']for r in rows}):
 p=allfiles[n];meta=metadata(p);excluded.append({'path':n,'metadata':meta,'symlink':str(p.readlink())if p.is_symlink()else None,'sha256':H(p),'bytesFollowed':p.stat().st_size})
# Record full directory memberships and modes/metadata; failed parent times change at replacement.
dirs={}
for root in [failed,reference]:
 for d in [root,*[p for p in root.rglob('*')if p.is_dir()and not p.is_symlink()]]:
  dirs[str(d)]={'metadata':metadata(d),'members':sorted(p.name for p in d.iterdir())}
# Bound own FD inspection and disclose denied processes, never claim a global lock.
paths={r['failed']['path']for r in rows}|{r['reference']['path']for r in rows};handles=[];denied=[];examined=0
for process in Path('/proc').iterdir():
 if not process.name.isdigit():continue
 try:
  for fd in (process/'fd').iterdir():
   try:
    target=os.readlink(fd);examined+=1
    if target in paths:handles.append({'pid':process.name,'fd':fd.name,'target':target})
   except (PermissionError,FileNotFoundError):pass
 except PermissionError:denied.append(process.name)
 except FileNotFoundError:pass
snapshot={'proposalPath':str(Q),'proposalSHA256':hashlib.sha256(raw).hexdigest(),'pairs':rows,'excluded':excluded,'allFailedFiles':len(allfiles),'directories':dirs,'FDInspection':{'examined':examined,'matchingHandles':handles,'deniedProcessCount':len(denied),'deniedPIDs':denied,'qualification':'Own incomplete read-only /proc observation, not a global reader absence or lock'},'recovery':{'duplicateLogicalBytes':sum(r['failed']['metadata']['st_size']for r in rows),'failedAllocatedBlocksBytes':sum(r['failed']['metadata']['st_blocks']*512 for r in rows),'symlinkBlocksUnknownBeforeTransaction':True},'atimeQualification':'Read-only hashing may change access timestamps; audit preserves observed before/after atime separately. Root metadata invariance promises cover mode/owner/device/inode/nlink/mtime/ctime/xattrs, not access time.'}
(O/'AUDIT.json').open('x').write(json.dumps(snapshot,indent=2)+'\n');(O/'PROPOSAL-R2.json').open('xb').write(raw);print(json.dumps({'pairs':len(rows),'fullRawBytesHashedEachSide':q['recoverableBytes'],'excluded':len(excluded),'failedFiles':len(allfiles),'fdMatches':handles,'deniedProcessCount':len(denied),'grossAllocatedRecovery':snapshot['recovery']['failedAllocatedBlocksBytes'],'proposalSHA256':snapshot['proposalSHA256']}))
