import json,pathlib,statistics,math
p=pathlib.Path('/workspace/scratch/hound-jaw-hinge-author-v08-r5');j=json.loads((p/'actual-browser-results-r5.json').read_text());by={(r['variant'],r['mode'],r['viewport']['width'],r['reduced']):r for r in j['rows']};pairs=[]
def tip(d):
 sx,sy,sw,sh=d['source'];dx,dy,dw,dh=d['destination'];x=dx+(1456-sx)/sw*dw;y=dy+(255-sy)/sh*dh;m=d['matrix'];return[m['a']*x+m['c']*y+m['e'],m['b']*x+m['d']*y+m['f']]
for k,b in by.items():
 if k[0]!='baseline':continue
 c=by[('candidate',*k[1:])];assert b['result']==c['result'];diffs=[z['label'] for z,w in zip(b['frames'],c['frames']) if z['pngSha256']!=w['pngSha256']]
 if b['mode'] in ['reaction','death','reduced']:assert not diffs
 e={'mode':b['mode'],'width':b['viewport']['width'],'canonicalStateEventsEqual':True,'differentFrameLabels':diffs}
 if b['mode'] in ['attack','resize']:
  age=next(z['at'] for z in b['frames'] if z['label']=='240');a=[d for d in b['draws'] if d['at']==age and d['source'][0]>=1024 and d['source'][1]==96][-1];v=[d for d in c['draws'] if d['at']==age and d['source'][0]>=1024 and d['source'][1]==0 and abs(d['matrix']['b'])<1e-10][-1];e['contactNoseA']=tip(a);e['contactNoseB']=tip(v);e['nosePositionDeltaPx']=math.dist(e['contactNoseA'],e['contactNoseB']);assert e['nosePositionDeltaPx']<1e-8
  perf={}
  for r in[b,c]:
   onset=next(z['at'] for z in r['frames'] if z['label']=='140')-140;vals=[x['wallMs'] for x in r['wallFrames'] if onset+190<=x['at']<onset+360];perf[r['variant']]={'samples':len(vals),'medianMs':statistics.median(vals),'p95Ms':sorted(vals)[int(len(vals)*.95)-1],'maxMs':max(vals)}
  e['wholeFrameWallCostOnThisHost']=perf
 pairs.append(e)
with open(p/'paired-analysis-r1.json','x') as f:json.dump({'scope':'Author equal-private-age actual production A/B. Nine exact full engine state/event pairs. Natural wall times are small local headless samples under variable host load, not a certified FPS or hardware performance result. Nose deltas establish retained source-landmark location, not a new target-gap improvement.', 'pairs':pairs},f,indent=2);f.write('\n')
print(json.dumps(pairs,indent=2))
