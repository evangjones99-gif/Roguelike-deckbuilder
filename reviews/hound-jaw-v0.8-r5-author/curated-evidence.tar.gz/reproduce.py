from pathlib import Path
import json,hashlib,shutil,argparse
here=Path(__file__).resolve().parent
args=argparse.ArgumentParser();args.add_argument('--variant',choices=['baseline','candidate'],required=True);args.add_argument('--dest',type=Path,required=True);ns=args.parse_args()
identity=json.loads((here/'SOURCE-BUILD-IDENTITY.json').read_text());records=identity['runtimeInputs'][ns.variant];destination=ns.dest.absolute()
assert destination.parent==Path('/tmp') and not destination.exists(),'new direct /tmp child required'
for rel,r in records.items():assert hashlib.sha256(Path(r['input']).read_bytes()).hexdigest()==r['sha256'],rel
frozen=json.loads((here/'FROZEN-FILES.json').read_text()) if (here/'FROZEN-FILES.json').exists() else None
if frozen:
 for rel,r in frozen['files'].items():assert hashlib.sha256((here/rel).read_bytes()).hexdigest()==r['sha256'],rel
sources={rel:r['sha256']for rel,r in records.items()};digest=hashlib.sha256(json.dumps(sources,separators=(',',':')).encode()).hexdigest();assert digest==identity[ns.variant+'Digest']
destination.mkdir()
for rel,r in records.items():
 target=destination/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r['input'],target)
for entry in (here/'test-inputs').iterdir():
 if entry.is_dir():shutil.copytree(entry,destination/entry.name,dirs_exist_ok=True)
 else:shutil.copy2(entry,destination/entry.name)
(destination/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules',target_is_directory=True)
print(json.dumps({'variant':ns.variant,'digest':digest,'runtimeInputs':len(records),'newRegularSourceRoot':str(destination),'externalDependencies':'installed root node_modules; pinned package lock; no network install performed'}))
