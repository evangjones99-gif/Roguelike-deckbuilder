import os,json,time,hashlib,subprocess,stat
from pathlib import Path
R=Path('/workspace/scratch/relocated-preflight-retirement-root-caller-r6');R.mkdir(mode=0o700)
W='/workspace/scratch/guard-node-phase-r1.py';S='/workspace/scratch/retire-relocated-preflight-root-r6.py'
commit='e225cdeaab72358bf783b81bb14d055c0e20d1cd'
def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        st=os.fstat(fd);assert stat.S_ISREG(st.st_mode) and st.st_size<262144
        b=b''
        while a:=os.read(fd,65536):b+=a
        assert len(b)==st.st_size and os.fstat(fd)==st
        return b
    finally:os.close(fd)
def write(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def digest(p):return hashlib.sha256(read(p)).hexdigest()
controls={S:'5afbbe7f16f81d44babceda93b832f11e45f6884e52ec353e4cab164217ad9ca',W:'7284b52f785779ffc5d2a2e1b539b19cd331ee7315ae6b7f7c71af1fa856f3cc','/workspace/scratch/preflight-new-copy-c-read-outcome-r1/READ-RESULT.json':'2c117f182a63ae835ecbeca6990dce7b4b6910795fa49c2548cf0d414343e67d','/workspace/scratch/standard-sol-preflight-storage-preference-independent-r1/PREFERENCE.json':'c645480be3c6c3f96b18ede0bc66cfe77951499d34261c718134fe03dad767cc','/workspace/scratch/standard-sol-relocated-preflight-retirement-source-independent-r6/SOURCE-CALLER-GATE.json':'6c89aa7ccd3c40b64c6ffb45b6182afe5148688d3d7b409515dbff6a476011a0'}
for p,h in controls.items():assert digest(p)==h
pref=json.loads(read('/workspace/scratch/standard-sol-preflight-storage-preference-independent-r1/PREFERENCE.json'))
judgment=json.loads(read('/workspace/scratch/preflight-relocation-producer-judgment-r1.json'));assert judgment['producerJudgmentWise']
# Root just observed normal push rc0, exact connected GitHub ref, and clean HEAD.
decision={**pref,'producerJudgmentWise':True,'confirmedPushedCommit':commit,'connectedReadbackObservedByRoot':True,'knownAffectedActorsHeld':True,'cleanupGrantedByRoot':True,'rootJudgment':judgment}
D=R/'DECISION.json';write(D,decision)
baseline={'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text()),'events':Path('/sys/fs/cgroup/memory.events').read_text(),'monotonic_ns':time.monotonic_ns(),'time_ns':time.time_ns()}
assert baseline['maximum']-baseline['current']>=(48+512)*1048576
write(R/'DECLARATION.json',{'baseline':baseline,'controls':controls,'scope':'one literal old TMP duplicate retirement; preserved full encoding on disk; known agents/readers held','connectedRefSHA':commit,'work':48*1048576,'reserve':512*1048576,'wholeDeadlineSeconds':60})
cmd=['python3','-I',W,'/workspace/Roguelike-deckbuilder','/workspace/scratch/relocated-preflight-retirement-action-guard-r6','48','python3','-I',S,'--retire-only-reviewed-tmp-duplicate',commit,str(D)]
start=time.monotonic();p=subprocess.Popen(cmd,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
    out,err=p.communicate(timeout=60)
except BaseException:
    # Preserve unknown ARMED state; stop only this known wrapper and its known action.
    import signal
    children=Path(f'/proc/{p.pid}/task/{p.pid}/children')
    if children.exists():
        for child in children.read_text().split():
            try:os.killpg(int(child),signal.SIGTERM)
            except ProcessLookupError:pass
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    p.wait(timeout=5)
    raise
elapsed=time.monotonic()-start
packet=Path('/workspace/scratch/relocated-preflight-retirement-action-guard-r6')
wr=json.loads(read(packet/'RESULT.json'));rows=wr['samples']+[wr['final']]
for row in rows:assert row['maximum']==baseline['maximum'] and row['headroom']>=512*1048576 and row['current']-baseline['current']<=48*1048576 and row['free']>=1048576
assert wr['memory_events_before']==wr['memory_events_after']==baseline['events'] and elapsed<60
assert p.returncode==wr['exit_code']==0 and wr['failure'] is None
for path,h in controls.items():assert digest(path)==h
actual=json.loads(read('/workspace/scratch/relocated-preflight-retirement-root-r6/RESULT.json'))
assert actual['oldNameAbsent'] and actual['newMetadataUnchanged'] and actual['ownArchiveFDsClosed']
assert not os.path.lexists(pref['retireOnlyPath'])
final=int(Path('/sys/fs/cgroup/memory.current').read_text())
result={'status':'ONLY REVIEWED TMP PHYSICAL DUPLICATE RETIRED; ORIGINAL ENCODING RETAINED ON DISK','commit':commit,'normalOwnedWrapperWait':True,'wrapperPid':p.pid,'wrapperPostWaitAbsent':not Path(f'/proc/{p.pid}').exists(),'exit_code':p.returncode,'allSamplesAndFinalPassed':True,'samples':len(wr['samples']),'elapsedSeconds':elapsed,'controlsUnchanged':True,'oldNameAbsent':True,'retainedPath':pref['retainedPath'],'retainedSHA256':pref['retainedSHA256'],'baseline':baseline,'finalCurrent':final,'observedCurrentDecrease':baseline['current']-final,'finalHeadroom':baseline['maximum']-final,'qualification':'Normal action return and owned wait close its known descriptors; no global process/cache/reader exclusion, causal gain, logical Git coverage or remote encoding backup. Independent actual post inspection still required.'}
for folder in [packet,Path('/workspace/scratch/relocated-preflight-retirement-root-r6')]:
    for f in folder.iterdir():
        fd=os.open(f,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
        try:os.fsync(fd)
        finally:os.close(fd)
    fd=os.open(folder,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
write(R/'ROOT-OUTCOME.json',result);fd=os.open(R,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps(result))
