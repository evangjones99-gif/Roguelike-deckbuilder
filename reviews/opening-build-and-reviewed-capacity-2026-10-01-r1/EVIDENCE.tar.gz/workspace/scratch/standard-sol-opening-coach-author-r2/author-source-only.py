import difflib, hashlib, json, os, pathlib, resource, time
resource.setrlimit(resource.RLIMIT_DATA, (24 * 1048576, 24 * 1048576))
root = pathlib.Path('/workspace/scratch/standard-sol-opening-coach-author-r2')
r1 = pathlib.Path('/workspace/scratch/standard-sol-opening-coach-author-r1')
stage = pathlib.Path('/workspace/scratch/first-five-opening-stage-r2')
work, reserve = 24 * 1048576, 512 * 1048576
samples = []
initial = int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
def guard():
    current = int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
    maximum = int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
    row = {'timeUnix': time.time(), 'memoryCurrent': current, 'memoryMax': maximum, 'deltaFromInitial': current - initial, 'headroom': maximum - current}
    samples.append(row)
    assert maximum - current >= work + reserve, row
    assert current - initial <= work, row
    assert os.statvfs(root).f_bavail * os.statvfs(root).f_frsize >= 1048576, row
    return row
def read(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME)
    try:
        body = os.read(fd, 256 * 1024 + 1)
        assert len(body) <= 256 * 1024
        return body
    finally:
        os.close(fd)
def sha(body):
    return hashlib.sha256(body).hexdigest()
def write(path, body):
    guard()
    body = body.encode() if isinstance(body, str) else body
    fd = os.open(root / path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        assert os.write(fd, body) == len(body)
        os.fsync(fd)
    finally:
        os.close(fd)
    return {'path': path, 'bytes': len(body), 'sha256': sha(body)}
guard()
main = read(r1 / 'baseline/src/main.ts')
style = read(r1 / 'baseline/src/style.css')
prior_main = read(r1 / 'candidate/src/main.ts')
prior_style = read(r1 / 'candidate/src/style.css')
assert sha(main) == '19bf2f6886859234da7629e22c34ba8166a7871db22ecf2a928ab49699f2ccfe'
assert sha(style) == '2efb77f760000f60895a81a5cd1389dbfc7ac8e70cffc2fdfedba48225371bf3'
assert sha(prior_main) == 'db08f507deba7b0ac819e99d33551b245174839d5bb44552f4ff7e7c61e42e9b'
assert sha(prior_style) == '996d5fc00a145ea6750e8dbdf7074f30e0d85e79addc9e9cdcc7f36357eb87ce'
old = 'Click a BINDING card, press Enter on it, or drag it onto the field.'
new = 'Click or drag a BINDING card.'
source = prior_main.decode()
assert source.count(old) == 1
source = source.replace(old, new)
for folder in ['baseline', 'candidate']:
    (root / folder).mkdir()
    (root / folder / 'src').mkdir()
outputs = []
for path, body in [('baseline/src/main.ts', main), ('baseline/src/style.css', style), ('candidate/src/main.ts', source), ('candidate/src/style.css', prior_style)]:
    outputs.append(write(path, body))
diff = ''.join(difflib.unified_diff(main.decode().splitlines(True), source.splitlines(True), fromfile='baseline/src/main.ts', tofile='candidate/src/main.ts'))
diff += ''.join(difflib.unified_diff(style.decode().splitlines(True), prior_style.decode().splitlines(True), fromfile='baseline/src/style.css', tofile='candidate/src/style.css'))
outputs.append(write('SOURCE.diff', diff))
outputs.append(write('R1-R2.diff', ''.join(difflib.unified_diff(prior_main.decode().splitlines(True), source.splitlines(True), fromfile='r1/candidate/src/main.ts', tofile='r2/candidate/src/main.ts'))))
inputs = []
for path in [r1 / 'baseline/src/main.ts', r1 / 'baseline/src/style.css', r1 / 'candidate/src/main.ts', r1 / 'candidate/src/style.css', r1 / 'SOURCE-PACKET.json', r1 / 'RATIONALE.md']:
    body = read(path)
    inputs.append({'path': str(path), 'bytes': len(body), 'sha256': sha(body)})
outputs.append(write('INPUTS.json', json.dumps(inputs, indent=2) + '\n'))
rationale = '''# Opening coaching source proposal r2

The cue now reads “Bind your first creature. Click or drag a BINDING card.” It retains the exact card label and concrete binding instruction in eleven words. This narrows r1's copy in response to ROOT's review and the owner's concern about wordiness. It avoids listing every input method in the heading; native button activation, accessible card labels, keyboard focus, keyboard hints and optional How to play remain unchanged.

The source-only change from preserved r1 is this one text substitution. CSS is byte-identical to r1. The retained implementation keeps instruction beside the hand independently of focus/hover consequence previews, uses the existing floor 1 / turn 1 / no allies / legal summon predicate, and stops emitting the cue after a binding or when legal summons disappear. It does not choose a particular card or command. The naturally wrapping paragraph and cue-scoped auto-height dock remain the same proposal; card dimensions, lift gutters, field/readout height measurement, targets and timelines are unedited.

This packet retains the complete original-stage baseline main.ts/style.css, complete r2 candidate files, original-baseline SOURCE.diff, and a separate R1-R2.diff. R1 is preserved without writes. No Node, browser, server, build, engine import, game/public/root write or independent review was performed. Bounded source authoring records exact bytes only. PC 1440×900 rendered fit and discoverability during actual focus require matching independent browser/gameplay observation. Shorter copy does not establish a line count, layout acceptance, fun or promotion.
'''
outputs.append(write('RATIONALE.md', rationale))
assert read(stage / 'src/main.ts') == main and read(stage / 'src/style.css') == style
assert read(r1 / 'candidate/src/main.ts') == prior_main and read(r1 / 'candidate/src/style.css') == prior_style
outputs.append({'path': 'author-source-only.py', 'bytes': len(read(root / 'author-source-only.py')), 'sha256': sha(read(root / 'author-source-only.py'))})
final = guard()
receipt = {'status': 'SOURCE ONLY; UNBUILT; UNPROMOTED; NO INDEPENDENT REVIEW', 'baselineSourceDigest': '46c1b0ff025847fa69587fdb127e57066d65627399dccdd7e60f1c53d81b6cf5', 'baselineStage': str(stage), 'priorPacket': str(r1), 'r1ToR2Scope': 'One visible copy substitution in main.ts; CSS identical', 'phaseWorkBytes': work, 'reserveBytes': reserve, 'samples': samples, 'onlyWrites': str(root), 'frozenStageMainAndStyleUnchangedAtClosure': True, 'r1CandidateMainAndStyleUnchangedAtClosure': True, 'files': outputs}
manifest = write('SOURCE-PACKET.json', json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'manifest': manifest, 'files': outputs, 'phaseFinal': final}, indent=2))
