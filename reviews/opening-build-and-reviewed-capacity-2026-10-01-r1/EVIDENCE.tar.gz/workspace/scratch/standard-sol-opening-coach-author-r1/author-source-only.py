import difflib, hashlib, json, os, pathlib, resource, time
resource.setrlimit(resource.RLIMIT_DATA, (24 * 1048576, 24 * 1048576))
root = pathlib.Path('/workspace/scratch/standard-sol-opening-coach-author-r1')
stage = pathlib.Path('/workspace/scratch/first-five-opening-stage-r2')
work, reserve = 24 * 1048576, 512 * 1048576
samples = []
initial = int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
def guard():
    current = int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
    maximum = int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
    row = {'timeUnix': time.time(), 'memoryCurrent': current, 'memoryMax': maximum, 'deltaFromInitial': current - initial, 'headroom': maximum - current}
    samples.append(row)
    assert maximum - current >= work + reserve, row
    assert current - initial <= work, row
    assert os.statvfs(root).f_bavail * os.statvfs(root).f_frsize >= 1048576, row
    return row
def read(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME)
    try:
        body = os.read(fd, 256 * 1024 + 1)
        assert len(body) <= 256 * 1024
        return body
    finally:
        os.close(fd)
def sha(body):
    return hashlib.sha256(body).hexdigest()
def write(path, body):
    guard()
    body = body.encode() if isinstance(body, str) else body
    fd = os.open(root / path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        assert os.write(fd, body) == len(body)
        os.fsync(fd)
    finally:
        os.close(fd)
    return {'path': path, 'bytes': len(body), 'sha256': sha(body)}
guard()
main = read(stage / 'src/main.ts')
style = read(stage / 'src/style.css')
assert sha(main) == '19bf2f6886859234da7629e22c34ba8166a7871db22ecf2a928ab49699f2ccfe'
assert sha(style) == '2efb77f760000f60895a81a5cd1389dbfc7ac8e70cffc2fdfedba48225371bf3'
source = main.decode()
old_instruction = "  if (state.floor === 1 && state.turn === 1 && state.allies.length === 0 && actions().some(action => action.type === 'play' && CARDS[state.hand[action.index]]?.type === 'summon'))\n    return 'Click a creature card to bind it, or drag it onto the highlighted area. How to play explains the rules.';\n"
assert source.count(old_instruction) == 1
source = source.replace(old_instruction, '')
old_playable = "  const playable = actions().filter(a => a.type === 'play');\n"
assert source.count(old_playable) == 1
source = source.replace(old_playable, old_playable + "  const firstBinding = state.floor === 1 && state.turn === 1 && state.allies.length === 0 && playable.some(action => action.type === 'play' && CARDS[state.hand[action.index]]?.type === 'summon');\n")
old_heading = '<div class="hand-heading"><span class="eyebrow">AVAILABLE CARDS <span>${state.hand.length}</span></span><div class="pile-buttons">'
new_heading = '<div class="hand-heading${firstBinding ? \' opening-hand-heading\' : \'\'}"><span class="eyebrow">AVAILABLE CARDS <span>${state.hand.length}</span></span>${firstBinding ? \'<p class="first-binding-cue"><strong>Bind your first creature.</strong> Click a BINDING card, press Enter on it, or drag it onto the field.</p>\' : \'\'}<div class="pile-buttons">'
assert source.count(old_heading) == 1
source = source.replace(old_heading, new_heading)
css = style.decode() + '''\n/* First binding stays beside the hand while focus/hover previews describe outcomes. */
#dock:has(.opening-hand-heading){height:auto}
#dock .opening-hand-heading{height:auto;min-height:18px;flex-wrap:wrap;gap:6px 16px}
#dock .opening-hand-heading>.eyebrow,#dock .opening-hand-heading>.pile-buttons{flex:0 0 auto}
#dock .first-binding-cue{flex:1 1 420px;min-width:0;margin:0;padding-left:10px;border-left:2px solid #c1a673;color:#e2d8bd;font:13px/18px Arial,sans-serif;overflow-wrap:anywhere}
#dock .first-binding-cue strong{color:#f0e1ba}
@media(max-width:1100px){#dock .first-binding-cue{order:2;flex-basis:100%}}
'''
for folder in ['baseline', 'candidate']:
    (root / folder).mkdir()
    (root / folder / 'src').mkdir()
outputs = []
for path, body in [('baseline/src/main.ts', main), ('baseline/src/style.css', style), ('candidate/src/main.ts', source), ('candidate/src/style.css', css)]:
    outputs.append(write(path, body))
diff = ''.join(difflib.unified_diff(main.decode().splitlines(True), source.splitlines(True), fromfile='baseline/src/main.ts', tofile='candidate/src/main.ts'))
diff += ''.join(difflib.unified_diff(style.decode().splitlines(True), css.splitlines(True), fromfile='baseline/src/style.css', tofile='candidate/src/style.css'))
outputs.append(write('SOURCE.diff', diff))
inputs = []
for path in [stage / 'src/main.ts', stage / 'src/style.css', stage / 'src/command-field.css', stage / 'src/compact-readout.css', stage / 'src/tactile-hand.css', stage / 'src/input.ts', '/workspace/Roguelike-deckbuilder/AGENTS.md', '/workspace/Roguelike-deckbuilder/docs/CONTINUATION.md', '/workspace/Roguelike-deckbuilder/docs/PRODUCTION.md', '/workspace/attachments/dd40a114-2c0f-49f8-a820-8d1c4a1716a6/Pasted text.txt', '/workspace/scratch/first-five-opening-runtime-freeze-root-r2.json']:
    body = read(path)
    inputs.append({'path': str(path), 'bytes': len(body), 'sha256': sha(body)})
outputs.append(write('INPUTS.json', json.dumps(inputs, indent=2) + '\n'))
rationale = '''# Opening coaching source proposal

The observed opening instruction was erased when initial keyboard focus on Iron Ward produced its legal consequence preview. This proposal places one contextual instruction in the hand heading, beside the cards it describes. It says “Bind your first creature. Click a BINDING card, press Enter on it, or drag it onto the field.” BINDING matches the actual creature-card label. The cue suggests no particular creature or outcome and leaves actual card selection to the player.

The former instruction branch is removed from selectionGuidance; selection and exact target outcomes keep their existing output. The hand cue uses the same floor 1, turn 1, no allies, legal summon predicate, from renderBattle's already computed playable actions. It persists through focus, hover and target selection and stops being emitted after a binding or after legal summons become unavailable. Existing state-driven rerendering owns that lifecycle. It is ordinary visible paragraph text, with no added focus target, modal, animation, event handler, engine action or local-storage write. Optional How to play and the candidate's removal of its automatic rules dialog stay in the retained source.

The hand-heading placement avoids another full-width tutorial strip. At desktop widths above 1100px, the label, instruction and Draw/Discard share the existing flex row, with the instruction allowed to wrap and grow the row naturally. At narrower widths, the instruction follows the two existing heading controls on its own natural row. The cue has 13px live text with 18px line height and a small gold rule, no fixed height, max height or hidden overflow. Dock auto height is scoped to cue presence so fallback card/control flow can also grow. Card heights, lift gutters, horizontal scrolling, tactile drop zones and turn controls are unedited.

Source geometry context: initial hand-heading height is fixed at 18px in style.css; command-field.css changes its margin but not height. Direct-field dock and tactile-host dock already use auto height. compact-readout.css reserves the preview strip independently at 84px on PC. positionFieldControls measures that battle-guidance height plus art-status height; it does not measure the hand. No readout, actor coordinate, arena height computation or creature timeline is changed by this proposal.

This packet contains full exact baseline/candidate main.ts and style.css and a unified diff. Only these two proposed runtime inputs differ. No Node, browser, server, build, engine imports, public/art writes or frozen-stage writes were used. The guarded Python authoring phase only reads bounded text and writes inside this exclusive packet. It records source identities; it is not an independent review, compile result, rendered fit check or gameplay comparison. PC 1440×900 fit, initial discoverability during real focus, wrapping/zoom, keyboard/screen-reader usability, fallback fit, no-legal-summon disappearance and the separate actual-choice/command behavior require independent matching build observations. No fun, craft, timing or promotion claim is made.
'''
outputs.append(write('RATIONALE.md', rationale))
assert read(stage / 'src/main.ts') == main and read(stage / 'src/style.css') == style
outputs.append({'path': 'author-source-only.py', 'bytes': len(read(root / 'author-source-only.py')), 'sha256': sha(read(root / 'author-source-only.py'))})
final = guard()
receipt = {'status': 'SOURCE ONLY; UNBUILT; UNPROMOTED; NO INDEPENDENT REVIEW', 'baselineSourceDigest': '46c1b0ff025847fa69587fdb127e57066d65627399dccdd7e60f1c53d81b6cf5', 'baselineStage': str(stage), 'phaseWorkBytes': work, 'reserveBytes': reserve, 'samples': samples, 'onlyWrites': str(root), 'frozenMainAndStyleUnchangedAtClosure': True, 'files': outputs}
manifest = write('SOURCE-PACKET.json', json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'manifest': manifest, 'files': outputs, 'phaseFinal': final}, indent=2))
