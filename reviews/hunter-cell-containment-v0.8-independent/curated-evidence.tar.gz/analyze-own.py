from pathlib import Path
import json,math
p=Path('/workspace/scratch/hunter-cell-containment-independent-v08-r1');r=json.loads((p/'browser-independent-r1.json').read_text());alpha=json.loads((p/'source-alpha-analysis.json').read_text())['bounds'];poses={(0,0):'idle',(512,0):'anticipation',(1024,0):'attack',(0,512):'recovery',(512,512):'reaction',(1024,512):'death'};out=[]
for row in r['rows']:
 outside=[];alphaOutside={str(t):[] for t in [1,8,10,32,128]};seen=set()
 for i,d in enumerate(row['draws']):
  pose=poses[tuple(d['source'][:2])];seen.add(pose);w,h=d['field'];outsideCell=any(x < -1e-7 or x>w+1e-7 or y < -1e-7 or y>h+1e-7 for x,y in d['points'])
  if outsideCell:outside.append({'index':i,'pose':pose,'time':d['time'],'field':d['field'],'css':d['css'],'title':d['title'],'opacity':d['opacity'],'points':d['points']})
  a,b,c,dd,e,f=d['matrix'];x0,y0,dw,dh=d['destination']
  for threshold in alphaOutside:
   left,top,right,bottom=alpha[pose][threshold];pts=[]
   for sx,sy in [(left,top),(right,top),(left,bottom),(right,bottom)]:
    x=x0+sx/512*dw;y=y0+sy/512*dh;pts.append((a*x+c*y+e,b*x+dd*y+f))
   if any(x < -1e-7 or x>w+1e-7 or y < -1e-7 or y>h+1e-7 for x,y in pts):alphaOutside[threshold].append({'index':i,'pose':pose,'field':d['field'],'title':d['title'],'opacity':d['opacity']})
 if row['variant']=='candidate':assert not outside and not any(alphaOutside.values()),(row['name'],outside)
 out.append({'variant':row['variant'],'case':row['name'],'capturedHunterDraws':len(row['draws']),'poses':sorted(seen),'outsideCellDraws':outside,'sourceAlphaOutsideDraws':alphaOutside,'steps':row['steps']})
paired=[]
for name in {x['name'] for x in r['rows']}:
 old=next(x for x in r['rows'] if x['variant']=='baseline' and x['name']==name);new=next(x for x in r['rows'] if x['variant']=='candidate' and x['name']==name);oldActions=[s for s in old['steps'] if 'action'in s];newActions=[s for s in new['steps'] if 'action'in s];assert oldActions==newActions;assert old['finalState']==new['finalState'];same=[]
 for b,a in zip(old['steps'],new['steps']):
  if 'action' not in b and b['last']['field']==a['last']['field'] and b['last']['source']==a['last']['source']:
   w,h=b['last']['field']
   if w>=360 and h<=400:assert b['last']['points']==a['last']['points'],(name,b['label']);same.append(b['label'])
 paired.append({'case':name,'canonicalActionsExact':len(oldActions),'finalStateExact':True,'normalNumericPaintExactSteps':same})
(p/'analysis-independent.json').write_text(json.dumps({'scope':'Ownactualpaintmatrices/fullsourcecells/read-onlyalphabounds. Opacity0title and CSS/backingtransientdrawsrecordedseparately; wrapperopacitydoesnotprovescreenpresentedframe. Alpha threshold doesnotassertperceptualvisibility.', 'cases':out,'paired':paired,'allSixCandidatePosesObserved':sorted(set(pose for x in out if x['variant']=='candidate' for pose in x['poses'])),'candidateDraws':sum(x['capturedHunterDraws'] for x in out if x['variant']=='candidate'),'candidateOutside':0},indent=2)+'\n')
print(json.dumps({'cases':len(out),'candidateDraws':sum(x['capturedHunterDraws'] for x in out if x['variant']=='candidate'),'candidateOutside':0,'candidatePoses':sorted(set(pose for x in out if x['variant']=='candidate' for pose in x['poses'])),'pairedActionsPerVariant':sum(x['canonicalActionsExact'] for x in paired)}))
