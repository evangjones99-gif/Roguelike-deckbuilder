from pathlib import Path
import json,hashlib,sys
A=Path('/workspace/scratch/installer-v09-decoder-author-r3');O=Path('/workspace/scratch/installer-v09-decoder-independent-r3');H=lambda b:hashlib.sha256(b).hexdigest();assert H((A/'MANIFEST.json').read_bytes())=='3a9718808fd01c97d300e6c96bfb13daecf5a855853d2c244559c228f9abcea4';manifest=json.loads((A/'MANIFEST.json').read_text())
for r in manifest['files']:
 b=(A/r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],r['path']
r2=json.loads((A/'R2-MANIFEST.json').read_text());R=Path('/workspace/scratch/installer-v08-current-author-r2')
for r in r2['files']:
 b=(R/r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],r['path']
sources=json.loads((A/'STAGED-SOURCE-INPUTS-BEFORE.json').read_text());outputs=json.loads((A/'STAGED-BUILD-OUTPUTS.json').read_text());result={'authorManifest':H((A/'MANIFEST.json').read_bytes()),'authorFiles':len(manifest['files']),'oldR2Files':len(r2['files']),'sources':{},'outputs':{}}
for r in sources['files']:
 b=Path(r['absolutePath']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'];result['sources'][r['path']]={'bytes':len(b),'sha256':H(b)}
for r in outputs['outputs']:
 b=(Path('/tmp/hollowpact-final-kill-v09-root-r1/dist')/r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'];result['outputs'][r['path']]={'bytes':len(b),'sha256':H(b)}
runtime=json.loads((A/'build-provenance.json').read_text());assert runtime['sourceDigest']=='8a33f950ed57093a222baf9b7883a5c1ccf2deb2e8412429ef0fe05d370467cb';assert H(json.dumps(runtime['hashes'],separators=(',',':')).encode())==runtime['sourceDigest'];assert {k:v['sha256']for k,v in result['sources'].items()}==runtime['hashes'];assert len(result['sources'])==77 and len(result['outputs'])==55
p=json.loads((A/'ASAR-PIN.json').read_text());b=Path(p['path']).read_bytes();assert len(b)==p['bytes']and H(b)==p['sha256']=='0d82286ca7e49206b5085c3544d377735f3af048129abdd1b261d9d1b4086251';result['ASAR']={'bytes':len(b),'sha256':H(b)}
header=(A/'upstream-audio-sample-types.h.txt').read_bytes();blob=hashlib.sha1(b'blob '+str(len(header)).encode()+b'\0'+header).hexdigest();assert blob=='2a87b919c5bda11abe65806a820d1d56f2babf89';result['upstreamGitBlob']=blob
for n in ['installer-smoke.json','manifest.json']:
 assert (A/'failed-native'/n).read_bytes()==(Path('/workspace/Roguelike-deckbuilder/reviews/root-v0.8-current-installer-failure')/n).read_bytes();result[n]=H((A/'failed-native'/n).read_bytes())
root=Path('/workspace/Roguelike-deckbuilder');changed=[]
for f in sorted((A/'proposed/scripts').glob('*.mjs')):
 base=A/'baseline/scripts'/f.name
 if f.read_bytes()!=base.read_bytes():changed.append(f.name)
assert changed==['windows-installer-current-validation.mjs','windows-installer-current-validation.test.mjs','windows-installer-guards.mjs'];result['proposalChangedScripts']=changed
old=(A/'baseline/scripts/windows-installer-guards.mjs').read_text();new=(A/'proposed/scripts/windows-installer-guards.mjs').read_text();assert old[old.index('export const hash'):]==new[new.index('export const hash'):]
if sys.argv[1]=='INPUT-AFTER.json':assert result==json.loads((O/'INPUT-BEFORE.json').read_text())
with (O/sys.argv[1]).open('x')as f:json.dump(result,f,indent=2)
print(json.dumps({'authorFiles':result['authorFiles'],'oldR2Files':result['oldR2Files'],'sources':len(result['sources']),'outputs':len(result['outputs']),'upstreamGitBlob':blob,'changedScripts':changed,'exactPins':True}))
