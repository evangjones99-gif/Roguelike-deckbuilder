import pathlib,json,hashlib,zipfile,stat
repo=pathlib.Path('/workspace/Roguelike-deckbuilder')
out=pathlib.Path('/workspace/scratch/hunter-native-package-independent-v07')
out.mkdir(exist_ok=True)
prior=pathlib.Path('/workspace/scratch/hunter-native-windows-independent-v07')
expected_prior='45fe59963cb9aefc046c6a65c024fabdadc02275d4af88ba748a671857557e1c'
def digest(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert digest(prior/'MANIFEST.json')==expected_prior
prior_manifest=json.loads((prior/'MANIFEST.json').read_text())
for f in prior_manifest['files']:
 p=prior/f['path'];assert p.stat().st_size==f['bytes'];assert digest(p)==f['sha256']
assert len(prior_manifest['files'])==141
art=prior/'current-original-artifact'
manifest=json.loads((art/'build-desktop/windows-transfer/manifest.json').read_text())
github=json.loads((prior/'evidence/current-api-2-completed.json').read_text())['value']['structuredContent']['artifacts']
records=json.loads((repo/'reviews/root-v0.7-source-capacity/native-transfer-downloads.json').read_text())
rootreceipt=json.loads((repo/'reviews/root-v0.7-source-capacity/native-reconstruction.json').read_text())
nativezip=pathlib.Path('/tmp/hollowpact-native-v07/windows-native/hollowpact-0.7.0-windows-native-x64.zip')
win=nativezip.parent/'win-unpacked'
assert len(records)==len(manifest['parts'])==8
combined=hashlib.sha256();wrapperresults=[]
with nativezip.open('rb') as full:
 for record,part in zip(records,manifest['parts']):
  api=next(a for a in github if a['id']==record['artifactId']);p=pathlib.Path(record['path'])
  assert p.stat().st_size==api['size_in_bytes']==record['expectedWrapperBytes']
  wrapperhash=digest(p);assert 'sha256:'+wrapperhash==api['digest']==record['expectedWrapperSHA256']
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   assert z.namelist()==[part['filename']]
   info=z.getinfo(part['filename']);assert info.file_size==part['bytes']
   h=hashlib.sha256();count=0
   with z.open(info) as stream:
    while chunk:=stream.read(1024*1024):
     h.update(chunk);combined.update(chunk);count+=len(chunk)
     assert full.read(len(chunk))==chunk
   assert count==part['bytes'];assert h.hexdigest()==part['sha256']
   wrapperresults.append({'index':part['index'],'artifactId':api['id'],'wrapperPath':str(p),'wrapperBytes':p.stat().st_size,'wrapperSHA256':wrapperhash,'partName':part['filename'],'partBytes':count,'partSHA256':h.hexdigest(),'zipCRC':'pass','everyConcatenatedByteMatchesOriginalZIP':True})
 assert full.read(1)==b''
assert combined.hexdigest()==manifest['sha256']==digest(nativezip)==rootreceipt['originalZIPSHA256']
assert nativezip.stat().st_size==manifest['bytes']==rootreceipt['originalZIPBytes']==185715968
smoke=json.loads((art/'reviews/windows-native/0.7.0/run-36797759232-1/smoke.json').read_text())
files=[]
with zipfile.ZipFile(nativezip) as z:
 assert z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))==len(set(n.casefold() for n in names))==72
 for info in z.infolist():
  n=info.filename;rel=pathlib.PurePosixPath(n)
  assert not info.is_dir() and not rel.is_absolute() and '..' not in rel.parts and '\\' not in n and ':' not in n and '\x00' not in n
  assert not stat.S_ISLNK(info.external_attr>>16)
  p=win.joinpath(*rel.parts);assert p.is_file() and not p.is_symlink()
  h=hashlib.sha256();count=0
  with z.open(info) as stream,p.open('rb') as extracted:
   while chunk:=stream.read(1024*1024):
    count+=len(chunk);h.update(chunk);assert extracted.read(len(chunk))==chunk
   assert extracted.read(1)==b''
  assert count==info.file_size==p.stat().st_size
  assert h.hexdigest()==smoke['packageFiles'][n]
  files.append({'path':n,'bytes':count,'sha256':h.hexdigest(),'archiveAndExtractedBytesExact':True})
 assert set(names)==set(smoke['packageFiles'])==set(rootreceipt['memberNames'])
 actual={p.relative_to(win).as_posix() for p in win.rglob('*') if p.is_file()}
 assert actual==set(names)
result={'status':'passed','scope':'Independently verified original wrapper/inner part/full native ZIP/extracted bytes and safe members; no Windows execution','actualMergeCommit':manifest['commit'],'branchHead':'bdf27374358eb176e62f832cb50261cb3334d8df','sourceDigest':manifest['sourceDigest'],'zipPath':str(nativezip),'zipBytes':nativezip.stat().st_size,'zipSHA256':digest(nativezip),'zipCRC':'pass','wrappers':wrapperresults,'files':files,'priorReviewManifestSHA256':expected_prior,'priorReviewFilesUnchanged':141}
(out/'transfer-and-files.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['wrappers','files']}))
