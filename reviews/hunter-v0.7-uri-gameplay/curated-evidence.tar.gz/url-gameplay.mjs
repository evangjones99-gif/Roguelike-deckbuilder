import assert from 'node:assert/strict';
import fs from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/playwright/index.mjs';
const OUT='/workspace/scratch/hunter-production-url-independent-gameplay-v07';
const ROOT='/workspace/Roguelike-deckbuilder';
const DIGEST='0be4f01d416e6fc4cca3f19b6916b5b65993b9fd426a926a1ede6d8487834a35';
const sha=b=>createHash('sha256').update(b).digest('hex');
const provenance=JSON.parse(fs.readFileSync(OUT+'/build-provenance.json'));
const guard=()=>{assert.equal(sha(JSON.stringify(provenance.hashes)),DIGEST);for(const [p,h]of Object.entries(provenance.hashes))assert.equal(sha(fs.readFileSync(ROOT+'/'+p)),h,p);};
const refs=JSON.parse(gunzipSync(fs.readFileSync(OUT+'/references.json.gz')));
const cases=refs.fixtures.map(f=>({f,width:1280,height:720,motion:f.name!=='finalkill-reduced'}));
const output=OUT+'/url-gameplay-r1.json';assert.ok(!fs.existsSync(output));guard();
const saved=p=>p.evaluate(()=>localStorage.getItem('hollowpact.run.v2'));
const storage=p=>p.evaluate(()=>Object.fromEntries(Object.entries(localStorage)));
const withoutSave=s=>{const x={...s};delete x['hollowpact.run.v2'];return x;};
async function action(p,a){
 if(a.type==='attack'){await p.locator(`[data-unit="${a.unit}"]`).focus();await p.keyboard.press('Enter');await p.locator(`[data-unit="${a.target}"]`).focus();await p.keyboard.press('Enter');}
 else if(a.type==='play'){await p.locator(`[data-ui="play-card"][data-index="${a.index}"]`).focus();await p.keyboard.press('Enter');if(a.target){await p.locator(`[data-unit="${a.target}"]`).focus();await p.keyboard.press('Enter');}}
 else if(a.type==='endTurn'){await p.keyboard.press('e');if(await p.locator('[data-ui="confirm-end"]').isVisible()){await p.locator('[data-ui="confirm-end"]').focus();await p.keyboard.press('Enter');}}
 else throw Error('Unsupported '+a.type);
}
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const results=[];
try{for(const {f,width,height,motion}of cases){guard();const context=await browser.newContext({viewport:{width,height},reducedMotion:motion?'no-preference':'reduce'});
 await context.addInitScript(({state,motion})=>{
  if(!localStorage.getItem('hollowpact.run.v2'))localStorage.setItem('hollowpact.run.v2',JSON.stringify(state));
  localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion,mute:true,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');
  window.__qaHunterFrames=[];const draw=CanvasRenderingContext2D.prototype.drawImage;
  CanvasRenderingContext2D.prototype.drawImage=function(...a){const result=draw.apply(this,a);if(this.canvas.id==='arena'&&a[0] instanceof HTMLImageElement&&a[0].src.endsWith('/art/hunter-marek-v07-r3.png')&&a.length===9){const [x,y,w,h]=a.slice(5),m=this.getTransform();const quad=[[x,y],[x+w,y],[x,y+h],[x+w,y+h]].map(([x,y])=>({x:m.a*x+m.c*y+m.e,y:m.b*x+m.d*y+m.f}));window.__qaHunterFrames.push({t:performance.now(),source:a.slice(1,5),quad,canvasWidth:this.canvas.width,canvasHeight:this.canvas.height,cssWidth:this.canvas.getBoundingClientRect().width,cssHeight:this.canvas.getBoundingClientRect().height});}return result;};
 },{state:f.state,motion});
 const page=await context.newPage(),errors=[],external=[],r={name:f.name,kind:f.kind,width,height,motion,steps:[],pass:false};results.push(r);
 page.on('pageerror',e=>errors.push(e.message));page.on('request',q=>{if(/^https?:/.test(q.url())&&!q.url().startsWith('http://127.0.0.1:4173/'))external.push(q.url())});
 try{
  await page.goto('http://127.0.0.1:4173/');const live=await(await page.request.get('http://127.0.0.1:4173/build-provenance.json')).json();assert.deepEqual(live,provenance);
  await page.locator('[data-ui="resume"]').click();await page.waitForLoadState('networkidle');assert.equal(await saved(page),JSON.stringify(f.state));
  assert.equal(await page.locator('#arena').evaluate(c=>'__hunterProbe'in c),false);assert.equal(await page.locator('.arena-caption').evaluate(c=>getComputedStyle(c).display),'none');
  assert.ok(await page.evaluate(()=>window.__qaHunterFrames.length>0),'Actual hunter sheet did not draw');
  const initial=await storage(page);
  for(const s of f.steps){
   assert.equal(await saved(page),JSON.stringify(s.before));await page.evaluate(()=>window.__qaHunterFrames=[]);
   const beforeCanvas=await page.locator('#arena').evaluate(c=>({width:c.getBoundingClientRect().width,height:c.getBoundingClientRect().height}));
   await action(page,s.action);assert.equal(await saved(page),JSON.stringify(s.after));assert.deepEqual(withoutSave(await storage(page)),withoutSave(initial));
   const immediate={held:await page.locator('#app').evaluate(e=>e.classList.contains('settling-combat')),hint:await page.locator('.keyboard-hint').textContent()};
   if(immediate.held){assert.match(immediate.hint,/Final impact resolving/);assert.match(immediate.hint,/Esc.*Pause/);assert.ok(!/Inspect|End turn|Regions/.test(immediate.hint));}
   if(f.name==='finalkill-motion')assert.equal(immediate.held,true);if(f.name==='finalkill-reduced')assert.equal(immediate.held,false);await page.waitForTimeout(700);await page.waitForFunction(()=>!document.querySelector('#app').classList.contains('settling-combat'));await page.waitForTimeout(420);
   assert.equal(await saved(page),JSON.stringify(s.after));assert.deepEqual(withoutSave(await storage(page)),withoutSave(initial));
   const frames=await page.evaluate(()=>window.__qaHunterFrames),afterCanvas=await page.locator('#arena').evaluate(c=>({width:c.getBoundingClientRect().width,height:c.getBoundingClientRect().height}));assert.ok(frames.length>0);
   for(const q of frames){assert.equal(q.source[2],512);assert.equal(q.source[3],512);assert.ok(q.quad.every(p=>p.x>=-1e-5&&p.y>=-1e-5&&p.x<=q.canvasWidth+1e-5&&p.y<=q.canvasHeight+1e-5),'Whole hunter cell escaped canvas');}
   const keys=[...new Set(frames.map(q=>q.source.slice(0,2).join(',')))];
   if(f.name==='actual-bind-zero-to-three'&&s.action.type==='play'&&motion){const animated=frames.filter(q=>q.source[0]!==0||q.source[1]!==0);assert.ok(animated.length>=3,'Binding animation missing');if(beforeCanvas.width!==afterCanvas.width||beforeCanvas.height!==afterCanvas.height)assert.ok(animated.filter(q=>q.cssWidth===afterCanvas.width&&q.cssHeight===afterCanvas.height).length>=3,'Automatic resize cancelled painted binding ritual');}
   if(['hunter-injured','hunter-fully-blocked'].includes(f.name))assert.ok(keys.includes('512,512'),'Actual hunter reaction cel missing');
   if(f.name==='hunter-lethal')assert.ok(keys.includes('1024,512'),'Actual fallen hunter cel missing');
   if(!motion&&s.after.phase==='battle')assert.ok(keys.every(k=>k==='0,0'));
   if(s.after.phase==='battle'){assert.deepEqual((await page.locator('.unit.ally').evaluateAll(ns=>ns.map(n=>n.dataset.unit))).sort(),s.after.allies.map(a=>a.uid).sort());assert.deepEqual((await page.locator('.unit.enemy').evaluateAll(ns=>ns.map(n=>n.dataset.unit))).sort(),s.after.enemies.map(a=>a.uid).sort());}
   await page.reload();await page.locator('[data-ui=resume]').click();assert.equal(await saved(page),JSON.stringify(s.after));r.steps.push({reloadCanonical:true,action:s.action,expectedEvents:s.events,canonicalImmediate:true,canonicalSettled:true,otherStorageExact:true,beforeCanvas,afterCanvas,immediate,observedCels:keys,frames});
  }
  assert.deepEqual(errors,[]);assert.deepEqual(external,[]);r.pass=true;
  if(['actual-bind-zero-to-three','finalkill-motion','finalkill-reduced'].includes(f.name))await page.screenshot({path:OUT+`/actual-hunter-${f.name}-${f.kind}-${width}-${motion}.png`,fullPage:true});
 }catch(e){r.error=String(e.stack||e)}finally{r.errors=errors;r.external=external;await context.close();fs.writeFileSync(output,JSON.stringify({scope:'Actual frozen0be4 relativeURI production compiled web4173, no query flags or renderer/reducer seams. Shipped keyboard callbacks; immutable accepted oracle fullstates/events from valid explicitly unearned diagnostic saves. Read-only actual drawImage instrumentation checks whole hunter cells, naturally observed cels and thirdbinding resize and reload; no source clock overrides/private probes. Instrumented software Chromium is not performance/native/humanfun evidence.',sourceDigest:DIGEST,results},null,2)+'\n');console.log(JSON.stringify({name:f.name,kind:f.kind,width,motion,pass:r.pass,actions:r.steps.length,error:r.error?.split('\n')[0]}));}
 }
}finally{await browser.close();guard()}
