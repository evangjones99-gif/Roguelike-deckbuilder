from pathlib import Path
import json, hashlib
O=Path('/workspace/scratch/hunter-cell-containment-author-v08-r1')
data=json.loads((O/'browser-probe.json').read_text());alpha=json.loads((O/'alpha-support.json').read_text());names=['idle','anticipation','attack','recovery','reaction','death'];by_pose={r['pose']:r for r in alpha['rows']}
results=[]
for row in data['rows']:
    failures=[];visible_failures={str(t):0 for t in [1,8,10,32,128]};poses=set();startup=[]
    for q in row['draws']:
        pose=names[int(q['source'][1]/512)*3+int(q['source'][0]/512)];poses.add(pose);W,H=q['backing'];p=q['points']
        inside=lambda points:all(-1e-7<=x['x']<=W+1e-7 and -1e-7<=x['y']<=H+1e-7 for x in points)
        if not inside(p):failures.append(q)
        for threshold in [1,8,10,32,128]:
            left,top,right,bottom=by_pose[pose]['thresholdBBoxes'][str(threshold)]
            projected=[{'x':p[0]['x']+(p[1]['x']-p[0]['x'])*x/512+(p[2]['x']-p[0]['x'])*y/512,'y':p[0]['y']+(p[1]['y']-p[0]['y'])*x/512+(p[2]['y']-p[0]['y'])*y/512} for x,y in [(left,top),(right,top),(left,bottom),(right,bottom)]]
            if not inside(projected):visible_failures[str(threshold)]+=1
        if row['name']=='natural-mobile-startup' and len(startup)<5 and not inside(p):startup.append(q)
    if row['variant']=='candidate':assert not failures
    results.append({'variant':row['variant'],'name':row['name'],'draws':len(row['draws']),'poses':sorted(poses),'wholeCellViolations':len(failures),'projectedAlphaSupportViolations':visible_failures,'naturalStartupViolationSamples':startup,'naturalStartupMutedViolations':sum(q['wrapperOpacity']=='0' for q in failures) if row['name']=='natural-mobile-startup' else None,'naturalStartupVisibleWrapperViolations':sum(q['wrapperOpacity']!='0' for q in failures) if row['name']=='natural-mobile-startup' else None})
candidate_poses=set(p for r in results if r['variant']=='candidate' for p in r['poses']);assert candidate_poses==set(names)
for name in set(r['name'] for r in data['rows']):
    pair=[r for r in data['rows'] if r['name']==name]
    assert len(pair)==2
    before=[s for s in pair[0]['steps'] if 'action' in s];after=[s for s in pair[1]['steps'] if 'action' in s]
    assert [s['action'] for s in before]==[s['action'] for s in after]
    assert [s['result'] for s in before]==[s['result'] for s in after]
report={'qualification':'Projected original alpha support uses explicit thresholds and a bounding box, not human perception/segmentation. Natural startup overflow occurs predominantly in an opacity0 muted title; a synchronous stale-backing draw also occurs after Resume before resize. These logs do not prove that intermediate draw was presented to the user. Tall/220px scenarios are intentional private Canvas geometry stress, not supported mobile app layout/native hardware. Normal supported geometry equality is separately asserted.','canonicalActionResultsPairedExact':True,'allSixCandidatePosesObserved':True,'cases':len(results),'candidateDraws':sum(r['draws'] for r in results if r['variant']=='candidate'),'candidateWholeCellViolations':0,'results':results}
(O/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'cases':len(results),'candidateDraws':report['candidateDraws'],'allSixPoses':True,'wholeCellCandidateViolations':0,'natural':[{k:r[k] for k in ['variant','wholeCellViolations','naturalStartupMutedViolations','naturalStartupVisibleWrapperViolations']} for r in results if r['name']=='natural-mobile-startup']}))
geometry=json.loads((O/'geometry-probe.json').read_text());items=[r for r in geometry['rows'] if r['width']==390 and r['height']==939][0]
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="900" height="1070" viewBox="0 0 900 1070"><rect width="900" height="1070" fill="#101719"/><text x="25" y="30" fill="#ddd1b8" font-family="sans-serif" font-size="18">Whole-cell geometry at390×939 — source pixels unchanged</text>']
for col,(name,color) in enumerate([('baseline','#ba715f'),('candidate','#8ba991')]):
    x=35+col*440;y=90;g=items[name];size=g['bodyHeight']*512/418;floor=g['feet']['y'];svg.append(f'<g transform="translate({x},{y})"><text x="0" y="-20" fill="{color}" font-family="sans-serif">{name}: cell{size:.2f}px, body{g["bodyHeight"]:.2f}px</text><rect width="390" height="939" fill="#1d272a" stroke="#d0c2a4"/><line x1="0" x2="390" y1="{floor}" y2="{floor}" stroke="#cfb376"/>')
    for index,pose in enumerate(['idle','death']):
        ground=502 if pose=='idle' else441;top=floor-size*ground/512;left=195-size/2;style='' if index==0 else 'stroke-dasharray="5 4"';svg.append(f'<rect x="{left}" y="{top}" width="{size}" height="{size}" fill="none" stroke="{color}" {style}/><text x="5" y="{top+15}" fill="{color}" font-size="12" font-family="sans-serif">{pose} whole cell</text>')
    svg.append('</g>')
svg.append('<text x="25" y="1050" fill="#b6c0bf" font-family="sans-serif" font-size="12">Boot plane stays fixed; normal supported arena geometry is numerically identical.</text></svg>')
(O/'geometry-diagram.svg').write_text(''.join(svg))
