import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import * as before from './baseline/src/hunter-presence.ts';
import * as after from './candidate/src/hunter-presence.ts';
const normal=[[502,277],[758,277],[1398,273],[1398,390],[390,220],[900,400]];
for(const[w,h]of normal)assert.deepEqual(after.hunterGeometry(w,h),before.hunterGeometry(w,h));
const rows=[];
for(const width of[1,4,10,80,120,220,360,390,502,758,1398])for(const height of[1,4,10,80,220,277,390,720,939,1200]){
 const base=before.hunterGeometry(width,height),next=after.hunterGeometry(width,height);
 const poses=[];
 for(const[name,frame]of Object.entries(after.HUNTER_R3_FRAMES))for(const facing of[-1,1]){
  const rect=(g:ReturnType<typeof after.hunterGeometry>)=>{const size=g.bodyHeight*512/418;return{x:g.feet.x-size/2,y:g.feet.y-size*frame.groundY/512,width:size,height:size};};
  const old=rect(base),current=rect(next);
  assert(current.x>=-1e-9&&current.y>=-1e-9&&current.x+current.width<=width+1e-9&&current.y+current.height<=height+1e-9);
  poses.push({name,facing,baseline:old,candidate:current,wholeCandidateCellInside:true,baselineOutside:old.x<0||old.y<0||old.x+old.width>width||old.y+old.height>height});
 }
 rows.push({width,height,baseline:base,candidate:next,commonScaleRatio:next.bodyHeight/base.bodyHeight,poses});
}
await fs.writeFile('/workspace/scratch/hunter-cell-containment-author-v08-r1/geometry-probe.json',JSON.stringify({scope:'Pure layout contract over110 positive geometry pairs ×6 unchanged source cells ×2 orientations. Actual browser actions/painted source-alpha support are separate checks. Six normal supported arena geometries retain exact original numerical geometry.',normalExact:normal,rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({layouts:rows.length,poseOrientationChecks:rows.reduce((n,r)=>n+r.poses.length,0),normalExact:normal.length,baselineLayoutsWithOutsideCells:rows.filter(r=>r.poses.some(p=>p.baselineOutside)).length,candidateOutside:0}));
