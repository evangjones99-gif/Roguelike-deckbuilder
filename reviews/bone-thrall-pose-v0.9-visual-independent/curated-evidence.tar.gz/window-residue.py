from pathlib import Path
import json,numpy as np
from PIL import Image
P=Path.cwd();rs=json.loads((P/'METADATA-WINDOWS-R3.json').read_text());out=[]
for r in rs:
 im=Image.open(r['path']);a=np.asarray(im.getchannel('A'));inside=np.zeros(a.shape,dtype=bool)
 for w in r['windows']:
  l,t,rr,b=w['rect'];inside[t:b,l:rr]=True
 residue={}
 for threshold in [1,8,32,128]:
  yy,xx=np.where((a>=threshold)&~inside);residue[str(threshold)]={'pixels':len(xx),'bbox':[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]if len(xx)else None,'sample':[[int(x),int(y),int(a[y,x])]for x,y in zip(xx[:20],yy[:20])]}
 out.append({'name':r['name'],'outsideUnionOfOwnMetadataWindows':residue,'scope':'Outside pixels remain preserved in original rawPNG. No deleted/masked/repaired pixel or recovered off-canvas anatomy claim.'})
(P/'WINDOW-RESIDUE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
