from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
from scipy import ndimage
P=Path('/workspace/scratch/bone-thrall-pose-visual-independent-v09-r1');H=lambda b:hashlib.sha256(b).hexdigest();root=Path('/workspace/scratch');source=[];packets=[]
for version,digest in [('r1','28cb01a89e4c07e0b46bd83f98730658ef68d822447bd94503168613639da42f'),('r2','d93dbe13a60b898d378d6e09dfd2646316a1135e5beaf8c95ea691c9776494bc')]:
 p=root/('bone-thrall-pose-study-author-v09-'+version);b=(p/'MANIFEST.json').read_bytes();assert H(b)==digest;r=json.loads(b)
 for row in r['files']:
  f=p/row['path'];assert f.stat().st_size==row['bytes']and H(f.read_bytes())==row['sha256']
 packets.append({'path':str(p),'manifestSHA256':digest,'allRowsExact':True,'files':r['files']})
for name,path,digest in [('original',root/'bone-thrall-art-author-v09-r1/generated-original-r1.png','3697dd4cc89f1550e0688b34bb421939988c90ab78832ce83d53ddb81b372dfd'),('R1',root/'bone-thrall-pose-study-author-v09-r1/generated-study-r1.png','7949ae070da0d964fa72c529b9e18ecffafd39f913a9f5b8fdaa6e9afc605dfc'),('R2',Path('/workspace/generated_images/exec-2c9f5f2a-2e28-46f1-b395-fca77952bf7c.png'),'440bdad1f593538aeb1a5e2a44e5f611bbd8339f36146b11a069a72c4c2f93b2')]:
 b=path.read_bytes();assert H(b)==digest;im=Image.open(path);a=np.asarray(im.getchannel('A'));r={'name':name,'path':str(path),'sha256':digest,'bytes':len(b),'mode':im.mode,'dimensions':im.size,'zeroPixels':int((a==0).sum()),'alphaRange':[int(a.min()),int(a.max())],'thresholds':{}}
 for threshold in [1,8,32,128]:
  mask=a>=threshold;labels,n=ndimage.label(mask,np.ones((3,3),dtype=np.uint8));sizes=np.bincount(labels.ravel());objects=ndimage.find_objects(labels);largest=sorted(range(1,n+1),key=lambda i:int(sizes[i]),reverse=True)[:16];r['thresholds'][str(threshold)]={'painted':int(mask.sum()),'components':n,'largest':[{'label':i,'pixels':int(sizes[i]),'bbox':[objects[i-1][1].start,objects[i-1][0].start,objects[i-1][1].stop,objects[i-1][0].stop]}for i in largest]}
  if name!='original':
   cells=[]
   for i in range(6):
    x=(i%3)*512;y=(i//3)*512;m=mask[y:y+512,x:x+512];yy,xx=np.where(m);bbox=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]if len(xx)else None
    cells.append({'pose':i,'bbox':bbox,'edges':{'left':int(m[:,0].sum()),'right':int(m[:,-1].sum()),'top':int(m[0,:].sum()),'bottom':int(m[-1,:].sum())}})
   r['thresholds'][str(threshold)]['fixedCells']=cells
 source.append(r)
(P/'SOURCE-READBACK.json').write_text(json.dumps({'packets':packets,'source':[{k:v for k,v in r.items()if k!='thresholds'}for r in source],'method':'Read-only raw PNG bytes/PIL channels; no image edit, alpha repair, masking, crop raster, generation or runtime integration.'},indent=2)+'\n')
(P/'COMPONENT-GEOMETRY.json').write_text(json.dumps(source,indent=2)+'\n')
for r in source:
 print(r['name'],[(c['pixels'],c['bbox'])for c in r['thresholds']['8']['largest'][:10]])
