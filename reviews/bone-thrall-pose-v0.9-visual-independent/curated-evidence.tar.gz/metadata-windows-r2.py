from pathlib import Path
from PIL import Image
from scipy import ndimage
import numpy as np,json,hashlib
P=Path.cwd();raw=json.loads((P/'COMPONENT-GEOMETRY.json').read_text());order=['idle','anticipation','attack','recovery','reaction','death'];records=[]
for r in raw:
 if r['name']=='original':continue
 a=np.asarray(Image.open(r['path']).getchannel('A'));levels={};mains={}
 for t in [1,8,32,128]:
  labs,n=ndimage.label(a>=t,np.ones((3,3),np.uint8));sizes=np.bincount(labs.ravel());objs=ndimage.find_objects(labs);largest=sorted(range(1,n+1),key=lambda i:int(sizes[i]),reverse=True)[:6]
  sortedlabels=sorted(largest,key=lambda i:((objs[i-1][0].start>500),objs[i-1][1].start))
  levels[t]=(labs,sizes,objs,sortedlabels)
 windows=[]
 # R1 alpha1 cloth merges figures, so smallest alpha8 body hulls are used to prove even significant-anatomy rectangle collision.
 chosen=8 if r['name']=='R1' else 1;labs,sizes,objs,keys=levels[chosen]
 for i,k in enumerate(keys):
  y,x=objs[k-1];padding=0 if r['name']=='R1'else 6;rect=[max(0,x.start-padding),max(0,y.start-padding),min(a.shape[1],x.stop+padding),min(a.shape[0],y.stop+padding)];observations=[]
  for t,(labels,sz,ob,ids)in levels.items():
   if len(ids)!=6:continue
   mine=ids[i];mask=labels[rect[1]:rect[3],rect[0]:rect[2]];foreign=[{'pose':order[j],'pixels':int((mask==idx).sum())}for j,idx in enumerate(ids)if j!=i and np.any(mask==idx)]
   observations.append({'alphaThreshold':t,'ownMainComponentPixelsTotal':int(sz[mine]),'ownMainComponentPixelsInside':int((mask==mine).sum()),'foreignMainComponentsInside':foreign,'otherNonzeroPixelsInside':int(((mask!=0)&~np.isin(mask,ids)).sum())})
  windows.append({'pose':order[i],'rect':rect,'width':rect[2]-rect[0],'height':rect[3]-rect[1],'observations':observations,'wholeImageCropFractions':{'x':rect[0]/1536,'y':rect[1]/1024,'width':(rect[2]-rect[0])/1536,'height':(rect[3]-rect[1])/1024}})
 records.append({'name':r['name'],'path':r['path'],'sha256':r['sha256'],'windowRule':f'Bounding rectangle of top-six dominant alpha{chosen} components, row/x order, {padding}px extra margin; no pixel rewriting or connected-component masking. Threshold geometry is not anatomical segmentation.','windows':windows})
(P/'METADATA-WINDOWS.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:
 print(r['name'])
 for w in r['windows']:print(w['pose'],w['rect'],[(o['alphaThreshold'],o['ownMainComponentPixelsTotal']-o['ownMainComponentPixelsInside'],o['foreignMainComponentsInside'],o['otherNonzeroPixelsInside'])for o in w['observations']])
