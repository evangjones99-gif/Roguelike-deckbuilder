from pathlib import Path
from PIL import Image
from scipy import ndimage
import numpy as np,json
P=Path.cwd();raw=json.loads((P/'COMPONENT-GEOMETRY.json').read_text());result=[]
for r in raw:
 im=Image.open(r['path']).convert('RGBA');rgba=np.asarray(im);a=rgba[:,:,3];labs,n=ndimage.label(a>=8,np.ones((3,3),np.uint8));sizes=np.bincount(labs.ravel());major=[i for i in range(1,n+1)if sizes[i]>=10_000];shape=(a.shape[1],a.shape[0]);bands={}
 for name,lo,hi in [('zero',0,0),('1to7',1,7),('8to31',8,31),('32to127',32,127),('128to253',128,253),('254',254,254),('255',255,255)]:
  m=(a>=lo)&(a<=hi);bands[name]={'pixels':int(m.sum()),'fraction':float(m.mean())}
 # Read-only dilation measures visible alpha outside an explicitly geometric near-silhouette neighborhood.
 majorMask=np.isin(labs,major);outside={}
 for radius in [0,4,12,24]:
  near=ndimage.binary_dilation(majorMask,iterations=radius)if radius else majorMask
  m=~near;outside[str(radius)]={'pixels':int(m.sum()),'alphaMean':float(a[m].mean()),'alphaMax':int(a[m].max()),'alpha1':int(((a>=1)&m).sum()),'alpha8':int(((a>=8)&m).sum()),'alpha32':int(((a>=32)&m).sum()),'alpha128':int(((a>=128)&m).sum()),'equivalentOpaquePixels':float(a[m].sum()/255)}
 points=[(0,0),(shape[0]-1,0),(0,shape[1]-1),(shape[0]-1,shape[1]-1)]
 if r['name']!='original':points += [(512,250),(512,700),(1000,600),(800,20),(800,512),(1200,640),(1100,700),(40,450),(1000,980)]
 else:points += [(30,500),(1200,50),(20,1000),(1000,200),(250,250)]
 result.append({'name':r['name'],'path':r['path'],'sha256':r['sha256'],'alphaBands':bands,'dominantAlpha8ComponentsOver10k':len(major),'outsideDominantSilhouetteNeighborhood':outside,'sampleRGBA':[{'xy':q,'rgba':list(map(int,rgba[q[1],q[0]]))}for q in points],'transparentRGBNonzeroPixels':int(((a==0)&(rgba[:,:,:3].max(axis=2)>0)).sum()),'interpretation':'RGB is undefined visually when alpha0; proper alpha-aware compositing multiplies it to zero. These measurements cannot assign semitransparent cloth to background, certify skeleton anatomy or judge native preview compositing.'})
(P/'ALPHA-BACKGROUND.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items()if k not in['sampleRGBA']}for r in result],indent=2))
