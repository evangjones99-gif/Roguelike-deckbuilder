from pathlib import Path
import json,hashlib
P=Path.cwd();H=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((P/'SOURCE-READBACK.json').read_text());after=[]
for p in before['packets']:
 root=Path(p['path']);assert H((root/'MANIFEST.json').read_bytes())==p['manifestSHA256']
 for r in p['files']:
  f=root/r['path'];assert f.stat().st_size==r['bytes']and H(f.read_bytes())==r['sha256']
 after.append({'path':p['path'],'manifestSHA256':p['manifestSHA256'],'allRowsExact':True})
for r in before['source']:
 f=Path(r['path']);assert f.stat().st_size==r['bytes']and H(f.read_bytes())==r['sha256']
(P/'SOURCE-AFTER.json').write_text(json.dumps({'packets':after,'allRawPNGUnchanged':True},indent=2)+'\n')
(P/'VIEWED.json').write_text(json.dumps({'rawOriginalsPersonallyOpened':[r['path']for r in before['source']],'productionOriginalAliasAlsoOpened':'/tmp/hollowpact-relic-bone-v09-root-r1/public/art/bone-thrall-v09-r1.png','ownStaticCapturesPersonallyOpened':['checker-1280.jpg','dark-390.jpg','light-1280.jpg'],'noAuthorCaptureSubstitution':True},indent=2)+'\n')
(P/'RESULT.json').write_text(json.dumps({'R1':'REJECT fixed grid and clean complete rectangular frame sampling','R2':'REJECT direct fixed grid; metadata-only complete-frame geometry viable for separately authored prototype, not runtime/anatomy/animation approval','amberBackground':'No near-opaque background in actual alpha/proper tested browser compositing; faint fringe persists','staticContexts':3,'browsersClosed':True,'ephemeralServerClosed':True,'rawEdited':False,'newGeneration':False,'runtimeWrites':False,'rawCopies':False,'AAAHumanHearingNativeSteamClaims':False,'authorPacketsAndRawPrePostExact':True,'authoritativeMetadata':'METADATA-WINDOWS-R3.json'},indent=2)+'\n')
files={f.relative_to(P).as_posix():{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size}for f in sorted(P.rglob('*'))if f.is_file()and f.name!='MANIFEST.json'};total=sum(v['bytes']for v in files.values());assert total<=1_000_000
(P/'MANIFEST.json').write_text(json.dumps({'files':files,'count':len(files),'bytes':total,'scope':'Independent read-only rejected pose research, exact external raw hashes referenced; no art/runtime edits. All failures preserved.'},indent=2)+'\n');print(json.dumps({'files':len(files),'bytes':total,'reviewSHA256':files['REVIEW.md']['sha256'],'manifestSHA256':H((P/'MANIFEST.json').read_bytes())}))
