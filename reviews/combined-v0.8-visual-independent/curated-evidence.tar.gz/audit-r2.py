from pathlib import Path
import json,gzip,hashlib,math
O=Path('.');R=Path('/workspace/Roguelike-deckbuilder');p=json.loads((R/'dist/build-provenance.json').read_text());before=json.loads((O/'actual-provenance-before.json').read_text());assert p==before
for f,digest in p['hashes'].items():assert hashlib.sha256((R/f).read_bytes()).hexdigest()==digest,f
r1=json.loads(gzip.decompress((O/'FAILURE.json.gz').read_bytes()));r2raw=gzip.decompress((O/'results.json.gz').read_bytes());r2=json.loads(r2raw);receipt=json.loads((O/'RESULTS-RECEIPT.json').read_text());assert hashlib.sha256(r2raw).hexdigest()==receipt['decodedSHA256'];assert len(r2raw)==receipt['decodedBytes']
rows=r1['rows']+r2['rows'];violations=[];total=0;art=0;contact=[];floor=[];paired=[]
for r in rows:
 for response in r['artResponses']:
  assert response['status']==200
  key='public'+response['url'].split('/art',1)[1];key='public/art'+response['url'].split('/art',1)[1]
  assert response['sha256']==r['provenance']['hashes'][key],key;art+=1
 for step in r['steps']:
  for q in step.get('draws',[]):
   if not q['arena']:continue
   total+=1
   if any(x['x'] < -1 or x['y'] < -1 or x['x']>q['size'][0]+1 or x['y']>q['size'][1]+1 for x in q['points']):violations.append({'variant':r['variant'],'case':r['name'],'stage':step['stage'],'viewport':r['viewport'],'url':q['url'],'size':q['size'],'points':q['points'],'at':q['at']})
 if r['name']=='hound-far':
  jaws=[]
  for step in r['steps']:
   for q in step.get('draws',[]):
    if q['arena'] and q['url'].endswith('hound-poses.png')and q['source'][:2]==[1056,96]:
     tx=(432-32)/448;ty=(255-96)/384;P=q['points'];jaw={k:(P[0][k]*(1-tx)+P[1][k]*tx)*(1-ty)+(P[2][k]*(1-tx)+P[3][k]*tx)*ty for k in ['x','y']};w,h=q['size'];size=min(h*.43,w/7*.92);target={'x':w*6/7,'y':h*.5-size*.43};jaws.append({'at':q['at'],'jaw':jaw,'target':target,'distance':math.hypot(jaw['x']-target['x'],jaw['y']-target['y'])})
  assert jaws;contact.append({'variant':r['variant'],'viewport':r['viewport'],'minimumMeasuredJawError':min(q['distance']for q in jaws),'attackDrawSamplesIncludingRepeatedSnapshots':len(jaws),'closest':min(jaws,key=lambda q:q['distance']),'qualification':'Painted authored source landmark432/255 to actual resolved far-target torso projection. Natural samples repeated and per-strike ages unequal; not deterministic timing certification.'})
 if r['variant'].startswith('candidate') and r['name']=='crypt-full-6v6':
  last=r['steps'][-1];backs=[q for q in last['draws']if 'ossuary-crypt' in q['url']and not q['arena']]
  if backs:
   q=backs[-1];dy=q['dest'][1];dh=q['dest'][3];floor.append({'viewport':r['viewport'],'canvas':last['rect'],'projectedManualSeam363':dy+363*dh/760,'enemyFootLine':last['rect'][1]*.5,'conservativeClearance':last['rect'][1]*.5-(dy+363*dh/760),'qualification':'Retained prior manual347±16sourcepx annotation projected through actual current draw; not a new automatic segmentation/pose grounding proof.'})
for r in r2['rows']:
 if r['variant'].startswith('candidate') and r['name']!='missing-crypt':
  match=next(x for x in r2['rows']if x['variant'].startswith('baseline')and x['name']==r['name']and x['viewport']==r['viewport']);a=[s['expected']for s in r['steps']if 'action'in s];b=[s['expected']for s in match['steps']if 'action'in s];assert a==b;paired.append({'case':r['name'],'viewport':r['viewport'],'stateEventsExact':True})
nonhunter=[q for q in violations if not q['url'].endswith('hunter-marek-v07-r3.png')]
(O/'NONHUNTER-FINDING.json').write_text(json.dumps(nonhunter,indent=2)+'\n')
summary={'runtimeDigest':p['sourceDigest'],'actualAll76InputsExactBeforeAfter':True,'runtimeUnchanged':True,'r1CompletedBeforeOwnHarnessFailure':len(r1['rows']),'r2Completed':len(r2['rows']),'totalCompletedActualCases':len(rows),'actions':sum(sum('action'in s for s in r['steps'])for r in rows),'affectedPairedCanonicalStateEvents':paired,'artResponsesExact':art,'arenaImageCellSamplesIncludingRepeatedSnapshots':total,'fullCellViolations':violations,'nonHunterCellViolations':len(nonhunter),'jawContact':contact,'cryptFloor':floor,'artifactCount':len(list(O.glob('*.jpg'))),'qualification':'No hardware/hearing/human-fun/AAA/native approval; natural captures are not equal-age deterministic A/B. Strict startup hunter-cell issue retained.'}
(O/'AUDIT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:summary[k]for k in ['r1CompletedBeforeOwnHarnessFailure','r2Completed','totalCompletedActualCases','actions','artResponsesExact','arenaImageCellSamplesIncludingRepeatedSnapshots','nonHunterCellViolations']}));print('hunter-cell-violations',len(violations));print('jaws',[(x['variant'],x['viewport']['width'],x['minimumMeasuredJawError'])for x in contact]);print('floor',[(x['viewport'],x['conservativeClearance'])for x in floor])
