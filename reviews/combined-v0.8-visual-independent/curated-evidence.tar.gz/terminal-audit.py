from pathlib import Path
import json,gzip
O=Path('.');r=json.loads(gzip.decompress((O/'results.json.gz').read_bytes()));term=[];bindings=[]
for row in r['rows']:
 if row['name'] in ['final-kill','hunter-defeat']:
  held=[s for s in row['steps']if str(s.get('stage','')).startswith('natural-')and 'held'in s]
  final=next(s for s in row['steps']if s.get('stage')=='hold-released');assert len(held)==4;assert all(s['held']for s in held);assert not final['held']
  count=sum(sum(q['url'].endswith('warleader-poses.png')and q['source'][:2]==[1024,544]for q in s.get('draws',[]))for s in held)if row['name']=='final-kill' else sum(sum(q['url'].endswith('hunter-marek-v07-r3.png')and q['source'][:2]==[1024,512]for q in s.get('draws',[]))for s in held)
  assert count>0;term.append({'variant':row['variant'],'case':row['name'],'viewport':row['viewport'],'allFourNaturalSamplesHeld':True,'settledRelease':True,'deathCellSamplesIncludingRepeatedDraws':count})
 if row['name']=='binding-resize':
  stage=next(s for s in row['steps']if s.get('stage')=='binding-after-resize');final=next(s for s in row['steps']if s.get('stage')=='binding-settled');assert stage['save']==final['save'];assert stage['allyButtons']==1;bindings.append({'variant':row['variant'],'viewportBefore':row['viewport'],'canvasAfter':stage['rect'],'oneBindingAndExactSaveThroughResize':True})
(O/'TERMINAL-AND-BINDING-AUDIT.json').write_text(json.dumps({'terminal':term,'binding':bindings},indent=2)+'\n');print('term',len(term),'bindings',len(bindings));print('durableBytes',sum(x.stat().st_size for x in O.rglob('*')if x.is_file()and not x.is_symlink()))
