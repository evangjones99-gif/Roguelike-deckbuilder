import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {Readable} from 'node:stream';import {createRequire} from 'node:module';
import{getRawHeader}from'@electron/asar';import {assertPackagedAsar} from './windows-installer-asar-validation.mjs';import {hash,hashFile} from './windows-installer-guards.mjs';
const require=createRequire(import.meta.url);const {createPackageFromStreams}=require(path.join(path.dirname(require.resolve('app-builder-lib/package.json')),'node_modules/@electron/asar/lib/asar.js'));
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'hollowpact-asar-negative-author-v09-'));let counter=0;
const digest=object=>hash(JSON.stringify(object));
async function fixture(options={}){
 const dir=path.join(tmp,String(++counter));fs.mkdirSync(dir);const source=path.join(dir,'source');fs.mkdirSync(path.join(source,'desktop'),{recursive:true});fs.mkdirSync(path.join(source,'dist'),{recursive:true});
 const pkg={name:'fixture',version:'0.9.0',description:'test',main:'desktop/main.cjs',repository:{type:'git',url:'https://example.invalid/test'},author:'test',license:'UNLICENSED',type:'module',bugs:{url:'https://example.invalid/test/issues'},homepage:'https://example.invalid/test',private:true};
 const packageBytes=Buffer.from(JSON.stringify(pkg,null,2));const mainBytes=Buffer.from('fixture main\n');fs.writeFileSync(path.join(source,'package.json'),packageBytes);fs.writeFileSync(path.join(source,'desktop/main.cjs'),mainBytes);
 const probeBytes=Buffer.from('nested mixed-case desktop probe\n');
 const nestedSource='desktop/QA/Nested/Probe.CJS';
 if(options.nested){fs.mkdirSync(path.join(source,'desktop','QA','Nested'),{recursive:true});fs.writeFileSync(path.join(source,...nestedSource.split('/')),probeBytes);}
 const hashes={'desktop/main.cjs':hash(mainBytes),...(options.nested?{[nestedSource]:hash(probeBytes)}:{}),'package.json':hash(packageBytes)};const runtime={version:pkg.version,sourceDigest:digest(hashes),hashes,node:process.version};const runtimeBytes=Buffer.from(JSON.stringify(runtime,null,2)+'\n');const htmlBytes=Buffer.from('<h1>fixture</h1>\n');fs.writeFileSync(path.join(source,'dist/build-provenance.json'),runtimeBytes);fs.writeFileSync(path.join(source,'dist/index.html'),htmlBytes);
 const nestedDist=options.nested?[['dist/art/PROVENANCE.json',Buffer.from('{\"original\":true}\n')],['dist/art/Creatures/BoneThrall.JSON',Buffer.from('{\"anatomy\":\"fixture\"}\n')]]:[];
 for(const [name,bytes]of nestedDist){const file=path.join(source,...name.split('/'));fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,bytes);}
 const canonical=[['desktop/main.cjs',mainBytes],...(options.nested?[[nestedSource,probeBytes]]:[]),['dist/build-provenance.json',runtimeBytes],['dist/index.html',htmlBytes],...nestedDist,['package.json',packageBytes]];
 const entries=options.transform?options.transform(canonical.map(([name,bytes])=>[name,Buffer.from(bytes)])):canonical;
 const archive=path.join(dir,'app.asar');const streams=entries.map(([name,bytes])=>({path:path.join(...name.split('/')),type:'file',unpacked:false,stat:{mode:0o100644,size:bytes.length},streamGenerator:()=>Readable.from(bytes)}));
 await createPackageFromStreams(archive,streams);const raw=getRawHeader(archive);
 let offset=0;const leaves=canonical.map(([name,bytes])=>{const block=hash(bytes);const record={path:name,bytes:bytes.length,sha256:block,offset:String(offset),integrity:{algorithm:'SHA256',hash:block,blockSize:4194304,blocks:[block]}};offset+=bytes.length;return record});
 const expected={version:pkg.version,sourceDigest:runtime.sourceDigest,sourceHashes:hashes,sourceInputCount:Object.keys(hashes).length,distOutputCount:canonical.filter(([name])=>name.startsWith('dist/')).length,leafCount:canonical.length,asarSHA256:await hashFile(archive),asarBytes:fs.statSync(archive).size,rawHeaderStringSHA256:hash(raw.headerString),normalizedManifest:{keys:Object.keys(pkg),sha256:hash(packageBytes),bytes:packageBytes.length,json:pkg},leaves};
 return {archive,source,expected,canonical};
}
function rewriteHeader(f,transform){const bytes=fs.readFileSync(f.archive);const raw=getRawHeader(f.archive);const original=raw.header;const next=transform(structuredClone(original));const text=Buffer.from(JSON.stringify(next));const pickle=require('chromium-pickle-js');const head=pickle.createEmpty();head.writeString(text.toString());const hb=head.toBuffer();const size=pickle.createEmpty();size.writeUInt32(hb.length);const rewritten=Buffer.concat([size.toBuffer(),hb,bytes.subarray(8+raw.headerSize)]);const file=f.archive+'.altered.asar';fs.writeFileSync(file,rewritten);f.archive=file;f.expected.asarSHA256=hash(rewritten);f.expected.asarBytes=rewritten.length;f.expected.rawHeaderStringSHA256=hash(text);return f;}

test('actual serialized canonical small fixture admitted with all raw source/dist correspondence',async()=>{const f=await fixture();const result=await assertPackagedAsar(f.archive,f.source,f.expected);assert.equal(result.leafCount,4)});
test('changed ASAR data without changing pinned envelope refused',async()=>{const f=await fixture();const b=fs.readFileSync(f.archive);b[b.length-1]^=1;const file=f.archive+'.corrupt';fs.writeFileSync(file,b);await assert.rejects(assertPackagedAsar(file,f.source,f.expected),/Exact builder ASAR bytes differ/)});
test('extra leaf refused even if outer/header pins were maliciously rebased',async()=>{const f=await fixture({transform:rows=>[...rows,['dist/secret.bin',Buffer.from('unexpected')]]});await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Closed ASAR leaf count differs/)});
test('missing leaf refused even when outer/header pins match altered serialized archive',async()=>{const f=await fixture({transform:rows=>rows.filter(([p])=>p!=='dist/index.html')});await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Closed ASAR leaf count differs/)});
test('changed raw payload refused with unchanged expected leaf ledger despite rebased outer pins',async()=>{const f=await fixture({transform:rows=>rows.map(([p,b])=>[p,p==='dist/index.html'?Buffer.from('<h1>altered</h1>\n'):b])});await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Closed ASAR names/)});
test('changed normalized manifest field refused with otherwise matching serialized leaf pins',async()=>{const f=await fixture({transform:rows=>rows.map(([p,b])=>[p,p==='package.json'?Buffer.from(b.toString().replace('"private": true','"private": false')):b])});const bytes=fs.readFileSync(f.archive);const raw=getRawHeader(f.archive);const leaf=raw.header.files['package.json'];const index=f.expected.leaves.findIndex(r=>r.path==='package.json');f.expected.leaves[index]={path:'package.json',bytes:leaf.size,sha256:leaf.integrity.hash,offset:leaf.offset,integrity:leaf.integrity};await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Normalized manifest exact bytes differ/)});
test('header unsafe path refused even with altered matching outer/header pins',async()=>{const f=rewriteHeader(await fixture(),h=>{h.files['des/top']=h.files.desktop;delete h.files.desktop;return h});await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Unsafe ASAR path component|invalid entry name/)});
test('changed source raw bytes refused despite intact packaged bytes and provenance',async()=>{const f=await fixture();fs.appendFileSync(path.join(f.source,'desktop/main.cjs'),'changed');await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Raw source changed/)});
test('changed local output bytes refused despite intact ASAR payload',async()=>{const f=await fixture();fs.appendFileSync(path.join(f.source,'dist/index.html'),'changed');await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Raw dist changed/)});
test('local build metadata mismatch refused independently from static inner source pins',async()=>{const f=await fixture();const p=path.join(f.source,'dist/build-provenance.json');const r=JSON.parse(fs.readFileSync(p));r.node='v0.0.0';fs.writeFileSync(p,JSON.stringify(r));await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Packaged\/local full build metadata differs/)});
test('wrong envelope size and wrong exact header pins refused',async()=>{for(const mutate of [e=>e.asarBytes++,e=>e.rawHeaderStringSHA256='0'.repeat(64)]){const f=await fixture();mutate(f.expected);await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/ASAR size differs|ASAR header\/order differs/)}});
test('actual serialized different stream order refused when rebased envelope/header match',async()=>{const f=await fixture({transform:rows=>rows.reverse()});await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Closed ASAR names/) });
test('serialized ASAR links/unpacked/executable headers refused before following or reading external bytes',async()=>{for(const kind of ['link','unpacked','executable']){const f=rewriteHeader(await fixture(),h=>{const entry=h.files.desktop.files['main.cjs'];if(kind==='link')h.files.desktop.files['main.cjs']={link:'package.json'};else entry[kind]=true;return h});await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Unexpected link\/unpacked\/executable ASAR node/)}});
test('unexpected file-header metadata refused with matching rewritten envelope/header',async()=>{const f=rewriteHeader(await fixture(),h=>{h.files.desktop.files['main.cjs'].invented=true;return h});await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Unexpected file header metadata/)});

test('extra local source or dist leaves refused before accepting stale provenance',async()=>{for(const dir of ['desktop','dist']){const f=await fixture();fs.writeFileSync(path.join(f.source,dir,'extra.bin'),'extra');await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Closed local runtime source set differs|Closed local dist set differs/)}});


test('actual native-path producer preserves nested three-directory mixed-case leaves and POSIX ledger',async()=>{
 const f=await fixture({nested:true});const result=await assertPackagedAsar(f.archive,f.source,f.expected);
 assert.equal(result.leafCount,7);assert.equal(result.sourceInputs,3);assert.equal(result.distOutputs,4);
 assert.ok(result.leaves.some(r=>r.path==='dist/art/PROVENANCE.json'));
 assert.ok(result.leaves.some(r=>r.path==='dist/art/Creatures/BoneThrall.JSON'));
 assert.ok(result.leaves.some(r=>r.path==='desktop/QA/Nested/Probe.CJS'));
 assert.ok(result.leaves.every(r=>!r.path.includes('\\')));
});
test('nested wrong-case archive identity and nested altered local payload refuse with exact envelope/header pins',async()=>{
 const f=await fixture({nested:true,transform:rows=>rows.map(([name,b])=>[name==='dist/art/Creatures/BoneThrall.JSON'?'dist/art/Creatures/bonethrall.JSON':name,b])});
 await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Closed ASAR names/);
 const g=await fixture({nested:true});fs.appendFileSync(path.join(g.source,'dist','art','Creatures','BoneThrall.JSON'),'tampered');
 await assert.rejects(assertPackagedAsar(g.archive,g.source,g.expected),/Raw dist changed/);
});
test('nested extra source and missing archive leaf retain closed inventory refusals',async()=>{
 const f=await fixture({nested:true});fs.writeFileSync(path.join(f.source,'desktop','QA','Nested','Extra.CJS'),'extra');
 await assert.rejects(assertPackagedAsar(f.archive,f.source,f.expected),/Closed local runtime source set differs/);
 const g=await fixture({nested:true,transform:rows=>rows.filter(([name])=>name!=='dist/art/Creatures/BoneThrall.JSON')});
 await assert.rejects(assertPackagedAsar(g.archive,g.source,g.expected),/Closed ASAR leaf count differs/);
});
