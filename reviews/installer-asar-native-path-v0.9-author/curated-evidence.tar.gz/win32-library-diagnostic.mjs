// Actual installed Filesystem source evaluated unchanged; only node:path linking is Win32.
// This is an in-memory path-lookup diagnostic on Linux, NOT a native Windows extraction/install.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {getRawHeader} from '/workspace/Roguelike-deckbuilder/node_modules/@electron/asar/lib/asar.js';
const packet='/workspace/scratch/installer-asar-native-path-author-v09-r1';
const file='/workspace/Roguelike-deckbuilder/node_modules/@electron/asar/lib/filesystem.js';
const archive='/tmp/hollowpact-installer-asar-current801d-producer-author-v09-r1/app.asar';
const raw=getRawHeader(archive),code=fs.readFileSync(file,'utf8');
const sha=b=>createHash('sha256').update(b).digest('hex');
const context=vm.createContext({process,Buffer});
const module=new vm.SourceTextModule(code,{context,identifier:pathToFileURL(file).href});
await module.link(async specifier=>{
 const ns=specifier==='node:path'?{default:path.win32}:await import(specifier.startsWith('.')?new URL(specifier,pathToFileURL(file)).href:specifier);
 return new vm.SyntheticModule(Object.keys(ns),function(){for(const key of Object.keys(ns))this.setExport(key,ns[key]);},{context,identifier:specifier});
});
await module.evaluate();
const Filesystem=module.namespace.Filesystem;
function fresh(){const f=new Filesystem('C:\\fixture');f.setHeader(structuredClone(raw.header),raw.headerSize);return f;}
const expected=JSON.parse(fs.readFileSync(`${packet}/proposed/scripts/windows-installer-asar-payload.json`,'utf8'));
const rows=[];
for(const leaf of expected.leaves){
 const original=fresh(),converted=fresh();let originalSuccess=false,error=null;
 try {const node=original.getFile(leaf.path,false);originalSuccess=true;assert.equal(node.size,leaf.bytes);}catch(e){error=String(e);}
 const native=path.win32.join(...leaf.path.split('/'));const node=converted.getFile(native,false);
 assert.equal(node.size,leaf.bytes);assert.equal(node.offset,leaf.offset);assert.equal(node.integrity.hash,leaf.sha256);
 assert.equal(JSON.stringify(converted.header),JSON.stringify(raw.header),'Native lookup must not invent cached header keys');
 rows.push({logicalPath:leaf.path,nativePath:native,originalSuccess,originalError:error,rawLookupHeaderMutated:JSON.stringify(original.header)!==JSON.stringify(raw.header),nativeMatch:true});
}
assert.equal(rows.length,60);assert.ok(rows.some(r=>r.logicalPath==='dist/art/PROVENANCE.json'&&!r.originalSuccess&&r.rawLookupHeaderMutated));
assert.ok(rows.some(r=>r.logicalPath==='dist/build-provenance.json'&&r.originalSuccess));
const report={schema:1,classification:'Linux-hosted isolated Win32-path diagnostic, not Windows binary/extractFile/install evidence',platform:process.platform,node:process.version,sourcePath:file,sourceSHA256:sha(code),sourceBytes:Buffer.byteLength(code),codeUnmodified:true,override:'ESM linker supplies actual node:path.win32 ONLY for node:path import; all other actual dependency namespaces bridged unmodified',archive,archiveSHA256:sha(fs.readFileSync(archive)),archiveBytes:fs.statSync(archive).size,rawHeaderStringSHA256:sha(raw.headerString),leafCount:rows.length,originalSucceeded:rows.filter(r=>r.originalSuccess).length,originalFailed:rows.filter(r=>!r.originalSuccess).length,nativeMatches:rows.filter(r=>r.nativeMatch).length,rows};
fs.writeFileSync(`${packet}/WIN32-LOOKUP-DIAGNOSTIC.json`,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({originalSucceeded:report.originalSucceeded,originalFailed:report.originalFailed,nativeMatches:report.nativeMatches,sourceSHA256:report.sourceSHA256,actualAsarSHA256:report.archiveSHA256}));
