import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {CARDS} from '../preparation-v08/source/src/engine';
import {SHOP_PRICES} from '../preparation-v08/source/src/content';
const original='/workspace/scratch/preparation-v08',out='/workspace/scratch/preparation-independent-v08';
const read=(p:string)=>JSON.parse(readFileSync(original+'/'+p,'utf8'));
const plan=read('plan.json'),actualProfiles=read('kit-profiles.json').kits;
const expected=plan.kits.map((k:any)=>{const defs=k.deck.map((id:string)=>CARDS[id]);return{id:k.id,size:defs.length,summons:defs.filter((c:any)=>c.type==='summon').length,totalEnergy:defs.reduce((n:number,c:any)=>n+c.cost,0),printedCompanionAttack:defs.reduce((n:number,c:any)=>n+(c.attack||0),0),printedCompanionHP:defs.reduce((n:number,c:any)=>n+(c.hp||0),0),hypotheticalShopGold:defs.reduce((n:number,c:any)=>n+SHOP_PRICES[c.type as keyof typeof SHOP_PRICES],0),cards:defs.map((c:any)=>({id:c.id,name:c.name,cost:c.cost,type:c.type,species:c.species,effect:c.effect,passive:c.passive,text:c.text}))}});
assert.deepEqual(JSON.parse(JSON.stringify(expected)),actualProfiles);
const branches=[];
for(const name of ['sunder','ready','aegis','silence']){const r=read('counterplay/'+name+'.json'),b=r.brief,candidate=r.branch.flatMap((x:any)=>x.events),baseline=r.baseline.events;
const loss=(es:any[],side:'hunter'|'ally')=>es.filter((e:any)=>e.type==='hit'&&(side==='hunter'?e.target==='hunter':e.target.startsWith('a'))).reduce((n:number,e:any)=>n+e.hpLost,0);
assert.equal(loss(baseline,'hunter'),b.baselineHunterDamage);assert.equal(loss(candidate,'hunter'),b.candidateHunterDamage);assert.equal(loss(baseline,'ally'),b.baselineCompanionDamage);assert.equal(loss(candidate,'ally'),b.candidateCompanionDamage);
branches.push({name,hunterLoss:[loss(baseline,'hunter'),loss(candidate,'hunter')],companionLoss:[loss(baseline,'ally'),loss(candidate,'ally')],exactBriefMatches:true});}
const mlPlan=JSON.parse(readFileSync('/workspace/Roguelike-deckbuilder/reviews/ml-policy-0.5-r1/plan.json','utf8'));
assert(!plan.seeds.some((n:number)=>mlPlan.trainSeeds.includes(n)||mlPlan.testSeeds.includes(n)));
const data={printedProfilesExact:true,allFourBranchesDamageArithmeticExact:true,branches,declaredSeedsDisjointFrozenMLTrainAndTest:true,seedScope:'Only inspected frozen ML plan; not externally authenticated globally untouched history.',profiles:expected.map(({cards,...r}:any)=>r)};
writeFileSync(out+'/profiles-and-branches.json',JSON.stringify(data,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(data,null,2));
