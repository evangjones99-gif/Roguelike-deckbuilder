import collections, hashlib, json, pathlib, statistics, math
root=pathlib.Path('/workspace/scratch/preparation-independent-v08')
original=pathlib.Path('/workspace/scratch/preparation-v08')
runs=json.loads((root/'replayed-outcomes.json').read_text())
plan=json.loads((original/'plan.json').read_text())
key=lambda r:(r['generation'],r['policy'],r['acquisition'],r['seed'],r['kit'])
by={key(r):r for r in runs}
assert len(by)==384
pairs=[]
world=[]
for gen in plan['worldGenerations']:
 for policy in plan['policies']:
  for acq in plan['acquisitionArms']:
   for seed in plan['seeds']:
    b=by[(gen,policy,acq,seed,'default')]
    for kit in ['pursuit','vigil','ash']:
     c=by[(gen,policy,acq,seed,kit)]
     pairs.append(dict(generation=gen,policy=policy,acquisition=acq,seed=seed,kit=kit,baselineId=b['id'],candidateId=c['id'],baselineWin=b['win'],candidateWin=c['win'],introducedLoss=b['win'] and not c['win'],rescue=c['win'] and not b['win'],deltas={field:c[field]-b[field] for field in ['hp','steps','turns','hunterHpLost','companionDeaths','enemyHpLost']}))
     bw={(x['kind'],x['floor']):x for x in b['world'] if x['kind']!='acquire'}
     cw={(x['kind'],x['floor']):x for x in c['world'] if x['kind']!='acquire'}
     for wkey in sorted(set(bw)&set(cw)):
      if bw[wkey]!=cw[wkey]:world.append(dict(generation=gen,policy=policy,acquisition=acq,seed=seed,kit=kit,key=list(wkey),baseline=bw[wkey],candidate=cw[wkey]))
assert pairs==json.loads((original/'results/paired-all.json').read_text())
assert world==json.loads((original/'results/world-discrepancies.json').read_text())
perkit={}
for kit in ['pursuit','vigil','ash']:
 p=[x for x in pairs if x['kit']==kit]
 perkit[kit]=dict(n=len(p),introducedLosses=[x for x in p if x['introducedLoss']],rescues=[x for x in p if x['rescue']],lowerHpPairs=sum(x['deltas']['hp']<0 for x in p),moreActionPairs=sum(x['deltas']['steps']>0 for x in p),moreTurnPairs=sum(x['deltas']['turns']>0 for x in p),largestHpDrop=min(x['deltas']['hp'] for x in p),meanDelta={f:statistics.mean(x['deltas'][f] for x in p) for f in ['hp','steps','turns','hunterHpLost','companionDeaths']})
assert perkit==json.loads((original/'results/summary.json').read_text())['perKitPaired']
groups=[]
for gen in [1,2]:
 for kit in ['default','pursuit','vigil','ash']:
  rs=[r for r in runs if r['generation']==gen and r['kit']==kit]
  groups.append(dict(generation=gen,kit=kit,n=len(rs),uniqueSeeds=len(set(r['seed'] for r in rs)),wins=sum(r['win'] for r in rs),mean={f:statistics.mean(r[f] for r in rs) for f in ['hp','steps','turns','hunterHpLost','commandHpLost','spellHpLost']},bosses=dict(collections.Counter(r['battles'][-1]['encounter'][0] for r in rs))))
winonly=[]
for gen in [1,2]:
 for kit in ['pursuit','vigil','ash']:
  ps=[p for p in pairs if p['generation']==gen and p['kit']==kit and p['baselineWin'] and p['candidateWin']]
  winonly.append(dict(generation=gen,kit=kit,n=len(ps),meanDelta={f:statistics.mean(p['deltas'][f] for p in ps) for f in ['hp','steps','turns','hunterHpLost']}))
silence=[]
for gen in [1,2]:
 for policy in plan['policies']:
  rs=[r for r in runs if r['generation']==gen and r['policy']==policy and r['acquisition']=='skip-rewards' and r['kit']=='ash']
  silence.append(dict(generation=gen,policy=policy,n=len(rs),casts=sum(r['played'].get('silence',0)+r['played'].get('silence+',0) for r in rs)))
profiles=json.loads((original/'kit-profiles.json').read_text())['kits']
for p in profiles:
 assert p['size']==12 and len(p['cards'])==12
 assert p['summons']==sum(c['type']=='summon' for c in p['cards'])
assert {p['id']:p['summons'] for p in profiles}==dict(default=5,pursuit=4,vigil=4,ash=4)
summary=dict(episodes=384,pairedComparisons=288,distinctSeeds=12,perKitPaired=perkit,worldDifferences=dict(generation1=sum(x['generation']==1 for x in world),generation2=sum(x['generation']==2 for x in world)),generationGroups=groups,sharedVictoryPairsOnly=winonly,ashSkipSilence=silence,scope='Independent reaggregation of exact reducer-replayed outcomes. Correlated policy/reward arms; actions are not wall-clock pacing or player enjoyment. Legacy world differences are confounded. No additional seeds or tuning.')
for name,obj in [('paired-comparisons.json',pairs),('world-comparisons.json',world),('summary.json',summary)]:
 with (root/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
print(json.dumps(dict(episodes=384,pairs=288,world=summary['worldDifferences'],perKit={k:dict(losses=len(v['introducedLosses']),deltas=v['meanDelta']) for k,v in perkit.items()},silence=silence),indent=2))
