import { createReadStream, readFileSync, writeFileSync } from 'node:fs';
import { createGunzip } from 'node:zlib';
import { createInterface } from 'node:readline';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { createGame, legalActions, applyAction, applyActionWithEvents, validateState, CARDS, type GameState, type Action } from '../preparation-v08/source/src/engine';
import { STARTER_DECK, SHOP_PRICES } from '../preparation-v08/source/src/content';
import { heuristicScore } from '../preparation-v08/source/scripts/simulate';
const original = '/workspace/scratch/preparation-v08', output = '/workspace/scratch/preparation-independent-v08';
const read = (p:string) => JSON.parse(readFileSync(original+'/'+p,'utf8'));
const plan=read('plan.json'), claimed=read('results/outcomes.json'), policy=read('source/reviews/ml-policy-0.5-r1/policy.json');
const sha=(x:string|Buffer)=>createHash('sha256').update(x).digest('hex');
const json=JSON.stringify;
const write=(name:string,x:any)=>writeFileSync(output+'/'+name,JSON.stringify(x,null,2)+'\n',{flag:'wx'});
for(const [p,h] of Object.entries(plan.sourceHashes)){assert.equal(sha(readFileSync(original+'/source/'+p)),h);assert.equal(sha(readFileSync('/workspace/Roguelike-deckbuilder/'+p)),h);}
const learned=readFileSync(original+'/source/scripts/learn-policy.ts','utf8');
const section=learned.slice(learned.indexOf('const sum ='),learned.indexOf('type Episode ='));
assert.equal(sha(section),read('adapter-derivation.json').sectionSha256);
assert.equal(readFileSync(original+'/source/scripts/policy-adapter.ts','utf8'),"import {applyAction,legalActions,validateState,CARDS,type GameState,type Action} from '../src/engine';\n"+section+"\nexport {choose as chooseFrozen, outside as chooseOutside};\n");
function freeze(x:any){if(x&&typeof x==='object'){Object.freeze(x);for(const v of Object.values(x))freeze(v);}return x;}
function outside(s:GameState, actions:Action[]):Action {
 if(s.phase==='map')return actions.find(a=>a.type==='travel'&&a.choice==='camp')??actions.find(a=>a.type==='travel'&&a.choice==='battle')??actions[0];
 if(s.phase==='camp')return actions.find(a=>a.type==='camp'&&a.choice===(s.hp<s.maxHp-14?'rest':'train'))??actions[0];
 if(s.phase==='event')return actions.find(a=>a.type==='event'&&a.choice==='forage')??actions[0];
 if(s.phase==='shop')return actions.find(a=>a.type==='leave')??actions[0];
 if(s.phase==='reward'){
  if(s.deck.length>=19)return actions.find(a=>a.type==='reward'&&a.card===null)!;
  const value=(a:Action)=>{if(a.type!=='reward'||a.card===null)return 0;const c=CARDS[a.card];return c.type==='summon'?(c.attack??0)*2+(c.hp??0)*.25-c.cost*.5:({rally:15,communion:14,ready:13,pack:11,siphon:10,aoe:8,draw:7,block:4,damage:5,energy:1,heal:3,shelter:5} as any)[c.effect]??4;};
  return actions.slice().sort((a,b)=>value(b)-value(a))[0];
 }return actions[0];
}
function choose(s:GameState, legal:Action[], meta:any):Action {
 if(s.phase!=='battle')return s.phase==='reward'&&meta.acquisition==='skip-rewards'?legal.find(a=>a.type==='reward'&&a.card===null)!:outside(s,legal);
 if(meta.policy==='existing-heuristic-combat')return legal.reduce((best,a)=>heuristicScore(s,a)>heuristicScore(s,best)?a:best,legal[0]);
 let best=-Infinity, chosen=legal[0];
 const sum=(x:GameState,k:'hp'|'attack')=>x.allies.reduce((t,u)=>t+u[k],0), eh=(x:GameState)=>x.enemies.reduce((t,u)=>t+u.hp,0);
 const incoming=s.enemies.reduce((n,u)=>n+(['hunter','all'].includes(u.intent?.target??'')?u.intent!.damage:0),0);
 for(const a of legal){const n=applyAction(s,a), battle=n.phase==='battle';assert(validateState(n));const f=[(eh(s)-(battle?eh(n):0))/10,(n.hp-s.hp)/10,battle?(sum(n,'attack')-sum(s,'attack'))/5:0,battle?(sum(n,'hp')-sum(s,'hp'))/15:0,battle?(Math.min(n.block,incoming)-Math.min(s.block,incoming))/10:0,battle?(n.energy-s.energy)/5:0,a.type==='endTurn'?1:0,['reward','victory'].includes(n.phase)?1:n.phase==='defeat'?-2:0];let score=f.reduce((n,x,i)=>n+x*policy.weights[i],0);if(a.type==='attack')score+=.15;if(score>best){best=score;chosen=a;}}
 return chosen;
}
const started=new Date().toISOString(), expectIds=new Set<string>();
for(const gen of plan.worldGenerations)for(const policy of plan.policies)for(const acq of plan.acquisitionArms)for(const seed of plan.seeds)for(const kit of plan.kits)expectIds.add(`g${gen}-${policy}-${acq}-${seed}-${kit.id}`);
assert.equal(expectIds.size,384);assert.equal(claimed.length,384);
const claimedMap=new Map(claimed.map((x:any)=>[x.id,x])), outcomes:any[]=[], sourceStates=new Map<string,GameState>();
const counterplay=read('counterplay/summary.json');
let current:any=null, records=0, transitions=0;
function finish(){if(!current)return;const {meta,s,steps,metrics,trace,initialHash,world,battles,active}=current;if(active)battles.push({...active,endHp:s.hp,turns:s.turn,acceptedActions:steps-active.startActions,result:s.phase});
 const actual={id:meta.id,kit:meta.kit,generation:meta.generation,policy:meta.policy,acquisition:meta.acquisition,seed:meta.seed,difficulty:plan.difficulty,phase:s.phase,win:s.phase==='victory',floor:s.floor,hp:s.hp,minLivingHp:metrics.minLivingHp,steps,turns:s.stats.turns,cardsPlayed:s.stats.cardsPlayed,damageDealtStat:s.stats.damageDealt,enemyHpLost:metrics.enemyHpLost,commandHpLost:metrics.commandHpLost,spellHpLost:metrics.spellHpLost,hunterHpLost:metrics.hunterHpLost,hunterHealEvents:metrics.hunterHealEvents,hunterBlocked:metrics.hunterBlocked,companionHpLost:metrics.companionHpLost,companionDeaths:metrics.companionDeaths,played:metrics.played,actionsCount:metrics.actionsCount,world,battles,initialStateSha256:initialHash,finalStateSha256:sha(json(s)),trajectorySha256:trace.digest('hex'),stalled:!['victory','defeat'].includes(s.phase)};
 assert.deepEqual(actual,claimedMap.get(meta.id),'all outcome fields '+meta.id);assert(!actual.stalled);outcomes.push(actual);}
const lines=createInterface({input:createReadStream(original+'/results/full-state-transitions.jsonl.gz').pipe(createGunzip()),crlfDelay:Infinity});
try{
for await(const line of lines){const row=JSON.parse(line);records++;
 if(row.step===-1){finish();assert(expectIds.delete(row.id),'unknown/duplicate '+row.id);const meta=claimedMap.get(row.id) as any;assert(meta);const kit=plan.kits.find((k:any)=>k.id===meta.kit);let s=createGame(meta.seed,plan.difficulty,{engineKind:meta.generation});assert.deepEqual(s.deck,STARTER_DECK);if(meta.kit!=='default')s={...s,deck:kit.deck.slice()};assert.deepEqual(s,row.state);assert(validateState(s));assert.equal(row.diagnosticKit,meta.kit!=='default');current={meta,s:freeze(s),steps:0,initialHash:sha(json(s)),trace:createHash('sha256').update(json(s)),world:[],battles:[],active:null,metrics:{minLivingHp:s.hp,enemyHpLost:0,commandHpLost:0,spellHpLost:0,hunterHpLost:0,hunterHealEvents:0,hunterBlocked:0,companionHpLost:0,companionDeaths:0,played:{},actionsCount:{}}};
 }else{assert(current);assert.equal(row.id,current.meta.id);assert.equal(row.step,current.steps);const {s,meta,metrics:m}=current;const before=json(s), legal=legalActions(s);assert(legal.some(a=>json(a)===json(row.action)));assert.deepEqual(choose(s,legal,meta),row.action,'policy choice '+row.id+'/'+row.step);const ordinary=applyAction(s,row.action), resolved=applyActionWithEvents(s,row.action);assert.notEqual(ordinary,s);assert.equal(json(s),before);assert(validateState(ordinary));assert.deepEqual(ordinary,resolved.state);assert.deepEqual(ordinary,row.state);assert.deepEqual(resolved.events,row.events);assert.deepEqual(applyAction(JSON.parse(before),row.action),ordinary);assert(validateState(JSON.parse(json(ordinary))));assert.equal(ordinary.schema===2?1:ordinary.engineKind,meta.generation);
 const a=row.action, n=ordinary; m.actionsCount[a.type]=(m.actionsCount[a.type]??0)+1;if(a.type==='play'){const card=s.hand[a.index];m.played[card]=(m.played[card]??0)+1;}
 if(a.type==='travel'&&n.phase==='battle'){current.world.push({kind:'encounter',floor:n.floor,route:a.choice,formation:n.enemies.map(u=>u.cardId)});current.active={floor:n.floor,encounter:n.enemies.map(u=>u.cardId),startHp:n.hp,startActions:current.steps,startTurns:n.stats.turns};}
 if(s.phase==='battle'&&n.phase==='reward')current.world.push({kind:'reward',floor:n.floor,offer:n.rewards.slice()});if(s.phase==='map'&&n.phase==='shop')current.world.push({kind:'shop',floor:n.floor,offer:n.rewards.slice()});if(a.type==='reward')current.world.push({kind:'acquire',floor:s.floor,card:a.card});
 for(const e of resolved.events){if(e.type==='hit'){if(e.target==='hunter'){m.hunterHpLost+=e.hpLost;m.hunterBlocked+=e.blocked;if(current.active)current.active.received=(current.active.received??0)+e.hpLost;}else if(e.target.startsWith('a'))m.companionHpLost+=e.hpLost;else if(e.target.startsWith('e')){m.enemyHpLost+=e.hpLost;if(e.kind==='command')m.commandHpLost+=e.hpLost;if(e.kind==='spell')m.spellHpLost+=e.hpLost;}}else if(e.type==='heal'&&e.target==='hunter')m.hunterHealEvents+=e.amount;else if(e.type==='death'&&e.target.startsWith('a'))m.companionDeaths++;}
 if(n.hp>0)m.minLivingHp=Math.min(m.minLivingHp,n.hp);if(current.active&&s.phase==='battle'&&n.phase!=='battle'){current.battles.push({...current.active,endHp:n.hp,turns:s.turn,acceptedActions:current.steps-current.active.startActions+1,result:n.phase});current.active=null;}
 current.trace.update(json({action:a,state:n,events:resolved.events}));current.s=freeze(n);current.steps++;transitions++;
 }
 for(const c of counterplay)if(c.sourceEpisode===row.id&&c.sourceStep===row.step)sourceStates.set(c.name,row.state);
 if(records%5000===0)console.log(`Verified ${records} records, ${outcomes.length} finished episodes`);
}
finish();assert.equal(expectIds.size,0);assert.equal(records,57029);assert.equal(transitions,56645);
const branchReports=[];
for(const c of counterplay){const report=read('counterplay/'+c.name+'.json'), before=sourceStates.get(c.name)!;assert(before);assert.deepEqual(before,report.before);assert.equal(sha(json(before)),c.sourceStateSha256);const checkStep=(s:GameState,r:any)=>{const a=r.action;if(r.notLegal){assert(!legalActions(s).some(x=>json(x)===json(a)));return s;}assert(legalActions(s).some(x=>json(x)===json(a)));const text=json(s), actual=applyActionWithEvents(freeze(s),a);assert.equal(json(s),text);assert.deepEqual(actual.state,r.state);assert.deepEqual(actual.events,r.events);assert.deepEqual(applyAction(JSON.parse(text),a),actual.state);assert(validateState(actual.state));return actual.state;};checkStep(before,report.baseline);let s=before;for(const r of report.branch)s=checkStep(s,r);assert.equal(report.baseline.state.hp,c.baselineHP);assert.equal(s.hp,c.candidateHP);branchReports.push({name:c.name,sourceEpisode:c.sourceEpisode,sourceStep:c.sourceStep,steps:report.branch.length,sourceExact:true,allLegalReducerEventsExact:true,baselineHP:report.baseline.state.hp,branchHP:s.hp});}
write('replayed-outcomes.json',outcomes);write('counterplay-checks.json',branchReports);write('replay-completion.json',{started,finished:new Date().toISOString(),node:process.version,episodes:outcomes.length,initialStates:384,acceptedTransitions:transitions,stateRecords:records,exactOutcomeFields:true,sourceHashes:plan.sourceHashes,planSha256:sha(readFileSync(original+'/plan.json')),datasetSha256:sha(readFileSync(original+'/results/full-state-transitions.jsonl.gz')),scope:'Independent streamed replay, deep-frozen inputs, exact reducer/event/legal/save/policy checks; no fresh seeds, training, graphical or human playtest.',failure:null});
console.log('PASS '+outcomes.length+' episodes; '+records+' exact state/event records; '+branchReports.length+' legal counterplay branches');
}catch(e){write('replay-failure.json',{records,transitions,completedEpisodes:outcomes.length,currentEpisode:current?.meta.id,currentStep:current?.steps,error:String(e),stack:(e as Error).stack});throw e;}
