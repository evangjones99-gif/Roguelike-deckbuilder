import fs from 'node:fs';
import path from 'node:path';
import {execFileSync,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const base='/workspace/scratch/release-bundle-independent-v07';
export const version='9.9.9-independent';
export const productionBranch='codex/lanternbound-production';
export const hash=data=>createHash('sha256').update(data).digest('hex');
export function git(root,args,options={}){return execFileSync('git',args,{cwd:root,encoding:'utf8',...options}).trim();}
export function write(root,name,data){const p=path.join(root,name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,data);}
export function setup(name,{stageFailure='',branch=productionBranch}={}){
 const root=path.join(base,'fixtures',name);fs.mkdirSync(root,{recursive:true});
 git(root,['init','-q','-b',branch]);git(root,['config','user.email','independent-review@example.invalid']);git(root,['config','user.name','Independent preservation reviewer']);
 write(root,'.gitignore','dist/\nreleases/\nbuild-desktop/\n.release-lock/\n.gate-runs.jsonl\nreviews/pair.json\nnode_modules/\n');
 write(root,'package.json',JSON.stringify({name:'independent-source-archive-fixture',version,scripts:{test:'node fixture-gate.cjs test',build:'node fixture-gate.cjs build'}}));
 write(root,'fixture-gate.cjs',`const fs=require('fs');const stage=process.argv[2];fs.appendFileSync('.gate-runs.jsonl',JSON.stringify(stage)+'\\n');if(stage===${JSON.stringify(stageFailure)})process.exit(17);if(stage==='build'){fs.mkdirSync('dist',{recursive:true});fs.writeFileSync('dist/index.html','Independent archive fixture, not a game');fs.writeFileSync('dist/build-provenance.json',JSON.stringify({sourceDigest:'synthetic-source-digest'}));}`);
 write(root,'reviews/canonical.json','{"kind":"independent-synthetic-preservation-fixture"}\n');
 write(root,'source/binary.bin',Buffer.from([0,255,1,13,10,127,128]));
 write(root,'source/quirky 雪\tline\nname.txt','Opaque filename fixture\n');
 write(root,'source/old-crlf.txt','Protected working CRLF\r\n');
 write(root,'.gitattributes','source/old-crlf.txt text eol=lf\n');
 git(root,['add','--all']);git(root,['commit','-qm','Independent fixture source']);
 return root;
}
export function invoke(root,producer,args=[version],env={}){
 const dest=path.join(root,'releases',version);
 const processResult=spawnSync(process.execPath,[producer,...args],{cwd:root,env:{...process.env,...env},encoding:'utf8',timeout:60000});
 return {status:processResult.status,signal:processResult.signal,error:processResult.error?String(processResult.error):null,stdout:processResult.stdout,stderr:processResult.stderr,destExists:fs.existsSync(dest),destFiles:fs.existsSync(dest)?fs.readdirSync(dest):[],lockExists:fs.existsSync(root+'/.release-lock'),gateRuns:fs.existsSync(root+'/.gate-runs.jsonl')?fs.readFileSync(root+'/.gate-runs.jsonl','utf8').trim().split('\n').filter(Boolean).map(l=>JSON.parse(l)):[]};
}
export function snapshot(root){
 const result={};function walk(directory){for(const entry of fs.readdirSync(directory,{withFileTypes:true})){const p=path.join(directory,entry.name);if(entry.isDirectory())walk(p);else if(entry.isFile())result[path.relative(root,p)]=hash(fs.readFileSync(p));else if(entry.isSymbolicLink())result[path.relative(root,p)]='symlink:'+fs.readlinkSync(p);}}walk(root);return result;
}
