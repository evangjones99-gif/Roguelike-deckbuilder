import fs from 'node:fs';import assert from 'node:assert/strict';import path from 'node:path';
import{base,version,productionBranch,setup,invoke,git,write,hash,snapshot}from'./fixture-utils.mjs';
import{verifyBundle}from'./frozen-r2-complete/source-bundle.mjs';
const producer=base+'/frozen-r2-complete/release-proposed.mjs',results=[];
function save(name,result,pass,detail={}){results.push({name,...result,pass,...detail});fs.writeFileSync(base+'/r2-gate-results-progress.json',JSON.stringify({scope:'Fresh affected exact R2 CLI/helper cases in independent synthetic Git/npm fixtures; no project release/build/native launch',cases:results},null,2)+'\n');}
const r=setup('r2-helper');const first=git(r,['rev-parse','HEAD']);write(r,'source/current.txt','Independent R2 current source');git(r,['add','source/current.txt']);git(r,['commit','-qm','Current source']);const current=git(r,['rev-parse','HEAD']);
const input=r+'/inputs';fs.mkdirSync(input);
git(r,['bundle','create','--version=2',input+'/good.bundle','HEAD','refs/heads/'+productionBranch]);
git(r,['bundle','create','--version=3',input+'/v3.bundle','HEAD','refs/heads/'+productionBranch]);
git(r,['bundle','create','--version=2',input+'/incremental.bundle','HEAD','refs/heads/'+productionBranch,'^'+first]);
git(r,['checkout','-qb','hidden-unique']);write(r,'source/rejected-only.txt','Must not leak hidden reachable objects');git(r,['add','source/rejected-only.txt']);git(r,['commit','-qm','Unpublished rejected source']);const hidden=git(r,['rev-parse','HEAD']);git(r,['tag','-a','excluded-annotated-tag','-m','Excluded annotation']);git(r,['checkout','-q',productionBranch]);
git(r,['bundle','create','--version=2',input+'/extra-ref.bundle','HEAD','refs/heads/'+productionBranch,'hidden-unique']);
const extra=fs.readFileSync(input+'/extra-ref.bundle'),headerEnd=extra.indexOf(Buffer.from('\n\n'));assert.ok(headerEnd>0);
const originalHeader=extra.subarray(0,headerEnd).toString(),fixedHeader=originalHeader.split('\n').filter(l=>!l.endsWith(' refs/heads/hidden-unique')).join('\n');assert.notEqual(fixedHeader,originalHeader);
fs.writeFileSync(input+'/hidden-object.bundle',Buffer.concat([Buffer.from(fixedHeader+'\n\n'),extra.subarray(headerEnd+2)]));
const good=fs.readFileSync(input+'/good.bundle');fs.writeFileSync(input+'/truncated.bundle',good.subarray(0,good.length-24));fs.writeFileSync(input+'/short.bundle',good.subarray(0,7));fs.writeFileSync(input+'/malformed.bundle','Invalid bundle');
const corrupt=Buffer.from(good);corrupt[corrupt.length-28]^=1;fs.writeFileSync(input+'/bad-pack.bundle',corrupt);
const highbit=Buffer.from(good);highbit[2]=0xf6;fs.writeFileSync(input+'/highbit-header.bundle',highbit);
const wrongHead=Buffer.from(good.toString('binary').replace(current+' HEAD',hidden+' HEAD'),'binary');fs.writeFileSync(input+'/wrong-head-ref.bundle',wrongHead);
const beforeRefs=git(r,['show-ref']);
for(const [name,file,expected,reject]of[['good-v2','good.bundle',current,false],['v3','v3.bundle',current,true],['incremental','incremental.bundle',current,true],['extra-ref','extra-ref.bundle',current,true],['hidden-object','hidden-object.bundle',current,true],['truncated','truncated.bundle',current,true],['short','short.bundle',current,true],['malformed','malformed.bundle',current,true],['bad-pack','bad-pack.bundle',current,true],['highbit','highbit-header.bundle',current,true],['wrong-head-ref','wrong-head-ref.bundle',current,true],['wrong-source','good.bundle',first,true]]){
 const temporary=r+'/restore-'+name;fs.mkdirSync(temporary);let proof,error=null;try{proof=await verifyBundle(r,expected,input+'/'+file,temporary)}catch(e){error=String(e)}
 save('helper-'+name,{status:error?'rejected':'accepted',error},reject?!!error:!!proof,{proof,sourceRefsUnchanged:git(r,['show-ref'])===beforeRefs});
}
// An independently executed standard Git consumer restore, distinct from the candidate helper.
const standard=base+'/standard-r2-restored.git';git(r,['clone','--bare','--branch',productionBranch,input+'/good.bundle',standard]);git(standard,['fsck','--full','--strict']);save('standard-consumer-restore',{status:'accepted'},git(standard,['rev-parse','HEAD'])===current&&git(standard,['rev-parse','HEAD^{tree}'])===git(r,['rev-parse',current+'^{tree}']),{tree:git(standard,['rev-parse','HEAD^{tree}'])});
for(const [name,args]of[['r2-default-clean',[version]],['r2-bundle-clean',[version,'--source-format=bundle']]]){
 const root=setup(name);const refs=git(root,['show-ref']);const raw=hash(fs.readFileSync(root+'/source/old-crlf.txt'));const out=invoke(root,producer,args);const dest=root+'/releases/'+version;const manifest=out.status===0?JSON.parse(fs.readFileSync(dest+'/manifest.json')):null;
 save(name,out,out.status===0&&out.gateRuns.join(',')==='test,build'&&!out.lockExists&&git(root,['show-ref'])===refs&&hash(fs.readFileSync(root+'/source/old-crlf.txt'))===raw,{manifest});
}
const root=setup('r2-mutated-official-bundle');
write(root,'fakebin/git',`#!/bin/sh\nif [ "$1" = bundle ] && [ "$2" = create ]; then\n /usr/bin/git "$@" || exit $?\n python3 - "$4" <<'PY'\nimport sys,pathlib\np=pathlib.Path(sys.argv[1]);d=p.read_bytes();assert d[:16]==b'# v2 git bundle\\n';p.write_bytes(b'# v3 git bundle\\n'+d[16:])\nPY\nelse\n exec /usr/bin/git "$@"\nfi\n`);
fs.chmodSync(root+'/fakebin/git',0o755);git(root,['add','fakebin/git']);git(root,['commit','-qm','Independent bundle-corrupting host wrapper fixture']);
let out=invoke(root,producer,[version,'--source-format=bundle'],{PATH:root+'/fakebin:'+process.env.PATH});const dest=root+'/releases/'+version;
save('actual-cli-mutated-bundle-retained-incomplete',out,out.status!==0&&out.destFiles.includes('INCOMPLETE.txt')&&out.destFiles.some(n=>n.endsWith('-source.bundle'))&&!out.destFiles.includes('manifest.json')&&!out.lockExists&&fs.readFileSync(dest+'/INCOMPLETE.txt','utf8').includes('Only exact Git bundle version 2'),{incomplete:fs.readFileSync(dest+'/INCOMPLETE.txt','utf8')});
const partial=snapshot(dest);out=invoke(root,producer,[version,'--source-format=bundle']);save('mutated-incomplete-retry-refused-unchanged',out,out.status!==0&&!out.lockExists&&JSON.stringify(snapshot(dest))===JSON.stringify(partial));
fs.writeFileSync(base+'/r2-gate-results.json',JSON.stringify({scope:'Affected R2 format/hidden-object/standard restore/actual CLI preservation gates, independent synthetic Git/npm fixtures; not game/native playtests',cases:results},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({cases:results.length,passes:results.filter(c=>c.pass).length,failures:results.filter(c=>!c.pass).map(c=>({name:c.name,error:c.error,stderr:c.stderr}))}));
