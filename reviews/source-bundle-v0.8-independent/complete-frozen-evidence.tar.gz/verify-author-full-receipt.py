import pathlib,json,subprocess,hashlib
base=pathlib.Path('/workspace/scratch/release-bundle-independent-v07')
root=pathlib.Path('/workspace/Roguelike-deckbuilder')
source=pathlib.Path('/workspace/scratch/release-bundle-v07/preflight-verified.json')
data=source.read_bytes();proof=json.loads(data);commit=proof['sourceCommit']
assert commit=='b065d1044c9486b616f2eb2e95021de18c349ab7'
assert proof['archiveBytes']==1526523777
assert proof['archiveSHA256']=='04c31e64dab1b8503746b452717f6cea7a806135ec07c0fa4bcd03d65ab7561c'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse',commit+'^{tree}').decode().strip()==proof['identity']['tree']
actual={}
for row in git('ls-tree','-r','-z',commit).split(b'\0'):
 if not row:continue
 info,name=row.split(b'\t',1);mode,kind,oid=info.split(b' ');assert kind==b'blob'
 actual[name.decode()]=(mode.decode(),oid.decode())
assert len(actual)==len(proof['identity']['files'])==5904
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
count=0;total=0
try:
 for entry in proof['identity']['files']:
  assert actual[entry['path']]==(entry['mode'],entry['gitBlob'])
  oid=entry['gitBlob'];proc.stdin.write((oid+'\n').encode());proc.stdin.flush();parts=proc.stdout.readline().split()
  assert parts[0].decode()==oid and parts[1]==b'blob'
  size=int(parts[2]);assert size==entry['bytes'];remain=size;h=hashlib.sha256();blob=hashlib.sha1(('blob '+str(size)+'\0').encode())
  while remain:
   chunk=proc.stdout.read(min(remain,1024*1024));assert chunk;remain-=len(chunk);h.update(chunk);blob.update(chunk)
  assert proc.stdout.read(1)==b'\n';assert h.hexdigest()==entry['sha256'];assert blob.hexdigest()==oid
  count+=1;total+=size
finally:
 proc.stdin.close();proc.wait(timeout=20);assert proc.returncode==0
closure=git('rev-list','--objects','--no-object-names',commit).splitlines();assert len(closure)==proof['reachableObjectCount']==3586
result={'scope':'Independent read-only verification of author-owned successful full-size fresh-bare receipt against every canonical b065 source blob; original author restore is not reviewer execution. Reviewer own import ENOSPC remains separate failure.','authorReceiptPath':str(source),'authorReceiptSHA256':hashlib.sha256(data).hexdigest(),'sourceCommit':commit,'tree':proof['identity']['tree'],'everySourceBlobSHA256AndGitOIDRecomputed':True,'sourceFiles':count,'sourceBlobBytesIncludingRepeatedPaths':total,'reachableObjects':len(closure),'canonicalReviewFiles':sum(n.startswith('reviews/') for n in actual),'authorFormat':proof['format'],'authorFsckOutput':proof['fsckOutput'],'authorInputBundleSHA256':proof['archiveSHA256'],'rawWorkingCIByteIdentityNotAsserted':True}
(base/'author-full-receipt-independent-source-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
