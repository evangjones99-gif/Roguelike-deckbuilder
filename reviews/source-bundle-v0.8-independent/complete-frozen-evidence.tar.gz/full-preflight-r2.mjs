import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import assert from 'node:assert/strict';
import{verifyBundle}from'./frozen-r2-complete/source-bundle.mjs';
import{sha256File}from'./frozen-r2-complete/sha256-file.mjs';
const base='/workspace/scratch/release-bundle-independent-v07',root='/workspace/Roguelike-deckbuilder';
const bundle='/tmp/hollowpact-v07-bundle-preflight-y4st1n0p/source.bundle';
const commit='b065d1044c9486b616f2eb2e95021de18c349ab7';
const expected='04c31e64dab1b8503746b452717f6cea7a806135ec07c0fa4bcd03d65ab7561c';
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'hollowpact-bundle-independent-r2-'));
const started=Date.now();let success=false;
try{
 assert.equal(fs.statSync(bundle).size,1526523777);assert.equal(await sha256File(bundle),expected);
 const proof=await verifyBundle(root,commit,bundle,temporary);
 assert.equal(proof.format,'git-bundle-v2');assert.equal(proof.identity.files.length,5904);assert.equal(proof.reachableObjectCount,3586);
 assert.equal(proof.identity.tree,'aaed2c69d8543f020a863afc3b969cee3148d339');
 const hunter=proof.identity.files.find(f=>f.path==='public/art/hunter-marek-v07-r3.png');assert.equal(hunter.sha256,'4492577d3bacc868e9b66da0abf25915bdeaf68bc8f5c31ae8a1d8db485f3c53');assert.equal(hunter.bytes,2128117);
 const sourceCount=proof.identity.files.filter(f=>f.path.startsWith('reviews/')).length;assert.equal(sourceCount,3132);
 assert.equal(await sha256File(bundle),expected);
 const result={scope:'Reviewer independent fresh bare execution of exact frozen R2 verification helper on author original actual b065 full-sized prototype bundle; NOT current official0.7source/new game/native execution',bundlePath:bundle,bundleBytes:fs.statSync(bundle).size,bundleSHA256:expected,temporaryDuplicateBarePath:temporary,temporaryRemovedAfterSuccessfulReceipt:true,elapsedSeconds:(Date.now()-started)/1000,...proof};
 fs.writeFileSync(base+'/full-preflight-r2-independent.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});success=true;
 console.log(JSON.stringify({status:'passed',scope:result.scope,bundleBytes:result.bundleBytes,bundleSHA256:expected,files:proof.identity.files.length,canonicalReviews:sourceCount,objects:proof.reachableObjectCount,elapsedSeconds:result.elapsedSeconds}));
}catch(error){fs.writeFileSync(base+'/full-preflight-r2-failure.json',JSON.stringify({error:String(error),temporaryRetainedPath:temporary,scope:'Failed independent full-size prototype verification; all temporary failure objects retained'},null,2)+'\n',{flag:'wx'});throw error}
finally{if(success)fs.rmSync(temporary,{recursive:true,force:false});}
