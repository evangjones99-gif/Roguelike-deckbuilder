"""Read only the fixed original ZIP EXE into the bounded parser pipe."""
from pathlib import Path
import zipfile,sys,hashlib
p=Path('/workspace/retained-native-experiments/windows-run-36806506465/hollowpact-0.8.0-windows-native-x64.zip')
expectedBytes=245867008;expectedSHA='1a875ee6c2f8d5697b86485c7fd1e5146de8a8a434f38c59cd0f54474c630798'
with zipfile.ZipFile(p) as z:
 i=z.getinfo('Hollowpact.exe');assert i.file_size==expectedBytes and not i.is_dir()
 h=hashlib.sha256();n=0
 with z.open(i) as f:
  while b:=f.read(1048576):n+=len(b);assert n<=expectedBytes;h.update(b);sys.stdout.buffer.write(b)
 assert n==expectedBytes and h.hexdigest()==expectedSHA
 sys.stdout.buffer.flush()
