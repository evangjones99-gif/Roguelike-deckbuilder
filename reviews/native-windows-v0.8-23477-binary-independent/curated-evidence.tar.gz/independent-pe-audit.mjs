import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import * as ResEdit from '/workspace/Roguelike-deckbuilder/node_modules/resedit/dist/index.mjs';
const root='/workspace/scratch/windows-native-original-independent-v08-run-36806506465';
const previous='/workspace/scratch/windows-native-independent-v08-run-36806506465/raw-small-members/reviews/windows-native/0.8.0/run-36806506465-1';
const smoke=JSON.parse(fs.readFileSync(previous+'/smoke.json'));
const nativePackage=JSON.parse(fs.readFileSync(previous+'/native-package.json','utf8').replace(/^\uFEFF/,''));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const chunks=[];let length=0;
for await(const chunk of process.stdin){length+=chunk.length;assert(length<=245867008);chunks.push(chunk);}
assert.equal(length,245867008);const raw=Buffer.concat(chunks);chunks.length=0;
assert.equal(hash(raw),smoke.executableSHA256);assert.equal(hash(raw),nativePackage.executableSHA256);
assert.equal(raw.readUInt16LE(0),0x5a4d);const peOffset=raw.readUInt32LE(0x3c);
assert.equal(raw.readUInt32LE(peOffset),0x4550);assert.equal(raw.readUInt16LE(peOffset+4),0x8664);
const optional=peOffset+24;assert.equal(raw.readUInt16LE(optional),0x20b);
const certOffset=raw.readUInt32LE(optional+112+4*8),certSize=raw.readUInt32LE(optional+112+4*8+4);
assert.equal(certOffset,0);assert.equal(certSize,0);assert.equal(nativePackage.signatureStatus,'NotSigned');
const exe=ResEdit.NtExecutable.from(raw,{ignoreCert:true});
const entries=ResEdit.NtExecutableResource.from(exe).entries;
const resources={
 icons:entries.filter(e=>e.type===3).map(e=>({id:e.id,language:e.lang,sha256:hash(Buffer.from(e.bin))})),
 iconGroups:ResEdit.Resource.IconGroupEntry.fromEntries(entries).map(g=>({id:g.id,language:g.lang,sizes:g.icons.map(i=>[i.width,i.height])})),
 versions:ResEdit.Resource.VersionInfo.fromEntries(entries).map(i=>({fixed:i.fixedInfo,strings:i.getAllLanguagesForStringValues().map(l=>i.getStringValues(l))})),
};
assert.deepEqual(resources,smoke.resources);assert.equal(resources.icons.length,7);
assert(resources.versions.some(v=>v.strings.some(s=>s.ProductName==='Hollowpact'&&s.FileVersion==='0.8.0'&&s.ProductVersion==='0.8.0.0')));
const pngSignature=Buffer.from([137,80,78,71,13,10,26,10]);let savedPNG=null;
for(const entry of entries.filter(e=>e.type===3)){
 const b=Buffer.from(entry.bin);if(b.subarray(0,8).equals(pngSignature)&&b.readUInt32BE(16)===256){
  savedPNG='ACTUAL-PE-ICON-256.png';fs.writeFileSync(root+'/'+savedPNG,b,{flag:'wx'});break;
 }
}
const result={status:'passed',originalEXEBytes:length,originalEXE_SHA256:hash(raw),PECOFFMachine:'0x8664-x64',optionalHeaderMagic:'0x20b-PE32+',
 actualCertificateDirectoryOffset:certOffset,actualCertificateDirectorySize:certSize,
 correspondenceToActualNativeNotSigned:true,newWindowsAuthenticodeQueryPerformed:false,
 allActualResourceFieldsEqualNativeCIReceipt:true,resources,actualPEIconPNG:savedPNG,
 scope:'Read-only bounded original EXE memory parse fed by CRC/hash-checked fixed ZIP member. No EXE disk extraction, writes/signing/execution/installation. Absence of PE certificate directory corresponds to real CI NotSigned; no local Windows signing query is claimed.'};
fs.writeFileSync(root+'/PE-AUDIT.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:result.status,bytes:length,machine:result.PECOFFMachine,icons:resources.icons.length,certificateBytes:certSize,actualPEIconPNG:savedPNG}));
