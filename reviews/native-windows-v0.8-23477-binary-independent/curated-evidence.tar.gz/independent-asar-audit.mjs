import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {getRawHeader,extractFile} from '/workspace/Roguelike-deckbuilder/node_modules/@electron/asar/lib/asar.js';
const root='/workspace/scratch/windows-native-original-independent-v08-run-36806506465';
const repo='/workspace/Roguelike-deckbuilder';
const archive='/tmp/hollowpact-v08-windows-asar-only-independent-run-36806506465/resources/app.asar';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(hash(fs.readFileSync(archive)),'c383c4437ac5467146174c6ea039b2a8b28af43d609701379e8cf695f59d530c');
const raw=getRawHeader(archive),header=raw.header,leaves=[],directories=[];
function walk(node,prefix=''){
  assert(!('link' in node));assert(node.unpacked!==true);
  if(node.files){directories.push(prefix||'.');for(const [name,value] of Object.entries(node.files)){
    assert(name&&!/[\\/:]/.test(name)&&name!=='.'&&name!=='..');walk(value,prefix?prefix+'/'+name:name);
  }}else{assert(Number.isSafeInteger(node.size)&&node.size>=0);assert(/^\d+$/.test(node.offset));leaves.push({path:prefix,node});}
}
walk(header);assert.equal(leaves.length,59);assert.equal(new Set(leaves.map(l=>l.path)).size,59);
const localFiles=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?localFiles(path.join(dir,e.name)):[path.join(dir,e.name)]);
const dist=localFiles(repo+'/dist').map(p=>path.relative(repo,p).replaceAll('\\','/')).sort();assert.equal(dist.length,55);
const desktop=['desktop/audio-lifecycle.cjs','desktop/icon.png','desktop/main.cjs'];
const expected=[...dist,...desktop,'package.json'].sort();assert.deepEqual(leaves.map(l=>l.path).sort(),expected);
const ledger=[];
for(const leaf of leaves){
  const b=extractFile(archive,leaf.path,false);assert.equal(b.length,leaf.node.size);const digest=hash(b);
  if(leaf.node.integrity){assert.equal(leaf.node.integrity.algorithm,'SHA256');assert.equal(leaf.node.integrity.hash,digest);}
  if(leaf.path!=='package.json')assert(Buffer.from(b).equals(fs.readFileSync(path.join(repo,leaf.path))),leaf.path);
  ledger.push({path:leaf.path,bytes:b.length,sha256:digest,headerIntegrityMatches:!!leaf.node.integrity,
    exactCurrentRawPayload:leaf.path!=='package.json'});
}
const normalized=JSON.parse(extractFile(archive,'package.json').toString()),expectedPackage=JSON.parse(fs.readFileSync(repo+'/package.json','utf8'));
for(const name of ['scripts','keywords','devDependencies','build'])delete expectedPackage[name];
assert.equal(Object.keys(normalized).length,11);assert.deepEqual(normalized,expectedPackage);
const provenance=JSON.parse(extractFile(archive,'dist/build-provenance.json').toString());
assert.equal(provenance.sourceDigest,'23477f68c99d6d60b0b3f82b286a8d33bb6da6f2ca92c103fbecf5663634959f');assert.equal(provenance.version,'0.8.0');
assert.equal(Object.keys(provenance.hashes).length,76);assert.equal(hash(JSON.stringify(provenance.hashes)),provenance.sourceDigest);
for(const [file,digest] of Object.entries(provenance.hashes))assert.equal(hash(fs.readFileSync(path.join(repo,file))),digest,file);
assert.equal(hash(fs.readFileSync('/tmp/hollowpact-linux-v08-width-r1/linux-unpacked/resources/app.asar')),hash(fs.readFileSync(archive)));
const spans=leaves.map(l=>({start:Number(l.node.offset),size:l.node.size,path:l.path})).sort((a,b)=>a.start-b.start);let end=0;
for(const span of spans){assert.equal(span.start,end);end+=span.size;}
assert.equal(8+raw.headerSize+end,fs.statSync(archive).size);
const result={status:'passed',runtimeSourceDigest:provenance.sourceDigest,ASAR_SHA256:hash(fs.readFileSync(archive)),
  exactRegularLeaves:59,exactRawCurrentPayloads:58,exactDistPayloads:55,exactDesktopPayloads:3,currentRuntimeInputs:76,
  noExtraLeavesLinksOrUnpackedFiles:true,normalizedPackageSemanticFields:11,normalizedRootFieldsRemoved:['scripts','keywords','devDependencies','build'],
  rawNormalizedPackageSHA256:ledger.find(l=>l.path==='package.json').sha256,rawRootManifestByteEqualityClaimed:false,
  completeContiguousPayloadSpanMatchesASARBytes:true,matchingRetainedLinuxASARBytes:true,
  proxyDirectory:path.dirname(path.dirname(archive)),proxyIsCompleteWindowsPackage:false,directories,leaves:ledger,
  scope:'Actual original nativeWindowsASAR extracted alone from hash/CRC-verified testedZIP. Actual59-leaf/58-raw-payload and76-current-input verification; separate normalized manifest semantics. No package launch/install.'};
fs.writeFileSync(root+'/ASAR-AUDIT.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});fs.writeFileSync(root+'/ASAR-RAW-HEADER.json',JSON.stringify(raw,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:result.status,leaves:59,payloads:58,inputs:76,matchingLinux:true}));
