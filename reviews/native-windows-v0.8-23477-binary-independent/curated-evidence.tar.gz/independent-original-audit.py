from pathlib import Path
import zipfile,hashlib,json,stat,os,datetime
r=Path(__file__).parent;retained=Path('/workspace/retained-native-experiments/windows-run-36806506465')
earlier=Path('/workspace/scratch/windows-native-independent-v08-run-36806506465');repo=Path('/workspace/Roguelike-deckbuilder')
read=lambda p:json.loads(p.read_bytes().decode('utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
recovery=read(retained/'RECOVERY.json');manifest=read(retained/'manifest.original.json')
native=earlier/'raw-small-members/reviews/windows-native/0.8.0/run-36806506465-1';smoke=read(native/'smoke.json')
api=read(earlier/'artifacts-final.json')['artifacts'];transfer=read(earlier/'raw-small-members/build-desktop/windows-transfer/manifest.json')
assert manifest==transfer and recovery['runtime']==transfer['sourceDigest']
assert recovery['bytes']==manifest['bytes']==191814688 and recovery['sha256']==manifest['sha256']=='1ce6c74baea02686183e833c28738e04d19f80d5826218a0d732eff304dce563'
assert len(recovery['wrappers'])==len(manifest['parts'])==8
wholeFromParts=hashlib.sha256();partBytes=0;wrappers=[]
for i,(wrapper,part) in enumerate(zip(recovery['wrappers'],manifest['parts']),1):
 p=Path(wrapper['path']);assert p.is_file() and not p.is_symlink();assert part['index']==i and wrapper['member']==part
 artifact=next(a for a in api if a['name']==f'hollowpact-0.8.0-windows-part-{i:02}-36806506465-1')
 assert p.stat().st_size==wrapper['bytes']==artifact['size_in_bytes'] and sha(p)==wrapper['sha256']==artifact['digest'].split(':')[1]
 with zipfile.ZipFile(p) as z:
  infos=z.infolist();assert len(infos)==1 and not infos[0].is_dir() and infos[0].filename==part['filename']
  assert not infos[0].flag_bits&1 and infos[0].file_size==part['bytes'];h=hashlib.sha256();n=0
  with z.open(infos[0]) as f:
   while b:=f.read(1048576):h.update(b);wholeFromParts.update(b);n+=len(b);partBytes+=len(b)
  assert n==part['bytes'] and h.hexdigest()==part['sha256']
 wrappers.append({'index':i,'originalPath':str(p),'wrapperBytes':p.stat().st_size,'wrapperSHA256':wrapper['sha256'],'actualAPIArtifactID':artifact['id'],'partBytes':n,'partSHA256':h.hexdigest(),'actualCRCReadVerified':True})
assert partBytes==manifest['bytes'] and wholeFromParts.hexdigest()==manifest['sha256']
original=retained/manifest['archive'];assert str(original)==recovery['archive'] and not original.is_symlink()
assert original.stat().st_size==manifest['bytes'] and sha(original)==manifest['sha256']
proxy=Path('/tmp/hollowpact-v08-windows-asar-only-independent-run-36806506465');proxy.mkdir(exist_ok=False)
(proxy/'resources').mkdir();payloads=[];total=0
with zipfile.ZipFile(original) as z:
 infos=z.infolist();assert len(infos)==72 and len(set(i.filename for i in infos))==72
 assert set(i.filename for i in infos)==set(smoke['packageFiles'])
 assert len({i.filename.casefold() for i in infos})==72
 for i in infos:
  assert not i.is_dir() and not i.flag_bits&1 and i.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)
  assert not i.filename.startswith('/') and '\\' not in i.filename and ':' not in i.filename and all(p not in ('','.','..') for p in i.filename.split('/'))
  assert stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG) and 0<i.file_size<=256*1024*1024
  h=hashlib.sha256();n=0;out=(proxy/'resources/app.asar').open('xb') if i.filename=='resources/app.asar' else None
  try:
   with z.open(i) as f:
    while b:=f.read(1048576):h.update(b);n+=len(b);total+=len(b);out.write(b) if out else None
  finally:
   if out:out.flush();os.fsync(out.fileno());out.close()
  assert n==i.file_size and h.hexdigest()==smoke['packageFiles'][i.filename],i.filename
  payloads.append({'path':i.filename,'bytes':n,'sha256':h.hexdigest(),'actualCRCReadVerified':True,'externalAttributes':i.external_attr})
assert total==416411060
assert sha(proxy/'resources/app.asar')==smoke['asarSHA256']=='c383c4437ac5467146174c6ea039b2a8b28af43d609701379e8cf695f59d530c'
provenance=read(earlier/'raw-small-members/dist/build-provenance.json');assert len(provenance['hashes'])==76
for name,expected in provenance['hashes'].items():assert sha(repo/name)==expected,name
assert hashlib.sha256(json.dumps(provenance['hashes'],separators=(',',':')).encode()).hexdigest()==manifest['sourceDigest']
ledger={'schema':1,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed-original-eight-wrapper-part-whole-and72-payload-gate','archive':str(original),'originalArchiveBytes':original.stat().st_size,'originalArchiveSHA256':sha(original),'runtimeSourceDigest':manifest['sourceDigest'],'current76InputBytesExact':True,'sourceMergeCheckout':manifest['commit'],'wrapperAudits':wrappers,'partsConcatenationStreamHashVerifiedWithoutNewWholeCopy':True,'packagePayloads':payloads,'packagePayloadBytes':total,'packagePayloadCount':72,'ASARProxyDirectory':str(proxy),'ASARProxyOnlyFile':'resources/app.asar','ASARProxyFileBytes':(proxy/'resources/app.asar').stat().st_size,'ASARProxySHA256':sha(proxy/'resources/app.asar'),'proxyIsCompleteWindowsPackage':False,'scope':'No original archive/wrapper modified; streamed every original payload, extracted only31MiBASAR. Proxy has no executable and is for accepted bundle-mode release producer version/provenance validation only, never default Windows repacking/launch/install.'}
with (r/'ORIGINAL-BINARY-AUDIT.json').open('x') as f:json.dump(ledger,f,indent=2);f.write('\n')
with (r/'ASAR-PROXY-SCOPE.json').open('x') as f:json.dump({k:v for k,v in ledger.items() if k.startswith('ASARProxy') or k in ['proxyIsCompleteWindowsPackage','scope']},f,indent=2);f.write('\n')
print(json.dumps({k:ledger[k] for k in ['status','packagePayloadCount','originalArchiveBytes','ASARProxyDirectory','proxyIsCompleteWindowsPackage']}))
