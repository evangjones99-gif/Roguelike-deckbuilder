import fs from 'node:fs';
import crypto from 'node:crypto';
import { build, stop } from '/workspace/Roguelike-deckbuilder/node_modules/esbuild/lib/main.js';
const stage='/dev/shm/hollowpact-owner-tactile-pc-root-r4';
const destination='/workspace/scratch/owner-tactile-pc-oracle-r4';
fs.mkdirSync(destination,{recursive:false});
try {
 const result=await build({entryPoints:[`${stage}/src/engine.ts`],bundle:true,platform:'node',format:'esm',target:'node24',outfile:`${destination}/engine.mjs`,metafile:true});
 const rows=Object.keys(result.metafile.inputs).map(path=>({path,bytes:fs.statSync(path).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex')}));
 const output=fs.readFileSync(`${destination}/engine.mjs`);
 fs.writeFileSync(`${destination}/MANIFEST.json`,JSON.stringify({scope:'Private pure reducer oracle for trusted PC browser diagnostics; prebundles exact engine inputs to avoid loading a TypeScript loader in the browser phase. No game-source/runtime change or private-state injection. Strict playable build separately recorded.',inputs:rows,output:{path:'engine.mjs',bytes:output.length,sha256:crypto.createHash('sha256').update(output).digest('hex')},metafile:result.metafile},null,2)+'\n');
 console.log(JSON.stringify({destination,inputs:rows.length,bytes:output.length}));
} finally {stop();}
