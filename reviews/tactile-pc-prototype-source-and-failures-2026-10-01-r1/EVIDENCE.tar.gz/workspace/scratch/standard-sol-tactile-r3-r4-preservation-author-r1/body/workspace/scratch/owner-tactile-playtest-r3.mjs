import fs from 'node:fs';
import { chromium } from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import { createGame, applyActionWithEvents, legalActions } from '/dev/shm/hollowpact-owner-tactile-root-r3/src/engine.ts';

const output=`/tmp/hollowpact-owner-tactile-root-playtest-r3-${Date.now()}`;
fs.mkdirSync(output,{recursive:false});
const admission=JSON.parse(fs.readFileSync(`${process.argv[2]}/ADMISSION.json`,'utf8'));
const maximum=Number(fs.readFileSync('/sys/fs/cgroup/memory.max')),current=Number(fs.readFileSync('/sys/fs/cgroup/memory.current'));
const spent=Math.max(0,current-admission.initial.current),remaining=Math.max(0,admission.work-spent);
if(!admission.admitted||admission.stage!=='/dev/shm/hollowpact-owner-tactile-root-r3'||admission.work!==640*1024**2||admission.reserve!==512*1024**2
 ||maximum!==admission.initial.maximum||spent>admission.work||maximum-current<admission.reserve+remaining)throw Error('Guarded phase remaining640MiB total work and512MiB reserve refused');
// The unchanged live external guard counts Node/tsx imports and Chromium in
// one640MiB operation. R1 redundantly demanded a second640MiB after imports.
const provenance=JSON.parse(fs.readFileSync('/dev/shm/hollowpact-owner-tactile-root-r3/dist/build-provenance.json','utf8'));
const report={sourceDigest:provenance.sourceDigest,kind:'Root actual trusted browser interaction diagnostics; not human playtesting',resourceAdmission:{initial:admission.initial,work:admission.work,reserve:admission.reserve,preBrowserCurrent:current,spent,remaining,scope:'unchanged live operation budget includes Node imports and browser; cgroup observations not exclusive process attribution'},captures:[],checks:[],errors:[]};
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
let page;
process.once('SIGTERM',()=>{report.interrupted=true;void browser.close().finally(()=>{fs.writeFileSync(`${output}/INTERRUPTED.json`,JSON.stringify(report,null,2));process.exit(143);});});
const save=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('hollowpact.run.v2')));
const equal=(a,b,label)=>{if(JSON.stringify(a)!==JSON.stringify(b))throw Error(label);report.checks.push(label);};
async function point(selector){
 const node=page.locator(selector).first();let box=await node.boundingBox();if(!box)throw Error(`Missing${selector}`);
 for(let attempt=0;attempt<3&&(box.y<24||box.y+Math.min(box.height/2,35)>page.viewportSize().height-24);attempt++){
   await page.mouse.move(12,200);await page.mouse.wheel(0,box.y+Math.min(box.height/2,35)-page.viewportSize().height/2);await page.waitForTimeout(180);box=await node.boundingBox();
 }
 const p={x:box.x+box.width/2,y:box.y+Math.min(box.height/2,35)};
 const owned=await node.evaluate((e,p)=>e.contains(document.elementFromPoint(p.x,p.y)),p);if(!owned)throw Error(`Wrong pointer ownership${selector}`);
 return p;
}
async function beginDrag(selector){
 await page.mouse.move(12,35);await page.waitForTimeout(180);
 const p=await point(selector);await page.mouse.move(p.x,p.y);await page.waitForTimeout(180);
 const settled=await point(selector);await page.mouse.move(settled.x,settled.y);await page.mouse.down();
 await page.mouse.move(settled.x,settled.y-35,{steps:5});await page.waitForTimeout(50);
 if(await page.locator('.tactile-ghost').count()!==1)throw Error('Drag did not create exactly one inert ghost');
 if(!await page.locator('.tactile-ghost').evaluate(e=>e.inert&&getComputedStyle(e).pointerEvents==='none'))throw Error('Ghost intercepts input');
 return settled;
}
async function capture(name){const path=`${output}/${name}.jpg`;await page.screenshot({path,fullPage:true});report.captures.push(path);}
try{
 const context=await browser.newContext({viewport:{width:390,height:900}});page=await context.newPage();page.setDefaultTimeout(7000);page.on('pageerror',e=>report.errors.push(String(e)));
 await page.addInitScript(()=>localStorage.setItem('hollowpact.tutorial.v2','yes'));
 await page.goto('http://127.0.0.1:4781');
 await page.locator('#scene-ui [data-ui="new"]').click();await page.locator('[data-hunt-disclosure="hunt-seed-panel"]').click();await page.locator('#seed').fill('44');await page.locator('#new-game-form [type="submit"]').click();await page.waitForTimeout(750);
 const initial=createGame(44,0);equal(await save(),applyActionWithEvents(initial,{type:'travel',choice:initial.route[0]}).state,'Initial run equals canonical first travel');
 const summon='.hand-cards .summon:not(.unplayable)';
 const before=await save();await beginDrag(summon);await page.mouse.move(25,35,{steps:6});await capture('invalid-destination');await page.mouse.up();await page.waitForTimeout(220);
 equal(await save(),before,'Invalid drop and subsequent physical click preserve exact state');if(await page.locator('.tactile-ghost').count())throw Error('Invalid ghost did not return');
 await beginDrag(summon);await page.keyboard.press('Escape');if(await page.locator('#dialog').evaluate(e=>e.open))throw Error('Drag Escape also opened pause');await page.waitForTimeout(760);await page.mouse.up();await page.waitForTimeout(80);
 equal(await save(),before,'Canceled held drag release after700ms preserves state');if(await page.locator('.tactile-ghost').count())throw Error('Canceled ghost remains');
 const index=Number(await page.locator(summon).first().getAttribute('data-index'));await beginDrag(summon);
 const deploy=page.locator('[data-tactile-drop-zone="deploy"]');await deploy.waitFor({state:'visible'});
 let zone=await deploy.boundingBox();if(!zone||zone.width<80||zone.height<24)throw Error('Published deployment destination missing');
 if(zone.y<0||zone.y+zone.height>900){await page.mouse.wheel(0,zone.y+zone.height/2-450);await page.waitForTimeout(150);zone=await deploy.boundingBox();}
 const drop={x:zone.x+zone.width/2,y:zone.y+zone.height/2};await page.mouse.move(drop.x,drop.y,{steps:12});await page.waitForTimeout(90);await capture('summon-ready');
 if(await page.locator('.tactile-ghost').getAttribute('data-legal')!=='true')throw Error('Summon deployment destination not legal');await page.mouse.up();await page.waitForTimeout(850);
 equal(await save(),applyActionWithEvents(before,{type:'play',index}).state,'Drag summon commits exact occurrence once and saves canonical result');
 if(await page.locator('.tactile-ghost').count())throw Error('Accepted ghost remains');
 const current=await save();const targeted=legalActions(current).find(a=>a.type==='play'&&a.target&&a.target!=='hunter');
 if(targeted){
   const selector=`.hand-cards [data-ui="play-card"][data-index="${targeted.index}"]`;await beginDrag(selector);
   // Native wheel reveals offscreen actors without injected state or forced clicks.
   let b=await page.locator(`[data-unit="${targeted.target}"]`).boundingBox();if(!b)throw Error('Target has no bounds');
   if(b.y<0||b.y+b.height>900){await page.mouse.wheel(0,b.y+b.height/2-450);await page.waitForTimeout(150);b=await page.locator(`[data-unit="${targeted.target}"]`).boundingBox();}
   const p={x:b.x+b.width/2,y:b.y+b.height/2};const uid=await page.evaluate(p=>document.elementFromPoint(p.x,p.y)?.closest('[data-unit]')?.dataset.unit,p);if(uid!==targeted.target)throw Error('Wrong target hit owner');
   await page.mouse.move(p.x,p.y,{steps:10});await page.waitForTimeout(90);await capture('targeted-preview');if(await page.locator('.tactile-ghost').getAttribute('data-legal')!=='true')throw Error('Exact reducer target missing drag legality');await page.mouse.up();await page.waitForTimeout(1000);
   equal(await save(),applyActionWithEvents(current,targeted).state,'Targeted drag commits exact legal UID once');
 }
 const after=await save();await page.reload();await page.locator('#scene-ui [data-ui="resume"]').click();await page.waitForTimeout(700);equal(await save(),after,'Actual reload and Continue retain drag result');
 report.geometry=await page.evaluate(()=>({documentWidth:document.documentElement.scrollWidth,viewport:innerWidth,ghosts:document.querySelectorAll('.tactile-ghost').length}));if(report.geometry.documentWidth!==390)throw Error('Horizontal document overflow');if(report.errors.length)throw Error('Browser page errors');
 await capture('resumed-field');await context.close();
}catch(error){report.failure=String(error);if(page&&!page.isClosed())await capture('failure').catch(()=>{});throw error;}
finally{await browser.close();fs.writeFileSync(`${output}/RESULT.json`,JSON.stringify(report,null,2));}
console.log(JSON.stringify({output,sourceDigest:report.sourceDigest,checks:report.checks,captures:report.captures}));
