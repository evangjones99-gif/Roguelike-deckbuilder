# External Root-host R4 focus-order repair — SOURCE ONLY

Only proposed main.ts changes are in this NEW immutable external packet. Frozen R3 stage/source/build, external R3 source freeze and its independent rejection6709601f remain unchanged. Root currently owns the actual R3 browser probe; this author launched no Node/typecheck/browser/tests. Root must fork a new stage and independently gate/build/retest before selecting the repair. Engine/audio/arena/tactile module/CSS are unchanged.

## Defect and repair

R3 set restoringDialogFocus only inside restoreDialogOrigin, called AFTER dialog.close(). Native dialog.close can focus its remembered source card while dialog.open is already false. Ordinary showConsequenceFor then erases the exact hovered target comparison before the later guarded restore. The independent source counterexample is controller/card Inspect opened while a different target comparison remains hovered. Mouse Inspect usually restored a semantic Inspect button and happened to avoid this branch; that was insufficient coverage.

R4 places the guard around the entire closeDialog transaction, including native close and subsequent explicit focus restoration. Both closeDialog and restoreDialogOrigin restore their previous guard value in finally, rather than reset to false, so nested synchronous close-listener callbacks cannot prematurely expose unguarded focus. If a synchronous close listener already consumed a non-null origin, closeDialog avoids a redundant fallback focusScene. A null origin still receives the existing fallback. A reopened dialog is not explicitly restored outside itself.

Native dialog cancel is routed through closeDialog with preventDefault: Escape in an input can bypass the current document shortcut handler, so allowing default native close there would recreate the same before-guard focus defect. Existing buttons, backdrop, keyboard/controller Back already use closeDialog; direct external programmatic dialog.close outside the host is not a supported new API guarantee. The existing close listener remains for native/host close notification, guarded helper nesting and origin restoration.

Real accepted state changes/render still clear comparison caches and active key. The guard suppresses only ordinary focus/hover preview routing during the close transaction; it never selects, dispatches, saves or changes legality. Source card/revision identity, legal target/deploy checks, released physical-click barriers and all tactile cancellation logic are untouched.

## Required independent verification

Inspect source card/controller while a different legal target comparison is last hovered; close via Return, close icon, Back/Escape and backdrop; require exact preview text/key semantics and unchanged save through native and explicit focus changes. Include Escape in a text input where native dialog cancel is generated. Check real dialog close/close-event timing, origin fallback and no repeated focus jump; diagnostic synchronous close listener path may supplement, never replace trusted browser evidence. Then a real accepted action/render must replace the preview, preventing stale outcome retention. Retain R3 source rejection and any actual browser failures; do not weaken gates or claim unexecuted acceptance.
