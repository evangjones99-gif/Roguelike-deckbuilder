"""New preservation preparation only. No original tool/harness execution."""
import hashlib,json,os,stat,time
from pathlib import Path

OUT=Path('/workspace/scratch/standard-sol-tactile-r3-r4-preservation-author-r1')
ROOT=Path('/workspace/Roguelike-deckbuilder')
SCRATCH=Path('/workspace/scratch')
WORK=32*1024**2;RESERVE=512*1024**2;CAP=16*1024**2

def guard():
    current=int(Path('/sys/fs/cgroup/memory.current').read_text());maximum=int(Path('/sys/fs/cgroup/memory.max').read_text())
    vm={}
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith(('VmHWM:','VmRSS:')):vm[line.split(':')[0]]=line.split(':',1)[1].strip()
    assert maximum-current>=RESERVE
    assert int(vm['VmHWM'].split()[0])*1024<WORK
    return {'current':current,'maximum':maximum,'headroom':maximum-current,**vm}

def metadata(s):
    return {'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'size':s.st_size,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,
            'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns}

def opened(p):return os.fdopen(os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME),'rb')
def load(p):
    with opened(p) as f:return json.load(f)

initial=guard();assert initial['headroom']>=WORK+RESERVE
r3path=SCRATCH/'owner-tactile-r3-runtime-freeze-r1.json';r4path=SCRATCH/'owner-tactile-pc-r4-runtime-freeze-r1.json'
r3=load(r3path);r4=load(r4path)
baselinepath=ROOT/'reviews/owner-playtest-ux-overhaul-2026-10-01/preserved-earned-2f1-independent-r1/body/tmp/standard-sol-owner-ux-gameplay-independent-r1/AUDIT-after.json'
baseline=load(baselinepath)['variants']['baseline']
assert r3['inputCount']==r4['inputCount']==len(r3['inputs'])==len(r4['inputs'])==87
assert r3['outputCount']==r4['outputCount']==len(r3['outputs'])==len(r4['outputs'])==56
assert r3['sourceDigest']=='f8f73c598434903f4fca0f4b87e01c0412bc93ab935b6c78575aecae80325c2f'
assert r4['sourceDigest']=='27239b7ea537c4694e345a28f8b8ff94dcf0aac4b50394d81396ceecbc9bea8f'
plan={};empty=[];refs=[];deltas={'r4_vs_ROOT':{},'r3_vs_r4':{}};exclusions=[]
def add(p,group,expected=None):
    p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),str(p)
    assert s.st_size<=4*1024**2,str(p)
    key=str(p)
    if key in plan:
        assert expected is None or plan[key]['expectedSHA256'] in [None,expected]
        if expected:plan[key]['expectedSHA256']=expected
        plan[key]['roles'].append(group);return
    plan[key]={'original':key,'roles':[group],'expectedSHA256':expected,'plannedMetadata':metadata(s)}

def tree(p,group):
    p=Path(p);assert p.is_dir() and not p.is_symlink(),str(p)
    found=0
    for current,dirs,files in os.walk(p,followlinks=False):
        for name in dirs:
            q=Path(current)/name
            assert not q.is_symlink(),str(q)
            assert 'profile' not in name.casefold(),str(q)
        for name in sorted(files):
            assert 'profile' not in name.casefold(),str(Path(current)/name)
            add(Path(current)/name,group);found+=1
    if not found:empty.append(str(p))

for domain in ['inputs','outputs']:
    prefix='dist/' if domain=='outputs' else ''
    changed=[]
    for relative,sha in r4[domain].items():
        b=baseline[domain].get(prefix+relative)
        original=Path(r4['stage'])/(prefix+relative)
        assert original.is_file(),str(original)
        if b and b['sha256']==sha:
            target=ROOT/(prefix+relative);assert target.is_file(),str(target)
            refs.append({'domain':domain,'relative':relative,'sha256':sha,'baselineOriginal':str(target),
                         'r4Original':str(original),'baselineMetadataNow':metadata(target.stat()),'r4MetadataNow':metadata(original.stat()),
                         'priorBaselineAudit':str(baselinepath),'verification':'Exact frozen R4 and previously independently audited baseline ledger equality; unchanged body not reread/copied.'})
        else:add(original,'r4-runtime-'+domain,sha);changed.append(relative)
    deltas['r4_vs_ROOT'][domain]=changed
    old=[]
    for relative,sha in r3[domain].items():
        if r4[domain].get(relative)!=sha:
            add(Path(r3['stage'])/(prefix+relative),'r3-retained-delta-'+domain,sha);old.append(relative)
    deltas['r3_vs_r4'][domain]=old
assert len(deltas['r4_vs_ROOT']['inputs'])==13 and len(deltas['r4_vs_ROOT']['outputs'])==4
assert deltas['r3_vs_r4']['inputs']==['src/main.ts'] and len(deltas['r3_vs_r4']['outputs'])==3
assert len(refs)==126
for p in [r3path,r4path,baselinepath]:add(p,'complete-frozen-ledger')

closure=[]
closurehashes={'reviews/ml-policy-v0.2/engine.ts':'21bafb33832ec2d3ee1ca4ead9486825510bd380b62e143a8736465f1ad4110b',
              'reviews/ml-policy-v0.2/content.ts':'2f45160b3e577a7cd44381cb361c4407661a68819ff827a24b8ab34ce15c4234',
              'reviews/solo-v0.3/silence-overflow-campaign.json':'3b923c9b71735fdfe5bcf9d0cf068733267022c7957378b109bfdc4118ff78b6'}
for relative,sha in closurehashes.items():
    p=Path(r4['stage'])/relative;add(p,'compiler-save-closure',sha)
    closure.append({'relative':relative,'copiedOriginal':str(p),'sha256':sha,'baselineReference':str(ROOT/relative),
                    'r3Reference':str(Path(r3['stage'])/relative) if (Path(r3['stage'])/relative).is_file() else None,
                    'outsideRuntimeInputLedger':True})

for name in ['standard-sol-tactile-hand-author-r4','standard-sol-tactile-hand-source-independent-r4',
             'standard-sol-tactile-root-host-author-r3','standard-sol-tactile-root-host-author-r4',
             'standard-sol-tactile-root-host-source-independent-r3','standard-sol-tactile-root-host-source-independent-r4',
             'standard-sol-tactile-phase-budget-independent-r1']:
    tree(Path('/tmp')/name,'author-or-source-review-'+name)
for name in ['owner-tactile-r3-strict-build-r1','owner-tactile-r3-strict-build-r2','owner-tactile-pc-r4-strict-build-r1',
             'owner-tactile-r3-semantic-tests-r1','owner-tactile-pc-r4-save-tests-r1',
             'owner-tactile-r3-browser-smoke-r1','owner-tactile-r3-browser-smoke-r2','owner-tactile-r3-browser-smoke-r3','owner-tactile-r3-browser-smoke-r4',
             'owner-tactile-pc-oracle-r4','owner-tactile-pc-r4-oracle-build-r1','owner-tactile-r3-empty-intent-author-r1']:
    tree(SCRATCH/name,'completed-root-packet-'+name)
for n in range(1,5):
    roots=list(Path('/tmp').glob(f'hollowpact-owner-tactile-root-playtest-r{n}-*'));assert len(roots)==1,(n,roots)
    tree(roots[0],f'closed-root-browser-r{n}')
    add(SCRATCH/f'owner-tactile-playtest-r{n}.mjs','closed-root-browser-harness')
for name in ['guard-node-phase-r1.py','build-tactile-pc-oracle-r4.mjs','owner-tactile-pc-oracle-r4-ROOT-verification-r1.json',
             'owner-tactile-r3-source-copy-r1-failure.json','owner-tactile-r3-source-copy-r2.json',
             'owner-tactile-r3-compiler-dependency-repair-r1.json','owner-tactile-pc-r4-source-fork-r1.json',
             'owner-tactile-completed-preview-close-r1.json']:
    add(SCRATCH/name,'supporting-root-receipt-tool')
testrefs=[]
for relative in ['tests/compact-intent.test.ts','tests/audio-presentation-delay.test.ts','tests/input.test.ts','tests/presentation-events.test.ts','tests/save-validity-v0.4.test.ts']:
    add(Path(r4['stage'])/relative,'diagnostic-test-source')
    testrefs.append({'relative':relative,'copiedOriginal':str(Path(r4['stage'])/relative),'r3Original':str(Path(r3['stage'])/relative),'outsideRuntimeInputLedger':True})
exclusions=['All profile contents; active independent gameplay packets; PC pack-advice/cache/immutable-pack contents; all future PC browser outputs and PC live harness; unchanged baseline art/audio bodies; no original helpers executed.']
assert sum(x['plannedMetadata']['size'] for x in plan.values())<=CAP
planning={'status':'READY for bounded copy; not independently accepted','initialResource':initial,'work':WORK,'reserve':RESERVE,
          'bodyCap':CAP,'files':list(plan.values()),'bodyCount':len(plan),'plannedBodyBytes':sum(x['plannedMetadata']['size'] for x in plan.values()),
          'deltas':deltas,'unchangedBaselineReferences':refs,'compilerAndSaveClosure':closure,'testSources':testrefs,'emptyDirectories':empty,'exclusions':exclusions,
          'r3SourceDigest':r3['sourceDigest'],'r4SourceDigest':r4['sourceDigest'],'baselineDigest':baseline['sourceDigest']}
(OUT/'INPUT-MANIFEST.json').write_text(json.dumps(planning,indent=2)+'\n')

receipt=[]
for row in plan.values():
    guard();source=Path(row['original']);dest=OUT/'body'/source.relative_to('/')
    dest.parent.mkdir(parents=True,exist_ok=True)
    with opened(source) as sf:
        initialstat=metadata(os.fstat(sf.fileno()));assert initialstat==row['plannedMetadata'],str(source)
        h=hashlib.sha256();size=0
        with dest.open('xb') as df:
            while True:
                chunk=sf.read(65536)
                if not chunk:break
                h.update(chunk);size+=len(chunk);df.write(chunk);guard()
            df.flush();os.fsync(df.fileno())
        assert metadata(os.fstat(sf.fileno()))==initialstat,str(source)
    sha=h.hexdigest();assert size==row['plannedMetadata']['size']
    assert row['expectedSHA256'] is None or sha==row['expectedSHA256'],str(source)
    os.chmod(dest,stat.S_IMODE(initialstat['mode']));os.utime(dest,ns=(initialstat['atime_ns'],initialstat['mtime_ns']))
    ds=dest.stat();assert ds.st_uid==initialstat['uid'] and ds.st_gid==initialstat['gid'],str(source)
    with opened(source) as sf,opened(dest) as df:
        beforeS=metadata(os.fstat(sf.fileno()));beforeD=metadata(os.fstat(df.fileno()));h=hashlib.sha256()
        while True:
            a=sf.read(65536);b=df.read(65536);assert a==b,str(source)
            if not a:break
            h.update(b);guard()
        assert h.hexdigest()==sha
        assert beforeS==initialstat==metadata(os.fstat(sf.fileno()))
        assert beforeD==metadata(os.fstat(df.fileno()))
    receipt.append({**row,'copy':str(dest),'bytes':size,'sha256':sha,'sourceBeforeAndAfterExact':beforeS,
                    'copyBeforeAndAfterExact':beforeD,'directStreamingReadbackEqual':True,
                    'metadataQualification':'Preservable mode/uid/gid/mtime/atime copied; dev/inode/ctime are independently recorded, not equated.'})
(OUT/'PRESERVATION.json').write_text(json.dumps({'status':'PASS author bounded copy/readback; independent acceptance and root sealing pending',
    'files':receipt,'allOriginalsRetained':True,'deltas':deltas,'unchangedBaselineReferences':refs,'compilerAndSaveClosure':closure,
    'testSources':testrefs,'emptyDirectories':empty,'exclusions':exclusions,'finalResource':guard(),
    'dependency':'Author previously wrote arena.ts/battlefield-layout.ts/hunter-presence.ts. This preparation is not independent acceptance of those renderer inputs or game quality.'},indent=2)+'\n')
print(json.dumps({'bodyCount':len(receipt),'bodyBytes':sum(x['bytes'] for x in receipt),'deltas':deltas,'finalResource':guard()}))
