# R8 minimal clock repair — SOURCE ONLY, NOT RUN

R7 remains unchanged. Supervisor is byte-identical apart from its literal driver-r8 path. Driver now arms the300-second timer immediately after titleAt=Date.now(), before awaiting entry snapshot/JPEG; no resource, input, seed, save, stage or UI changes.896MiB TOTAL /512MiB reserve, Node heap256 and360-second whole-phase checks stay unchanged. Existing candidate300.076-second observation used the old late timer and therefore includes entry-evidence latency before timer arming; it is not exact deadline proof. Its action timestamps/raw receipts remain intact.

After distinct source acceptance and explicit ROOT grant only: python3 /workspace/scratch/standard-sol-first-five-opening-gameplay-actual-r1/supervise-r8.py /dev/shm/hollowpact-owner-tactile-pc-root-r4 /workspace/scratch/owner-tactile-pc-r4-runtime-freeze-r1.json /workspace/scratch/standard-sol-first-five-opening-gameplay-actual-r1/baseline-r2 4802

This is the baseline-only entrypoint. R7 cleanup/final checks and scope limits remain as documented in R7-SOURCE-NOTES.md. No Node/browser execution occurred. Python source syntax parsed only; actual timer delivery/event-loop jitter is runtime evidence, not a millisecond scheduling guarantee.
