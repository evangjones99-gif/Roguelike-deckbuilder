# Actual opening checkpoint — candidate complete, baseline interrupted

This is agent UI observation, not novice/human enjoyment evidence. The operator knows the rules/source, authored earlier renderer/art research, and did not author ROOT's coaching main. Candidate-first order and different ordinary random seeds/hands prevent a causal timing comparison. No manual H1 instruction, fixed seed, save/hand injection, reroll, forced click or engine-oracle choice was used. R6 is prepared source only and has not been run at this checkpoint.

All four attempted phases verified the frozen 87 inputs, 56 outputs and 56 HTTP-served bodies before the browser step. Candidate source `46c1b0ff025847fa69587fdb127e57066d65627399dccdd7e60f1c53d81b6cf5`, compiled outputs `06db3e033c589efd36692ea968a0d0a8e78185c7d9ebfb50d0c9dc985cc793cb`; baseline source `27239b7ea537c4694e345a28f8b8ff94dcf0aac4b50394d81396ceecbc9bea8f`. BYTE-AUDIT files contain actual individual hashes. Stages were not edited. Save behavior was not separately tested; UI reported local saves. Sound preference was on, but no audio audition is claimed.

## Candidate-r3: actual 300 seconds

New empty context, 1440×900, port 4801, ordinary default Initiate, visible random seed **5475926**. Title interactive `2026-10-01T14:30:27.677Z`. Close initiation `14:35:27.753Z`, elapsed **300.076 seconds**; normal browser/server close receipt `14:35:27.892Z`. Outer normal wait rc0 at302.360 whole seconds. Forty-one logged UI operations, nine JPEGs, no trace/video. Fresh640 MiB total /512 MiB reserve passed sampled resource checks; peak cgroup increase656,736,256 bytes, minimum headroom1,731,395,584. Memory.events did not change.

| Elapsed | Actually observed |
|---|---|
| 14.267s | Take a contract opened ordinary entry form. Initiate/default selected; seed/kit left unchanged. |
| 22.959s | Accepted contract; entered live fight without compulsory tutorial. Reaver+Revenant; hand Iron Ward, Ash Widow, Scour, Sundering Hex, Fen Stalker. |
| 31.865s | First binding: Ash Widow. Chosen because its passive boosts targeted spells; wanted to remove the block-bypassing Revenant. |
| 47.913s | Hover preview Scour → Revenant:6 health damage. This informed the target choice. |
| 73.483s | Ordinary Playwright sprite click timed out on its stability check. It did not commit Scour. This is a tool limitation, not proof the human pointer cannot click. No force flag used. |
| 87.471–100.356s | Used visible T / ArrowRight / Enter shortcuts; verified focused Revenant and6-damage preview, then committed. Revenant15→9, energy3→2. |
| 113.980s | Bound Fen Stalker. Immediate B at114.193s did not move focus during arrival. Later B did. READY was already displayed; exact unlock duration was not measured. |
| 147.911s | First free command: Ash Widow→Revenant, preview2 damage and resolved9→7; status Command spent. No energy required. |
| 158.829–178.508s | ArrowRight from Ash focused Reaver rather than the other ally. Native Tab through Inspect reached Fen; target preview4 damage verified. |
| 192.006–192.231s | Fen command resolved7→3; E ended turn. Hunter65→60 from Rend; Reaver gained4 block; turn2 drew/refilled5. Displayed ignores-block consequence was understood. |
| 218.491s | Bound Cairn Hound; hunter gained2 block. New actor/readout arrived later than this immediate response snapshot. |
| 234.467–256.462s | B remembered Fen, so Tab traversal reached Cairn rather than initially intended Fen. Actual source name in focused/preview text exposed the mismatch before commitment. Deliberately accepted Cairn's lethal3-HP preview; Revenant fell. |
| 256.794–257.082s | Iron Ward raised hunter block to9; bound Briar Colossus. Four actual bindings eventually published. |
| 293.302–299.151s | Fen→Reaver preview explicitly stated0 health damage,4 blocked,1 retaliation. Chose shield-breaking trade; Reaver block4→0, Fen10→9. |

At cutoff: contract1/turn2, hunter60/65 and9 block, four bindings, Reaver16 HP remained. Ash/Colossus commands remained; no reward or loss reached. Observation ended instead of extending to manufacture a terminal outcome.

The **new first-binding cue was not observed in the first battle snapshot**: guidance displayed `Iron Ward: hunter: gains 7 block`, and focused element was Iron Ward. This establishes the captured entry state, not that the cue never flashed before capture or the precise reason without a targeted follow-up. The source cue alone therefore has not earned actual teaching-access acceptance. Full intent type/amount/target and keyboard previews were readable in the observed DOM; initial/turn2 screenshots show the large rails and small hunter. No complete visual-quality or one-screen conclusion is implied by DOM text.

B's remembered identity and spatial ArrowRight surprised the operator. Several keyboard navigation steps were sent in small batches with logged intent; these revealed source-focus mismatches on the response, and the actual command preview was checked before later target commitment. Record this operator/tool behavior rather than treating it as novice confusion or a timing benchmark. Optional Help was not used in candidate. Drag/cancel/save continuation and no-canvas fallback belong to separate ROOT checks and remain unassessed here.

## Failed/partial phases remain evidence

`candidate/`: preplay default Playwright headless-shell missing, no browser/title clock. Driver failed, server closed; outer wait1.243s, rc76/driver2. No installation/retry was automatic.

`candidate-r2/`: installed `/usr/bin/chromium` opened actual title, but this author's wrong wait expected Initiate there rather than Take a contract. It timed out before any action/clock. Actual title screenshot retained; normal close receipt and12.271s outer wait, rc76/driver2. ROOT specifically authorized the corrected new attempt.

`baseline/`: fresh default Initiate, visible random seed **4616350**, Reaver+Bone Thrall, hand Scour/Colossus/Fen/Cairn/Survey. Title `14:35:54.817Z`; accepted contract20.047s and saw compulsory four-section tutorial. Resource cancellation at whole21.855s/titleabout20.399s:688,824,320-byte cgroup increase exceeded640 MiB by17,735,680, while headroom remained1,701,584,896. Subsequent close-tutorial/bind commands were queued but never executed. No binding/command/reward/loss and no completed300 seconds.

The old close routine let final snapshot failure skip remaining cleanup, and old supervisor waited the remaining phase ceiling instead of5 seconds after resource stop. This author detected the defect and killed only identity-verified own Node group450805/starttick7583928 at14:37:22.993Z. Outer waited rc76/child-9 at90.109s, no remaining Node group. This was failed teardown evidence, not a success.

All old supervisors tracked **Node's group only** (owned count1); Playwright Chromium used separate groups. Candidate normal `browser.close` and Node-group disappearance do **not** establish historical Chromium PID disappearance. ROOT's later independent census and this author's current census found no live Chromium/Node; recent dead/zombie processes and historical zombies remain, RSS0, not killed. Keep this qualified closure statement. R6 source addresses future observations across groups and classifies unreaped zombies explicitly; it cannot retroactively repair these receipts.

No conclusion that candidate teaches better or is more enjoyable follows from a completed candidate and an interrupted, differently seeded baseline. Current useful finding: compulsory dialog removal worked in this actual entry, but the captured binding cue was displaced by a consequence preview. Further comparison requires the separately reviewed/admitted baseline revision; no automatic retry.

Personally viewed captures at this checkpoint: candidate-r2 `01-final.jpg`; candidate-r3 `02-first-fight.jpg` and `06-enemy-response.jpg`; baseline `02-tutorial-or-fight.jpg`. Other stored JPEGs are retained raw evidence, not claimed personally inspected. Source knowledge, DOM snapshots, static screenshots and motion/audio observations stay distinct.
