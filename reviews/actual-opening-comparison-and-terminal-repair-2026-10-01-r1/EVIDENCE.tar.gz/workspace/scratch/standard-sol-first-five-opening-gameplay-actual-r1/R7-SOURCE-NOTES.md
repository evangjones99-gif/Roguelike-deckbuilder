# Baseline R7 source repair — NOT RUN

R6 remains exact source-refusal evidence. R7 changes only its supervisor cleanup/result path; `driver-r7.mjs` is byte-identical to driver-r6. Both use the specifically authorized **896 MiB TOTAL / unchanged512 MiB reserve**, Node heap256. This does not rewrite the old640 MiB candidate observations or failed baseline. No Node/browser/server execution of R7 occurred.

The baseline-only caller after distinct source acceptance and explicit ROOT grant is:

```sh
python3 /workspace/scratch/standard-sol-first-five-opening-gameplay-actual-r1/supervise-r7.py /dev/shm/hollowpact-owner-tactile-pc-root-r4 /workspace/scratch/owner-tactile-pc-r4-runtime-freeze-r1.json /workspace/scratch/standard-sol-first-five-opening-gameplay-actual-r1/baseline-r2 4802
```

NEW packet must not exist. The driver verifies source27239… and87/56/served bodies, validates its own same-phase outer admission credit, uses installed Chromium/no-sandbox, then ordinary empty-context/default Initiate/random UI seed at1440×900. Title clock300s, no forced input or injected state, <=10 JPEGs/128 logged events, no trace/video. It cannot run the new hand-cue candidate; that requires a later separately pinned entrypoint.

Post-admission launch through normal wait now has an enclosing try/except/finally. A launch-receipt, identity, sampling, signal-log, wait or execution-log error triggers scoped cleanup and a failed/unknown result. Child poll errors are recorded rather than escaping cleanup. A pidfd retains the exact launched child even if identity/log observation fails; if pidfd acquisition fails, Popen's own still-unreaped child is the fallback, never an arbitrary reused PID. Known descendants retain PID/starttick across PGIDs/reparenting; per-PID signals verify current UID/PGID/starttick and use pidfds. Zombies are nonlive/unreaped and never signalled. No global/historical zombie cleanup.

Cancellation starts by350s. Cleanup attempts TERM, waits at most5s and no later than355, then scoped KILL plus bounded child wait with359s deadline margin; incomplete status fails. Normal close also examines tracked live descendants. The overall360s and known-descendant coverage are checks, not an impossible guarantee under kernel/power loss. Unknown observations remain unknown; ROOT monitors incomplete output using scoped launch/known identities.

RESULT explicitly requires rc0, no lifecycle/cleanup error, no observed tracked live descendants, all sampled and final work/reserve/free/max checks, unchanged memory.events and whole time<=360. A stopped phase cannot become success merely because close later finishes. Execution log and RESULT fsync are attempted. A RESULT write/fsync failure emits a failure notice and exit76 when possible; a partial/pass-shaped file alone is not authoritative—caller must require successful wrapper exit and complete receipt. Filesystem/stdout failure may leave incomplete evidence and is not declared safe success.

Root's no-live-Chromium census and old normal browser.close receipts stay distinct from historical PID disappearance, which old group-only sampling did not establish. R7 source repair does not repair those past receipts or prove novice understanding/fun. No runtime/performance/quality/platform acceptance is supplied by source preparation.
