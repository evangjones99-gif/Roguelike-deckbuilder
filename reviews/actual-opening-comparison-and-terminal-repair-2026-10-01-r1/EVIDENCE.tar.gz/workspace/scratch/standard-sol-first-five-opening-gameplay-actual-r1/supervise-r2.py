import os,sys,time,json,pathlib,subprocess,signal
stage,freeze,packet,port=sys.argv[1:];p=pathlib.Path(packet);p.mkdir(exist_ok=False)
work=640*1048576;reserve=512*1048576;cgroup=pathlib.Path('/sys/fs/cgroup')
def sample():
 c=int((cgroup/'memory.current').read_text());m=int((cgroup/'memory.max').read_text());return {'time_ns':time.time_ns(),'current':c,'maximum':m,'headroom':m-c,'free':os.statvfs(stage).f_bavail*os.statvfs(stage).f_frsize}
def identities(group):
 result={}
 for d in pathlib.Path('/proc').iterdir():
  if not d.name.isdigit():continue
  try:
   x=(d/'stat').read_text();fields=x[x.rindex(')')+2:].split()
   if int(fields[2])==group:result[d.name]={'starttime':fields[19],'state':fields[0],'pgrp':group}
  except (OSError,ValueError,IndexError):pass
 return result
initial=sample();before=(cgroup/'memory.events').read_text();admitted=initial['headroom']>=work+reserve and initial['free']>=64*1048576
(p/'ADMISSION.json').write_text(json.dumps({'admitted':admitted,'initial':initial,'work':work,'reserve':reserve,'stage':stage,'freeze':freeze,'whole_wall_ceiling_seconds':360},indent=2)+'\n')
if not admitted:print('REFUSED',json.dumps(initial));sys.exit(75)
rows=[];owned={};failure=None;start=time.monotonic()
with (p/'EXECUTION.log').open('xb') as log:
 proc=subprocess.Popen(['node','/workspace/scratch/standard-sol-first-five-opening-gameplay-actual-r1/driver-r2.mjs',stage,freeze,packet,port],cwd=stage,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (p/'OWNED-LAUNCH.json').write_text(json.dumps({'pid':proc.pid,'pgrp':proc.pid,'identities':identities(proc.pid),'utc_ns':time.time_ns()})+'\n')
 while proc.poll() is None:
  r=sample();r['delta']=r['current']-initial['current'];r['elapsed']=time.monotonic()-start;rows.append(r)
  owned.update(identities(proc.pid))
  if r['headroom']<reserve or r['delta']>work or r['free']<1048576 or r['elapsed']>=355:
   failure={'kind':'resource or 355s cancellation','sample':r};os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=max(.1,360-(time.monotonic()-start)))
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=2)
   break
  time.sleep(.1)
 rc=proc.wait();log.flush();os.fsync(log.fileno())
left=identities(proc.pid)
if left:
 failure={'kind':'group remained after driver wait','remaining':left};os.killpg(proc.pid,signal.SIGTERM)
 time.sleep(.5);left=identities(proc.pid)
 if left:os.killpg(proc.pid,signal.SIGKILL)
time.sleep(.2);remaining=identities(proc.pid);final=sample()
result={'exit_code':rc,'failure':failure,'initial':initial,'final':final,'samples':rows,'memory_events_before':before,'memory_events_after':(cgroup/'memory.events').read_text(),'owned_observed':owned,'post_wait_group':remaining,'normal_wait':failure is None and rc==0 and not remaining,'whole_seconds':time.monotonic()-start,'scope':'640 total cgroup-delta work plus512 reserve; tracked owned process group; no claim that detached escaped descendants are proven absent'}
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['samples','owned_observed','memory_events_before','memory_events_after']}));sys.exit(0 if result['normal_wait'] else 76)
