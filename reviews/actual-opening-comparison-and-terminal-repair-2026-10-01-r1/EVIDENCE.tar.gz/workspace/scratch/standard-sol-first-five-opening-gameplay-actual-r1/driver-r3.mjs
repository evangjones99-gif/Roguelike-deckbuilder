import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const [stage,freezePath,packet,portText]=process.argv.slice(2);
const port=Number(portText), started=Date.now(), freeze=JSON.parse(fs.readFileSync(freezePath));
const require=createRequire(path.join(stage,'package.json'));
let browser,server,page,closing=false,titleAt=null,shots=0,events=0;
const log=(name,x)=>fs.appendFileSync(path.join(packet,name),JSON.stringify(x)+'\n');
const stamp=()=>({utc:new Date().toISOString(),elapsed_ms:titleAt===null?null:Date.now()-titleAt});
async function hashFile(file){const h=crypto.createHash('sha256');let bytes=0;for await(const b of fs.createReadStream(file,{flags:fs.constants.O_RDONLY|fs.constants.O_NOATIME|fs.constants.O_NOFOLLOW,highWaterMark:32768})){h.update(b);bytes+=b.length;}return {sha256:h.digest('hex'),bytes};}
async function snapshot(){return page.evaluate(()=>({text:document.body.innerText.slice(0,14000),buttons:Array.from(document.querySelectorAll('button,input,select')).filter(x=>x.getClientRects().length).slice(0,100).map(x=>({tag:x.tagName,text:x.innerText,aria:x.getAttribute('aria-label'),disabled:x.disabled,ariaDisabled:x.getAttribute('aria-disabled'),id:x.id,ui:x.dataset.ui,action:x.dataset.action,index:x.dataset.index,unit:x.dataset.unit,card:x.dataset.card,value:x.tagName==='INPUT'||x.tagName==='SELECT'?x.value:undefined})),focus:document.activeElement?.getAttribute('aria-label')||document.activeElement?.textContent?.slice(0,150)}));}
async function shot(label){if(shots>=10){log('LIMITS.jsonl',{...stamp(),kind:'screenshot cap',label});return null;}const file=path.join(packet,`${String(++shots).padStart(2,'0')}-${label.replace(/[^a-z0-9-]/gi,'-')}.jpg`);await page.screenshot({path:file,type:'jpeg',quality:80});return file;}
async function close(reason){if(closing)return;closing=true;log('LIFECYCLE.jsonl',{...stamp(),event:'close initiated',reason,whole_elapsed_ms:Date.now()-started});try{if(page&&!page.isClosed()){log('FINAL-UI.jsonl',{...stamp(),ui:await snapshot()});await shot('final');}if(browser)await browser.close();if(server)await new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()));log('LIFECYCLE.jsonl',{...stamp(),event:'normal browser and server close',reason,whole_elapsed_ms:Date.now()-started});process.exitCode=reason==='300s'?0:2;}catch(e){log('LIFECYCLE.jsonl',{...stamp(),event:'close failed',error:String(e)});process.exitCode=3;}}
process.on('SIGTERM',()=>{void close('supervisor SIGTERM');});
const wholeTimer=setTimeout(()=>void close('350s cancellation'),350000);
try{
 if(freeze.stage!==stage||freeze.inputCount!==87||freeze.outputCount!==56)throw Error('unexpected freeze identity/count');
 const audit={freezePath,stage,sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest??null,inputs:[],outputs:[],served:[]};
 for(const [rel,expected] of Object.entries(freeze.inputs)){const actual=await hashFile(path.join(stage,rel));if(actual.sha256!==expected)throw Error('input mismatch '+rel);audit.inputs.push({path:rel,...actual});}
 for(const [rel,expected] of Object.entries(freeze.outputs)){const actual=await hashFile(path.join(stage,'dist',rel));if(actual.sha256!==expected)throw Error('output mismatch '+rel);audit.outputs.push({path:rel,...actual});}
 const outputKeys=Object.keys(freeze.outputs).sort();
 server=http.createServer((req,res)=>{try{const pathname=new URL(req.url,'http://localhost').pathname;const key=pathname==='/'?'index.html':decodeURIComponent(pathname.slice(1));if(!outputKeys.includes(key)){res.writeHead(404);res.end('Not found');return;}res.setHeader('Content-Type',key.endsWith('.html')?'text/html':key.endsWith('.js')?'text/javascript':key.endsWith('.css')?'text/css':key.endsWith('.png')?'image/png':key.endsWith('.json')?'application/json':'application/octet-stream');fs.createReadStream(path.join(stage,'dist',key)).pipe(res);}catch{res.writeHead(400);res.end('Bad request');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
 for(const rel of outputKeys){const response=await fetch(`http://127.0.0.1:${port}/${rel.split('/').map(encodeURIComponent).join('/')}`);if(!response.ok)throw Error('serve failed '+rel);const h=crypto.createHash('sha256');let bytes=0;for await(const b of response.body){h.update(b);bytes+=b.length;}const sha256=h.digest('hex');if(sha256!==freeze.outputs[rel])throw Error('served mismatch '+rel);audit.served.push({path:rel,bytes,sha256});}
 fs.writeFileSync(path.join(packet,'BYTE-AUDIT.json'),JSON.stringify(audit,null,2)+'\n');
 const {chromium}=require('playwright');browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:1440,height:900}});page=await context.newPage();page.on('pageerror',e=>log('ERRORS.jsonl',{...stamp(),kind:'pageerror',message:String(e).slice(0,1200)}));page.on('console',m=>{if(m.type()==='error')log('ERRORS.jsonl',{...stamp(),kind:'console error',message:m.text().slice(0,1200)});});
 log('LIFECYCLE.jsonl',{...stamp(),event:'navigation start',url:`http://127.0.0.1:${port}`});await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded',timeout:15000});await page.locator('button[data-ui="new"]').waitFor({state:'visible',timeout:10000});
 titleAt=Date.now();log('LIFECYCLE.jsonl',{...stamp(),event:'title interactive',whole_elapsed_ms:titleAt-started});log('RESPONSES.jsonl',{id:'entry',...stamp(),ui:await snapshot(),screenshot:await shot('entry')});
 const runTimer=setTimeout(()=>void close('300s'),300000);let offset=0;
 while(!closing){const file=path.join(packet,'COMMANDS.jsonl');if(fs.existsSync(file)){const content=fs.readFileSync(file,'utf8');const lines=content.slice(offset).split('\n');for(const raw of lines.slice(0,-1)){offset+=raw.length+1;if(!raw)continue;const c=JSON.parse(raw);if(++events>128)throw Error('event cap exceeded');const event={id:c.id,...stamp(),intent:c.intent,alternative:c.alternative,input:c};log('ACTIONS.jsonl',event);try{if(c.op==='click')await page.locator(c.selector).click({timeout:1800});else if(c.op==='key')await page.keyboard.press(c.key);else if(c.op==='hover')await page.locator(c.selector).hover({timeout:1800});else if(c.op==='inspect'){}else throw Error('unsupported operation');await page.waitForTimeout(100);log('RESPONSES.jsonl',{id:c.id,...stamp(),ui:await snapshot(),screenshot:c.shot?await shot(c.shot):null});}catch(e){log('RESPONSES.jsonl',{id:c.id,...stamp(),error:String(e),ui:await snapshot()});}if(closing)break;}}await new Promise(r=>setTimeout(r,100));}
 clearTimeout(runTimer);clearTimeout(wholeTimer);
}catch(e){log('FAILURE.jsonl',{...stamp(),error:String(e)});await close('driver failure');clearTimeout(wholeTimer);}
