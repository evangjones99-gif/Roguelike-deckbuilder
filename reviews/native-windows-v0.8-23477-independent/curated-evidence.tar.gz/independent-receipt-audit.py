from pathlib import Path
import json,hashlib,zipfile,math,datetime
r=Path(__file__).parent;repo=Path('/workspace/Roguelike-deckbuilder')
read=lambda p:json.loads(p.read_bytes().decode('utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
run=read(r/'run-final.json');jobs=read(r/'jobs-final.json');artifacts=read(r/'artifacts-final.json')['artifacts']
merge=read(r/'actual-merge-commit.json');tree=read(r/'actual-merge-tree.json')
head='2e93c2dab38c513a6f43e1dc4e31307f0866db14';checkout='7c460a706d6e5bfd8c98d5886b3d1d5cab679cef'
assert run['id']==36806506465 and run['head_sha']==head and run['event']=='pull_request' and run['run_attempt']==1
assert run['path']=='.github/workflows/windows-validation.yml' and run['status']=='completed' and run['conclusion']=='success'
assert jobs['total_count']==1 and jobs['jobs'][0]['id']==110191925032 and jobs['jobs'][0]['conclusion']=='success'
assert all(s['conclusion']=='success' for s in jobs['jobs'][0]['steps'])
assert merge['sha']==checkout and head in [p['sha'] for p in merge['parents']]
assert tree['sha']==merge['commit']['tree']['sha'] and tree['truncated'] is False
blobs={row['path']:row for row in tree['tree'] if row['type']=='blob'}
small=r/'raw-small-members';current=small/'reviews/windows-native/0.8.0/run-36806506465-1'
smoke=read(current/'smoke.json');package=read(current/'native-package.json');transfer=read(small/'build-desktop/windows-transfer/manifest.json');provenance=read(small/'dist/build-provenance.json')
assert provenance['version']=='0.8.0' and len(provenance['hashes'])==76 and provenance['node']=='v24.19.0'
ordered=json.dumps(provenance['hashes'],separators=(',',':'),ensure_ascii=False).encode()
runtime=sha(ordered);assert runtime=='23477f68c99d6d60b0b3f82b286a8d33bb6da6f2ca92c103fbecf5663634959f'==provenance['sourceDigest']
source=[]
for name,expected in provenance['hashes'].items():
 p=repo/name;b=p.read_bytes();assert sha(b)==expected,name
 gitblob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert blobs[name]['sha']==gitblob and blobs[name]['mode']=='100644',name
 source.append({'path':name,'sha256':expected,'actualPRMergeGitBlobSHA':gitblob})
assert smoke['commit']==package['commit']==transfer['commit']==checkout
assert str(run['id'])==smoke['runId']==package['runId']==transfer['runId']
assert smoke['version']==transfer['version']=='0.8.0' and smoke['runtimeSourceDigest']==transfer['sourceDigest']==runtime
assert smoke['status']=='passed' and smoke['platform']=='win32' and smoke['architecture']=='x64' and smoke['osRelease']=='10.0.20348'
assert len(smoke['steps'])==13 and smoke['errors']==[]
assert smoke['security']=={'sandbox':True,'contextIsolation':True,'nodeIntegration':False,'launchSandboxDisabled':False}
assert len(smoke['packageFiles'])==72 and smoke['packageFiles']['Hollowpact.exe']==smoke['executableSHA256']==package['executableSHA256']
assert smoke['asarSHA256']==smoke['packageFiles']['resources/app.asar']=='c383c4437ac5467146174c6ea039b2a8b28af43d609701379e8cf695f59d530c'
assert package['signatureStatus']=='NotSigned' and package['fileVersion']=='0.8.0' and package['productVersion']=='0.8.0.0'
assert package['productName']=='Hollowpact'
assert package['archiveSHA256']==transfer['sha256']=='1ce6c74baea02686183e833c28738e04d19f80d5826218a0d732eff304dce563'
assert transfer['bytes']==191814688 and len(transfer['parts'])==8 and sum(p['bytes'] for p in transfer['parts'])==transfer['bytes']
assert len(artifacts)==10 and all(a['expired'] is False and a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==head for a in artifacts)
wrapper=[]
for i,part in enumerate(transfer['parts'],1):
 assert part['index']==i and part['filename']==f'part-{i:02}.bin' and 0<part['bytes']<=25165824
 matches=[a for a in artifacts if a['name']==f'hollowpact-0.8.0-windows-part-{i:02}-36806506465-1'];assert len(matches)==1
 a=matches[0];assert a['size_in_bytes']==part['bytes']+136 and a['size_in_bytes']<=25165960
 wrapper.append({'partIndex':i,'artifactID':a['id'],'wrapperBytes':a['size_in_bytes'],'APIWrapperSHA256':a['digest'],'rawPartBytes':part['bytes'],'rawPartSHA256':part['sha256'],'originalWholeRecoveryVerifiedHere':False})
assert len(smoke['resources']['icons'])==7 and len(smoke['resources']['iconGroups'])==1
assert any(s['ProductName']=='Hollowpact' and s['FileVersion']=='0.8.0' and s['ProductVersion']=='0.8.0.0' for v in smoke['resources']['versions'] for s in v['strings'])
draws=smoke['hunterFigure']['draws'];assert len(draws)==8
overflow=[]
for i,d in enumerate(draws):
 assert d['width']==1536 and d['height']==1024 and d['source']==[0,0,512,512]
 assert d['url'].startswith('file:') and d['url'].endswith('/resources/app.asar/dist/art/hunter-marek-v07-r3.png')
 w,h=d['viewport']['width'],d['viewport']['height']
 for p in d['quad']:
  assert math.isfinite(p['x']) and math.isfinite(p['y'])
  if p['x'] < -0.01 or p['x'] > w+0.01 or p['y'] < -0.01 or p['y'] > h+0.01:overflow.append(i)
assert not overflow
keyboard=smoke['keyboard'];assert keyboard['physicalKeyboard'] is False and keyboard['physicalController'] is False
assert len(keyboard['held'])==2 and all(v['saveUnchangedUntilFreshActivation'] and v['cancelRestoresSource'] for v in keyboard['held'])
assert all(v is True for k,v in keyboard['modal'].items()) and keyboard['regional']['saveUnchanged'] is True
assert all(t['trusted'] for t in keyboard['trace'])
for key in ['Enter',' ']:assert any(t['key']==key and t['repeat'] and t['prevented'] for t in keyboard['trace'])
assert keyboard['command']=={'type':'attack','unit':'a3','target':'e1','exactCanonicalState':True,'afterSaveSHA256':'27968c3637426cd739de234aa59cfd7644d0b397d46973749c876702e3f6f2f8'}
feedback=read(current/'synthetic-negative-feedback.json');assert sha((current/'synthetic-negative-feedback.json').read_bytes())==smoke['feedback']['reportSHA256']
assert feedback['context']['build']=={'version':'0.8.0','sourceDigest':runtime,'channel':'packaged'}
assert feedback['responses']['replayIntent']=='no' and feedback['responses']['confusion'].startswith('[AUTOMATED WINDOWS QA — not a human opinion]')
assert smoke['feedback']=={'download':'completed','storageUnchanged':True,'reportSHA256':smoke['feedback']['reportSHA256'],'synthetic':True}
helper_names=['scripts/windows-smoke.mjs','.github/workflows/windows-validation.yml','desktop/main.cjs','desktop/audio-lifecycle.cjs','scripts/build.mjs','src/engine.ts','src/content.ts','src/world-rng.ts']
copied=[]
for name in helper_names:
 p=repo/name;b=p.read_bytes();gitblob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert gitblob==blobs[name]['sha'],name
 target=r/'actual-merge-verified-source'/name;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as f:f.write(b)
 copied.append({'path':name,'sha256':sha(b),'actualPRMergeGitBlobSHA':gitblob})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed-actual-native-small-receipt-source-gate-originalWholePending','branchHead':head,'actualPRMergeCheckout':checkout,'runtimeSourceDigest':runtime,'runtimeInputs':76,'all76CurrentAndMergeBlobsMatch':True,'currentSourceLedger':source,'actualMergeVerifiedHelpers':copied,'reportedNativePhases':13,'reportedPackageFiles':72,'reportedWindowsASAR':smoke['asarSHA256'],'matchingPreviouslyTestedLinuxASAR':True,'actualHunterIdleDraws':8,'wholeCellQuadsWithinRecordedViewport':True,'signatureStatus':'NotSigned','originalZIPBytes':transfer['bytes'],'originalZIP_SHA256':transfer['sha256'],'boundedWrapperAPIPlan':wrapper,'originalWholeRecoveryVerifiedHere':False,'scope':'Actual hosted-Windows run/raw small evidence/source audit. No local Windows execution, whole native original download, installer lifecycle, native listening/controller/Deck, AAA or Steam acceptance.'}
with (r/'INDEPENDENT-RECEIPT-AUDIT.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:result[k] for k in ['status','runtimeInputs','reportedNativePhases','reportedPackageFiles','actualHunterIdleDraws','originalWholeRecoveryVerifiedHere']}))
