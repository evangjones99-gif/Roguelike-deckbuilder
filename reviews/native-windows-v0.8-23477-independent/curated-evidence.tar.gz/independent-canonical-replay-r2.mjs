import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {tsImport} from '/workspace/Roguelike-deckbuilder/node_modules/tsx/dist/esm/api/index.mjs';
const root='/workspace/scratch/windows-native-independent-v08-run-36806506465';
const receiptDir=root+'/raw-small-members/reviews/windows-native/0.8.0/run-36806506465-1';
const smoke=JSON.parse(fs.readFileSync(receiptDir+'/smoke.json'));
const feedback=JSON.parse(fs.readFileSync(receiptDir+'/synthetic-negative-feedback.json'));
const provenance=JSON.parse(fs.readFileSync(root+'/raw-small-members/dist/build-provenance.json'));
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
for(const file of ['src/engine.ts','src/content.ts','src/world-rng.ts']){
  assert.equal(hash(fs.readFileSync(root+'/actual-merge-verified-source/'+file)),provenance.hashes[file]);
  assert.equal(smoke.canonicalEngineSource[file],provenance.hashes[file]);
}
const {createGame,applyAction,legalActions,validateState}=await tsImport(pathToFileURL(root+'/actual-merge-verified-source/src/engine.ts').href,import.meta.url);
let state=createGame(121,0);
const travel=legalActions(state).find(action=>action.type==='travel'&&action.choice==='battle');assert(travel);
state=applyAction(state,travel);
const binding={type:'play',index:state.hand.indexOf('cairnhound')};assert(binding.index>=0);
assert(legalActions(state).some(action=>JSON.stringify(action)===JSON.stringify(binding)));
state=applyAction(state,binding);assert(validateState(state));
assert.equal(hash(JSON.stringify(state)),smoke.keyboard.beforeSaveSHA256);
const command={type:'attack',unit:'a3',target:'e1'};
assert(legalActions(state).some(action=>JSON.stringify(action)===JSON.stringify(command)));
state=applyAction(state,command);assert(validateState(state));
assert.equal(hash(JSON.stringify(state)),smoke.keyboard.command.afterSaveSHA256);
assert.deepEqual(smoke.state,{seed:state.seed,phase:state.phase,allies:state.allies.length,enemies:state.enemies.length,hp:state.hp});
assert.deepEqual(feedback.context.run,{seed:state.seed,difficulty:state.difficulty,phase:state.phase,contract:state.floor,
  hunterHealth:state.hp,maximumHealth:state.maxHp,saveSchema:state.schema,rulesGeneration:state.engineKind,
  deck:state.deck,relics:state.relics,stats:state.stats});
assert.deepEqual(feedback.context.build,{version:'0.8.0',sourceDigest:provenance.sourceDigest,channel:'packaged'});
assert.equal(feedback.context.screen,'battle');assert.equal(feedback.responses.replayIntent,'no');
assert.equal(feedback.responses.interestingChoice,'None in this synthetic interaction check.');
assert.equal(feedback.responses.confusion,'[AUTOMATED WINDOWS QA — not a human opinion] <script>window.nativeAudit=1</script> Target unclear.');
assert.equal(hash(fs.readFileSync(receiptDir+'/synthetic-negative-feedback.json')),smoke.feedback.reportSHA256);
const result={status:'passed',scope:'Independent Linux replay using exact actual-merge Git-blob/provenance-verified canonical rules. Actual native serialized save itself is absent from the small artifact; independent replay matches both recorded before/after full-serialized-save SHA256 and exact recorded feedback context, not a direct native save-file byte comparison. No native Windows rerun.',
  seed:121,difficulty:0,actions:[travel,binding,command],allActionsLegal:true,stateValid:true,
  beforeSaveSHA256:smoke.keyboard.beforeSaveSHA256,afterSaveSHA256:hash(JSON.stringify(state)),
  nativeSaveBytesDirectlyAvailable:false,feedbackCanonicalContextExact:true,syntheticNegativeFeedback:true};
fs.writeFileSync(root+'/INDEPENDENT-CANONICAL-REPLAY.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
