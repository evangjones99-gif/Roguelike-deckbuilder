import os,json,hashlib,shutil
from pathlib import Path
root=Path('/workspace/Roguelike-deckbuilder');stage=Path('/workspace/scratch/first-five-opening-row-navigation-stage-r6');packet=Path('/workspace/scratch/root-opening-row-r6-promotion-r1');packet.mkdir(mode=0o700)
freeze=json.loads(Path('/workspace/scratch/first-five-opening-row-navigation-runtime-freeze-root-r6.json').read_text());assert freeze['sourceDigest']=='93162336479c7affb874164fc59136c655fae7e5f793b70afbbba4888fe1fcfb'
old=json.loads((root/'dist/build-provenance.json').read_text());assert old['sourceDigest']=='801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029'
def body(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  st=os.fstat(fd);out=b''
  while b:=os.read(fd,65536):out+=b
  assert os.fstat(fd)==st
  return out
 finally:os.close(fd)
def sha(p):return hashlib.sha256(body(p)).hexdigest()
for rel,h in old['hashes'].items():assert sha(root/rel)==h,rel
for rel,h in freeze['inputs'].items():assert sha(stage/rel)==h,rel
for rel,h in freeze['outputs'].items():assert sha(stage/'dist'/rel)==h,rel
changes=[rel for rel,h in freeze['inputs'].items() if old['hashes'].get(rel)!=h];assert all(x.startswith('src/') for x in changes)
assert len(changes)==15
# Preserve exact old source and non-media build bodies; all unchanged public media
# remain in the current tree/Git and have their exact old output identities below.
oldoutputs={f.relative_to(root/'dist').as_posix():sha(f) for f in sorted((root/'dist').rglob('*')) if f.is_file()}
for rel in changes:
 if (root/rel).exists():
  q=packet/'old-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(body(root/rel))
for rel,h in oldoutputs.items():
 if (root/'public'/rel).is_file():assert sha(root/'public'/rel)==h,rel
 else:
  q=packet/'old-build'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(body(root/'dist'/rel))
for rel in changes:
 target=root/rel;tmp=target.with_name(target.name+'.opening-r6-tmp');assert not tmp.exists()
 data=body(stage/rel)
 with tmp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.replace(tmp,target)
for rel,h in freeze['inputs'].items():assert sha(root/rel)==h,rel
# Preserve already-used targeted regression tests as production regression tools.
tests=['tests/compact-intent.test.ts','tests/audio-presentation-delay.test.ts'];testpins={}
for rel in tests:
 source=body(stage/rel);target=root/rel
 if target.exists():assert body(target)==source
 else:
  with target.open('xb') as f:f.write(source);f.flush();os.fsync(f.fileno())
 testpins[rel]=hashlib.sha256(source).hexdigest()
r={'status':'Exact source promoted; ROOT strict build/integration unit checks pending','producerJudgment':'Scoped first-five opening/PC development promotion: meaningful repaired entry, names/intents, survivor identity, tactile mouse/cancel/Continue and row navigation have independently compared evidence. No general-game/AAA/human-fun/native/pixel-art acceptance.','baselineRuntime':old['sourceDigest'],'baselineCommit':'0e9fbd9974c65d44150dd18dcf9e37a2330074f3','candidateRuntime':freeze['sourceDigest'],'candidateOutputsDigest':freeze['outputsDigest'],'sourceChanges':changes,'oldInputs':old['hashes'],'oldOutputs':oldoutputs,'newInputs':freeze['inputs'],'regressionTests':testpins,'preservation':'Old source/nonmedia build bodies copied; exact unchanged media remain in public and Git. Historical releases/stages/images/reviews/data retained. Atomic source replacement; public/trace/old stage bodies never written.'}
(packet/'PROMOTION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['oldInputs','oldOutputs','newInputs']}))
