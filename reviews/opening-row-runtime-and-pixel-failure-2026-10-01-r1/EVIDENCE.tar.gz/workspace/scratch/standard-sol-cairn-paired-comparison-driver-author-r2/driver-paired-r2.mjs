// SOURCE-ONLY paired Cairn actual-Arena supplement. No execution without ROOT grant.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/playwright-core/index.mjs';


const [stage,freezePath,packet,portText]=process.argv.slice(2),port=Number(portText),started=Date.now();
const expected=JSON.parse(fs.readFileSync('/workspace/scratch/standard-sol-cairn-paired-comparison-driver-author-r2/EXPECTED-CANDIDATE.json'));
assert.equal(stage,expected.stage);assert.equal(freezePath,expected.freezePath);
assert.equal(packet,expected.actualPacket);assert.equal(port,expected.port);
assert.equal(expected.captureCap,12);assert.equal(expected.perContextCaptureCap,6);
const hash=b=>createHash('sha256').update(b).digest('hex');
const controlsPath='/workspace/scratch/standard-sol-cairn-paired-comparison-driver-author-r2/MANIFEST.json';
const controlsBytes=fs.readFileSync(controlsPath),controls=JSON.parse(controlsBytes);
const freezeBytes=fs.readFileSync(freezePath),freeze=JSON.parse(freezeBytes);
assert.equal(hash(freezeBytes),expected.freezeSHA256);assert.equal(freeze.stage,stage);
assert.equal(freeze.sourceDigest,expected.sourceDigest);assert.equal(freeze.outputsDigest,expected.outputsDigest);
assert.equal(freeze.inputCount,89);assert.equal(freeze.outputCount,57);
const admission=JSON.parse(fs.readFileSync(path.join(packet,'ADMISSION.json'))),work=896*1048576,reserve=512*1048576;
const current=Number(fs.readFileSync('/sys/fs/cgroup/memory.current','utf8')),maximum=Number(fs.readFileSync('/sys/fs/cgroup/memory.max','utf8'));
const spent=Math.max(0,current-admission.initial.current);
assert(admission.admitted===true&&admission.stage===stage&&admission.freeze===freezePath&&admission.work===work&&admission.reserve===reserve&&admission.initial.maximum===maximum&&admission.initial.headroom>=work+reserve&&spent<=work&&maximum-current>=reserve+Math.max(0,work-spent),'Same outer896+512 accounting rejected');
fs.writeFileSync(path.join(packet,'INSIDE-PHASE-ACCOUNTING.json'),JSON.stringify({work,reserve,current,maximum,spent,remaining:Math.max(0,work-spent),freshAdmission:false,sameOuterAdmission:true})+'\n');
const result={scope:'FIXED REPRO supplement, Initiate seed9592029, same frozen89/57 stage queryoff/on. Author-made art/adapter; no independent art/fun approval, primary random300, all10frames, hardwareFPS or cohesive pixel build claim',sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,captureCap:12,perContextCaptureCap:6,actions:[],captures:[],contexts:[],pageErrors:[],browser:'NOT_LAUNCHED',server:'NOT_LAUNCHED',mechanicalPass:false,personallyViewed:false};
let browser,context,page,server,stopReason=null,timer,auditBefore=false,closingPromise=null,closedBrowser=null,closedServer=null,activeCase=null;
const K='hollowpact.run.v2';
const stamp=()=>({utc:new Date().toISOString(),wholeElapsedMs:Date.now()-started});
function log(name,data){fs.appendFileSync(path.join(packet,name),JSON.stringify({...stamp(),...data})+'\n');}
function persist(){fs.writeFileSync(path.join(packet,'VISUAL-PROGRESS.json'),JSON.stringify(result,null,2)+'\n');}
function check(){if(stopReason||Date.now()-started>=90000||result.pageErrors.length)throw Error(stopReason||result.pageErrors[0]||'90s paired driver abort');}
async function hashFile(file){const h=createHash('sha256');let bytes=0;for await(const b of fs.createReadStream(file,{flags:fs.constants.O_RDONLY|fs.constants.O_NOATIME|fs.constants.O_NOFOLLOW,highWaterMark:32768})){check();h.update(b);bytes+=b.length;}return {sha256:h.digest('hex'),bytes};}
async function audit(label){
 const row={label,inputs:[],outputs:[],controls:[]};
 assert.equal((await hashFile(controlsPath)).sha256,hash(controlsBytes),'Control manifest changed');
 for(const entry of controls.bodies){const actual=await hashFile(path.join(path.dirname(controlsPath),entry.name));assert.equal(actual.sha256,entry.sha256,'Driver/caller control changed '+entry.name);row.controls.push({name:entry.name,...actual});}assert.equal(Object.keys(freeze.inputs).length,89);assert.equal(Object.keys(freeze.outputs).length,57);
 for(const [rel,expected] of Object.entries(freeze.inputs)){check();const actual=await hashFile(path.join(stage,rel));assert.equal(actual.sha256,expected,'Input mismatch '+rel);row.inputs.push({path:rel,...actual});}
 for(const [rel,expected] of Object.entries(freeze.outputs)){check();const actual=await hashFile(path.join(stage,'dist',rel));assert.equal(actual.sha256,expected,'Output mismatch '+rel);row.outputs.push({path:rel,...actual});}
 fs.writeFileSync(path.join(packet,`BYTE-AUDIT-${label}.json`),JSON.stringify(row,null,2)+'\n');
}
async function bounded(promise,ms,label){let t;try{return await Promise.race([promise,new Promise((_,reject)=>{t=setTimeout(()=>reject(Error(label+' timeout')),ms);})]);}finally{clearTimeout(t);}}
async function close(reason){
 if(closingPromise)return closingPromise;
 closingPromise=(async()=>{
  log('LIFECYCLE.jsonl',{event:'close initiated',reason});const errors=[],ownedBrowser=browser,ownedServer=server;
  try{if(ownedBrowser){await bounded(ownedBrowser.close(),8000,'browser close');closedBrowser=ownedBrowser;result.browser='CLOSED';}}catch(e){errors.push(String(e));result.browser='CLOSE_UNCONFIRMED';}
  try{if(ownedServer){ownedServer.closeIdleConnections?.();await bounded(new Promise((resolve,reject)=>ownedServer.close(e=>e?reject(e):resolve())),2000,'server close');closedServer=ownedServer;result.server='CLOSED';}}catch(e){errors.push(String(e));result.server='CLOSE_UNCONFIRMED';}
  if(errors.length){result.closeErrors=errors;result.mechanicalPass=false;process.exitCode=2;}
  log('LIFECYCLE.jsonl',{event:errors.length?'close failures':'normal browser and server close',reason,errors});persist();
 })();return closingPromise;
}
function abort(reason){if(stopReason)return;stopReason=reason;result.abortReason=reason;result.mechanicalPass=false;process.exitCode=2;void close(reason).catch(e=>{result.closeFailure=String(e);process.exitCode=2;});}
process.once('SIGTERM',()=>abort('supervisor SIGTERM'));
timer=setTimeout(()=>abort('90s visual driver abort'),Math.max(0,90000-(Date.now()-started)));
async function owned(locator){
 check();await locator.waitFor();
 // Avoid Playwright's stability-based scroll wait on already visible animated
 // actor bodies. Keep the original scoped scroll path for offscreen controls.
 const existing=await locator.boundingBox(),viewport=page.viewportSize();
 const alreadyFullyVisible=existing&&viewport&&existing.width>0&&existing.height>0&&existing.x>=0&&existing.y>=0&&existing.x+existing.width<=viewport.width&&existing.y+existing.height<=viewport.height;
 if(!alreadyFullyVisible)await locator.scrollIntoViewIfNeeded();await settle();
 let b=await locator.boundingBox();assert(b,'Missing pointer box');await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await settle();
 b=await locator.boundingBox();assert(b,'Owner vanished after hover');const point={x:b.x+b.width/2,y:b.y+b.height/2};
 // Move to the final settled coordinate that will actually be pressed. Do not
 // assert/log a recomputed center while leaving the mouse at the prior center.
 await page.mouse.move(point.x,point.y);await settle();
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},point),'Fresh actual pointer owner missing');
 assert(await locator.evaluate(e=>!e.disabled&&e.getAttribute('aria-disabled')!=='true'),'Unavailable control');return point;
}

async function rawSave(){check();return page.evaluate(k=>localStorage.getItem(k),K);}
async function settle(){check();await page.waitForTimeout(220);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));check();}
async function eventsSince(n){return page.evaluate(n=>window.__cueVisualEvents.slice(n),n);}
async function click(locator,label,captureKind=null){
 const p=await owned(locator),before=await rawSave(),n=await page.evaluate(()=>window.__cueVisualEvents.length);
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual press owner changed');
 await page.mouse.down();await page.waitForTimeout(60);check();
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual release owner changed');
 await page.mouse.up();const release=await page.evaluate(()=>performance.now());
 const action={case:activeCase.name,label,point:p,beforeSHA:before===null?null:hash(before),releaseObservedAtMs:release,assertionsPending:true};result.actions.push(action);persist();
 // Real wall waits/screenshots only. Capture intervals do not certify a sprite phase.
 if(captureKind==='bind'){await shot('arrival-requested',release);await waitUntilAfterRelease(release,400);await shot('settled-ready-requested',release);}
 if(captureKind==='command'){await shot('anticipation-requested',release);await waitUntilAfterRelease(release,240);await shot('contact-window-requested',release);await waitUntilAfterRelease(release,430);await shot('recovery-window-requested',release);}
 await settle();const events=await eventsSince(n);action.events=events;action.afterSHA=await rawSave().then(v=>v===null?null:hash(v));persist();
 assert(events.some(e=>e.type==='pointerdown'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1)&&events.some(e=>e.type==='pointerup'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1),'Missing trusted native press/release at actual checked coordinates');
 action.assertionsPending=false;persist();
}
async function key(value,label){
 check();const n=await page.evaluate(()=>window.__cueVisualEvents.length),before=await rawSave();await page.keyboard.press(value);await settle();
 const events=await eventsSince(n);result.actions.push({case:activeCase.name,label,key:value,events,beforeSHA:before===null?null:hash(before),afterSHA:await rawSave().then(v=>v===null?null:hash(v))});persist();
 assert(events.some(e=>e.type==='keydown'&&e.trusted),'Native key event absent');
}
async function waitUntilAfterRelease(release,ms){check();const now=await page.evaluate(()=>performance.now());if(now-release<ms)await page.waitForTimeout(ms-(now-release));check();}
async function shot(label,release=null){
 check();assert(result.captures.length<expected.captureCap&&activeCase.captureCount<expected.perContextCaptureCap,'Declared PNG capture cap exceeded');
 const entry={case:activeCase.name,label,path:path.join(packet,`${activeCase.name}-${String(++activeCase.captureCount).padStart(2,'0')}-${label}.png`),request:stamp(),requestObservedAtMs:await page.evaluate(()=>performance.now()),releaseObservedAtMs:release,phaseCertified:false,pending:true,personallyViewed:false};
 result.captures.push(entry);persist();await page.screenshot({path:entry.path,type:'png',fullPage:false});
 entry.completed=stamp();entry.completedObservedAtMs=await page.evaluate(()=>performance.now());Object.assign(entry,await hashFile(entry.path));entry.pending=false;persist();
}
async function observation(label){
 check();const row=await page.evaluate(()=>{
  const rect=e=>e.getBoundingClientRect().toJSON(),active=document.activeElement;
  return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio,reducedMotion:matchMedia('(prefers-reduced-motion: reduce)').matches},scroll:{x:scrollX,y:scrollY,width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight},active:{id:active?.id,focus:active?.dataset?.focus,uid:active?.dataset?.unit,ui:active?.dataset?.ui},artStatus:document.querySelector('.arena-art-status')?.innerText,dialog:{open:document.querySelector('#dialog')?.open,title:document.querySelector('#dialog-title')?.innerText,text:document.querySelector('#dialog')?.innerText,controls:[...document.querySelectorAll('#dialog [data-ui]')].map(e=>({ui:e.dataset.ui,text:e.innerText}))},selection:{targeting:!!document.querySelector('.battle-guidance.targeting'),unitUIDs:[...document.querySelectorAll('.field-unit.selected')].map(e=>e.dataset.unit),cardIndices:[...document.querySelectorAll('.hand-cards .game-card.selected')].map(e=>e.dataset.index)},preview:{kind:document.querySelector('#consequence-preview')?.dataset.preview,text:document.querySelector('#consequence-preview')?.innerText},cards:[...document.querySelectorAll('.hand-cards .game-card')].map(e=>({cardId:e.dataset.card,index:e.dataset.index,disabled:e.getAttribute('aria-disabled'),text:e.innerText,rect:rect(e)})),actors:[...document.querySelectorAll('.field-actor:not([hidden])')].map(e=>({uid:e.dataset.actor,body:rect(e.querySelector('.field-unit')),disabled:e.querySelector('.field-unit').disabled,identity:e.querySelector('.field-nameplate')?.innerText,intent:e.querySelector('.field-intent')?.innerText,stats:e.querySelector('.field-stat-line')?.innerText,ready:e.querySelector('.field-ready')?.innerText,inspect:rect(e.querySelector('.field-inspect'))}))};
 });activeCase.observations.push({label,...stamp(),row});persist();return row;
}
async function checkpoint(label){
 const raw=await rawSave();assert(raw!==null,'Actual run save absent');const file=path.join(packet,`${activeCase.name}-${label}-OPAQUE-SAVE.json`);
 fs.writeFileSync(file,JSON.stringify({observedOnly:true,raw})+'\n');activeCase.checkpoints[label]={path:file,sha256:hash(raw),raw};persist();return JSON.parse(raw);
}
function unit(name){return page.locator('.field-actor:not([hidden])').filter({has:page.locator('.field-nameplate',{hasText:name})}).locator('.field-unit').first();}
async function runCase(name,query){
 const row={name,query,seed:9592029,classification:'FIXED REPRO supplement',captureCount:0,checkpoints:{},observations:[],context:'NOT_CREATED',completed:false};result.contexts.push(row);activeCase=row;persist();
 let ownedContext;
 try{
  check();ownedContext=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'no-preference'});context=ownedContext;row.context='OPEN';
  await ownedContext.addInitScript(()=>{window.__cueVisualEvents=[];for(const type of ['pointerdown','pointerup','click','focusin','keydown'])window.addEventListener(type,e=>{window.__cueVisualEvents.push({type,trusted:e.isTrusted,observedAtMs:performance.now(),key:e.key,x:e.clientX,y:e.clientY,id:e.target.id,ui:e.target.closest?.('[data-ui]')?.dataset.ui,uid:e.target.closest?.('[data-unit]')?.dataset.unit,card:e.target.closest?.('[data-card]')?.dataset.card,index:e.target.closest?.('[data-card]')?.dataset.index});if(window.__cueVisualEvents.length>1000)window.__cueVisualEvents.splice(0,200);},{capture:true,passive:true});});
  page=await ownedContext.newPage();page.setDefaultTimeout(5000);page.on('pageerror',e=>{result.pageErrors.push(String(e));log('ERRORS.jsonl',{case:name,kind:'pageerror',error:String(e)});});
  await page.goto(`http://127.0.0.1:${port}/${query}`,{waitUntil:'domcontentloaded',timeout:12000});await settle();assert.equal(await rawSave(),null,'Fresh context has a preexisting run');
  await click(page.locator('#scene-ui [data-ui="new"]'),'open ordinary contract');assert(await page.locator('input[name="difficulty"][value="0"]').isChecked(),'Default Initiate missing');
  await click(page.locator('[data-hunt-disclosure="hunt-seed-panel"]'),'ordinary Set a seed disclosure');await click(page.locator('#seed'),'native seed field');
  assert(await page.locator('#seed').evaluate(e=>document.activeElement===e),'Seed field lacks native focus');const typingStart=await page.evaluate(()=>window.__cueVisualEvents.length);
  await page.keyboard.press('Control+A');await page.keyboard.type('9592029',{delay:25});assert.equal(await page.locator('#seed').inputValue(),'9592029');row.seedInputEvents=await eventsSince(typingStart);assert(row.seedInputEvents.some(e=>e.type==='keydown'&&e.trusted&&e.id==='seed'),'Seed lacks native keyboard evidence');persist();
  await click(page.locator('#new-game-form [type="submit"]'),'Accept contract with ordinary typed seed');await page.waitForTimeout(600);await settle();
  let initial=JSON.parse(await rawSave());if(initial.phase==='map'){
   const travel=page.locator('[data-action="travel"]:visible').first();assert(await travel.count(),'No visible ordinary battle route');row.routeText=await travel.innerText();await click(travel,'ordinary first visible battle route');await page.waitForTimeout(600);await settle();
  }
  initial=await checkpoint('C0');assert.equal(initial.seed,9592029);assert.equal(initial.difficulty,0);assert.equal(initial.phase,'battle','No earned battle opening');
  await observation('opening before deliberate card hover/scroll');await shot('opening');
  const card=page.locator('.hand-cards .game-card[data-card="cairnhound"][aria-disabled="false"]').first();assert(await card.count(),'Fixed repro has no actual legal Cairn opportunity; no reroll or fixture');
  row.cardOccurrence={cardId:await card.getAttribute('data-card'),index:await card.getAttribute('data-index')};persist();
  await click(card,'bind actual first legal Cairn occurrence','bind');const bound=await checkpoint('C1');
  const cairn=unit('Cairn Hound');assert(await cairn.count(),'Bound Cairn visible body missing');row.cairnUID=await cairn.getAttribute('data-unit');
  const canonical=bound.allies.find(u=>u.uid===row.cairnUID);assert(canonical&&canonical.cardId==='cairnhound'&&canonical.species==='hound','Observed body/save ownership differs');row.bindingResult={energyBefore:initial.energy,energyAfter:bound.energy,hunterBlockBefore:initial.block,hunterBlockAfter:bound.block,unit:canonical};await observation('earned Cairn arrival/READY');
  const pure=await rawSave();await click(cairn,'select actual Cairn for cancellation');await key('Escape','native selected command cancel');assert.equal(await rawSave(),pure,'Command cancellation changed save');
  await click(page.locator(`.field-inspect[data-uid="${row.cairnUID}"]`),'Inspect actual Cairn UID');assert(await page.locator('#dialog').evaluate(e=>e.open),'Inspect dialog absent');await observation('Cairn Inspect');await key('Escape','dismiss Inspector');assert.equal(await rawSave(),pure,'Inspect changed actual save');
  const thrall=unit('Bone Thrall');assert(await thrall.count(),'Actual Bone Thrall opportunity absent; no invented substitute');row.thrallUID=await thrall.getAttribute('data-unit');persist();
  await click(unit('Cairn Hound'),'select ready actual Cairn for command');await owned(thrall);const preview=await observation('actual Thrall consequence preview');assert.equal(preview.preview.kind,'consequence');assert.equal(await rawSave(),pure,'Target preview changed save');
  await click(thrall,'command actual Cairn into actual Bone Thrall','command');const commanded=await checkpoint('C2');row.commandResult={sourceUID:row.cairnUID,targetUID:row.thrallUID,source:commanded.allies.find(u=>u.uid===row.cairnUID),target:commanded.enemies.find(u=>u.uid===row.thrallUID)??null,log:commanded.log};assert(row.commandResult.source?.acted,'Accepted actual command not recorded');await observation('resolved command');
  const scour=page.locator('.hand-cards .game-card[data-card="scour"][aria-disabled="false"]').first(),remainingThrall=unit('Bone Thrall');
  if(await scour.count()&&await remainingThrall.count()){
   await click(scour,'select actual legal Scour');const target=page.locator(`.field-unit[data-unit="${row.thrallUID}"].valid-target`);
   if(await target.count()){await owned(target);await observation('actual Scour target preview');await click(target,'play actual Scour into surviving Thrall');row.scourPlayed=true;}
   else{row.scourGap='Selected Scour has no actual legal surviving Thrall target';await observation('unexercised Scour selection');if(await page.locator('[data-ui="cancel"]:visible').count())await key('Escape','cancel observed unexercised Scour selection');}
  }else row.scourGap='No actual legal Scour plus surviving visible Thrall; not fabricated.';
  const beforeEnd=await checkpoint('C2S');await observation('before ordinary End turn; actual modal and selection');
  assert(!(await page.locator('#dialog').evaluate(e=>e.open)),'An existing dialog blocks ordinary End turn; observed and preserved');
  if(await page.locator('[data-ui="cancel"]:visible').count()){
   const selectedSave=await rawSave();await key('Escape','cancel observed pending selection before End turn');
   const cancelled=await observation('after observed selection cancellation');assert.equal(await rawSave(),selectedSave,'Selection cancellation changed save');assert(!cancelled.dialog.open,'Selection cancellation unexpectedly opened a dialog');assert.equal(await page.locator('[data-ui="cancel"]:visible').count(),0,'Selection cancellation did not clear actual pending control');
  }
  if(beforeEnd.phase==='battle'){
   await key('e','ordinary native End turn');const ended=await observation('after ordinary End turn or visible confirmation');
   if(ended.dialog.open){
    const confirm=page.locator('[data-ui="confirm-end"]:visible');assert.equal(ended.dialog.title,'Unspent commands remain','Unexpected dialog after ordinary End turn; actual question preserved');assert.equal(await confirm.count(),1,'Actual unspent-command question lacks its ordinary confirmation');
    await click(confirm,'ordinary End turn anyway for observed unspent-command question');await observation('after ordinary unspent-command confirmation');assert(!(await page.locator('#dialog').evaluate(e=>e.open)),'Confirmed End turn left a dialog open');
   }
  }
  await page.waitForTimeout(850);await settle();const response=await checkpoint('C3');assert(beforeEnd.phase!=='battle'||response.phase!=='battle'||response.turn>beforeEnd.turn,'Ordinary End turn did not actually advance');row.response={phase:response.phase,turn:response.turn,hp:response.hp,block:response.block,allies:response.allies,enemies:response.enemies,log:response.log};await observation('actual enemy response or terminal');
  const beforeMotion=await rawSave();await page.emulateMedia({reducedMotion:'reduce'});await settle();const motion=await observation('native reduced-motion preference');assert(motion.viewport.reducedMotion);assert.equal(await rawSave(),beforeMotion,'Native reduced preference changed canonical save');
  const ready=unit('Cairn Hound');if(await ready.count()){
   await owned(ready);await observation('reduced-motion actual Cairn hover');assert.equal(await rawSave(),beforeMotion,'Reduced hover changed save');
   if(response.phase==='battle'&&await ready.evaluate(e=>e.classList.contains('ready')&&!e.disabled)){
    await click(ready,'select actual ready Cairn under reduced motion');await observation('reduced-motion actual pending command');assert.equal(await ready.getAttribute('aria-pressed'),'true','Reduced-motion Cairn command was not actually selected');assert.equal(await page.locator('[data-ui="cancel"]:visible').count(),1,'Reduced-motion selected command has no actual Cancel control');assert.equal(await rawSave(),beforeMotion,'Reduced selection changed save');
    await key('Escape','reduced-motion observed selected-command cancel');const cancelled=await observation('reduced-motion command cancelled');assert(!cancelled.dialog.open,'Reduced selected-command cancellation opened a dialog');assert.equal(await page.locator('[data-ui="cancel"]:visible').count(),0,'Reduced selected-command cancellation did not clear selection');assert.equal(await rawSave(),beforeMotion,'Reduced selected-command cancel changed save');row.reducedSelectedCancel=true;
   }else row.reducedCancelGap='No actual enabled READY Cairn in battle; hover observed, selected cancellation not claimed.';
  }else row.reducedCancelGap='No visible Cairn after actual response; reduced selected cancellation not claimed.';
  const beforeReload=await rawSave();await page.reload({waitUntil:'domcontentloaded',timeout:12000});await settle();assert.equal(await rawSave(),beforeReload,'Reload changed actual save');await click(page.locator('#scene-ui [data-ui="resume"]'),'ordinary Continue of this earned run');assert.equal(await rawSave(),beforeReload,'Continue changed actual save');await observation('ordinary reload/Continue');await checkpoint('C4');row.completed=true;persist();
 }catch(e){row.failure=e.stack;persist();throw e;}
 finally{
  if(ownedContext){try{await bounded(ownedContext.close(),4000,'case context close');row.context='CLOSED';}catch(e){row.context='CLOSE_UNCONFIRMED';row.closeFailure=String(e);process.exitCode=2;throw e;}finally{persist();}}
 }
}

try{
 await audit('before');auditBefore=true;check();const keys=Object.keys(freeze.outputs).sort();
 server=http.createServer((req,res)=>{try{const pathname=new URL(req.url,'http://localhost').pathname,key=pathname==='/'?'index.html':decodeURIComponent(pathname.slice(1));if(!keys.includes(key)){res.writeHead(404);res.end('Not found');return;}res.setHeader('Content-Type',key.endsWith('.html')?'text/html':key.endsWith('.js')?'text/javascript':key.endsWith('.css')?'text/css':key.endsWith('.png')?'image/png':key.endsWith('.json')?'application/json':'application/octet-stream');const stream=fs.createReadStream(path.join(stage,'dist',key));stream.on('error',()=>res.destroy());stream.pipe(res);}catch{res.writeHead(400);res.end('Bad request');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});result.server='OPEN';
 const served=[];for(const rel of keys){check();const response=await fetch(`http://127.0.0.1:${port}/${rel.split('/').map(encodeURIComponent).join('/')}`,{signal:AbortSignal.timeout(8000)});assert(response.ok,'Serve failed '+rel);const h=createHash('sha256');let bytes=0;for await(const b of response.body){check();h.update(b);bytes+=b.length;}const sha256=h.digest('hex');assert.equal(sha256,freeze.outputs[rel],'Served mismatch '+rel);served.push({path:rel,bytes,sha256});}
 fs.writeFileSync(path.join(packet,'SERVED-BYTE-AUDIT.json'),JSON.stringify({sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,served},null,2)+'\n');

 check();browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox'],timeout:12000});result.browser='OPEN';check();
 await runCase('A-current','');assert.equal(result.contexts[0].context,'CLOSED');
 await runCase('B-pixel','?pixelCairn=1');assert.equal(result.contexts[1].context,'CLOSED');
 const [a,b]=result.contexts;result.canonicalComparisons=[];
 for(const label of ['C0','C1','C2','C2S','C3','C4']){const same=a.checkpoints[label].raw===b.checkpoints[label].raw;result.canonicalComparisons.push({label,aSHA:a.checkpoints[label].sha256,bSHA:b.checkpoints[label].sha256,byteEqual:same});persist();assert(same,'Matched actual canonical save differs at '+label);}
 assert.equal(a.cairnUID,b.cairnUID);assert.equal(a.thrallUID,b.thrallUID);assert.deepEqual(a.cardOccurrence,b.cardOccurrence);assert.equal(!!a.scourPlayed,!!b.scourPlayed);
 result.completed=true;result.mechanicalPass=true;persist();
}catch(e){result.failure=e.stack;result.mechanicalPass=false;process.exitCode=2;log('FAILURE.jsonl',{error:String(e)});}
finally{
 await close(stopReason||'paired actual checks completed or failed');
 if(browser&&browser!==closedBrowser||server&&server!==closedServer){closingPromise=null;await close('final late-created or unconfirmed resource cleanup');}
 if(auditBefore&&!stopReason){try{await audit('after');}catch(e){result.afterAuditFailure=e.stack;result.mechanicalPass=false;process.exitCode=2;}}
 clearTimeout(timer);result.wholeElapsedMs=Date.now()-started;if(stopReason){result.mechanicalPass=false;process.exitCode=2;}
 fs.writeFileSync(path.join(packet,'VISUAL-RESULT.json'),JSON.stringify(result,null,2)+'\n');
 // Only owned proof outputs are fsynced; no source/stage/archive write.
 for(const name of fs.readdirSync(packet)){const file=path.join(packet,name);if(fs.statSync(file).isFile()){const fd=fs.openSync(file,fs.constants.O_RDONLY);try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}}
 const dirfd=fs.openSync(packet,fs.constants.O_RDONLY);try{fs.fsyncSync(dirfd);}finally{fs.closeSync(dirfd);}
 console.log(JSON.stringify({browser:result.browser,server:result.server,completed:result.completed,mechanicalPass:result.mechanicalPass,captures:result.captures.length,contexts:result.contexts.map(x=>({name:x.name,context:x.context,completed:x.completed})),wholeElapsedMs:result.wholeElapsedMs,failure:result.failure?.split('\n')[0],abortReason:stopReason}));
}
