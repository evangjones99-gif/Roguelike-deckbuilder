import os,json,hashlib,shutil,time
from pathlib import Path
base=Path('/workspace/scratch/first-five-opening-row-navigation-stage-r6');stage=Path('/workspace/scratch/first-five-opening-preview-identity-stage-r7');author=Path('/workspace/scratch/preview-identity-concise-root-r2/candidate')
freeze=json.loads(Path('/workspace/scratch/first-five-opening-row-navigation-runtime-freeze-root-r6.json').read_text())
def digest(p):
    h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
    try:
        s=os.fstat(fd)
        while b:=os.read(fd,65536):h.update(b)
        assert os.fstat(fd)==s
    finally:os.close(fd)
    return h.hexdigest()
assert freeze['sourceDigest']=='93162336479c7affb874164fc59136c655fae7e5f793b70afbbba4888fe1fcfb'
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h,rel
replacements={'src/engine.ts':'7dca47973c0d78a130730450215569fa7747a1cb043764b16217c1b9c0ce6bf8','src/main.ts':'b56e5a6a931c3780f160aee19fd550a27d45a700217f933c8d1e8be8bf897cc4'}
for rel,h in replacements.items():assert digest(author/rel)==h
stage.mkdir(mode=0o700)
for current,names,files in os.walk(base,followlinks=False):
    names[:]=[n for n in names if n not in ['dist','node_modules','public']]
    for name in names:assert not (Path(current)/name).is_symlink()
    for name in files:
        source=Path(current)/name;assert not source.is_symlink()
        rel=source.relative_to(base).as_posix();target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
        source=author/rel if rel in replacements else source
        fd=os.open(source,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
        try:
            with target.open('xb') as f:
                while b:=os.read(fd,65536):f.write(b)
                f.flush();os.fsync(f.fileno())
        finally:os.close(fd)
(stage/'public').symlink_to(base.joinpath('public').resolve(),target_is_directory=True)
(stage/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules',target_is_directory=True)
fixture='reviews/world-rng-v0.5/golden-vectors-r1.json'
fixture_source=Path('/workspace/Roguelike-deckbuilder')/fixture
fixture_target=stage/fixture;fixture_target.parent.mkdir(parents=True,exist_ok=True)
assert not fixture_target.exists();shutil.copyfile(fixture_source,fixture_target);assert digest(fixture_source)==digest(fixture_target)
inputs={**freeze['inputs'],**replacements}
for rel,h in inputs.items():assert digest(stage/rel)==h
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h
record={'stage':str(stage),'status':'PREVIEW IDENTITY R7 STAGED; UNBUILT; UNPROMOTED','baselineStage':str(base),'baselineSourceDigest':freeze['sourceDigest'],'inputs':dict(sorted(inputs.items())),'inputCount':len(inputs),'sourceDigest':hashlib.sha256(json.dumps(dict(sorted(inputs.items())),separators=(',',':')).encode()).hexdigest(),'onlyChangedInputs':list(replacements),'sharedPublicRoot':str(base.joinpath('public').resolve()),'baselineUnchanged':True,'limitations':'No new playable/brower/human-fun/art/release acceptance.'}
p=Path('/workspace/scratch/first-five-opening-preview-identity-assembly-root-r7.json')
with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
for folder in [stage,stage.parent]:fd=os.open(folder,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({k:v for k,v in record.items() if k!='inputs'}))
