# Cairn paired trial: failed A-current phase, pixel comparison withheld

The ONE authorized attempt FAILED before its pixel context. All six retained lossless1440×900 PNGs from A-current were personally inspected. Browser, server and A-current context are CLOSED; the exclusive live window was released before image/report work. No actual retry, caller/game/stage edit, promotion or new version occurred. Pixel quality and queryoff/on canonical/visual equality remain WITHHELD.

Exact frozen source89/de9396b89376f413a7a262c80b7a0eeef3eb57d726ec313d61e0d76988f7cabe; outputs57/1d3843b68753353e9836593e1ed3d779e6d2326eb35c27c479609f2256e33011. Stage /workspace/scratch/first-five-opening-cairn-pixel-stage-r5, freeze19e2ef17bd7c592d5e7c025a9d10efe3e89ac21d908376348dd757e2931c3de5. The exact declared CLI used new actual-r1-phase1 and port4814. Source manifest762f794cafda176ceb06c94cb714ae169a3acb9bcd92e8bd37b664223a6ce867, driver412278458cfdde0a3ed1284f9359067ac856ab697dc23276aadcc4602f41ed5a, supervisoreab0b2d3a8e776131a55aed6e62cd09d25fa122ff40b1f9b40ad5252431e1afa.

## Result and owned closure

Fresh admission1965953024B headroom passed unchanged896MiB TOTAL work plus512MiB reserve/heap256/driver90s/whole120s. Driver exit2, outer76, whole21.075089582s. All110 recorded samples, final resource values, fixed maximum, memory events and lifecycle checks independently pass; peak delta740163584B, minimum sampled headroom1225789440B. driver_rc0 is the sole false check. normal_wait=false records driver failure, while browser/server normal close at20.247s has errors[]. Eleven scoped process identities were recorded, no tracked live descendants remain. PPID1 zombies457493/start8345668 and457496/start8345669 remain nonlive/unreaped. No universal process-absence claim.

Before/after89source/57output maps match the freeze;57 streamed served outputs match. Eight caller control maps match before/after and original bodies. Raw actual bodies, six personally viewed PNGs and complete-wrapper versus opaque-raw checkpoint hashes are pinned in INDEPENDENT-RECEIPTS.json. Ordinary interpreter/browser/image-view atime effects are qualified; direct reads used O_NOATIME. No source, asset, public or preexisting evidence file was edited.

## Concrete caller sequencing defect

After Scour completed, caller147 unconditionally sent Escape ('clear any optional selection'). Retained trusted events show focus move to dialog-title with canonical save unchanged. Its following native e occurred at dialog-title and also left the same save. Caller150 then asserted the open dialog must contain confirm-end and threw 'Unexpected dialog after ordinary End turn'.

Exact frozen main.ts237–242 makes Escape open Pause when no selection exists;1224 ignores other shortcuts while a dialog is open. Scour had already completed and returned focus to Survey. The caller therefore opened Pause itself before requesting End turn. This is a caller defect, not proof that game End turn rejected an input. There is no failure-dialog screenshot; its raw input/focus/save sequence and exact source support this diagnosis. Preserve the caller and failed evidence. A future caller should cancel only an actually selected target state and verify its resulting dialog before End turn. Any further actual attempt requires a separately sealed source gate and Root grant.

A separate report-preparation assertion initially confused the checkpoint wrapper file with its embedded opaque save and failed before writing this packet. The correction checks wrapper.raw against the recorded raw and preserves both hashes. This source-only verification correction did not rerun gameplay.

## Partial actual evidence

The fixed reproduction used ordinary UI-entered seed9592029 on Initiate, supplementing the prior R3 draw rather than a primary random300s opening. Actual Cairn occurrence index4 binds discovered UIDa3; the target Bone Thrall is discovered UIDe2. No fixture, engine import or private state edit was used.

C0→C1 shows one Cairn7HP/3Attack/unacted, hunter block0→2, energy5→4. Native selected-command Escape and Inspect/Escape preserve C1 bytes. The command gives C2: Cairn acted and Thrall7→2HP, consistent with5-damage preview. Scour gives C2S: Thrall removed, energy4→3, Scour in discard. No C3 enemy response, C4 reload/Continue, reduced-motion step or B-pixel context was reached. Paired outcomes/UID/checkpoint equality cannot be asserted.

## All six original PNGs inspected

01-opening shows Help/HUD, five complete cards, rules/stats and End turn within900px. The separate first-bind instruction survives Survey consequence guidance. Pointer position left by contract acceptance also hovers and raises Scour; this is not a pointer-neutral composition. Named readouts show Guard4 Self and Claw3 → Hunter. No essential hand/readout text is visibly clipped.

02-arrival-requested shows a binding mark/hunter gesture before a clear hound body, while its readout already says Ready.03-settled-ready-requested shows the painted hound at the near slot. This actual label/body ordering is worth watching for first-binding identity payoff, but it establishes neither a pixel arrival nor an invalid-input defect.

04-anticipation-requested shows the hound near its origin and strike arc after targetHP already became2/Command spent.05-contact-window-requested shows the hound displaced near the Thrall;06-recovery-window-requested shows it back at the source. No readout/card overlap or cropped essential text is apparent. The guidance strip describes Survey while the strike is visible, leaving completed-action attribution to source/target labels and the effect. The hunter remains small.

Requested filenames are NOT certified animation phases. Command requests are4.1ms/328.1ms/585.5ms after observed release; screenshot completions are299.5ms/581ms/855.3ms after it. Latency may miss or straddle cels. These static images cannot prove motion continuity, impact synchronization, responsiveness, all10 poses or death. Every retained image is painterly A-current; none establishes the new pixel anatomy in live composition.

Decision: retain this partial functional/visible evidence; reject this attempt as a completed paired gate and withhold pixel/art promotion. No human enjoyment, AAA, hardware performance or franchise judgment is supplied.
