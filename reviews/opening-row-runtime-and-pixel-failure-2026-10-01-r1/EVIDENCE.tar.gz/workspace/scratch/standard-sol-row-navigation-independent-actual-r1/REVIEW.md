# Independent actual row-navigation comparison: R5 baseline versus R6

Decision: ACCEPT the tested R6 row-navigation repair for this sparse opening. Baseline's actual negative control moves Right from Cairn to Ironjaw in the enemy row. R6 moves Right to Fen in the allied row and Left back to Cairn. Native row changes, Tab, genuine target selection/cancellation and modal ownership remain usable without changing the canonical save. This is scoped actual acceptance, not whole-game promotion, dense-field acceptance or a human-fun verdict.

Both phases were explicitly granted separately, executed once with the same sealed caller, separately freshly admitted, and normally CLOSED before any next browser phase. All12 original1440×900 JPEGs were personally inspected. No stage/source/public edit, fixture, engine import, storage injection, forced input or automatic retry occurred. Query/pixel trial is separate and remains withheld after its earlier failed A-only attempt.

## Exact matching cases

Literal caller /workspace/scratch/standard-sol-row-navigation-caller-author-r1: manifestecd7edfa6da867d192900dedd6dc5c83650cbc430352c6543b6d48a5470be1d2, driver3678cefa75f93375a4a37b1a9a3bf0e2b805f6b9f3e5c2e50e388a560c061cb8, supervisor6a502636bbad889ac25b9e999f4c247b31a85ab1a48b46d22b2a48c16abb0892. Baseline used declared new actual-baseline-r1/port4809; candidate used separately granted declared new actual-candidate-r1/port4810. The first source read guessed a nonexistent filename and failed before launch/write; the declared filenames were then verified, without a runtime retry.

R5 source87/3e4e518b9e46717c4be830448e9dbbe860f1fefca88fd3589bf918df22a95bd7 and outputs56/f56c608267547c968dfe2b298e61384d2be23e4c717f812bafb476f0a7cdee6c. R6 source87/93162336479c7affb874164fc59136c655fae7e5f793b70afbbba4888fe1fcfb and outputs56/194d2e32186f6eab3cd33a2c798358e081c03e96af6f0e1c51a289ebe4e5e060. Each before/after source/output receipt matches its freeze, and all56 streamed served outputs match. The exact final frozen paths/hashes, raw body pins and caller hashes are retained in INDEPENDENT-RECEIPTS.json.

Each fresh1440×900/DPR1 context took the ordinary Set a seed UI, typed9845209 and accepted default Initiate once. Both actual initial hands are Cairn/Fen/Sunder/Sutures/Survey; identical uninjured enemies are Ironjaw16HP and Gloam15HP. Actual native clicks bind Cairn7HP/3Attack (UIDa3), then Fen10HP/4Attack (UIDa4), energy5→4→2 and hunter block0→2. B after the first binding establishes remembered Cairn. The initial saved state, bind-result hashes, all corresponding later action-save hashes and final opaque save bytes are exactly equal across phases; final SHA c59b37c436983fbf9c69c7370de029fb9260fca35386c511725469d9658eb936.

This reproduces the primary R5 B→Right navigation defect with a shorter history: both commands are still Ready and Gloam is undamaged. The primary13-focus-fen occurred after Cairn had spent its command and Gloam was damaged. The supplement is not a private reconstruction of that later state or a random primary300s run.

## Actual navigation and input result

| Native path | R5 actual | R6 actual |
| --- | --- | --- |
| B then Right from Cairn | Ironjaw e1, enemy row | Fen a4, allied row |
| Left | Cairn a3 | Cairn a3 |
| Up from Cairn | Fen a4 | Ironjaw e1 |
| Down after Up | Cairn a3 | Remembered Cairn a3 |
| Down again | Fen a4 | Hand card0, Sunder |
| Up from that focus | Cairn a3 | Remembered Cairn a3 |

The gold focus outline in each03-B-Right-actual-focus image visibly owns the corresponding actor, corroborating the activeElement/ARIA/event receipts. All recorded native key actions have trusted keydown evidence and savePure results. Native Tab reaches Cairn Inspect instead of being trapped by arrow handling. B restores Cairn, Enter genuinely selects its command, T chooses legal hostile focus, Right reaches Gloam and Left reaches Ironjaw. Preview reports5 health damage; Escape removes selection and returns Cairn Ready with identical saved bytes. No command is committed here, so this is actual preview/navigation evidence, not a new reducer/damage-resolution oracle.

Help is opened through an owned native click. B, ArrowDown and Tab remain inside the actual open dialog. Native Escape closes it and returns focus to the Help control. Optional Help and targeting do not change the saved state. Composition is explicitly UNEXERCISED because no native IME is available. Settling is OBSERVATION ONLY: the actual post-bind observation sees disabled actor controls, but this test does not inject or force a busy gate.

## Personal visual judgment

Opening, two-binding, target-preview and cancellation images retain complete named readouts, essential HP/Attack/Ready/intent numbers and targets, full card rules/stats, Help, End turn and footer within the captured900px height. In R6 the visible Right focus lands beside Cairn on Fen, matching the visual allied row. Target preview shows selected source and both legal targets while preserving the hand. Cancellation visibly removes target mode and restores Cairn's focus. Neither phase introduces apparent clipped text or field/hand overlap in these sparse frames. No new font-size or document-height measurement was collected by this caller; image fit is the scope.

Both Help images show the full manual and action button inside the viewport, with no clipped instructions. Help still documents generic arrows and H/B/T groups rather than the new row directions; explicit Up/Down row hints could make the change discoverable, but this test does not establish that users need them. The target strip still uses ordinal hostile1/2; users must connect it to the named field labels. The small hunter/large empty center and painterly anatomy concerns remain unchanged. This navigation correction does not accept the art or animation quality.

## Resource and closure verification

Unchanged per phase896MiB TOTAL work plus512MiB reserve, heap256, driver90s/whole120s and110/115/119 cleanup deadlines. R5 fresh headroom1948274688B,100 samples, peak delta735358976B/minimum headroom1212915712B, normal browser/serverclose18.216s, supervisor whole19.122993848s. R6 fresh headroom1946718208B,99 samples, peak delta737423360B/minimum headroom1209294848B, normal browser/serverclose18.213s, supervisor whole19.037523698s. All sampled rows/final values/fixed maxima/events/seven checks independently verified; driver and outer exits0, normal_wait=true, no cleanup errors.

Each phase records11 scoped owned identities and no tracked live descendants after close. R5 retains PPID1 nonlive/unreaped zombies457929/457930, start8388048; R6 retains458088/start8394358 and458090/start8394359. This is scoped ownership evidence, not universal unrelated-process absence. Ordinary browser/interpreter/view_image atime effects are qualified; exact body hashes were verified by O_NOATIME reads. Both browser/server phases and all reviewer tools are CLOSED.

Still unassessed: dense/mixed six-slot geometry, removed/terminal actors, fallback/resize, native IME, full busy-event rejection, long or overflowing keyboard previews, committed command/End turn, reload, reduced motion and drag. Earlier accepted/failed evidence is preserved separately. No further browser attempt or whole-game/first300fun claim follows from this supplement.
