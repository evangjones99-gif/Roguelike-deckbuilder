// UNEXECUTED focused fixed-UI-seed row navigation comparison. Separate ROOT grants required.
// Uses a separately reviewed narrow R8 supervisor; no baseline gate is borrowed.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/playwright-core/index.mjs';

const [stage,freezePath,packet,portText]=process.argv.slice(2),port=Number(portText),started=Date.now();
// A single separately reviewed literal parameter file will name ROOT's repaired
// candidate. Pending parameters fail before any server/browser is launched.
const phase=stage==='/workspace/scratch/first-five-opening-pc-drag-viewport-stage-r5'?'baseline':'candidate';
const expected=JSON.parse(fs.readFileSync('/workspace/scratch/standard-sol-row-navigation-caller-author-r1/EXPECTED-'+phase.toUpperCase()+'.json'));
assert.equal(expected.status,'FROZEN_FOR_REVIEW','Repaired candidate freeze has not been supplied/reviewed');
assert.equal(stage,expected.stage);assert.equal(freezePath,expected.freezePath);
assert(packet?.startsWith('/workspace/scratch/standard-sol-row-navigation-actual-'));
assert(Number.isInteger(port)&&port>1024&&port<65536);
const hash=b=>createHash('sha256').update(b).digest('hex');
const freezeBytes=fs.readFileSync(freezePath),freeze=JSON.parse(freezeBytes);
assert.equal(hash(freezeBytes),expected.freezeSHA256);
assert.equal(freeze.stage,stage);
assert.equal(freeze.sourceDigest,expected.sourceDigest);
assert.equal(freeze.outputsDigest,expected.outputsDigest);
assert.equal(freeze.inputCount,87);assert.equal(freeze.outputCount,56);
const admission=JSON.parse(fs.readFileSync(path.join(packet,'ADMISSION.json'))),work=896*1048576,reserve=512*1048576;
const current=Number(fs.readFileSync('/sys/fs/cgroup/memory.current','utf8')),maximum=Number(fs.readFileSync('/sys/fs/cgroup/memory.max','utf8'));
const spent=Math.max(0,current-admission.initial.current);
assert(admission.admitted===true&&admission.stage===stage&&admission.freeze===freezePath&&admission.work===work&&admission.reserve===reserve&&admission.initial.maximum===maximum&&admission.initial.headroom>=work+reserve&&spent<=work&&maximum-current>=reserve+Math.max(0,work-spent),'Same outer896+512 accounting rejected');
fs.writeFileSync(path.join(packet,'INSIDE-PHASE-ACCOUNTING.json'),JSON.stringify({work,reserve,current,maximum,spent,remaining:Math.max(0,work-spent),freshAdmission:false,sameOuterAdmission:true})+'\n');
const result={scope:'Focused fixed UI seed9845209 default Initiate navigation supplement; fresh1440x900/DPR1; no human fun, engine imports, saved-state injection, reroll, pixel integration or whole-game acceptance',sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,phase,seed:9845209,actions:[],captures:[],navigationObservations:[],gates:{composition:'UNEXERCISED: no native IME provided; no synthetic composition events',settling:'OBSERVATION_ONLY: no forced settling state or earned terminal action'},browser:'NOT_LAUNCHED',server:'NOT_LAUNCHED',mechanicalPass:false,personallyViewed:false};
let browser,context,page,server,stopReason=null,timer,auditBefore=false,closingPromise=null,closedBrowser=null,closedServer=null;
const K='hollowpact.run.v2',expectedCue='Bind your first creature. Click or drag a BINDING card.';
const stamp=()=>({utc:new Date().toISOString(),wholeElapsedMs:Date.now()-started});
function log(name,data){fs.appendFileSync(path.join(packet,name),JSON.stringify({...stamp(),...data})+'\n');}
function persist(){fs.writeFileSync(path.join(packet,'VISUAL-PROGRESS.json'),JSON.stringify(result,null,2)+'\n');}
function check(){if(stopReason||Date.now()-started>=90000)throw Error(stopReason||'90s visual driver abort');}
async function hashFile(file){const h=createHash('sha256');let bytes=0;for await(const b of fs.createReadStream(file,{flags:fs.constants.O_RDONLY|fs.constants.O_NOATIME|fs.constants.O_NOFOLLOW,highWaterMark:32768})){check();h.update(b);bytes+=b.length;}return {sha256:h.digest('hex'),bytes};}
async function audit(label){
 const row={label,inputs:[],outputs:[]};assert.equal(Object.keys(freeze.inputs).length,87);assert.equal(Object.keys(freeze.outputs).length,56);
 for(const [rel,expected] of Object.entries(freeze.inputs)){check();const actual=await hashFile(path.join(stage,rel));assert.equal(actual.sha256,expected,'Input mismatch '+rel);row.inputs.push({path:rel,...actual});}
 for(const [rel,expected] of Object.entries(freeze.outputs)){check();const actual=await hashFile(path.join(stage,'dist',rel));assert.equal(actual.sha256,expected,'Output mismatch '+rel);row.outputs.push({path:rel,...actual});}
 fs.writeFileSync(path.join(packet,`BYTE-AUDIT-${label}.json`),JSON.stringify(row,null,2)+'\n');
}
async function bounded(promise,ms,label){let t;try{return await Promise.race([promise,new Promise((_,reject)=>{t=setTimeout(()=>reject(Error(label+' timeout')),ms);})]);}finally{clearTimeout(t);}}
async function close(reason){
 if(closingPromise)return closingPromise;
 closingPromise=(async()=>{
  log('LIFECYCLE.jsonl',{event:'close initiated',reason});const errors=[],ownedBrowser=browser,ownedServer=server;
  try{if(ownedBrowser){await bounded(ownedBrowser.close(),8000,'browser close');closedBrowser=ownedBrowser;result.browser='CLOSED';}}catch(e){errors.push(String(e));result.browser='CLOSE_UNCONFIRMED';}
  try{if(ownedServer){ownedServer.closeIdleConnections?.();await bounded(new Promise((resolve,reject)=>ownedServer.close(e=>e?reject(e):resolve())),2000,'server close');closedServer=ownedServer;result.server='CLOSED';}}catch(e){errors.push(String(e));result.server='CLOSE_UNCONFIRMED';}
  if(errors.length){result.closeErrors=errors;result.mechanicalPass=false;process.exitCode=2;}
  log('LIFECYCLE.jsonl',{event:errors.length?'close failures':'normal browser and server close',reason,errors});persist();
 })();return closingPromise;
}
function abort(reason){if(stopReason)return;stopReason=reason;result.abortReason=reason;result.mechanicalPass=false;process.exitCode=2;void close(reason).catch(e=>{result.closeFailure=String(e);process.exitCode=2;});}
process.once('SIGTERM',()=>abort('supervisor SIGTERM'));
timer=setTimeout(()=>abort('90s visual driver abort'),Math.max(0,90000-(Date.now()-started)));
async function rawSave(){check();return page.evaluate(k=>localStorage.getItem(k),K);}
async function settle(){check();await page.waitForTimeout(220);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));check();}
async function owned(locator){
 check();await locator.waitFor();
 // Avoid Playwright's stability-based scroll wait on already visible animated
 // actor bodies. Keep the original scoped scroll path for offscreen controls.
 const existing=await locator.boundingBox(),viewport=page.viewportSize();
 const alreadyFullyVisible=existing&&viewport&&existing.width>0&&existing.height>0&&existing.x>=0&&existing.y>=0&&existing.x+existing.width<=viewport.width&&existing.y+existing.height<=viewport.height;
 if(!alreadyFullyVisible)await locator.scrollIntoViewIfNeeded();await settle();
 let b=await locator.boundingBox();assert(b,'Missing pointer box');await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await settle();
 b=await locator.boundingBox();assert(b,'Owner vanished after hover');const point={x:b.x+b.width/2,y:b.y+b.height/2};
 // Move to the final settled coordinate that will actually be pressed. Do not
 // assert/log a recomputed center while leaving the mouse at the prior center.
 await page.mouse.move(point.x,point.y);await settle();
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},point),'Fresh actual pointer owner missing');
 assert(await locator.evaluate(e=>!e.disabled&&e.getAttribute('aria-disabled')!=='true'),'Unavailable control');return point;
}
async function click(locator,label){
 const p=await owned(locator),before=await rawSave(),n=await page.evaluate(()=>window.__cueVisualEvents.length);
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual press owner changed');await page.mouse.down();await page.waitForTimeout(60);check();assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual release owner changed');
 await page.mouse.up();await settle();const events=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);assert(events.some(e=>e.type==='pointerdown'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1)&&events.some(e=>e.type==='pointerup'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1),'Missing trusted native press/release at actual checked coordinates');
 result.actions.push({label,point:p,beforeSHA:before===null?null:hash(before),afterSHA:await rawSave().then(v=>v===null?null:hash(v)),events});persist();
}
async function shot(label){
 check();assert(result.captures.length<6,'Capture cap exceeded');const file=path.join(packet,`${String(result.captures.length+1).padStart(2,'0')}-${label}.jpg`);await page.screenshot({path:file,type:'jpeg',quality:78});result.captures.push({label,path:file,...await hashFile(file),personallyViewed:false});persist();
}
try{
 await audit('before');auditBefore=true;check();const keys=Object.keys(freeze.outputs).sort();
 server=http.createServer((req,res)=>{try{const pathname=new URL(req.url,'http://localhost').pathname,key=pathname==='/'?'index.html':decodeURIComponent(pathname.slice(1));if(!keys.includes(key)){res.writeHead(404);res.end('Not found');return;}res.setHeader('Content-Type',key.endsWith('.html')?'text/html':key.endsWith('.js')?'text/javascript':key.endsWith('.css')?'text/css':key.endsWith('.png')?'image/png':key.endsWith('.json')?'application/json':'application/octet-stream');const stream=fs.createReadStream(path.join(stage,'dist',key));stream.on('error',()=>res.destroy());stream.pipe(res);}catch{res.writeHead(400);res.end('Bad request');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});result.server='OPEN';
 const served=[];for(const rel of keys){check();const response=await fetch(`http://127.0.0.1:${port}/${rel.split('/').map(encodeURIComponent).join('/')}`,{signal:AbortSignal.timeout(8000)});assert(response.ok,'Serve failed '+rel);const h=createHash('sha256');let bytes=0;for await(const b of response.body){check();h.update(b);bytes+=b.length;}const sha256=h.digest('hex');assert.equal(sha256,freeze.outputs[rel],'Served mismatch '+rel);served.push({path:rel,bytes,sha256});}
 fs.writeFileSync(path.join(packet,'SERVED-BYTE-AUDIT.json'),JSON.stringify({sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,served},null,2)+'\n');
 check();browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox'],timeout:12000});result.browser='OPEN';check();
 context=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'no-preference'});
 // Passive pre-app WINDOW capture sees handled drag Escape before the game
 // stops propagation there; it never prevents, stops or dispatches any input.
 await context.addInitScript(()=>{window.__cueVisualEvents=[];for(const type of ['pointerdown','pointerup','click','focusin','keydown'])window.addEventListener(type,e=>{const card=e.target.closest?.('.hand-cards .game-card');
 // This listener was installed before application handlers. Native pointerdown
 // reads the exact then-visible rect, before tactile-pressed changes transforms.
 const pointerdownSource=type==='pointerdown'&&card?{rect:card.getBoundingClientRect().toJSON(),offsetWidth:card.offsetWidth,offsetHeight:card.offsetHeight,computedWidth:getComputedStyle(card).width,computedHeight:getComputedStyle(card).height,transform:getComputedStyle(card).transform}:undefined;
 window.__cueVisualEvents.push({type,trusted:e.isTrusted,observedAtMs:performance.now(),key:e.key,x:e.clientX,y:e.clientY,ui:e.target.closest?.('[data-ui]')?.dataset.ui,card:e.target.closest?.('[data-card]')?.dataset.card,index:e.target.closest?.('[data-card]')?.dataset.index,pointerdownSource});if(window.__cueVisualEvents.length>1000)window.__cueVisualEvents.splice(0,200);},{capture:true,passive:true});});
 page=await context.newPage();page.setDefaultTimeout(5000);page.on('pageerror',e=>log('ERRORS.jsonl',{kind:'pageerror',error:String(e)}));
// Ordinary DOM/save observation only. No exposed engine/reducer or private adapter calls.
async function observe(label){
 check();const row=await page.evaluate(()=>{
  const a=document.activeElement,d=document.querySelector('#dialog'),preview=document.querySelector('#consequence-preview');
  const describe=e=>({unit:e.dataset.unit,focus:e.dataset.focus,card:e.dataset.card,ui:e.dataset.ui,aria:e.getAttribute('aria-label'),disabled:e.disabled,side:e.matches('.ally')?'ally':e.matches('.enemy')?'enemy':null});
  return {active:a?describe(a):null,dialogOpen:d.open,activeInDialog:!!a&&d.contains(a),settlingCombat:document.querySelector('#app').classList.contains('settling-combat'),preview:preview?{kind:preview.dataset.preview,text:preview.innerText}:null,selected:[...document.querySelectorAll('.field-unit.selected')].map(describe),legalTargets:[...document.querySelectorAll('.field-unit.valid-target:not(:disabled)')].map(describe),hand:[...document.querySelectorAll('.hand-cards .game-card')].map(describe),actors:[...document.querySelectorAll('.field-unit')].map(e=>({...describe(e),rect:e.getBoundingClientRect().toJSON()})),hint:document.querySelector('.keyboard-hint')?.innerText};
 });result.navigationObservations.push({label,...stamp(),...row});persist();return row;
}
async function key(keyText,label){
 check();assert(result.actions.length<40,'Focused action cap exceeded');const before=await rawSave(),n=await page.evaluate(()=>window.__cueVisualEvents.length);
 await page.keyboard.press(keyText);await settle();const events=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);
 assert(events.some(e=>e.type==='keydown'&&e.trusted&&e.key.toLowerCase()===(keyText==='Shift+Tab'?'tab':keyText.toLowerCase())),'Missing trusted key '+keyText);
 assert.equal(await rawSave(),before,'Navigation/selection/cancel changed canonical save: '+label);
 result.actions.push({label,key:keyText,savePure:true,saveSHA:before===null?null:hash(before),events});persist();return observe(label);
}
async function bind(cardId){
 const before=JSON.parse(await rawSave()),card=page.locator(`.hand-cards .game-card[data-card="${cardId}"][aria-disabled="false"]`);assert.equal(await card.count(),1,'Missing unique actual legal opening binding '+cardId);
 await click(card,'ordinary native bind '+cardId);const immediate=await observe('post-bind observable availability '+cardId);await page.waitForTimeout(600);await settle();
 const after=JSON.parse(await rawSave());assert.equal(after.allies.length,before.allies.length+1);const added=after.allies.find(u=>!before.allies.some(v=>v.uid===u.uid));assert.equal(added.cardId,cardId);assert(added.hp>0&&!added.acted,'Binding not actually ready');
 result.actions.at(-1).binding={cardId,uid:added.uid,beforeHand:before.hand,afterHand:after.hand,beforeEnergy:before.energy,afterEnergy:after.energy,immediateSettling:immediate.settlingCombat,immediateDisabledActors:immediate.actors.filter(a=>a.disabled).map(a=>a.unit)};persist();return added;
}
 await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded',timeout:12000});await settle();
 await click(page.locator('#scene-ui [data-ui="new"]'),'open ordinary contract');result.originalGeneratedFormSeed=await page.locator('#seed').inputValue();
 await click(page.locator('[data-hunt-disclosure="hunt-seed-panel"]'),'open native Set a seed');await click(page.locator('#seed'),'focus visible campaign seed');
 await page.keyboard.press('Control+a');await page.keyboard.type('9845209');assert.equal(await page.locator('#seed').inputValue(),'9845209');assert.equal(await page.locator('input[name="difficulty"]:checked').inputValue(),'0');
 await click(page.locator('#new-game-form [type="submit"]'),'accept fixed seed with default Initiate');await page.waitForTimeout(600);await settle();
 const initial=JSON.parse(await rawSave());assert.equal(initial.seed,9845209);assert.equal(initial.difficulty,0);assert.equal(initial.phase,'battle');assert.equal(initial.turn,1);
 result.actualOpening={seed:initial.seed,difficulty:initial.difficulty,hand:initial.hand,allies:initial.allies,enemies:initial.enemies};
 assert.deepEqual(initial.hand,['cairnhound','fenstalker','sunder','sutures','survey'],'Fixed-seed opening differs; stop without reroll');assert.equal(initial.allies.length,0);await observe('actual fixed seed opening');await shot('fixed-seed-opening');
 const cairn=await bind('cairnhound');let row=await key('b','remember actual Cairn after first binding');assert.equal(row.active.unit,cairn.uid);
 const fen=await bind('fenstalker');result.bindingUids={cairn:cairn.uid,fen:fen.uid};await shot('both-native-bindings');
 const navigationSave=await rawSave();row=await key('b','B remembers Cairn');assert.equal(row.active.unit,cairn.uid);
 row=await key('ArrowRight','13-focus-fen reproduction: B then Right');
 if(phase==='candidate')assert.equal(row.active.unit,fen.uid,'R6 Right failed to reach Fen');
 else assert.equal(row.active.unit,initial.enemies[0].uid,'R5 did not reproduce legacy Right to Hostile 1');
 result.rightComparison={expected:phase==='candidate'?'Fen in allied row':'legacy Hostile 1',actual:row.active};await shot('B-Right-actual-focus');
 row=await key('ArrowLeft','Left returns remembered Cairn');assert.equal(row.active.unit,cairn.uid);
 row=await key('ArrowUp','Up from Cairn');if(phase==='candidate')assert.equal(row.active.side,'enemy');
 row=await key('ArrowDown','Down from prior row');if(phase==='candidate')assert.equal(row.active.unit,cairn.uid);
 row=await key('ArrowDown','Down toward hand');if(phase==='candidate')assert(row.active.card,'R6 Down did not reach hand');
 row=await key('ArrowUp','Up toward remembered bindings');if(phase==='candidate')assert.equal(row.active.unit,cairn.uid);
 assert.equal(await rawSave(),navigationSave,'Row navigation changed canonical fight');
 row=await key('b','B returns bindings before native Tab');assert.equal(row.active.unit,cairn.uid);
 row=await key('Tab','native Tab remains available');assert(row.active.focus&&row.active.focus!=='unit-'+cairn.uid,'Tab did not move focus');result.gates.tab={observed:true,actual:row.active};
 row=await key('b','B restores remembered Cairn after native Tab');assert.equal(row.active.unit,cairn.uid);
 row=await key('Enter','genuine native command selection');assert(row.selected.some(a=>a.unit===cairn.uid),'Cairn not actually selected');assert(row.legalTargets.length>=2,'Two legal hostile targets not earned');
 row=await key('t','native T focuses canonical legal targets');assert(row.legalTargets.some(a=>a.unit===row.active.unit));const firstTarget=row.active.unit;
 row=await key('ArrowRight','legal target Right');assert(row.legalTargets.some(a=>a.unit===row.active.unit));assert.notEqual(row.active.unit,firstTarget,'Right did not change actual legal target');assert.equal(row.preview?.kind,'consequence');await shot('legal-command-target-preview');
 row=await key('ArrowLeft','legal target Left');assert.equal(row.active.unit,firstTarget);assert.equal(row.preview?.kind,'consequence');
 row=await key('Escape','cancel genuine command');assert.equal(row.selected.length,0);assert.equal(await rawSave(),navigationSave);await shot('cancel-save-preserved');
 await click(page.locator('[data-ui="help"]'),'ordinary optional Help');row=await observe('native Help dialog');assert(row.dialogOpen&&row.activeInDialog);await shot('native-dialog-gate');
 row=await key('b','B inside Help remains dialog-owned');assert(row.dialogOpen&&row.activeInDialog);
 row=await key('ArrowDown','native arrow inside Help');assert(row.dialogOpen&&row.activeInDialog);
 row=await key('Tab','native Tab inside Help');assert(row.dialogOpen&&row.activeInDialog);result.gates.dialog={observed:true,savePure:true};
 row=await key('Escape','native Escape closes Help');assert(!row.dialogOpen);assert.equal(await rawSave(),navigationSave);
 fs.writeFileSync(path.join(packet,'LAST-ACTUAL-SAVE.json'),JSON.stringify({observedOnly:true,raw:await rawSave()})+'\n');
 check();result.completed=true;result.mechanicalPass=true;
}catch(e){result.failure=e.stack;result.mechanicalPass=false;process.exitCode=2;log('FAILURE.jsonl',{error:String(e)});}
finally{
 await close(stopReason||'visual checks completed or failed');
 // Cancellation can race async launch/listen. An earlier completed close does
 // not cover a subsequently returned owned browser/server; retire those too.
 if(browser&&browser!==closedBrowser||server&&server!==closedServer){closingPromise=null;await close('final late-created or unconfirmed owned-resource cleanup');}
 if(auditBefore&&!stopReason){try{await audit('after');}catch(e){result.afterAuditFailure=e.stack;result.mechanicalPass=false;process.exitCode=2;}}
 clearTimeout(timer);result.wholeElapsedMs=Date.now()-started;if(stopReason){result.mechanicalPass=false;process.exitCode=2;}
 fs.writeFileSync(path.join(packet,'VISUAL-RESULT.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({browser:result.browser,server:result.server,completed:result.completed,mechanicalPass:result.mechanicalPass,wholeElapsedMs:result.wholeElapsedMs,coverageGap:result.coverageGap,failure:result.failure?.split('\n')[0],abortReason:stopReason}));
}
