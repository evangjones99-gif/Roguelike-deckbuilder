from pathlib import Path
import hashlib,json,sys
O=Path('/workspace/scratch/installer-asar-current801d-independent-v09-r1');A=Path('/workspace/scratch/installer-asar-current801d-author-v09-r1');OLD=Path('/workspace/scratch/installer-asar-platform-author-v09-r1');S=Path('/tmp/hollowpact-event-availability-v09-root-r2');H=lambda b:hashlib.sha256(b).hexdigest()
packets=[]
for root in [OLD,A]:
 raw=(root/'MANIFEST.json').read_bytes();rows=json.loads(raw)['files'];assert root!=OLD or H(raw)=='dbd5455bc517f11536cc94bd9bfbb05c0f6064fa58544eb5fd960cefdf93c7f3'
 for r in rows:
  f=root/r['path']
  if r['type']=='symlink':assert f.is_symlink()and str(f.readlink())==r['target']
  else:b=f.read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],str(f)
 packets.append({'path':str(root),'rows':len(rows),'manifestSHA256':H(raw)})
prov=json.loads((S/'dist/build-provenance.json').read_text());assert prov['sourceDigest']=='801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029';assert len(prov['hashes'])==78;assert H(json.dumps(prov['hashes'],separators=(',',':')).encode())==prov['sourceDigest'];sources={}
for n,h in prov['hashes'].items():
 f=S/n;b=f.read_bytes();assert H(b)==h;sources[n]={'bytes':len(b),'sha256':h,'symlink':f.is_symlink()}
outputs={str(f.relative_to(S/'dist')):{'bytes':f.stat().st_size,'sha256':H(f.read_bytes())}for f in sorted((S/'dist').rglob('*'))if f.is_file()};assert len(outputs)==56
inputroot=Path('/tmp/hollowpact-event-availability-native-v09-r1/asar-input');inputtree={str(f.relative_to(inputroot)):{'bytes':f.stat().st_size,'sha256':H(f.read_bytes()),'symlink':f.is_symlink()}for f in sorted(inputroot.rglob('*'))if f.is_file()};assert len(inputtree)==60;assert not any(r['symlink']for r in inputtree.values())
for n,r in outputs.items():assert inputtree['dist/'+n]['sha256']==r['sha256']
for n in ['desktop/main.cjs','desktop/audio-lifecycle.cjs','desktop/icon.png']:assert inputtree[n]['sha256']==prov['hashes'][n]
proposed=[];changed=[]
for f in sorted((A/'proposed/scripts').iterdir()):
 b=f.read_bytes();same=b==(OLD/'proposed/scripts'/f.name).read_bytes();proposed.append({'name':f.name,'bytes':len(b),'sha256':H(b),'sameAs8a':same})
 if not same:changed.append(f.name)
assert changed==['windows-installer-asar-payload.json','windows-installer-current-validation.test.mjs','windows-installer-guards.mjs'],changed
mods=[]
for r in json.loads(Path('/workspace/scratch/installer-asar-platform-independent-v09-r1/ACTUAL-MODULE-FILES.json').read_text()):
 f=Path(r['path']);b=f.read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'];mods.append(r)
refs=json.loads((A/'EXTERNAL-ASAR-REFERENCES.json').read_text());refs.append({'role':'independentFreshProducer','path':'/tmp/hollowpact-installer-asar-current801d-independent-v09-r1/app.asar','bytes':33063240,'sha256':'6a89d2b61562309f0d8b9974df6a3bb18008dd5626a6001e898491bbba2ce03b'})
for r in refs:b=Path(r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256']
root=Path('/workspace/Roguelike-deckbuilder');runtime=json.loads((root/'dist/build-provenance.json').read_text());rootSources={}
for n,h in runtime['hashes'].items():b=(root/n).read_bytes();assert H(b)==h;rootSources[n]=h
rootTools=json.loads((OLD/'BASELINE-INPUTS.json').read_text())
for r in rootTools:b=Path(r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256']
result={'packets':packets,'sources':sources,'outputs':outputs,'inputTree':inputtree,'sourceDigest':prov['sourceDigest'],'proposedFiles':proposed,'changedVs8a':changed,'actualModuleFiles':mods,'binaryReferences':refs,'rootRuntime':runtime['sourceDigest'],'rootSources':rootSources,'unchangedRootTools':rootTools}
if sys.argv[1]=='INPUT-AFTER.json':assert result==json.loads((O/'INPUT-BEFORE.json').read_text())
(O/sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n');print('VERIFIED',len(sources),len(outputs),len(inputtree),'root',runtime['sourceDigest'],'changed',changed)
