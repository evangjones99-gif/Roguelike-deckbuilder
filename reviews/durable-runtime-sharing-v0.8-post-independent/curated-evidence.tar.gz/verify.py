import collections,datetime,hashlib,json,os,stat
from pathlib import Path
OUT=Path(__file__).parent
ROOT=Path('/workspace/Roguelike-deckbuilder/reviews/root-durable-runtime-capacity-v0.8')
AUDIT=Path('/workspace/scratch/durable-runtime-capacity-independent-v08-r1/AUDIT.json')
RELEASES=Path('/workspace/Roguelike-deckbuilder/releases')
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1048576): h.update(b)
 return h.hexdigest()
def meta(p):
 s=p.lstat()
 return {'type':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'other','size':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns,'blocks':s.st_blocks,'uid':s.st_uid,'gid':s.st_gid,'xattrs':{n:os.getxattr(p,n,follow_symlinks=False).hex() for n in sorted(os.listxattr(p,follow_symlinks=False))}}
inputs=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [AUDIT,*[ROOT/n for n in ('BEFORE.json','AFTER.json','JOURNAL.jsonl','consolidate.py','actual-consolidation.txt')]]]
assert sha(ROOT/'consolidate.py')=='4de719bd0bfd04f7dac75cf425fc29735005da48a4d4a7268f611e62a726beff'
assert sha(AUDIT)=='baa73b3df3105de3a10b4da3a894f4ee59349eb59d3966c9af98ac3545adbc06'
a=json.loads(AUDIT.read_text());before=json.loads((ROOT/'BEFORE.json').read_text());after=json.loads((ROOT/'AFTER.json').read_text())
assert before['auditSHA256']==after['auditSHA256']==sha(AUDIT)
groups=a['runtime_candidate_duplicate_groups'];assert len(groups)==141
eligible={p for g in groups for p in g['paths']};rows={};aliases=collections.defaultdict(list);counts=collections.Counter()
stable=('type','size','mode','device','inode','nlink','mtime_ns','ctime_ns','blocks','uid','gid','xattrs')
for inv in a['complete_inventories']:
 root=Path(inv['root']);assert not root.is_symlink() and root.resolve()==root
 expected={r['path'] for r in inv['rows']};actual={str(root),*(str(p) for p in root.rglob('*'))}
 assert expected==actual==set(before['memberships'][str(root)])
 for r in inv['rows']:
  p=Path(r['path']);m=meta(p);old=r['after_hash'];original=before['before'][str(p)]
  assert all(original[k]==old[k] for k in stable if k!='blocks')
  assert all(m[k]==after['after'][str(p)][k] for k in stable)
  assert all(m[k]==original[k] for k in ('type','mode','uid','gid','xattrs'))
  row={'path':str(p),'currentBeforeRead':m,'atimeReadChangesQualified':True};counts[m['type']]+=1
  if m['type']=='file':
   h=sha(p);assert h==r['sha256'] and m['size']==original['size'];row['sha256']=h;aliases[(m['device'],m['inode'])].append(str(p))
   assert all(meta(p)[k]==m[k] for k in stable),'file changed during read'
   if str(p) not in eligible:
    assert all(m[k]==original[k] for k in stable);row['excludedFullStableMetadataAndBytesUntouched']=True
  else:
   assert m['type']=='directory'
   assert all(m[k]==original[k] for k in ('device','inode','nlink','mtime_ns','uid','gid','xattrs','mode'))
   row['originalDirectoryMtimeAndIdentityRestored']=True
  rows[str(p)]=row
 print(json.dumps({'root':str(root),'completeBytesModesOwnershipXattrsMembershipPass':True}),flush=True)
assert counts=={'file':432,'directory':18}
gr=[]
for g in groups:
 members=[rows[p] for p in g['paths']];identities={(r['currentBeforeRead']['device'],r['currentBeforeRead']['inode']) for r in members};assert len(identities)==1
 for r in members:
  m=r['currentBeforeRead'];assert r['sha256']==g['sha256'] and m['size']==g['bytes'] and all(m[k]==g[k] for k in ('mode','uid','gid','xattrs'))
 gr.append({'bytes':g['bytes'],'sha256':g['sha256'],'mode':g['mode'],'uid':g['uid'],'gid':g['gid'],'xattrs':g['xattrs'],'deviceInode':list(next(iter(identities))),'aliasCount':len(members),'paths':g['paths']})
for r in rows.values():
 m=r['currentBeforeRead']
 if m['type']=='file':assert m['nlink']==len(aliases[(m['device'],m['inode'])]),'outside inventory inode alias'
journal=[json.loads(x) for x in (ROOT/'JOURNAL.jsonl').read_text().splitlines()];assert len(journal)==281==after['operations']
assert len({j['path'] for j in journal})==281
for j in journal:
 assert j['path'] in eligible and j['canonical'] in eligible
 assert before['before'][j['path']]['inode']==j['originalInode']
 assert rows[j['path']]['currentBeforeRead']['inode']==j['sharedInode']==rows[j['canonical']]['currentBeforeRead']['inode']
 assert rows[j['path']]['sha256']==rows[j['canonical']]['sha256']==j['sha256']
archives=[];ledgers=[]
for ledger in sorted(RELEASES.glob('*/SHA256SUMS')):
 digest=sha(ledger);ledgers.append({'path':str(ledger),'sha256':digest})
 for line in ledger.read_text().splitlines():
  if not line.strip():continue
  expected,name=line.split(None,1);p=ledger.parent/name.strip();assert p.parent==ledger.parent and not p.is_symlink()
  m=meta(p);assert m['type']=='file';h=sha(p);assert h==expected
  assert all(meta(p)[k]==m[k] for k in stable)
  archives.append({'path':str(p),'bytes':m['size'],'sha256':h,'ledger':str(ledger),'currentBeforeRead':m})
 assert sha(ledger)==digest
 print(json.dumps({'release':ledger.parent.name,'fullArchiveHashesMatchSealedLedger':True}),flush=True)
assert len(archives)==35 and sum('/0.7.0/' not in r['path'] for r in archives)==30
for r in inputs:assert sha(Path(r['path']))==r['sha256']
(OUT/'ARCHIVES.json').write_text(json.dumps({'scope':'35 current sealed archives: 30 pre-v0.7 plus five v0.7. Incomplete v0.6.0 excluded. Current complete bytes match original sealed ledgers; no invented pretransaction inode/mtime snapshot.','ledgers':ledgers,'archives':archives},indent=2)+'\n')
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted':True,'sourceInputs':inputs,'all432FileBytesSizesModesUIDGIDXattrsPass':True,'all18DirectoryIdentityOwnershipModesMembershipAndRestoredMtimePass':True,'all141GroupsOneInodeAndNoOutsideAliases':True,'all281JournalOperationsMatchActual':True,'sharedPaths':len(eligible),'untouchedExcludedFiles':432-len(eligible),'all35SealedArchiveWholeHashesPass':True,'metadataChanges':'Sharing changes inode,nlink,ctime and differing per-file atime/mtime to canonical metadata; directory ctime changes while original atime/mtime restored at transaction. Readers can subsequently update atime. Usage-contract immutability, no chmod enforcement. All original snapshots retained. Official archive old inode/timestamp identity was not freshly captured before transaction; byte equality proven against sealed SHA ledgers.','rows':list(rows.values()),'groups':gr,'forecastAllocatedSavingBytes':a['incremental_allocated_saving_bytes'],'rootObservedFreeDelta':after['observedFreeDelta'],'observedDeltaIncludesOtherWriters':True,'currentFreeBytes':{p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ('/tmp','/workspace')},'mutationsPerformedToAnyReviewedInput':False}
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
