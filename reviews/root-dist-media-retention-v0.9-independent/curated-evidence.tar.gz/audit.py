from pathlib import Path
import hashlib,json,os,stat
R=Path('/workspace/Roguelike-deckbuilder');T=R/'reviews/root-dist-media-retention-v0.9/transaction-r1';P=Path('/workspace/scratch/root-dist-media-retention-post-independent-v09-r1');I=Path('/workspace/scratch/root-dist-media-hardlink-plan-independent-v09-r1')
def memory():
 root=Path('/sys/fs/cgroup');maximum=int((root/'memory.max').read_text());current=int((root/'memory.current').read_text());remaining=maximum-current;assert remaining>=(512+128)*1048576;return remaining
memoryBefore=memory()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1048576):memory();h.update(b)
 return h.hexdigest()
def meta(p):
 s=p.lstat();assert not p.is_symlink()
 return {'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'bytes':s.st_size,'blocks':s.st_blocks,'atimeNS':s.st_atime_ns,'mtimeNS':s.st_mtime_ns,'ctimeNS':s.st_ctime_ns,'xattrs':{n:os.getxattr(p,n,follow_symlinks=False).hex()for n in os.listxattr(p,follow_symlinks=False)}}
def without(m,*keys):return{k:v for k,v in m.items()if k not in keys}
def stable(m):return without(m,'atimeNS')
def preserved(m):return without(m,'atimeNS','ctimeNS','nlink')
inventory=json.loads((I/'INVENTORY-R2.json').read_text());assert sha(I/'INVENTORY-R2.json')=='069fbddb61bc5fc9af80b94e4770f7bf9a808fb5356bc4b1f5264034c9982113'
names={'PREFLIGHT.json','BEFORE-BYTES.json','ALL-TEMPORARIES-VERIFIED.json','STEPS.jsonl','AFTER-BYTES.json','POST.json'};assert {p.name for p in T.iterdir()}==names
journalRows=[]
for p in sorted(T.iterdir()):
 assert stat.S_ISREG(p.lstat().st_mode)and p.lstat().st_uid==os.getuid();journalRows.append({'path':str(p),'metadata':meta(p),'sha256':sha(p)})
pre=json.loads((T/'PREFLIGHT.json').read_text());before=json.loads((T/'BEFORE-BYTES.json').read_text());allTemps=json.loads((T/'ALL-TEMPORARIES-VERIFIED.json').read_text());stepBytes=(T/'STEPS.jsonl').read_bytes();assert stepBytes.endswith(b'\n');steps=[json.loads(s)for s in stepBytes.splitlines()];after=json.loads((T/'AFTER-BYTES.json').read_text());post=json.loads((T/'POST.json').read_text());assert before==after
assert pre['planSHA256']==sha(I/'PLAN.md')and pre['inventorySHA256']==sha(I/'INVENTORY-R2.json')
assert len(pre['pairs'])==len(allTemps)==len(steps)==len(inventory['pairs'])==50
assert [(r['source'],r['destination'])for r in pre['pairs']]==[(r['source'],r['destination'])for r in inventory['pairs']]==[(r['source'],r['destination'])for r in steps]
live=[]
for original,row,tempRow,step in zip(inventory['pairs'],pre['pairs'],allTemps,steps):
 src=R/row['source'];dst=R/row['destination'];assert src.resolve()==src and dst.resolve()==dst
 assert all(not p.is_symlink()for p in [*src.parents,*dst.parents])
 assert stable(row['sourceMetadata'])==stable(original['sourceMetadata'])and stable(row['destinationMetadata'])==stable(original['destinationMetadata'])
 assert step['beforeSource']==row['sourceMetadata']and step['beforeDestination']==row['destinationMetadata']
 assert row['sha256']==step['sha256']==original['sha256']
 expectedTemp=dst.with_name('.'+dst.name+'.'+pre['token']);assert row['temporary']==str(expectedTemp)==tempRow['temporary'];assert tempRow['source']==str(src)
 assert not expectedTemp.exists()and not expectedTemp.is_symlink()
 sourceAfterLink=tempRow['sourceAfterLink'];assert sourceAfterLink['nlink']==2 and preserved(sourceAfterLink)==preserved(row['sourceMetadata']);assert sourceAfterLink['ctimeNS']>row['sourceMetadata']['ctimeNS']
 assert step['afterSource']==step['afterDestination']and step['afterSource']['nlink']==2
 assert preserved(step['afterSource'])==preserved(row['sourceMetadata'])and step['afterSource']['ctimeNS']>=sourceAfterLink['ctimeNS']
 sm,dm=meta(src),meta(dst);assert sm==dm;assert stat.S_ISREG(sm['mode'])and sm['nlink']==2
 assert stable(sm)==stable(step['afterSource'])and preserved(sm)==preserved(original['sourceMetadata'])
 assert (sm['dev'],sm['ino'])==(original['sourceMetadata']['dev'],original['sourceMetadata']['ino'])
 assert (sm['dev'],sm['ino'])!=(original['destinationMetadata']['dev'],original['destinationMetadata']['ino'])
 assert sha(src)==sha(dst)==row['sha256'];assert sm['ctimeNS']>original['sourceMetadata']['ctimeNS']
 live.append({'source':row['source'],'destination':row['destination'],'sha256':row['sha256'],'sharedMetadata':meta(src),'sourceOriginalCtimeNS':original['sourceMetadata']['ctimeNS'],'destinationOriginalInode':original['destinationMetadata']['ino'],'sourcePreservedFieldsExact':True,'originalDestinationAllocationBytes':original['destinationMetadata']['blocks']*512})
assert not list((R/'dist').rglob('*hollowpact-media-retention*'))
untouched=0
for row in inventory['excludedPublicMetadata']:
 for name,key in [('source','sourceMetadata'),('destination','destinationMetadata')]:
  p=R/row[name];assert stable(meta(p))==stable(row[key])and sha(p)==row['sha256'];untouched+=1
for row in inventory['uniqueUntouchedOutputs']:
 p=R/row['path'];assert stable(meta(p))==stable(row['metadata'])and sha(p)==row['sha256'];untouched+=1
directoryRows=[]
for name,initial in pre['directories'].items():
 current=meta(Path(name));recorded=post['directoriesAfter'][name];assert stable(current)==stable(recorded)
 assert without(current,'atimeNS','mtimeNS','ctimeNS')==without(initial,'atimeNS','mtimeNS','ctimeNS')
 if name.endswith('/dist/art')or name.endswith('/dist/audio'):assert current['ctimeNS']>=initial['ctimeNS']
 else:assert stable(current)==stable(initial)
 directoryRows.append({'path':name,'before':initial,'after':current})
runtime=json.loads((R/'dist/build-provenance.json').read_text());assert runtime['sourceDigest']==before['runtime']==post['runtime']==inventory['sourceDigest'];assert runtime['hashes']==before['sources']and len(runtime['hashes'])==78
assert hashlib.sha256(json.dumps(runtime['hashes'],separators=(',',':')).encode()).hexdigest()==runtime['sourceDigest']
sourceNames=sorted([str(p.relative_to(R))for name in ['src','desktop','public']for p in(R/name).rglob('*')if p.is_file()]+['index.html','THIRD-PARTY.md','package.json','package-lock.json','tsconfig.json','vite.config.ts','scripts/build.mjs']);assert sourceNames==sorted(runtime['hashes'])
for name,h in runtime['hashes'].items():assert sha(R/name)==h
outputs={str(p.relative_to(R)):sha(p)for p in sorted((R/'dist').rglob('*'))if p.is_file()};assert outputs==before['outputs']and len(outputs)==56
selected={'scripts/windows-installer-asar-validation.mjs':'716d5c1b763c8d34ea04f504eeb02472290993ea469471d7e7298f1766dd9ca4','scripts/windows-installer-asar-validation.test.mjs':'2ee456b0a7b7f3c0a031a574ae96c76299f18ceef8ac7757719bc48ec6bd746a','scripts/windows-installer-smoke.mjs':'19689fb40d41426c2dfa29e3da3e70df4c4865ed0835e4bb254d644fa1cb74a8'}
tools=[]
for row in inventory['tools']:
 p=R/row['path'];h=sha(p);assert h==selected.get(row['path'],row['sha256'])
 if row['path']not in selected:assert stable(meta(p))==stable(row['metadata'])
 tools.append({'path':row['path'],'sha256':h,'explicitNativepathSuccessor':row['path']in selected})
assert sha(R/'reviews/root-dist-media-retention-v0.9/retain.py')=='510a68caf2b75e85b25b767722c7a62a16115d87ce505131bd732826e6c352f4'
assert sha(R/'reviews/root-dist-media-retention-v0.9/retain-r2.py')=='df06abd16b4d1b1752350330c9be3eb878465493a5abab8fa24c61dbb9bb364a'
log=R/'reviews/root-dist-media-retention-v0.9/retain-r2.log';logData=json.loads(log.read_text());assert logData['retainedPairs']==50 and logData['runtime']==runtime['sourceDigest']
expectedReclaim=sum(r['destinationMetadata']['blocks']*512 for r in inventory['pairs']);journalAlloc=sum(r['metadata']['blocks']*512 for r in journalRows);priorPostAlloc=journalAlloc-(T/'POST.json').stat().st_blocks*512
assert post['freeAfterBeforeThisReceipt']-post['freeBefore']==post['measuredRecoveryBeforeThisReceipt']
assert post['measuredRecoveryBeforeThisReceipt']==expectedReclaim-priorPostAlloc
assert logData['free']==post['freeAfterBeforeThisReceipt']-(T/'POST.json').stat().st_blocks*512
v=os.statvfs(R);currentFree=v.f_bavail*v.f_frsize;assert currentFree>=pre['reserve']==1048576
assert sum(r['metadata']['bytes']for r in journalRows)<=262144 and journalAlloc<=262144
for r in journalRows:assert sha(Path(r['path']))==r['sha256']and stable(meta(Path(r['path'])))==stable(r['metadata'])
memoryAfter=memory()
report={'classification':'Independent actual post-transaction state/raw/journal audit; no reviewer mutation/build/nativepackage/crash test','sourceDigest':runtime['sourceDigest'],'livePairCount':50,'sourceCount':78,'outputCount':56,'sourceAndOutputHashesBeforeAfterAndLiveExact':True,'livePairs':live,'untouchedMetadataAndRawRows':untouched,'directories':directoryRows,'tools':tools,'journalFiles':journalRows,'stepCount':len(steps),'allTemporaryCount':len(allTemps),'noTemporaryPaths':True,'sourceNlinkCtimeAndDestinationMetadataDisclosed':True,'recovery':{'sourceAllocatedReductionEstimate':expectedReclaim,'sixJournalEncodedBytes':sum(r['metadata']['bytes']for r in journalRows),'sixJournalAllocatedBytes':journalAlloc,'beforePostReceiptJournalAllocatedBytes':priorPostAlloc,'rootIntervalFreeBefore':post['freeBefore'],'rootIntervalFreeBeforePostReceipt':post['freeAfterBeforeThisReceipt'],'rootMeasuredBeforePostReceiptDelta':post['measuredRecoveryBeforeThisReceipt'],'afterPostReceiptFreeFromRootLog':logData['free'],'currentFreeAtIndependentAudit':currentFree,'reserve':pre['reserve'],'intervalAccountingExactlyMatches':True,'qualification':'Root interval measurements reconciled; current global free may include other allocations, no universal extent/crash/rebuild guarantee'},'actualLog':{'path':str(log),'sha256':sha(log),'bytes':log.stat().st_size},'memoryAdmission':{'workBytes':128*1048576,'reserveBytes':512*1048576,'beforeHeadroom':memoryBefore,'afterHeadroom':memoryAfter},'readFailure':'Initial requested rootretain-r2.log basename did not exist; actual retained filename retain-r2.log read and hashed. No journal missing.'}
b=(json.dumps(report,separators=(',',':'))+'\n').encode();assert len(b)<50000
(P/'AUDIT.json').open('xb').write(b)
print(json.dumps({'pairs':50,'sources':78,'outputs':56,'untouched':untouched,'journalBytes':report['recovery']['sixJournalEncodedBytes'],'rootBeforePostDelta':post['measuredRecoveryBeforeThisReceipt'],'currentFree':currentFree,'reportBytes':len(b),'reportSHA256':hashlib.sha256(b).hexdigest()}))
