from pathlib import Path
import json,hashlib,urllib.request,sys,difflib
O=Path('/workspace/scratch/bone-thrall-art-technical-independent-v09-r1'); S=Path('/workspace/scratch/bone-thrall-art-author-v09-r1-supplement-r2'); A=Path('/workspace/scratch/bone-thrall-art-author-v09-r1'); H=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((S/'MANIFEST.json').read_text());assert H((S/'MANIFEST.json').read_bytes())=='1bc9fce3c8da0c56a8fbd00d9683e48ff3630027f03c7eb076ea61d92d080ecb'
for r in m['files']:
 b=(S/r['path']).read_bytes();assert len(b)==r['bytes'] and H(b)==r['sha256'],r['path']
original=json.loads((S/'ORIGINAL-BEFORE.json').read_text())
for r in original:
 f=A/r['path'];b=f.read_bytes();assert len(b)==r['bytes'] and H(b)==r['sha256'],r['path']
 if r['symlink'] is not None:assert str(f.readlink())==r['symlink']
i=json.loads((S/'SOURCE-BUILD-IDENTITY.json').read_text());base=json.loads((S/'BASELINE-INPUTS.json').read_text());result={'supplementManifest':H((S/'MANIFEST.json').read_bytes()),'supplementFileCount':len(m['files']),'originalRows':len(original),'variants':{}}
for name,rows,root,port,count in [('candidate',i['sources'],A/'prototype/dist',4598,56),('baseline',[dict(path=n,**r) for n,r in base.items()],Path('/workspace/scratch/hound-jaw-hinge-author-v08-r5/baseline/dist'),4599,55)]:
 sources={}
 for r in rows:
  b=Path(r['input']).read_bytes();assert len(b)==r['bytes'] and H(b)==r['sha256'],r['path'];sources[r['path']]={'sha256':H(b),'bytes':len(b),'input':r['input']}
 digest=H(json.dumps({n:r['sha256'] for n,r in sources.items()},separators=(',',':')).encode());outputs={}
 for f in sorted(root.rglob('*')):
  if f.is_file():
   n=str(f.relative_to(root));b=f.read_bytes();served=urllib.request.urlopen(f'http://127.0.0.1:{port}/{n}',timeout=10).read();assert b==served,n;outputs[n]={'sha256':H(b),'bytes':len(b)}
 assert len(outputs)==count
 p=json.loads((root/'build-provenance.json').read_text());assert digest==p['sourceDigest'];result['variants'][name]={'runtime':digest,'sources':sources,'outputs':outputs}
a=result['variants']['candidate']['sources'];b=result['variants']['baseline']['sources'];changed=[n for n in a if n not in b or a[n]['sha256']!=b[n]['sha256']];assert sorted(changed)==sorted(['THIRD-PARTY.md','public/art/PROVENANCE.json','public/art/bone-thrall-v09-r1.png','src/art.ts','src/main.ts']);result['changedInputs']=changed
for n in ['src/main.ts','src/art.ts']:
 text=''.join(difflib.unified_diff(Path(b[n]['input']).read_text().splitlines(True),Path(a[n]['input']).read_text().splitlines(True),fromfile='baseline/'+n,tofile='candidate/'+n));dest=O/(n.replace('/','-')+'.diff')
 if not dest.exists():dest.write_text(text)
if sys.argv[1]=='INPUT-AFTER.json':assert result==json.loads((O/'INPUT-BEFORE.json').read_text())
with (O/sys.argv[1]).open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({'originalRows':len(original),'supplementFiles':len(m['files']),'candidateSources':len(a),'candidateOutputs':56,'baselineSources':len(b),'baselineOutputs':55,'changedInputs':changed}))
