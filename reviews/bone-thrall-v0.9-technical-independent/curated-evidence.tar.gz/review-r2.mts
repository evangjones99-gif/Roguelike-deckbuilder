import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import {transform} from '/workspace/Roguelike-deckbuilder/node_modules/esbuild/lib/main.js';
import {createGame,applyAction,applyActionWithEvents,legalActions,validateState,type GameState} from '/workspace/scratch/bone-thrall-art-author-v09-r1/prototype/src/engine.ts';
import {ENEMIES,CARDS} from '/workspace/scratch/bone-thrall-art-author-v09-r1/prototype/src/content.ts';
const O='/workspace/scratch/bone-thrall-art-technical-independent-v09-r1',P='/workspace/scratch/bone-thrall-art-author-v09-r1/prototype',H=(x:any)=>createHash('sha256').update(x).digest('hex');
const ids=JSON.parse(await fs.readFile(O+'/INPUT-BEFORE.json','utf8'));
const mappings:any={};
for(const variant of ['candidate','baseline']){
 const raw=await fs.readFile(ids.variants[variant].sources['src/art.ts'].input,'utf8');
 const code=(await transform(raw.replaceAll('import.meta.env.BASE_URL','"/"'),{loader:'ts',format:'esm'})).code;
 const mod=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));const rows:any={};
 for(const species of [...new Set([...Object.values(ENEMIES),...Object.values(CARDS)].map((c:any)=>c.species).filter(Boolean)), 'Thrall','THRALL','thrallish','unmapped'])rows[species]=mod.portraitFor(species);
 assert.equal(mod.animationFor('thrall'),null);mappings[variant]=rows;
}
for(const s of Object.keys(mappings.candidate))if(s.toLowerCase()!=='thrall')assert.deepEqual(mappings.candidate[s],mappings.baseline[s],s);
for(const s of ['thrall','Thrall','THRALL'])assert.deepEqual(mappings.candidate[s],{url:'/art/bone-thrall-v09-r1.png',column:0,row:0,columns:1,rows:1,focal:[65,13]});
const artBytes=await fs.readFile(P+'/public/art/bone-thrall-v09-r1.png');assert.equal(H(artBytes),'3697dd4cc89f1550e0688b34bb421939988c90ab78832ce83d53ddb81b372dfd');
const provenance=JSON.parse(await fs.readFile(P+'/public/art/PROVENANCE.json','utf8'));assert.equal(JSON.stringify(provenance).includes(H(artBytes)),true);const served=await fetch('http://127.0.0.1:4598/art/bone-thrall-v09-r1.png');assert.equal(H(Buffer.from(await served.arrayBuffer())),H(artBytes));await fs.writeFile(O+'/MAPPING-CHECKS-r2.json',JSON.stringify({mappings,artSHA256:H(artBytes),sourcePixelsUnchanged:true,notAnimation:true},null,2)+'\n',{flag:'wx'});
function fixture(schema:number,mode:string):GameState{
 let s:any=createGame(91831,1);s=applyAction(s,{type:'travel',choice:s.route.find((x:string)=>x==='battle')||s.route[0]});assert.equal(s.phase,'battle');s.allies=[]; // Entered battle has no deployed card; retain original card conservation.
 if(schema===2){s.schema=2;delete s.engineKind;}
 const kinds=mode==='wraith'?['revenant']:mode==='spawn'?['acolyte']:mode==='mixed'?['thrall','revenant']:['thrall'];
 s.enemies=kinds.map(id=>{const d=ENEMIES[id];return {...d,uid:'e'+s.nextUid++,cardId:id,maxHp:d.hp,hp:d.hp,block:0,acted:false,intent:mode==='spawn'?{damage:0,target:'hunter',label:'Raise 1 Bone Thrall',summon:['thrall']}:{damage:d.attack,target:'hunter',label:'Attack hunter '+d.attack}}});
 assert(validateState(s),JSON.stringify(s));return s;
}
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const rows:any[]=[];
async function run(variant:string,schema:number,mode:string,fault=''){
 const initial=fixture(schema,mode),width=schema===2?390:1440;const ctx=await browser.newContext({viewport:{width,height:900},deviceScaleFactor:1,reducedMotion:'reduce'});const errors:string[]=[];
 await ctx.addInitScript(({initial,fault})=>{
  if(!localStorage.getItem('hollowpact.run.v2'))localStorage.setItem('hollowpact.run.v2',JSON.stringify(initial));localStorage.setItem('hollowpact.settings.v2',JSON.stringify({mute:true,volume:0,motion:false}));localStorage.setItem('hollowpact.tutorial.v2','yes');
  const w=window as any;w.__boneDraws=[];
  const old=CanvasRenderingContext2D.prototype.drawImage;CanvasRenderingContext2D.prototype.drawImage=function(...a:any[]){if(this.canvas.id==='arena'&&a[0] instanceof HTMLImageElement){w.__boneDraws.push({src:a[0].src,args:a.slice(1),canvas:[this.canvas.width,this.canvas.height]});if(w.__boneDraws.length>1000)w.__boneDraws.shift();}return old.apply(this,a as any)} as any;
  if(fault==='no-canvas'){const get=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(...a:any[]){return this.id==='arena'?null:get.apply(this,a as any)}as any;}
 },{initial,fault});
 const page=await ctx.newPage();page.on('pageerror',e=>errors.push(String(e)));let release:()=>void=()=>{};
 if(fault==='missing')await page.route('**/art/bone-thrall-v09-r1.png',r=>r.abort());
 if(fault==='late'){const wait=new Promise<void>(r=>release=r);await page.route('**/art/bone-thrall-v09-r1.png',async r=>{await wait;await r.continue()});}
 await page.goto('http://127.0.0.1:'+(variant==='candidate'?4598:4599),{waitUntil:'domcontentloaded'});await page.locator('[data-ui=resume]').click();await page.locator('[data-action=endTurn]').waitFor();
 const row:any={variant,schema,mode,fault,width,initial,errors,frames:[],checkpoints:[],actions:[]};let current=initial;
 async function snap(label:string){const d=await page.evaluate(()=>{const c=document.querySelector('#arena')as HTMLCanvasElement;return{save:localStorage.getItem('hollowpact.run.v2'),draws:(window as any).__boneDraws,canvas:[c.width,c.height],png:c.toDataURL(),units:[...document.querySelectorAll('.unit')].map(x=>({text:x.textContent,style:x.querySelector('.portrait')?.getAttribute('style')})),fallback:document.querySelector('.arena-fallback')?.textContent}});assert.equal(d.save,JSON.stringify(current));row.checkpoints.push({label,saveSHA256:H(d.save)});row.frames.push({...d,label,pngSHA256:H(Buffer.from(d.png.split(',')[1],'base64')),png:undefined,save:undefined});}
 if(fault==='late'){await page.waitForTimeout(160);await snap('pending');assert(!row.frames.at(-1).draws.some((d:any)=>d.src.includes('bone-thrall')));release();}
 await page.waitForTimeout(650);await snap('idle');
 if(variant==='candidate'&&mode!=='wraith'&&mode!=='spawn'&&!['missing','no-canvas'].includes(fault))assert(row.frames.at(-1).draws.some((d:any)=>d.src.includes('bone-thrall')),'Dedicated canvas body never drawn');
 if(fault==='missing')assert(!row.frames.at(-1).draws.some((d:any)=>d.src.includes('bone-thrall')));
 if(fault==='no-canvas')assert(row.frames.at(-1).fallback);
 if(mode==='wraith')assert(!row.frames.at(-1).draws.some((d:any)=>d.src.includes('bone-thrall')));
 const enemy=current.enemies.find(e=>e.cardId==='thrall')||current.enemies[0];await page.locator(`[data-ui=inspect-unit][data-uid="${enemy.uid}"]`).click();await page.locator('#dialog-title').waitFor();
 row.dossier=await page.locator('#dialog').evaluate((x:any)=>({text:x.textContent,portrait:[...x.querySelectorAll('.portrait')].map((p:any)=>({inline:p.getAttribute('style'),bg:getComputedStyle(p).backgroundImage,position:getComputedStyle(p).backgroundPosition,focalX:getComputedStyle(p.parentElement).getPropertyValue('--portrait-x'),focalY:getComputedStyle(p.parentElement).getPropertyValue('--portrait-y')}))}));assert(row.dossier.text.includes(enemy.name));assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),JSON.stringify(current));
 if(variant==='candidate'&&enemy.cardId==='thrall'){assert(row.dossier.portrait.some((p:any)=>p.bg.includes('bone-thrall-v09-r1.png')));assert(row.dossier.portrait.some((p:any)=>p.focalX==='65%'&&p.focalY==='13%'));}
 if((schema===2&&mode==='mixed'&&!fault)||(fault==='missing'))await page.screenshot({path:O+`/${variant}-${schema}-${mode}${fault?'-'+fault:''}-dossier.jpg`,type:'jpeg',quality:70,fullPage:true});
 await page.getByRole('button',{name:'Close dialog'}).click();
 const action={type:'endTurn'}as const;assert(legalActions(current).some(a=>a.type==='endTurn'));const result=applyActionWithEvents(current,action);await page.locator('[data-action=endTurn]').click();current=result.state;assert(validateState(current));row.actions.push({action,events:result.events,state:current});await page.waitForTimeout(700);await snap('action');
 if(mode==='spawn'){assert(current.enemies.some(e=>e.cardId==='thrall'));if(variant==='candidate')assert(row.frames.at(-1).draws.some((d:any)=>d.src.includes('bone-thrall')));const second=applyActionWithEvents(current,action);await page.locator('[data-action=endTurn]').click();current=second.state;row.actions.push({action,events:second.events,state:current});await page.waitForTimeout(700);await snap('raised-thrall-action');}
 await page.reload({waitUntil:'load'});assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),JSON.stringify(current));row.checkpoints.push({label:'reload',saveSHA256:H(JSON.stringify(current))});assert.deepEqual(errors,[]);await ctx.close();rows.push(row);await fs.writeFile(O+'/CHECKPOINT.json',JSON.stringify({completed:rows.length},null,2)+'\n');
}
try{
 for(const schema of [2,3])for(const mode of ['single','mixed','wraith','spawn'])for(const variant of ['baseline','candidate'])await run(variant,schema,mode);
 for(const schema of [2,3])for(const fault of ['missing','late','no-canvas'])await run('candidate',schema,'mixed',fault);
 const pairs:any[]=[];for(const schema of [2,3])for(const mode of ['single','mixed','wraith','spawn']){const a=rows.find(r=>r.variant==='baseline'&&r.schema===schema&&r.mode===mode),b=rows.find(r=>r.variant==='candidate'&&r.schema===schema&&r.mode===mode&&!r.fault);assert.deepEqual(a.actions,b.actions);assert.deepEqual(a.checkpoints,b.checkpoints);if(mode==='wraith')assert.equal(a.frames[0].pngSHA256,b.frames[0].pngSHA256);pairs.push({schema,mode,exactActions:a.actions.length,exactSaveCheckpoints:a.checkpoints.length,unchangedWraithPixels:mode==='wraith'?a.frames[0].pngSHA256:undefined});}
 await fs.writeFile(O+'/RESULTS.json.gz',gzipSync(Buffer.from(JSON.stringify({scope:'Independent frozen exterior component browser QA; injected valid unearned diagnostics; no human/native/rights/performance claim',rows,pairs},null,2)+'\n')),{flag:'wx'});console.log(JSON.stringify({contexts:rows.length,actions:rows.reduce((n,r)=>n+r.actions.length,0),reloads:rows.length,pairs:pairs.length,pageErrors:rows.flatMap(r=>r.errors).length}));
}catch(e){await fs.writeFile(O+'/FAILURE-r2.json',JSON.stringify({error:String(e),stack:(e as Error).stack,completed:rows},null,2)+'\n',{flag:'wx'});throw e;}finally{await browser.close();}
