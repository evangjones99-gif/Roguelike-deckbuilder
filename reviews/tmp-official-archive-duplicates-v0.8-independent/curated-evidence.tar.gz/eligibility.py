import datetime,hashlib,json,os,stat
from pathlib import Path
OUT=Path(__file__).parent
TMP=Path('/tmp/hollowpact-native-v07/windows-native/hollowpact-0.7.0-windows-native-x64.zip')
OFFICIAL=Path('/workspace/Roguelike-deckbuilder/releases/0.7.0/hollowpact-0.7.0-windows-native-x64.zip')
EXPECTED='256babeb74761b0608ae8be249f30f475522c70f86c0fd377f1bef737fb35fbe'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def meta(p):
 s=p.lstat();return {'type':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'other','bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'blocks':s.st_blocks,'xattrs':{n:os.getxattr(p,n,follow_symlinks=False).hex() for n in sorted(os.listxattr(p,follow_symlinks=False))}}
tm=meta(TMP);om=meta(OFFICIAL);pm=meta(TMP.parent);opm=meta(OFFICIAL.parent)
assert TMP.resolve()==TMP and OFFICIAL.resolve()==OFFICIAL and tm['type']==om['type']=='file' and tm['nlink']==om['nlink']==1
assert tm['bytes']==om['bytes']==185715968
assert all(tm[k]==om[k] for k in ('mode','uid','gid','xattrs')) and sha(TMP)==sha(OFFICIAL)==EXPECTED
members=sorted(str(p) for p in TMP.parent.iterdir());officialmembers=sorted(str(p) for p in OFFICIAL.parent.iterdir())
fds=[];denied=[];examined=0
for pid in Path('/proc').iterdir():
 if not pid.name.isdecimal():continue
 try:
  for fd in (pid/'fd').iterdir():
   try:target=os.readlink(fd)
   except FileNotFoundError:continue
   examined+=1
   if target in (str(TMP),str(OFFICIAL),str(TMP)+' (deleted)',str(OFFICIAL)+' (deleted)'):
    info=(pid/'fdinfo'/fd.name).read_text();flag=next((line.split(':',1)[1].strip() for line in info.splitlines() if line.startswith('flags:')),None)
    fds.append({'pid':int(pid.name),'fd':fd.name,'target':target,'openFlagsOctal':flag,'comm':(pid/'comm').read_text().strip()})
 except (PermissionError,FileNotFoundError) as e:
  denied.append({'pid':int(pid.name),'kind':type(e).__name__})
assert not fds,'active reader/writer; reject until released'
for p,m in ((TMP,tm),(OFFICIAL,om),(TMP.parent,pm),(OFFICIAL.parent,opm)):
 assert all(meta(p)[k]==m[k] for k in m if k!='atime_ns'),'metadata changed during gate'
assert members==sorted(str(p) for p in TMP.parent.iterdir()) and officialmembers==sorted(str(p) for p in OFFICIAL.parent.iterdir())
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'eligibility':'ACCEPTED only for the exact narrow future transaction with fresh preflight and exclusive writer coordination','tmpOriginal':{'path':str(TMP),'sha256':EXPECTED,'metadata':tm},'officialRetained':{'path':str(OFFICIAL),'sha256':EXPECTED,'metadata':om},'tmpParent':{'path':str(TMP.parent),'metadata':pm,'members':members},'officialParent':{'path':str(OFFICIAL.parent),'metadata':opm,'members':officialmembers},'processFDInspection':{'examinedFDCount':examined,'matchedOpenFDs':fds,'uninspectableOrTransientPIDs':denied,'scope':'Point-in-time /proc snapshot only; does not lock files or guarantee no future writers. No process arguments/environment/credentials read.'},'requiredRootControls':['Explicitly freeze this historical archive path and official counterpart from concurrent writers/readers before fresh proof and transaction.','Before mutation rehash both originals and retain original file/parent metadata and complete parent membership; reject stale metadata or unexpected aliases.','Create a unique neighboring symlink to the exact unchanged absolute durable official archive then atomically replace only this redundant TMP regular file. Never overwrite or mutate official archive, wrappers, source preflight, trial bundle or neighboring files.','Restore original TMP parent atime/mtime, retain original path as symlink and every original timestamp/inode/mode in sidecars; disclose lstat file-type/inode/ctime/timestamp changes.','Postcheck exact original-path resolution, SHA/size/access mode/uid/gid/xattrs and unchanged official stable metadata except read atime; TMP parent membership/mode/ownership/inode/restored mtime unchanged.','A separately independent postgate must verify the actual transaction. Recoverable allocated bytes are 185716736 before tiny symlink overhead, not 300MB; TMP is not durable backup.'],'mutationPerformedToReviewedInput':False}
(OUT/'ELIGIBILITY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'eligibility':result['eligibility'],'processFDInspection':result['processFDInspection']}))
