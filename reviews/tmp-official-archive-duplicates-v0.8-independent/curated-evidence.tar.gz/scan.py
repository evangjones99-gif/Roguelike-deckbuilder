import datetime,hashlib,json,os,stat,subprocess
from pathlib import Path
OUT=Path(__file__).parent
POOL=Path('/workspace/scratch/durable-runtime-capacity-postmove-independent-v08-r1/ARCHIVES.json')
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def meta(p):
 s=p.lstat()
 return {'size':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns,'allocatedBytes':s.st_blocks*512,'uid':s.st_uid,'gid':s.st_gid,'xattrs':{n:os.getxattr(p,n,follow_symlinks=False).hex() for n in sorted(os.listxattr(p,follow_symlinks=False))}}
poolhash=sha(POOL);pool=json.loads(POOL.read_text());sizes={r['bytes'] for r in pool['archives']};assert len(pool['archives'])==35
command=['rg','--files','--hidden','--no-ignore','/tmp'];run=subprocess.run(command,capture_output=True,text=True);assert run.returncode==0
archives=[];matches=[];missing=[];regular=0
for name in run.stdout.splitlines():
 p=Path(name)
 try:s=p.lstat()
 except FileNotFoundError:missing.append(name);continue
 if not stat.S_ISREG(s.st_mode):continue
 regular+=1
 archive=name.endswith(('.zip','.tar','.tar.gz','.tgz','.tar.xz','.tar.bz2','.zip.gz'))
 if archive:
  m=meta(p)
  reason='fixture/research/wrapper inputs excluded' if any(v in name for v in ('hollowpact-preserve-','hollowpact-independent-storage-','installer-r2-original','wrapper','frames.tar')) else 'nonmatching size; unique archive retained' if s.st_size not in sizes else 'size candidate only, requires whole SHA'
  archives.append({'path':name,'metadataBeforeRead':m,'classification':reason})
 if s.st_size in sizes:
  m=meta(p);h=sha(p);current=meta(p)
  assert all(current[k]==m[k] for k in m if k!='atime_ns'),'TMP candidate changed during read'
  same=[r for r in pool['archives'] if r['bytes']==s.st_size and r['sha256']==h]
  candidate={'path':name,'tmpOriginalMetadataBeforeRead':m,'sha256':h,'matchingSealedArchives':[],'acceptedCapacityCandidate':False}
  for r in same:
   official=Path(r['path']);om=meta(official);ledger=Path(r['ledger']);lines=ledger.read_text().splitlines();assert f"{h}  {official.name}" in lines
   assert sha(official)==h and official.stat().st_size==s.st_size
   assert all(meta(official)[k]==om[k] for k in om if k!='atime_ns')
   candidate['matchingSealedArchives'].append({'path':str(official),'bytes':s.st_size,'sha256':h,'metadataBeforeRead':om,'ledgerPath':str(ledger),'ledgerSHA256':sha(ledger)})
  excluded=any(v in name for v in ('hollowpact-preserve-','hollowpact-independent-storage-','installer-r2-original','wrapper','frames.tar','bundle-preflight'))
  candidate['acceptedCapacityCandidate']=bool(same) and archive and not excluded
  matches.append(candidate)
assert sha(POOL)==poolhash
accepted=[r for r in matches if r['acceptedCapacityCandidate']];identities={(r['tmpOriginalMetadataBeforeRead']['device'],r['tmpOriginalMetadataBeforeRead']['inode']) for r in accepted}
allocated=sum(next(r['tmpOriginalMetadataBeforeRead']['allocatedBytes'] for r in accepted if (r['tmpOriginalMetadataBeforeRead']['device'],r['tmpOriginalMetadataBeforeRead']['inode'])==identity) for identity in identities)
assert len(accepted)==1 and allocated==185716736
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pool':{'path':str(POOL),'sha256':poolhash,'sealedArchiveCount':35,'olderPreV07Count':30},'scanCommand':command,'scanStdErr':run.stderr,'regularFilesEnumerated':regular,'concurrentMissingPaths':missing,'completeSuffixArchiveInventory':archives,'allRegularFileSizeCandidates':matches,'acceptedExactDuplicateCount':len(accepted),'potentialAllocatedRecoveryBytesBeforeReplacementOverhead':allocated,'potentialLogicalRecoveryBytes':sum(r['tmpOriginalMetadataBeforeRead']['size'] for r in accepted),'requestedMinimumRecoveryBytes':300000000,'requestedCapacityGate':'REJECTED - insufficient measured whole-archive duplicates','tmpFreeBytesSnapshot':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'mutationsPerformedToReviewedInput':False,'limitations':'No file removed, relocated or linked. No unique source/trial bundle, media, profiles, datasets, review inputs or raw wrapper parts proposed. rg enumeration is a point-in-time filesystem scan; new concurrent files may appear afterward. Exact duplicate only supports a future separately gated retention plan with original-path/metadata sidecars and fresh before/after hashes. TMP is not durable backup. Link inode/ctime/identity is intentionally not equivalent to original regular-file lstat metadata.'}
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('regularFilesEnumerated','acceptedExactDuplicateCount','potentialAllocatedRecoveryBytesBeforeReplacementOverhead','requestedCapacityGate','tmpFreeBytesSnapshot')}))
