const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const base=__dirname,pins=JSON.parse(fs.readFileSync(path.join(base,'pins.json')));
const exactStatus={36802452392:'failed',36803389350:'failed',36804006841:'failed',36804825248:'passed'};
const source=fs.readFileSync(path.join(base,'candidate-script.js'),'utf8');
const sha=data=>crypto.createHash('sha256').update(data).digest('hex');
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const retained=[];
const createRemote=()=>({refs:new Map(),releases:new Map(),assets:new Map(),nextId:9000});
const copyRemote=r=>({refs:new Map([...r.refs].map(([k,v])=>[k,{...v,object:{...v.object}}])),releases:new Map([...r.releases].map(([k,v])=>[k,{...v}])),assets:new Map([...r.assets].map(([k,v])=>[k,{...v,data:v.data?Buffer.from(v.data):null}])),nextId:r.nextId});
async function execute(name,remote,script=source){
 const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'hollowpact-preserve-storage-'));
 const virtual=new Map(),writes=[],reads=[],notices=[],failures=[];
 const fixtureFS={...fs,statfsSync:()=>({bavail:4096,bsize:1048576}),statSync:p=>{const s=fs.statSync(p),m=virtual.get(p);return m?{...s,size:m.bytes}:s;},readFileSync:(p,...args)=>{const b=fs.readFileSync(p,...args),m=virtual.get(p);if(m&&Buffer.isBuffer(b))b.virtualFixtureIdentity=m;return b;}};
 const fixturePath={...path,resolve:(...args)=>args.length===1&&args[0]==='installer-research-preservation'?path.join(temporary,args[0]):path.resolve(...args)};
 const fixtureRequire=n=>n==='node:fs'?fixtureFS:n==='node:path'?fixturePath:require(n);
 const response=data=>({data});
 const readonly=(label,fn)=>async p=>{reads.push({operation:label});return response(fn(p));};
 const getPinByTag=tag=>pins.find(p=>p.tag===tag);
 const github={rest:{actions:{
  getWorkflowRun:readonly('get run',p=>JSON.parse(fs.readFileSync(path.join(base,`live-run-${p.run_id}.json`)))),
  listWorkflowRunArtifacts:readonly('list artifacts',p=>JSON.parse(fs.readFileSync(path.join(base,`live-artifacts-${p.run_id}.json`)))),
 },git:{
  getRef:readonly('get ref',p=>{const ref=remote.refs.get(p.ref);if(ref)return ref;const e=new Error('fixture missing');e.status=404;throw e;}),
  createRef:async p=>{assert.equal(p.owner,'evangjones99-gif');assert.equal(p.repo,'Roguelike-deckbuilder');const pin=getPinByTag(p.ref.replace('refs/tags/',''));assert(pin);assert.equal(p.sha,pin.headSHA);assert(!remote.refs.has(p.ref.replace('refs/','')));const value={ref:p.ref,object:{type:'commit',sha:p.sha}};remote.refs.set(p.ref.replace('refs/',''),value);writes.push({operation:'createRef',tag:pin.tag,target:p.sha});return response(value);},
 },repos:{
  listReleases:readonly('list releases',()=>[...remote.releases.values()]),
  getRelease:readonly('get release',p=>{const r=remote.releases.get(p.release_id);assert(r);return r;}),
  createRelease:async p=>{const pin=getPinByTag(p.tag_name);assert(pin);assert.equal(p.target_commitish,pin.headSHA);assert.equal(p.draft,true);assert.equal(p.prerelease,true);assert.equal(p.make_latest,'false');const r={id:remote.nextId++,tag_name:p.tag_name,target_commitish:p.target_commitish,draft:p.draft,prerelease:p.prerelease,name:p.name,body:p.body};remote.releases.set(r.id,r);writes.push({operation:'createRelease',tag:r.tag_name,draft:r.draft,prerelease:r.prerelease});return response(r);},
  listReleaseAssets:readonly('list assets',p=>[...remote.assets.values()].filter(x=>x.release_id===p.release_id)),
  uploadReleaseAsset:async p=>{
   const release=remote.releases.get(p.release_id);assert(release&&release.draft&&release.prerelease);assert(![...remote.assets.values()].some(a=>a.release_id===p.release_id&&a.name===p.name));
   const meta=p.data.virtualFixtureIdentity;const bytes=meta?meta.bytes:p.data.length,digest=meta?meta.sha256:sha(p.data);
   assert.equal(p.headers['content-length'],bytes);const a={id:remote.nextId++,release_id:p.release_id,name:p.name,size:bytes,sha256:digest,state:'uploaded',data:meta?null:Buffer.from(p.data)};
   remote.assets.set(a.id,a);writes.push({operation:'uploadAsset',name:a.name,declaredBytes:bytes,sha256:digest,largeBinaryBoundaryMocked:Boolean(meta)});return response(a);
  },
 }}};
 const core={getInput:()=> 'fixture-credential',setFailed:x=>failures.push(x),notice:x=>notices.push(x)};
 const context={repo:{owner:'evangjones99-gif',repo:'Roguelike-deckbuilder'},ref:'refs/heads/codex/lanternbound-production',eventName:'push'};
 const fixtureAdapter={
  downloadArtifact:async(pin,expected,dest)=>{
   assert.equal(pin.nativeQAStatus,exactStatus[pin.runId]);
   if(expected.artifactId===pin.evidence.artifactId){const actual=path.join(base,'input-receipts',String(pin.runId),'original-native-evidence.zip');fs.copyFileSync(actual,dest);assert.equal(fs.statSync(dest).size,expected.bytes);assert.equal(sha(fs.readFileSync(dest)),expected.sha256);}
   else{assert(pin.parts.some(p=>p.artifactId===expected.artifactId));fs.writeFileSync(dest,'MOCKED LARGE WRAPPER\n',{flag:'wx'});virtual.set(dest,{bytes:expected.wrapperBytes,sha256:expected.wrapperSHA256});}
  },
  verifyZIP:(actualVerifier,purpose,archive,spec,output,work)=>{
   if(purpose==='evidence')return actualVerifier(purpose,archive,spec,output,work);
   assert.equal(purpose,'part');assert.deepEqual(virtual.get(archive),{bytes:spec.wrapperBytes,sha256:spec.wrapperSHA256});fs.writeFileSync(output,'MOCKED LARGE RAW PART\n',{flag:'wx'});virtual.set(output,{bytes:spec.bytes,sha256:spec.sha256});
  },
  concatenate:(pin,work,output)=>{let total=0;for(const p of pin.parts){assert.deepEqual(virtual.get(path.join(work,p.filename)),{bytes:p.bytes,sha256:p.sha256});total+=p.bytes;}assert.equal(total,pin.bytes);fs.writeFileSync(output,'MOCKED WHOLE ORIGINAL BINARY\n',{flag:'wx'});virtual.set(output,{bytes:pin.bytes,sha256:pin.sha256});},
  digestFile:p=>virtual.has(p)?virtual.get(p).sha256:sha(fs.readFileSync(p)),
  binaryResponse:async(endpoint,purpose,bytes)=>{assert.equal(purpose,'release-asset');const id=Number(endpoint.split('/').at(-1));const a=remote.assets.get(id);assert(a);assert.equal(a.size,bytes);return {fixtureAsset:a};},
  consumeBinary:async(actualConsumer,response,bytes,expected,dest)=>{assert.equal(dest,undefined);const a=response.fixtureAsset;assert(a);assert.equal(a.size,bytes);assert.equal(a.sha256,expected);if(a.data)await actualConsumer(new Response(a.data),bytes,expected);},
 };
 const marker='// BEGIN EXECUTION:';assert.equal(script.split(marker).length,2);
 const [prefix,execution]=script.split(marker);
 const adapter=`
 const fixtureOriginalZIPVerifier = verifyZIP, fixtureOriginalConsumer = consumeBinary;
 downloadArtifact = fixtureAdapter.downloadArtifact;
 verifyZIP = (...args) => fixtureAdapter.verifyZIP(fixtureOriginalZIPVerifier,...args);
 concatenate = fixtureAdapter.concatenate;
 digestFile = fixtureAdapter.digestFile;
 binaryResponse = fixtureAdapter.binaryResponse;
 consumeBinary = (...args) => fixtureAdapter.consumeBinary(fixtureOriginalConsumer,...args);
 `;
 await new AsyncFunction('require','core','context','github','fixtureAdapter',prefix+adapter+marker+execution)(fixtureRequire,core,context,github,fixtureAdapter);
 const report=JSON.parse(fs.readFileSync(path.join(temporary,'installer-research-preservation','report.json')));
 return {name,temporary,scope:'Exact frozen embedded orchestration/control flow with mocked large wrapper/part/concatenation/upload/readback metadata boundaries and synthetic4GiB capacity. Original small ZIP parsers/CRC and small ZIP/receipt readback hashes executed against real bytes. No live API/write/full-original validation.',report,writes,reads,notices,failures};
}
function verifyFourTruthfulReports(result,remote){
 assert.equal(result.failures.length,0);assert.equal(result.report.status,'passed-four-installer-research-draft-preservation');assert.equal(result.report.cases.length,4);
 const actualStatus=result.report.cases.map(c=>c.originalNativeQAStatus);assert.deepEqual(actualStatus,['failed','failed','failed','passed']);
 for(const c of result.report.cases){assert.equal(c.originalNativeQAStatus,exactStatus[c.runId]);assert.equal(c.assets.length,3);assert(c.assets.every(a=>a.fullReadBackVerified));}
 assert.equal(remote.releases.size,4);assert.equal(remote.refs.size,4);assert.equal(remote.assets.size,12);
 for(const pin of pins){
  const release=[...remote.releases.values()].find(x=>x.tag_name===pin.tag);assert(release);assert.equal(release.target_commitish,pin.headSHA);assert(release.draft&&release.prerelease);
  assert(release.body.includes('Pinned research inputs SHA256:'));assert(!release.body.includes('Pinned failed research inputs SHA256:'));
  const receipt=[...remote.assets.values()].find(a=>a.release_id===release.id&&a.name==='preservation-coverage.json');assert(receipt&&receipt.data);const coverage=JSON.parse(receipt.data);
  assert.equal(coverage.statusOfOriginalNativeQA,exactStatus[pin.runId]);assert.equal(coverage.officialGameRelease,false);assert.equal(coverage.newNativeGameplayVerificationPerformed,false);assert.equal(coverage.newUninstallVerificationPerformed,false);
  assert.equal(coverage.steamPublished,false);assert.equal(coverage.requestedDurableAssets.length,3);assert(coverage.notMirroredByThisWorkflow.includes('the five original Actions ZIP part wrappers'));
  assert.equal(sha(receipt.data),receipt.sha256);
 }
}
(async()=>{
 const fresh=createRemote();const full=await execute('fresh-four-origin-success',fresh);verifyFourTruthfulReports(full,fresh);assert.equal(full.writes.filter(x=>x.operation==='createRef').length,4);assert.equal(full.writes.filter(x=>x.operation==='createRelease').length,4);assert.equal(full.writes.filter(x=>x.operation==='uploadAsset').length,12);retained.push({...full,acceptedAsExpected:true});
 const repeat=await execute('matching-complete-idempotent',copyRemote(fresh));verifyFourTruthfulReports(repeat,fresh);assert.equal(repeat.writes.length,0);retained.push({...repeat,acceptedAsExpected:true});
 const partialRemote=copyRemote(fresh);for(const[id,a]of partialRemote.assets)if(a.name==='preservation-coverage.json')partialRemote.assets.delete(id);
 const partial=await execute('matching-partial-drafts-only-missing-receipts',partialRemote);verifyFourTruthfulReports(partial,partialRemote);assert.equal(partial.writes.length,4);assert(partial.writes.every(x=>x.operation==='uploadAsset'&&x.name==='preservation-coverage.json'));retained.push({...partial,acceptedAsExpected:true});
 const changed=copyRemote(fresh);const asset=[...changed.assets.values()].find(x=>x.name.endsWith('.exe'));asset.sha256='0'.repeat(64);
 const refusal=await execute('reject-differing-existing-whole-before-writes',changed);assert.equal(refusal.report.status,'failed');assert.equal(refusal.writes.length,0);assert.equal(refusal.report.phase,'reconstruct-all-four-without-remote-writes');retained.push({...refusal,acceptedAsExpected:false});
 const rejectedSource=fs.readFileSync(path.join(base,'reference-r2','candidate-script.js'),'utf8');const oldRemote=createRemote();const old=await execute('R2-full-control-flow-reproduces-false-R5-diagnostic',oldRemote,rejectedSource);
 assert.equal(old.report.status,'passed-four-installer-research-draft-preservation');assert.equal(old.report.cases[3].runId,36804825248);assert.equal(old.report.cases[3].originalNativeQAStatus,'failed');
 const mismatches=old.report.cases.filter(c=>c.originalNativeQAStatus!==exactStatus[c.runId]);assert.equal(mismatches.length,1);retained.push({...old,acceptedAsExpected:false,negativeOracleDetected:mismatches.map(c=>({runId:c.runId,actual:c.originalNativeQAStatus,expected:exactStatus[c.runId]}))});
 fs.writeFileSync(path.join(base,'storage-flow-results.json'),JSON.stringify({passed:retained.length,failures:0,exactFourOriginStatusOracle:exactStatus,scope:'Control-flow successes/idempotent/partial and refusals with explicitly mocked large binary boundaries; original small ZIP/receipt bytes actually parsed/hashed. Does not prove actual live full originals/uploads.',tests:retained},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({passed:retained.length,failures:0,threeSuccessBranchesTruthful:true,R2FalseR5DiagnosticReproduced:true}));
})().catch(error=>{console.error(error);process.exitCode=1;});
