from pathlib import Path
import json,hashlib,stat,os
B=Path('/workspace/scratch/failed-builder-stock-retention-independent-r1');O=Path('/workspace/scratch/failed-builder-stock-retention-post-independent-r1');root=Path('/workspace/Roguelike-deckbuilder/reviews/root-v0.9-asar-builder-investigation');H=lambda b:hashlib.sha256(b).hexdigest();HF=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();m=json.load(open(B/'FROZEN-FILES.json'));assert H((B/'FROZEN-FILES.json').read_bytes())=='33ac2d93c46b43263940508984b31fabc7bdf5c745134e4057bf332ae38d067a'
for r in m['files']:
 b=(B/r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256']
a=json.load(open(B/'AUDIT.json'));protected=json.load(open(B/'PROTECTED.json'));journalPath=root/'FAILED-STOCK-RETENTION-TRANSACTION.json';raw=journalPath.read_bytes();j=json.loads(raw);assert len(j['completed'])==69;assert set(r['path']for r in j['completed'])==set(r['failed']['path']for r in a['pairs']);assert len({r['path']for r in j['completed']})==69
keys=['st_dev','st_ino','st_nlink','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_blocks'];aliasKeys=['st_dev','st_ino','st_nlink','st_mode','st_uid','st_gid','st_mtime_ns','st_ctime_ns']
def meta(p,follow=False):
 s=p.stat()if follow else p.lstat();return {k:getattr(s,k)for k in keys}|{'atimeNs':s.st_atime_ns,'xattrs':{k:os.getxattr(p,k).hex()for k in os.listxattr(p)}}
def invariant(now,before):return {k:v for k,v in now.items()if k!='atimeNs'}=={k:v for k,v in before.items()if k!='atimeNs'}
rows=[];allocatedAlias=0
for r in a['pairs']:
 f=Path(r['failed']['path']);t=Path(r['reference']['path']);jr=next(x for x in j['completed']if x['path']==str(f));assert f.is_symlink();assert f.readlink()==t and t.is_absolute();assert jr['target']==str(t);assert jr['sha256']==r['failed']['sha256'];l=meta(f);ref=meta(t);follow=meta(f,True);assert stat.S_ISLNK(l['st_mode']);assert stat.S_ISREG(ref['st_mode']);assert invariant(ref,r['reference']['metadata']),(t,'reference metadata changed');assert invariant(follow,ref);assert all(l[k]==jr['afterLstat'][k]for k in aliasKeys);assert l['st_uid']==r['failed']['metadata']['st_uid'];assert l['st_gid']==r['failed']['metadata']['st_gid'];fh=HF(f);th=HF(t);assert fh==th==r['failed']['sha256'];assert f.stat().st_size==r['failed']['metadata']['st_size'];allocatedAlias+=l['st_blocks']*512;rows.append({'path':str(f),'target':str(t),'sha256':fh,'aliasMetadata':l,'referenceMetadata':ref,'followedMetadata':follow,'oldFailedMetadata':r['failed']['metadata']})
excluded=[]
for r in a['excluded']:
 p=Path('/tmp/hollowpact-asar-builder-order-v09-root-r1/linux-unpacked')/r['path'];now=meta(p);assert invariant(now,r['metadata']),(p,'excluded metadata changed');assert HF(p)==r['sha256'];excluded.append({'path':str(p),'sha256':r['sha256'],'metadata':now})
dirs=[]
for n,r in a['directories'].items():
 p=Path(n);now=meta(p);members=sorted(c.name for c in p.iterdir());assert members==r['members'];reference='/hollowpact-relic-bone-native-v09-r1/'in n
 if reference or n.endswith('/resources'):assert invariant(now,r['metadata']),(n,'protected directory metadata changed')
 else:
  for k in ['st_dev','st_ino','st_nlink','st_mode','st_uid','st_gid','st_size','st_blocks']:assert now[k]==r['metadata'][k],(n,k)
  assert now['xattrs']==r['metadata']['xattrs']
 dirs.append({'path':n,'members':members,'before':r['metadata'],'after':now,'mtimeChanged':now['st_mtime_ns']!=r['metadata']['st_mtime_ns'],'ctimeChanged':now['st_ctime_ns']!=r['metadata']['st_ctime_ns'],'referenceDirectory':reference})
for r in [*protected['sourceInputs'],*protected['buildOutputs'],*protected['rawLogsProposals']]:
 p=Path(r['path']);assert p.stat().st_size==r['bytes']and HF(p)==r['sha256'];
 if 'symlink'in r:assert (str(p.readlink())if p.is_symlink()else None)==r['symlink']
assert H((root/'FAILED-STOCK-RETENTION-PROPOSAL-R2.json').read_bytes())==a['proposalSHA256'];assert j['observedFreeDelta']==j['freeTMPAfter']-j['freeTMPBefore'];result={'preManifestSHA256':H((B/'FROZEN-FILES.json').read_bytes()),'rootJournalSHA256':H(raw),'oldPreFiles':len(m['files']),'pairs':rows,'excluded':excluded,'directories':dirs,'protectedCounts':{'sources':len(protected['sourceInputs']),'outputs':len(protected['buildOutputs']),'rawFiles':len(protected['rawLogsProposals'])},'recovery':{'grossOriginalAllocatedBytes':a['recovery']['failedAllocatedBlocksBytes'],'observedAliasAllocatedBytes':allocatedAlias,'measuredSelectedPathsAllocatedReduction':a['recovery']['failedAllocatedBlocksBytes']-allocatedAlias,'rootObservedFreeDelta':j['observedFreeDelta'],'qualification':'Selected path allocation and root observed mount delta differ by symlink allocation/concurrentwriters; not fresh capacity guarantee'},'scope':'Independent exact posttransaction bytes/linktext/reference metadata/excluded/protected audit. No own mutation/native/consumer claims'};(O/'RESULTS.json').open('x').write(json.dumps(result,indent=2)+'\n');(O/'ROOT-TRANSACTION.json').open('xb').write(raw);print(json.dumps({'pairs':len(rows),'excluded':len(excluded),'directories':len(dirs),'sources':len(protected['sourceInputs']),'outputs':len(protected['buildOutputs']),'rawFiles':len(protected['rawLogsProposals']),'referenceMetadataUnchanged':True,'selectedAllocatedReduction':result['recovery']['measuredSelectedPathsAllocatedReduction'],'rootObservedFreeDelta':j['observedFreeDelta'],'changedFailedDirectoryTimes':[r['path']for r in dirs if r['mtimeChanged']or r['ctimeChanged']]}))
