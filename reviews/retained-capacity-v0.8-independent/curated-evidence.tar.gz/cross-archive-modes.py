import json,hashlib,os,stat
from pathlib import Path
def filehash(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while True:
   b=f.read(1024*1024)
   if not b:break
   h.update(b)
 return h.hexdigest()
def inventory(root):
 rows={}
 for p in [root,*sorted(root.rglob('*'))]:
  s=p.lstat();rel=p.relative_to(root).as_posix()
  typ='file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'other'
  r={'type':typ,'mode':oct(stat.S_IMODE(s.st_mode)),'size':s.st_size,'blocks':s.st_blocks,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink}
  if typ=='file':r['sha256']=filehash(p)
  if typ=='symlink':r['target']=os.readlink(p)
  rows[rel]=r
 return rows
OUT=Path(__file__).parent
results=[]
for crossno,nativeno in ((3,6),(4,7)):
 cross=json.loads((OUT/f'case-{crossno:02d}.json').read_text())
 native=json.loads((OUT/f'case-{nativeno:02d}.json').read_text())
 archive=Path(cross['official_archive']);root=Path(native['working_directory'])
 actual=inventory(root);assert actual==native['working_inventory']
 assert filehash(archive)==cross['archive_sha256_before']
 files={k:v for k,v in actual.items() if v['type']=='file'}
 afiles={k:v for k,v in cross['archive_inventory'].items() if v['type']=='file'}
 assert set(files)==set(afiles)
 for k,f in files.items():
  a=afiles[k]
  assert all(f[t]==a[t] for t in ('type','size','sha256','mode')),k
 assert filehash(archive)==cross['archive_sha256_after']
 record={'working_directory':str(root),'official_mode_containing_archive':str(archive),'official_native_archive_also_content_exact':native['official_archive'],'mode_containing_archive_sha256':cross['archive_sha256_before'],'native_archive_sha256':native['archive_sha256_before'],'working_inventory_unchanged':True,'all_files_content_and_modes_match_mode_containing_archive':True,'file_count':len(files),'file_bytes':sum(f['size'] for f in files.values()),'allocated_file_bytes':sum(f['blocks']*512 for f in files.values()),'working_inventory_source':f'case-{nativeno:02d}.json','mode_containing_archive_inventory_source':f'case-{crossno:02d}.json','limitation':'ZIP directories were implicit; their POSIX modes are preserved in the inventory sidecar, not claimed contained in ZIP.'}
 results.append(record);print(json.dumps(record),flush=True)
(OUT/'CROSS-ARCHIVE-MODES.json').write_text(json.dumps(results,indent=2)+'\n')
