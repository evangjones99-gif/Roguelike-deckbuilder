import hashlib,json,os,stat,tarfile,zipfile,time
from pathlib import Path

OUT=Path(__file__).parent
RELEASE=Path('/workspace/Roguelike-deckbuilder/releases')
SCRATCH=Path('/workspace/scratch')
CASES=[
 ('0.4.0','linux-x64.tar.gz','retained-working-linux-0.4.0-da553781de9d'),
 ('0.5.0','linux-x64.tar.gz','retained-working-linux-0.5.0-d6221bf764ba'),
 ('0.4.0','windows-x64.zip','retained-working-windows-0.4.0-da553781de9d'),
 ('0.5.0','windows-x64.zip','retained-working-windows-0.5.0-d6221bf764ba'),
 ('0.3.0','windows-x64.zip','native-windows-v04/retained-working-v0.3-win-unpacked'),
 ('0.4.0','windows-native-tested-x64.zip','native-windows-v04/run-36772521612-1/win-unpacked'),
 ('0.5.0','windows-native-tested-x64.zip','native-windows-v05/run-36782560136-1/native-extracted'),
]
def digest(f):
 h=hashlib.sha256()
 while True:
  b=f.read(1024*1024)
  if not b: return h.hexdigest()
  h.update(b)
def filehash(p):
 with open(p,'rb') as f:return digest(f)
def inventory(root):
 rows={}
 for p in [root,*sorted(root.rglob('*'))]:
  s=p.lstat();rel=p.relative_to(root).as_posix()
  typ='file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'other'
  r={'type':typ,'mode':oct(stat.S_IMODE(s.st_mode)),'size':s.st_size,'blocks':s.st_blocks,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink}
  if typ=='file': r['sha256']=filehash(p)
  if typ=='symlink':r['target']=os.readlink(p)
  rows[rel]=r
 return rows
def archive_inventory(p):
 rows={}
 if p.name.endswith('.zip'):
  with zipfile.ZipFile(p) as z:
   for i in z.infolist():
    assert i.filename not in rows,'duplicate archive member'
    assert not i.filename.startswith('/') and '..' not in Path(i.filename).parts,'unsafe archive path'
    r={'type':'directory' if i.is_dir() else 'file','size':i.file_size,'create_system':i.create_system,'mode':oct(stat.S_IMODE(i.external_attr>>16)) if i.create_system==3 else None}
    if not i.is_dir():
     with z.open(i) as f:r['sha256']=digest(f)
    rows[i.filename.rstrip('/') or '.']=r
 else:
  with tarfile.open(p,mode='r|gz') as t:
   for i in t:
    n=i.name[2:] if i.name.startswith('./') else i.name
    assert n not in rows,'duplicate archive member'
    assert not n.startswith('/') and '..' not in Path(n).parts,'unsafe archive path'
    r={'type':'file' if i.isfile() else 'directory' if i.isdir() else 'symlink' if i.issym() else 'other','size':i.size,'mode':oct(i.mode)}
    if i.isfile():r['sha256']=digest(t.extractfile(i))
    if i.issym():r['target']=i.linkname
    rows[n]=r
 return rows

all_results=[]
for v,kind,relative in CASES:
 p=RELEASE/v/f'hollowpact-{v}-{kind}';root=SCRATCH/relative
 expected=dict(line.split(None,1)[::-1] for line in (RELEASE/v/'SHA256SUMS').read_text().strip().splitlines())[p.name]
 before_archive=filehash(p);assert before_archive==expected
 before=inventory(root);archive=archive_inventory(p);after=inventory(root)
 after_archive=filehash(p);assert before==after and after_archive==expected
 files={k:x for k,x in before.items() if x['type']=='file'}
 afiles={k:x for k,x in archive.items() if x['type']=='file'}
 issues=[]; mode_issues=[]
 for k,x in files.items():
  a=afiles.get(k)
  if not a:issues.append({'path':k,'reason':'missing-archive-member'});continue
  if a['size']!=x['size'] or a['sha256']!=x['sha256']:issues.append({'path':k,'reason':'content-mismatch','working_sha256':x['sha256'],'archive_sha256':a['sha256']})
  if a['mode']!=x['mode']:mode_issues.append({'path':k,'working_mode':x['mode'],'archive_mode':a['mode']})
 extra=sorted(set(afiles)-set(files))
 links=[k for k,x in before.items() if x['type'] not in ('file','directory')]
 passed=not issues and not extra and not links
 exactmode=passed and not mode_issues
 result={'working_directory':str(root),'official_archive':str(p),'official_ledger':str(RELEASE/v/'SHA256SUMS'),'archive_sha256_before':before_archive,'archive_sha256_after':after_archive,'archive_size':p.stat().st_size,'working_file_count':len(files),'working_file_bytes':sum(x['size'] for x in files.values()),'working_allocated_file_bytes':sum(x['blocks']*512 for x in files.values()),'working_directory_count':sum(x['type']=='directory' for x in before.values()),'working_unchanged_before_after':before==after,'all_file_content_exact':passed,'all_file_content_and_archive_modes_exact':exactmode,'content_issues':issues,'extra_archive_files':extra,'mode_issues':mode_issues,'nonregular_leaves':links,'working_inventory':before,'archive_inventory':archive}
 name=f'case-{len(all_results)+1:02d}.json';(OUT/name).write_text(json.dumps(result,indent=2)+'\n');all_results.append({'report':name,**{k:x for k,x in result.items() if k not in ('working_inventory','archive_inventory','mode_issues','content_issues')}})
 print(json.dumps({k:x for k,x in all_results[-1].items() if k not in ('nonregular_leaves','extra_archive_files')}) ,flush=True)
(OUT/'SUMMARY.json').write_text(json.dumps({'cases':all_results,'strict_archive_mode_accepted_bytes':sum(x['working_file_bytes'] for x in all_results if x['all_file_content_and_archive_modes_exact']),'content_exact_bytes_including_mode_unsupported':sum(x['working_file_bytes'] for x in all_results if x['all_file_content_exact'])},indent=2)+'\n')
