# Independent preservation review: ACCEPT combined packets

ACCEPT the combined three-packet preservation set for the two reviewed storage actions. Independent streaming checks verified every archive byte hash, ordered regular-member inventory, member length/whole SHA256, and current original body. Counts108+22+27=157members represent144unique original paths;13copies are intentional overlap, not extra independent evidence. No further important bounded receipt omission was found within the reviewed source/post evidence chains.

The original two packets alone omitted important external bounded inputs. This finding remains part of the review; acceptance requires the immutable supplement. ROOT preserved the original packets unchanged instead of rewriting their inventories/outcomes.

## Exact packets and verification

Under /workspace/Roguelike-deckbuilder/reviews:

| Packet | Members | EVIDENCE.tar.gz bytes | Archive SHA256 |
| --- | ---: | ---: | --- |
| reviewed-v060-source-zip-retirement-2026-10-01 |108|940843|279a988da0296f217d5191277850c5f0a2a584111ec6381efa6103f17bc05e94|
| reviewed-trace-media-alias-recovery-2026-10-01 |22|25642|4af14b984f3bd1b6bc49288dfdd8a73c6466d7d89b6f3a6ca5eb8af8d5f6f7bc|
| reviewed-retirement-preservation-supplement-2026-10-01-r1 |27|877330|bee7b9450b7212941a475d0ad88b7303cfe03af7dc8b36df22f68d213ed1c8c5|

PRESERVATION.json hashes in this order:62d85e3624ebd44305a534c029b7930924ab097176c1d3d00d59db3e8fac0237;8b46e2b1e5e757146bc60bc34401bbe7723c1f87658e4bc4e1d23910b54c8ce0;ca4f2d0e6c53a306f357793094c538ac2d66c9848f06364984c37093ce96f673. OUTCOME.md hashes:4031670758ab596b1244a63b534a32dd4f2ec475463b0ab5e3cbd0e56e4afeec;46c60c2448d5b025b1f5ffa742376935521fcdb2c345b32aa0d88d62c16876fb;963111f1d35c86e325d1e427cf85d929dd38b1b4e22cf53315c51fb839d1d0e1.

CHECKS.json24229B/SHA25674cb2bb8fb55027c53860f369fb0170c82b61467788aced3a674d5244bc84b70 records all157indexed member results, all archive/manifest/outcome pins and resource samples. Indexes refer to the exact hash-bound PRESERVATION arrays; this avoids duplicating their full path maps in the independent packet.

Archive/original reads used anchored no-follow root-to-parent chains, O_RDONLY/O_NOFOLLOW/O_NOATIME regular FDs,64KiB hashing/extraction chunks and before/after FD/name/chain checks. Each gzip was fully drained to validate its end/trailer; tar end padding had no unexplained nonzero bytes. Every member was a regular file with exact declared relative name/size, no link/directory/device entry or duplicate name. Only normal PAX mtime/path keys were allowed, with path exactly matching its declared member. Original bodies and archive header modes matched current originals. Header uid/gid defaults and filesystem inode/xattrs are not a complete restored-filesystem identity guarantee; exact proof bodies are the preservation scope.

## Initial omission and immutable correction

Prefix-based root selection omitted the original99177B reachable-object ledger,8531B restore source and other small accepted STATIC-AUDIT receipts outside those roots. The trace packet omitted the10032B PRESERVED-PARTIAL-TRACE-REFERENCES ledger and6654B frozen handoff inventory used to establish31retained paths/27hashes. Recorded hashes inside prior reports did not substitute for preserving those input bodies in this archive set.

The supplement now includes every one of the23STATIC-AUDIT input receipts at its accepted length/SHA, including original closure/restore controls, historical failure/incomplete notes, release manifest and canonical preservation reviews. It includes both frozen trace-ledger files and the two preservation-author scripts. Their member/current-original hashes were independently verified. The frozen handoff correctly binds the31-row trace ledger; accepted source/post reports for both actions retain their exact previously reviewed hashes. Rejected source iterations, size failures and actual refused coverage/pager evidence remain in the first packet. No prior failure is rewritten as success.

An initial reviewer stream pass refused a normal long-name PAX path key at member67. The decoded path/size already matched the manifest; the over-strict helper was corrected to accept only exact path/mtime. This was a review-helper refusal, not an actual archive mismatch, and is recorded in CHECKS.json.

## Outcome wording, durability and limits

The old-ZIP outcome correctly distinguishes intentional container-encoding loss from verified logical/Git preservation, producer judgment from independent preference, and measured2,863,767,552B utility available-space delta from exclusive causality. It claims no fresh post-deletion restore/large-body rehash or new game milestone. Trace outcome records all eight paths/raw PNGs retained through immutable hardlinks, intentional inode/time changes, measured0→8,302,592B available space rather than18,493,440B prospective allocation,27body hashes and four ZIP path/size-only checks. No raw trace archive completeness or fresh archive/body/product approval is added. Future aliases must remain immutable; changed art requires new files/inodes or atomic replacement preserving history.

The author seal script fsyncs archive data but has no explicit manifest/outcome/directory fsync. ROOT subsequently reports fsync of every new packet file, packet directories and reviews parent without changing bytes. That closure is a ROOT tool-result fact communicated to this reviewer, not an independently witnessed syscall trace or crash/power-loss experiment. Exact body checks plus recorded closure support preservation; no crash-recovery guarantee is claimed.

These are bounded evidence archives, not self-contained game/trace media, retained multi-GiB bundle copies, all raw source/art/data, complete tool environment or portable completed Playwright traces. Those external originals remain subject to their recorded retention/immutability rules. No old ZIP, retained bundle, large native/web archive or PNG body was read here; no restore, Git/ref mutation, browser/Node/native run or protected-source mutation occurred. The two small evidence archives and small supplement were expressly authorized for streaming inspection; gameplay kept its exclusive heavy window.

Helper peak RSS12,189,696B; initial/final cgroup headroom739,786,752B/739,057,664B, each above24MiB+512MiB reserve. Guards also ran per member. Samples are not a certified global minimum. This report approves the combined proof preservation only, not new cleanup or game/platform/Steam/human-fun acceptance. Independent read descriptors closed; only this new external review packet was written.
