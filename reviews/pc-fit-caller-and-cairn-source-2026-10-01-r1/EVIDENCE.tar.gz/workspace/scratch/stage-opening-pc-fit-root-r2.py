import os,json,hashlib,shutil,time
from pathlib import Path
base=Path('/workspace/scratch/first-five-opening-readout-stage-r1');stage=Path('/workspace/scratch/first-five-opening-pc-fit-stage-r2');author=Path('/workspace/scratch/pc-opening-fit-root-r2/candidate')
freeze=json.loads(Path('/workspace/scratch/first-five-opening-readout-runtime-freeze-root-r1.json').read_text())
def digest(p):
    h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
    try:
        s=os.fstat(fd)
        while b:=os.read(fd,65536):h.update(b)
        assert os.fstat(fd)==s
    finally:os.close(fd)
    return h.hexdigest()
assert freeze['sourceDigest']=='0cd0cbca6428e29f899cde48e0d759a1441e8b5c9271889b8f464b75e1f09571'
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h,rel
replacements={'src/main.ts':'10cafc39cfb8b922cd24d14f2d4e2ab501facd1d2e58632c0d5c9ff2a7d13364','src/compact-readout.css':'dd2d8bc02ef77844a650626dccbd881e64faa3f1cdd1ab4c242419fb3606d06c'}
for rel,h in replacements.items():assert digest(author/rel)==h
stage.mkdir(mode=0o700)
for current,names,files in os.walk(base,followlinks=False):
    names[:]=[n for n in names if n not in ['dist','node_modules','public']]
    for name in names:assert not (Path(current)/name).is_symlink()
    for name in files:
        source=Path(current)/name;assert not source.is_symlink()
        rel=source.relative_to(base).as_posix();target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
        source=author/rel if rel in replacements else source
        fd=os.open(source,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
        try:
            with target.open('xb') as f:
                while b:=os.read(fd,65536):f.write(b)
                f.flush();os.fsync(f.fileno())
        finally:os.close(fd)
(stage/'public').symlink_to(base.joinpath('public').resolve(),target_is_directory=True)
(stage/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules',target_is_directory=True)
inputs={**freeze['inputs'],**replacements}
for rel,h in inputs.items():assert digest(stage/rel)==h
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h
record={'stage':str(stage),'status':'PC OPENING FIT R2 STAGED; UNBUILT; UNPROMOTED','baselineStage':str(base),'baselineSourceDigest':freeze['sourceDigest'],'inputs':dict(sorted(inputs.items())),'inputCount':len(inputs),'sourceDigest':hashlib.sha256(json.dumps(dict(sorted(inputs.items())),separators=(',',':')).encode()).hexdigest(),'onlyChangedInputs':list(replacements),'sharedPublicRoot':str(base.joinpath('public').resolve()),'baselineUnchanged':True,'limitations':'No new playable/brower/human-fun/art/release acceptance.'}
p=Path('/workspace/scratch/first-five-opening-pc-fit-assembly-root-r2.json')
with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
for folder in [stage,stage.parent]:fd=os.open(folder,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({k:v for k,v in record.items() if k!='inputs'}))
