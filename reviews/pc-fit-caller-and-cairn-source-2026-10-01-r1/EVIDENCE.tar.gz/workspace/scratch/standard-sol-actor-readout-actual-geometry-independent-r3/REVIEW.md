# Actual exported geometry — R3 focused pass

Outcome: **PASS for actual exported geometry only.** The exact granted runner/case/declaration and every declared body pin were verified before launch. R1's 64 MiB refusal and R2's missing-dependency failure remain untouched.

The unchanged focused logic imported actual R2 layout exports from the new byte-exact layout/budget module pair and actual R3 exports from `/workspace/scratch/first-five-opening-readout-stage-r1`. For 2, 3 and 6 slots at PC widths 1440 and 1920, both resize directions and endpoint/interior interpolation produced **176 invariant comparisons**. R2 reproduced the expected negative controls: **44 projected-readout cap/ownership violations** and **24 interpolation cap violations**. R3 passed centered capped within-cell readouts, including narrow-cell full-lane ownership. Cell/body rectangles and every readout's transformed vertical top/height remained equal to R2.

Whole phase **0.474 seconds**, Node exit 0 with natural child wait. All admission/running/post-wait/final sample rows passed the separate **128 MiB total / unchanged 512 MiB reserve** checks. The sampled own-resident peak was **76,611,584 bytes**; cgroup delta and remaining headroom were independently constrained. Point samples do not establish a continuous aggregate peak or performance result. `POST-CLOSE-SUPPLEMENT.json` retains exact post-close memory.max/events and sampled extrema. The granted runner did not capture a prelaunch memory.events snapshot, so no before/after event-delta claim is made.

Node PID 454029 is absent after wait. Observed esbuild PID 454037 remains the same recorded start identity in nonlive state Z with zero RSS. This is qualified owned-session closure with no observed live workload, not universal process absence or removal of the zombie. No global cleanup occurred.

All runner/case/layout/budget/freeze before-and-after body hashes and inode/mode/size/mtime/ctime checks pass, with ordinary-read atime qualified. Full receipts are in `RESULT.json`, with exact original case results in `stdout.log` and an empty `stderr.log`. No browser, server, build, package installation, new cases/framework, engine fixture, shared source edit or retry occurred.

This accepts the focused exported geometry regression. Actual browser binding/PC resize/font wrapping/convergence, accessible input, terminal survivor/death labels, gameplay and human-fun acceptance remain separate. Geometry correctness does not promote the game or establish a whole-build re-audit.
