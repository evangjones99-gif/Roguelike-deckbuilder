import assert from 'node:assert/strict';
import * as r2 from '/workspace/scratch/standard-sol-actor-readout-actual-geometry-independent-r3/repro-r2/battlefield-layout.ts';
import * as r3 from '/workspace/scratch/first-five-opening-readout-stage-r1/src/battlefield-layout.ts';
const names = ['intentRect','inspectRect','identityRect','statsRect','statusRect'] as const;
let comparisons=0, r2ProjectionFailures=0, r2InterpolationFailures=0;
const close=(a:number,b:number)=>assert.ok(Math.abs(a-b)<1e-7, `${a} != ${b}`);
function invariant(c:any) {
 for(const name of names){const r=c[name];assert.ok(r.width>0 && r.width<=240+1e-7);assert.ok(r.left>=c.left-1e-7 && r.left+r.width<=c.left+c.width+1e-7);close(r.left+r.width/2,c.left+c.width/2);assert.ok(r.height>=0);}
 // A readout occupies the whole lane only when the creature cell itself is narrower than the cap.
 if(c.width<240) for(const name of names) close(c[name].width,c.width);
 else for(const name of names) close(c[name].width,240);
}
function preserved(old:any, fresh:any){for(const k of ['left','top','width','height'])close(old[k],fresh[k]);assert.deepEqual(old.bodyRect,fresh.bodyRect);for(const name of names){close(old[name].top,fresh[name].top);close(old[name].height,fresh[name].height);}comparisons++;}
for(const count of [2,3,6]){
 const config={allies:count,enemies:count,intentRows:4,statsRows:2,identityRows:2};
 const old1440=r2.createBattlefieldLayout(1440,0,config),old1920=r2.createBattlefieldLayout(1920,0,config);
 const new1440=r3.createBattlefieldLayout(1440,0,config),new1920=r3.createBattlefieldLayout(1920,0,config);
 assert.deepEqual(old1440,new1440);assert.deepEqual(old1920,new1920);
 for(const side of ['ally','enemy'] as const)for(let slot=0;slot<count;slot++){
  invariant(new1440[side][slot]);invariant(new1920[side][slot]);
  for(const [a,b] of [[old1440[side][slot],old1920[side][slot]],[old1920[side][slot],old1440[side][slot]]]){
   for(const blend of [0,.5,1]){const old=r2.interpolateCell(a,b,blend),fresh=r3.interpolateCell(a,b,blend);preserved(old,fresh);invariant(fresh);if(Math.abs(old.inspectRect.width-Math.min(240,old.width))>1e-7)r2InterpolationFailures++;}
  }
  for(const [cell,scale] of [[old1440[side][slot],1920/1440],[old1920[side][slot],1440/1920]] as const){const old=r2.projectCell(cell,scale,1.125),fresh=r3.projectCell(cell,scale,1.125);preserved(old,fresh);invariant(fresh);if(old.inspectRect.width>240+1e-7||Math.abs(old.inspectRect.width-Math.min(240,old.width))>1e-7)r2ProjectionFailures++;}
 }
}
assert.ok(r2ProjectionFailures>0,'R2 expected projection counterexample must fail');assert.ok(r2InterpolationFailures>0,'R2 expected interpolation cap crossing must fail');
console.log(JSON.stringify({status:'PASS geometry only',comparisons,r2ProjectionFailures,r2InterpolationFailures,counts:[2,3,6],widths:[1440,1920],preserved:'cell/body rectangles and all readout vertical extents',limitations:'No browser font/layout convergence, input, actual binding, game fixtures, or promotion acceptance'}));
