"""Original direct-pixel Cairn Hound anatomy; stdlib only. No external image input.
Every pose supplies its own anatomical polygons. Indexed native64x64, no affine
cutout transform, smoothing, antialias, generated-image sampling or UI text.
"""
import os,json,struct,zlib,hashlib,time,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
ROOT='/workspace/scratch/standard-sol-cairn-pixel-assets-author-r1/draw-r2'
PAL=[(0,0,0),(14,20,23),(27,37,42),(43,58,62),(65,81,82),(77,91,88),(108,122,111),(149,158,137),(190,196,164),(57,91,91),(88,125,117),(135,173,145),(194,217,170),(85,75,59),(125,107,75),(213,176,98)]
# Rearthreequarter, facing northeast; coordinates are individually drawn landmarks.
# Layer order: far legs,tail,near legs,body,neck,ears,head,muzzle,stone/shade details.
POSES=[
 dict(name='arrival0',role='coalescing crouch',feet=[[18,58],[38,55]],tail=[(17,43),(10,46),(7,50),(12,49),(18,47)],
 rearFar=[(26,45),(28,48),(27,53),(30,55),(26,56),(24,53),(24,49)],
 frontFar=[(35,42),(39,43),(39,49),(42,51),(39,52),(36,49)],
 rearNear=[(19,43),(24,46),(23,50),(18,53),(20,56),(23,56),(23,58),(17,58),(15,55),(15,51),(18,49)],
 frontNear=[(31,44),(36,45),(36,49),(40,52),(41,55),(36,55),(33,52),(30,49)],
 body=[(13,41),(18,37),(24,36),(28,37),(33,35),(38,37),(40,42),(36,47),(29,49),(20,48),(15,45)],
 neck=[(32,38),(33,34),(37,31),(41,33),(41,39),(37,43)],
 earFar=[(40,31),(42,25),(45,33)],earNear=[(34,32),(33,24),(39,30),(39,34)],
 head=[(33,33),(36,29),(41,30),(44,33),(44,37),(39,40),(34,38)],
 muzzle=[(42,34),(47,33),(50,35),(50,38),(45,39),(41,37)],eye=[43,34],nose=[49,36],
 plates=[[(19,38),(24,36),(27,38),(24,41),(19,41)],[(28,38),(32,35),(36,37),(34,41),(29,42)]],
 shade=[[(16,42),(22,43),(25,47),(19,46)],[(29,43),(36,41),(35,45),(30,47)]],
 glow=[[(10,51),(12,51),(11,54),(8,55)],[(27,32),(29,31),(28,34)],[(44,42),(46,41),(46,43)]],marks=[(17,43),(22,42),(30,44),(34,43)]),
 dict(name='arrival1',role='weight rises onto paws',feet=[[19,58],[40,55]],tail=[(17,40),(11,43),(8,48),(12,47),(19,44)],
 rearFar=[(26,41),(29,46),(27,51),(30,53),(29,55),(25,54),(24,49),(24,44)],
 frontFar=[(36,36),(40,39),(40,46),(43,48),(42,50),(38,49),(36,44)],
 rearNear=[(18,39),(24,43),(24,48),(20,51),(18,53),(21,56),(24,56),(24,58),(18,58),(15,54),(16,49),(19,46)],
 frontNear=[(32,37),(37,39),(38,46),(40,51),(43,53),(43,55),(37,55),(35,51),(34,45),(31,41)],
 body=[(13,37),(18,32),(24,32),(28,31),(32,29),(37,30),(40,35),(39,40),(33,45),(26,47),(19,45),(15,42)],
 neck=[(32,31),(33,26),(37,24),(42,27),(42,34),(37,39)],
 earFar=[(42,22),(43,16),(46,24)],earNear=[(36,23),(34,15),(41,21),(41,25)],
 head=[(34,25),(38,21),(42,22),(47,25),(46,30),(41,33),(36,31)],
 muzzle=[(45,26),(49,25),(52,27),(52,30),(47,31),(44,29)],eye=[45,26],nose=[51,28],
 plates=[[(18,33),(23,31),(27,33),(25,37),(20,38)],[(27,33),(31,29),(36,31),(35,35),(30,37)]],
 shade=[[(16,37),(21,38),(26,44),(21,44),(17,41)],[(29,38),(37,36),(35,42),(29,44)]],
 glow=[[(10,49),(12,49),(10,52),(8,53)],[(25,28),(27,27),(27,30)],[(43,37),(45,36),(45,38)]],marks=[(18,38),(22,38),(30,40),(34,39)]),
 dict(name='idle0',role='ready weight-bearing stance',feet=[[20,58],[40,55]],tail=[(17,38),(11,42),(8,46),(9,49),(12,46),(19,43)],
 rearFar=[(27,40),(30,44),(27,50),(29,52),(31,53),(29,55),(25,53),(24,49),(25,44)],
 frontFar=[(37,33),(41,37),(41,43),(43,47),(46,48),(45,50),(40,49),(38,43)],
 rearNear=[(18,38),(25,42),(25,46),(22,50),(18,52),(20,56),(24,56),(24,58),(18,58),(15,54),(15,50),(19,46)],
 frontNear=[(32,35),(37,37),(39,43),(39,49),(42,52),(44,53),(44,55),(38,55),(35,51),(35,46),(32,41)],
 body=[(13,35),(18,30),(24,30),(28,28),(32,29),(35,27),(39,29),(41,34),(39,40),(33,44),(26,46),(19,44),(15,41)],
 neck=[(31,30),(32,24),(37,22),(42,25),(43,31),(38,37)],
 earFar=[(42,20),(44,13),(48,22)],earNear=[(35,20),(34,11),(41,18),(41,23)],
 head=[(33,23),(37,18),(42,19),(47,22),(47,27),(42,31),(36,29),(32,26)],
 muzzle=[(45,23),(50,22),(53,24),(53,27),(49,29),(44,27)],eye=[45,23],nose=[52,25],
 plates=[[(18,31),(23,29),(27,31),(26,35),(20,37),(17,35)],[(26,31),(30,28),(35,29),(36,33),(31,36),(27,35)]],
 shade=[[(15,36),(21,36),(24,41),(22,43),(17,40)],[(28,37),(35,34),(38,36),(34,41),(29,43)]],
 glow=[[(10,48),(12,47),(12,49)],[(29,26),(31,25),(31,27)]],marks=[(18,37),(22,38),(30,39),(33,38)]),
 dict(name='idle1',role='breath and ear/forepaw adjustment',feet=[[20,58],[42,55]],tail=[(17,39),(11,43),(10,49),(12,47),(20,43)],
 rearFar=[(27,41),(29,44),(27,50),(30,52),(31,54),(27,55),(25,52),(25,47)],
 frontFar=[(36,34),(40,38),(40,44),(44,47),(45,49),(41,50),(38,47),(36,41)],
 rearNear=[(18,39),(25,43),(24,47),(21,50),(18,53),(21,56),(24,56),(24,58),(18,58),(16,54),(15,50),(19,46)],
 frontNear=[(33,35),(38,38),(40,44),(40,50),(43,52),(45,53),(45,55),(39,55),(37,52),(36,46),(33,41)],
 body=[(13,36),(18,31),(24,31),(28,29),(32,30),(36,28),(40,30),(42,35),(39,41),(33,45),(26,47),(19,45),(15,42)],
 neck=[(32,31),(33,25),(38,23),(43,26),(43,32),(38,38)],
 earFar=[(43,20),(47,15),(48,23)],earNear=[(36,20),(36,11),(42,19),(41,24)],
 head=[(34,24),(38,19),(43,20),(48,23),(47,28),(43,32),(37,30),(33,27)],
 muzzle=[(46,24),(51,23),(54,25),(53,28),(49,30),(45,28)],eye=[46,24],nose=[53,26],
 plates=[[(18,32),(23,30),(27,32),(26,36),(20,38),(17,36)],[(27,32),(31,29),(36,30),(36,34),(32,37),(28,36)]],
 shade=[[(16,37),(22,38),(24,43),(19,43),(17,40)],[(29,38),(36,35),(38,37),(35,42),(30,44)]],
 glow=[[(11,48),(13,47),(12,50)]],marks=[(19,38),(22,39),(30,40),(34,39)]),
 dict(name='anticipation',role='hind hocks load and jaw dips',feet=[[17,58],[44,55]],tail=[(18,42),(11,43),(6,47),(9,49),(14,46),(21,46)],
 rearFar=[(27,44),(30,47),(28,52),(31,54),(30,55),(26,54),(25,49)],
 frontFar=[(37,39),(41,41),(42,48),(47,50),(47,52),(41,52),(38,47)],
 rearNear=[(18,41),(25,44),(25,49),(20,51),(15,53),(17,56),(21,56),(21,58),(15,58),(12,54),(15,50),(19,47)],
 frontNear=[(32,41),(38,42),(39,47),(43,51),(47,53),(47,55),(40,55),(37,52),(35,47),(31,44)],
 body=[(13,39),(18,34),(24,34),(29,34),(33,34),(38,35),(42,39),(41,43),(34,47),(27,49),(20,47),(15,44)],
 neck=[(33,36),(36,30),(41,29),(45,32),(45,37),(40,43)],
 earFar=[(44,29),(46,22),(50,32)],earNear=[(38,28),(33,21),(42,26),(43,31)],
 head=[(36,32),(40,27),(45,28),(50,31),(49,36),(44,39),(39,38),(35,35)],
 muzzle=[(48,32),(53,31),(56,34),(55,37),(51,38),(47,35)],eye=[48,32],nose=[55,35],
 plates=[[(18,35),(23,33),(27,35),(26,39),(20,41),(16,39)],[(27,36),(32,33),(37,35),(37,39),(32,42),(28,41)]],
 shade=[[(15,40),(20,41),(24,46),(20,46),(16,43)],[(29,42),(36,39),(39,40),(35,45),(29,47)]],
 glow=[[(8,48),(10,47),(10,50)]],marks=[(18,42),(22,42),(31,43),(35,42)]),
 dict(name='contact0',role='open canine bite and forward extension',feet=[[15,58],[47,49]],tail=[(19,39),(12,38),(6,40),(5,43),(10,42),(19,43)],
 rearFar=[(26,40),(30,43),(27,49),(26,53),(29,55),(25,56),(23,53),(23,48)],
 frontFar=[(38,30),(43,32),(44,38),(49,41),(52,42),(52,44),(47,44),(41,39),(38,35)],
 rearNear=[(18,37),(25,40),(24,46),(19,50),(13,53),(14,56),(18,56),(18,58),(12,58),(10,55),(15,49),(19,43)],
 frontNear=[(33,32),(40,34),(43,39),(44,43),(49,45),(52,46),(52,48),(47,49),(41,46),(38,41),(33,38)],
 body=[(14,34),(19,29),(24,29),(29,26),(34,25),(39,25),(42,30),(41,35),(35,40),(28,44),(21,43),(16,40)],
 neck=[(34,27),(37,21),(42,19),(47,22),(47,28),(42,34)],
 earFar=[(46,18),(48,10),(52,20)],earNear=[(40,18),(38,8),(45,16),(46,22)],
 head=[(37,21),(41,16),(46,17),(51,20),(51,24),(46,28),(40,27),(36,24)],
 muzzle=[(49,21),(54,20),(58,23),(57,25),(53,26),(48,24)],eye=[49,21],nose=[57,23],
 jaw=[(48,25),(53,28),(57,27),(55,31),(51,31),(46,28)],
 plates=[[(19,30),(24,28),(28,30),(27,34),(21,36),(17,34)],[(28,28),(33,25),(38,26),(38,30),(33,33),(29,33)]],
 shade=[[(17,35),(23,35),(26,40),(21,42),(18,39)],[(30,35),(37,31),(39,33),(36,38),(30,41)]],
 glow=[[(7,42),(10,41),(9,44)]],marks=[(20,35),(23,36),(32,36),(35,35)]),
 dict(name='contact1',role='bite closes with shoulder over paw',feet=[[17,58],[47,52]],tail=[(19,39),(12,40),(8,44),(7,47),(11,45),(20,43)],
 rearFar=[(27,42),(29,45),(27,50),(29,53),(31,54),(28,56),(25,53),(24,48)],
 frontFar=[(40,32),(44,35),(45,42),(49,45),(53,46),(53,48),(48,48),(43,44),(40,38)],
 rearNear=[(19,39),(25,42),(24,47),(21,51),(15,54),(17,56),(21,56),(21,58),(15,58),(13,55),(17,50),(20,45)],
 frontNear=[(35,34),(41,36),(44,42),(45,46),(49,48),(52,49),(52,51),(47,52),(42,49),(40,43),(35,39)],
 body=[(15,36),(20,31),(25,31),(30,29),(35,28),(40,29),(44,33),(43,38),(37,42),(29,46),(22,45),(17,42)],
 neck=[(35,30),(39,24),(44,22),(49,25),(49,31),(43,37)],
 earFar=[(48,21),(50,14),(53,23)],earNear=[(42,21),(41,11),(48,19),(48,25)],
 head=[(39,24),(43,19),(48,20),(53,23),(52,28),(47,32),(41,30),(38,27)],
 muzzle=[(51,25),(55,24),(58,27),(57,30),(53,31),(49,28)],eye=[51,25],nose=[57,28],
 plates=[[(20,32),(25,30),(29,32),(28,36),(22,38),(18,36)],[(29,31),(34,28),(39,29),(40,33),(34,36),(30,36)]],
 shade=[[(18,37),(24,38),(27,43),(23,44),(19,41)],[(31,38),(38,34),(41,36),(37,41),(31,44)]],
 glow=[[(9,45),(11,44),(10,47)]],marks=[(21,38),(25,39),(33,39),(37,38)]),
 dict(name='recovery',role='withdrawn jaw and reweighted chest',feet=[[21,58],[40,55]],tail=[(18,40),(12,45),(11,50),(14,46),(21,44)],
 rearFar=[(28,43),(31,46),(28,51),(31,53),(30,55),(26,54),(25,49)],
 frontFar=[(35,36),(39,39),(39,45),(43,48),(43,50),(39,50),(36,46)],
 rearNear=[(20,40),(26,44),(25,48),(23,51),(19,53),(22,56),(25,56),(25,58),(19,58),(17,54),(17,50),(21,47)],
 frontNear=[(31,38),(36,40),(37,46),(38,51),(42,53),(42,55),(37,55),(34,51),(34,46),(31,42)],
 body=[(15,37),(20,32),(25,32),(29,31),(33,30),(38,32),(40,36),(38,41),(33,45),(27,47),(21,45),(17,42)],
 neck=[(31,32),(31,26),(35,24),(40,27),(41,33),(36,39)],
 earFar=[(40,23),(42,17),(46,26)],earNear=[(34,23),(33,14),(39,21),(39,27)],
 head=[(31,26),(35,22),(40,23),(45,26),(45,31),(40,34),(34,33),(30,29)],
 muzzle=[(43,27),(48,26),(51,28),(51,31),(47,33),(42,30)],eye=[43,27],nose=[50,29],
 plates=[[(20,33),(25,31),(29,33),(27,37),(22,39),(18,37)],[(28,34),(32,30),(37,32),(37,36),(33,39),(29,38)]],
 shade=[[(18,38),(23,39),(26,44),(22,44),(19,41)],[(29,40),(35,36),(38,38),(34,42),(29,45)]],
 glow=[[(12,48),(14,47),(13,50)]],marks=[(21,39),(25,39),(31,41),(34,40)]),
 dict(name='hit',role='braced recoil with shoulder turned',feet=[[22,58],[43,56]],tail=[(19,37),(13,36),(9,39),(8,42),(13,40),(21,41)],
 rearFar=[(28,40),(30,44),(28,49),(31,52),(32,54),(28,55),(26,51)],
 frontFar=[(36,35),(41,38),(42,44),(47,47),(48,49),(43,50),(38,45)],
 rearNear=[(19,37),(26,41),(26,46),(23,50),(20,54),(23,56),(26,56),(26,58),(20,58),(18,55),(18,50),(21,46)],
 frontNear=[(32,37),(38,40),(38,46),(41,51),(46,53),(46,56),(40,56),(36,52),(34,47),(31,42)],
 body=[(14,34),(19,29),(25,29),(29,28),(33,29),(38,31),(41,35),(39,41),(33,45),(26,46),(20,43),(16,40)],
 neck=[(31,31),(31,25),(35,24),(40,28),(40,35),(36,39)],
 earFar=[(38,25),(41,20),(43,28)],earNear=[(33,24),(29,17),(36,22),(36,29)],
 head=[(29,28),(33,23),(38,25),(43,29),(42,34),(37,37),(32,35),(28,31)],
 muzzle=[(40,29),(45,29),(49,32),(48,35),(44,36),(39,33)],eye=[41,30],nose=[48,33],
 plates=[[(19,30),(25,28),(28,31),(26,35),(21,37),(17,34)],[(28,31),(32,28),(37,30),(37,34),(32,38),(29,36)]],
 shade=[[(17,35),(22,36),(25,41),(21,41),(18,38)],[(29,38),(35,34),(38,37),(33,42),(28,43)]],
 glow=[[(23,26),(25,25),(25,28)],[(43,40),(46,40),(44,42)]],marks=[(20,36),(24,37),(30,39),(34,38)]),
 dict(name='death',role='supported collapsed canine, stones settle',feet=[[21,58],[43,57]],tail=[(18,48),(10,51),(7,55),(13,55),(20,52)],
 rearFar=[(26,48),(30,49),(31,53),(35,54),(34,56),(28,55),(26,52)],
 frontFar=[(35,46),(40,48),(43,52),(48,53),(48,55),(42,55),(37,51)],
 rearNear=[(17,45),(23,47),(25,51),(21,53),(18,55),(22,56),(25,56),(25,58),(18,58),(15,55),(17,51)],
 frontNear=[(31,47),(37,48),(39,53),(43,54),(47,55),(47,57),(40,58),(35,55),(30,53)],
 body=[(12,45),(17,41),(24,40),(29,41),(33,41),(38,43),(40,47),(36,52),(29,55),(21,55),(15,51)],
 neck=[(32,43),(33,38),(37,38),(41,42),(41,47),(36,51)],
 earFar=[(40,39),(44,34),(46,42)],earNear=[(34,39),(30,34),(37,37),(38,43)],
 head=[(32,42),(35,38),(40,39),(45,43),(45,47),(40,50),(34,48),(30,45)],
 muzzle=[(43,44),(48,43),(52,46),(51,49),(46,50),(42,47)],eye=[43,44],nose=[51,47],
 plates=[[(17,42),(23,40),(27,42),(24,46),(18,47),(14,45)],[(27,43),(32,41),(37,43),(36,47),(31,49),(28,47)]],
 shade=[[(15,47),(22,47),(26,52),(20,53),(16,50)],[(29,49),(36,46),(37,49),(32,53),(28,54)]],
 glow=[[(11,57),(13,56),(13,58)],[(45,51),(47,51),(46,53)]],marks=[(19,48),(23,49),(30,51),(34,50)])
]
def guard():
 c=int(Path('/sys/fs/cgroup/memory.current').read_text());m=int(Path('/sys/fs/cgroup/memory.max').read_text());v=os.statvfs(ROOT)
 assert m-c>=512*1048576
 assert c-BASELINE['current']<=24*1048576
 assert v.f_bavail*v.f_frsize>=1048576
 return {'current':c,'maximum':m,'headroom':m-c,'free':v.f_bavail*v.f_frsize}
def line(a,b,col):
 x0,y0=a;x1,y1=b;dx=abs(x1-x0);sx=1 if x0<x1 else -1;dy=-abs(y1-y0);sy=1 if y0<y1 else -1;err=dx+dy
 while True:
  assert 0<=x0<64 and 0<=y0<64;PIX[y0*64+x0]=col
  if x0==x1 and y0==y1:break
  e=2*err
  if e>=dy:err+=dy;x0+=sx
  if e<=dx:err+=dx;y0+=sy
def poly(points,col,outline=None):
 # Integer point-in-polygon sampled at pixel centers, then authored crisp boundary.
 for y in range(min(p[1]for p in points),max(p[1]for p in points)+1):
  for x in range(min(p[0]for p in points),max(p[0]for p in points)+1):
   inside=False;j=len(points)-1
   for i,(xi,yi)in enumerate(points):
    xj,yj=points[j]
    if (yi>y+.5)!=(yj>y+.5)and x+.5<(xj-xi)*(y+.5-yi)/(yj-yi)+xi:inside=not inside
    j=i
   if inside:PIX[y*64+x]=col
 if outline is not None:
  for a,b in zip(points,points[1:]+points[:1]):line(a,b,outline)
def paint(spec):
 global PIX;PIX=bytearray(4096)
 for part,col in [('rearFar',2),('frontFar',2),('tail',3),('rearNear',4),('frontNear',4),('body',4),('neck',4),('earFar',2),('earNear',4),('head',4),('muzzle',5)]:
  poly(spec[part],col,1)
 for plate in spec['plates']:
  poly(plate,6,3)
  top=plate[:3];line(top[0],top[1],8);line(top[1],top[2],7)
 for patch in spec['shade']:poly(patch,3)
 # Short clusters define shoulder, thigh and spectral coat; no linear skeleton ribs.
 for x,y in spec['marks']:
  PIX[y*64+x]=9;PIX[y*64+x+1]=10;PIX[(y+1)*64+x]=3
 for ear in ['earNear','earFar']:
  a,b,d=spec[ear][:3];cx=(a[0]+b[0]+d[0])//3;cy=(a[1]+b[1]+d[1])//3
  PIX[cy*64+cx]=9;PIX[(cy+1)*64+cx]=10
 ex,ey=spec['eye'];PIX[ey*64+ex]=15;PIX[(ey-1)*64+ex]=2
 nx,ny=spec['nose'];PIX[ny*64+nx]=1;PIX[(ny+1)*64+nx]=1
 # A compact cheek highlight, furred jaw corner and visible canine in bite frame.
 PIX[(ey+2)*64+ex-2]=6;PIX[(ey+3)*64+ex-3]=7
 if 'jaw'in spec:
  poly(spec['jaw'],4,1);PIX[25*64+53]=12;PIX[26*64+53]=8;PIX[26*64+56]=8
 for glow in spec['glow']:
  poly(glow,10);x,y=glow[0];PIX[y*64+x]=12
 for x,y in spec['feet']:
  assert PIX[y*64+x]!=0,(spec['name'],'foot contact not painted',x,y)
 return bytes(PIX)
def chunk(k,b):return struct.pack('>I',len(b))+k+b+struct.pack('>I',zlib.crc32(k+b)&0xffffffff)
def png(w,h,pixels):
 rows=b''.join(b'\0'+pixels[y*w:(y+1)*w]for y in range(h))
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,3,0,0,0))+chunk(b'PLTE',bytes(c for rgb in PAL for c in rgb))+chunk(b'tRNS',bytes([0]+[255]*15))+chunk(b'IDAT',zlib.compress(rows,9))+chunk(b'IEND',b'')
def put(name,b):
 fd=os.open(ROOT+'/'+name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  v=memoryview(b)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
 return {'path':ROOT+'/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def bounds(p):
 coords=[(i%64,i//64)for i,v in enumerate(p)if v]
 return [min(x for x,y in coords),min(y for x,y in coords),max(x for x,y in coords)+1,max(y for x,y in coords)+1]
BASELINE={'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text())}
assert BASELINE['maximum']-BASELINE['current']>=24*1048576+512*1048576
assert os.path.isdir(ROOT)
frames=[];files=[];records=[]
for i,spec in enumerate(POSES):
 guard();p=paint(spec);frames.append(p)
 files.append(put('cairn-hound-'+spec['name']+'.png',png(64,64,p)))
 records.append({'index':i,'name':spec['name'],'role':spec['role'],'cell':[i*64,0,64,64],'opaqueBounds':bounds(p),'opaquePixels':sum(bool(v)for v in p),'nativeIndicesUsed':sorted(set(p)),'footContactPoints':spec['feet'],'placementAnchor':[28,58],'pixelSHA256':hashlib.sha256(p).hexdigest()})
sheet=b''.join(b''.join(p[y*64:(y+1)*64]for p in frames)for y in range(64))
files.append(put('cairn-hound-sheet.png',png(640,64,sheet)))
# Diagnostic contact sheet is derived from these NEW pixels at exact nearest3x.
preview=bytearray(960*384)
for i,p in enumerate(frames):
 ox=(i%5)*192;oy=(i//5)*192
 for y in range(64):
  for x in range(64):
   for dy in range(3):
    start=(oy+y*3+dy)*960+ox+x*3;preview[start:start+3]=bytes([p[y*64+x]])*3
files.append(put('cairn-hound-preview-3x.png',png(960,384,preview)))
union=[min(r['opaqueBounds'][0]for r in records),min(r['opaqueBounds'][1]for r in records),max(r['opaqueBounds'][2]for r in records),max(r['opaqueBounds'][3]for r in records)]
meta={'species':'Cairn Hound','cardId':'cairnhound','engineSpecies':'hound','side':'ally','orientation':'original rear three-quarter canine facing northeast into field','nativeCell':[64,64],'sheet':[640,64],'palette':[{'index':i,'rgb':list(c),'alpha':0 if i==0 else 255}for i,c in enumerate(PAL)],'paletteEntryCount':16,'transparentIndex':0,'sampling':'indexed8bit; integer pixels; no antialias','placementAnchor':[28,58],'anchorQualification':'Common floor-plane placement reference; actual painted support contacts are recorded separately per pose. No physics/game fit claim.','fullPoseOpaqueUnion':union,'frames':records,'files':files,'drawnPoseCount':10,'distinctNativePixelHashes':len({r['pixelSHA256']for r in records}),'sequenceCandidates':{'arrival':['arrival0','arrival1','idle0'],'idleReady':['idle0','idle1'],'loadedCommand':['anticipation','contact0','contact1','recovery'],'reaction':['hit','recovery'],'death':['death']},'timingsImplemented':False,'engineIntegration':False,'readyRuleChanged':False,'gameStatsOrRulesDrawn':False,'provenance':'Original author-defined anatomical polygons/pixel clusters; stdlib PNG encoder. No external image input, prior art copied, mirroring, cutout transforms, generated-image samples or shared helper input.','limitations':['Ten hand-authored pose cells are not a demonstrated complete animation or playable payoff.','Rear perspective/canine identity and pixel craft require independent visual rejection-capable review.','No actual Arena fit, transformed hit region, contact/audio timing, reduced-motion or first-binding runtime tested.','No Grave Hound/fenstalker/ashwidow/colossus/enemy coverage.'],'sourceGuardFinal':guard()}
assert meta['distinctNativePixelHashes']==10
files.append(put('ASSET-METADATA.json',(json.dumps(meta,sort_keys=True,indent=2)+'\n').encode()))
print(json.dumps({'files':files,'fullPoseUnion':union,'paletteEntries':16,'nativeCell':[64,64],'uniquePoseHashes':10,'sourceGuardFinal':guard()}))
