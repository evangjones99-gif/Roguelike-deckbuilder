"""Original direct-pixel Cairn Hound anatomy; stdlib only. No external image input.
Every pose supplies its own anatomical polygons. Indexed native64x64, no affine
cutout transform, smoothing, antialias, generated-image sampling or UI text.
"""
import os,json,struct,zlib,hashlib,time,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
ROOT='/workspace/scratch/standard-sol-cairn-pixel-assets-author-r1/draw-r4'
PAL=[(0,0,0),(14,20,23),(27,37,42),(43,58,62),(65,81,82),(77,91,88),(108,122,111),(149,158,137),(190,196,164),(57,91,91),(88,125,117),(135,173,145),(194,217,170),(85,75,59),(125,107,75),(213,176,98)]
# Rearthreequarter, facing northeast; coordinates are individually drawn landmarks.
# Layer order: far legs,tail,near legs,body,neck,ears,head,muzzle,stone/shade details.
POSES=[
 dict(name='arrival0',role='rear haunch coalesces in a low crouch',feet=[[22,58],[42,54]],
 tail=[(20,44),(15,46),(11,50),(12,54),(16,50),(22,49)],
 rearFar=[(30,42),(33,47),(31,50),(32,52),(35,52),(35,54),(30,54),(28,49)],
 frontFar=[(40,33),(44,34),(45,40),(48,43),(47,46),(43,43)],
 rearNear=[(20,44),(27,46),(27,50),(22,52),(21,56),(25,56),(25,58),(20,58),(18,54),(19,50)],
 frontNear=[(35,36),(39,37),(41,44),(41,49),(45,52),(45,54),(40,54),(38,50),(36,44)],
 body=[(21,36),(28,30),(35,27),(40,28),(43,33),(40,38),(34,44),(26,48),(20,46),(17,42)],
 rump=[(19,39),(23,36),(29,37),(33,41),(33,47),(28,50),(22,49),(18,46),(17,42)],
 neck=[(34,30),(36,25),(40,23),(44,26),(43,32),(40,36),(35,37)],
 earFar=[(43,23),(45,18),(48,24)],earNear=[(37,26),(36,18),(41,22),(42,27)],
 head=[(36,26),(38,22),(43,21),(47,24),(46,28),(42,31),(38,30)],
 muzzle=[(44,25),(48,24),(50,24),(50,27),(47,29),(44,28)],eye=[47,26],nose=[50,25],
 back=[(23,38),(28,32),(35,28),(39,28),(38,32),(32,38),(26,43)],
 rumpLight=[(19,40),(23,37),(28,38),(30,41),(27,43),(21,43)],
 stones=[[(28,34),(31,31),(33,33),(31,36)],[(34,29),(36,27),(39,28),(37,31)]],
 glow=[[(11,54),(13,53),(12,56)],[(31,26),(33,25),(32,28)]]),
 dict(name='arrival1',role='hindquarters rise while forefeet settle farther away',feet=[[22,58],[42,52]],
 tail=[(20,42),(15,44),(11,49),(12,53),(16,49),(22,47)],
 rearFar=[(29,41),(32,46),(31,50),(34,51),(34,54),(29,54),(27,49)],
 frontFar=[(40,28),(44,30),(45,37),(47,41),(47,44),(44,44),(41,38)],
 rearNear=[(20,42),(27,44),(28,48),(24,51),(21,54),(22,56),(25,56),(25,58),(20,58),(18,54),(20,49)],
 frontNear=[(36,31),(40,32),(42,39),(41,46),(44,49),(45,52),(40,52),(38,48),(38,40)],
 body=[(20,33),(26,26),(34,22),(39,24),(42,28),(41,33),(35,40),(27,46),(21,45),(17,40)],
 rump=[(19,35),(24,33),(29,34),(33,39),(32,45),(28,48),(22,47),(18,43),(16,39)],
 neck=[(34,25),(35,20),(40,17),(44,20),(44,26),(40,31),(35,33)],
 earFar=[(42,17),(44,11),(47,18)],earNear=[(36,20),(35,11),(41,16),(41,21)],
 head=[(35,20),(37,16),(42,14),(47,18),(46,22),(42,25),(38,25)],
 muzzle=[(44,19),(48,17),(51,17),(50,20),(47,23),(44,22)],eye=[47,19],nose=[50,18],
 back=[(22,35),(28,28),(34,24),(39,25),(37,29),(31,36),(26,41)],
 rumpLight=[(18,37),(23,34),(28,35),(30,39),(27,42),(21,41)],
 stones=[[(28,29),(31,26),(33,27),(31,31)],[(34,24),(36,22),(39,24),(37,26)]],
 glow=[[(11,54),(13,52),(13,55)],[(30,21),(32,20),(31,23)]]),
 dict(name='idle0',role='ready rear stance: broad near haunch and receding shoulders',feet=[[22,58],[42,52]],
 tail=[(20,40),(15,43),(11,48),(11,52),(14,50),(17,47),(22,45)],
 rearFar=[(29,39),(33,44),(31,49),(31,51),(35,51),(35,54),(30,54),(27,49),(27,44)],
 frontFar=[(41,26),(44,28),(45,35),(47,39),(47,42),(43,42),(41,35)],
 rearNear=[(20,41),(27,43),(28,48),(24,51),(21,53),(22,56),(25,56),(25,58),(20,58),(18,54),(19,50),(22,46)],
 frontNear=[(36,29),(41,31),(42,38),(40,46),(44,49),(45,52),(40,52),(38,48),(38,40),(35,35)],
 body=[(20,31),(26,24),(33,20),(39,21),(42,26),(41,32),(35,39),(28,45),(21,44),(17,39)],
 rump=[(18,34),(23,31),(29,32),(33,37),(33,44),(28,48),(22,47),(17,43),(16,38)],
 neck=[(34,23),(35,17),(40,14),(44,18),(44,24),(40,30),(35,32)],
 earFar=[(42,13),(44,6),(47,14)],earNear=[(36,16),(35,7),(41,12),(41,17)],
 head=[(35,16),(37,12),(42,10),(47,14),(46,18),(42,22),(38,22)],
 muzzle=[(44,16),(48,14),(51,14),(50,17),(47,20),(44,19)],eye=[47,16],nose=[50,15],
 back=[(22,34),(27,27),(34,22),(39,23),(37,28),(31,35),(26,41)],
 rumpLight=[(18,36),(23,32),(28,34),(30,38),(27,41),(21,40)],
 stones=[[(28,27),(31,24),(33,25),(31,29)],[(34,22),(36,20),(39,21),(37,24)]],
 glow=[[(11,53),(13,52),(12,55)],[(30,18),(32,17),(31,20)]]),
 dict(name='idle1',role='rear stance breath with one forepaw and ear adjustment',feet=[[22,58],[44,51]],
 tail=[(20,41),(15,44),(12,50),(13,53),(16,49),(22,46)],
 rearFar=[(29,40),(32,44),(31,49),(33,51),(35,52),(34,54),(29,54),(27,49)],
 frontFar=[(40,27),(44,30),(44,35),(47,38),(47,41),(44,42),(41,36)],
 rearNear=[(20,42),(27,44),(27,48),(24,51),(21,54),(22,56),(25,56),(25,58),(20,58),(18,54),(19,50),(22,47)],
 frontNear=[(36,30),(41,32),(43,38),(42,44),(44,47),(47,49),(47,51),(42,51),(39,47),(38,41),(35,35)],
 body=[(20,32),(26,25),(34,21),(40,22),(43,27),(41,33),(35,40),(28,46),(21,45),(17,40)],
 rump=[(18,35),(23,32),(29,33),(33,38),(32,45),(28,49),(22,48),(17,44),(16,39)],
 neck=[(34,24),(36,18),(41,15),(45,19),(44,25),(40,31),(35,33)],
 earFar=[(43,14),(47,9),(48,16)],earNear=[(37,17),(37,8),(42,13),(42,18)],
 head=[(36,17),(38,13),(43,11),(48,15),(47,19),(43,23),(39,23)],
 muzzle=[(45,17),(49,15),(52,15),(51,18),(48,21),(45,20)],eye=[48,17],nose=[51,16],
 back=[(22,35),(28,28),(35,23),(40,24),(38,29),(32,36),(27,42)],
 rumpLight=[(18,37),(23,33),(28,35),(30,39),(27,42),(21,41)],
 stones=[[(29,28),(32,25),(34,26),(32,30)],[(35,23),(37,21),(40,22),(38,25)]],
 glow=[[(12,54),(14,52),(13,55)]]),
 dict(name='anticipation',role='near haunch compresses and hocks load under diagonal back',feet=[[19,58],[45,53]],
 tail=[(19,42),(14,44),(9,48),(10,51),(15,48),(21,47)],
 rearFar=[(29,42),(32,46),(30,50),(32,52),(35,52),(35,54),(29,54),(27,48)],
 frontFar=[(42,29),(45,31),(46,39),(50,42),(49,45),(45,43)],
 rearNear=[(19,44),(26,45),(27,49),(22,51),(17,54),(18,56),(22,56),(22,58),(17,58),(15,54),(18,49)],
 frontNear=[(37,33),(42,34),(43,40),(42,47),(47,50),(48,53),(43,53),(39,49),(38,42)],
 body=[(19,35),(26,28),(34,24),(40,25),(44,30),(42,36),(36,42),(28,48),(21,47),(17,42)],
 rump=[(18,38),(23,35),(29,36),(33,41),(32,47),(28,50),(21,49),(17,45),(16,41)],
 neck=[(35,27),(38,21),(43,19),(47,23),(46,29),(42,34),(36,37)],
 earFar=[(44,19),(47,13),(49,21)],earNear=[(39,22),(36,14),(43,18),(44,24)],
 head=[(38,22),(40,18),(45,16),(50,20),(49,24),(45,28),(40,28)],
 muzzle=[(47,22),(51,20),(54,20),(53,23),(50,26),(47,25)],eye=[50,22],nose=[53,21],
 back=[(22,38),(28,31),(35,26),(40,27),(38,32),(32,40),(26,44)],
 rumpLight=[(18,40),(23,36),(28,38),(30,42),(27,45),(21,44)],
 stones=[[(29,31),(32,28),(34,29),(32,33)],[(35,26),(37,24),(40,25),(38,28)]],
 glow=[[(9,52),(11,50),(10,54)]]),
 dict(name='contact0',role='foreshortened open bite; rear legs extend from near haunch',feet=[[17,58],[46,47]],
 tail=[(20,40),(13,41),(8,44),(8,47),(13,46),(22,45)],
 rearFar=[(29,40),(31,44),(28,49),(28,51),(32,51),(32,53),(27,53),(25,48)],
 frontFar=[(42,24),(46,26),(48,31),(52,35),(52,38),(48,38),(44,33)],
 rearNear=[(20,40),(26,43),(26,47),(22,51),(16,54),(15,56),(19,56),(19,58),(14,58),(12,55),(18,48),(21,44)],
 frontNear=[(36,28),(42,29),(46,35),(45,41),(49,44),(50,47),(45,47),(42,43),(41,37),(36,34)],
 body=[(21,30),(27,23),(34,18),(40,19),(44,24),(43,29),(36,37),(28,44),(22,44),(18,39)],
 rump=[(19,33),(24,30),(29,32),(33,37),(32,43),(28,47),(22,46),(18,42),(17,37)],
 neck=[(35,22),(38,15),(43,12),(47,16),(47,22),(43,28),(37,31)],
 earFar=[(44,10),(46,4),(49,12)],earNear=[(39,13),(38,4),(44,9),(44,15)],
 head=[(38,13),(40,9),(45,7),(50,11),(50,15),(46,19),(41,20)],
 muzzle=[(47,13),(51,10),(54,10),(54,13),(51,16),(48,16)],eye=[50,13],nose=[53,11],
 jaw=[(47,17),(51,17),(54,15),(54,19),(51,22),(46,21)],
 back=[(22,33),(28,25),(35,20),(40,21),(38,27),(32,35),(26,41)],
 rumpLight=[(19,35),(24,31),(29,34),(30,38),(27,41),(21,40)],
 stones=[[(29,25),(32,22),(34,23),(32,27)],[(35,20),(37,18),(40,19),(38,22)]],
 glow=[[(8,48),(10,46),(9,50)]]),
 dict(name='contact1',role='bite closes with far shoulder and nearer forepaw offset',feet=[[19,58],[47,49]],
 tail=[(20,42),(14,44),(10,47),(11,51),(15,48),(23,47)],
 rearFar=[(29,42),(32,46),(30,50),(32,52),(35,52),(35,54),(29,54),(27,49)],
 frontFar=[(43,26),(47,28),(48,34),(52,39),(52,42),(48,42),(45,36)],
 rearNear=[(20,42),(27,45),(26,49),(23,52),(17,54),(18,56),(22,56),(22,58),(17,58),(15,55),(19,50),(21,47)],
 frontNear=[(37,30),(42,31),(46,38),(45,44),(49,47),(50,49),(45,49),(42,45),(41,39),(37,36)],
 body=[(21,32),(27,25),(35,20),(41,22),(45,27),(43,32),(36,40),(28,46),(22,46),(18,41)],
 rump=[(19,35),(24,32),(29,34),(33,39),(32,45),(28,49),(22,48),(18,44),(17,39)],
 neck=[(36,24),(39,18),(44,14),(49,18),(48,24),(44,30),(38,33)],
 earFar=[(45,13),(48,7),(50,15)],earNear=[(40,16),(39,7),(45,12),(45,18)],
 head=[(39,16),(41,12),(46,10),(51,14),(51,18),(47,22),(42,23)],
 muzzle=[(48,16),(52,13),(55,13),(55,16),(52,19),(49,20)],eye=[51,16],nose=[54,14],
 back=[(23,35),(29,27),(36,22),(41,24),(39,29),(33,37),(27,43)],
 rumpLight=[(19,37),(24,33),(29,36),(30,40),(27,43),(21,42)],
 stones=[[(30,27),(33,24),(35,25),(33,29)],[(36,22),(38,20),(41,22),(39,24)]],
 glow=[[(10,52),(12,50),(11,54)]]),
 dict(name='recovery',role='near haunch reweights while forequarters withdraw and jaw settles',feet=[[24,58],[41,53]],
 tail=[(21,42),(16,46),(14,52),(16,54),(19,50),(24,47)],
 rearFar=[(30,42),(33,46),(31,50),(33,52),(35,53),(34,55),(29,54),(28,49)],
 frontFar=[(39,29),(43,32),(44,37),(46,41),(46,44),(42,44),(40,37)],
 rearNear=[(21,43),(28,45),(28,49),(25,52),(23,54),(24,56),(27,56),(27,58),(22,58),(20,54),(22,50)],
 frontNear=[(35,32),(39,34),(40,41),(39,47),(42,50),(44,53),(39,53),(37,49),(37,41)],
 body=[(21,34),(27,27),(33,24),(38,25),(42,30),(40,35),(34,42),(28,47),(22,46),(18,41)],
 rump=[(20,37),(25,34),(30,36),(34,41),(33,46),(29,50),(23,49),(19,45),(18,41)],
 neck=[(33,26),(33,21),(38,18),(42,22),(42,28),(38,33),(34,35)],
 earFar=[(40,17),(42,12),(45,19)],earNear=[(34,21),(33,13),(39,17),(40,23)],
 head=[(33,22),(35,18),(40,16),(45,20),(44,24),(40,28),(35,28)],
 muzzle=[(42,23),(46,21),(49,21),(48,24),(45,27),(42,26)],eye=[45,23],nose=[48,22],
 back=[(23,37),(28,30),(34,26),(38,27),(36,32),(31,39),(27,44)],
 rumpLight=[(20,39),(25,35),(30,38),(31,42),(28,45),(23,44)],
 stones=[[(29,30),(31,27),(34,28),(32,32)],[(34,26),(36,24),(38,25),(37,28)]],
 glow=[[(14,55),(16,53),(15,57)]]),
 dict(name='hit',role='braced rear haunch turns as shoulder and skull recoil inward',feet=[[24,58],[44,54]],
 tail=[(22,39),(16,40),(12,44),(13,47),(18,44),(25,44)],
 rearFar=[(30,40),(33,44),(31,49),(33,52),(36,52),(35,55),(30,54),(28,48)],
 frontFar=[(41,29),(45,32),(46,37),(49,40),(49,44),(45,44),(43,37)],
 rearNear=[(22,42),(29,44),(29,48),(26,51),(22,54),(24,56),(27,56),(27,58),(22,58),(20,55),(21,50)],
 frontNear=[(36,32),(41,35),(42,42),(41,48),(45,51),(47,54),(42,54),(39,50),(38,43)],
 body=[(22,32),(28,26),(35,23),(40,26),(44,31),(42,36),(36,42),(29,47),(23,46),(19,40)],
 rump=[(21,35),(26,32),(31,35),(35,40),(33,46),(29,49),(24,48),(20,44),(19,39)],
 neck=[(33,26),(32,21),(37,18),(41,22),(42,29),(38,34),(34,36)],
 earFar=[(38,18),(40,14),(43,22)],earNear=[(32,22),(28,16),(36,19),(37,25)],
 head=[(31,23),(33,19),(38,17),(43,22),(43,26),(39,30),(33,29)],
 muzzle=[(40,24),(44,22),(47,23),(46,26),(43,29),(40,28)],eye=[43,25],nose=[46,24],
 back=[(24,35),(29,29),(35,25),(40,28),(37,33),(32,40),(28,44)],
 rumpLight=[(21,37),(26,33),(31,37),(32,41),(29,44),(24,43)],
 stones=[[(30,29),(32,26),(35,27),(33,31)],[(35,25),(37,23),(40,26),(38,28)]],
 glow=[[(26,28),(28,27),(27,30)],[(45,44),(47,43),(46,46)]]),
 dict(name='death',role='rear-weight collapse: flank grounded, head and ears folded onto far paws',feet=[[24,58],[43,56]],
 tail=[(21,49),(14,52),(10,55),(11,58),(16,56),(24,54)],
 rearFar=[(30,48),(33,51),(32,54),(37,55),(36,57),(30,56)],
 frontFar=[(39,42),(44,44),(45,48),(50,49),(50,52),(43,51),(39,47)],
 rearNear=[(20,48),(28,50),(29,53),(25,55),(22,56),(27,56),(27,58),(20,58),(18,55)],
 frontNear=[(35,45),(40,47),(41,52),(47,54),(47,56),(42,56),(37,53),(33,50)],
 body=[(22,43),(29,37),(35,36),(40,40),(43,44),(40,49),(33,54),(26,57),(21,55),(18,50)],
 rump=[(20,46),(25,43),(31,45),(34,50),(31,55),(26,58),(20,55),(17,51)],
 neck=[(34,40),(36,37),(40,37),(43,41),(43,45),(39,49),(35,47)],
 earFar=[(40,41),(42,39),(45,42)],earNear=[(36,44),(33,41),(39,43),(40,46)],
 head=[(35,45),(38,42),(42,41),(46,45),(46,48),(42,51),(38,50)],
 muzzle=[(44,46),(48,44),(51,45),(50,48),(47,51),(44,49)],eye=[47,47],nose=[50,46],
 back=[(23,47),(29,40),(35,38),(40,42),(37,46),(31,52),(26,55)],
 rumpLight=[(20,48),(25,44),(30,47),(31,51),(27,54),(23,52)],
 stones=[[(29,41),(32,38),(34,40),(32,43)],[(35,38),(37,36),(40,40),(38,42)]],
 glow=[[(11,59),(13,57),(13,59)],[(44,53),(46,52),(45,54)]])
]
def guard():
 c=int(Path('/sys/fs/cgroup/memory.current').read_text());m=int(Path('/sys/fs/cgroup/memory.max').read_text());v=os.statvfs(ROOT)
 assert m-c>=512*1048576
 assert c-BASELINE['current']<=24*1048576
 assert v.f_bavail*v.f_frsize>=1048576
 return {'current':c,'maximum':m,'headroom':m-c,'free':v.f_bavail*v.f_frsize}
def line(a,b,col):
 x0,y0=a;x1,y1=b;dx=abs(x1-x0);sx=1 if x0<x1 else -1;dy=-abs(y1-y0);sy=1 if y0<y1 else -1;err=dx+dy
 while True:
  assert 0<=x0<64 and 0<=y0<64;PIX[y0*64+x0]=col
  if x0==x1 and y0==y1:break
  e=2*err
  if e>=dy:err+=dy;x0+=sx
  if e<=dx:err+=dx;y0+=sy
def poly(points,col,outline=None):
 # Integer point-in-polygon sampled at pixel centers, then authored crisp boundary.
 for y in range(min(p[1]for p in points),max(p[1]for p in points)+1):
  for x in range(min(p[0]for p in points),max(p[0]for p in points)+1):
   inside=False;j=len(points)-1
   for i,(xi,yi)in enumerate(points):
    xj,yj=points[j]
    if (yi>y+.5)!=(yj>y+.5)and x+.5<(xj-xi)*(y+.5-yi)/(yj-yi)+xi:inside=not inside
    j=i
   if inside:PIX[y*64+x]=col
 if outline is not None:
  for a,b in zip(points,points[1:]+points[:1]):line(a,b,outline)
def paint(spec):
 global PIX;PIX=bytearray(4096)
 # Far legs are first, visibly offset and occluded by broad near rump/chest.
 for part,col in [('rearFar',2),('frontFar',2),('tail',3),('rearNear',4),('frontNear',4),('body',4),('rump',4),('neck',4),('earFar',2),('head',4),('earNear',4),('muzzle',5)]:
  poly(spec[part],col,1)
 poly(spec['back'],5)
 poly(spec['rumpLight'],5)
 # Back-to-neck coat connection is a diagonal cold fur plane, not side ribs.
 a=spec['back'];line(a[0],a[1],9);line(a[1],a[2],10)
 for stone in spec['stones']:
  poly(stone,6,3);line(stone[0],stone[1],7)
 # Top/back of skull is visible; short muzzle recedes NE with a small nose plane.
 h=spec['head'];line(h[0],h[1],9);line(h[1],h[2],10)
 for ear in ['earNear','earFar']:
  a,b,d=spec[ear][:3];cx=(a[0]+b[0]+d[0])//3;cy=(a[1]+b[1]+d[1])//3
  PIX[cy*64+cx]=3
 ex,ey=spec['eye'];PIX[ey*64+ex]=15 if spec['name']!='death' else 2
 nx,ny=spec['nose'];PIX[ny*64+nx]=1;PIX[(ny+1)*64+nx]=1
 if 'jaw' in spec:
  poly(spec['jaw'],4,1);PIX[17*64+51]=8;PIX[18*64+51]=12
 for glow in spec['glow']:
  poly(glow,10);x,y=glow[0];PIX[y*64+x]=12
 for x,y in spec['feet']:
  assert PIX[y*64+x]!=0,(spec['name'],'foot contact not painted',x,y)
 return bytes(PIX)
def chunk(k,b):return struct.pack('>I',len(b))+k+b+struct.pack('>I',zlib.crc32(k+b)&0xffffffff)
def png(w,h,pixels):
 rows=b''.join(b'\0'+pixels[y*w:(y+1)*w]for y in range(h))
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,3,0,0,0))+chunk(b'PLTE',bytes(c for rgb in PAL for c in rgb))+chunk(b'tRNS',bytes([0]+[255]*15))+chunk(b'IDAT',zlib.compress(rows,9))+chunk(b'IEND',b'')
def put(name,b):
 fd=os.open(ROOT+'/'+name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  v=memoryview(b)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
 return {'path':ROOT+'/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def bounds(p):
 coords=[(i%64,i//64)for i,v in enumerate(p)if v]
 return [min(x for x,y in coords),min(y for x,y in coords),max(x for x,y in coords)+1,max(y for x,y in coords)+1]
BASELINE={'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text())}
assert BASELINE['maximum']-BASELINE['current']>=24*1048576+512*1048576
assert os.path.isdir(ROOT)
frames=[];files=[];records=[]
for i,spec in enumerate(POSES):
 guard();p=paint(spec);frames.append(p)
 files.append(put('cairn-hound-'+spec['name']+'.png',png(64,64,p)))
 records.append({'index':i,'name':spec['name'],'role':spec['role'],'cell':[i*64,0,64,64],'opaqueBounds':bounds(p),'opaquePixels':sum(bool(v)for v in p),'nativeIndicesUsed':sorted(set(p)),'footContactPoints':spec['feet'],'placementAnchor':[28,58],'pixelSHA256':hashlib.sha256(p).hexdigest()})
sheet=b''.join(b''.join(p[y*64:(y+1)*64]for p in frames)for y in range(64))
files.append(put('cairn-hound-sheet.png',png(640,64,sheet)))
# Diagnostic contact sheet is derived from these NEW pixels at exact nearest3x.
preview=bytearray(960*384)
for i,p in enumerate(frames):
 ox=(i%5)*192;oy=(i//5)*192
 for y in range(64):
  for x in range(64):
   for dy in range(3):
    start=(oy+y*3+dy)*960+ox+x*3;preview[start:start+3]=bytes([p[y*64+x]])*3
files.append(put('cairn-hound-preview-3x.png',png(960,384,preview)))
union=[min(r['opaqueBounds'][0]for r in records),min(r['opaqueBounds'][1]for r in records),max(r['opaqueBounds'][2]for r in records),max(r['opaqueBounds'][3]for r in records)]
meta={'species':'Cairn Hound','cardId':'cairnhound','engineSpecies':'hound','side':'ally','orientation':'intended rear three-quarter canine facing northeast; independent visual acceptance pending','nativeCell':[64,64],'sheet':[640,64],'palette':[{'index':i,'rgb':list(c),'alpha':0 if i==0 else 255}for i,c in enumerate(PAL)],'paletteEntryCount':16,'transparentIndex':0,'sampling':'indexed8bit; integer pixels; no antialias','placementAnchor':[28,58],'anchorQualification':'Common floor-plane placement reference; actual painted support contacts are recorded separately per pose. No physics/game fit claim.','fullPoseOpaqueUnion':union,'frames':records,'files':files,'drawnPoseCount':10,'distinctNativePixelHashes':len({r['pixelSHA256']for r in records}),'sequenceCandidates':{'arrival':['arrival0','arrival1','idle0'],'idleReady':['idle0','idle1'],'loadedCommand':['anticipation','contact0','contact1','recovery'],'reaction':['hit','recovery'],'death':['death']},'timingsImplemented':False,'engineIntegration':False,'readyRuleChanged':False,'gameStatsOrRulesDrawn':False,'provenance':'NEW original anatomical polygons/pixel clusters for rear3q repair. Exact own R3 raster/PNG/receipt helpers reused from source SHA673d0a77a8781a0916d6b9123cf72e7d24caf4dcbc6f83e405179fbd6afd250a; R3 image pixels not read/copied. No external image input, cutout transform, mirrored front anatomy or generated-image sample.','limitations':['Ten hand-authored pose cells are not a demonstrated complete animation or playable payoff.','Rear perspective/canine identity and pixel craft require independent visual rejection-capable review.','No actual Arena fit, transformed hit region, contact/audio timing, reduced-motion or first-binding runtime tested.','No Grave Hound/fenstalker/ashwidow/colossus/enemy coverage.'],'sourceGuardFinal':guard()}
assert meta['distinctNativePixelHashes']==10
files.append(put('ASSET-METADATA.json',(json.dumps(meta,sort_keys=True,indent=2)+'\n').encode()))
print(json.dumps({'files':files,'fullPoseUnion':union,'paletteEntries':16,'nativeCell':[64,64],'uniquePoseHashes':10,'sourceGuardFinal':guard()}))
