# Cairn rear-angle repair R4 — source/native assets only

R3 was independently rejected as mostly lateral despite improved canine silhouette. R4 redraws all ten poses with a broad near haunch, diagonal top/back plane, farther offset legs, overlapping shoulder/neck, shorter receding muzzle and a low folded head/ears in death. The intended rear three-quarter angle is pending independent actual-image review; no angle acceptance or game-art selection is claimed.

Only this new draw-r4 directory was authored. R3 PNGs and source remain exact; the author's pinned small raster/PNG/receipt helpers were reused, but no R3 image pixels were read or copied into the drawings. Original explicit polygons and pixel clusters supply every pose; no translated/scaled source cutout, front-image mirroring, external reference image or image-generation input. Sixteen palette entries include transparency; actually used indices and each pose support point/full union are in ASSET-METADATA and NATIVE-AUDIT.

The ten 64x64 cells supply arrival0, arrival1, idle0, idle1, anticipation, contact0, contact1, recovery, hit, death in that order. Sheet640x64; transparent indexed8bit; preview960x384 is exactly native3x. Common placement reference[28,58] is not every painted support point. No stats/rules are baked into the sheet. Metadata bounds are half-open.

No Node, browser, engine import, server, build, Arena integration, gameplay timing or archive operation. Earlier actual-Arena source reads were preserved as preparation held after R3 rejection; integration remains pending visual inspection. Native-byte checks are authorship verification only, not independent visual approval. Assets and pose timing still need a real opt-in candidate and rejection-capable technical/visual/play comparisons.
