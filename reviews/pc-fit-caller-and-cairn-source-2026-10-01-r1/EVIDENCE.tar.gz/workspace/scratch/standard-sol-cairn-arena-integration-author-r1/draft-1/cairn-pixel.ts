/** Cairn-only prototype. Original R4 art remains artistically withheld.
 * No rules, RNG, saves, action dispatch or extra clocks live in this module.
 * Half-open native bounds and painted support contacts come from pinned R4 metadata.
 */
import type { Unit } from './engine';
import type { BattlefieldRect } from './battlefield-layout';
import { CREATURE_IMPACT_MS, type CreaturePose } from './art';

export const CAIRN_PIXEL_URL = `${import.meta.env.BASE_URL}art/cairn-hound-pixel-r4.png`;
export const CAIRN_PIXEL_SCALE = 2;
export const CAIRN_PIXEL_SIZE = 64 * CAIRN_PIXEL_SCALE;
export const CAIRN_PIXEL_ANCHOR = [28, 58] as const;
export const CAIRN_PIXEL_UNION = [8, 4, 56, 60] as const;
export const CAIRN_PIXEL_FRAMES = [
  { name: 'arrival0', bounds: [11,18,51,59], feet: [[22,58],[42,54]] },
  { name: 'arrival1', bounds: [11,11,52,59], feet: [[22,58],[42,52]] },
  { name: 'idle0', bounds: [11,6,52,59], feet: [[22,58],[42,52]] },
  { name: 'idle1', bounds: [12,8,53,59], feet: [[22,58],[44,51]] },
  { name: 'anticipation', bounds: [9,13,55,59], feet: [[19,58],[45,53]] },
  { name: 'contact0', bounds: [8,4,55,59], feet: [[17,58],[46,47]] },
  { name: 'contact1', bounds: [10,7,56,59], feet: [[19,58],[47,49]] },
  { name: 'recovery', bounds: [14,12,50,59], feet: [[24,58],[41,53]] },
  { name: 'hit', bounds: [12,14,50,59], feet: [[24,58],[44,54]] },
  { name: 'death', bounds: [10,36,52,60], feet: [[24,58],[43,56]] },
] as const;

export function isPixelCairn(unit: Pick<Unit, 'cardId' | 'species'>, side: 'ally' | 'enemy') {
  return side === 'ally' && unit.cardId === 'cairnhound' && unit.species === 'hound';
}
export function cairnPixelFits(body: BattlefieldRect) {
  // Both target facings reserve the complete pose union at the SAME native2x.
  return body.width >= 120 && body.height >= 120;
}
export function cairnPixelFeet(body: BattlefieldRect) {
  return { x: Math.round(body.left + body.width / 2), y: Math.round(body.top + body.height - 8) };
}
export function cairnPixelFrame(pose: CreaturePose, now: number, born: number,
  gestureBorn: number | null, reduced: boolean, deadAt: number | null) {
  if (deadAt !== null && now >= deadAt) return 9;
  if (reduced) return 2;
  if (pose === 'reaction') return 8;
  if (pose === 'anticipation') return 4;
  if (pose === 'attack') return gestureBorn !== null && now - gestureBorn >= CREATURE_IMPACT_MS / 1000 ? 6 : 5;
  if (pose === 'recovery') return 7;
  const arrival = now - born;
  if (arrival < .16) return 0;
  if (arrival < .32) return 1;
  return Math.floor(Math.max(0, arrival - .32) / .55) % 2 === 0 ? 2 : 3;
}
export function cairnPixelBounds(index: number, origin: { x: number; y: number }, facing: -1 | 1): BattlefieldRect {
  const [left, top, right, bottom] = CAIRN_PIXEL_FRAMES[index].bounds;
  const x1 = (left - CAIRN_PIXEL_ANCHOR[0]) * CAIRN_PIXEL_SCALE * facing;
  const x2 = (right - CAIRN_PIXEL_ANCHOR[0]) * CAIRN_PIXEL_SCALE * facing;
  return { left: origin.x + Math.min(x1, x2), top: origin.y + (top - CAIRN_PIXEL_ANCHOR[1]) * CAIRN_PIXEL_SCALE,
    width: (right - left) * CAIRN_PIXEL_SCALE, height: (bottom - top) * CAIRN_PIXEL_SCALE };
}
export function cairnPixelContactRoot(target: { x: number; y: number }, body: BattlefieldRect, facing: -1 | 1) {
  // Authored contact1 nose[54,14]. The full pose union stays inside the victim
  // body allocation; near a boundary, residual contact gap is honest, not clipping.
  const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
  return { x: clamp(target.x - (54 - 28) * 2 * facing, body.left + 60, body.left + body.width - 60),
    y: clamp(target.y - (14 - 58) * 2, body.top + 112, body.top + body.height - 8) };
}
