from pathlib import Path
import os,json,hashlib,difflib
root=Path('/workspace/scratch/standard-sol-pc-opening-fit-author-r1');base=Path('/workspace/scratch/first-five-opening-readout-stage-r1')
freeze=Path('/workspace/scratch/first-five-opening-readout-runtime-freeze-root-r1.json')
visual=Path('/workspace/scratch/standard-sol-opening-hand-cue-visual-actual-r2-phase1/VISUAL-RESULT.json')
report=Path('/workspace/scratch/standard-sol-opening-hand-cue-visual-actual-r2-report-r1/REVIEW.md')
work=24*1024*1024;reserve=512*1024*1024;limit=int(Path('/sys/fs/cgroup/memory.max').read_text());initial=int(Path('/sys/fs/cgroup/memory.current').read_text());samples=[]
def read(p):
    with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME),'rb') as f:return f.read()
def sha(b):return hashlib.sha256(b).hexdigest()
def guard(label):
    current=int(Path('/sys/fs/cgroup/memory.current').read_text());rss=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmHWM:')))*1024
    row=dict(label=label,current=current,delta=max(0,current-initial),headroom=limit-current,processVmHWM=rss);samples.append(row)
    assert row['headroom']>=reserve and row['delta']<=work and rss<=work,row

def replace(text,old,new):
    assert text.count(old)==1,(old,text.count(old));return text.replace(old,new)
guard('admission')
frozenbytes=read(freeze);frozen=json.loads(frozenbytes);assert frozen['sourceDigest']=='0cd0cbca6428e29f899cde48e0d759a1441e8b5c9271889b8f464b75e1f09571'
names=['src/main.ts','src/compact-readout.css'];before={name:read(base/name) for name in names};after=dict(before)
for name in names:assert sha(before[name])==frozen['inputs'][name]
oldmain=before['src/main.ts'].decode()
newmain=replace(oldmain,"  const height = hand?.querySelector<HTMLElement>('.game-card')?.offsetHeight;","  // Natural printed rules can make a later card taller than the first.\n  const height = hand ? Math.max(0, ...Array.from(hand.querySelectorAll<HTMLElement>('.game-card'), card => card.offsetHeight)) : 0;")
after['src/main.ts']=newmain.encode()
css='''
/* PC opening fit: recover chrome/art whitespace before touching actor geometry.
   Full printed content sets natural card height; bigger text keeps page overflow. */
@media(min-width:1101px){
 .phase-battle.direct-field #topbar{height:44px}
 .phase-battle.direct-field #hud{height:52px}
 .phase-battle.direct-field #footer{height:23px}
 /* Fixed during focus/hover/press: exact longer consequences scroll internally. */
 .phase-battle.direct-field .battle-guidance{height:40px;min-height:40px;max-height:40px;padding:4px 12px}
 .phase-battle.direct-field #consequence-preview{max-height:30px}
 .phase-battle.direct-field #dock[data-tactile-hand]{padding-top:4px;padding-bottom:4px;min-height:0}
 .phase-battle.direct-field #dock[data-tactile-hand] .hand-cards{
  height:auto;min-height:calc(var(--tactile-card-height,201px) + 40px);
  padding-top:32px;padding-bottom:8px;
 }
 .phase-battle.direct-field #dock[data-tactile-hand] .hand-cards .game-card{
  height:auto;min-height:201px;width:170px;min-width:170px;max-width:170px;flex-basis:170px;
 }
 .phase-battle.direct-field #dock[data-tactile-hand] .hand-cards .card-art{height:46px}
 .phase-battle.direct-field #dock[data-tactile-hand] .hand-cards .card-name{overflow:visible;text-overflow:clip;overflow-wrap:anywhere}
 .phase-battle.direct-field #dock[data-tactile-hand] .hand-cards .card-description{flex:1 0 auto}
 .phase-battle.direct-field #dock[data-tactile-hand] .hand-cards .card-stats{flex-shrink:0}
}
'''
after['src/compact-readout.css']+=css.encode()
# These source sections remain byte-identical, including measured shared scene geometry.
def section(text,start,end):return text[text.index(start):text.index(end,text.index(start))]
assert section(newmain,'function fieldIdentity(','function renderBattle()')==section(oldmain,'function fieldIdentity(','function renderBattle()')
assert section(newmain,'function updateFinalStrikeReadout(','function render(')==section(oldmain,'function updateFinalStrikeReadout(','function render(')
assert 'font-size' not in css and 'transform:' not in css
visualbytes=read(visual);reportbytes=read(report);observed=json.loads(visualbytes)
assert observed['sourceDigest']=='56834feaf81415b7dfd3a1f03ea4f0a24dc51eaee4bd0dea47c5e81d0b318928'
assert observed['geometry'][0]['scroll']['height']==1016
assert observed['geometry'][0]['scroll']['y']==57
guard('proposal-ready')
for name in names:
    for folder,data in [('baseline',before[name]),('candidate',after[name])]:
        p=root/folder/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data)
diff=''.join(''.join(difflib.unified_diff(before[name].decode().splitlines(True),after[name].decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name)) for name in names)
(root/'CHANGE.diff').write_text(diff)
(root/'SOURCE-PINS.json').write_text(json.dumps(dict(baselineStage=str(base),sourceDigest=frozen['sourceDigest'],outputsDigest=frozen['outputsDigest'],freezeSHA256=sha(frozenbytes),files={name:dict(baseline=sha(before[name]),candidate=sha(after[name])) for name in names},evidence={str(visual):sha(visualbytes),str(report):sha(reportbytes)}),indent=2)+'\n')
(root/'PROPOSAL.md').write_text('''# PC opening fit — source proposal only

The hypothesis is that reclaiming preview, chrome and decorative hand space will show the default opening's Help, hunter HUD, intentions and complete cards together at1440×900. This is not measured fit, visual acceptance or human-fun evidence. Independent reviewers may reject it.

## Baseline and observed problem

Exact baseline `/workspace/scratch/first-five-opening-readout-stage-r1`, strict-built source `0cd0cbca6428e29f899cde48e0d759a1441e8b5c9271889b8f464b75e1f09571`,87inputs/56outputs, output ledger `ff4e49a4fed2838548c8576ff2f4fbbd82dcf70af98b2d35aeeb41724b6da13f`. The two edited bodies are checked against its freeze; no whole-build87/56 re-audit is claimed. The readout R3 implementation is retained.

The supplied actual cue-stage visual evidence is source56834fe…, not this newer named-readout stage: document height1016 at1440×900, natural initial card focus scrollY57, How to play at−45…−12. Help/Escape returns scrollY0 and card bottoms957, cutting lower binding stats from that viewport. Its separate report rejects simultaneous fit; the failed held-cancel logger does not erase these measured dimensions. Both exact evidence body hashes are in SOURCE-PINS.json. The help-return screenshot was personally viewed for this proposal; no new browser or gameplay ran.

I inspected main imports, style.css, command-field.css, compact-readout.css, tactile-hand.css and imported hunt-entry.css, as well as compact-field-budget, shared battlefield layout and arena resize/published-region paths. The current shared width1440 sparse field reserves460px, with unchanged150px body allocations. main already measures guidance height and sizes scene/arena-wrap from requiredHeight plus guidance/art-status height. Shrinking only CSS scene height would lie about canvas/control geometry; this proposal does not do that.

## Two focused changes

main.ts changes only its existing hand-height measurement to use the tallest rendered card's offsetHeight rather than the first card. Actual DOM content height supplies the tactile gutter variable; no duplicate font-measurement formula or new observer/framework is introduced.

compact-readout.css adds a battle/direct-field PC-only min-width1101px block. Topbar58→44px, hunter HUD64→52px, footer27→23px retain all controls and existing fonts. Guidance84→40px remains a fixed press-stable strip; the existing tabindex0/live consequence region keeps internal overflow:auto, complete text and12px/18px line height, with a30px scroll viewport. Long consequences remain scrollable, rather than changing actor anchors while a pointer is held.

Dock padding10+16→4+4px; the32px upper hand lift/focus gutter remains. Bottom gutter16→8px. Cards150→170px wide, fixed230px→natural height with minimum201px; decorative art66→46px. Existing12px printed rules and16px cost fonts are not changed. Rules use flex:1 0 auto and stats cannot shrink, so longer printed content grows the card/hand/page instead of being clipped. Names retain wrapping and no ellipsis. Five normal cards use890px plus horizontal gutters within the observed1189px hand; larger hands retain horizontal scrolling. Existing accessible activation, hover/tilt/focus/drag/return and reduced-motion paths remain.

Source arithmetic suggests approximately129px reclaimed from the old sampled1016px page when cards fit their201px minimum:14topbar+12HUD+4footer+44preview+18dock padding+8bottom gutter+29card height. This predicts about887px for that old sample before natural-content differences. It is an estimate, not executed CSS geometry or a guarantee for the named-readout build. The added20px card width is intended to reduce wrapping pressure while smaller art preserves rule space; actual fonts determine natural height. None of the four shared readout geometry/arena files, actor bodies, hit regions, rules, saves, RNG or sound changes.

## Remaining risks and next evidence

UNBUILT, UNMERGED and UNPROMOTED. Actual PC fit, card natural sizing, focus scroll, Help return, taller names/intents, hover/focus rings and scrollbar gutters remain unverified. Wider cards show fewer simultaneously in a large hand, while retaining horizontal access. The30px preview viewport can show a partial second line; all consequence text remains in the scrollable accessible node, but discoverability must be independently judged. Large printed text can legitimately exceed900px and retain document scrolling. Header/HUD fixed heights need real computed-font checks to ensure controls and portraits fit. Font/media changes rely on natural CSS content growth; the measured minimum may remain larger than needed until the hand is rebuilt, though it cannot force content smaller.

The tallest-card offsetHeight change also improves the existing measurement outside this PC CSS scope; other viewport styling is unchanged, and no mobile acceptance matrix is requested. Existing input's nearest scrollIntoView behavior is preserved; the goal is to remove the default opening overflow rather than suppress accessible scrolling.

After distinct source review and a separately admitted strict build, compare ordinary1440×900 fresh default opening with its retained baseline: natural focus/scroll/document dimensions, visible How to play and hunter HUD, complete rules/stats/costs/intent, real binding/command, hover/focus/drag lift, long internally scrollable consequence, Help/Escape return and normal/reduced motion. Check one genuinely longer/dense earned content case for honest overflow and reachable controls. No synthetic game state or expanded screen matrix is introduced. Reviewer rejection and real human feedback remain separate from source correctness.

ROOT owns any integration/runtime grant. Apply these two focused hunks only after independent acceptance; restore the exact matching baseline or revert the hunks to roll back. No shared stage/ROOT writes, Node, build, server, browser, art or cleanup occurred. R1/R2 readout failures and R3 freeze are untouched.

RESOURCE.json records fresh24MiB work/512MiB reserve point samples using the interpreter's actual /proc/self/status VmHWM. Point samples do not establish continuous peak usage; earlier ordinary read-only shell/image inspections had no aggregate peak capture.
''')
for name in names:assert read(base/name)==before[name]
assert read(freeze)==frozenbytes and read(visual)==visualbytes and read(report)==reportbytes
guard('final')
(root/'RESOURCE.json').write_text(json.dumps(dict(workBytes=work,reserveBytes=reserve,scope='Source-only two-file proposal and exact-byte assertions',samples=samples),indent=2)+'\n')
files=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name!='MANIFEST.json':
        data=read(p);files.append(dict(relative=str(p.relative_to(root)),bytes=len(data),sha256=sha(data)))
(root/'MANIFEST.json').write_text(json.dumps(dict(status='SEALED PC FIT SOURCE PROPOSAL; UNBUILT; UNMERGED; UNPROMOTED; independent review pending',files=files),indent=2)+'\n')
print(json.dumps(dict(manifestSHA256=sha(read(root/'MANIFEST.json')),diffSHA256=sha(read(root/'CHANGE.diff')),mainSHA256=sha(after['src/main.ts']),cssSHA256=sha(after['src/compact-readout.css']),members=len(files),resource=samples[-1])))
