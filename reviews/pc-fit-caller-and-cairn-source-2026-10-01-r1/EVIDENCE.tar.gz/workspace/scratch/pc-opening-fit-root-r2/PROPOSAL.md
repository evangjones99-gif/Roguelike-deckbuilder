# PC opening fit R2 — source only

ROOT authored this minimal correction after the delegated source author could not be restarted (agent thread limit reached). R1 stays intact. The independent technical reviewer found that the body-mounted drag ghost inherited old inner card spacing inside a newly shorter measured outer card. Four PC selectors now share art height, full name wrapping, nonshrinking description and stats with the actual ghost context. Ghost measured outer dimensions, pointer handling and live hand natural sizing are unchanged. main.ts remains byte-identical to R1.

This is unbuilt and unpromoted; no actual ghost clipping or repaired viewport fit has been observed. Independent review may reject it. No shared source, stage, public alias, rules, saves or old evidence was edited.
