import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

OUT = Path(__file__).resolve().parent
WORK = 128 * 1024 * 1024
RESERVE = 512 * 1024 * 1024
CG = Path('/sys/fs/cgroup')
PAGE = os.sysconf('SC_PAGE_SIZE')
R2 = Path('/workspace/scratch/standard-sol-actor-readout-author-r2/candidate/src/battlefield-layout.ts')
R3 = Path('/workspace/scratch/first-five-opening-readout-stage-r1/src/battlefield-layout.ts')
FREEZE = Path('/workspace/scratch/first-five-opening-readout-runtime-freeze-root-r1.json')
CASE = OUT / 'geometry.mts'

def identity(path):
    s = path.stat()
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'metadata': [s.st_dev, s.st_ino, s.st_mode, s.st_size,
                         s.st_mtime_ns, s.st_ctime_ns, s.st_atime_ns]}

def process_rows(session_id):
    rows = {}
    supervisor_rss = 0
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            stat = (path / 'stat').read_text()
            tail = stat[stat.rfind(')') + 2:].split()
            pid, sid = int(path.name), int(tail[3])
            rss = int(tail[21]) * PAGE
            if pid == os.getpid():
                supervisor_rss = rss
            if session_id is not None and sid == session_id:
                rows[str(pid)] = {'start': tail[19], 'pgid': int(tail[2]),
                                  'sid': sid, 'state': tail[0], 'resident': rss}
        except (OSError, ValueError, IndexError):
            continue
    return rows, supervisor_rss

def stop_owned(process):
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=2)

assert not (OUT / 'RESULT.json').exists(), 'Refuse overwrite or retry in this phase'
started = time.monotonic()
initial = int((CG / 'memory.current').read_text())
limit = int((CG / 'memory.max').read_text())
before = {str(p): identity(p) for p in [R2, R3, FREEZE, CASE, Path(__file__).resolve()]}
assert before[str(R2)]['sha256'] == '1595f72fe8a1fd1a8f9c96302e6d217962098e265046c4d63502e2fb10811840'
assert before[str(R3)]['sha256'] == '6bbe1518398964b624bbcc8ce81f7fb36a02c9902fb8286336e9aae34f4d6b58'
assert CASE.read_bytes() == Path('/workspace/scratch/standard-sol-actor-readout-actual-geometry-independent-r1/geometry.mts').read_bytes()
freeze = json.loads(FREEZE.read_text())
assert freeze['sourceDigest'] == '0cd0cbca6428e29f899cde48e0d759a1441e8b5c9271889b8f464b75e1f09571'
assert freeze['outputsDigest'] == 'ff4e49a4fed2838548c8576ff2f4fbbd82dcf70af98b2d35aeeb41724b6da13f'
assert freeze['inputs']['src/battlefield-layout.ts'] == before[str(R3)]['sha256']
owned, samples = {}, []
reason = None
process = None

def sample(label):
    global reason
    rows, supervisor_rss = process_rows(None if process is None else process.pid)
    owned.update(rows)
    current = int((CG / 'memory.current').read_text())
    phase_resident = supervisor_rss + sum(row['resident'] for row in rows.values())
    row = {'label': label, 'elapsed': time.monotonic() - started,
           'current': current, 'delta': current - initial,
           'phaseResident': phase_resident, 'supervisorResident': supervisor_rss,
           'headroom': limit - current, 'owned': rows}
    samples.append(row)
    if phase_resident > WORK or current - initial > WORK or limit - current < RESERVE:
        reason = reason or '128 MiB total / 512 MiB reserve resource refusal'
    if row['elapsed'] > 55:
        reason = reason or 'bounded phase deadline refusal'
    return rows

if limit - initial < WORK + RESERVE:
    reason = 'fresh admission headroom refusal'
sample('admission')
if reason is None:
    with (OUT / 'stdout.log').open('x') as stdout, (OUT / 'stderr.log').open('x') as stderr:
        process = subprocess.Popen(
            ['node', '--import', '/workspace/Roguelike-deckbuilder/node_modules/tsx/dist/loader.mjs', str(CASE)],
            stdout=stdout, stderr=stderr, start_new_session=True)
        while True:
            sample('running')
            if reason:
                stop_owned(process)
                break
            if process.poll() is not None:
                process.wait()
                break
            time.sleep(.01)

# Record exact session remnants after wait; permit a short bounded natural exit.
if process is not None:
    deadline = min(started + 57, time.monotonic() + 1)
    while True:
        rows = sample('post-wait')
        live = [row for row in rows.values() if row['state'] not in ('Z', 'X')]
        if not live or time.monotonic() >= deadline:
            break
        time.sleep(.01)
    if live:
        reason = reason or 'owned live descendants remained after child wait'
        stop_owned(process)
        sample('post-cancel')

post = {}
for pid, old in owned.items():
    try:
        stat = Path('/proc', pid, 'stat').read_text()
        tail = stat[stat.rfind(')') + 2:].split()
        post[pid] = {'sameIdentity': tail[19] == old['start'], 'state': tail[0],
                     'resident': int(tail[21]) * PAGE}
    except OSError:
        post[pid] = {'absent': True}
for path, old in before.items():
    new = identity(Path(path))
    assert new['sha256'] == old['sha256']
    assert new['metadata'][:6] == old['metadata'][:6]
    old['afterMetadata'] = new['metadata']
sample('final')
whole = time.monotonic() - started
if whole > 60:
    reason = reason or 'whole phase exceeded 60 seconds'
status = 'REFUSED' if reason else 'PASS' if process and process.returncode == 0 else 'FAIL'
result = {'status': status, 'reason': reason, 'exit': None if process is None else process.returncode,
          'naturalCommandCompletion': process is not None and reason is None,
          'wholeSeconds': whole, 'beforeAfterPins': before, 'ownedIdentities': owned,
          'ownedPostWait': post, 'samples': samples, 'workBytes': WORK, 'reserveBytes': RESERVE,
          'sampledPhaseResidentPeak': max(row['phaseResident'] for row in samples),
          'allSampleRowsWithinLimits': all(row['phaseResident'] <= WORK and row['delta'] <= WORK and row['headroom'] >= RESERVE for row in samples),
          'continuousAggregatePeakEstablished': False,
          'accounting': 'Both own resident sum (supervisor plus observed launched-session members) and cgroup delta independently bounded; current headroom retains reserve',
          'scope': 'Exact unchanged R1 focused case source; actual exported geometry only; no browser/server/engine fixtures/build; no retry'}
(OUT / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['status', 'reason', 'exit', 'wholeSeconds', 'naturalCommandCompletion', 'sampledPhaseResidentPeak', 'allSampleRowsWithinLimits', 'ownedPostWait']}))
if (OUT / 'stdout.log').exists():
    print((OUT / 'stdout.log').read_text())
if (OUT / 'stderr.log').exists():
    print((OUT / 'stderr.log').read_text()[:2000])
