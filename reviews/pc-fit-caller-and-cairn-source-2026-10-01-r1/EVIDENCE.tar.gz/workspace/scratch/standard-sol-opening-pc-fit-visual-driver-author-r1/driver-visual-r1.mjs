// UNEXECUTED independent PC-fit visual driver. Explicit ROOT runtime grant required.
// Uses a separately reviewed narrow R8 supervisor; no baseline gate is borrowed.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/playwright-core/index.mjs';

const [stage,freezePath,packet,portText]=process.argv.slice(2),port=Number(portText),started=Date.now();
// A single separately reviewed literal parameter file will name ROOT's repaired
// candidate. Pending parameters fail before any server/browser is launched.
const expected=JSON.parse(fs.readFileSync('/workspace/scratch/standard-sol-opening-pc-fit-visual-driver-author-r1/EXPECTED-CANDIDATE.json'));
assert.equal(expected.status,'FROZEN_FOR_REVIEW','Repaired candidate freeze has not been supplied/reviewed');
assert.equal(stage,expected.stage);assert.equal(freezePath,expected.freezePath);
assert(packet?.startsWith('/workspace/scratch/standard-sol-opening-pc-fit-visual-actual-'));
assert(Number.isInteger(port)&&port>1024&&port<65536);
const hash=b=>createHash('sha256').update(b).digest('hex');
const freezeBytes=fs.readFileSync(freezePath),freeze=JSON.parse(freezeBytes);
assert.equal(hash(freezeBytes),expected.freezeSHA256);
assert.equal(freeze.stage,stage);
assert.equal(freeze.sourceDigest,expected.sourceDigest);
assert.equal(freeze.outputsDigest,expected.outputsDigest);
assert.equal(freeze.inputCount,87);assert.equal(freeze.outputCount,56);
const admission=JSON.parse(fs.readFileSync(path.join(packet,'ADMISSION.json'))),work=896*1048576,reserve=512*1048576;
const current=Number(fs.readFileSync('/sys/fs/cgroup/memory.current','utf8')),maximum=Number(fs.readFileSync('/sys/fs/cgroup/memory.max','utf8'));
const spent=Math.max(0,current-admission.initial.current);
assert(admission.admitted===true&&admission.stage===stage&&admission.freeze===freezePath&&admission.work===work&&admission.reserve===reserve&&admission.initial.maximum===maximum&&admission.initial.headroom>=work+reserve&&spent<=work&&maximum-current>=reserve+Math.max(0,work-spent),'Same outer896+512 accounting rejected');
fs.writeFileSync(path.join(packet,'INSIDE-PHASE-ACCOUNTING.json'),JSON.stringify({work,reserve,current,maximum,spent,remaining:Math.max(0,work-spent),freshAdmission:false,sameOuterAdmission:true})+'\n');
const result={scope:'Affected opening visual/native UI only; fresh1440x900/DPR1 Initiate random; no human fun, engine imports, saved-state injection, pixel integration or whole-game acceptance',sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,actions:[],captures:[],geometry:[],fitObservations:[],ghostObservations:[],previewKeyboardObservations:[],browser:'NOT_LAUNCHED',server:'NOT_LAUNCHED',mechanicalPass:false,personallyViewed:false};
let browser,context,page,server,stopReason=null,timer,auditBefore=false,closingPromise=null,closedBrowser=null,closedServer=null;
const K='hollowpact.run.v2',expectedCue='Bind your first creature. Click or drag a BINDING card.';
const stamp=()=>({utc:new Date().toISOString(),wholeElapsedMs:Date.now()-started});
function log(name,data){fs.appendFileSync(path.join(packet,name),JSON.stringify({...stamp(),...data})+'\n');}
function persist(){fs.writeFileSync(path.join(packet,'VISUAL-PROGRESS.json'),JSON.stringify(result,null,2)+'\n');}
function check(){if(stopReason||Date.now()-started>=90000)throw Error(stopReason||'90s visual driver abort');}
async function hashFile(file){const h=createHash('sha256');let bytes=0;for await(const b of fs.createReadStream(file,{flags:fs.constants.O_RDONLY|fs.constants.O_NOATIME|fs.constants.O_NOFOLLOW,highWaterMark:32768})){check();h.update(b);bytes+=b.length;}return {sha256:h.digest('hex'),bytes};}
async function audit(label){
 const row={label,inputs:[],outputs:[]};assert.equal(Object.keys(freeze.inputs).length,87);assert.equal(Object.keys(freeze.outputs).length,56);
 for(const [rel,expected] of Object.entries(freeze.inputs)){check();const actual=await hashFile(path.join(stage,rel));assert.equal(actual.sha256,expected,'Input mismatch '+rel);row.inputs.push({path:rel,...actual});}
 for(const [rel,expected] of Object.entries(freeze.outputs)){check();const actual=await hashFile(path.join(stage,'dist',rel));assert.equal(actual.sha256,expected,'Output mismatch '+rel);row.outputs.push({path:rel,...actual});}
 fs.writeFileSync(path.join(packet,`BYTE-AUDIT-${label}.json`),JSON.stringify(row,null,2)+'\n');
}
async function bounded(promise,ms,label){let t;try{return await Promise.race([promise,new Promise((_,reject)=>{t=setTimeout(()=>reject(Error(label+' timeout')),ms);})]);}finally{clearTimeout(t);}}
async function close(reason){
 if(closingPromise)return closingPromise;
 closingPromise=(async()=>{
  log('LIFECYCLE.jsonl',{event:'close initiated',reason});const errors=[],ownedBrowser=browser,ownedServer=server;
  try{if(ownedBrowser){await bounded(ownedBrowser.close(),8000,'browser close');closedBrowser=ownedBrowser;result.browser='CLOSED';}}catch(e){errors.push(String(e));result.browser='CLOSE_UNCONFIRMED';}
  try{if(ownedServer){ownedServer.closeIdleConnections?.();await bounded(new Promise((resolve,reject)=>ownedServer.close(e=>e?reject(e):resolve())),2000,'server close');closedServer=ownedServer;result.server='CLOSED';}}catch(e){errors.push(String(e));result.server='CLOSE_UNCONFIRMED';}
  if(errors.length){result.closeErrors=errors;result.mechanicalPass=false;process.exitCode=2;}
  log('LIFECYCLE.jsonl',{event:errors.length?'close failures':'normal browser and server close',reason,errors});persist();
 })();return closingPromise;
}
function abort(reason){if(stopReason)return;stopReason=reason;result.abortReason=reason;result.mechanicalPass=false;process.exitCode=2;void close(reason).catch(e=>{result.closeFailure=String(e);process.exitCode=2;});}
process.once('SIGTERM',()=>abort('supervisor SIGTERM'));
timer=setTimeout(()=>abort('90s visual driver abort'),Math.max(0,90000-(Date.now()-started)));
async function rawSave(){check();return page.evaluate(k=>localStorage.getItem(k),K);}
async function settle(){check();await page.waitForTimeout(220);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));check();}
async function owned(locator){
 check();await locator.waitFor();await locator.scrollIntoViewIfNeeded();await settle();
 let b=await locator.boundingBox();assert(b,'Missing pointer box');await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await settle();
 b=await locator.boundingBox();assert(b,'Owner vanished after hover');const point={x:b.x+b.width/2,y:b.y+b.height/2};
 // Move to the final settled coordinate that will actually be pressed. Do not
 // assert/log a recomputed center while leaving the mouse at the prior center.
 await page.mouse.move(point.x,point.y);await settle();
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},point),'Fresh actual pointer owner missing');
 assert(await locator.evaluate(e=>!e.disabled&&e.getAttribute('aria-disabled')!=='true'),'Unavailable control');return point;
}
async function click(locator,label){
 const p=await owned(locator),before=await rawSave(),n=await page.evaluate(()=>window.__cueVisualEvents.length);
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual press owner changed');await page.mouse.down();await page.waitForTimeout(60);check();assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual release owner changed');
 await page.mouse.up();await settle();const events=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);assert(events.some(e=>e.type==='pointerdown'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1)&&events.some(e=>e.type==='pointerup'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1),'Missing trusted native press/release at actual checked coordinates');
 result.actions.push({label,point:p,beforeSHA:before===null?null:hash(before),afterSHA:await rawSave().then(v=>v===null?null:hash(v)),events});persist();
}
async function geometry(label){
 check();const row=await page.evaluate(()=>{
  const rect=e=>e.getBoundingClientRect().toJSON(),text=e=>{const css=getComputedStyle(e),range=document.createRange();range.selectNodeContents(e);return {text:e.innerText,rect:rect(e),glyphRect:range.getBoundingClientRect().toJSON(),font:css.font,fontSize:css.fontSize,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,scrollTop:e.scrollTop,overflowX:css.overflowX,overflowY:css.overflowY};};
  const cue=document.querySelector('.first-binding-cue'),hand=document.querySelector('.hand-cards'),preview=document.querySelector('#consequence-preview');
  return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio,reducedMotion:matchMedia('(prefers-reduced-motion: reduce)').matches},scroll:{x:scrollX,y:scrollY,width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight},active:{tag:document.activeElement?.tagName,ui:document.activeElement?.dataset?.ui,focus:document.activeElement?.dataset?.focus,card:document.activeElement?.dataset?.card,aria:document.activeElement?.getAttribute('aria-label')},dialog:{open:document.querySelector('#dialog').open,text:document.querySelector('#dialog').innerText},cue:cue?text(cue):null,preview:preview?{...text(preview),kind:preview.dataset.preview}:null,heading:document.querySelector('.hand-heading')?text(document.querySelector('.hand-heading')):null,hand:hand?{rect:rect(hand),clientWidth:hand.clientWidth,scrollWidth:hand.scrollWidth,scrollLeft:hand.scrollLeft}:null,chrome:[...document.querySelectorAll('#topbar,#hud,#footer')].map(e=>({id:e.id,...text(e)})),actors:[...document.querySelectorAll('.field-actor:not([hidden])')].map(e=>({uid:e.dataset.actor,cell:rect(e),body:rect(e.querySelector('.field-unit')),intent:text(e.querySelector('.field-intent')),identity:text(e.querySelector('.field-nameplate')),inspect:rect(e.querySelector('.field-inspect')),stats:text(e.querySelector('.field-stat-line')),ready:e.querySelector('.field-ready')?text(e.querySelector('.field-ready')):null,publishedReadoutWidth:e.querySelector('.field-intent').style.width,publishedInspectWidth:e.querySelector('.field-inspect').style.width})),help:[...document.querySelectorAll('[data-ui="help"]')].map(text),cards:[...document.querySelectorAll('.hand-cards .game-card')].map(e=>({card:e.dataset.card,index:e.dataset.index,unavailable:e.getAttribute('aria-disabled'),...text(e),cost:text(e.querySelector('.card-cost')),rules:text(e.querySelector('.card-description')),art:text(e.querySelector('.card-art')),name:text(e.querySelector('.card-name')),stats:e.querySelector('.card-stats')?text(e.querySelector('.card-stats')):null})),readouts:[...document.querySelectorAll('.field-intent,.field-ready,.field-stats,.field-identity,.field-inspect')].map(text)};
 });result.geometry.push({label,...row});
 const inViewport=r=>r.left>=-1&&r.top>=-1&&r.right<=row.viewport.width+1&&r.bottom<=row.viewport.height+1;
 const contains=(outer,inner)=>inner.width===0||inner.left>=outer.left-1&&inner.top>=outer.top-1&&inner.right<=outer.right+1&&inner.bottom<=outer.bottom+1;
 const parts=row.cards.flatMap(c=>[c.cost,c.rules,c.name,...(c.stats?[c.stats]:[])]);
 const observation={label,documentFits:row.scroll.height<=row.viewport.height+1&&row.scroll.width<=row.viewport.width+1,chromeFits:row.chrome.every(c=>inViewport(c.rect)),helpFits:row.help.every(c=>inViewport(c.rect)),allCardsFit:row.cards.every(c=>inViewport(c.rect)),allEssentialCardPartsFit:parts.every(c=>inViewport(c.glyphRect)),essentialCardTextUnclipped:row.cards.every(c=>[c.cost,c.rules,c.name,...(c.stats?[c.stats]:[])].every(p=>contains(c.rect,p.glyphRect)&&p.scrollWidth<=p.clientWidth+1&&p.scrollHeight<=p.clientHeight+1)),essentialFontsAtLeast12:parts.every(c=>parseFloat(c.fontSize)>=12),fullHorizontalHand:!row.hand||row.hand.scrollWidth<=row.hand.clientWidth+1,readoutCap240:row.actors.every(a=>a.intent.rect.width<=240.5&&a.inspect.width<=240.5),nameplatesComplete:row.actors.every(a=>a.identity.text.trim().length>0&&contains(a.inspect,a.identity.glyphRect)),actors:row.actors.map(a=>({uid:a.uid,name:a.identity.text,body:a.body,cell:a.cell,publishedReadoutWidth:a.publishedReadoutWidth,publishedInspectWidth:a.publishedInspectWidth}))};
 result.fitObservations.push(observation);persist();return row;
}
// Read-only ordinary DOM evidence; no game-state/layout mutation or synthetic input.
async function appearance(locator){
 return locator.evaluate(e=>{
  const rect=n=>n.getBoundingClientRect().toJSON(),rangeRect=n=>{const r=document.createRange();r.selectNodeContents(n);return r.getBoundingClientRect().toJSON();};
  const part=selector=>{const n=e.querySelector(selector);if(!n)return null;const c=getComputedStyle(n);return {text:n.innerText,font:c.font,fontSize:c.fontSize,lineHeight:c.lineHeight,height:c.height,width:c.width,rect:rect(n),glyphRect:rangeRect(n),clientWidth:n.clientWidth,scrollWidth:n.scrollWidth,clientHeight:n.clientHeight,scrollHeight:n.scrollHeight,overflowX:c.overflowX,overflowY:c.overflowY};};
  return {card:rect(e),cost:part('.card-cost'),art:part('.card-art'),name:part('.card-name'),rules:part('.card-description'),stats:part('.card-stats')};
 });
}
async function ghostEvidence(card,sourceAppearance){
 const ghost=await appearance(page.locator('.tactile-ghost-card'));
 const parts=['cost','name','rules','stats'];
 const parity=parts.every(k=>sourceAppearance[k]===null&&ghost[k]===null||sourceAppearance[k]&&ghost[k]&&sourceAppearance[k].text===ghost[k].text&&sourceAppearance[k].fontSize===ghost[k].fontSize&&sourceAppearance[k].lineHeight===ghost[k].lineHeight);
 const fits=parts.every(k=>!ghost[k]||ghost[k].scrollWidth<=ghost[k].clientWidth+1&&ghost[k].scrollHeight<=ghost[k].clientHeight+1&&ghost[k].glyphRect.left>=ghost.card.left-1&&ghost[k].glyphRect.top>=ghost.card.top-1&&ghost[k].glyphRect.right<=ghost.card.right+1&&ghost[k].glyphRect.bottom<=ghost.card.bottom+1);
 result.ghostObservations.push({label:'actual held legal deploy ghost',source:sourceAppearance,heldSource:await appearance(card),ghost,innerTextAndFontParity:!!parity,artHeightParity:sourceAppearance.art.height===ghost.art.height,ghostEssentialTextUnclipped:fits,note:'Source hovered transform can enlarge outer geometry; compare inner computed art height/fonts and full text, not falsely require identical transformed rectangles.'});persist();await shot('held-ghost-parity');
}
async function previewKeyboardIfLong(row){
 if(!row.preview||row.preview.scrollHeight<=row.preview.clientHeight+1){result.previewKeyboardObservations.push({label:row.label,status:'SKIPPED_NO_NATURALLY_OVERFLOWING_PREVIEW'});persist();return;}
 const before=await rawSave(),start=await page.evaluate(()=>window.__cueVisualEvents.length);
 let reached=false,steps=0;
 for(;steps<24;steps++){await page.keyboard.press('Tab');await settle();if(await page.locator('#consequence-preview').evaluate(e=>e===document.activeElement)){reached=true;break;}}
 const previous=await page.locator('#consequence-preview').evaluate(e=>({scrollTop:e.scrollTop,text:e.textContent,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight}));
 if(reached){await page.keyboard.press('ArrowDown');await page.waitForTimeout(250);await settle();}
 const after=await page.locator('#consequence-preview').evaluate(e=>({scrollTop:e.scrollTop,text:e.textContent,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight}));
 result.previewKeyboardObservations.push({label:row.label,reachedByNativeTab:reached,tabSteps:steps,previous,after,textPreserved:previous.text===after.text,savePure:await rawSave()===before,nativeArrowScrolled:reached&&after.scrollTop>previous.scrollTop,events:await page.evaluate(n=>window.__cueVisualEvents.slice(n),start)});persist();
}
async function shot(label){
 check();assert(result.captures.length<11,'Capture cap exceeded');const file=path.join(packet,`${String(result.captures.length+1).padStart(2,'0')}-${label}.jpg`);await page.screenshot({path:file,type:'jpeg',quality:78});result.captures.push({label,path:file,...await hashFile(file),personallyViewed:false});persist();
}
try{
 await audit('before');auditBefore=true;check();const keys=Object.keys(freeze.outputs).sort();
 server=http.createServer((req,res)=>{try{const pathname=new URL(req.url,'http://localhost').pathname,key=pathname==='/'?'index.html':decodeURIComponent(pathname.slice(1));if(!keys.includes(key)){res.writeHead(404);res.end('Not found');return;}res.setHeader('Content-Type',key.endsWith('.html')?'text/html':key.endsWith('.js')?'text/javascript':key.endsWith('.css')?'text/css':key.endsWith('.png')?'image/png':key.endsWith('.json')?'application/json':'application/octet-stream');const stream=fs.createReadStream(path.join(stage,'dist',key));stream.on('error',()=>res.destroy());stream.pipe(res);}catch{res.writeHead(400);res.end('Bad request');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});result.server='OPEN';
 const served=[];for(const rel of keys){check();const response=await fetch(`http://127.0.0.1:${port}/${rel.split('/').map(encodeURIComponent).join('/')}`,{signal:AbortSignal.timeout(8000)});assert(response.ok,'Serve failed '+rel);const h=createHash('sha256');let bytes=0;for await(const b of response.body){check();h.update(b);bytes+=b.length;}const sha256=h.digest('hex');assert.equal(sha256,freeze.outputs[rel],'Served mismatch '+rel);served.push({path:rel,bytes,sha256});}
 fs.writeFileSync(path.join(packet,'SERVED-BYTE-AUDIT.json'),JSON.stringify({sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,served},null,2)+'\n');
 check();browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox'],timeout:12000});result.browser='OPEN';check();
 context=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'no-preference'});
 // Passive pre-app WINDOW capture sees handled drag Escape before the game
 // stops propagation there; it never prevents, stops or dispatches any input.
 await context.addInitScript(()=>{window.__cueVisualEvents=[];for(const type of ['pointerdown','pointerup','click','focusin','keydown'])window.addEventListener(type,e=>{window.__cueVisualEvents.push({type,trusted:e.isTrusted,observedAtMs:performance.now(),key:e.key,x:e.clientX,y:e.clientY,ui:e.target.closest?.('[data-ui]')?.dataset.ui,card:e.target.closest?.('[data-card]')?.dataset.card,index:e.target.closest?.('[data-card]')?.dataset.index});if(window.__cueVisualEvents.length>1000)window.__cueVisualEvents.splice(0,200);},{capture:true,passive:true});});
 page=await context.newPage();page.setDefaultTimeout(5000);page.on('pageerror',e=>log('ERRORS.jsonl',{kind:'pageerror',error:String(e)}));
 await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded',timeout:12000});await settle();await shot('title');
 await click(page.locator('#scene-ui [data-ui="new"]'),'open normal contract');result.defaultSeed=await page.locator('#seed').inputValue();
 await click(page.locator('#new-game-form [type="submit"]'),'start normal default Initiate');await page.waitForTimeout(600);
 const initial=JSON.parse(await rawSave());assert.equal(initial.phase,'battle');assert.equal(initial.difficulty,0);result.actualOpening={seed:initial.seed,hand:initial.hand,allies:initial.allies,enemies:initial.enemies,floor:initial.floor,turn:initial.turn};
 const natural=await geometry('natural opening before mouse travel or manual scroll');await shot('natural-opening');assert(!natural.dialog.open,'Unexpected automatic modal');
 const summons=page.locator('.hand-cards .game-card.summon[aria-disabled="false"]');result.legalSummonSample=await summons.count()>0;
 if(result.legalSummonSample){assert.equal(natural.cue?.text.replace(/\s+/g,' ').trim(),expectedCue,'Missing persistent exact cue');}
 else{assert.equal(natural.cue,null,'Cue despite no legal summon');result.coverageGap='Random sampled opening has no legal summon; no injected state, reroll or binding result claim.';}
 const beforeHelp=await rawSave();await click(page.locator('[data-ui="help"]'),'optional How to play');await geometry('Help');await shot('optional-help');
 await page.keyboard.press('Escape');await settle();assert(!(await page.locator('#dialog').evaluate(e=>e.open)),'Native Escape did not close Help');assert.equal(await rawSave(),beforeHelp,'Help changed actual save');
 const returned=await geometry('Help Escape return');assert.equal(returned.active.ui,'help','Help did not restore semantic source focus');await shot('help-return');
 if(result.legalSummonSample){
  const card=summons.first(),beforeHover=await rawSave();await owned(card);assert.equal(await rawSave(),beforeHover,'Hover changed save');const hover=await geometry('legal binding settled hover');assert.equal(hover.cue?.text.replace(/\s+/g,' ').trim(),expectedCue,'Hover erased cue');assert.equal(hover.preview?.kind,'consequence','Legal binding consequence lost');await shot('binding-hover');await previewKeyboardIfLong(hover);
  const p=await owned(card),cancelOccurrence={cardId:await card.getAttribute('data-card'),index:await card.getAttribute('data-index')},n=await page.evaluate(()=>window.__cueVisualEvents.length);assert(await card.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Cancel source actual press owner changed');
  await page.mouse.down();await page.mouse.move(5,Math.max(5,p.y-100),{steps:10});await page.waitForTimeout(850);await page.keyboard.press('Escape');await page.waitForTimeout(850);await page.mouse.up();await settle();
  const cancelEvents=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n),down=cancelEvents.find(e=>e.type==='pointerdown'&&e.trusted),escape=cancelEvents.find(e=>e.type==='keydown'&&e.key==='Escape'&&e.trusted),up=cancelEvents.find(e=>e.type==='pointerup'&&e.trusted);
  const held={downToEscapeMs:down&&escape?escape.observedAtMs-down.observedAtMs:null,escapeToUpMs:escape&&up?up.observedAtMs-escape.observedAtMs:null,downToUpMs:down&&up?up.observedAtMs-down.observedAtMs:null};
  const cancelObservation={label:'native outside drag held over700ms before and after Escape',sourcePoint:p,occurrence:cancelOccurrence,events:cancelEvents,measuredHold:held,assertionsPending:true};result.actions.push(cancelObservation);persist();
  // Preserve raw observations before any assertion can interrupt the phase.
  assert(down&&down.card===cancelOccurrence.cardId&&down.index===cancelOccurrence.index&&escape&&up,'Held cancel lacks native occurrence press/key/release');assert(held.downToEscapeMs>700&&held.escapeToUpMs>700&&held.downToUpMs>1400,'Long hold not actually measured');
  assert.equal(await rawSave(),beforeHover,'Held Escape/outside cancel changed save');assert.equal(await page.locator('.tactile-layer').count(),0,'Canceled ghost remains');cancelObservation.assertionsPending=false;cancelObservation.savePure=true;persist();
  const canceled=await geometry('after long held Escape cancel');assert.equal(canceled.cue?.text.replace(/\s+/g,' ').trim(),expectedCue,'Cancel erased cue');await shot('held-cancel');
  const before=JSON.parse(await rawSave()),occurrence={cardId:await card.getAttribute('data-card'),index:await card.getAttribute('data-index')},zone=page.locator('[data-tactile-drop-zone="deploy"]');
  const sourcePoint=await owned(card),sourceAppearance=await appearance(card);const z=await zone.boundingBox();assert(z&&z.width>=80&&z.height>=30,'No actual marked deploy apron');const dest={x:z.x+z.width/2,y:z.y+z.height/2};
  const bindStart=await page.evaluate(()=>window.__cueVisualEvents.length);assert(await card.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},sourcePoint),'Binding source actual press owner changed');await page.mouse.down();await page.mouse.move(dest.x,dest.y,{steps:12});await settle();
  assert.equal(await zone.getAttribute('data-active'),'true','Deploy apron not active');assert.equal(await page.locator('.tactile-ghost').getAttribute('data-legal'),'true','Actual release preview not legal');
  assert(await page.evaluate(p=>{const e=document.elementFromPoint(p.x,p.y);return e&&!e.closest('#dialog,#dock,.battle-guidance,[data-ui="inspect-unit"],[data-unit],.hunter-hud [data-ui="hunter"]');},dest),'Apron release ownership intercepted');
  const dragged=await geometry('legal actual binding drag release preview');assert.equal(dragged.cue?.text.replace(/\s+/g,' ').trim(),expectedCue,'Legal drag erased cue');assert.equal(dragged.preview?.kind,'consequence','Legal drag lost consequence');
  await ghostEvidence(card,sourceAppearance);await page.mouse.up();await page.waitForTimeout(500);await settle();const bindEvents=await page.evaluate(n=>window.__cueVisualEvents.slice(n),bindStart);assert(bindEvents.some(e=>e.type==='pointerdown'&&e.trusted&&e.card===occurrence.cardId&&e.index===occurrence.index&&Math.abs(e.x-sourcePoint.x)<=1&&Math.abs(e.y-sourcePoint.y)<=1)&&bindEvents.some(e=>e.type==='pointerup'&&e.trusted&&Math.abs(e.x-dest.x)<=1&&Math.abs(e.y-dest.y)<=1),'Binding lacks native occurrence press/release at checked coordinates');result.actions.push({label:'one actual legal first binding drag',sourcePoint,occurrence,destination:dest,events:bindEvents});
  const after=JSON.parse(await rawSave());assert.equal(after.allies.length,before.allies.length+1,'Binding did not commit');assert.equal(await page.locator('.first-binding-cue').count(),0,'Earned binding retained cue');result.binding={occurrence,beforeAllies:before.allies.length,afterAllies:after.allies.length,afterHand:after.hand};await geometry('earned first binding');await shot('earned-binding');
  const ready=after.allies.find(u=>!u.acted&&u.hp>0),enemy=after.enemies.find(u=>u.hp>0);
  if(ready&&enemy){const beforeTarget=await rawSave();await click(page.locator(`.field-unit[data-unit="${ready.uid}"]`),'select actual ready binding');await owned(page.locator(`.field-unit[data-unit="${enemy.uid}"]`));const target=await geometry('actual target consequence');assert.equal(target.preview?.kind,'consequence','Target outcome missing');assert.equal(await rawSave(),beforeTarget,'Target preview changed save');await shot('target-preview');await previewKeyboardIfLong(target);await page.keyboard.press('Escape');await settle();assert.equal(await rawSave(),beforeTarget,'Target cancel changed save');}
  else result.targetCoverageGap='No living ready ally/hostile after binding; no invented target coverage.';
 }
 // One native motion preference check in the same actual context; no second warm game page.
 const beforeMotion=await rawSave();await page.emulateMedia({reducedMotion:'reduce'});await settle();const legalMotionCard=page.locator('.hand-cards .game-card[aria-disabled="false"]').first();if(await legalMotionCard.count())await owned(legalMotionCard);assert.equal(await rawSave(),beforeMotion,'Reduced-motion hover changed canonical save');const motion=await geometry('native reduced motion preference and hover');assert(motion.viewport.reducedMotion,'Native motion preference absent');await shot('reduced-motion');
 const beforeReload=await rawSave();await page.reload({waitUntil:'domcontentloaded',timeout:12000});await settle();assert.equal(await rawSave(),beforeReload,'Local reload changed saved run');await click(page.locator('#scene-ui [data-ui="resume"]'),'ordinary Continue after actual local reload');assert.equal(await rawSave(),beforeReload,'Continue changed actual saved run');await geometry('actual reload and Continue');await shot('reload-continue');result.pcViewportFit=result.fitObservations.filter(x=>['natural opening before mouse travel or manual scroll','Help Escape return','actual reload and Continue'].includes(x.label)).every(x=>x.documentFits&&x.chromeFits&&x.helpFits&&x.allCardsFit&&x.allEssentialCardPartsFit&&x.essentialCardTextUnclipped&&x.essentialFontsAtLeast12&&x.fullHorizontalHand);persist();
 await context.storageState({path:path.join(packet,'ACTUAL-CONTEXT-STORAGE.json')});fs.writeFileSync(path.join(packet,'LAST-ACTUAL-SAVE.json'),JSON.stringify({observedOnly:true,raw:await rawSave()})+'\n');
 check();result.completed=true;result.mechanicalPass=true;
}catch(e){result.failure=e.stack;result.mechanicalPass=false;process.exitCode=2;log('FAILURE.jsonl',{error:String(e)});}
finally{
 await close(stopReason||'visual checks completed or failed');
 // Cancellation can race async launch/listen. An earlier completed close does
 // not cover a subsequently returned owned browser/server; retire those too.
 if(browser&&browser!==closedBrowser||server&&server!==closedServer){closingPromise=null;await close('final late-created or unconfirmed owned-resource cleanup');}
 if(auditBefore&&!stopReason){try{await audit('after');}catch(e){result.afterAuditFailure=e.stack;result.mechanicalPass=false;process.exitCode=2;}}
 clearTimeout(timer);result.wholeElapsedMs=Date.now()-started;if(stopReason){result.mechanicalPass=false;process.exitCode=2;}
 fs.writeFileSync(path.join(packet,'VISUAL-RESULT.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({browser:result.browser,server:result.server,completed:result.completed,mechanicalPass:result.mechanicalPass,wholeElapsedMs:result.wholeElapsedMs,coverageGap:result.coverageGap,failure:result.failure?.split('\n')[0],abortReason:stopReason}));
}
