from pathlib import Path
import json,zipfile,subprocess,warnings,stat
base=Path(__file__).parent;out=base/'extra-zip-probes';out.mkdir();extract=base/'reproduced/extraction.py';rows=[]
cases=[('single-backslash-unrelated',[('native.zip',b'original'),('folder'+chr(92)+'evil',b'not-extracted')],False),('duplicate-unrelated',[('native.zip',b'original'),('extra',b'one'),('extra',b'two')],True),('selected-symbolic-link',[(zipfile.ZipInfo('native.zip'),b'original')],True)]
for name,entries,expected in cases:
 z=out/(name+'.zip');o=out/(name+'.out')
 with warnings.catch_warnings():
  warnings.simplefilter('ignore')
  with zipfile.ZipFile(z,'w') as archive:
   for entry,data in entries:
    if isinstance(entry,zipfile.ZipInfo):entry.create_system=3;entry.external_attr=(stat.S_IFLNK|0o777)<<16
    archive.writestr(entry,data)
 p=subprocess.run(['python3',str(extract),str(z),str(o),'native.zip','8'],capture_output=True,text=True)
 rows.append({'name':name,'expectedRefusal':not expected,'actualExit':p.returncode,'expectedMet':(p.returncode==0)==expected,'stderr':p.stderr,'selectedOutput':o.read_bytes().decode() if o.exists() else None})
z=out/'selected-encrypted-header.zip'
with zipfile.ZipFile(z,'w') as archive:archive.writestr('native.zip',b'original')
b=bytearray(z.read_bytes());local=b.find(b'PK\x03\x04');central=b.find(b'PK\x01\x02');b[local+6]|=1;b[central+8]|=1;z.write_bytes(b);p=subprocess.run(['python3',str(extract),str(z),str(out/'selected-encrypted-header.out'),'native.zip','8'],capture_output=True,text=True);rows.append({'name':'selected-encrypted-header','expectedRefusal':True,'actualExit':p.returncode,'expectedMet':p.returncode!=0,'stderr':p.stderr,'qualification':'Actual ZIP header encryption flags; synthetic unencrypted data remains present; parser must reject before any password or member decode'})
(base/'extra-zip-results-r1.json').write_text(json.dumps({'scope':'Exact extraction subprocess source unchanged; actual tiny ZIPs; unselected paths never extracted and selected symlink bytes treated only as bounded file bytes, never followed/executed','cases':rows},indent=2)+'\n')
print(json.dumps(rows,indent=2))
