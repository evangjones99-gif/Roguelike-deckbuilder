import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const dir=path.dirname(new URL(import.meta.url).pathname);
const source=fs.readFileSync(path.join(dir,'workflow-script.js'),'utf8');
const meta=JSON.parse(fs.readFileSync(path.join(dir,'github-read-metadata.json')));
const manifest=fs.readFileSync(path.join(dir,'manifest.json'));
const sums=fs.readFileSync(path.join(dir,'SHA256SUMS'));
const sha=d=>d.virtual ? d.sha : crypto.createHash('sha256').update(d).digest('hex');
const nativeName='hollowpact-0.6.1-windows-native-x64.zip', evidenceName='hollowpact-0.6.1-native-evidence-36791619534-1.zip';
const native={virtual:true,length:183597187,sha:'06e48cce30ccd2a8fcfcc7a829ec79d3fa6b628541a19effa368852df0bce90b'};
const token='MOCK_TOKEN_NOT_A_CREDENTIAL';
async function run(name,opt={}) {
 const files=new Map(),calls=[],cancellations=[],failures=[];let rid=900,aid=1000,current,readCount=0,extractCount=0;
 const marker='Preservation manifest SHA256: 6999e88dfc4b19626e50734571e997c9fd19b1a5c2e4ce9439159343160fd500';
 const baseRelease={id:rid,tag_name:'v0.6.1',draft:true,prerelease:true,body:marker,html_url:'https://github.com/evangjones99-gif/Roguelike-deckbuilder/releases/tag/MOCK'};
 let assets=[];const assetData=new Map();
 if(opt.existing)current={...baseRelease,...opt.release};
 const wrap=meta.artifacts.find(a=>a.id===11132128179),evidenceMeta=meta.artifacts.find(a=>a.id===11131988966);
 const payloads=new Map([[wrap.id,{virtual:true,length:wrap.size_in_bytes,sha:wrap.digest.slice(7)}],[evidenceMeta.id,{virtual:true,length:evidenceMeta.size_in_bytes,sha:evidenceMeta.digest.slice(7)}]]);
 const fsMock={mkdirSync(){},statfsSync(){return {bsize:1,bavail:opt.diskLow?1:1024**3}},writeFileSync(p,d){files.set(path.basename(p),d)},readFileSync(p){const d=files.get(path.basename(p)); assert(d!==undefined);return d},statSync(p){return {size:files.get(path.basename(p)).length}}};
 const cryptoMock={createHash(){let d;return{update(v){d=v;return this},digest(){if(opt.bypassMetadataHash&&Buffer.isBuffer(d)&&d.toString().startsWith('{'))return sha(manifest);return sha(d)}}}};
 const bufferMock={from(v,encoding){return v.virtual?v:Buffer.from(v,encoding)},concat(chunks,n){if(chunks.some(c=>c.virtual))return {...chunks[0],length:n};return Buffer.concat(chunks,n)}};
 const record=(method,args)=>{calls.push({method,args:Object.fromEntries(Object.entries(args).filter(([k])=>!['data','content'].includes(k)))});assert(args.owner==='evangjones99-gif'&&args.repo==='Roguelike-deckbuilder');};
 const response=d=>({status:200,ok:true,headers:{get(k){return k==='content-length'?(opt.badHeader?'garbage':String(d.length+(opt.headerOversize?1:0))):null}},body:opt.noBody?null:{getReader(){let done=false;return{async read(){if(done)return {done:true};done=true;let value=d;if(opt.streamOversize)value=d.virtual?{...d,length:d.length+1}:Buffer.concat([d,Buffer.alloc(1)]);if(opt.shortBody)value=d.virtual?{...d,length:d.length-1}:d.subarray(0,-1);return {done:false,value}},async cancel(){cancellations.push('cancelled')},releaseLock(){}}}}});
 let pending;
 const fetchMock=async(url,opts={})=>{
  const u=new URL(url);calls.push({method:'fetch',host:u.host,path:u.pathname,tokenPresent:!!opts.headers?.Authorization,redirect:opts.redirect,accept:opts.headers?.Accept});
  if(u.hostname==='api.github.com'){
   assert.equal(opts.headers.Authorization,'Bearer '+token);assert.equal(opts.redirect,'manual');
   const isAsset=u.pathname.includes('/releases/assets/');assert.equal(opts.headers.Accept,isAsset?'application/octet-stream':'application/vnd.github+json');
   const id=Number(u.pathname.match(/\/(\d+)(?:\/zip)?$/)?.[1]);let data=isAsset?assetData.get(id):payloads.get(id);assert(data);
   if(opt.payloadHashWrong&&!isAsset)data={...data,sha:'0'.repeat(64)};
   if(opt.readbackBad&&isAsset&&(!opt.readbackName||assets.find(a=>a.id===id)?.name===opt.readbackName))data=data.virtual?{...data,sha:'0'.repeat(64)}:Buffer.from('corrupt');
   if(opt.apiError)throw new Error('SECRET_URL_'+token);
   if(opt.apiStatus)return {status:opt.apiStatus};
   if(opt.direct)return response(data);
   pending=data;return{status:302,headers:{get(){return opt.location||'https://mock.blob.core.windows.net/fixed?signature=MOCK_ONLY'}}};
  }
  assert(!opts.headers,'Signed redirect received headers/token');assert.equal(opts.redirect,'manual');
  if(opt.redirectError)throw new Error('SECRET_URL_'+token);
  if(opt.redirectChain)return{status:302,ok:false};
  return response(pending);
 };
 const repos={
  async getContent(args){record('getContent',args);assert.equal(args.ref,'83d75e30a90db65db743a4522288607cf45682b1');let d=args.path.endsWith('manifest.json')?manifest:sums;if(opt.badManifest&&args.path.endsWith('manifest.json'))d=Buffer.from('bad');if(opt.badSums&&args.path.endsWith('SHA256SUMS'))d=Buffer.from('bad');if(opt.manifestMutation&&args.path.endsWith('manifest.json'))d=Buffer.from(JSON.stringify({...JSON.parse(manifest),...opt.manifestMutation}));return{data:{type:opt.contentType||'file',encoding:'base64',content:d.toString('base64')}}},
  listReleases(){},listReleaseAssets(){},
  async createRelease(args){record('createRelease',args);assert(args.draft&&args.prerelease&&args.make_latest==='false'&&!args.generate_release_notes);assert.equal(args.target_commitish,'83d75e30a90db65db743a4522288607cf45682b1');assert.equal(args.tag_name,'v0.6.1');current={...baseRelease,body:args.body,...opt.createResponse};return{data:current}},
  async getRelease(args){record('getRelease',args);readCount++;let data={...current};if(opt.publishAtRead===readCount)data.draft=false;if(opt.responseAtRead?.read===readCount)Object.assign(data,opt.responseAtRead.fields);if(opt.tagAtFinal&&readCount===6)data.tag_name='v0.5.0';return{data}},
  async uploadReleaseAsset(args){record('uploadReleaseAsset',args);if(opt.uploadError)throw new Error(opt.errorWithToken?'Mock upload failed '+token:'Mock upload failed');assert.equal(args.headers['content-length'],args.data.length);const asset={id:++aid,name:opt.uploadNameWrong?'UNEXPECTED-'+args.name:args.name,size:args.data.length+(opt.uploadSizeWrong?1:0)};assetData.set(asset.id,args.data);assets.push(asset);return{data:asset}},
 };
 const github={rest:{repos,git:{async getRef(args){record('getRef',args);return{data:{object:{type:'tag',sha:opt.tagWrong?'0'.repeat(40):'cb1c3964d4865ae729807fcb3208b6d856bd25fc'}}}},async getTag(args){record('getTag',args);return{data:{object:{type:'commit',sha:opt.targetWrong?'0'.repeat(40):'83d75e30a90db65db743a4522288607cf45682b1'}}}}},actions:{async getWorkflowRun(args){record('getWorkflowRun',args);return{data:{...meta.run,...opt.run}}},async getArtifact(args){record('getArtifact',args);return{data:{...meta.artifacts.find(a=>a.id===args.artifact_id),...(!opt.artifactTarget||opt.artifactTarget===args.artifact_id?opt.artifact:{})}}}}},async paginate(method,args){record(method===repos.listReleases?'listReleases':'listReleaseAssets',args);if(method===repos.listReleases)return opt.duplicateRelease?[baseRelease,baseRelease]:current?[current]:[];if(opt.existingAssets){for(const n of [nativeName,evidenceName,'manifest.json','SHA256SUMS','preservation-coverage.json']){const d=files.get(n);const a={id:++aid,name:n,size:d.length};assets.push(a);assetData.set(a.id,d);}if(opt.duplicateAsset)assets.push(assets[0]);if(opt.existingSizeWrong)assets[0].size++;}return assets}};
 const context={repo:{owner:'evangjones99-gif',repo:'Roguelike-deckbuilder'},ref:'refs/heads/codex/lanternbound-production',eventName:'push',payload:{inputs:{}},...opt.context};
 const core={getInput(){return token},setFailed(m){failures.push(m)},notice(){}};
 const requireMock=n=>n==='node:fs'?fsMock:n==='node:crypto'?cryptoMock:n==='node:path'?path:n==='node:child_process'?{execFileSync(executable,args,options){assert.equal(executable,'python3');assert.equal(options.timeout,120000);assert.equal(args[3],path.resolve('preservation',nativeName));assert.equal(args[4],nativeName);assert.equal(args[5],'183597187');extractCount++;if(opt.extractFail)throw new Error('Mock extraction failure');fs.writeFileSync(path.join(dir,'extraction.py'),args[1]);files.set(nativeName,opt.nativeHashWrong?{...native,sha:'0'.repeat(64)}:native);}}:assert.fail('Unexpected require '+n);
 await vm.runInNewContext('(async()=>{'+source+'})()', {require:requireMock,core,github,context,Buffer:bufferMock,fetch:fetchMock,URL,AbortSignal});
 const report=JSON.parse(files.get('report.json'));assert(!JSON.stringify(report).includes(token));assert(!calls.some(c=>/delete|updateRelease|publish/i.test(c.method)));
 const expected=opt.expectFail?'failed':'passed-draft-partial-preservation';assert.equal(report.status,expected,`${name}: ${report.error}`);
 if(opt.expectFail){assert(failures.length===1);if(opt.noMutation)assert(!calls.some(c=>['createRelease','uploadReleaseAsset'].includes(c.method)));if(opt.errorIncludes)assert(report.error.includes(opt.errorIncludes),`${name}: ${report.error}`);}else{assert.equal(report.assets.length,5);assert.deepEqual(report.assets.map(a=>a.name),[nativeName,evidenceName,'manifest.json','SHA256SUMS','preservation-coverage.json']);assert.equal(calls.filter(c=>c.method==='uploadReleaseAsset').length,opt.existingAssets?0:5);assert.equal(calls.filter(c=>c.method==='createRelease').length,opt.existing?0:1);const cov=JSON.parse(files.get('preservation-coverage.json'));assert.equal(cov.preservedArchiveNames.length,2);assert.equal(cov.notUploadedArchiveNames.length,4);assert(cov.draft&&cov.developmentOnly&&!cov.steamPublished&&!cov.commercialQualityAccepted);}
 const result={name,passed:true,expected,report,calls,cancellations,extractCount,virtualLargePayloads:true,returnedAssets:assets};fs.writeFileSync(path.join(dir,'mock-results',name+'.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});return {name,passed:true,status:report.status,error:report.error,uploads:calls.filter(c=>c.method==='uploadReleaseAsset').length};
}
fs.mkdirSync(path.join(dir,'mock-results'),{recursive:true});await run('wrong-upload-name-accepted-witness',{uploadNameWrong:true});
