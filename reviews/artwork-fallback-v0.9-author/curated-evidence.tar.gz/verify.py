import json,hashlib,pathlib,urllib.request,sys
P=pathlib.Path('/workspace/scratch/artwork-fallback-author-v09-r1')
rows=[]
for label,stage,port in [('baseline','/tmp/hollowpact-final-kill-v09-root-r1',4610),('candidate','/tmp/hollowpact-artwork-fallback-v09-author-r1',4624)]:
 d=pathlib.Path(stage); prov=json.loads((d/'dist/build-provenance.json').read_text()); hashes={}
 for name,expected in prov['hashes'].items():
  f=d/name; actual=hashlib.sha256(f.read_bytes()).hexdigest(); assert actual==expected,(name,actual,expected);hashes[name]=actual
 digest=hashlib.sha256(json.dumps(hashes,separators=(',',':')).encode()).hexdigest();assert digest==prov['sourceDigest']
 outputs=[]
 for f in sorted((d/'dist').rglob('*')):
  if not f.is_file():continue
  name=str(f.relative_to(d/'dist')); raw=f.read_bytes();remote=urllib.request.urlopen(f'http://127.0.0.1:{port}/'+name).read(); assert raw==remote,name
  outputs.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 rows.append({'label':label,'stage':stage,'port':port,'version':prov['version'],'sourceDigest':digest,'inputs':hashes,'outputs':outputs})
assert rows[0]['sourceDigest']=='8a33f950ed57093a222baf9b7883a5c1ccf2deb2e8412429ef0fe05d370467cb'
changed=[k for k in rows[0]['inputs'] if rows[0]['inputs'][k]!=rows[1]['inputs'][k]];assert changed==['src/arena.ts','src/style.css'],changed
assert [len(r['inputs']) for r in rows]==[77,77]; assert [len(r['outputs'])for r in rows]==[55,55]
(P/sys.argv[1]).write_text(json.dumps({'changedInputs':changed,'rows':rows},indent=2)+'\n')
print('VERIFIED',rows[1]['sourceDigest'],changed)
