import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createGame,validateState,applyActionWithEvents} from '/dev/shm/hollowpact-shrine-thrall-v09-root-r1/src/engine.ts';
import {CARDS,ENEMIES} from '/dev/shm/hollowpact-shrine-thrall-v09-root-r1/src/content.ts';
const dir='/workspace/scratch/shrine-thrall-gameplay-independent-v09-r1';
function ally(id:string,i:number){const c:any=CARDS[id];return{uid:'a'+(10+i),cardId:id,name:c.name,species:c.species,hp:c.hp,maxHp:c.hp,attack:c.attack,block:0,acted:false,color:c.color,passive:c.passive};}
function foe(id:string,i:number,target='hunter'){const c:any=ENEMIES[id];return{uid:'e'+(30+i),cardId:id,...c,maxHp:c.hp,block:0,acted:false,intent:{target,damage:c.attack,label:id==='thrall'?'Claw weakest creature':'Grave curse'}};}
function battle(g:1|2,mode:string){const s:any=createGame(739201+g,0,{engineKind:g});Object.assign(s,{phase:'battle',floor:4,turn:1,route:['elite'],nextUid:100,energy:5,block:0});s.stats={cardsPlayed:0,damageDealt:0,turns:1,battles:1};
const ids=mode==='raised'?['cairnhound','gravehound','fenstalker','fenraker','briarcolossus','ossuarycolossus']:mode==='reduced'?[]:['gravehound'];
s.allies=ids.map(ally);s.deck=[...ids,'scour','ironward','sutures','scour+','edict','cairnhound'];s.hand=['scour','ironward','sutures'];s.draw=['scour+','edict','cairnhound'];s.discard=[];
s.enemies=[foe('thrall',0,s.allies[0]?.uid??'hunter')];
if(mode==='command')s.enemies[0].hp=s.enemies[0].maxHp=20;
if(mode==='kill')s.enemies[0].hp=2;
if(mode==='raised'){s.allies.forEach((u:any)=>{u.hp=u.maxHp=60;});s.enemies=[foe('acolyte',0),...Array.from({length:4},(_,i)=>foe('thrall',i+1,'a10'))];s.enemies[0].intent={target:'e30',damage:0,label:'Raise 1 Bone Thrall',summon:['thrall']};}
assert(validateState(s),mode);return s;}
function shrine(g:1|2){const s:any=createGame(740123,0,{engineKind:g});Object.assign(s,{phase:'event',floor:2,route:['event'],hp:9,gold:30,energy:0,nextUid:10});s.deck=['cairnhound','gravehound','fenraker','scour','ironward','sutures'];assert(validateState(s));return s;}
const profiles=[{id:'command-shrine',g:1,w:1280,mode:'command'},{id:'held-kill',g:2,w:1280,mode:'kill'},{id:'delayed-sixth',g:2,w:390,mode:'raised',delay:true},{id:'reduced-hunter',g:1,w:360,mode:'reduced',reduced:true},{id:'fault-recovery',g:2,w:1440,mode:'command',fault:true}].map((spec:any)=>({...spec,s:battle(spec.g,spec.mode),...(spec.id==='command-shrine'?{shrine:shrine(spec.g)}:{})}));
for(const p of profiles){const a:any=p.mode==='command'||p.mode==='kill'?{type:'attack',unit:p.s.allies[0].uid,target:p.s.enemies[0].uid}:{type:'endTurn'};assert(validateState(applyActionWithEvents(p.s,a).state));}
await fs.writeFile(dir+'/fixtures.json',JSON.stringify({profiles},null,2)+'\n',{flag:'wx'});console.log('Five fresh validator-valid fixtures, both schemas; no borrowed prior executions');
