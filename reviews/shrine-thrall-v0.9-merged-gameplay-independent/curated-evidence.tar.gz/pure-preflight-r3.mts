import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import * as baseline from '/tmp/hollowpact-event-availability-v09-root-r2/src/engine.ts';
import * as candidate from '/dev/shm/hollowpact-shrine-thrall-v09-root-r1/src/engine.ts';
const O='/workspace/scratch/shrine-thrall-gameplay-independent-v09-r1';
const profiles=JSON.parse(await fs.readFile(O+'/fixtures-r3.json','utf8')).profiles,rows=[];
for(const p of profiles){const first:any=p.mode==='command'||p.mode==='kill'?{type:'attack',unit:p.s.allies[0].uid,target:p.s.enemies[0].uid}:{type:'endTurn'};assert(baseline.validateState(p.s)&&candidate.validateState(p.s));const a=baseline.applyActionWithEvents(p.s,first),b=candidate.applyActionWithEvents(p.s,first);assert.deepEqual(a,b);assert(candidate.validateState(b.state));const row:any={profile:p.id,first,phase:b.state.phase,eventTypes:b.events.map(e=>e.type)};
if(p.mode==='kill')assert.equal(b.state.phase,'reward');
if(p.mode==='raised'){const summon:any=b.events.find(e=>e.type==='summon');assert(summon&&b.state.enemies.length===6&&!b.events.some((e:any)=>e.type==='hit'&&e.source===summon.target));const next=candidate.applyActionWithEvents(b.state,{type:'endTurn'});assert(candidate.validateState(next.state));assert(next.events.some((e:any)=>e.type==='hit'&&e.source===summon.target));row.raisedUid=summon.target;row.raisedNextTurnHits=next.events.filter((e:any)=>e.type==='hit'&&e.source===summon.target);}
if(p.reduced)assert(b.events.some((e:any)=>e.type==='hit'&&e.target==='hunter'));
if(p.hunter){const h=candidate.applyActionWithEvents(p.hunter,{type:'endTurn'});assert(candidate.validateState(h.state)&&h.events.some((e:any)=>e.type==='hit'&&e.target==='hunter'));}
if(p.shrine){const event=candidate.applyActionWithEvents(p.shrine,{type:'event',choice:'offering'});assert(candidate.validateState(event.state)&&event.state.hp===1&&event.state.relics.includes('moon-charm'));}
rows.push(row);}
await fs.writeFile(O+'/pure-preflight-r3.json',JSON.stringify({method:'pure diagnostic fixture preparation only; no browser gameplay acceptance',rows},null,2)+'\n',{flag:'wx'});console.log('Five static pure fixture checks pass; not playable proof');
