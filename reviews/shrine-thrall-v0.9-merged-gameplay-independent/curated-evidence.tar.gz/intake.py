import hashlib,json,pathlib,sys,urllib.request
out=pathlib.Path('/workspace/scratch/shrine-thrall-gameplay-independent-v09-r1')
configs=[('baseline',pathlib.Path('/tmp/hollowpact-event-availability-v09-root-r2'),4632,'801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029',78,56),('candidate',pathlib.Path('/dev/shm/hollowpact-shrine-thrall-v09-root-r1'),4670,'fe3f5604e93e8e4cc148b8ac13dcf5a94954d43b5a1a0308f7d972dd1bcd593d',79,57)]
rows=[]
for name,root,port,digest,ninputs,noutputs in configs:
    provenance=json.loads((root/'dist/build-provenance.json').read_bytes())
    assert provenance['sourceDigest']==digest
    inputs={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in provenance['hashes']}
    assert inputs==provenance['hashes'] and len(inputs)==ninputs
    assert hashlib.sha256(json.dumps(inputs,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==digest
    outputs=[]
    for file in sorted((root/'dist').rglob('*')):
        if not file.is_file():continue
        raw=file.read_bytes();rel=file.relative_to(root/'dist').as_posix()
        assert urllib.request.urlopen(f'http://127.0.0.1:{port}/{rel}',timeout=10).read()==raw
        outputs.append(dict(path=rel,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    assert len(outputs)==noutputs
    rows.append(dict(name=name,root=str(root),port=port,inputs=inputs,outputs=outputs,provenance=provenance))
changed=[f for f,h in rows[0]['inputs'].items() if rows[1]['inputs'].get(f)!=h]
added=list(set(rows[1]['inputs'])-set(rows[0]['inputs']))
assert changed==['THIRD-PARTY.md','public/art/PROVENANCE.json','src/art.ts']
assert added==['public/art/bone-thrall-poses-v09-r2.png']
assert rows[1]['inputs'][added[0]]=='440bdad1f593538aeb1a5e2a44e5f611bbd8339f36146b11a069a72c4c2f93b2'
result=dict(rows=rows,changed=changed,added=added)
target=out/(sys.argv[1]+'.json')
with target.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('157 exact source inputs /113 complete local and HTTP outputs; three changed inputs and one exact original added PNG')
