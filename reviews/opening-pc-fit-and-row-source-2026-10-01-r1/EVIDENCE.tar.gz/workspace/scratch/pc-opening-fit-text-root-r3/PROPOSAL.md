# PC card text — source only

Actual PCfitR2 passed physical containment, names/caps and held ghost parity, but failed the retained >=12px cardstats readability metric: stats were still10px. This candidate makes source-hand AND drag-copy stats12px; binding/tool kind labels also grow8→10px to improve early type recognition. Rules12px, cost16px, actor size, card widths/art/geometry, natural height, input and saves are unchanged. Naturally sized cards may grow; real1440×900 fit must be rechecked. No old result is waived or rewritten.

Exact baseline: source894648d55151d112ca2bfed55eccfae65a84a9833410d2f480bb16ce56304647/outputsbacd5924ad0cd639391f7f3124004ec3c123108ae0b83a5709421334f24965af. One new CSS body, unbuilt/unpromoted, independent review pending.
