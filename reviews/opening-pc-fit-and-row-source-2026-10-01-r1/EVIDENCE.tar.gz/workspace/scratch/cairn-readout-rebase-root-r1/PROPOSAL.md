# Cairn overlay rebased onto named readouts — source only

The independently reviewed original Cairn opt-in patch was applied to the current PCfitR2 Arena, preserving its named readout allocation. New module/art bytes stay exact. This is a new three-body partial source overlay; no shared stage/public alias, build, runtime or source promotion. R4 art remains withheld; actual binding/command comparison is next after independent composite source review and strict build.

Baseline Arena77bbca50… comes from strict stage894648…/bacd592…. The upcoming card ghost/text patch changes only CSS, so Arena bytes remain this same base. QuerypixelCairn=1 trial only; default remains old art. Original terminal-cue56834 source/overlay and all assets remain retained.
