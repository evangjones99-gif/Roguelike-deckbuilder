import os,json,hashlib,subprocess,time
from pathlib import Path
stage=Path('/workspace/scratch/first-five-opening-cairn-pixel-stage-r1');record=json.loads(Path('/workspace/scratch/first-five-opening-cairn-pixel-assembly-root-r1.json').read_text())
assert not (stage/'dist').exists()
def sha(p):
    h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        st=os.fstat(fd)
        while b:=os.read(fd,65536):h.update(b)
        assert os.fstat(fd)==st
    finally:os.close(fd)
    return h.hexdigest()
def sourcecheck():
    for rel,h in record['inputs'].items():assert sha(stage/rel)==h,rel
sourcecheck();start=time.monotonic()
cmd=['python3','-I','/workspace/scratch/guard-node-phase-r1.py',str(stage),'/workspace/scratch/first-five-opening-cairn-pixel-strict-build-guard-r1','384','node','scripts/build.mjs']
p=subprocess.Popen(cmd,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
owned={}
while True:
    children=Path(f'/proc/{p.pid}/task/{p.pid}/children')
    if children.exists():
        for child in children.read_text().split():
            try:
                b=Path(f'/proc/{child}/stat').read_text();a=b[b.rfind(')')+2:].split();owned[int(child)]=(int(a[19]),int(a[2]))
            except FileNotFoundError:pass
    try:
        out,err=p.communicate(timeout=.25);break
    except subprocess.TimeoutExpired:
        if time.monotonic()-start<60:continue
        import signal
        for child,(ticks,group) in owned.items():
            try:
                b=Path(f'/proc/{child}/stat').read_text();a=b[b.rfind(')')+2:].split()
                if int(a[19])==ticks and int(a[2])==group:os.killpg(group,signal.SIGTERM)
            except ProcessLookupError:pass
            except FileNotFoundError:pass
        try:os.killpg(p.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
        raise TimeoutError('strict build whole60s stopped; preserve partial logs, no retry')
assert p.returncode==0,(out,err)
r=json.loads(Path('/workspace/scratch/first-five-opening-cairn-pixel-strict-build-guard-r1/RESULT.json').read_text())
assert r['exit_code']==0 and r['failure'] is None and r['memory_events_before']==r['memory_events_after']
for row in r['samples']+[r['final']]:assert row['headroom']>=512*1048576 and row['current']-r['initial']['current']<=384*1048576 and row['maximum']==r['initial']['maximum'] and row['free']>=1048576
sourcecheck();outputs={f.relative_to(stage/'dist').as_posix():sha(f) for f in sorted((stage/'dist').rglob('*')) if f.is_file()}
provenance=json.loads((stage/'dist/build-provenance.json').read_text());assert provenance['hashes']==record['inputs'] and provenance['sourceDigest']==record['sourceDigest']
freeze={'stage':str(stage),'status':'STRICT-BUILT OPT-IN CAIRN PIXEL ARENA CANDIDATE; UNPROMOTED','version':provenance['version'],'sourceDigest':record['sourceDigest'],'inputCount':len(record['inputs']),'inputs':record['inputs'],'outputCount':len(outputs),'outputs':outputs,'outputsDigest':hashlib.sha256(json.dumps(outputs,separators=(',',':'),sort_keys=True).encode()).hexdigest(),'strictBuildExit':0,'samples':len(r['samples']),'wholeSeconds':time.monotonic()-start,'ownedWrapperNormalWait':True,'ownedCommandIdentities':owned,'ownedCommandPostWait':{str(pid):not Path(f'/proc/{pid}').exists() for pid in owned},'limitations':'No actual browser/play/visual acceptance, human enjoyment or release claim.'}
path=Path('/workspace/scratch/first-five-opening-cairn-pixel-runtime-freeze-root-r1.json')
with path.open('x') as f:json.dump(freeze,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
assert freeze['wholeSeconds']<60
print(json.dumps({k:v for k,v in freeze.items() if k not in ['inputs','outputs']}))
