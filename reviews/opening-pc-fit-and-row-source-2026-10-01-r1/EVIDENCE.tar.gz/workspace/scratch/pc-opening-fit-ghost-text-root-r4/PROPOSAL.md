# PC card drag and text — source only

Actual R2 viewport fits, but10px stats fail readability. Independent capture review additionally measured a170×201 source card versus150×230 drag clone. Existing four-class fixed hand dimensions outrank tactile ghost three-class100% declarations. The new exact ghost selector keeps the clone within its existing measured press wrapper (width/height100%, no minimum/flex growth), without pointer/state/rule changes. Source-hand and ghost stats grow to12px; card kind labels8→10px. All font, outer and viewport results require matching actual comparison. No old failure/negative is waived.

This immutable R4 proposal supersedes an unbuilt, retained text-only R3 scratch proposal; it is not a game version. Only compact-readout.css changes against strictbuilt source894648…/bacd592… stage. Actor size, engine, local saves, card width/art, live hand natural content and input logic remain unchanged. Unbuilt/unpromoted, independent review pending.
