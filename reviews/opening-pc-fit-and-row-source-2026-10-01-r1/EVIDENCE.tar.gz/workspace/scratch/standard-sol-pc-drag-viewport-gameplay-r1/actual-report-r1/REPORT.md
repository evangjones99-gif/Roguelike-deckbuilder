# R5 actual first 300 seconds — independent gameplay observations

The exact R5 session completed its scheduled 300-second title clock with normal browser/server closure and all seven supervisor checks passing. It established two bindings, used both free commands, cancelled a pending command safely, consulted optional Help, made a real draw-versus-damage choice, and observed the enemy response. The encounter remained unfinished at turn2. No reward, terminal survivor/death case, drag, save/Continue or next encounter was exercised.

**Accept the tested binding/command/preview/cancel/Help/enemy-response behavior and the captured attached-name readability. Withhold a claim that the opening has earned the owner's five-minute fun target or a general gameplay promotion.** This was source-aware agent tool play, not a novice/human playtest. The elapsed outcome cannot isolate pacing effects from my deliberation, tool exchange costs, different seed/order or navigation inspection.

## Exact session and closure

Source `3e4e518b9e46717c4be830448e9dbbe860f1fefca88fd3589bf918df22a95bd7`, output ledger `f56c608267547c968dfe2b298e61384d2be23e4c717f812bafb476f0a7cdee6c`. The admitted caller audited all87 source inputs,56 built outputs and56 served bodies. Fresh1440×900 context, default Initiate, UI-created seed **9845209**; no seed edit/reroll, state/save fixture, engine import, forced click or outcome. No Cairn pixel query was used.

Title interactive **2026-10-01 16:26:28.626 UTC**; cancellation **16:31:28.626 UTC**, exactly300.000 seconds before which all actions occurred. Normal browser/server closure at300.155 seconds; whole supervisor301.977 seconds.26 UI operations,7 JPEGs, zero caught tool-operation errors. The896 MiB total cgroup-delta phase/512 MiB reserve/heap256 limits stayed unchanged.1620 sample rows plus final pass; sampled peak delta653,565,952 bytes, minimum headroom1,368,915,968 bytes, unchanged memory.events and maximum. These are sampled limits, not continuous peak/performance evidence.

Eleven owned identities were observed across process groups; no observed tracked live descendants remained. Two same-recorded-identity descendants remained nonlive Z/unreaped, and are qualified in RESULT rather than called removed. No global cleanup or universal escaped-descendant proof. All18 actual artifacts were closed before independent size/hash pinning; EVIDENCE-PINS.json identifies1,970,928 bytes. The source packet and earlier failures remain untouched.

## Chronology and choices

Times below are actual response-observation times from title; ACTUAL-SUMMARY also retains the slightly earlier input times, exact intent/alternative strings and actual focus.

| Seconds | Observed event |
| --- | --- |
| 25.980 | Default contract entered. Hand: Cairn, Fen, Sundering Hex, Blood Sutures, Survey. Reaver showed Guard4; Revenant showed Rend5, hunter target, ignores block. |
| 44.132 | Cairn bound for1 energy: energy5→4, hunter block2, Binding1/7HP/Ready. I chose its guaranteed free command against the urgent block-ignoring hostile over a costlier Fen or unknown draw. |
| 55.354–88.552 | B reached Cairn. Enter opened its command; default target was Reaver. Esc at88.250 restored Cairn focus and preserved65HP,4energy, the hand and Ready status. Reselect and target-only Right reached Revenant with a5-damage preview. |
| 100.523 | First free command matched preview: Revenant15→10HP; energy remained4; Cairn became Command spent. |
| 117.987 | Fen bound for2 energy: energy4→2, Binding2/10HP/Ready. Its guaranteed4 damage was preferable to seeking unknown cards at that point. |
| 134.177 | From B-focused Cairn, Right moved to Hostile1, rather than the other binding. I stopped before committing. |
| 156.181–179.657 | B→Tab→Tab reached ready Fen through Cairn's Inspect control. Enter then target-only Right reached Revenant and displayed4 health damage. |
| 195.650 | Fen's command matched preview: Revenant10→6HP, energy stayed2, both commands spent. |
| 222.327–222.441 | Optional Help opened and Esc returned to the unchanged fight. Help described Tab navigation and explicit creature→enemy commands. |
| 222.622 | Survey spent1 energy and actually drew two Iron Wards. No reroll: these did not answer the current block-ignoring Rend. |
| 252.661 | T focused Revenant for Sundering Hex. The target-specific preview showed **1 health damage**, while its card printed3. |
| 278.707 | I accepted that displayed result: Revenant6→5HP, energy1→0. This sets up a later free Cairn command; no removal was forced before cutoff. |
| 294.509 | End turn resolved: hunter65→60, Reaver gained4 block, both bindings returned Ready, turn2 began with5 energy and a new hand including Ash Widow, Briar, Cairn and two Scours. |
| 300.000 | Scheduled cancellation; no further action. Reaver16HP/4block and Revenant5HP remained; both allied bindings had full health. |

## Findings

The separate hand cue survived the automatically focused card's consequence preview. I personally inspected the retained R5 first-fight and enemy-response images after closure: the cue, attached full creature names/ordinals, complete intents and the hand are visible. Names distinguish Cairn from Fen and Reaver from Revenant without opening Inspect, while the former56834 first-fight image showed wide ordinal-only readouts. This is a useful observed readability improvement in these captured states; it does not certify dense/terminal/drag or all font/viewport conditions.

The reusable-binding payoff is concrete: one paid card became a7-health Cairn with a free5-damage command and returned Ready next turn; Fen added a second free command. The target preview, actual damage, energy and spent/ready labels agreed. Cancellation restored the correct actor and left resources unchanged. Optional Help remained accessible. Survey exposed an actual strategic risk by drawing two defenses that did not counter the current threat.

The actionable confusion is **directional navigation versus the rendered formation**. Right from the near-row Cairn crossed to the far-row Reaver; it did not move to the right-hand Fen. B→Tab→Tab worked and was confirmed before any command. Inside a pending target selection, Right did move between hostile targets as expected. The visible hint said “Arrows Move” and Help mentioned Tab, without explaining this change of roster. ROOT separately traced legacy Right-to-hostile behavior; that is an implementation explanation, not evidence captured in this run. A focused next hypothesis is to align direct-field directional movement with its near/far rows while preserving the old fallback contract, or clearly describe the existing direction rule. No current frozen source was changed.

**Printed3 versus preview1** was a second decision friction. The preview correctly predicted the actual6→5 health result. My logged “heavy resistance” interpretation used prior source/rules knowledge. I did not open the Revenant trait Inspect, and the visible consequence did not state the cause; this run therefore does not establish a visible resistance explanation. A player can trust the exact preview, but the reason for the reduction still requires investigation. Do not rewrite the logged source-informed inference as a newly observed trait.

I would continue another turn to test the visible free-Cairn removal opportunity and the new Ash Widow/Scour combination. That is a grounded analyst continuation rationale from the actual hand and enemy state, not human replay intent or a verified next encounter. No encounter clear was reached, so this sample gives no earned reward/terminal-label acceptance. The first300 goal has a partial action/response payoff, with the navigation mismatch a concrete next repair; no tool-operated elapsed result proves enjoyment or losing track of time.

## Retained comparisons and limits

| UI-earned session | First fight | First binding | First command | First observed turn2 | Reward screen observed |
| --- | --- | --- | --- | --- | --- |
| Original retained baseline, source27239b7e…, seed3105108 | 27.756s | 36.661s | 52.283s | 138.411s | 260.378s |
| Terminal-cue source56834…, different random hand/seed | 15.153s | 36.686s | 76.706s | 90.179s | 188.961s |
| Current R5, seed9845209 | 25.980s | 44.132s | 100.523s | 294.509s | Not reached |

These response observations were independently extracted from the retained raw UI records. Reward-screen observation can occur after the actual lethal action/animation and is not the lethal-action timestamp. Original baseline had a selector error and the false survivor-loss finding; earlier candidate entry-evidence clock skew remains historical. The prepared R4 gameplay packet was never executed and has no first300 result. R4's short PC-fit/ghost/stability findings stay separate from the older five-minute baselines and this primary sample.

Different seeds, hands, enemies/order, learned source, reviewer actions, optional Help/cancel and tool deliberation prevent causal speed or difficulty conclusions. Current R5 took longer to respond than the two retained observations; that fact does not establish that its presentation slowed human play. No hardware controller, listening, native launch, drag, reload/Continue, art selection, human fun or whole-game release claim is made. Independent visual judgment may reject these captures separately.
