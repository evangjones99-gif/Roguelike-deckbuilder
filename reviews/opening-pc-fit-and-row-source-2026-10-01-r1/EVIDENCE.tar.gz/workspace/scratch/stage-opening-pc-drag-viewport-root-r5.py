import os,json,hashlib,shutil,time
from pathlib import Path
base=Path('/workspace/scratch/first-five-opening-pc-ghost-text-stage-r4');stage=Path('/workspace/scratch/first-five-opening-pc-drag-viewport-stage-r5');author=Path('/workspace/scratch/pc-drag-viewport-root-r5/candidate')
freeze=json.loads(Path('/workspace/scratch/first-five-opening-pc-ghost-text-runtime-freeze-root-r4.json').read_text())
def digest(p):
    h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
    try:
        s=os.fstat(fd)
        while b:=os.read(fd,65536):h.update(b)
        assert os.fstat(fd)==s
    finally:os.close(fd)
    return h.hexdigest()
assert freeze['sourceDigest']=='f73b2ef46dd2eaba984922c76de372112341d7ad9cd530df3544c2d7304e9804'
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h,rel
replacements={'src/tactile-hand.ts':'8335b61df0ddec91b413bcf5c109b7741e589bdc8ab63a7346602654851a7bb5'}
for rel,h in replacements.items():assert digest(author/rel)==h
stage.mkdir(mode=0o700)
for current,names,files in os.walk(base,followlinks=False):
    names[:]=[n for n in names if n not in ['dist','node_modules','public']]
    for name in names:assert not (Path(current)/name).is_symlink()
    for name in files:
        source=Path(current)/name;assert not source.is_symlink()
        rel=source.relative_to(base).as_posix();target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
        source=author/rel if rel in replacements else source
        fd=os.open(source,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
        try:
            with target.open('xb') as f:
                while b:=os.read(fd,65536):f.write(b)
                f.flush();os.fsync(f.fileno())
        finally:os.close(fd)
(stage/'public').symlink_to(base.joinpath('public').resolve(),target_is_directory=True)
(stage/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules',target_is_directory=True)
inputs={**freeze['inputs'],**replacements}
for rel,h in inputs.items():assert digest(stage/rel)==h
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h
record={'stage':str(stage),'status':'PC DRAG VIEWPORT R5 STAGED; UNBUILT; UNPROMOTED','baselineStage':str(base),'baselineSourceDigest':freeze['sourceDigest'],'inputs':dict(sorted(inputs.items())),'inputCount':len(inputs),'sourceDigest':hashlib.sha256(json.dumps(dict(sorted(inputs.items())),separators=(',',':')).encode()).hexdigest(),'onlyChangedInputs':list(replacements),'sharedPublicRoot':str(base.joinpath('public').resolve()),'baselineUnchanged':True,'limitations':'No new playable/brower/human-fun/art/release acceptance.'}
p=Path('/workspace/scratch/first-five-opening-pc-drag-viewport-assembly-root-r5.json')
with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
for folder in [stage,stage.parent]:fd=os.open(folder,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({k:v for k,v in record.items() if k!='inputs'}))
