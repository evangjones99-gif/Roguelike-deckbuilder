import { chromium } from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createGame, applyAction, validateState} from '/tmp/hollowpact-scene-jaw-v09-root-r1/src/engine.ts';
import {RELICS} from '/tmp/hollowpact-scene-jaw-v09-root-r1/src/content.ts';
const output='/workspace/scratch/relic-discovery-author-v09-r1';
const fixture=JSON.parse(fs.readFileSync('/workspace/Roguelike-deckbuilder/reviews/screenshots-v0.2/full-fixture.json','utf8'));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const rows:any[]=[];
try {
 for(const generation of [1,2] as const) for(const width of [1440,390]) for(const phase of ['map','reward','victory']) {
  const map=createGame(44,1,{engineKind:generation}); map.relics=['moon-charm','war-brand','ember-seed'];
  const battle=structuredClone(fixture); battle.relics=map.relics.slice(); battle.enemies=[battle.enemies.find((u:any)=>u.cardId==='thrall')]; battle.enemies[0].hp=1;
  if(generation===2){battle.schema=3;battle.engineKind=2;}else{battle.schema=2;delete battle.engineKind;}
  battle.floor=phase==='victory'?10:1; if(phase==='victory')battle.route=['boss'];
  const action={type:'attack' as const,unit:battle.allies[0].uid,target:battle.enemies[0].uid};
  assert(validateState(battle));const resolved=applyAction(battle,action);assert.equal(resolved.phase,phase==='victory'?'victory':'reward');assert(validateState(resolved));
  const initial=phase==='map'?map:phase==='reward'?resolved:battle;
  const ctx=await browser.newContext({viewport:{width,height:900},reducedMotion:'reduce'});
  const page=await ctx.newPage();const errors:string[]=[];page.on('pageerror',(e:any)=>errors.push(e.message));
  await page.addInitScript(({save}:any)=>{localStorage.setItem('hollowpact.run.v2',save);localStorage.setItem('hollowpact.settings.v2',JSON.stringify({mute:true,motion:false,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');},{save:JSON.stringify(initial)});
  await page.goto('http://127.0.0.1:4597/');await page.locator('[data-ui="resume"]').click();
  if(phase==='victory'){await page.locator(`[data-unit="${action.unit}"]`).click();await page.locator(`[data-unit="${action.target}"]`).click();await page.locator('.outcome-panel').waitFor();}
  if(await page.locator('dialog[open]').count()) await page.locator('[data-ui="close"]').click();
  const before=await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2'));
  const expected=phase==='map'?initial:resolved;assert.deepEqual(JSON.parse(before!),expected);
  const buttons=page.locator('.relic-strip [data-ui="relic"]');assert.equal(await buttons.count(),3);
  for(const id of initial.relics){
   const button=page.locator(`[data-ui="relic"][data-relic="${id}"]`);await button.focus();await page.keyboard.press('Enter');
   await page.locator('dialog[open]').waitFor();assert.equal(await page.locator('#dialog-title').textContent(),RELICS[id].name);
   assert((await page.locator('dialog[open]').innerText()).includes(RELICS[id].text));await page.keyboard.press('Escape');
   assert.equal(await button.evaluate((node:any)=>document.activeElement===node),true);
   assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),before);
  }
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth);assert.equal(overflow,false);
  const control=page.locator(phase==='reward'?'[data-action="reward"][data-card=""]':phase==='map'?'.route-card':'.outcome-actions button').first();await control.scrollIntoViewIfNeeded();assert(await control.isEnabled());
  if(generation===2&&width===390)await page.screenshot({path:`${output}/mobile-${phase}.png`});
  assert.deepEqual(errors,[]);rows.push({generation,width,phase,inspections:3,saveExactAndUnchanged:true,focusRestored:true,noHorizontalOverflow:true,pageErrors:errors});
  await ctx.close();
 }
 fs.writeFileSync(`${output}/RESULTS-r3.json`,JSON.stringify({scope:'Author diagnostic UI and focus checks; unearned valid fixtures, not a human campaign or independent review.',contexts:rows.length,rows},null,2)+'\n');
}catch(error){fs.writeFileSync(`${output}/FAILURE-r3.json`,JSON.stringify({message:String(error),completed:rows},null,2)+'\n');throw error;}
finally{await browser.close();}
