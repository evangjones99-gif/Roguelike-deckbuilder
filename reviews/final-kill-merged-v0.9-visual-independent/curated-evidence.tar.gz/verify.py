from pathlib import Path
import hashlib,json,urllib.request,sys
out=Path('/workspace/scratch/final-kill-merged-visual-independent-v09-r1'); roots={'baseline':Path('/tmp/hollowpact-scene-jaw-v09-root-r1'),'candidate':Path('/tmp/hollowpact-final-kill-v09-root-r1')};expected={'baseline':'efef7131d1c0cbb5cc0420c70e3d2afd9c9dfaf3013dfb8761e6bb8b00d3b525','candidate':'8a33f950ed57093a222baf9b7883a5c1ccf2deb2e8412429ef0fe05d370467cb'};result={}
for v,root in roots.items():
 port=4173 if v=='baseline' else 4610;p=json.loads(urllib.request.urlopen(f'http://127.0.0.1:{port}/build-provenance.json').read());assert p['sourceDigest']==expected[v]
 sources={}
 for n,h in p['hashes'].items():
  b=(root/n).read_bytes();assert hashlib.sha256(b).hexdigest()==h,(v,n);sources[n]={'bytes':len(b),'sha256':h,'input':str(root/n)}
 assert len(sources)==77;assert hashlib.sha256(json.dumps(p['hashes'],separators=(',',':')).encode()).hexdigest()==expected[v]
 paths=[]
 for folder in ['src','desktop','public']:
  paths.extend(str(x.relative_to(root))for x in (root/folder).rglob('*')if x.is_file())
 paths+=['index.html','THIRD-PARTY.md','package.json','package-lock.json','tsconfig.json','vite.config.ts','scripts/build.mjs'];assert sorted(paths)==list(p['hashes'])
 builds={}
 for f in sorted((root/'dist').rglob('*')):
  if not f.is_file():continue
  n=str(f.relative_to(root/'dist'));b=f.read_bytes();http=urllib.request.urlopen(f'http://127.0.0.1:{port}/{n}').read();assert http==b,(v,n);builds[n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 assert len(builds)==55;result[v]={'runtimeDigest':expected[v],'sourceInputs':sources,'outputs':builds,'httpPort':port}
changed=[n for n,x in result['baseline']['sourceInputs'].items()if x['sha256']!=result['candidate']['sourceInputs'][n]['sha256']];assert changed==['src/main.ts'];assert result['candidate']['sourceInputs']['src/main.ts']['sha256']=='be5c677784b73eb757fb3541a363933604706ae2f7a5538b694d33df340509c9'
with (out/sys.argv[1]).open('x')as f:json.dump({'scope':'Fresh closed source enumeration, recipe recomputation, complete local and HTTP outputs. Aliased media are explicit retained prerequisites, not backups.','onlyChangedInput':changed,'variants':result},f,indent=2)
print('Verified77+77 source,55+55 local/HTTP,main-onlydelta')
