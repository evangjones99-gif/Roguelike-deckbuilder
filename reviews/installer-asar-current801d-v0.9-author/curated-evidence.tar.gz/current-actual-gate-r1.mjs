import assert from'node:assert/strict';import fs from'node:fs';import{assertPackagedAsar}from'./proposed/scripts/windows-installer-asar-validation.mjs';
const out='/workspace/scratch/installer-asar-current801d-author-v09-r1',source='/tmp/hollowpact-event-availability-v09-root-r2',asar='/tmp/hollowpact-installer-asar-current801d-producer-author-v09-r1/app.asar';
const admitted=await assertPackagedAsar(asar,source);assert.equal(admitted.sourceDigest,'801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029');assert.equal(admitted.leafCount,60);assert.equal(admitted.sourceInputs,78);assert.equal(admitted.distOutputs,56);
const refusals=[];for(const [name,file,root,pattern]of[
 ['manualcurrente8fd','/tmp/hollowpact-event-availability-native-v09-r1/linux-unpacked/resources/app.asar',source,/Exact builder ASAR bytes differ/],
 ['old8abuilder905','/tmp/hollowpact-installer-asar-producer-author-v09-r1/app.asar',source,/Exact builder ASAR bytes differ/],
 ['currentASARwithold201dlocalsource',asar,'/tmp/hollowpact-fallback-cards-v09-root-r1',/Packaged\/local full build metadata differs/],
 ['currentASARwithold8alocal77source',asar,'/tmp/hollowpact-final-kill-v09-root-r1',/Closed local runtime source set differs/]
]){let failure;try{await assertPackagedAsar(file,root)}catch(e){failure=e.message}assert.match(failure??'',pattern);refusals.push({name,path:file,sourceRoot:root,refused:true,failure});}
fs.writeFileSync(out+'/CURRENT-ACTUAL-GATE-r1.json',JSON.stringify({scope:'Fresh actualnestedproducer/current60closedleaf+78source56output audit plus4actualstale/manual/sourceinventory refusals. NoWindows/nativeinstall/QAactivation claim.',admitted,refusals},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({digest:admitted.sourceDigest,asar:admitted.asarSHA256,leaves:admitted.leafCount,source:admitted.sourceInputs,dist:admitted.distOutputs,refusals:refusals.map(r=>r.name)}));
