import pathlib,hashlib,subprocess,json,zipfile,time
repo=pathlib.Path('/workspace/Roguelike-deckbuilder');out=pathlib.Path('/workspace/scratch/preservation-v07-independent');start=time.monotonic()
manifest=json.loads((repo/'releases/0.6.1/manifest.json').read_text());commit=manifest['sourceCommit'];zipname='hollowpact-0.6.1-source.zip';archive=repo/'releases/0.6.1'/zipname
sha=hashlib.sha256()
with archive.open('rb')as f:
 while b:=f.read(1024*1024):sha.update(b)
zipsha=sha.hexdigest();assert zipsha==manifest['artifacts'][zipname]
def tree(commit):
 data=subprocess.check_output(['git','ls-tree','-r','-z',commit,'--','reviews/'],cwd=repo);entries=[]
 for row in data.split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);mode,kind,oid=meta.split(b' ');entries.append({'path':name.decode('utf-8'),'mode':mode.decode(),'kind':kind.decode(),'gitBlob':oid.decode()})
 return entries
actual=[];missing=[];zipMismatch=[]
with zipfile.ZipFile(archive)as z:
 members={i.filename:i for i in z.infolist()}
 for row in tree(commit):
  if row['path']not in members:missing.append(row);continue
  info=members[row['path']];blob=hashlib.sha1(('blob '+str(info.file_size)+'\0').encode());digest=hashlib.sha256()
  with z.open(info)as f:
   while b:=f.read(1024*1024):blob.update(b);digest.update(b)
  same=blob.hexdigest()==row['gitBlob'];r={**row,'bytes':info.file_size,'archiveSHA256':digest.hexdigest(),'archiveGitBlobMatches':same};actual.append(r)
  if not same:zipMismatch.append(r)
metadata=subprocess.check_output(['git','rev-parse','v0.6.1^{commit}'],cwd=repo,text=True).strip();working=[]
for row in tree(metadata):
 p=repo/row['path'];size=p.stat().st_size;blob=hashlib.sha1(('blob '+str(size)+'\0').encode());sha=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1024*1024):blob.update(b);sha.update(b)
 if blob.hexdigest()!=row['gitBlob']:
  raw=p.read_bytes() if size<2000000 else None
  committed=subprocess.check_output(['git','cat-file','blob',row['gitBlob']],cwd=repo)if size<2000000 else None
  working.append({**row,'workingBytes':size,'workingSHA256':sha.hexdigest(),'workingGitBlob':blob.hexdigest(),'onlyCRLFNormalization':raw.replace(b'\r\n',b'\n')==committed if raw is not None else None})
report={'scope':'Independentstreamedactualexistingv0.6.1sourceZIP against exactmanifestsourcecommit, notmetadata-tagcurrentindex ornewrelease. Readonlyallsource/outputbytes.','sourceCommit':commit,'sourceZIP':str(archive),'sourceZIPBytes':archive.stat().st_size,'sourceZIPSHA256':zipsha,'actualCanonicalCount':len(actual),'actualCanonicalBytes':sum(x['bytes']for x in actual),'missingCanonical':missing,'archiveGitBlobMismatches':zipMismatch,'canonicalEntries':actual,'metadataCommit':metadata,'metadataCanonicalCount':len(tree(metadata)),'workingVsMetadataBlobMismatches':working,'elapsedSec':time.monotonic()-start}
(out/'actual-source-archive-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='canonicalEntries'},indent=2))
