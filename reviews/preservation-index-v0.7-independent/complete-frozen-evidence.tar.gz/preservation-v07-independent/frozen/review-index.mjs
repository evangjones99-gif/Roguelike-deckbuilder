import fs from 'node:fs';
import path from 'node:path';
import {execFileSync}from'node:child_process';
import {createReadStream}from'node:fs';
import{createHash}from'node:crypto';
import{Writable}from'node:stream';
import{pipeline}from'node:stream/promises';
import{createGunzip}from'node:zlib';
import{sha256File}from'./sha256-file.mjs';
/** New milestones index canonical evidence already preserved in their source ZIP.
 * Existing milestone copies are never changed. Every raw/gzip pair is verified. */
export async function reviewIndex(root,sourceCommit,sourceArchive){
 const entries=execFileSync('git',['ls-tree','-r','-z',sourceCommit,'--','reviews/'],{cwd:root,encoding:'utf8'}).split('\0').filter(Boolean);
 const paths=entries.map(entry=>{const split=entry.indexOf('\t'),[mode,kind,oid]=entry.slice(0,split).split(' ');if(split<0||kind!=='blob'||!['100644','100755'].includes(mode))throw Error('Unsupported canonical review entry');return {relative:entry.slice(split+1),oid};});
 if(!paths.length)throw Error('No committed canonical reviews to index');
 const files=[];const rawGzipPairs=[];
 for(const {relative,oid} of paths){
  const absolute=path.join(root,relative);const stat=fs.lstatSync(absolute);if(!stat.isFile())throw Error('Review index requires ordinary committed files: '+relative);
  const sha=createHash('sha256'),blob=createHash('sha1').update('blob '+stat.size+'\0');let readBytes=0;
  for await(const chunk of createReadStream(absolute)){readBytes+=chunk.length;sha.update(chunk);blob.update(chunk);}
  if(readBytes!==stat.size||blob.digest('hex')!==oid)throw Error('Canonical review bytes differ from committed source: '+relative);
  files.push({path:relative,bytes:stat.size,sha256:sha.digest('hex'),gitBlob:oid});
  if(relative.endsWith('.json.gz')){
   const raw=absolute.slice(0,-3);if(!fs.existsSync(raw))continue;
   const size=fs.statSync(raw).size;const hash=createHash('sha256');let bytes=0;
   await pipeline(createReadStream(absolute),createGunzip(),new Writable({write(chunk,_encoding,callback){bytes+=chunk.length;if(bytes>size){callback(Error('Compressed review exceeds original size: '+relative));return;}hash.update(chunk);callback();}}));
   const digest=hash.digest('hex');if(bytes!==size||digest!==await sha256File(raw))throw Error('Compressed review differs from retained raw bytes: '+relative);
   rawGzipPairs.push({rawPath:relative.slice(0,-3),compressedPath:relative,rawBytes:size,rawSHA256:digest});
  }
 }
 return {schema:1,sourceCommit,sourceArchive,canonicalDirectory:'reviews/',scope:'Committed canonical files are included exactly in the source archive. No repeated full local review tree is made for this new milestone; previous release copies remain unchanged.',files,rawGzipPairs};
}
