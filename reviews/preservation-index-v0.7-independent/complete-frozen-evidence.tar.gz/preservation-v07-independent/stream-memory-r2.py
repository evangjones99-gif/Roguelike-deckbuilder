import subprocess,pathlib,json,resource,time,shutil
root=pathlib.Path('/workspace/scratch/preservation-v07-independent');r=root/'stream-fixture';start=time.monotonic();node=shutil.which('node')
p=subprocess.run([node,'--max-old-space-size=64',str(r/'child.mjs')],capture_output=True,text=True,timeout=30)
out={'method':'Actual64MiB+257raw streamed comparison with Node64MiBheap; Pythonresource.RUSAGE_CHILDREN peakRSS reflects max child accounting, not simultaneous summedprocessRSS/targethardwarebudget. First retained launcher usedmissing /usr/bin/time and startedno utility, recordedstatusnull.','node':node,'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'childPeakRSSKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'elapsedSec':time.monotonic()-start,'priorFailure':'r3-stream-memory.json: missingtime launcher, not completedmeasurement'}
if p.returncode==0:
 x=json.loads(p.stdout);rawhash=subprocess.check_output(['sha256sum',str(r/'reviews/raw.json')],text=True).split()[0];out['pass']=len(x['pairs'])==1 and x['pairs'][0]['rawBytes']==67109121 and x['pairs'][0]['rawSHA256']==rawhash;out['gnuRawSHA256']=rawhash
(root/'r3-stream-memory-r2.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
