import { chromium } from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import fs from 'node:fs/promises';
const OUT='/workspace/scratch/hunter-independent-visual-v07-r4';
const full=JSON.parse(await fs.readFile('/workspace/Roguelike-deckbuilder/reviews/visual-v0.5-runtime/fullhand-fixture.json','utf8'));
const occupancy=JSON.parse(await fs.readFile('/workspace/scratch/hunter-v07/evidence/occupancy-fixtures-r5.json','utf8')).fixtures;
const sources=[['r4',process.env.HUNTER_REVIEW_URL]];
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),results=[];
try { for (const [revision,url] of sources) for (const mode of ['bind-third-auto','bind-third-window','bind-fifth-auto','final-kill-window','hunter-defeat-window']) {
 const context=await browser.newContext({viewport:{width:1280,height:720}}), page=await context.newPage(), errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto(url);
 const s=mode.startsWith('bind')?structuredClone(occupancy.find(f=>f.name===`legal-occupancy-${mode.startsWith('bind-third')?2:4}`).state):mode.startsWith('hunter')?structuredClone(full):await page.evaluate(async()=>{const e=await import('/src/engine.ts');const s=e.applyAction(e.createGame(121),{type:'travel',choice:'battle'});s.enemies=s.enemies.slice(0,1);s.enemies[0].hp=1;s.enemies[0].block=0;const pile=[...s.hand,...s.draw,...s.discard];const i=pile.indexOf('scour');s.hand=[pile.splice(i,1)[0]];s.draw=pile;s.discard=[];return s;});
 if(mode.startsWith('hunter')){s.hp=1;s.block=0;}
 await page.evaluate(s=>{localStorage.setItem('hollowpact.run.v2',JSON.stringify(s));localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion:true,mute:true,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');},s);
 await page.reload(); await page.locator('[data-ui=resume]').click(); await page.waitForTimeout(350);
 const action=mode.startsWith('bind')?{type:'play',index:s.hand.indexOf('cairnhound')}:mode.startsWith('hunter')?{type:'endTurn'}:{type:'play',index:0,target:s.enemies[0].uid};
 const expected=await page.evaluate(async({s,action})=>{const e=await import('/src/engine.ts');if(!e.validateState(s)||!e.legalActions(s).some(a=>JSON.stringify(a)===JSON.stringify(action)))throw Error('Invalid independent resize fixture/action');return e.applyActionWithEvents(s,action);},{s,action});
 const before=await page.evaluate(()=>document.querySelector('#arena').__hunterProbe());
 await page.evaluate(()=>{window.reviewFrames=[];window.reviewEpoch=performance.now();window.reviewDone=false;const sample=()=>{const canvas=document.querySelector('#arena');window.reviewFrames.push({elapsed:performance.now()-window.reviewEpoch,probe:canvas?.__hunterProbe?.(),held:document.querySelector('#app').classList.contains('settling-combat'),save:localStorage.getItem('hollowpact.run.v2'),reward:!!document.querySelector('[data-action=reward]')});if(performance.now()-window.reviewEpoch<1900)requestAnimationFrame(sample);else window.reviewDone=true;};requestAnimationFrame(sample);});
 if(action.type==='play'){await page.locator(`[data-ui=play-card][data-index="${action.index}"]`).click();if(action.target)await page.locator(`[data-unit="${action.target}"]`).click();}else{await page.locator('[data-action=endTurn]').click();if(await page.locator('dialog[open] [data-ui=confirm-end]').count())await page.locator('[data-ui=confirm-end]').click();}
 const immediate=await page.evaluate(()=>({save:localStorage.getItem('hollowpact.run.v2'),probe:document.querySelector('#arena').__hunterProbe?.(),held:document.querySelector('#app').classList.contains('settling-combat')}));
 if(mode.endsWith('window')){await page.waitForTimeout(60);await page.setViewportSize({width:1024,height:720});}
 await page.waitForFunction(()=>window.reviewDone); const frames=await page.evaluate(()=>window.reviewFrames);
 const final=await page.evaluate(()=>({save:localStorage.getItem('hollowpact.run.v2'),probe:document.querySelector('#arena')?.__hunterProbe?.(),held:document.querySelector('#app').classList.contains('settling-combat'),text:document.querySelector('#scene-ui').innerText}));
 await page.screenshot({path:OUT+`/affected-${revision}-${mode}-settled.png`,fullPage:true});
 results.push({revision,mode,fixture:s,action,expected,before,immediate,frames,final,errors,immediateCanonical:immediate.save===JSON.stringify(expected.state),finalCanonical:final.save===JSON.stringify(expected.state)});
 await fs.writeFile(OUT+'/affected-actions-partial.json',JSON.stringify({scope:'Actual host UI dispatch; natural RAF probe sampling; no clock/pose overrides; explicit actual viewport resize for window cases. R2 preserved unchanged comparison.',results},null,2)+'\n');
 console.log({revision,mode,widths:[...new Set(frames.filter(f=>f.probe).map(f=>f.probe.width))],pose:[...new Set(frames.filter(f=>f.probe?.hunter).map(f=>f.probe.hunter.pose))],canonical:results.at(-1).immediateCanonical&&results.at(-1).finalCanonical,errors}); await context.close();
} await fs.writeFile(OUT+'/affected-actions.json',JSON.stringify({scope:'Five actual accepted-control scenarios each frozen R2/R3. Frame trace is timing evidence in software Chromium, not target-hardware performance measurement.',results},null,2)+'\n'); }finally{await browser.close();}
