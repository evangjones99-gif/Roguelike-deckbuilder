from pathlib import Path
import json,gzip,hashlib,math,collections
from PIL import Image
O=Path('.');R=Path('/workspace/Roguelike-deckbuilder');source=json.loads((O/'SOURCE-INTAKE.json').read_text());p=json.loads((R/'dist/build-provenance.json').read_text());assert p==source['candidate']
for f,h in p['hashes'].items():assert hashlib.sha256((R/f).read_bytes()).hexdigest()==h,f
raw=gzip.decompress((O/'results.json.gz').read_bytes());rec=json.loads((O/'RESULTS-RECEIPT.json').read_text());assert hashlib.sha256(raw).hexdigest()==rec['decodedSHA256']and len(raw)==rec['decodedBytes'];rows=json.loads(raw)['rows'];viol=[];poseMap={(0,0):'idle',(512,0):'anticipation',(1024,0):'attack',(0,512):'recovery',(512,512):'reaction',(1024,512):'death'};counts={};pairs=[];art=0
im=Image.open(R/'public/art/hunter-marek-v07-r3.png');assert im.size==(1536,1024);alpha=im.getchannel('A');alphaBounds={}
for (x,y),name in poseMap.items():alphaBounds[name]={str(t):alpha.crop((x,y,x+512,y+512)).point(lambda a:255 if a>=t else 0).getbbox()for t in [1,8,10,32,128]}
alphaViol=[]
for row in rows:
 for response in row['responses']:
  key='public/art'+response['url'].split('/art',1)[1];assert response['status']==200 and response['sha256']==row['provenance']['hashes'][key];art+=1
 bypose=collections.Counter()
 for q in row['draws']:
  pose=poseMap[tuple(q['source'][:2])];bypose[pose]+=1;w,h=q['backing'];outside=any(v['x']<-1e-8 or v['x']>w+1e-8 or v['y']<-1e-8 or v['y']>h+1e-8 for v in q['points']);
  if outside:viol.append({'variant':row['variant'],'case':row['name'],'pose':pose,'at':q['at'],'backing':q['backing'],'css':q['css'],'opacity':q['appOpacity'],'points':q['points']})
  if row['variant']=='candidate-23477':assert not outside
  for threshold,bbox in alphaBounds[pose].items():
   P=q['points'];xs=[bbox[0]/512,bbox[2]/512];ys=[bbox[1]/512,bbox[3]/512];points=[{k:(P[0][k]*(1-tx)+P[1][k]*tx)*(1-ty)+(P[2][k]*(1-tx)+P[3][k]*tx)*ty for k in ['x','y']}for tx in xs for ty in ys];bad=any(v['x']<-1e-8 or v['x']>w+1e-8 or v['y']<-1e-8 or v['y']>h+1e-8 for v in points)
   if bad:alphaViol.append({'variant':row['variant'],'case':row['name'],'pose':pose,'threshold':int(threshold),'backing':q['backing'],'opacity':q['appOpacity']})
   if row['variant']=='candidate-23477':assert not bad
 counts[row['variant']+'-'+row['name']+'-'+str(row['viewport']['width'])]=dict(bypose)
 if row['variant']=='candidate-23477':
  other=next(x for x in rows if x['variant']=='baseline-45bd'and x['name']==row['name']and x['viewport']==row['viewport']);a=[s['expected']for s in row['steps']if 'action'in s];b=[s['expected']for s in other['steps']if 'action'in s];assert a==b
  pixels=[]
  if row['name']=='normal-full6v6':
   A=next(s['pngSHA256']for s in row['steps']if s.get('stage')=='pixel-normal');B=next(s['pngSHA256']for s in other['steps']if s.get('stage')=='pixel-normal');assert A==B;pixels.append({'normalPixelsExact':True,'pngSHA256':A})
  if row['name'].startswith('terminal-')and row['name']!='terminal-wound':
   active=next(s for s in row['steps']if s.get('stage')=='active-'+row['name'].split('-',1)[1]);settled=next(s for s in row['steps']if s.get('stage')=='settled');assert active['held'] and not settled['held']
  pairs.append({'case':row['name'],'viewport':row['viewport'],'allStateEventsExact':True,'pixels':pixels})
seen=set(k for key,v in counts.items()if key.startswith('candidate-23477')for k in v);assert seen==set(poseMap.values()),seen
startup=[q for q in viol if q['case']=='normal-full6v6'and q['backing']==[390,939]]
strongStartup=[q for q in alphaViol if q['case']=='normal-full6v6'and q['backing']==[390,939]and q['threshold']>=8]
assert not strongStartup
summary={'actualAll76InputsStillExact':True,'served55OutputsPerBuild':'ALL110-SERVED-OUTPUTS.json','actualCases':len(rows),'actions':rec['actions'],'actualNormalCanvasPixelPairsExact':2,'matchedStateEventPairs':pairs,'artResponsesExact':art,'hunterPoseCounts':counts,'candidateObservedAllSixPoses':sorted(seen),'candidateHunterDraws':sum(len(row['draws'])for row in rows if row['variant']=='candidate-23477'),'baselineOutsideFullCells':viol,'baselineAlphaOutside':alphaViol,'naturalStartupOutsideCellDraws':len(startup),'naturalStartupStrongAlphaViolations':len(strongStartup),'alphaSourceBounds':alphaBounds,'qualification':'Full-cell/different alpha support checks are recorded, not evidence natural startup draws reached display. Inline220/390x939 stress is outside normal layout, and natural A/B ages differ. No RAF/time/source mutation or hardware/hearing/humanfun claim.'}
(O/'AUDIT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:summary[k]for k in ['actualCases','actions','actualNormalCanvasPixelPairsExact','artResponsesExact','candidateObservedAllSixPoses','candidateHunterDraws','naturalStartupOutsideCellDraws','naturalStartupStrongAlphaViolations']}));print('baselinefullcelloutsides',len(viol),'baselinealphacount',len(alphaViol))
