"""Unlink ONLY reviewed duplicate TMP ZIP after byte-exact disk retention and pushed source.
Source proposal; requires exact independent decision and a clean confirmed Git HEAD.
"""
import os,sys,json,hashlib,stat,subprocess,time
from pathlib import Path
BASE=Path('/workspace/scratch/standard-sol-preflight-new-copy-verification-author-r1')
OLD='/tmp/hollowpact-native-v07/source-preflight-bdf27374358eb176e62f832cb50261cb3334d8df.zip'
NEW='/workspace/scratch/retained-original-archives/preflight-bdf273-original-r4.zip'
REPO='/workspace/Roguelike-deckbuilder'
OUT=Path('/workspace/scratch/relocated-preflight-retirement-root-r6')
def load(path):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        s=os.fstat(fd);assert stat.S_ISREG(s.st_mode) and s.st_size<65536
        data=os.read(fd,65537);assert len(data)==s.st_size and os.fstat(fd)==s
        return json.loads(data)
    finally:os.close(fd)
def anchor(path):
    fds=[os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW)];rows=[]
    try:
        for name in str(Path(path).parent).split('/')[1:]:
            fd=os.open(name,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fds[-1]);s=os.fstat(fd)
            assert s==os.stat(name,dir_fd=fds[-1],follow_symlinks=False)
            rows.append((fds[-1],name,fd,s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid));fds.append(fd)
        return fds,rows
    except BaseException:
        for fd in reversed(fds):os.close(fd)
        raise
def stable(rows):
    for parent,name,fd,*wanted in rows:
        for s in (os.fstat(fd),os.stat(name,dir_fd=parent,follow_symlinks=False)):
            assert [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid]==wanted

def meta(path,fd):
    s=os.fstat(fd)
    return dict(path=path,dev=s.st_dev,ino=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,bytes=s.st_size,blocks=s.st_blocks,atimeNs=s.st_atime_ns,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,xattrs={k:os.getxattr(fd,k).hex() for k in sorted(os.listxattr(fd))})
def save(name,value):
    p=OUT/name
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    fd=os.open(OUT,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def writeall(fd,data):
    view=memoryview(data)
    while view:
        n=os.write(fd,view)
        if n<=0:raise OSError('failure-slot short write')
        view=view[n:]
def git(*args):return subprocess.check_output(['git','-C',REPO,*args],text=True).strip()
assert len(sys.argv)==4 and sys.argv[1]=='--retire-only-reviewed-tmp-duplicate'
commit,decision_path=sys.argv[2:]
assert len(commit)==40 and all(x in '0123456789abcdef' for x in commit)
pins=load(str(BASE/'PINS.json'));decision=load(decision_path)
assert decision['retireOnlyPath']==OLD and decision['retainedPath']==NEW
assert decision['replacementBetterStorage'] is True and decision['oldPhysicalPathNoLongerNeeded'] is True
assert decision['independentFullNewBodyVerified'] is True and decision['retainedSHA256']=='e7c40a711ec970e265818d3153b02237efde959231ebc024f13a2b57c21bfef0'
assert decision['producerJudgmentWise'] is True and decision['confirmedPushedCommit']==commit
assert git('rev-parse','HEAD')==git('rev-parse','refs/remotes/origin/codex/lanternbound-production')==commit
assert git('status','--porcelain')==''
result=load('/workspace/scratch/preflight-new-copy-c-read-outcome-r1/READ-RESULT.json')
assert result['status']=='ACTUAL INDEPENDENT WHOLE NEW ENCODING VERIFIED; ORIGINAL RETAINED'
assert result['sha256']==decision['retainedSHA256'] and result['bytes']==1856041104
assert result['originalMetadataBefore']==result['originalMetadataAfter']==pins['originalMetadata']
assert result['targetMetadataBefore']==result['targetMetadataAfter']==pins['targetMetadata']
assert result['nativeArchiveAndAnchorFDsClosed'] is True and result['allCallerFDsClosed'] is True
assert result['normalOwnedWrapperWaitCompleted'] is True and result['wrapperReturnCode']==0
assert result['allWrapperRowsAndFinal32MiB512MiBPassed'] is True and result['eventsUnchanged'] is True
assert result['nativeReceipts'][-1]['kind']=='RESULT' and result['nativeReceipts'][-1]['closeErrors']==0
assert result['originalBodyBytesRead']==result['originalAdvisedBytes']==0
OUT.mkdir(mode=0o700);held=[];files=[];started=time.time_ns();deleted=False;failurefd=None
try:
    for path,expected in [(OLD,pins['originalMetadata']),(NEW,pins['targetMetadata'])]:
        fds,rows=anchor(path);held.append((fds,rows))
        fd=os.open(Path(path).name,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW,dir_fd=fds[-1]);files.append(fd)
        assert meta(path,fd)==expected and os.fstat(fd)==os.stat(Path(path).name,dir_fd=fds[-1],follow_symlinks=False)
        stable(rows)
    # Current known agents/readers were held by ROOT; Linux open readers cannot be excluded atomically.
    save('BEFORE.json',dict(time_ns=started,old=pins['originalMetadata'],new=pins['targetMetadata'],decision=decision,commit=commit,originalBodyRead=False))
    for (fds,rows),fd,path,expected in zip(held,files,[OLD,NEW],[pins['originalMetadata'],pins['targetMetadata']]):
        stable(rows);assert meta(path,fd)==expected and os.fstat(fd)==os.stat(Path(path).name,dir_fd=fds[-1],follow_symlinks=False)
    assert git('status','--porcelain')=='' and git('rev-parse','HEAD')==commit
    oldparent=held[0][0][-1]
    # Reserve a new owned failure slot before the irreversible boundary.
    failurefd=os.open(OUT/'FAILURE-SLOT.json',os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    initial=json.dumps(dict(state='PREALLOCATED; EFFECT UNKNOWN IF ARMED WITHOUT CLOSED RESULT',oldPath=OLD,newPath=NEW)).encode()
    writeall(failurefd,initial+b' '*(65536-len(initial)));os.fsync(failurefd)
    save('ARMED.json',dict(state='UNLINK EFFECT UNKNOWN UNTIL ACTUAL RESULT OR PATH/FD INSPECTION',oldPath=OLD,newPath=NEW,commit=commit,time_ns=time.time_ns(),qualification='Interruption can occur between the filesystem effect and volatile bookkeeping. Never infer old name survival from an unset flag.'))
    os.unlink(Path(OLD).name,dir_fd=oldparent);deleted=True
    try:os.stat(Path(OLD).name,dir_fd=oldparent,follow_symlinks=False)
    except FileNotFoundError:pass
    else:raise RuntimeError('Old name unexpectedly exists after unlink')
    assert os.fstat(files[0]).st_nlink==0
    assert meta(NEW,files[1])==pins['targetMetadata'];stable(held[1][1])
    syncfd=os.open('.',os.O_RDONLY|os.O_DIRECTORY,dir_fd=oldparent)
    try:os.fsync(syncfd)
    finally:os.close(syncfd)
    for fd in files:os.close(fd)
    files=[]
    save('RESULT.json',dict(status='ONLY OLD PHYSICAL TMP DUPLICATE RETIRED; EXACT ENCODING RETAINED ON DISK',time_ns=time.time_ns(),commit=commit,oldPath=OLD,newPath=NEW,bytes=1856041104,sha256=decision['retainedSHA256'],oldNameAbsent=True,ownArchiveFDsClosed=True,newMetadataUnchanged=True,qualification='Independent full-new hash versus prior producer fresh hash; no logical Git audit, remote ZIP backup or exclusive unknown-reader guarantee. All formal releases and history retained.'))
except BaseException as e:
    observed=None
    try:
        observed=not os.path.lexists(OLD)
    except BaseException:pass
    payload=dict(state='FAILURE; INSPECT ACTUAL PATH AND RETAINED COPY',error=repr(e),oldNameAbsentObserved=observed,volatileUnlinkReturnedFlag=deleted,time_ns=time.time_ns(),qualification='ARMED remains durable if this failure update is interrupted; no blind retry and no survival claim from the volatile flag.')
    if failurefd is not None:
        data=json.dumps(payload).encode();assert len(data)<65536
        os.lseek(failurefd,0,os.SEEK_SET);writeall(failurefd,data+b' '*(65536-len(data)));os.fsync(failurefd)
    else:
        save('FAILURE-BEFORE-ARMING.json',payload)
    raise
finally:
    if failurefd is not None:os.close(failurefd)
    for fd in files:os.close(fd)
    for fds,rows in reversed(held):
        for fd in reversed(fds):os.close(fd)
