import os,resource,json,hashlib,subprocess,time,signal,stat
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(32*1048576,32*1048576))
B='/workspace/scratch/standard-sol-preflight-new-copy-c-verification-author-r1'
P='/workspace/scratch/standard-sol-preflight-new-copy-c-source-independent-r1'
D='/workspace/scratch/preflight-new-copy-c-binary-r1'
E='/workspace/scratch/preflight-new-copy-c-compile-guard-r1'
R='/workspace/scratch/preflight-new-copy-c-compile-outcome-r1'
W='/workspace/scratch/guard-node-phase-r1.py'
CC='/usr/bin/x86_64-linux-gnu-gcc-14'
def read(p,cap=65536):
 f=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  s=os.fstat(f);assert stat.S_ISREG(s.st_mode)and s.st_size<=cap
  b=b''
  while True:
   x=os.read(f,65536)
   if not x:break
   b+=x;assert len(b)<=cap
  assert s==os.fstat(f)==os.stat(p,follow_symlinks=False);return b
 finally:os.close(f)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):
 b=(json.dumps(v,sort_keys=True,indent=2)+'\n').encode();f=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  view=memoryview(b)
  while view:view=view[os.write(f,view):]
  os.fsync(f)
 finally:os.close(f)
 return sha(b)
def pid(p):
 try:
  b=read('/proc/'+str(p)+'/stat',4096);tail=b[b.rfind(b')')+2:].decode().split();return {'status':'PRESENT','pid':p,'startTimeTicks':int(tail[19]),'pgid':int(tail[2]),'sid':int(tail[3])}
 except FileNotFoundError:return {'status':'ABSENT'}
os.mkdir(R,0o700)
p=json.loads(read(B+'/PINS.json'))
sourcegate=read(P+'/SOURCE-GATE.json');assert sha(sourcegate).startswith('e259b1')
controls=[B+'/verify_new_copy.c',B+'/PINS.json',B+'/CALLER-PROTOCOL.md',W,P+'/SOURCE-GATE.json',P+'/REVIEW.md','/workspace/scratch/preflight-new-copy-c-tool-prerequisite-supplement-r1.json']+[x['path']for x in p['controlBodies']]
before={x:sha(read(x))for x in controls}
assert before[B+'/verify_new_copy.c']=='684e5e6a4382eda0dd078134d0e06c59239df9ca78781be63a2db5c5408af9e9'
assert before[B+'/PINS.json']=='9872aec57818dbe46f57b026520049d658dc06c9aa68d458b2dba94d18b907be'
assert before[B+'/CALLER-PROTOCOL.md']=='1c077c6ef831933ab31a0581cd2f89c7617bf0febeccf383714f4c3c26726c7e'
assert before[W]==p['wrapperSHA256']
for x in p['controlBodies']:assert before[x['path']]==x['sha256']
cs=os.stat(CC,follow_symlinks=False);compiler={'path':CC,'dev':cs.st_dev,'ino':cs.st_ino,'mode':cs.st_mode,'uid':cs.st_uid,'gid':cs.st_gid,'bytes':cs.st_size,'mtimeNs':cs.st_mtime_ns,'ctimeNs':cs.st_ctime_ns}
assert cs.st_ino==9223372036855095028 and cs.st_size==1162264 and stat.S_ISREG(cs.st_mode)and os.access(CC,os.X_OK)
v=os.statvfs('/workspace/scratch');baseline={'time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text()),'free':v.f_bavail*v.f_frsize,'memoryEvents':Path('/sys/fs/cgroup/memory.events').read_text()}
cmd=['python3','-I',W,B,E,'32',CC,'-std=c11','-O0','-Wall','-Wextra',B+'/verify_new_copy.c','-o',D+'/verify_new_copy','-lcrypto']
result={'scope':'ONE compilation only; no binary/archive execution','phaseBaseline':baseline,'command':cmd,'sourceGateSHA256':sha(sourcegate),'sourceControlBefore':before,'compilerMetadataBefore':compiler,'binaryExecuted':False,'archiveBodyBytesRead':0,'archiveAdviceIssued':False,'retirementGranted':False,'noRetry':True}
child=None
try:
 if baseline['maximum']-baseline['current']<32*1048576+512*1048576 or baseline['free']<64*1048576:
  result['status']='PRE-WRAPPER32+512 ADMISSION REFUSED'
 else:
  os.mkdir(D,0o700)
  env=dict(os.environ);removed=[]
  for k in ['LD_PRELOAD','LD_LIBRARY_PATH','OPENSSL_CONF','OPENSSL_MODULES','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','OBJC_INCLUDE_PATH']:
   if k in env:removed.append(k);env.pop(k)
  env['LC_ALL']='C';result['sanitizedEnvironmentKeys']=removed
  child=subprocess.Popen(cmd,env=env,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE);ident=pid(child.pid);result['ownedWrapperIdentity']=ident
  stdout,stderr=child.communicate(timeout=max(0,(baseline['monotonic_ns']+60_000_000_000-time.monotonic_ns())/1e9))
  result.update({'wrapperReturnCode':child.returncode,'normalOwnedWrapperWaitCompleted':True,'wrapperPostWait':pid(child.pid),'stdout':stdout.decode(errors='replace'),'stderr':stderr.decode(errors='replace'),'wholePhaseNanoseconds':time.monotonic_ns()-baseline['monotonic_ns']})
  assert result['wholePhaseNanoseconds']<=60_000_000_000
  ar=json.loads(read(E+'/ADMISSION.json'));wr=json.loads(read(E+'/RESULT.json'))
  result['actualWrapperResultSHA256']=sha(read(E+'/RESULT.json'));result['actualCompilerLogSHA256']=sha(read(E+'/EXECUTION.log'));result['compilerWarningsAndErrorsRetainedAt']=E+'/EXECUTION.log'
  rows=wr['samples']+[wr['final']];result['samples']=len(wr['samples']);result['minimumHeadroom']=min(x['headroom']for x in rows);result['maximumObservedWholePhaseDelta']=max(x['current']-baseline['current']for x in rows)
  assert ar['admitted'] and ar['work']==33554432 and ar['reserve']==536870912
  for row in rows:assert row['maximum']==baseline['maximum'] and row['headroom']>=536870912 and row['current']-baseline['current']<=33554432 and row['free']>=1048576 and baseline['time_ns']<=row['time_ns']<=baseline['time_ns']+60_000_000_000
  assert wr['memory_events_before']==wr['memory_events_after']==baseline['memoryEvents']==Path('/sys/fs/cgroup/memory.events').read_text()
  result['allSamplesAndFinal32MiB512MiBPassed']=True;result['eventsUnchanged']=True
  if child.returncode!=0 or wr['exit_code']!=0 or wr['failure']is not None:result['status']='COMPILATION FAILED OR RESOURCE STOPPED; NO RETRY'
  else:
   binary=D+'/verify_new_copy';f=os.open(binary,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);s=os.fstat(f)
   try:
    assert stat.S_ISREG(s.st_mode)and s.st_uid==os.geteuid()and s.st_nlink==1 and s.st_size<=2097152
    digest=hashlib.sha256();n=0;magic=b''
    while True:
     b=os.read(f,65536)
     if not b:break
     if not n:magic=b[:4]
     n+=len(b);digest.update(b)
    assert n==s.st_size and magic==b'\x7fELF'and s==os.fstat(f)==os.stat(binary,follow_symlinks=False);os.fsync(f)
    result['binaryPin']={'path':binary,'sha256':digest.hexdigest(),'bytes':n,'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'ELFMagicVerified':True,'binaryExecuted':False}
   finally:os.close(f)
   result['status']='COMPILED AND WHOLE ELF PINNED; NOT EXECUTED'
 after={x:sha(read(x))for x in controls};assert before==after;result['sourceControlPosthashes']=after
 s=os.stat(CC,follow_symlinks=False);assert compiler=={'path':CC,'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns};result['compilerMetadataUnchangedExceptNormalAccessTime']=True
 for folder in [D,E]:
  if os.path.isdir(folder):
   for name in os.listdir(folder):
    f=os.open(folder+'/'+name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:os.fsync(f)
    finally:os.close(f)
   f=os.open(folder,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME);os.fsync(f);os.close(f)
 result['proofFilesAndDirectoriesFsynced']=True;result['finalCallerTimeNs']=time.time_ns();assert result['finalCallerTimeNs']<=baseline['time_ns']+60_000_000_000
except BaseException as e:
 result.update({'status':'COMPILE CALLER FAILED/REFUSED; NO RETRY','errorType':type(e).__name__,'error':str(e)})
 if child is not None and child.poll()is None:
  # Wrapper compiler owns a separate known group; TERM it, then owned wrapper.
  try:
   for name in os.listdir('/proc'):
    if not name.isdigit():continue
    seen=pid(int(name))
    if seen.get('status')=='PRESENT':
     b=read('/proc/'+name+'/stat',4096);tail=b[b.rfind(b')')+2:].decode().split()
     if int(tail[1])==child.pid:os.killpg(seen['pgid'],signal.SIGTERM)
  except (FileNotFoundError,ProcessLookupError):pass
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:child.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  result['ownedWrapperTerminatedAndWaited']=True
finally:
 result['processClosureQualification']='Normal owned wrapper wait plus exact wrapper PID/starttick post-observation where available; compiler/gcc descendants are qualified by normal command return, not a global/group-absence proof.'
 result['allCallerFDsClosed']=True
 h=put(R+'/COMPILE-RESULT.json',result)
 f=os.open(R,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME);os.fsync(f);os.close(f)
 print(json.dumps({'outcomePath':R+'/COMPILE-RESULT.json','outcomeSHA256':h,'status':result['status'],'binaryPin':result.get('binaryPin'),'samples':result.get('samples'),'minimumHeadroom':result.get('minimumHeadroom'),'maximumObservedWholePhaseDelta':result.get('maximumObservedWholePhaseDelta'),'elapsedNs':result.get('wholePhaseNanoseconds'),'error':result.get('error')}))
