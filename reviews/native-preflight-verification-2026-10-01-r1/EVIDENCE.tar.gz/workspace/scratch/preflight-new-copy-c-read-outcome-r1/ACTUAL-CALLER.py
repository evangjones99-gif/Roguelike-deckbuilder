import os,resource,json,time,hashlib,subprocess,signal,stat
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(32*1048576,32*1048576))
B='/workspace/scratch/standard-sol-preflight-new-copy-c-verification-author-r1'
BIN='/workspace/scratch/preflight-new-copy-c-binary-r1/verify_new_copy'
E='/workspace/scratch/preflight-new-copy-c-read-guard-r1'
R='/workspace/scratch/preflight-new-copy-c-read-outcome-r1'
D='/workspace/scratch/preflight-new-copy-c-ROOT-DECLARATION-r1.json'
EVENTS='/workspace/scratch/preflight-new-copy-c-ROOT-EVENTS-r1.txt'
W='/workspace/scratch/guard-node-phase-r1.py'
G='/workspace/scratch/standard-sol-preflight-new-copy-c-compile-independent-r1'
def read(p,cap=65536):
 f=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  s=os.fstat(f);assert stat.S_ISREG(s.st_mode)and s.st_size<=cap;b=b''
  while True:
   a=os.read(f,65536)
   if not a:break
   b+=a;assert len(b)<=cap
  assert s==os.fstat(f)==os.stat(p,follow_symlinks=False);return b
 finally:os.close(f)
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,b):
 f=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  view=memoryview(b)
  while view:view=view[os.write(f,view):]
  os.fsync(f)
 finally:os.close(f)
def encode(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def pid(n):
 try:
  b=read('/proc/'+str(n)+'/stat',4096);tail=b[b.rfind(b')')+2:].decode().split();return {'status':'PRESENT','pid':n,'startTimeTicks':int(tail[19]),'pgid':int(tail[2]),'sid':int(tail[3])}
 except FileNotFoundError:return {'status':'ABSENT'}
def metadata(expected,parents):
 p=Path(expected['path']);flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC;held=[os.open('/',flags)];rows=[];fd=None
 try:
  for name in p.parent.parts[1:]:
   n=os.open(name,flags,dir_fd=held[-1]);s=os.fstat(n);assert s==os.stat(name,dir_fd=held[-1],follow_symlinks=False)
   rows.append({'name':name,'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid});held.append(n)
  assert rows==parents
  fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK,dir_fd=held[-1]);s=os.fstat(fd)
  row={'path':str(p),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'bytes':s.st_size,'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'xattrs':{k:os.getxattr(fd,k).hex()for k in sorted(os.listxattr(fd))}}
  assert row==expected and s==os.stat(p.name,dir_fd=held[-1],follow_symlinks=False) and os.lseek(fd,0,os.SEEK_CUR)==0
  return row
 finally:
  if fd is not None:os.close(fd)
  for f in reversed(held):os.close(f)
p=json.loads(read(B+'/PINS.json'));compiled=json.loads(read('/workspace/scratch/preflight-new-copy-c-compile-outcome-r1/COMPILE-RESULT.json'))
controls=[B+'/verify_new_copy.c',B+'/PINS.json',B+'/CALLER-PROTOCOL.md',W,G+'/COMPILE-BINARY-GATE.json',G+'/REVIEW.md','/workspace/scratch/preflight-new-copy-c-compile-outcome-r1/COMPILE-RESULT.json']+[x['path']for x in p['controlBodies']]
before={x:sha(read(x))for x in controls}
assert before[G+'/COMPILE-BINARY-GATE.json']=='59a53c7246e104439183ed476d784d7f9b5f07880f86de3f0cef27a63aa949fc'
assert before[G+'/REVIEW.md']=='f6c350f6357963a7aefdc055a5395b72c729f60a22a5934e61ab46bd089c28ef'
assert before[B+'/verify_new_copy.c']=='684e5e6a4382eda0dd078134d0e06c59239df9ca78781be63a2db5c5408af9e9'
assert before[B+'/PINS.json']=='9872aec57818dbe46f57b026520049d658dc06c9aa68d458b2dba94d18b907be'
assert before[B+'/CALLER-PROTOCOL.md']=='1c077c6ef831933ab31a0581cd2f89c7617bf0febeccf383714f4c3c26726c7e'
assert before[W]==p['wrapperSHA256']
for x in p['controlBodies']:assert before[x['path']]==x['sha256']
binary=read(BIN);assert sha(binary)==compiled['binaryPin']['sha256']=='98bc207422f4f4957d1222e52a9431f3f5709c97d66da6e49b80237afc67098e'and len(binary)==32504
s=os.stat(BIN,follow_symlinks=False);assert (s.st_dev,s.st_ino,s.st_uid,s.st_nlink,s.st_mode,s.st_size)==(27,678921,1000,1,0o100700,32504)
target_before=metadata(p['targetMetadata'],p['targetParents']);old_before=metadata(p['originalMetadata'],p['originalParents'])
v=os.statvfs('/workspace/scratch');baseline={'time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text()),'free':v.f_bavail*v.f_frsize,'memoryEvents':Path('/sys/fs/cgroup/memory.events').read_text()}
result={'scope':'ONE independent full NEW disk-encoding stream vs ROOT producer fresh hash; original metadata-only','phaseBaseline':baseline,'targetMetadataBefore':target_before,'originalMetadataBefore':old_before,'sourceControlBefore':before,'binarySHA256':sha(binary),'compileAcceptanceSHA256':before[G+'/COMPILE-BINARY-GATE.json'],'authority':'ROOT explicit independent full-read grant after sealed distinct actual compile acceptance','archiveBodyBytesReadBeforeAdmission':0,'archiveAdviceBeforeAdmission':False,'bothArchivesRetained':True,'retirementGranted':False,'noRetry':True}
child=None;os.mkdir(R,0o700)
try:
 if baseline['maximum']-baseline['current']<33554432+536870912 or baseline['free']<64*1048576:
  result.update({'status':'PRE-WRAPPER32+512 ADMISSION REFUSED','helperLaunched':False,'declarationCreated':False})
 else:
  d={'sourceSHA256':before[B+'/verify_new_copy.c'],'pinSHA256':before[B+'/PINS.json'],'protocolSHA256':before[B+'/CALLER-PROTOCOL.md'],'binaryPath':BIN,'binarySHA256':sha(binary),'compileAcceptancePath':G+'/COMPILE-BINARY-GATE.json','compileAcceptanceSHA256':before[G+'/COMPILE-BINARY-GATE.json'],'knownAffectedArchiveActorsHeld':True,'noUnknownAffectedWriterObserved':True,'noHeavyRuntimeConcurrent':True,'priorCopyCompleteAndFsynced':True,'phaseBaseline':baseline,'work':33554432,'reserve':536870912,'deadlineSeconds':60,'allowsRetirement':False}
  write(D,encode(d));write(EVENTS,baseline['memoryEvents'].encode());controls.extend([D,EVENTS]);before[D]=sha(read(D));before[EVENTS]=sha(read(EVENTS))
  argv=[BIN,str(baseline['current']),str(baseline['maximum']),str(baseline['time_ns']),str(baseline['monotonic_ns']),EVENTS]
  cmd=['python3','-I',W,B,E,'32']+argv;result['command']=cmd;result['declarationCreated']=True
  env=dict(os.environ)
  for key in ['LD_PRELOAD','LD_LIBRARY_PATH','OPENSSL_CONF','OPENSSL_MODULES']:env.pop(key,None)
  env['LC_ALL']='C'
  child=subprocess.Popen(cmd,env=env,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE);result['ownedWrapperIdentity']=pid(child.pid)
  out,err=child.communicate(timeout=max(0,(baseline['monotonic_ns']+60_000_000_000-time.monotonic_ns())/1e9))
  result.update({'normalOwnedWrapperWaitCompleted':True,'wrapperReturnCode':child.returncode,'wrapperPostWait':pid(child.pid),'stdout':out.decode(errors='replace'),'stderr':err.decode(errors='replace'),'wholePhaseNanoseconds':time.monotonic_ns()-baseline['monotonic_ns']})
  wr=json.loads(read(E+'/RESULT.json'));ad=json.loads(read(E+'/ADMISSION.json'));log=read(E+'/EXECUTION.log');receipts=[json.loads(line)for line in log.decode().splitlines()if line.strip()]
  result['nativeReceipts']=receipts;rows=wr['samples']+[wr['final']]
  result.update({'samples':len(wr['samples']),'minimumHeadroom':min(x['headroom']for x in rows),'maximumObservedWholePhaseDelta':max(x['current']-baseline['current']for x in rows),'wrapperResultSHA256':sha(read(E+'/RESULT.json')),'nativeLogSHA256':sha(log)})
  assert ad['admitted'] and ad['work']==33554432 and ad['reserve']==536870912 and ad['command']==argv
  for row in rows:assert row['maximum']==baseline['maximum'] and row['headroom']>=536870912 and row['current']-baseline['current']<=33554432 and row['free']>=1048576 and baseline['time_ns']<=row['time_ns']<=baseline['time_ns']+60_000_000_000
  assert wr['memory_events_before']==wr['memory_events_after']==baseline['memoryEvents']==Path('/sys/fs/cgroup/memory.events').read_text()
  assert result['wholePhaseNanoseconds']<=60_000_000_000;result['allWrapperRowsAndFinal32MiB512MiBPassed']=True;result['eventsUnchanged']=True
  for entry in receipts:
   n=entry['pid'];observed=pid(n);assert observed['status']=='ABSENT'or observed['startTimeTicks']!=entry['startTimeTicks'];result.setdefault('nativePostWait',{})[str(n)]=observed
  if child.returncode!=0 or wr['exit_code']!=0 or wr['failure']is not None:
   result['status']='NATIVE READ FAILED/RESOURCE STOPPED; FULL VERIFICATION INCOMPLETE'
  else:
   assert len(receipts)==2 and receipts[0]['kind']=='BEGIN'and receipts[1]['kind']=='RESULT'
   begin,final=receipts;assert (begin['pid'],begin['startTimeTicks'])==(final['pid'],final['startTimeTicks'])
   assert final['bytesRead']==1856041104 and final['sha256']=='e7c40a711ec970e265818d3153b02237efde959231ebc024f13a2b57c21bfef0'
   assert final['adviceAttemptedRanges']==final['adviceReturnedRanges']==885 and final['advisedBytes']==1855979520 and final['pendingRangeLength']==0 and final['originalBodyBytesRead']==final['originalAdvisedBytes']==0 and final['archiveAndAnchorFDsClosed']and final['closeErrors']==0
   assert final['lastGuard']['rss']<=33554432 and final['lastGuard']['hwm']<=33554432 and final['maximumAggregateDelta']<=33554432 and final['minimumHeadroom']>=536870912
   result.update({'status':'ACTUAL INDEPENDENT WHOLE NEW ENCODING VERIFIED; ORIGINAL RETAINED','bytes':final['bytesRead'],'sha256':final['sha256'],'adviceAttemptedRanges':885,'adviceReturnedRanges':885,'advisedBytes':1855979520,'unadvisedTailBytes':61584,'originalBodyBytesRead':0,'originalAdvisedBytes':0,'nativeArchiveAndAnchorFDsClosed':True,'producerComparisonNotHistoricalGolden':True,'logicalGitCoverageClaim':False})
 result['targetMetadataAfter']=metadata(p['targetMetadata'],p['targetParents']);result['originalMetadataAfter']=metadata(p['originalMetadata'],p['originalParents'])
 after={x:sha(read(x))for x in controls};assert before==after;result['sourceControlPosthashes']=after
 assert sha(read(BIN))==result['binarySHA256'];bs=os.stat(BIN,follow_symlinks=False)
 result['binaryMetadataAfter']={'dev':bs.st_dev,'ino':bs.st_ino,'mode':bs.st_mode,'uid':bs.st_uid,'nlink':bs.st_nlink,'bytes':bs.st_size,'atimeNs':bs.st_atime_ns,'mtimeNs':bs.st_mtime_ns,'ctimeNs':bs.st_ctime_ns}
 assert (bs.st_dev,bs.st_ino,bs.st_mode,bs.st_uid,bs.st_nlink,bs.st_size,bs.st_mtime_ns,bs.st_ctime_ns)==(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 result['binaryAtimeQualification']='Ordinary executable access may alter atime; bytes/identity/other metadata unchanged.'
 if os.path.isdir(E):
  for name in os.listdir(E):
   f=os.open(E+'/'+name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
   try:os.fsync(f)
   finally:os.close(f)
  f=os.open(E,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME);os.fsync(f);os.close(f)
 for path in [BIN,D,EVENTS]:
  if os.path.exists(path):
   f=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);os.fsync(f);os.close(f)
 result['proofFilesAndDirectoriesFsynced']=True;result['finalCallerTimeNs']=time.time_ns();result['finalCallerMonotonicNs']=time.monotonic_ns()
 assert result['finalCallerTimeNs']<=baseline['time_ns']+60_000_000_000 and result['finalCallerMonotonicNs']<=baseline['monotonic_ns']+60_000_000_000
except BaseException as e:
 result.update({'status':'READ CALLER FAILED/INTERRUPTED; NO RETRY','errorType':type(e).__name__,'error':str(e)})
 if child is not None and child.poll()is None:
  try:
   if os.path.exists(E+'/EXECUTION.log'):
    for line in read(E+'/EXECUTION.log').decode().splitlines():
     r=json.loads(line);ident=pid(r['pid'])
     if ident['status']=='PRESENT'and ident['startTimeTicks']==r['startTimeTicks']:os.killpg(r['pgid'],signal.SIGTERM)
  except BaseException as stop_error:result['nativeStopError']=repr(stop_error)
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:child.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  result['ownedWrapperTerminatedAndWaited']=True
finally:
 result['allCallerFDsClosed']=True;result['qualification']='Independent new full stream compares producer fresh hash; no original body reread, logical Git audit, continuous exclusion, durable cache gain or retirement approval. Native receipt FD closure qualified by normal process exit and scoped PID absence.'
 b=encode(result);write(R+'/READ-RESULT.json',b);f=os.open(R,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME);os.fsync(f);os.close(f)
 print(json.dumps({'path':R+'/READ-RESULT.json','sha256':sha(b),'status':result['status'],'bytes':result.get('bytes'),'fullHash':result.get('sha256'),'samples':result.get('samples'),'minimumHeadroom':result.get('minimumHeadroom'),'maximumObservedWholePhaseDelta':result.get('maximumObservedWholePhaseDelta'),'elapsedNs':result.get('wholePhaseNanoseconds'),'nativePostWait':result.get('nativePostWait'),'error':result.get('error')}))
