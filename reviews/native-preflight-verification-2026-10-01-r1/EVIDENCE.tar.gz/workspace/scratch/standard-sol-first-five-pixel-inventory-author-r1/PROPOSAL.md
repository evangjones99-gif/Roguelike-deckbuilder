# Real opening: opt-in pixel binding trial

SOURCE PROPOSAL ONLY. No game edits, assets, adapter, build or play were produced here. The fresh 300-second coaching protocol remains sealed and awaits its own actual comparison. ROOT owns any subsequent experimental fork, strict build, runtime and selection. R4 research art remains withheld from game-art selection; owner-authorized comparison **inside a playable experimental candidate** can still test a limited alternative without promotion.

## One payoff hypothesis, after the coaching comparison

A visibly connected card → Cairn Hound arrival → READY → intentional command sequence may help the first binding feel like an acquired ally and make its command opportunity easier to understand. This is a presentation hypothesis, not a balance or fun result. Test only after actual H1 coaching observations, so coaching and art changes are not silently conflated.

Propose one opt-in **Cairn Hound** presentation in a separate, clearly labelled experimental fork. Use the ordinary deck, random UI-created hand, legal card play and enemy formation. If no Cairn Hound is drawn/bound, record that the hypothesis was not exercised; do not replace the hand, change the seed, summon through a script or call a Grave Hound the starter. All unhandled actors retain existing artwork. A mixed-art trial can isolate a local binding payoff but cannot prove cohesive whole-game art or a better complete opening. No new lab, roster expansion or framework rewrite is needed.

## Actual opening inventory

Default `createGame` is schema 3 / engineKind 2, floor 0 map, 65 health, 65 gold, `nextUid=1`, with the 12-card starter deck. Actual travel advances to floor 1. Battle starts turn 1, normally 5 energy, zero hunter block, no allies, and draws five from the seeded shuffled deck. The primary UI does not guarantee a summon in the opening hand.

| Starter binding | Copies; base cost / HP / attack | Identity and actual payoff | Original pixel requirement |
|---|---|---|---|
| `cairnhound`, Cairn Hound, `hound` | 2; 1 / 7 / 3 | Binding wards hunter 2; commands add 2 damage against an enemy with no block | Rear three-quarter **spectral Cairn** canine: arrival, idle/READY, loaded jaw attack, recovery, reaction, supported death |
| `fenstalker`, Fen Stalker, `stalker` | 1; 2 / 10 / 4 | No binding effect; command that lowers enemy HP heals this creature 2 | Rear amphibious corpse-stalker, distinct anatomy and command/reaction/heal silhouette |
| `ashwidow`, Ash Widow, `spider` | 1; 2 / 7 / 2 | No binding effect; living widow adds 2 to targeted damaging spells | Rear spider silhouette with readable support legs, bite/command and reaction; no invented on-bind burn |
| `briarcolossus`, Briar Colossus, `colossus` | 1; 3 / 18 / 4 | No binding effect; each command gives hunter 2 block | Rear bark/bone/iron giant, loaded heavy strike and grounded collapse |

Remaining starter cards: Scour×2 (`damage`, cost 1, base 6 enemy damage); Iron Ward×2 (`block`, 1, hunter block 7); Blood Sutures×1 (`heal`, 1, creature heal 6 plus block 2); Sundering Hex×1 (`shred`, 1, remove enemy block then damage 3); Forbidden Survey×1 (`draw`, 1, draw 2). These require truthful tool/ward/heal/readout feedback, not five additional monster sheets. Exact effects remain reducer-derived: widow modifies targeted spell damage; Revenant reduces it; draw does not emit an invented hit event. Costs and full card rules stay live DOM.

Generation-2 `worldFormation` selects first two regular nodes from **raider + revenant** or **raider + thrall** using stable formation IDs. The legacy random `sets` in engine are not the default sampler. At floor 1 / difficulty 0, the enemies are:

| Enemy cardId / species | Base HP / attack | Actual intent and consequence | Required front/three-quarter identity |
|---|---|---|---|
| `raider` / `warlord`, Ironjaw Reaver | 16 / 4 | Turn 1 Guard 4 self; turn 2 Cleave 5; armored commands retaliate for 1 through creature block | Armored reaver with shield/cleaver poses; skeleton spear is not this enemy |
| `revenant` / `wraith`, Gloam Revenant | 15 / 5 | Rend 5 to hunter, ignores block; targeted damaging spells deal 2 less | Spectral front silhouette and ranged rend; no generic skeletal thrust substitution |
| `thrall` / `thrall`, Bone Thrall | 7 / 3 | Claw weakest binding, or hunter if none; a fallen marked binding redirects to hunter | Bone Thrall skull/ribs, front claw attack; research skeleton spear needs redesign |

Thus complete first-fight original art needs **eight identities**: hunter + four ally species + three enemies, with duplicate Cairn cards sharing appropriate artwork but separate UIDs. At the second node enemy HP gains the floor-based scale; difficulty and later rewards also change values, so never bake these base numbers into sprites/UI. A fast 300-second run may reach rewards, later regular brood/acolyte formations or other routes; this bounded trial must fall back honestly rather than claiming coverage of everything encountered.

UIDs are runtime identities, not asset names. First-battle enemy creation ordinarily consumes `e1`,`e2`; an immediate first binding then becomes `a3`, but later actions/encounters change that sequence. Key presentation by actual `Unit.uid`; choose an asset by exact side/cardId/species, never by hardcoded `a3`, display order or translated name. Enhanced `cardId + '+'` variants retain species but change stats/rules; rewards can add nonstarter Grave Hound and other species. Do not silently map all hounds to an allegedly finished Cairn asset.

## What R4 sheets genuinely supply

R4 is a synthetic static research composition, not a saved game or animation implementation. Each 64×64 indexed actor contains `idle0`, `idle1`, `bind`, `anticipate`, `contact`, `hit`, `death`; shared feet `[27,60]`, explicit per-pose/full-union bounds and integer 2×/3× display. It has no distinct recovery drawing, ordered arrival frames, timed contact dispatcher or engine-backed READY transition. The static hound knee-contact endpoint is not a valid contact target for every real enemy or a swept-contact proof.

The rear **gravehound** offers an original rear perspective and seven pose sketches; its long jaw still received reptilian/schematic criticism. It is not yet a spectral Cairn Hound, a finalized Grave Hound game asset or the stalker/spider/giant. The front skeleton supplies a skeletal perspective study, but its spear does not depict Bone Thrall's claw, the armored Reaver or Revenant. The adult masked hunter gives a flank identity study, not the current complete hunter cue/pose contract. No current research frame represents the pack-widow spell bonus or colossus ward mechanically.

Keep R4 and its rejection/acceptance reports exact. Its repaired static full slot union does not license copying the synthetic scene geometry into gameplay. Its above-label measured height >120 CSS px at 2× can still go above scene origin; bottom-only expansion is insufficient. A playable fork must use actual DOM measurements and expose upper and lower readouts, not reuse the lab's fixed illustrative strings.

## Minimal adapter boundary

Use the existing lightweight TypeScript/Canvas arena and live DOM controls, with one optional internal pixel-presentation module and exact asset metadata. No parallel reducer, replay engine, second renderer canvas, new dependency or persistent save setting. A fork/query opt-in may select this experimental presentation; its default remains current art, and labels identify the subset/unpromoted status. An invalid flag or missing asset uses current presentation with a truthful artwork notice. The exact flag/interface is a later source-reviewed implementation choice, not an API implemented here.

Keep main's accepted-action order: `applyActionWithEvents` → canonical replacement/save → `arena.playAction(action,before,after,events)` → audio with the exact renderer delay → live render/terminal hold. The optional adapter observes ordered `TransitionEvent`s only. `summon` includes side, target UID, cardId and cloned unit; Cairn's summon is followed by a real ward event sourced from that new UID to `hunter`. `hit` carries source/target/kind and resolved before/after HP, blocked and HP lost; `death` identifies the actual fallen UID. Heal/ward/buff/control remain their own effects. No damage, healing, ward or draw is reconstructed from pose/color.

Put the first Cairn's native `bind`/arrival pose at the existing action/birth anchor, then settle into idle with the canonical READY/readout available from its first published summon frame. Do not add a mandatory tutorial delay or invent a resource cost. Existing `acted=false` permits a free command on arrival; readiness is rule state, not an animation unlock. Author the missing recovery and enough genuinely different arrival/attack drawings before claiming a frame sequence. Preserve current attack phases (140 ms anticipation, 180 attack, 260 recovery), contact at 240 ms, reaction 220 ms and death hold 900 ms initially; pacing changes need their own comparison.

Preserve the renderer's common action anchor: max of allocation, reused-corpse-slot and referenced-future-birth holds. Audio must still use `getActionPresentationDelayMs`. Do not start an event touching a future newborn before that actor's published birth or put an overlapping birth over a held corpse. Do not lock unrelated ordinary actions merely because optional cues exist. Ordered resolved hits drive visual contact once; pose changes must not dispatch gameplay/audio hits. Terminal, cancellation, hidden-window and reduced-motion paths must settle to the saved canonical result and clean all owned RAF/listeners/waiters.

## Paint, ownership and readable outcome contract

Native art uses nearest-neighbor sampling and common integer display scale. Current PC body budgets reach 150 CSS px, so a 64×64 cell at 2× can be investigated; this is arithmetic, not measured fit. Sparse/narrow/dense bodies shrink under current budgets, and full-pose union plus hunter footprint may not fit that scale. Do not shrink only paint, clip poses, mix fractional pixel density or borrow the lab's 768×480 stage. Either publish a shared measured allocation that fits the trial at PC widths, or retain current presentation outside that reviewed fit envelope. No mobile/one-screen claim.

The actual arena region must come from the same pose/source cell/feet/transform that paints the actor. Publish one UID-owned `cell`, `bodyRect`, painted rect, `hitRect` (paint intersect actual body cell), and intent/Inspect/identity/stats/status rectangles. Main consumes these already. No moving only DOM readouts, full transparent cell as an overlapping hit button, hidden actor relabelled as a survivor, or separate synthetic `ownerAt` deciding legal targets. Reducer `legalActions` remains the authority. Held departed actors retain `readoutUnit` and null `canonicalIndex`; newborn publication waits for its real deadline.

Keep identity, complete compact intent type/amount/target, HP/attack/block and READY/command-spent live, ≥12 px, naturally wrapped with full Inspector/ARIA text. Actual intent types include Guard, Rend with ignores-block, and Claw with binding target/fallback. Readout growth must reserve both top and bottom and keep Inspect near the actor; no giant background rail or victim-readout overlap to make the sprite larger. Keep bottom hand, costs, rules, hover/drag/cancel and keyboard targets unchanged. No-canvas/missing-art paths must retain usable normal-flow combat controls and explain artwork unavailability.

## Rejection-capable playable comparison

After H1, ROOT may prepare a separate strictly built/pinned experimental fork and fresh runtime phase. Compare the unchanged current presentation with the opt-in subset using real UI-created runs; disclose seed/hand/order and any missing Cairn opportunity. Record first Cairn card choice, actual binding ward, arrival/READY recognition, selected command/target preview, resolved contact/HP/block/death, and actual enemy response. Observe hand reach, pointer/Inspect ownership, keyboard focus, full readouts and reduced-motion/cancellation separately from any enjoyment statement. Existing saved runs must load identically; presentation state never enters the save schema.

Reject or revise for unclear Cairn identity, unconvincing canine motion, lost target/readout, mismatched cue/audio anchor, invented READY delay, clipping, broken fallback or rule/save divergence. R4 visual objections are inputs to that comparison, not silently waived. Actual play may show no benefit. This author's renderer/art authorship prevents independent approval of its own adapter; obtain distinct source and visual/play review. No browser, Node, build, archived body, remote telemetry or platform/Steam validation was performed here. The project uses Vite/TypeScript, Canvas/DOM, built-in Node build scripts and Playwright; package entries for Electron/platform packaging are not platform execution evidence.
