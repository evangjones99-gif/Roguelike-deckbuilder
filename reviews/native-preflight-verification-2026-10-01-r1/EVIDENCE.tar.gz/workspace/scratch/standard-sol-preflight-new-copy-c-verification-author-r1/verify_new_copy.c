#define _GNU_SOURCE
#define _FILE_OFFSET_BITS 64
#include <openssl/evp.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/xattr.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>

/* SOURCE PROPOSAL ONLY. One NEW disk encoding; original TMP never read/advised. */
#define TARGET "/workspace/scratch/retained-original-archives/preflight-bdf273-original-r4.zip"
#define ORIGINAL "/tmp/hollowpact-native-v07/source-preflight-bdf27374358eb176e62f832cb50261cb3334d8df.zip"
#define EVENTS "/workspace/scratch/preflight-new-copy-c-ROOT-EVENTS-r1.txt"
#define TOTAL UINT64_C(1856041104)
#define RANGE UINT64_C(2097152)
#define WORK UINT64_C(33554432)
#define RESERVE UINT64_C(536870912)
#define EXPECTED "e7c40a711ec970e265818d3153b02237efde959231ebc024f13a2b57c21bfef0"
typedef struct { const char *name; uint64_t dev,ino,mode,uid,gid; } Parent;
typedef struct { const char *path; uint64_t dev,ino,blocks,ctime_ns; const Parent *parents; int n; int fd[5]; struct stat root; } Archive;
static const Parent np[]={{"workspace",27,UINT64_C(9223372036854775855),040755,1000,1000},{"scratch",27,UINT64_C(9223372036855894707),040755,1000,1000},{"retained-original-archives",27,678627,040700,1000,1000}};
static const Parent op[]={{"tmp",33,1,041777,0,0},{"hollowpact-native-v07",33,1673651,040700,1000,1000}};
static Archive target={TARGET,27,678628,3625096,UINT64_C(1790859776790106720),np,3,{-1,-1,-1,-1,-1},{0}};
static Archive original={ORIGINAL,33,1702362,3625088,UINT64_C(1790815567573263991),op,2,{-1,-1,-1,-1,-1},{0}};
static uint64_t base,maximum,wall0,mono0,bytes,advised,attempted,returned,pending,current,seen_max,head,wall,mono,free_bytes,rss,hwm,samples,min_head=UINT64_MAX,max_delta;
static uint64_t start_ticks; static int close_errors,close_errno,errnum,all_closed; static volatile sig_atomic_t stopped;
static char events[1024],reason[96]="not-started",hash[65]=""; static EVP_MD_CTX *ctx;
static uint64_t ns(struct timespec t){return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec;}
static uint64_t now(clockid_t clock){struct timespec t;if(clock_gettime(clock,&t))return 0;return ns(t);}
static void on_signal(int n){stopped=n;}
static int bad(const char *why){snprintf(reason,sizeof reason,"%s",why);errnum=errno;return -1;}
static int text(const char *path,char *out,size_t cap){
 int fd=open(path,O_RDONLY|O_NOFOLLOW|O_CLOEXEC|O_NONBLOCK|(strcmp(path,EVENTS)==0?O_NOATIME:0));if(fd<0)return bad("control-open");
 if(strcmp(path,EVENTS)==0){struct stat s;if(fstat(fd,&s)||!S_ISREG(s.st_mode)||s.st_uid!=1000||s.st_mode!=0100600||s.st_nlink!=1||s.st_size>1023){close(fd);return bad("events-file-identity");}}
 size_t n=0;ssize_t r;while(n<cap-1&&(r=read(fd,out+n,cap-1-n))>0)n+=(size_t)r;
 if(n==cap-1){char extra; r=read(fd,&extra,1);if(r!=0){close(fd);return bad("control-bound");}}
 else if(r<0){close(fd);return bad("control-read");}
 out[n]=0;if(close(fd))return bad("control-close");return 0;
}
static int number(const char *s,uint64_t *v){char *end;errno=0;unsigned long long n=strtoull(s,&end,10);if(errno||!s[0]||s[0]=='-'||*end)return bad("number");*v=n;return 0;}
static int proc_identity(void){
 char b[4096];if(text("/proc/self/stat",b,sizeof b))return -1;char *p=strrchr(b,')');if(!p)return bad("proc-stat");p+=2;char *save,*t=strtok_r(p," ",&save);for(int i=0;i<19&&t;i++)t=strtok_r(NULL," ",&save);if(!t)return bad("proc-startticks");return number(t,&start_ticks);
}
static int guard(void){
 char b[8192],e[1024];uint64_t m;struct statvfs v;
 wall=now(CLOCK_REALTIME);mono=now(CLOCK_MONOTONIC);
 if(text("/sys/fs/cgroup/memory.current",b,sizeof b))return -1;b[strcspn(b,"\n")]=0;if(number(b,&current))return -1;
 if(text("/sys/fs/cgroup/memory.max",b,sizeof b))return -1;b[strcspn(b,"\n")]=0;if(number(b,&m))return -1;
 seen_max=m;head=m>=current?m-current:0;if(samples==0||head<min_head)min_head=head;if(current>=base&&current-base>max_delta)max_delta=current-base;samples++;
 if(text("/sys/fs/cgroup/memory.events",e,sizeof e)||text("/proc/self/status",b,sizeof b)||statvfs("/workspace/scratch",&v))return bad("guard-read");
 free_bytes=(uint64_t)v.f_bavail*(uint64_t)v.f_frsize;char *p=strstr(b,"VmRSS:"),*q=strstr(b,"VmHWM:");unsigned long long r=0,h=0;
 if(!p||!q||sscanf(p,"VmRSS: %llu kB",&r)!=1||sscanf(q,"VmHWM: %llu kB",&h)!=1)return bad("own-rss");
 rss=r*1024;hwm=h*1024;if(stopped)return bad("catchable-signal");if(m!=maximum)return bad("maximum-changed");if(head<RESERVE)return bad("reserve");
 if(current>=base&&current-base>WORK)return bad("aggregate-work");if(rss>WORK||hwm>WORK)return bad("own-rss-hwm");
 if(free_bytes<UINT64_C(1114112))return bad("disk-free");if(strcmp(events,e))return bad("memory-events");
 if(!wall||!mono||wall<wall0||mono<mono0||wall-wall0>UINT64_C(60000000000)||mono-mono0>UINT64_C(60000000000))return bad("whole60s");return 0;
}
static int parent_ok(struct stat s,Parent p){return S_ISDIR(s.st_mode)&&(uint64_t)s.st_dev==p.dev&&(uint64_t)s.st_ino==p.ino&&(uint64_t)s.st_mode==p.mode&&(uint64_t)s.st_uid==p.uid&&(uint64_t)s.st_gid==p.gid;}
static int leaf_ok(struct stat s,Archive *a){return S_ISREG(s.st_mode)&&(uint64_t)s.st_dev==a->dev&&(uint64_t)s.st_ino==a->ino&&s.st_mode==0100600&&s.st_uid==1000&&s.st_gid==1000&&s.st_nlink==1&&(uint64_t)s.st_size==TOTAL&&(uint64_t)s.st_blocks==a->blocks&&ns(s.st_atim)==UINT64_C(1790815508306217040)&&ns(s.st_mtim)==UINT64_C(1790815567573263991)&&ns(s.st_ctim)==a->ctime_ns;}
static int root_same(struct stat a,struct stat b){return a.st_dev==b.st_dev&&a.st_ino==b.st_ino&&a.st_mode==b.st_mode&&a.st_uid==b.st_uid&&a.st_gid==b.st_gid;}
static int observe(Archive *a){
 struct stat s,t;if(fstat(a->fd[0],&s)||lstat("/",&t)||!root_same(s,a->root)||!root_same(t,a->root))return bad("root-parent");
 for(int i=0;i<a->n;i++)if(fstat(a->fd[i+1],&s)||fstatat(a->fd[i],a->parents[i].name,&t,AT_SYMLINK_NOFOLLOW)||!parent_ok(s,a->parents[i])||!parent_ok(t,a->parents[i]))return bad("anchored-parent");
 const char *leaf=strrchr(a->path,'/')+1;if(fstat(a->fd[a->n+1],&s)||fstatat(a->fd[a->n],leaf,&t,AT_SYMLINK_NOFOLLOW)||!leaf_ok(s,a)||!leaf_ok(t,a)||flistxattr(a->fd[a->n+1],NULL,0)!=0)return bad("full-archive-metadata-xattrs");return 0;
}
static int open_archive(Archive *a){
 a->fd[0]=open("/",O_PATH|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);if(a->fd[0]<0||fstat(a->fd[0],&a->root))return bad("root-open");
 for(int i=0;i<a->n;i++){a->fd[i+1]=openat(a->fd[i],a->parents[i].name,O_PATH|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);if(a->fd[i+1]<0)return bad("parent-open");}
 a->fd[a->n+1]=openat(a->fd[a->n],strrchr(a->path,'/')+1,O_RDONLY|O_NOFOLLOW|O_NOATIME|O_NONBLOCK|O_CLOEXEC);if(a->fd[a->n+1]<0)return bad("archive-open");return observe(a);
}
static void close_archive(Archive *a){for(int i=a->n+1;i>=0;i--)if(a->fd[i]>=0){int fd=a->fd[i];a->fd[i]=-1;if(close(fd)){close_errors++;close_errno=errno;}}}
static int emit(const char *kind){
 int rc=printf("{\"kind\":\"%s\",\"reason\":\"%s\",\"errno\":%d,\"pid\":%ld,\"startTimeTicks\":%"PRIu64",\"ppid\":%ld,\"pgid\":%ld,\"sid\":%ld,\"bytesRead\":%"PRIu64",\"sha256\":\"%s\",\"advisedBytes\":%"PRIu64",\"adviceAttemptedRanges\":%"PRIu64",\"adviceReturnedRanges\":%"PRIu64",\"pendingRangeLength\":%"PRIu64",\"originalBodyBytesRead\":0,\"originalAdvisedBytes\":0,\"closeErrors\":%d,\"closeErrno\":%d,\"archiveAndAnchorFDsClosed\":%s,\"lastGuard\":{\"current\":%"PRIu64",\"maximum\":%"PRIu64",\"headroom\":%"PRIu64",\"baseline\":%"PRIu64",\"rss\":%"PRIu64",\"hwm\":%"PRIu64",\"free\":%"PRIu64",\"wallNs\":%"PRIu64",\"monotonicNs\":%"PRIu64"},\"samples\":%"PRIu64",\"minimumHeadroom\":%"PRIu64",\"maximumAggregateDelta\":%"PRIu64",\"retirementGranted\":false}\n",kind,reason,errnum,(long)getpid(),start_ticks,(long)getppid(),(long)getpgrp(),(long)getsid(0),bytes,hash,advised,attempted,returned,pending,close_errors,close_errno,all_closed?"true":"false",current,seen_max,head,base,rss,hwm,free_bytes,wall,mono,samples,min_head,max_delta);
 if(rc<0||fflush(stdout)||fsync(STDOUT_FILENO))return bad("receipt-write-fsync");return 0;
}
int main(int argc,char **argv){
 unsigned char buffer[65536],digest[EVP_MAX_MD_SIZE];unsigned int length=0;int status=1;struct rlimit limit={WORK,WORK};
 if(signal(SIGTERM,on_signal)==SIG_ERR||signal(SIGINT,on_signal)==SIG_ERR){bad("signal-handler");goto done;}
 if(proc_identity()||argc!=6||number(argv[1],&base)||number(argv[2],&maximum)||number(argv[3],&wall0)||number(argv[4],&mono0)||strcmp(argv[5],EVENTS)){bad("caller-arguments");goto done;}
 if(setrlimit(RLIMIT_DATA,&limit)||getuid()!=1000||geteuid()!=1000||text(EVENTS,events,sizeof events)){bad("caller-events-owner-limit");goto done;}
 if(maximum<base||maximum-base<WORK+RESERVE||guard()||emit("BEGIN"))goto done;
 if(open_archive(&original))goto done;if(lseek(original.fd[original.n+1],0,SEEK_CUR)!=0){bad("original-position");goto done;}if(open_archive(&target))goto done;
 ctx=EVP_MD_CTX_new();if(!ctx||EVP_DigestInit_ex(ctx,EVP_sha256(),NULL)!=1){bad("sha256-init");goto done;}
 for(;;){
  if(guard())goto done;ssize_t n=read(target.fd[target.n+1],buffer,sizeof buffer);if(n<0){bad("target-read");goto done;}if(!n)break;
  bytes+=(uint64_t)n;if(bytes>TOTAL||EVP_DigestUpdate(ctx,buffer,(size_t)n)!=1){bad("count-or-digest-update");goto done;}
  uint64_t end=bytes/RANGE*RANGE;if(end>advised){if(end-advised!=RANGE){bad("consumed-range-size");goto done;}if(observe(&target)||guard())goto done;pending=RANGE;attempted++;int rc=posix_fadvise(target.fd[target.n+1],(off_t)advised,(off_t)RANGE,POSIX_FADV_DONTNEED);if(rc){errno=rc;bad("target-advice");goto done;}returned++;advised=end;pending=0;}
 }
 if(bytes!=TOTAL||EVP_DigestFinal_ex(ctx,digest,&length)!=1||length!=32){bad("whole-count-or-digest");goto done;}
 for(unsigned int i=0;i<length;i++)snprintf(hash+i*2,3,"%02x",digest[i]);
 if(strcmp(hash,EXPECTED)||attempted!=885||returned!=885||advised!=UINT64_C(1855979520)||pending){bad("whole-hash-or-range-count");goto done;}
 if(observe(&target)||observe(&original)||lseek(original.fd[original.n+1],0,SEEK_CUR)!=0||guard())goto done;
 status=0;snprintf(reason,sizeof reason,"whole-new-copy-count-hash-match");
done:
 if(ctx)EVP_MD_CTX_free(ctx);close_archive(&target);close_archive(&original);
 all_closed=close_errors==0;
 if(close_errors){status=1;snprintf(reason,sizeof reason,"archive-anchor-close-return-error");}
 if(status==0&&guard())status=1;
 if(emit(status==0?"RESULT":"FAILURE"))status=1;return status;
}
