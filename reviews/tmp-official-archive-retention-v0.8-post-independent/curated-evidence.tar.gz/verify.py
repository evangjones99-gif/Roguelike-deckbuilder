import datetime,hashlib,json,os,stat
from pathlib import Path
OUT=Path(__file__).parent
ROOT=Path('/workspace/Roguelike-deckbuilder/reviews/root-v0.8-official-covered-tmp-retention')
OLD=Path('/workspace/scratch/tmp-official-archive-duplicates-independent-v08-r1')
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def meta(p,follow=False):
 s=p.stat() if follow else p.lstat()
 return {'type':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'link' if stat.S_ISLNK(s.st_mode) else 'other','bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'blocks':s.st_blocks,'xattrs':{n:os.getxattr(p,n,follow_symlinks=follow).hex() for n in sorted(os.listxattr(p,follow_symlinks=follow))}}
inputs=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [*[ROOT/n for n in ('retain.py','BEFORE.json','JOURNAL.jsonl','AFTER.json')],*[OLD/n for n in ('ELIGIBILITY.json','RESULTS.json','REVIEW.md','MANIFEST.json','READER-LIMIT-ADDENDUM.json','SUPPLEMENT-MANIFEST.json')]]]
assert sha(ROOT/'retain.py')=='792dd0b90c192ccbb82f2e9a9b85044d0b5ad606fb5b938fc10e971275331589'
assert sha(OLD/'SUPPLEMENT-MANIFEST.json')=='426be189895b3919981b0e965eb3c691f2cae9d4f245ad7aa235772daf87a2a0'
for r in json.loads((OLD/'SUPPLEMENT-MANIFEST.json').read_text())['files']:
 assert (OLD/r['path']).stat().st_size==r['bytes'] and sha(OLD/r['path'])==r['sha256']
b=json.loads((ROOT/'BEFORE.json').read_text());a=json.loads((ROOT/'AFTER.json').read_text());e=json.loads((OLD/'ELIGIBILITY.json').read_text())
assert b['eligibilitySHA256']==sha(OLD/'ELIGIBILITY.json')
stable=lambda m:{k:v for k,v in m.items() if k!='atime_ns'}
for key in ('tmpOriginal','officialRetained','tmpParent','officialParent'):
 assert b['before'][key]['path']==e[key]['path'] and stable(b['before'][key]['metadata'])==stable(e[key]['metadata'])
 if 'members' in e[key]:assert b['before'][key]['members']==e[key]['members']
s=Path(e['tmpOriginal']['path']);t=Path(e['officialRetained']['path']);expected=e['tmpOriginal']['sha256']
assert s.is_symlink() and os.readlink(s)==str(t) and s.resolve()==t and not t.is_symlink()
sm=meta(s);tm=meta(t);followed=meta(s,True)
assert stable(tm)==stable(b['before']['officialRetained']['metadata'])==stable(a['officialRetained'])
assert followed==tm and followed['type']=='file'
assert all(followed[k]==e['tmpOriginal']['metadata'][k] for k in ('bytes','mode','uid','gid','xattrs'))
assert sha(s)==sha(t)==expected==a['sourceSHA256']
assert expected=='256babeb74761b0608ae8be249f30f475522c70f86c0fd377f1bef737fb35fbe' and followed['bytes']==185715968 and followed['mode']=='0o600'
assert stable(meta(t))==stable(tm) and stable(meta(s))==stable(sm),'input changed during reads'
parents=[]
for key in ('tmpParent','officialParent'):
 row=b['before'][key];p=Path(row['path']);m=meta(p);assert sorted(str(q) for q in p.iterdir())==row['members']
 for k,v in row['metadata'].items():
  if k not in ('atime_ns','ctime_ns') or key=='officialParent' and k=='ctime_ns':assert m[k]==v,(key,k)
 parents.append({'key':key,'path':str(p),'current':m,'members':row['members'],'ctimeChanged':m['ctime_ns']!=row['metadata']['ctime_ns']})
j=[json.loads(v) for v in (ROOT/'JOURNAL.jsonl').read_text().splitlines()];assert len(j)==2
assert j[0]=={'phase':'ready','original':str(s),'temporaryAlias':str(s.parent/'.hollowpact-retained-0.7.0-original-alias'),'target':str(t)}
assert j[1]=={'phase':'replaced','linkTarget':str(t)}
assert not Path(j[0]['temporaryAlias']).exists() and not Path(j[0]['temporaryAlias']).is_symlink()
excluded=[]
for row in json.loads((OLD/'RESULTS.json').read_text())['completeSuffixArchiveInventory']:
 p=Path(row['path'])
 if p==s:continue
 actual=meta(p);old=row['metadataBeforeRead']
 for k,v in old.items():
  if k=='atime_ns':continue
  if k=='size':assert actual['bytes']==v
  elif k=='allocatedBytes':assert actual['blocks']*512==v
  else:assert actual[k]==v,(str(p),k)
 excluded.append({'path':str(p),'allOriginalStableMetadataUnchanged':True,'completeOldSHAProofAvailable':False})
ledger=t.parent/'SHA256SUMS';assert f'{expected}  {t.name}' in ledger.read_text().splitlines()
canonical=json.loads((OLD/'RESULTS.json').read_text())['allRegularFileSizeCandidates'][0]['matchingSealedArchives'][0]
assert canonical['ledgerPath']==str(ledger) and sha(ledger)==canonical['ledgerSHA256']
for r in inputs:assert sha(Path(r['path']))==r['sha256']
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'acceptedActualTransaction':True,'sourceInputs':inputs,'originalPath':str(s),'absoluteSymlinkTarget':str(t),'symlinkMetadata':sm,'officialAndFollowedMetadata':tm,'originalBytes':185715968,'wholeSHA256':expected,'officialFullBytesAndStableMetadataUnchanged':True,'allOriginalPathFollowedAccessMetadataPass':True,'bothParentOriginalMembershipIdentityModeOwnershipRestoredMtimePass':True,'parents':parents,'exactTwoJournalRecordsPass':True,'excludedSuffixArchivesStableMetadataChecks':excluded,'excludedCoverageQualification':'Every earlier inventoried excluded TMP suffix archive keeps its original stable metadata; original full SHA was not captured for unique/excluded inputs, so no invented full-byte audit of them. Exact helper mutation scope contains only the one named duplicate and TMPparent timestamp restoration. Unique trial bundle is outside archive scan and outside helper mutation scope.','readerWriterQualification':'Explicit parent coordination applied before root transaction. Previous incomplete FD inspection never establishes a global no-reader guarantee. Archives remain immutable by usage contract.','metadataChanges':'Original regular-file inode,type,nlink,ctime/mtime now represented by symlink; original metadata retained in immutable independent eligibility and root BEFORE. Followed metadata matches untouched official archive. TMPparentctime changes; reader atime may update.','rootObservedFreeDelta':a['observedFreeDelta'],'measuredOriginalAllocatedBytes':e['tmpOriginal']['metadata']['blocks']*512,'currentTMPFreeBytes':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'mutationsPerformedToReviewedInputs':False}
assert a['observedFreeDelta']==e['tmpOriginal']['metadata']['blocks']*512==185716736
(OUT/'RESULTS.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'acceptedActualTransaction':True,'originalBytes':185715968,'wholeSHA256':expected,'excludedSuffixArchiveMetadataCount':len(excluded),'rootObservedFreeDelta':a['observedFreeDelta']}))
