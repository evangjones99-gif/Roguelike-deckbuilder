import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const out='/workspace/scratch/hunter-independent-technical-v07-r3/evidence';
const fixtures=(JSON.parse(await fs.readFile('/workspace/scratch/hunter-v07/evidence/occupancy-fixtures-r5.json','utf8'))).fixtures;
const full=JSON.parse(await fs.readFile('/workspace/scratch/hunter-v07/evidence/fullhand-fixture.json','utf8'));
const URL='http://127.0.0.1:4190/?hunter=midgap&painted=1&lanes=reserved-adaptive&fit=wholecell';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const results=[];
async function contextFor(state,viewport={width:1280,height:720}){const context=await browser.newContext({viewport});await context.addInitScript(state=>{if(localStorage.getItem('hollowpact.run.v2')===null)localStorage.setItem('hollowpact.run.v2',JSON.stringify(state));localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion:true,mute:true,volume:0}));},state);const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));return{context,page,errors};}
try{
for(const viewport of [{width:1920,height:720},{width:1280,height:720},{width:390,height:844}]){
 const {context,page,errors}=await contextFor(full,viewport);await page.goto(URL);await page.locator('[data-ui=resume]').click();await page.waitForTimeout(250);
 const action={type:'play',index:0,target:full.enemies[0].uid};const expected=await page.evaluate(async({state,action})=>{const e=await import('/src/engine.ts');return e.applyActionWithEvents(state,action);},{state:full,action});
 await page.locator('[data-ui=play-card][data-index="0"]').click();await page.locator(`[data-unit="${action.target}"]`).click();
 const first=await page.evaluate(()=>({raw:localStorage.getItem('hollowpact.run.v2'),probe:document.querySelector('canvas').__hunterProbe()}));assert.equal(first.raw,JSON.stringify(expected.state));assert.ok(first.probe.hunter.cues.some(c=>c.kind==='ritual'));
 await page.waitForTimeout(1400);const last=await page.evaluate(()=>({raw:localStorage.getItem('hollowpact.run.v2'),probe:document.querySelector('canvas').__hunterProbe()}));assert.equal(last.raw,first.raw);assert.equal(last.probe.hunter.cues.length,0);await page.reload();await page.locator('[data-ui=resume]').click();const reload=await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2'));assert.equal(reload,first.raw);assert.deepEqual(errors,[]);
 results.push({kind:'actual-copied-host-tool',viewport,action,before:full,expected,first,last,reloadExact:true,errors});await context.close();
}
for(const [w,h] of [[390,220],[502,277],[758,277],[1398,277],[1398,328]]){
 const initial=fixtures[0].state;const {context,page,errors}=await contextFor(initial);await page.goto(URL);await page.locator('[data-ui=resume]').click();
 const result=await page.evaluate(async({fixtures,w,h,initial})=>{
  const {createArena}=await import('/src/arena.ts');const c=document.createElement('canvas');c.style.cssText=`width:${w}px;height:${h}px;position:fixed;left:0;top:0;z-index:99`;document.body.append(c);
  const ctx=c.getContext('2d'),original=ctx.drawImage;let draws=[];ctx.drawImage=function(image,...args){if(typeof image.src==='string'){let x,y,width,height;if(args.length===8){[x,y,width,height]=args.slice(4);}else if(args.length===4){[x,y,width,height]=args;}if(Number.isFinite(width)){const t=this.getTransform(),points=[[x,y],[x+width,y],[x,y+height],[x+width,y+height]].map(([x,y])=>({x:t.a*x+t.c*y+t.e,y:t.b*x+t.d*y+t.f}));draws.push({src:image.src,points});}}return original.call(this,image,...args);};
  const a=createArena(c);const rows=[];
  for(const f of fixtures.filter(f=>f.name.startsWith('legal-occupancy-'))){a.render(f.state);await new Promise(r=>setTimeout(r,390));draws=[];a.setSelected(null);const probe=c.__hunterProbe(),quads=draws;
   const expected=[...f.state.allies,...f.state.enemies].map(u=>u.uid).sort(),actual=probe.actors.filter(u=>u.dead===null).map(u=>u.uid).sort();rows.push({name:f.name,probe,quads,expected,actual,rawExact:localStorage.getItem('hollowpact.run.v2')===JSON.stringify(initial)});
  }
  a.cancelPresentation();a.render(fixtures.find(f=>f.name==='legal-death-start-3').state);await new Promise(r=>setTimeout(r,400));const before=c.__hunterProbe();
  for(const f of fixtures.filter(f=>f.name.startsWith('legal-death-turn-'))){a.render(f.state);await new Promise(r=>setTimeout(r,350));}
  a.cancelPresentation();const after=c.__hunterProbe();const slotsStable=after.actors.filter(u=>u.side==='ally'&&u.dead===null).every(u=>before.actors.find(v=>v.uid===u.uid)?.slot===u.slot);
  const rowsResult={dimensions:{w,h},rows,beforeDeath:before,afterDeath:after,slotsStable};a.dispose();c.remove();return rowsResult;
 },{fixtures,w,h,initial});
 for(const row of result.rows){assert.deepEqual(row.actual,row.expected);assert.equal(row.rawExact,true);for(const q of row.quads){assert.ok(q.points.every(p=>p.x>=-1e-7&&p.y>=-1e-7&&p.x<=w+1e-7&&p.y<=h+1e-7),JSON.stringify({w,h,name:row.name,q}));}}
 assert.equal(result.slotsStable,true);assert.deepEqual(errors,[]);results.push({kind:'actual-drawImage-and-stable-slots',...result,errors});await context.close();
}
await fs.writeFile(out+'/browser-primary-r3.json',JSON.stringify({scope:'Independent browser execution. Copied historical host UI, three actual tool/save/reload groups; isolated final renderer at five measured canvas sizes with real drawImage matrices, 35 legal occupancy states and actual saved attrition snapshots. Renderer fixtures are valid author-generated custom campaigns, not own earned campaigns. Research diagnostics only.',results},null,2)+'\n',{flag:'wx'});console.log({groups:results.length,hostActions:3,actualOccupancyDraws:35,allPass:true});
}catch(e){await fs.writeFile(out+'/browser-primary-r3-failure.json',JSON.stringify({error:e.stack,completed:results},null,2)+'\n',{flag:'wx'});throw e;}finally{await browser.close();}
