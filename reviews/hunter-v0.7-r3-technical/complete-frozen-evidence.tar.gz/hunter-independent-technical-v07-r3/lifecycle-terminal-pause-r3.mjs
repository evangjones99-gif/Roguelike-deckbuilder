import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const out='/workspace/scratch/hunter-independent-technical-v07-r3/evidence';const fixture=JSON.parse(await fs.readFile('/workspace/scratch/hunter-v07/evidence/fullhand-fixture.json','utf8'));
fixture.hp=1;fixture.block=0;
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const results=[];
try{for(const mode of ['host-pause']){
 const context=await browser.newContext({viewport:{width:1280,height:720}});let release;const hold=new Promise(r=>release=r),routes=[];
 if(['missing','late','dispose-late'].includes(mode))await context.route('**/hunter-sheet-r3.png',async route=>{if(mode==='missing')return route.abort();routes.push(route.request().url());await hold;try{await route.continue();}catch{}});
 if(mode==='no-canvas')await context.addInitScript(()=>{const old=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(kind,...args){return kind==='2d'?null:old.call(this,kind,...args);};});
 await context.addInitScript(s=>{localStorage.setItem('hollowpact.run.v2',JSON.stringify(s));localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion:true,mute:true,volume:0}));},fixture);
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:4190/?hunter=midgap&painted=1&lanes=reserved-adaptive&fit=wholecell',{waitUntil:'domcontentloaded'});await page.locator('[data-ui=resume]').click();
 if(['no-canvas','host-pause'].includes(mode)){
  const action={type:'endTurn'};const expected=await page.evaluate(async({fixture,action})=>(await import('/src/engine.ts')).applyActionWithEvents(fixture,action).state,{fixture,action});
  await page.locator('[data-action=endTurn]').click();await page.locator('[data-ui=confirm-end]').click();
  if(mode==='host-pause'){await page.keyboard.press('Escape');await page.locator('dialog[open]').waitFor();await page.locator('dialog[open] [data-ui=close]').first().click();}
  await page.waitForTimeout(150);const actual=await page.evaluate(()=>({raw:localStorage.getItem('hollowpact.run.v2'),notice:[...document.querySelectorAll('[role=status]')].map(n=>n.textContent),live:!!document.querySelector('[data-action=endTurn]:not(:disabled)'),probe:document.querySelector('canvas').__hunterProbe?.()}));assert.equal(actual.raw,JSON.stringify(expected));assert.equal(actual.live,false);if(mode==='no-canvas')assert.ok(actual.notice.some(x=>x.includes('unavailable')));if(mode==='host-pause')assert.equal(actual.probe.hunter.cues.length,0);results.push({mode,actual,expected,errors});
 }else{
  const a=await page.evaluate(async({mode,fixture})=>{
   const {createArena}=await import('/src/arena.ts'),e=await import('/src/engine.ts');const c=document.createElement('canvas');c.id='independent-lifecycle';c.style.cssText='position:fixed;left:0;top:0;width:700px;height:277px;z-index:99';document.body.append(c);const arena=createArena(c);window.__independentArena=arena;window.__independentCanvas=c;
   let before=structuredClone(fixture);if(mode==='static-defeat'){before.hp=1;before.block=0;before=e.applyActionWithEvents(before,{type:'endTurn'}).state;if(before.phase!=='defeat')throw Error('fixture not lethal');}
   arena.render(before);await new Promise(r=>setTimeout(r,130));let after=before;let waitResolved=false;
   if(!['static-defeat','missing'].includes(mode)){const action={type:'play',index:0,target:before.enemies[0].uid},r=e.applyActionWithEvents(before,action);after=r.state;arena.playAction(action,before,after,r.events);arena.waitForPresentation().then(()=>waitResolved=true);}
   const pre=c.__hunterProbe();
   if(mode==='cancel')arena.cancelPresentation();if(mode==='dispose-late')arena.dispose();if(mode==='reduced-midflight')document.documentElement.dataset.reducedMotion='true';
   if(mode==='emulated-hidden'){Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));}
   if(mode==='resize'){c.style.width='650px';arena.resize();}
   await new Promise(r=>setTimeout(r,30));return{pre,post:c.__hunterProbe(),waitResolved,busy:arena.busyMs(),raw:localStorage.getItem('hollowpact.run.v2'),valid:e.validateState(after),after,notice:[...document.querySelectorAll('[role=status]')].map(n=>n.textContent)};
  },{mode,fixture});assert.equal(a.raw,JSON.stringify(fixture));assert.equal(a.valid,true);
  if(['cancel','dispose-late','reduced-midflight','emulated-hidden','resize'].includes(mode)){assert.equal(a.waitResolved,true);assert.equal(a.busy,0);if(mode!=='dispose-late')assert.equal(a.post.hunter.cues.length,0);}
  if(mode==='static-defeat')assert.equal(a.post.hunter.pose,'death');
  if(mode==='late'||mode==='dispose-late'){release();await page.waitForTimeout(300);a.loaded=await page.evaluate(()=>{const c=window.__independentCanvas,a=window.__independentArena;return{probe:c.__hunterProbe(),busy:a.busyMs(),raw:localStorage.getItem('hollowpact.run.v2')};});assert.equal(a.loaded.raw,a.raw);if(mode==='dispose-late')assert.equal(a.loaded.busy,0);}
  await page.evaluate(()=>{window.__independentArena.dispose();window.__independentCanvas.remove();});results.push({mode,result:a,errors,routes});
 }
 assert.deepEqual(errors,[]);release();await context.close();
}await fs.writeFile(out+'/lifecycle-terminal-pause-r3.json',JSON.stringify({scope:'Independent actual copied-host no-Canvas action/save and Escape pause, plus isolated final renderer lifecycle at700x277. Native browser loaded/delayed/aborted HTTP sheet, dispose-before-load, resize/reduced/cancel/static reducer defeat. Visibility deliberately property-emulated, no physical OS/tab claim. Local audit objects are scratch-only.',results},null,2)+'\n',{flag:'wx'});console.log({cases:results.length,allPass:true});
}catch(e){await fs.writeFile(out+'/lifecycle-terminal-pause-r3-failure.json',JSON.stringify({error:e.stack,completed:results},null,2)+'\n',{flag:'wx'});throw e;}finally{await browser.close();}
