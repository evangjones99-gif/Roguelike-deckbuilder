import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import {createGame,applyAction,applyActionWithEvents,legalActions,validateState} from '/tmp/hollowpact-relic-bone-v09-root-r1/src/engine.ts';
import {ENEMIES,CARDS,RELICS} from '/tmp/hollowpact-relic-bone-v09-root-r1/src/content.ts';
import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const O='/workspace/scratch/combined-relic-bone-gameplay-independent-v09-r1',H=(b:any)=>crypto.createHash('sha256').update(b).digest('hex'),rows:any[]=JSON.parse(fs.readFileSync(O+'/FAILURE-r4.json','utf8')).completed,ids=Object.keys(RELICS);
function fixture(kind:1|2){
 let s=createGame(21188,1,{engineKind:kind});s.relics=ids.slice();s=applyAction(s,{type:'travel',choice:'battle'});
 const d=ENEMIES.acolyte;s.enemies=[{...d,uid:'e'+s.nextUid++,cardId:'acolyte',maxHp:d.hp,hp:d.hp,block:0,acted:false,intent:{damage:0,target:'hunter',label:'Raise 1 Bone Thrall',summon:['thrall']}}];assert(validateState(s));return s;
}
function terminal(kind:1|2){
 let s=fixture(kind);s=applyAction(s,{type:'endTurn'});s=applyAction(s,{type:'endTurn'});const summon=legalActions(s).find(a=>a.type==='play'&&CARDS[s.hand[a.index]].type==='summon');assert(summon,'Diagnostic seed must have legal binding');s=applyAction(s,summon);
 const thrall=s.enemies.find(e=>e.cardId==='thrall')!;assert(thrall);s.enemies=[thrall];thrall.hp=1;const ally=s.allies.find(u=>!u.acted)!;assert(ally);ally.attack=20;assert(validateState(s));const action={type:'attack' as const,unit:ally.uid,target:thrall.uid};assert(legalActions(s).some(a=>JSON.stringify(a)===JSON.stringify(action)));return {s,action};
}
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
async function run(kind:1|2,variant:string,mode:string,fault=''){
 const width=kind===1?390:1280,t=terminal(kind),initial=mode==='terminal'?t.s:mode==='reward'?applyAction(t.s,t.action):mode==='map'?(()=>{const s=createGame(21188,1,{engineKind:kind});s.relics=ids.slice();return s;})():fixture(kind);assert(validateState(initial));
 const ctx=await browser.newContext({viewport:{width,height:844},reducedMotion:mode==='terminal'?'no-preference':'reduce'}),page=await ctx.newPage(),errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await ctx.addInitScript(({save,motion,fault})=>{
  if(!localStorage.getItem('reviewInitialized')){localStorage.setItem('reviewInitialized','yes');localStorage.setItem('hollowpact.run.v2',save);localStorage.setItem('hollowpact.settings.v2',JSON.stringify({mute:true,motion,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');}
  const w=window as any;w.__combinedDraws=[];const old=CanvasRenderingContext2D.prototype.drawImage;CanvasRenderingContext2D.prototype.drawImage=function(image:any,...a:any[]){if(this.canvas.id==='arena'&&image instanceof HTMLImageElement&&w.__combinedDraws.length<600)w.__combinedDraws.push({url:image.src,dimensions:[image.naturalWidth,image.naturalHeight]});return old.call(this,image,...a as any);};
  if(fault==='no-canvas'){const oldGet=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(...a:any[]){return this.id==='arena'?null:oldGet.apply(this,a as any); } as any;}
 },{save:JSON.stringify(initial),motion:mode==='terminal',fault});
 if(fault==='missing')await page.route('**/art/bone-thrall-v09-r1.png',route=>route.abort());
 await page.goto('http://127.0.0.1:'+(variant==='candidate'?4605:4610)+'/');await page.locator('[data-ui="resume"]').click();
 let state=initial;const row:any={kind,width,variant,mode,fault,diagnosticFixture:true,actions:[],checks:[]};
 async function snap(label:string){const raw=await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2'));assert.equal(raw,JSON.stringify(state));assert(validateState(JSON.parse(raw!)));row.checks.push({label,saveSHA256:H(raw!),storage:await page.evaluate(()=>JSON.stringify({...localStorage}))});}
 await snap('initial');
 if(mode==='spawn'){
  for(let turn=0;turn<2;turn++){const action={type:'endTurn' as const};assert(legalActions(state).some(a=>a.type==='endTurn'));const result=applyActionWithEvents(state,action);await page.locator('[data-action="endTurn"]').click();state=result.state;await page.waitForTimeout(100);row.actions.push({action,events:result.events,state});await snap('end-turn-'+turn);}
  const thrall=state.enemies.find(u=>u.cardId==='thrall')!;assert(thrall);const before=await page.evaluate(()=>JSON.stringify({...localStorage}));await page.locator(`[data-ui="inspect-unit"][data-uid="${thrall.uid}"]`).click();await page.getByRole('dialog').waitFor();
  const body=await page.locator('dialog[open]').innerText();assert(body.includes(thrall.name)&&body.includes(ENEMIES.thrall.passive!));const portrait=page.locator('dialog .portrait');assert(await portrait.count());row.dossier={text:body,background:await portrait.evaluate(n=>getComputedStyle(n).backgroundImage),focal:await page.locator('dialog .portrait-frame').evaluate(n=>({x:n.style.getPropertyValue('--portrait-x'),y:n.style.getPropertyValue('--portrait-y')}))};
  if(variant==='candidate'){assert(row.dossier.background.includes('bone-thrall-v09-r1.png'));assert.deepEqual(row.dossier.focal,{x:'65%',y:'13%'});}
  if(kind===1)await page.screenshot({path:O+`/${variant}-spawn-${fault||'normal'}-dossier-r5.jpg`,type:'jpeg',quality:80});await page.keyboard.press('Escape');assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),before);
  row.draws=await page.evaluate(()=>(window as any).__combinedDraws);
  if(variant==='candidate'&&!fault)assert(row.draws.some((d:any)=>d.url.includes('bone-thrall-v09-r1.png')&&d.dimensions[0]===1254));
  if(fault==='missing')assert(!row.draws.some((d:any)=>d.url.includes('bone-thrall-v09-r1.png')));
  if(fault==='no-canvas'){assert(await page.locator('#arena-wrap .arena-fallback[role="status"]').isVisible());assert(await page.locator('#arena').evaluate(n=>(n as HTMLCanvasElement).hidden));row.canvasFallbackNotice=await page.locator('#arena-wrap .arena-fallback[role="status"]').innerText();}
 }
 if(mode==='terminal'){
  await page.evaluate("window.__heldReadouts=[];const take=()=>{if(document.querySelector('#app.settling-combat')&&window.__heldReadouts.length<128)window.__heldReadouts.push({at:performance.now(),busy:document.querySelector('#scene-ui').getAttribute('aria-busy'),units:Array.from(document.querySelectorAll('.unit[data-unit]')).map(n=>({uid:n.getAttribute('data-unit'),aria:n.getAttribute('aria-label'),stats:n.querySelector('.unit-stats')?.textContent,status:n.querySelector('.unit-status')?.textContent,health:n.querySelector('.health-track i')?.style.width})),hunter:document.querySelector('.hunter-icon')?.getAttribute('aria-label')});};window.__readoutObserver=new MutationObserver(take);window.__readoutObserver.observe(document.documentElement,{subtree:true,childList:true,attributes:true});");
  const result=applyActionWithEvents(state,t.action);await page.locator(`[data-unit="${t.action.unit}"]`).click();await page.locator(`[data-unit="${t.action.target}"]`).click();state=result.state;await snap('immediate-canonical-kill');await page.locator('.reward-panel').waitFor();row.actions.push({action:t.action,events:result.events,state});
  row.held=await page.evaluate(()=>{(window as any).__readoutObserver.disconnect();return (window as any).__heldReadouts;});assert(row.held.length>0,'Real final-kill hold must be observed');const dead=row.held.flatMap((r:any)=>r.units).filter((u:any)=>u.uid===t.action.target);assert(dead.length);for(const u of dead){assert(u.aria.includes('0 of '+t.s.enemies[0].maxHp+' health'));assert.equal(u.status,'Quarry down');assert.equal(u.health,'0%');}assert(row.held.some((r:any)=>r.busy==='true'));await snap('settled-kill');
 }
 if(mode==='reward'||mode==='map'||mode==='terminal'){
  const storage=await page.evaluate(()=>JSON.stringify({...localStorage}));
  if(variant==='candidate'){
   assert.equal(await page.locator('.relic-strip > span').textContent(),'Inspect relic effects');assert.equal(await page.locator('.relic-strip [data-ui="relic"]').count(),6);
   const id='grave-coin',button=page.locator(`[data-focus="relic-${id}"]`);await button.focus();await page.keyboard.press('Enter');await page.getByRole('dialog',{name:RELICS[id].name,exact:true}).waitFor();assert.equal(await page.locator('.dossier-rule p').textContent(),RELICS[id].text);await page.keyboard.press('Escape');assert(await button.evaluate(n=>n===document.activeElement));assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),storage);row.relicEffectAndFocusExact=true;
   await button.evaluate(n=>n.setAttribute('data-relic','toString'));await button.click();assert.equal(await page.locator('dialog[open]').count(),0);assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),storage);await button.evaluate(n=>n.setAttribute('data-relic','grave-coin'));row.relicPrototypeGuard=true;
   if(mode==='reward'&&kind===1){await page.locator('.relic-strip').scrollIntoViewIfNeeded();await page.screenshot({path:O+'/candidate-mobile-reward-r3.jpg',type:'jpeg',quality:80});}
   if(mode==='reward'){
    await page.evaluate("window.__reviewPad={index:0,connected:true,mapping:'standard',axes:[0,0],buttons:Array.from({length:17},()=>({pressed:false,value:0}))};Object.defineProperty(navigator,'getGamepads',{configurable:true,value:()=>[window.__reviewPad]});window.dispatchEvent(new Event('focus'));window.dispatchEvent(new Event('gamepadconnected'));");await page.waitForTimeout(100);const origin=page.locator('[data-relic="war-brand"]');await origin.focus();
    async function edge(i:number){await page.evaluate(i=>{(window as any).__reviewPad.buttons[i]={pressed:true,value:1};},i);await page.waitForTimeout(80);await page.evaluate(i=>{(window as any).__reviewPad.buttons[i]={pressed:false,value:0};},i);await page.waitForTimeout(80);}
    await edge(0);await page.getByRole('dialog',{name:RELICS['war-brand'].name,exact:true}).waitFor();await edge(1);assert(await origin.evaluate(n=>n===document.activeElement));assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),storage);row.syntheticPadABExact=true;
   }
  }else assert.equal(await page.locator('[data-ui="relic"]').count(),0);
  const main=page.locator(mode==='map'?'.route-card':'[data-action="reward"][data-card=""]').first();assert(await main.isEnabled());await main.scrollIntoViewIfNeeded();
 }
 row.horizontalOverflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert.equal(row.horizontalOverflow,false);await page.reload();await page.locator('[data-ui="resume"]').click();await snap('reload');assert.deepEqual(errors,[]);row.errors=errors;rows.push(row);await ctx.close();fs.writeFileSync(O+'/CHECKPOINT-r5.json',JSON.stringify({completed:rows.length,last:{kind,variant,mode,fault}},null,2)+'\n');
}
try{
 for(const fault of ['missing','no-canvas'])await run(2,'candidate','spawn',fault);
 const pairs=[];for(const kind of [1,2])for(const mode of ['spawn','terminal','reward']){const a=rows.find(r=>r.kind===kind&&r.mode===mode&&r.variant==='baseline'),b=rows.find(r=>r.kind===kind&&r.mode===mode&&r.variant==='candidate');assert.deepEqual(a.actions,b.actions);assert.deepEqual(a.checks.map((r:any)=>r.saveSHA256),b.checks.map((r:any)=>r.saveSHA256));pairs.push({kind,mode,fullCanonicalActionsAndEventsExact:true,saveCheckpointsExact:true});}
 fs.writeFileSync(O+'/RESULTS.json',JSON.stringify({scope:'Fresh actual merged-build browser QA; validator-valid unearned diagnostic fixtures, muted/software Chromium, no human/native/AAA/hardware claim.',contexts:rows.length,pairs,rows},null,2)+'\n');
}catch(e){fs.writeFileSync(O+'/FAILURE-r5.json',JSON.stringify({error:String(e),stack:(e as Error).stack,completed:rows},null,2)+'\n');throw e;}finally{await browser.close();}
