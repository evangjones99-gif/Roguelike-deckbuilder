from pathlib import Path
import json,hashlib,urllib.request,sys
O=Path('/workspace/scratch/combined-relic-bone-gameplay-independent-v09-r1');H=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for label,stage,port,digest,count,outCount in [('baseline',Path('/tmp/hollowpact-final-kill-v09-root-r1'),4610,'8a33f950ed57093a222baf9b7883a5c1ccf2deb2e8412429ef0fe05d370467cb',77,55),('candidate',Path('/tmp/hollowpact-relic-bone-v09-root-r1'),4605,'4bfa417ad790dd88a18868e10e7574666ae8bfc3187bdab1df4947c31231de61',78,56)]:
 p=json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/build-provenance.json'));assert p['sourceDigest']==digest and len(p['hashes'])==count
 assert H(json.dumps(p['hashes'],separators=(',',':')).encode())==digest
 for f,h in p['hashes'].items():assert H((stage/f).read_bytes())==h,f
 outputs={}
 for f in sorted((stage/'dist').rglob('*')):
  if f.is_file():
   name=f.relative_to(stage/'dist').as_posix();b=f.read_bytes();assert urllib.request.urlopen(f'http://127.0.0.1:{port}/{name}').read()==b,name;outputs[name]={'bytes':len(b),'sha256':H(b)}
 assert len(outputs)==outCount
 rows.append({'label':label,'stage':str(stage),'port':port,'provenance':p,'outputs':outputs})
changed=[f for f,h in rows[0]['provenance']['hashes'].items() if rows[1]['provenance']['hashes'][f]!=h]
added=list(set(rows[1]['provenance']['hashes'])-set(rows[0]['provenance']['hashes']));assert set(changed)=={'src/main.ts','src/art.ts','THIRD-PARTY.md','public/art/PROVENANCE.json'} and added==['public/art/bone-thrall-v09-r1.png']
for f in ('src/engine.ts','src/content.ts','src/input.ts','src/arena.ts','src/style.css'):assert rows[0]['provenance']['hashes'][f]==rows[1]['provenance']['hashes'][f]
(O/(sys.argv[1]+'-identity.json')).write_text(json.dumps({'scope':'Exact combined before/after actual source and complete local/HTTP outputs; no source writes or native execution','changed':changed,'added':added,'rows':rows},indent=2)+'\n')
print('Verified77/78 source bodies and55/56 complete HTTP output bodies: '+sys.argv[1])
