// Isolated local art lab. No dependency install, game import, arbitrary file route or telemetry.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const allowed = new Set(['index.html','styles.css','lab.js','timeline.js','sprites.js','assets/hunter-sheet.png','assets/hound-sheet.png','assets/skeleton-sheet.png']);
const types = { '.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png' };
const server = http.createServer((request,response) => {
  if (!['GET','HEAD'].includes(request.method)) { response.writeHead(405);response.end();return; }
  let relative;
  try { const p=decodeURIComponent(new URL(request.url,'http://localhost').pathname);relative=p==='/'?'index.html':p.slice(1); }
  catch {response.writeHead(400);response.end();return;}
  if (!allowed.has(relative)) {response.writeHead(404);response.end();return;}
  const file=path.join(root,relative);
  try {
    if (!fs.lstatSync(file).isFile() || fs.lstatSync(file).isSymbolicLink()) throw Error('Nonregular lab file');
    response.writeHead(200,{'Content-Type':types[path.extname(file)],'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    if(request.method==='HEAD'){response.end();return;}
    const stream=fs.createReadStream(file,{highWaterMark:32768});stream.on('error',()=>response.destroy());response.on('close',()=>stream.destroy());stream.pipe(response);
  }catch{response.writeHead(500);response.end();}
});
server.maxConnections=8;
server.on('error',error=>{console.error(error.message);process.exitCode=1;});
server.listen(5176,'127.0.0.1',()=>console.log('ART / ANIMATION RESEARCH ONLY · http://127.0.0.1:5176 · Ctrl+C stops server. No game/save integration.'));
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{server.close(()=>process.exit(0));const stop=setTimeout(()=>{server.closeAllConnections();process.exit(0);},3000);stop.unref();});
