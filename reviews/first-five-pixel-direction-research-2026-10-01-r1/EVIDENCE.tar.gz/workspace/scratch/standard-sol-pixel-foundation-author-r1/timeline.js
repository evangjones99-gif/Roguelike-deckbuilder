/** Presentation-only art demo. No reducer, HP, intent, save or legal action. */
export const ATTACK_PHASES = Object.freeze([
  { pose: 'anticipate0', duration: 100 }, { pose: 'anticipate1', duration: 80 },
  { pose: 'attack0', duration: 40 }, { pose: 'attack1', duration: 20 },
  { pose: 'contact', duration: 40 }, { pose: 'recover0', duration: 90 },
  { pose: 'recover1', duration: 110 },
]);
export const CONTACT_MS = 240;
export const END_MS = 760;
function attackPose(elapsed) {
  let end = 0;
  for (const phase of ATTACK_PHASES) { end += phase.duration; if (elapsed < end) return phase.pose; }
  return 'idle0';
}
function victimPose(elapsed) {
  if (elapsed < CONTACT_MS) return 'idle0';
  if (elapsed < 320) return 'hit0';
  if (elapsed < 400) return 'hit1';
  if (elapsed < 560) return 'death0';
  if (elapsed < END_MS) return 'death1';
  return 'death2';
}

/** The host owns one RAF. These synchronous callbacks may cancel/restart/dispose. */
export function createTimeline({ onFrame = () => {}, onContact = () => {}, onComplete = () => {} } = {}) {
  let run = null, revision = 0, disposed = false;
  let state = Object.freeze({ sequence: 0, actorPose: 'idle0', victimPose: 'idle0', phase: 'idle', elapsed: 0, contacts: 0, active: false });
  function publish(next) { state = Object.freeze(next); onFrame(state); }
  function valid(captured) { return !disposed && run === captured && revision === captured.revision; }
  function start(now, { reduced = false } = {}) {
    if (disposed) return false;
    if (!Number.isFinite(now)) throw Error('Finite presentation clock required');
    const captured = { revision: ++revision, started: now, elapsed: 0, contacts: 0, contactDelivered: false };
    run = captured;
    if (reduced) {
      run = null;
      publish({ sequence: captured.revision, actorPose: 'idle0', victimPose: 'death2', phase: 'static result', elapsed: END_MS, contacts: 0, active: false });
      if (!disposed && revision === captured.revision) onComplete({ sequence: captured.revision, reduced: true, contacts: 0 });
      return true;
    }
    publish({ sequence: captured.revision, actorPose: 'anticipate0', victimPose: 'idle0', phase: 'anticipate', elapsed: 0, contacts: 0, active: true });
    return true;
  }
  function advance(now) {
    const captured = run; if (!captured || disposed) return state;
    if (!Number.isFinite(now)) throw Error('Finite presentation clock required');
    captured.elapsed = Math.max(captured.elapsed, now - captured.started, 0);
    const elapsed = captured.elapsed;
    if (!captured.contactDelivered && elapsed >= CONTACT_MS) {
      // A delayed RAF first displays the literal contact pair for one sample.
      // It does not skip the pose and emit a decorative/late unrelated trail.
      captured.contactDelivered = true; captured.contacts = 1;
      publish({ sequence: captured.revision, actorPose: 'contact', victimPose: 'hit0', phase: 'contact', elapsed, contacts: 1, active: true });
      if (!valid(captured)) return state;
      onContact(Object.freeze({ sequence: captured.revision, scheduledMs: CONTACT_MS, observedElapsedMs: elapsed,
        lateByMs: Math.max(0, elapsed - CONTACT_MS), research: true }));
      return state; // restart/cancel/dispose from callback cannot advance an old run
    }
    if (elapsed >= END_MS) {
      run = null;
      publish({ sequence: captured.revision, actorPose: 'idle0', victimPose: 'death2', phase: 'complete', elapsed, contacts: captured.contacts, active: false });
      if (!disposed && revision === captured.revision) onComplete({ sequence: captured.revision, reduced: false, contacts: captured.contacts });
      return state;
    }
    const pose = attackPose(elapsed);
    publish({ sequence: captured.revision, actorPose: pose, victimPose: victimPose(elapsed), phase: pose.replace(/[0-9]/g, ''), elapsed, contacts: captured.contacts, active: true });
    return state;
  }
  function cancel(reason = 'cancelled') {
    if (disposed) return;
    const contacts = state.contacts, sequence = state.sequence; ++revision; run = null;
    publish({ sequence, actorPose: 'idle0', victimPose: 'idle0', phase: reason, elapsed: 0, contacts, active: false });
  }
  function settleStatic(reason = 'static result') {
    if (disposed) return;
    const contacts = state.contacts, sequence = state.sequence; ++revision; run = null;
    publish({ sequence, actorPose: 'idle0', victimPose: 'death2', phase: reason, elapsed: END_MS, contacts, active: false });
  }
  function dispose() { if (disposed) return; revision++; run = null; disposed = true; }
  return Object.freeze({ start, advance, cancel, settleStatic, dispose, getState: () => state, isActive: () => !!run, isDisposed: () => disposed });
}
