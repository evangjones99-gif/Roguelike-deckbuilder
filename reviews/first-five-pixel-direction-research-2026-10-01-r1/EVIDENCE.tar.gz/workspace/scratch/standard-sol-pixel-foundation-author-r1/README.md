# Original pixel foundation — first art slice

**ART / ANIMATION RESEARCH ONLY.** Three original indexed sprite sets and a small local lab support a future opening-slice trial. This is not the game, a replacement runtime, a fun test, or accepted visual quality. The owner's current aim is the **first five minutes of fun**, with handcrafted pixel-art feel while retaining JavaScript/TypeScript and tested rules/saves/tactile cards. This packet changes none of those runtime files.

The sources are readable JavaScript, HTML and CSS with no dependency install, framework or game build. Once Root grants an exclusive runtime window and independently reviews this exact freeze, run:

```sh
node /absolute/path/to/this/packet/serve.mjs
```

Open `http://127.0.0.1:5176`. Any normal static server can also serve this folder. No remote fetch, telemetry, localStorage or game import is present. Node/browser execution has **not** been performed by this author. The server only exposes eight lab/art files, never the workspace/repository. Ctrl+C stops it; sources remain. Port, HTTP behavior and stop/cleanup still need actual verification.

Use **Play strike + collapse**, switch attacker, inspect the source poses, then try **Esc**, **Cancel**, **Reduce motion**, hiding the tab and **Dispose lab**. Native buttons, selects and checkboxes keep their browser keyboard behavior. Dispose removes the lab's RAF and registered listeners, preserving a static view; reload restarts. Readable labels and observation counts stay live HTML, not sprite text. The initial art sequence always demonstrates a victim collapse; it is explicitly synthetic, not a conclusion about actual damage or rules.

## What was authored

One shared14-entry indexed palette includes fully transparent index0. Original hand-positioned low-resolution masks and pixel-cluster recipes define a crimson-cloaked contract hunter with an iron hook, a lean horizontal pact hound with a horned jaw, and a tall skeletal adversary with a broken helm. A restrained original16×16 slate-stone tile supplies the backdrop. No earlier painted art, screenshot, proprietary reference, filter or downsample is used.

Each actor uses a fixed64×48 source cell, with14 genuinely different indexed drawings: two idle, two anticipate, two attack, contact, two recovery, two hit, three death. Supported legs, compressed hips/shoulders, extended weapon/jaw, retraction and collapsed anatomy change in the source pixels; there are no whole-body translate/scale-only attack frames or alpha crossfades. Mirroring reflects both indexed pixels and anchor x coordinates; asymmetric equipment stays the same authored equipment.

The earlier32×40 hunter/40×28 hound/28×40 skeleton sketch references are recorded as `anatomyReference`, not enforced clip dimensions or claimed opaque bounds. Tails, horns, weapon extensions and fallen poses occupy the larger fixed union cell. Exact `frameBounds` and `unionBounds` come from opaque indices and are inspectable. These bounds are art metadata, not game hitboxes or legal target ownership.

`author-assets.py` is the one-off inspectable original asset author/export source. `sprites.js` contains all indexed masks, palette, frame order and geometry. The three `assets/*-sheet.png` files are original transparent **indexed PNG** sheets,256×192, four64×48 columns; unused last cells stay transparent. They were generated with a small standard-library PNG writer from these indices. There is no image input or high-resolution intermediate. The lab draws1×1 source pixels at integer positions and displays the whole scene and actor canvases at one common2×/3×/4× CSS scale with nearest-neighbor rendering. Fractional device-pixel-ratio appearance still needs actual inspection; a CSS scale is not universal physical-pixel proof.

The author personally inspected the three native sheet exports. That confirms what the source sheets look like, not the3× browser composition, motion quality, game integration or independent acceptance. The very lean hound and flattened late-death silhouettes are deliberate first sketches and may be rejected or need further anatomy work. No handcrafted-human authorship or professional artist approval is claimed.

## Contact and lifecycle contract

The source foot plane is y44. Hunter/skeleton contact is `(63,25)`; hound contact is `(63,33)`. The stage positions a mirrored target so its chest or knee anchor is **the same source-space world point**, with integer arithmetic. The contact drawing reaches that point, the target's hit drawing contains it, and the single-pixel impact is painted there. There is no decorative trail used as a substitute for touching the target.

The attack phases total480ms; contact is authored at240ms; the hit/collapse demonstration settles at760ms. The host owns one RAF, including quiet two-frame idle loops. `timeline.js` has no timer, reducer or global listener. A large clock jump first publishes the contact pair for one sample and emits at most one contact callback, then a later sample settles to the final static result. Observation records distinguish scheduled240ms from actual sampled elapsed time. This does not prove first browser paint, audio alignment or a real game strike deadline.

Sequence/revision checks stop synchronous callback reentrancy from advancing or completing an old run after cancellation/restart/disposal. New reduced-motion plays show a static final result and emit no timed contact. Switching to reduced motion or hiding the page settles an active demonstration, stops the RAF and emits no stale future contact. Cancellation resets to the idle pair while preserving the observed count for that cancelled sequence. Disposal invalidates the timeline, cancels the RAF, unregisters the lab's listeners and disables its controls. These are source contracts; actual browser behavior is still pending.

## Eventual engine-backed opening trial

The author inspected the full current `src/arena.ts` and `src/engine.ts` bytes and their relevant renderer/event interfaces. Existing `createArena` exposes `render(state)`, `playAction(action,before,after,events)`, presentation waiting/cancellation and disposal. `TransitionEvent` is an ordered observation of an **actual accepted resolution**, never saved or used for rules. Real `hit` records contain source/target UID, kind, damage, blocked, hpLost and before/after HP; `death` is a separate actual event; `summon` contains source/target UID, canonical unit and side. The current source uses a240ms contact offset and preserves canonical state independently of optional presentation.

A later adapter should select these sprites by species while retaining canonical UID, live rules/saves, legal targeting authority, final readouts, held corpse/birth identities and existing tactile input. Attack/hit/death must be driven by actual accepted events: no invented intent attacks, no death from every hit, and no gameplay mutation from `onContact`. The lab's unconditional synthetic collapse is **not** an engine adapter. Contact/audio must share the real action allocation anchor; body/attack/readout geometry must use the same published formation and art metadata, not transparent atlas-cell rectangles. Alpha masks and these art bounds alone cannot prove swept geometry or disjoint controls.

This first freeze intentionally stops before integration. Root owns the later original-pixel opening slice through the existing arena boundary and pacing/first-binding/strike/terminal-payoff changes. Keep the retained runtime and launcher untouched until actual independent comparisons prefer a verified successor. Actual opening-session comparisons, visual quality at integer scale, silhouette/contact motion, accessible input/cleanup and the first300 seconds of play are still needed. The current lab is no evidence of enjoyment, AAA polish, full-roster readiness, native/Steam qualification or retirement eligibility.
