"""One-shot bounded source freeze, not JavaScript/browser execution."""
import os, pathlib, hashlib, json, time, stat

ROOT = pathlib.Path(__file__).resolve().parent
WORK = 24 * 1024 * 1024
RESERVE = 512 * 1024 * 1024
CGROUP = pathlib.Path('/sys/fs/cgroup')
def memory():
    current = int((CGROUP / 'memory.current').read_text())
    maximum = int((CGROUP / 'memory.max').read_text())
    return current, maximum
initial, maximum = memory()
if maximum - initial < WORK + RESERVE:
    raise SystemExit('Fresh 24 MiB work + 512 MiB reserve admission refused')
def guard():
    current, ceiling = memory()
    status = pathlib.Path('/proc/self/status').read_text()
    rss_hwm = int(next(line.split()[1] for line in status.splitlines() if line.startswith('VmHWM:'))) * 1024
    spent = max(0, current - initial)
    if ceiling != maximum or rss_hwm > WORK or spent > WORK or ceiling - current < RESERVE + max(0, WORK-spent):
        raise RuntimeError(f'Source seal budget exceeded: initial={initial}, current={current}, maximum={ceiling}, shared_delta={spent}, RSS_HWM={rss_hwm}, work={WORK}, reserve={RESERVE}')
    return current, rss_hwm
def pin(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOATIME | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode): raise RuntimeError('Nonregular source')
        digest = hashlib.sha256()
        while True:
            chunk = os.read(fd, 32768)
            if not chunk: break
            digest.update(chunk); guard()
        after = os.fstat(fd)
        fields = ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_atime_ns')
        if any(getattr(before,k) != getattr(after,k) for k in fields): raise RuntimeError('Source changed while pinned')
        return {'bytes': before.st_size, 'sha256': digest.hexdigest()}
    finally: os.close(fd)
def write(name, data):
    target = ROOT / name
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd,'w') as file: json.dump(data,file,indent=2); file.write('\n')
sources = {p:pin('/workspace/Roguelike-deckbuilder/'+p) for p in ['AGENTS.md','src/arena.ts','src/engine.ts','src/art.ts']}
write('SOURCE-PINS.json', {'scope':'Inspected interfaces only; these live source files were not edited or copied into the lab.', 'root': '/workspace/Roguelike-deckbuilder', 'files':sources,
 'owner_direction':'Original pixel opening slice; first five minutes of fun is the later gameplay goal, not evidence supplied by this lab.',
 'consultation':'Independent visual reviewer supplied native-grid/palette/pose/anchor guidance in team messages; those messages are consultation, not visual acceptance.',
 'execution':'Python original indexed export and three native PNG sheet inspections only. No Node, JS evaluation, browser, game build, server or integration.'})
current,hwm = guard()
write('SEAL-RESOURCE.json', {'admitted':True,'initial_current':initial,'maximum':maximum,'work':WORK,'reserve':RESERVE,'current_at_report':current,'actual_RSS_high_water_bytes':hwm,'time_ns':time.time_ns(),
 'scope':'This one-shot source pin/seal process only; actual /proc/self/status VmHWM, not getrusage inherited high water. Not a retrospective continuous guard or measurement of prior asset author/export operations.'})
files = {}
for path in sorted(ROOT.rglob('*')):
    if path.is_symlink(): raise RuntimeError('Symlink in packet')
    if path.is_file(): files[str(path.relative_to(ROOT))]=pin(path)
total = sum(item['bytes'] for item in files.values())
if total > 512 * 1024: raise RuntimeError('Small lab source packet limit exceeded')
write('MANIFEST.json', {'kind':'Original pixel foundation r1 SOURCE freeze','scope':'Research only; not executed in browser, integrated or accepted for game quality.', 'files':files,'body_bytes':total,'body_count':len(files)})
print(json.dumps({'manifest':pin(ROOT/'MANIFEST.json'), 'bodies':len(files),'body_bytes':total,'final_RSS_high_water_bytes':guard()[1]},indent=2))
