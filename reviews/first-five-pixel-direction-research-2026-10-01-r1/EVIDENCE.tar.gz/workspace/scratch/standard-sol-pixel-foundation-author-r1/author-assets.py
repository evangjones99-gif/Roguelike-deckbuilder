"""Original low-resolution indexed cluster drawings; no existing image input.
One-off asset authorship/export, not a game build or image downsampling pipeline.
"""
import json,pathlib,struct,zlib,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
W,H=64,48
PALETTE=[None,'#14171b','#26333c','#43535d','#6b7c80','#6e6552','#b3aa89','#e0d9b0','#626967','#969d92','#795a41','#64393f','#92565b','#e9a25b']
KEYS='0123456789ABCD'
FRAMES=['idle0','idle1','anticipate0','anticipate1','attack0','attack1','contact','recover0','recover1','hit0','hit1','death0','death1','death2']
HOOD=[
'000111111000','001222222100','012BBBBB2210','12BBB2222221','12BB15555221','12B155665221','12B155165221','12B115665221','012B11112210','0012BBB22100','00012B221000','000011110000']
SKULL=[
'000166661000','001677776100','016777777610','167711177761','167111177761','167711177761','016776676610','001661166100','000167761000','000161161000','000016610000','000001100000']
FALLEN_HOOD=['001111111100','0122BBBBB210','12B115556621','12B155516621','12B115556221','012BB1112210','00122BBB2100','000111111000']
def grid():return [['0']*W for _ in range(H)]
def pixel(g,x,y,c):
 assert isinstance(x,int) and isinstance(y,int) and 0<=x<W and 0<=y<H,(x,y,c)
 assert c in KEYS;g[y][x]=c
def rect(g,x,y,w,h,c):
 for py in range(y,y+h):
  for px in range(x,x+w):pixel(g,px,py,c)
def mask(g,x,y,rows):
 for dy,row in enumerate(rows):
  for dx,c in enumerate(row):
   if c!='0':pixel(g,x+dx,y+dy,c)
def poly(g,points,c):
 for y in range(min(p[1] for p in points),max(p[1] for p in points)+1):
  for x in range(min(p[0] for p in points),max(p[0] for p in points)+1):
   inside=False;j=len(points)-1
   for i in range(len(points)):
    a,b=points[i],points[j]
    if (a[1]>y+.5)!=(b[1]>y+.5) and x+.5<(b[0]-a[0])*(y+.5-a[1])/(b[1]-a[1])+a[0]:inside=not inside
    j=i
   if inside:pixel(g,x,y,c)
def line(g,a,b,c,width=1):
 x,y=a;tx,ty=b;dx=abs(tx-x);dy=-abs(ty-y);sx=1 if x<tx else -1;sy=1 if y<ty else -1;err=dx+dy;r=width//2
 while True:
  for yy in range(y-r,y+r+1):
   for xx in range(x-r,x+r+1):pixel(g,xx,yy,c)
  if x==tx and y==ty:break
  twice=2*err
  if twice>=dy:err+=dy;x+=sx
  if twice<=dx:err+=dx;y+=sy
def limb(g,a,j,b,c='8'):
 line(g,a,j,'1',3);line(g,j,b,'1',3);line(g,a,j,c);line(g,j,b,c)
def hook(g,hand,tip,contact=False):
 # Individually posed steel hook, not a screen-space trail or whole-body transform.
 line(g,hand,tip,'1',3);line(g,hand,tip,'8')
 line(g,(tip[0]-4,tip[1]-1),tip,'9');rect(g,hand[0]-1,hand[1]-1,3,3,'A')
 if contact:pixel(g,63,tip[1],'D')

HUNTER={
'idle0':(22,6,28,32,37,28,46,35,0),'idle1':(22,7,28,32,36,29,45,35,1),
'anticipate0':(21,8,26,34,28,22,20,12,2),'anticipate1':(23,8,27,35,27,19,15,14,3),
'attack0':(26,6,29,32,43,19,54,13,4),'attack1':(28,7,30,32,48,25,60,25,5),
'contact':(28,7,30,32,49,25,62,25,6),'recover0':(27,8,28,33,43,29,54,32,7),
'recover1':(24,7,28,32,38,30,47,36,8),'hit0':(20,9,25,34,25,25,34,19,9),'hit1':(22,8,27,33,31,28,42,33,10)}
def hunter(name):
 g=grid()
 if name.startswith('death'):
  n=int(name[-1])
  if n==0:
   poly(g,[(17,27),(29,25),(37,40),(31,44),(13,44)],'1');poly(g,[(18,29),(29,27),(34,40),(28,43),(15,43)],'B')
   mask(g,21,20,HOOD);limb(g,(28,36),(18,39),(17,42));rect(g,13,43,8,2,'1');limb(g,(29,31),(37,37),(44,40),'A');line(g,(44,40),(58,42),'8')
  elif n==1:
   poly(g,[(13,37),(27,29),(37,34),(46,41),(36,44),(12,44)],'1');poly(g,[(15,38),(27,31),(36,36),(42,41),(34,43),(14,43)],'B')
   mask(g,33,31,FALLEN_HOOD);line(g,(16,42),(27,38),'8',3);line(g,(27,38),(35,42),'A');line(g,(44,41),(60,43),'8')
  else:
   poly(g,[(9,41),(24,36),(40,38),(46,43),(35,44),(9,44)],'1');poly(g,[(12,41),(24,38),(39,40),(41,43),(17,43)],'B')
   line(g,(14,41),(25,40),'2',3);line(g,(25,40),(37,42),'A');mask(g,42,35,FALLEN_HOOD);line(g,(43,44),(60,44),'8');pixel(g,58,43,'9')
  return g
 hx,hy,hpx,hpy,handx,handy,tipx,tipy,n=HUNTER[name];shoulder=(hx+6,hy+15)
 # Anchored boots and distinct bent leg placement carry weight at y44.
 leftk=(21-(2 if n in [2,3,9] else 0),38+(1 if n in [2,3] else 0));rightk=(33+(2 if n in [4,5,6] else 0),39)
 limb(g,(hpx-3,hpy),leftk,(19,42),'2');limb(g,(hpx+2,hpy),rightk,(34,42),'8')
 rect(g,16,43,7,2,'1');rect(g,31,43,7,2,'1');rect(g,17,43,4,1,'A');rect(g,32,43,4,1,'8')
 poly(g,[(hx+1,hy+10),(hx+11,hy+10),(hpx+7,hpy+5),(hpx-8,hpy+7),(hpx-9,hpy+1)],'1')
 poly(g,[(hx+2,hy+12),(hx+9,hy+12),(hpx+5,hpy+4),(hpx-6,hpy+5)],'B')
 poly(g,[(hx+3,hy+13),(hx+6,hy+13),(hpx-3,hpy+4),(hpx-5,hpy+5)],'C')
 rect(g,hpx-4,hpy-2,10,2,'A');rect(g,hpx+2,hpy-2,2,2,'9')
 limb(g,(hx+2,hy+15),(hx-1,hy+21),(hpx-6,hpy-1),'8')
 elbow=(max(shoulder[0]+1,(shoulder[0]+handx)//2),max(shoulder[1]+1,(shoulder[1]+handy)//2))
 limb(g,shoulder,elbow,(handx,handy),'8');rect(g,shoulder[0]-2,shoulder[1]-2,5,3,'8');line(g,(shoulder[0]-2,shoulder[1]-2),(shoulder[0]+1,shoulder[1]-2),'9')
 hook(g,(handx,handy),(tipx,tipy),name=='contact');mask(g,hx,hy,HOOD)
 pixel(g,hx+9,hy+16,'D')
 return g

HOUND={
'idle0':(0,0,0,0),'idle1':(0,1,-1,1),'anticipate0':(-2,3,-3,-1),'anticipate1':(-3,4,-4,-2),
'attack0':(3,0,3,2),'attack1':(6,1,5,4),'contact':(7,2,7,6),'recover0':(4,3,3,3),'recover1':(1,1,1,1),
'hit0':(-3,3,-4,3),'hit1':(-1,2,-2,2)}
def hound(name):
 g=grid()
 if name.startswith('death'):
  n=int(name[-1]);top=31+n*3
  poly(g,[(8,top+3),(16,top),(33,top),(42,top+3),(47,43),(8,44)],'1')
  poly(g,[(10,top+4),(17,top+2),(33,top+2),(41,top+4),(43,42),(11,43)],'5')
  line(g,(17,top+2),(32,top+2),'A');line(g,(14,42),(22,43),'6');line(g,(32,43),(40,43),'6')
  poly(g,[(39,top+1),(49,top+2),(55,top+5),(52,42),(41,41)],'1');poly(g,[(41,top+3),(49,top+3),(53,top+5),(49,40),(42,39)],'6')
  line(g,(44,top+2),(47,top-2),'6');line(g,(47,top-2),(51,top-1),'7');pixel(g,47,top+5,'1')
  return g
 dx,dy,snout,jaw=HOUND[name]
 hip=(16+dx,28+dy);shoulder=(35+dx,25+dy)
 # Four slender jointed legs; only their joint/foot poses change, not atlas placement.
 limb(g,(hip[0]-2,hip[1]),(12+dx,36),(9,42),'5');limb(g,(hip[0]+2,hip[1]),(21+dx,35),(20,42),'A')
 front=45 if name=='contact' else 40+(2 if name=='attack1' else 0)
 limb(g,(shoulder[0]-3,shoulder[1]+3),(31+dx,35),(31,42),'5');limb(g,(shoulder[0]+2,shoulder[1]+2),(41+dx,35),(front,42),'A')
 for foot in [9,20,31,front]:rect(g,foot-2,43,5,2,'1');rect(g,foot-1,43,3,1,'6')
 line(g,(hip[0]-3,hip[1]-3),(5+dx,19+dy),'1',3);line(g,(5+dx,19+dy),(2,20+dy),'5')
 poly(g,[(10+dx,23+dy),(18+dx,19+dy),(35+dx,19+dy),(42+dx,25+dy),(35+dx,32+dy),(15+dx,30+dy)],'1')
 poly(g,[(12+dx,23+dy),(19+dx,21+dy),(35+dx,21+dy),(39+dx,26+dy),(33+dx,30+dy),(16+dx,28+dy)],'5')
 line(g,(19+dx,21+dy),(34+dx,21+dy),'A',3);line(g,(21+dx,22+dy),(33+dx,22+dy),'6')
 line(g,(29+dx,25+dy),(32+dx,29+dy),'6');line(g,(33+dx,25+dy),(35+dx,28+dy),'A')
 headx=37+dx;heady=18+dy;tip=50+snout
 poly(g,[(headx,heady+1),(headx+7,heady),(tip,heady+6),(tip+2,heady+10),(headx+3,heady+12),(headx-3,heady+8)],'1')
 poly(g,[(headx+1,heady+2),(headx+6,heady+2),(tip,heady+7),(tip,heady+8),(headx+4,heady+10),(headx-1,heady+7)],'6')
 line(g,(headx+2,heady+4),(headx+6,heady+4),'7');pixel(g,headx+5,heady+5,'D')
 line(g,(headx+1,heady+1),(headx+3,heady-5),'6');line(g,(headx+3,heady-5),(headx+7,heady-7),'7');line(g,(headx+3,heady-3),(headx-1,heady-6),'6')
 poly(g,[(headx+1,heady+10),(tip+1,heady+9),(tip,heady+11+jaw),(headx+2,heady+12+jaw)],'1')
 line(g,(headx+3,heady+11+jaw),(tip-1,heady+10+jaw),'5');pixel(g,tip-2,heady+11+jaw,'7')
 if name=='contact':
  # Mouth extends to the explicit fixed knee contact; no decorative strike trail.
  line(g,(tip,heady+8),(62,33),'6');pixel(g,63,33,'D')
 return g

SKELETON={
'idle0':(23,5,28,31,38,28,47,18),'idle1':(23,6,28,31,37,29,47,19),
'anticipate0':(21,8,26,33,27,21,17,12),'anticipate1':(22,9,26,34,26,20,14,13),
'attack0':(25,5,30,31,43,18,55,11),'attack1':(27,6,31,32,49,25,60,25),
'contact':(27,6,31,32,50,25,62,25),'recover0':(25,8,29,33,43,28,54,30),
'recover1':(24,6,28,31,39,29,48,20),'hit0':(20,8,25,33,27,25,35,18),'hit1':(22,7,27,32,33,28,43,23)}
def skeleton(name):
 g=grid()
 if name.startswith('death'):
  n=int(name[-1])
  if n==0:
   mask(g,22,18,SKULL);limb(g,(28,31),(22,37),(19,42),'6');limb(g,(30,32),(36,38),(34,42),'6');line(g,(25,30),(29,37),'6',3);line(g,(27,30),(39,38),'6')
  elif n==1:
   mask(g,34,30,SKULL);line(g,(19,37),(33,39),'6',3);line(g,(14,42),(26,40),'6');line(g,(27,41),(38,43),'7');line(g,(20,35),(22,40),'5')
  else:
   mask(g,43,32,SKULL);line(g,(12,43),(27,41),'6');line(g,(20,42),(35,43),'7');line(g,(28,38),(39,40),'6',3)
   for x in [29,32,35]:line(g,(x,37),(x+1,42),'5')
  rect(g,17,43,6,2,'5');rect(g,32,43,6,2,'6');line(g,(40,44),(61,44),'8');return g
 hx,hy,hpx,hpy,handx,handy,tipx,tipy=SKELETON[name];shoulder=(hx+5,hy+15)
 limb(g,(hpx-3,hpy),(21,38),(19,42),'6');limb(g,(hpx+3,hpy),(35,37),(35,42),'6')
 rect(g,16,43,7,2,'5');rect(g,32,43,7,2,'6')
 poly(g,[(hpx-6,hpy-1),(hpx+6,hpy),(hpx+4,hpy+6),(hpx-1,hpy+4),(hpx-6,hpy+7)],'1')
 poly(g,[(hpx-4,hpy),(hpx+4,hpy+1),(hpx+2,hpy+5),(hpx-2,hpy+3)],'A')
 line(g,(shoulder[0],shoulder[1]-1),(hpx,hpy),'5',3);line(g,(shoulder[0],shoulder[1]),(hpx,hpy),'7')
 for i in range(3):
  y=shoulder[1]+2+i*3;line(g,(shoulder[0]-5,y),(shoulder[0]+5,y+1),'1',3);line(g,(shoulder[0]-4,y),(shoulder[0]+4,y+1),'6')
 limb(g,(shoulder[0]-5,shoulder[1]),(hx-1,hy+23),(hpx-6,hpy),'6')
 elbow=((shoulder[0]+handx)//2,(shoulder[1]+handy)//2+2);limb(g,shoulder,elbow,(handx,handy),'6');hook(g,(handx,handy),(tipx,tipy),name=='contact')
 mask(g,hx,hy,SKULL);line(g,(hx+8,hy),(hx+10,hy-3),'8');pixel(g,hx+10,hy-3,'9')
 # Chest/knee anchors remain inside the authored hit result, including compression.
 if name=='hit0':pixel(g,24,25,'6');pixel(g,24,33,'5')
 return g

TILE=[
'2222222222222222','2333333333333332','2333333333333332','2333333333333332',
'2333333333333332','2333333333333332','2333333333333332','2222222222222222',
'3333333233333333','3333333233333333','3333333233333333','3333333233333333',
'3333333233333333','3333333233333333','3333333233333333','2222222222222222']
def png_chunk(name,data):return struct.pack('!I',len(data))+name+data+struct.pack('!I',zlib.crc32(name+data)&0xffffffff)
def write_sheet(actor):
 rows=[];cols=4;sheetw=W*cols;sheeth=H*4
 for y in range(sheeth):
  row=[]
  for x in range(sheetw):
   f=(y//H)*cols+x//W;c=actor['frames'][FRAMES[f]][y%H][x%W] if f<len(FRAMES) else '0';row.append(KEYS.index(c))
  rows.append(bytes(row))
 plte=b''.join(bytes.fromhex(color[1:]) if color else bytes([0,0,0]) for color in PALETTE)
 raw=b''.join(b'\x00'+row for row in rows)
 png=b'\x89PNG\r\n\x1a\n'+png_chunk(b'IHDR',struct.pack('!IIBBBBB',sheetw,sheeth,8,3,0,0,0))+png_chunk(b'PLTE',plte)+png_chunk(b'tRNS',bytes([0]+[255]*13))+png_chunk(b'IDAT',zlib.compress(raw,9))+png_chunk(b'IEND',b'')
 (ROOT/'assets'/f"{actor['id']}-sheet.png").write_bytes(png)
 return dict(width=sheetw,height=sheeth,columns=4,frameOrder=FRAMES,sha256=hashlib.sha256(png).hexdigest())

(ROOT/'assets').mkdir(exist_ok=True)
actors={}
for name,make,anatomy in [('hunter',hunter,[32,40]),('hound',hound,[40,28]),('skeleton',skeleton,[28,40])]:
 frames={frame:[''.join(row) for row in make(frame)] for frame in FRAMES}
 assert len({''.join(rows) for rows in frames.values()})==len(FRAMES),'Every pose must have genuinely different indexed anatomy'
 for rows in frames.values():
  assert len(rows)==H and all(len(row)==W for row in rows)
  assert all(c=='0' for row in rows[45:] for c in row),'Feet-plane bound exceeded'
 bounds={}
 for frame,rows in frames.items():
  points=[(x,y) for y,row in enumerate(rows) for x,c in enumerate(row) if c!='0']
  bounds[frame]=dict(left=min(x for x,y in points),top=min(y for x,y in points),right=max(x for x,y in points)+1,bottom=max(y for x,y in points)+1)
 union=dict(left=min(b['left'] for b in bounds.values()),top=min(b['top'] for b in bounds.values()),right=max(b['right'] for b in bounds.values()),bottom=max(b['bottom'] for b in bounds.values()))
 actors[name]=dict(id=name,width=W,height=H,anatomyReference=anatomy,feet=[24,44],contact=[63,33 if name=='hound' else 25],targetAnchor='knee' if name=='hound' else 'chest',hitAnchors=dict(chest=[24,25],knee=[24,33]),nativeFacing='right',frameBounds=bounds,unionBounds=union,frames=frames)
 assert frames['contact'][actors[name]['contact'][1]][63]!='0'
 actors[name]['sheet']=write_sheet(actors[name])
assert actors['skeleton']['frames']['hit0'][25][24]!='0' and actors['skeleton']['frames']['hit0'][33][24]!='0'
assert actors['hunter']['frames']['hit0'][25][24]!='0'
payload=dict(palette=PALETTE,keys=KEYS,cell=[W,H],frameOrder=FRAMES,tile=TILE,actors=actors)
(ROOT/'sprites.js').write_text('// Original indexed pixel drawings exported by author-assets.py; no painted source images.\nexport const ART = '+json.dumps(payload,separators=(',',':'))+';\n')
print(json.dumps(dict(actors=list(actors),framesPerActor=len(FRAMES),nativeCell=[W,H],paletteEntries=len(PALETTE),pngSheets='three original transparent indexed sheets; no runtime visual claim')))
