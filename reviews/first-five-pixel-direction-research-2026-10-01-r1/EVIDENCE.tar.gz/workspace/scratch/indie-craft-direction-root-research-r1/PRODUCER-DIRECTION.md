# Owner steering: handcrafted pixel-art Hollowpact

The owner clarifies that AAA means care, polish and feel rather than budget or photorealism. The new presentation direction is original grim pixel art for PC. Monster-binding, a dangerous contract hunter, meaningful deck tactics and tactile cards remain the identity; the cheerful woodland direction remains rejected. Pixel art is a production constraint and an art discipline, not an automatic quality or cost guarantee.

## Decision now

Prototype a coherent small slice before replacing the full presentation. Build original hunter, pact hound and skeletal adversary sprites with a reusable limited palette, distinct poses and fixed contact/feet anchors, a restrained ruined-abbey backdrop and compatible card/UI treatments. Measure sparse and full formations, not only a spacious concept. Keep costs, rules, intent and accessibility text live. No pixel filter applied to old paintings, no copied commercial assets and no generated screenshot used as proof of implementation. The generated concept is mood research and is not sprite-ready.

Keep the tested pure TypeScript reducer, seeded RNG, legal-action boundary, save migrations and local feedback isolation while the framework assessment proceeds. Switching language/engine requires evidence of a specific production advantage over the working pipeline. A renderer can be trialled separately if scene management, atlas animation or effects are the real bottleneck. Neither a framework's platform support nor an Electron package proves native consumer installation or Steam readiness.

## Small-team practices to adopt

- One finished encounter before another broad roster expansion: hover, drag, cancel, summon, command, hit, final kill, reward, save/reload and repeat must all tell a coherent story.
- Reuse a small palette, consistent pixels, atlas anchors and animation timelines. Spend authored frames on anticipation, contact and recovery rather than arbitrary standee scaling.
- Keep presentation events separate from canonical reducer actions. A contact cue occurs once per action even when rendering drops frames; cancellation or reduced motion must not undo or double-play a legal action.
- Tune forgiving acquisition/cancellation and readable target feedback with real pointer paths. Copying Celeste's platformer constants would be inappropriate; its explicit timings and grace windows demonstrate intentional tuning, not rules for a card game.
- Use sparse and crowded formation comparisons, actual mouse/keyboard play, readable live typography and motion controls. Prioritize frame-time, decoded texture memory and loading over asset-count claims.
- Match tests to stable contracts: reducer/save invariants and asset schema checks are useful; repeated miniature tests of changing cosmetic values are not a substitute for actual play.
- Keep prototypes reversible, retain honest rejected findings and archive major accepted milestones. Retire old material only after thorough independent review verifies that its replacement is better and the old material is no longer needed; record the producer's judgment and exact evidence first.
- Learn from prospective players separately from simulations. Models can expose balance and invariants; they cannot supply human enjoyment consensus.

## Primary sources actually read

Celeste's released Player Readme describes two programmers, familiar XNA/C# and cross-platform FNA/MonoGame, consciously ordered player logic, reusable components, and a desire for more data-driven animation. It explicitly says tactics games can benefit from more modular architecture. The released Player constants include named jump grace, variable-jump and dash timing windows; these are examples of carefully controlled feel, not algorithms copied into Hollowpact.

MonoGame's official README describes its .NET framework and lists Celeste and Stardew Valley among uses. Celeste's own account is more specific about platforms. LÖVE's official README describes a Lua 2D framework and warns its development main branch is not stable. Phaser's official README describes JavaScript/TypeScript scene, loader, input, animation, particle and tween support, with native apps requiring third-party tools. These framework descriptions do not demonstrate performance in our game.

Read-only connected GitHub retrievals are preserved in OFFICIAL-SOURCES.json. The first guessed uppercase LÖVE README returned 404; the actual lowercase readme.md was then fetched. No Balatro or Terraria developer interview/footage was inspected in this research, and no causal claim that pixel art made those games successful is supported here.

## Current scope and next evidence

The generated image is an original concept, not an implemented game. The first pixel foundation is an art/animation research lab, not yet an engine-backed game conversion. The existing PC R4 card-interaction prototype is strict-built and only partly tested; it remains unpromoted. Independent visual, technical and gameplay gates may reject these candidates. No AAA, human-fun, native Windows/Steam Deck or Steam publication qualification follows from this direction document.
