import os,pathlib,json,hashlib,resource,stat,time,shutil
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576));R=pathlib.Path('/workspace/Roguelike-deckbuilder');H=pathlib.Path('/workspace/scratch/standard-sol-indie-framework-research-r1')
def guard():
 c=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());m=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text());assert m-c>=24*1048576+512*1048576;return {'time':time.time(),'headroom':m-c}
def save(p,b):
 f=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:assert os.write(f,b)==len(b);os.fsync(f)
 finally:os.close(f)
initial=guard();rows=[];total=0
for rel in ['src/world-rng.ts','src/hunter-presence.ts','src/hound-jaw.ts','src/style.css','tests/engine.test.ts','tests/presentation-events.test.ts','tests/world-rng-v0.5.test.ts','tests/input.test.ts','tests/browser/save-schema-v0.5.spec.ts','.github/workflows/windows-validation.yml','package-lock.json']:
 guard();p=R/rel;f=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  s=os.fstat(f);assert stat.S_ISREG(s.st_mode) and s.st_size<=512*1024;b=bytearray()
  while x:=os.read(f,65536):b.extend(x);assert len(b)<=512*1024
  assert s==os.fstat(f)==os.stat(p,follow_symlinks=False)
 finally:os.close(f)
 total+=len(b);assert total<=1024*1024;name=rel.replace('/','__');save(H/'project-source'/name,bytes(b));rows.append({'path':str(p),'copy':'project-source/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'metadata':{k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}})
executables=[]
for name in ['node','npm','godot','godot4','blender','love','dotnet','aseprite']:
 p=shutil.which(name);r={'name':name,'executableFoundOnPATH':p,'versionExecuted':False,'bodyRead':False}
 if p:
  l=os.lstat(p);s=os.stat(p);r.update({'resolvedPath':os.path.realpath(p),'leafMode':l.st_mode,'targetMetadata':{k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_nlink','st_mtime_ns','st_ctime_ns']}})
 executables.append(r)
value={'scope':'Additional source/test/native-tool metadata only, no execution','files':rows,'bodyBytes':total,'executableMetadata':executables,'qualification':'Godot installed availability confirmed as metadata only, not version/plugin/export-template/runtime readiness; love/dotnet/aseprite absent on inspected PATH does not prove absent everywhere. Source tests were read, not run.','initial':initial,'final':guard(),'ownInputFDsClosed':True};save(H/'PROJECT-SOURCE-SUPPLEMENT.json',(json.dumps(value,indent=2)+'\n').encode());print(json.dumps({'files':len(rows),'bytes':total,'tools':[{k:r[k] for k in ['name','executableFoundOnPATH']} for r in executables]}))
