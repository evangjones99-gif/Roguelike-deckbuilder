import os,pathlib,json,hashlib,resource,stat,time,re
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576));R=pathlib.Path('/workspace/Roguelike-deckbuilder');H=pathlib.Path('/workspace/scratch/standard-sol-indie-framework-research-r1')
def guard():
 c=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());m=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text());print(json.dumps({'phase':'source-research-admission','headroom':m-c,'required':24*1048576+512*1048576}),flush=True);assert m-c>=24*1048576+512*1048576;v=os.statvfs(H);assert v.f_bavail*v.f_frsize>=2*1048576
 return {'time':time.time(),'headroom':m-c,'free':v.f_bavail*v.f_frsize}
def identity(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)
def read(p):
 fds=[];rows=[];fd=None
 try:
  fds.append(os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW))
  for n in p.parts[1:-1]:
   parent=fds[-1];f=os.open(n,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent);fds.append(f);i=identity(os.fstat(f));assert i==identity(os.stat(n,dir_fd=parent,follow_symlinks=False));rows.append((parent,n,f,i))
  fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=fds[-1]);s=os.fstat(fd);assert stat.S_ISREG(s.st_mode) and s.st_size<=1024*1024;b=bytearray()
  while chunk:=os.read(fd,65536):b.extend(chunk);assert len(b)<=1024*1024
  for parent,n,f,i in rows:assert identity(os.fstat(f))==i==identity(os.stat(n,dir_fd=parent,follow_symlinks=False))
  assert s==os.fstat(fd)==os.stat(p.name,dir_fd=fds[-1],follow_symlinks=False)
  return bytes(b),s
 finally:
  if fd is not None:os.close(fd)
  for f in reversed(fds):os.close(f)
def save(p,b):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:assert os.write(fd,b)==len(b);os.fsync(fd)
 finally:os.close(fd)
initial=guard();paths=['AGENTS.md','package.json','tsconfig.json','vite.config.ts','README.md','docs/CONTINUATION.md','docs/ENGINE-CONTRACT.md','docs/NATIVE-WINDOWS.md','docs/WINDOWS-INSTALLER-VALIDATION.md','docs/INPUT-v0.6.md','src/engine.ts','src/content.ts','src/main.ts','src/input.ts','src/arena.ts','src/art.ts','src/audio-host.ts','src/audio-player.mjs','desktop/main.cjs','desktop/audio-lifecycle.cjs','scripts/build.mjs','scripts/desktop-smoke.mjs','scripts/windows-installer-current-validation.mjs','scripts/windows-installer-asar-validation.mjs','scripts/simulate.ts','playwright.config.ts']
(H/'project-source').mkdir();rows=[];excerpts=[];total=0
for relative in paths:
 guard();p=R/relative;b,s=read(p);total+=len(b);assert total<=3*1048576;n=relative.replace('/','__');save(H/'project-source'/n,b);rows.append({'path':str(p),'relative':relative,'copy':'project-source/'+n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'metadata':{k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}})
 lines=b.decode().splitlines();matched=[]
 pattern=r'^(import |export (?:function|const|interface|type|class))|requestAnimationFrame|imageSmoothing|devicePixelRatio|localStorage|SAVE_VERSION|SCHEMA|saveGame|serialize|deserialize|saveRun|loadRun|backgroundThrottling|contextIsolation|nodeIntegration|ready-to-show|did-finish-load|app\.on|BrowserWindow|pointerdown|keydown|gamepad|presentation|stamp|innerHTML|canvas|electron|build|test|preview|immutable|readonly'
 for i,line in enumerate(lines,1):
  if re.search(pattern,line,re.I):matched.append({'line':i,'text':line[:600]})
 excerpts.append({'path':str(p),'hits':matched[:120]})
value={'scope':'Actual project source/config/docs full bounded reads, not runtime validation','initial':initial,'final':guard(),'files':rows,'bodyBytes':total,'allOwnInputFDsClosed':True,'gameSourceModified':False,'GitNodeBrowserBuildExecuted':False,'qualifiedHeadContext':'Parent reports currentconfirmedHEADdc4; no fresh Git operation by researcher.'};save(H/'PROJECT-SOURCE-PINS.json',(json.dumps(value,indent=2)+'\n').encode());save(H/'PROJECT-SOURCE-EXCERPTS.json',(json.dumps(excerpts,indent=2)+'\n').encode())
fd=os.open(H,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:os.fsync(fd)
finally:os.close(fd)
print(json.dumps({'files':len(rows),'bytes':total,'copiesClosed':True}))
