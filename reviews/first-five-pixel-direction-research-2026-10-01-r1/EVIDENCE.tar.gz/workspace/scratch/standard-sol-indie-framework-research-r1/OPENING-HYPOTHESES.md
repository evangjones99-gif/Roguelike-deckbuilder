# First five minutes: independent opening hypotheses
Prepared 2026-10-01. Latest owner direction: PC, keep JS/TS, handcrafted pixel art, focus the hourly work on the first five minutes rather than a full AAA game. This is a source-derived design proposal. Neither this researcher nor a model can establish first-time human absorption or fun.

## The actual current opening, before proposing changes
Selected frozen R4 source was read directly with O_NOATIME and copied with hashes. It differs from the retained ROOT implementation and must not be described as promoted. Its freeze declares runtime sourceDigest 27239b7ea537c4694e345a28f8b8ff94dcf0aac4b50394d81396ceecbc9bea8f, 87 inputs / 56 outputs. We did not rerun the freeze or a browser.

R4 hunt-entry.ts presents “Hunt the horrors. Make them fight for you.” A first-time title has Take a contract; Continue only appears for an actual nonterminal saved hunt. The next form exposes difficulty, with seed and starting kit behind optional disclosures; saved-run replacement requires explicit confirmation. It defaults to Initiate (0), not the Hunter difficulty used by the independent fixed-seed protocol.

R4 main.ts start(), lines 397–403, creates the campaign and immediately takes a sole map route, saving/rendering battle. Thus the first forced map click is already removed. The next statement opens the four-section tutorial dialog whenever hollowpact.tutorial.v2 is absent, including when storage fails. The modal explains energy/piles, six slots, commands/inspection, enemy intent order, and shortcuts before any battle action. This is a concrete source-observed teaching interruption, not a newly observed human rejection. Existing Help can retain the complete rules.

The engine begins with 65 health, 12 cards, a five-card draw and five energy. The starter deck has five summon copies and seven tools; a summon is not guaranteed in every possible opening hand. New creatures may command immediately and once per turn. The first two battle formations are small; exact seed 104729 hand/formation was not generated or played in this research. Hound commands have a bonus against unblocked enemies; enemy block, explicit target and intent are consequential. Binding means summoning from a card here, not capturing the defeated enemy. The title promise may create a capture expectation; show the current pact action honestly rather than silently implying an unavailable capture mechanic.

The UI already has real target selection, exact consequence previews, explicit cancel, Inspect, End turn, permanent reward/decline, and Replay seed after defeat. Saves occur after accepted actions. Existing optional field reports ask about confusion, meaningful choices and replay intent; this is an appropriate voluntary feedback channel, not an enjoyment metric automatically derived from wins.

## Developer evidence and careful transfer
[Celeste Classic readme](https://github.com/NoelFB/Celeste/blob/master/Source/PICO-8/Readme.md) says Classic.cs is a line-by-line C# port of the PICO-8 Lua game and links the original cart/code. We inspected the port's complete public source, not the original Lua cart, level tilemaps/art, video, or human play sessions. Its first comments explicitly warn that this translation is not a recommended C# implementation architecture.

[Classic.cs](https://github.com/NoelFB/Celeste/blob/master/Source/PICO-8/Classic.cs):
- Lines 157–162 begin at room (0,0); level_index()/next_room() provide discrete sequential rooms. No claim about the actual first room's obstacle arrangement is justified without its map.
- The player uses an edge-triggered jump buffer of four update ticks and ground grace of six ticks; sound/smoke and dash feedback acknowledge different outcomes. These are observed code values, not measured milliseconds here.
- Lines 1349–1382 kill_player gives immediate sound/particles, increments deaths and requests the same-room restart with delay_restart = 15; lines 1506–1513 count it down. This supports a short local retry loop in design, not a recommended half-second Hollowpact campaign reset. We did not independently inspect the emulator's update rate.
- Lines 1497–1504 respect DisableScreenShake. Feedback intensity can be optional.
- Lines 1534–1548 allow jump or dash to leave title, but include their own flash/countdown; do not describe Celeste as literally instant on every transition.
- The nearby memorial text is proximity-triggered (989–1028), rather than a complete rules manual. Its presence is evidence of contextual text, not evidence of player comprehension.

The larger [Celeste Player.cs](https://github.com/NoelFB/Celeste/blob/master/Source/Player/Player.cs) independently includes 0.1-second jump grace, explicit buffer consumption, pixel snapping and frame-driven sounds. These illustrate many deliberate small feel decisions. They do not make a card game's input queue, shake or failure cost automatically desirable.

[Godot's official first-game HUD example](https://github.com/godotengine/godot-docs/blob/master/getting_started/first_2d_game/06.heads_up_display.rst) separates score, short state messages, start and restart UI from the world. It is an implementation teaching example, not a peer-reviewed claim about five-minute retention. [Its scene organization guidance](https://github.com/godotengine/godot-docs/blob/master/tutorials/best_practices/scene_organization.rst) supports focused reusable components and explicit dependency ownership. We can use those ideas in JavaScript without adopting Godot.

All five-minute ordering and acceptance ideas below are our design inferences. No fetched primary source establishes a universal 300-second fun formula.

## Opening hypotheses, in priority order
| Hypothesis | Small concrete change to test | Expected observable signal | Counterevidence / stop condition |
|---|---|---|---|
| H1: first action teaches better than the automatic manual | Replace automatic startup tutorial with concise nonmodal, legal-state-aware guidance; retain complete Help and shortcuts | A new player identifies a playable card and its cost without staff explanation | Players cannot find binding/target/End turn; require better in-context cue, not merely less text |
| H2: binding ownership is the distinctive early payoff | Clearly show a legal summon landing beside the hunter, its real on-entry effect and READY state, then direct selection + enemy target | Player can explain “my creature can act now” and intentionally gives its first command | Arrival is mistaken for an automatic attack, new creature overlooked, or “binding” sounds like enemy capture |
| H3: a short real tactical comparison gives the opening agency | Present two legal target outcomes using current previews, e.g. blocked vs unblocked damage, damage vs defense; keep cancel free | Player predicts a visible consequence and chooses a reason, then sees that prediction confirmed | Everyone clicks a decorative highlight without understanding, preview unreadable or misleading |
| H4: one clean enemy response closes the learning loop | End-turn affordance summarizes the actual incoming target/health consequence; show one orderly retaliation and refreshed hand/readiness | Player links their defense/target decision to the resulting health/block and next opportunity | Long presentation locks, tiny intents, target redirection surprise or inability to tell whose turn it is |
| H5: earned salvage suggests “one more fight” | Show one permanent reward or decline and immediately offer the actual next route | Player can explain what they added and voluntarily proceeds | Five minutes elapsed before payoff, reward text overload, irrelevant choices or repeated menu friction |
| H6: recovery respects the experiment | Keep Continue/save integrity; terminal failure offers clearly labeled Replay seed and new hunt | Player can resume or deliberately retry without confusion/destructive surprise | Retry unexpectedly destroys an active save, alters learned seed rules, or forces the whole manual again |

These hypotheses should not all change at once. H1 is the smallest concrete source-level experiment; H2 is the first pixel-craft beat to pair with it. Keep meaningful choices real: do not fake previews, inject unseen cards, silently change enemy behavior for the reviewer, or script automatic plays. If ordinary openings repeatedly contain no summon before the intended payoff, record that actual finding. A later guaranteed opening kit or first-contract rule would be an explicit new-rules decision with legacy-save/replay compatibility, not an invisible renderer fix.

Avoid turning the opening into a forced tutorial puzzle. Permit tools first, cancel, Inspect, different target choices and a safe Help path. A tiny cue such as “Bind a creature. Command it this turn.” only appears when the visible hand/state supports it; otherwise show the applicable card/energy instruction. Teach one present decision, not shop/event/relic/boss systems in advance. Do not remove replacement confirmations or save error notices in pursuit of fewer clicks.

## A proposed 300-second observation, not a player deadline
| Approximate observer interval | Desired opportunity |
|---|---|
| 0–30 s | Understand the pact promise and start/Continue without setup demands |
| 30–90 s | Make the first legal cost/target decision, with a visible acknowledgment |
| 90–180 s | Own a binding and issue an intentional command; see one enemy response |
| 180–300 s | Finish a short earned exchange, see salvage or the next meaningful choice, choose whether to continue |

These are unvalidated design targets, not existing measured times, guaranteed wins, or a countdown displayed to players. Slow deliberate reading can be good play. If one fight cannot conclude by 300 seconds, record why; do not speed through human thinking or fabricate a reward. First test the observation on actual normal play before changing health/deck/formation to force the schedule.

## Review protocol and evidence
Use a genuinely first-time consenting human on PC when available, with their normal mouse/keyboard, ordinary UI-created campaign, sound/motion preferences and the complete Help available. Observe quietly before asking explanations. A fresh dedicated browser profile is legitimate; do not delete someone's current save or preconstruct localStorage. Fixed seed 104729/Hunter is useful for reproducible independent agent comparisons, but the first-time/default Initiate/random opening also needs observation. Do not report a Hunter protocol as the default onboarding experience.

Record actual wall/monotonic elapsed times from launch to first accepted action, first binding, first command, first enemy response and first reward, plus the visible actions, cancellations, help requests and confusion. Preserve exceptions and incomplete sessions. For saves, hash the actual opaque saved bytes and compare after real orderly close/relaunch/Continue; never edit the payload or import the engine as gameplay. Keep resource admission and short orderly phases from the existing PC protocol: the 640 MiB whole-phase work bound and 512 MiB reserve remain binding; source research does not authorize a browser launch.

After play, ask neutral questions: “What did your last choice change?”, “What did you expect the creature to do?”, “What was unclear?”, “Would you continue, and why?” Offer a choice to stop. Human self-report and behavior remain qualified observations from those participants, not population-level retention or AAA proof. Avoid leading “Was this fun?” pressure and success-only reporting.

Independent agent play can flag inability to parse cost/target/intent, redundant clicks, stalled feedback, pointless decisions and contradictory payoffs. It cannot substitute for a first-time person's surprise, tension or absorption. Win rate, completion, fewer clicks and correct saves are useful distinct signals; none alone proves fun.

## Recommended next bounded production step
Keep the R4 engine/native pipeline and JS direction. Author one small original binding pixel atlas plus a generic cel/contact timeline; add a concise contextual start cue in a new candidate while preserving Help and all saves. Make arrival/READY/first command an unmistakable three-beat sequence driven by existing events. Build and inspect that actual candidate, then run a short earned PC opening and seek first-time human observation. Promote only after separate technical/visual/gameplay evidence; retain all failures. Finish this opening experiment before new campaign content or a framework migration.
