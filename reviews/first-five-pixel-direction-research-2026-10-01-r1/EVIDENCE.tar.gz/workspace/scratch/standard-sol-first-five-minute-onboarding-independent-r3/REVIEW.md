# Independent onboarding r3 source review
Verdict: ACCEPT FOR SOURCE INTEGRATION AND A DISTINCT BUILD/PLAY REVIEW. This is not runtime, first-time comprehension or fun acceptance.

Exact candidate main.ts: 19bf2f6886859234da7629e22c34ba8166a7871db22ecf2a928ab49699f2ccfe (104,435 bytes).
Author FROZEN-FILES.json: 53813737391d91701e9152417d51e6537a8434fcbba38fa35f4cf75545309083.
Actual R4 baseline main.ts: c213d5cbcdbe9e2b4154d9187e912c3adbdf96aaaf5df8716fb095cc3b9c51a7.
Baseline runtime reference: 27239b7ea537c4694e345a28f8b8ff94dcf0aac4b50394d81396ceecbc9bea8f, unpromoted.

## Findings resolved
The hint's floor 1 matches initial canonical travel: createGame begins in map at floor 0; travel increments the floor before beginBattle; start auto-takes the sole opening route. First-turn/no-allies scope is narrow and legal summon availability is queried through actions(), which directly delegates to legalActions(state). The predicate therefore respects energy, binding capacity and current summon identity. Current attack/card selection instructions still return first. No summon is guaranteed in every possible hand and this source does not pretend otherwise.

R3 replaces the nonexistent “choose Deploy” instruction with the actual interaction: click a creature card to bind it, or drag it onto the highlighted area. selectCard immediately dispatches a legal targetless summon; existing drag logic highlights its valid area. The cue does not require finding a new named button or an unlabeled “seal.” The author R2-to-R3 diff recomputes exactly as a single copy replacement; the complete R4-to-R3 diff also matches exactly.

The only complete baseline differences are removing the automatic startup tutorial invocation and adding the guarded guidance line. Manual How to play, full tutorial contents, explicit learned preference handling, saved-run replacement confirmation and canonical save ordering are unchanged. No engine/save/seed/deck/rules behavior is changed. Storage failure no longer causes an automatic tutorial dialog; existing save-error reporting remains available. This is a deliberate presentation hypothesis, not proof that all new players will understand it.

## Scope and qualifications
All five author packet bodies were read with bounded nofollow/noatime FDs and before/after FD/path metadata equality; hashes matched the author freeze. Actual R4 main, engine and tactile CSS were read to bind baseline/control behavior. Both authored diffs were recomputed from complete exact source bodies. Fresh source-only 24 MiB work + 512 MiB reserve admissions were maintained. No game/framework/Git/Node/browser/build execution, fixture state, imported engine or human play occurred. Originals and r1/r2 rejections remain unchanged.

Reviewer independence: this agent authored framework research, independent play plans and unrelated retirement/preservation/advice tooling, not the game or this ROOT implementation. Suggesting the wording repair did not make this reviewer its implementation author; final exact source was authored and sealed separately by ROOT.

## Conditions for the next stage
Integrate only the exact accepted candidate against its pinned R4 baseline, or independently inspect any merged differences. Perform the existing strict build and freeze the actual resulting input/output identities before runtime review. Run the opening in a genuine UI-created profile, default Initiate and ordinary seeds, with the optional full Help discoverable. Compare a fixed-seed Hunter run separately rather than calling it the default experience.

Check actual cue wrapping/readability, legal summon vs tool-only/insufficient-energy behavior, selection priority, first binding/command, cancel, keyboard/Inspect, target preview, storage failure and real save/Continue. Preserve short 300-second observations and failures under the separate runtime resource admission. The source review itself grants no browser window or change to memory bounds.

Longer instructional text may wrap or obscure other guidance; actual human comprehension may be worse without the manual. Both remain open risks to measure, not source-blocking contradictions. Technical passes, agent judgments and fewer clicks do not establish human enjoyment, AAA quality, Steam readiness or ROOT promotion.
