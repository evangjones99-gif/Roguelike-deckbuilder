# Independent source review: first-five-minute onboarding r1
Verdict: REJECT the exact source proposal for integration as written.

Candidate main.ts SHA256: 70e11756f892fbc4a9ef18542330f3606e1b7c41cc78e24edb51e10c37387c50.
Author freeze SHA256: 8644a26fccf324edc4a5f10263adc75cdcb7cacbe25ca4998a92928ce55d8b7d.
Actual frozen R4 main.ts SHA256: c213d5cbcdbe9e2b4154d9187e912c3adbdf96aaaf5df8716fb095cc3b9c51a7.
R4 runtime reference: 27239b7ea537c4694e345a28f8b8ff94dcf0aac4b50394d81396ceecbc9bea8f, unpromoted.

## Concrete blocking finding
Candidate selectionGuidance() line 513 requires state.floor === 0 for the contextual summon hint. createGame() begins at floor 0 in map phase, but main.ts start() auto-travels its sole route. The unchanged engine increments s.floor before beginBattle (lines 951–954). A normal opening battle therefore has floor 1. This is static control-flow evidence from exact source, not an engine execution or private gameplay fixture. The promised first-battle replacement teaching cue is unreachable at the actual opening.

The modal-removal hunk is implemented, so accepting this source would remove the startup explanation without adding its intended contextual substitute. The fallback general guidance and manual How to play remain, so this is a specific mismatch between proposal and behavior; it is not proof of human confusion.

A second narrower concern: any summon card in hand does not imply a legal deployment. After first-turn tools spend energy, the proposed condition can still advise deployment with no affordable summon. Require an actually legal summon action for this new cue. The existing generic fallback wording is retained historical behavior, not newly fixed by this proposal.

## Required isolated repair
Preserve r1 unchanged. Produce a new candidate using first battle floor 1 and at least one legal summon play action, with current attack/card selection guidance taking precedence. Preserve manual Help, save replacement confirmation, existing preference behavior and all engine/save/seed/deck contracts. Review the new exact bytes independently.

## Other source observations
The candidate removes only the automatic tutorial invocation and adds the two-line guidance condition/text. Exact full source diff is checked against the author's main.diff. No reducer, save schema, seed, deck or persisted tutorial flag is changed by this diff. Existing How to play and its explicit learned action are unchanged. Existing R4 first-route auto-travel is unchanged. These are source observations, not strict-build, rendered geometry, focus, storage-failure, input or first-time enjoyment acceptance.

The independent reviewer authored framework research and unrelated retirement/preservation/advice tooling, not this proposal or the game implementation. All four author bodies were fully read and byte-verified against the author freeze with O_NOATIME before/after FD/path metadata equality. Actual R4 main.ts and engine.ts were fully read to bind the opening control flow. This review used source-only fresh 24 MiB work plus 512 MiB reserve admissions, no Node/browser/Git/game execution. Candidate and originals remain untouched.

## Required actual evaluation after a repaired build
Observe fresh-profile/default-difficulty startup and an ordinary fixed-seed Hunter comparison separately; confirm optional Help discoverability, first binding/command, cancel, keyboard/Inspect, target preview and storage failure. Check cue wrapping/readability in the actual desktop layout. Preserve actual 300-second observations and failures. A successful source review would only admit a hypothesis to build/play review; agent judgment and technical passes do not establish first-time human fun or ROOT promotion.
