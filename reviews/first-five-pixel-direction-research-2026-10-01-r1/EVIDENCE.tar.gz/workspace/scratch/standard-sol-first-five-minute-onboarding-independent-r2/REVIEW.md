# Independent onboarding r2 source review
Verdict: REJECT for one remaining concrete first-time instruction mismatch. The two r1 control-flow repairs are accepted as source findings.

Candidate: ee1c2b31fcd589eb70e74120ed78c93d0a8278ac3170ad0d94f8d2e97ad79ad1.
Author freeze: 70f975f418e20f4af88bb625a6b839cb3578885359d21d531ad2cfdb5f1f66db.
Actual R4 main: c213d5cbcdbe9e2b4154d9187e912c3adbdf96aaaf5df8716fb095cc3b9c51a7.

Floor 1 matches initial canonical travel. actions() directly calls legalActions(state); the new summon predicate therefore honors energy and binding capacity. Existing card/attack selection guidance takes precedence. Removal of the automatic tutorial leaves manual Help and the learned preference handler unchanged. The exact complete baseline/candidate diff and r1/r2 diff were recomputed and matched the retained authored diffs. No engine/save/seed/deck change is introduced.

Blocking copy finding: selectionGuidance line 514 says “choose Deploy”, but renderCard line 741 creates no Deploy-labeled button or action. selectCard lines 898–909 binds a targetless summon by clicking the creature card directly. The actual drag apron is a pointer-events:none / aria-hidden div; its sole visible pseudo-element text is “Release here” during active drag (tactile-hand.css lines 139–151). The instruction's alternate named action therefore cannot be found in the unchanged interface. “Seal” is also not the drag apron's source label. This is a source/UI naming mismatch, not newly observed human confusion or a claim that drag cannot work.

Preserve r2 unchanged. Suggested new isolated text: “Click a creature card to bind it, or drag it onto the highlighted area. How to play explains the rules.” Keep the repaired legal predicate and selection precedence. Avoid inventing a new Deploy button solely to match instructional text.

Full author bodies, actual frozen R4 main and engine, and actual tactile-hand.css were read with bounded nofollow/noatime FDs and before/after identity checks. Source-only fresh 24 MiB + 512 MiB admission; no game/framework/Git/Node/browser execution. Originals and previous source/rejection packets remain. Reviewer authored framework research and unrelated retirement/preservation/advice tooling, not this implementation.

This judgment only addresses whether the proposal's instructions describe the current controls. Fresh-profile comprehension, cue wrapping, focus, storage failure, actual mouse/keyboard play, save/Continue, first 300 seconds and human enjoyment still need a separately built runtime and earned observation. No technical runtime, human-fun, AAA, Steam or ROOT promotion acceptance.
