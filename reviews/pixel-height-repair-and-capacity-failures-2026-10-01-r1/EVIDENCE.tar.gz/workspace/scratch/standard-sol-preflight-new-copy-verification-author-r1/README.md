# Independent new-copy verifier source r1

Source-only proposal. No candidate execution, ZIP body read, cache advice, or retirement occurred during preparation. Review verify_new_copy.py, PINS.json and CALLER-PROTOCOL.md, then bind a fresh source acceptance and truthful ROOT declaration before any run.

This author did not produce the r4 copy or its hash. Prior unrelated retirement/preservation/cache tooling authoring is disclosed. The actual independent full new body is pending. The comparison SHA is the producer's fresh original+reopened-new hash, not a historical golden hash. Current metadata-only anchored intake exactly matched producer records for both originals and new copy, including xattrs and parent identities; all intake FDs closed.

One64KiB streaming hash reads the literal new copy only. Advice is limited to885 fully consumed aligned2MiB ranges;61584B tail is left unadvised. Original TMP is metadata-only. No logical ZIP/Git audit is proposed. Receipts<=64KiB; all external wrapper rows/final are retained and reviewed against the pre-wrapper24MiBTOTAL+512MiB baseline,60s deadline. No per-chunk ledger or duplicate producer-wrapper audit is introduced.

Source parsed with ast.parse; no import or execution. A fresh acceptance requires the exact binding keys in ACCEPTANCE.schema-example.json, its read/advice flag true, and an exact review path/hash. ROOT-DECLARATION.template.json is intentionally invalid; ROOT must create the separate literal declaration with true holds and a fresh pre-wrapper baseline.

Success requires full count/hash, protected metadata unchanged,885 attempted/returned advice calls, no pending range, exact closure and actual caller gates. Normal advice may reclaim nothing. Signals/power loss and blocking calls are not continuously guarded; caller manually bounds60s and checks actual final row and normal process wait/scoped PID absence. Original encoding remains retained; storage preference/path references/push/producer judgment/removal are separate.

All source writes closed before freeze. No repository, Git, browser, Node, archive mutation or deletion. Known ordinary interpreter source atime drift is distinguished from byte mutation; archive full metadata is strict.
