"""Independent new-disk-copy verifier. SOURCE ONLY until a fresh ROOT grant.
Reads only the literal new ZIP; advice only covers fully consumed 2 MiB ranges.
Never writes archive bytes, reads/advises the TMP body, or authorizes retirement.
"""
import argparse, hashlib, json, os, resource, signal, stat, sys, time
from pathlib import Path
BASE='/workspace/scratch/standard-sol-preflight-new-copy-verification-author-r2'
TARGET='/workspace/scratch/retained-original-archives/preflight-bdf273-original-r4.zip'
ORIGINAL='/tmp/hollowpact-native-v07/source-preflight-bdf27374358eb176e62f832cb50261cb3334d8df.zip'
OUT='/workspace/scratch/preflight-new-copy-independent-read-r2'
EXTERNAL='/workspace/scratch/preflight-new-copy-independent-guard-r2'
DECL='/workspace/scratch/preflight-new-copy-ROOT-DECLARATION-r2.json'
WRAPPER='/workspace/scratch/guard-node-phase-r1.py'
WRAPPER_SHA='7284b52f785779ffc5d2a2e1b539b19cd331ee7315ae6b7f7c71af1fa856f3cc'
SCOPE='One independent full new-disk ZIP read with consumed-only aligned advice; original TMP retained'
WORK,RESERVE,CHUNK,RANGE=64*1048576,512*1048576,65536,2*1048576
PROOF_CAP=65536
EXPECTED_SIZE=1856041104
EXPECTED_PRODUCER_SHA='e7c40a711ec970e265818d3153b02237efde959231ebc024f13a2b57c21bfef0'
resource.setrlimit(resource.RLIMIT_DATA,(WORK,WORK))

def need(ok,message):
    if not ok:raise RuntimeError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def encode(v):return (json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def identity(s):return {'name':None,'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid}
def metadata(path,fd):
    s=os.fstat(fd)
    return {'path':path,'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'bytes':s.st_size,'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'xattrs':{k:os.getxattr(fd,k).hex()for k in sorted(os.listxattr(fd))}}
def anchor(path):
    need(path.startswith('/')and'..'not in path.split('/'),'Literal absolute parent')
    flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    held=[os.open('/',flags)];rows=[]
    try:
        for name in path.split('/')[1:]:
            if not name:continue
            parent=held[-1];fd=os.open(name,flags,dir_fd=parent);held.append(fd);s=os.fstat(fd);r=identity(s);r['name']=name
            need(stat.S_ISDIR(s.st_mode)and s==os.stat(name,dir_fd=parent,follow_symlinks=False),'Parent redirection')
            rows.append((parent,name,fd,r))
        return held,rows
    except BaseException:
        for fd in reversed(held):os.close(fd)
        raise
def stable(rows):
    for parent,name,fd,r in rows:
        a=identity(os.fstat(fd));a['name']=name;b=identity(os.stat(name,dir_fd=parent,follow_symlinks=False));b['name']=name
        need(a==b==r,'Parent identity drift')
def control(path):
    p=Path(path);held,rows=anchor(str(p.parent));fd=None
    try:
        fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=held[-1]);before=os.fstat(fd)
        need(stat.S_ISREG(before.st_mode)and before.st_size<=65536,'Control bound/type')
        b=bytearray()
        while True:
            x=os.read(fd,min(4096,65537-len(b)))
            if not x:break
            b.extend(x);need(len(b)<=65536,'Control overflow')
        stable(rows);need(before==os.fstat(fd)==os.stat(p.name,dir_fd=held[-1],follow_symlinks=False),'Control drift')
        return bytes(b)
    finally:
        if fd is not None:os.close(fd)
        for fd in reversed(held):os.close(fd)
def reference(expected,parents):
    p=Path(expected['path']);held,rows=anchor(str(p.parent));fd=None
    try:
        need([r for _,_,_,r in rows]==parents,'Archive parent pin')
        fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=held[-1]);s=os.fstat(fd)
        need(stat.S_ISREG(s.st_mode)and s.st_uid==os.geteuid()and s.st_nlink==1,'Owned regular single link')
        need(s==os.stat(p.name,dir_fd=held[-1],follow_symlinks=False),'Archive path drift')
        observed=metadata(str(p),fd);need(observed==expected,'Archive reference metadata/xattr drift');stable(rows)
        need(os.lseek(fd,0,os.SEEK_CUR)==0,'Metadata reference body untouched')
        return observed
    finally:
        if fd is not None:os.close(fd)
        for fd in reversed(held):os.close(fd)
def own_memory():
    with open('/proc/self/status','rb')as f:b=f.read(8193)
    need(len(b)<=8192,'Own status bound');v={}
    for line in b.decode('ascii').splitlines():
        if line.startswith(('VmRSS:','VmHWM:')):
            k,n,unit=line.split();need(unit=='kB','Own RSS unit');v[k[:-1]]=int(n)*1024
    need(set(v)=={'VmRSS','VmHWM'},'Own RSS fields');return v
def own_process():
    with open('/proc/self/stat','rb')as f:b=f.read(4097)
    need(len(b)<=4096,'Own proc stat bound');tail=b[b.rfind(b')')+2:].decode().split();need(len(tail)>=20,'Own proc stat syntax')
    return {'pid':os.getpid(),'startTimeTicks':int(tail[19]),'ppid':int(tail[1]),'pgid':int(tail[2]),'sid':int(tail[3])}
def stop(signum,frame):raise InterruptedError('Catchable signal '+str(signum))

class Proof:
    def __init__(self):
        self.held,self.rows=anchor('/workspace/scratch');self.directory=None;self.failure=None;self.used=0
        try:
            os.mkdir(Path(OUT).name,0o700,dir_fd=self.held[-1])
            self.directory=os.open(Path(OUT).name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC,dir_fd=self.held[-1])
            self.write('FAILURE-SLOT.json',encode({'status':'reserved; no completed verification','adviceOutcomeWithoutCompleteResult':'unknown'}).ljust(8192,b' '))
            self.failure=os.open('FAILURE-SLOT.json',os.O_WRONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.directory)
            os.fsync(self.directory)
        except BaseException:self.close();raise
    def put(self,fd,b):
        need(self.used+len(b)<=PROOF_CAP,'Physical proof64KiB cap')
        view=memoryview(b)
        while view:
            n=os.write(fd,view);need(n>0,'Proof short write');view=view[n:]
        self.used+=len(b)
    def write(self,name,b):
        fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.directory)
        try:self.put(fd,b);os.fsync(fd);os.fsync(self.directory)
        finally:os.close(fd)
    def fail(self,v):
        b=encode(v);need(len(b)<=8192,'Failure slot bound');b=b.ljust(8192,b' ');offset=0
        while offset<len(b):
            n=os.pwrite(self.failure,b[offset:],offset);need(n>0,'Failure pwrite');offset+=n
        os.fsync(self.failure);os.fsync(self.directory)
    def close(self):
        for key in ['failure','directory']:
            fd=getattr(self,key,None)
            if fd is not None:os.close(fd);setattr(self,key,None)
        for fd in reversed(self.held):os.close(fd)
        self.held=[]

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--declaration',required=True);parser.add_argument('--acceptance',required=True);args=parser.parse_args()
    need(args.declaration==DECL,'Fresh literal declaration only')
    source=control(str(Path(__file__).absolute()));pinraw=control(BASE+'/PINS.json');pin=json.loads(pinraw);protocol=control(BASE+'/CALLER-PROTOCOL.md');wrapper=control(WRAPPER)
    need(sha(protocol)==pin['callerProtocolSHA256']and sha(wrapper)==WRAPPER_SHA,'Caller binding')
    declared=control(DECL);d=json.loads(declared);accepted=control(args.acceptance);a=json.loads(accepted)
    binding={'sourceSHA256':sha(source),'pinSHA256':sha(pinraw),'scope':SCOPE,'callerProtocolPath':BASE+'/CALLER-PROTOCOL.md','callerProtocolSHA256':sha(protocol),'wrapperPath':WRAPPER,'wrapperSHA256':WRAPPER_SHA,'targetPath':TARGET,'outputPath':OUT,'externalOutputPath':EXTERNAL}
    for v in [d,a]:
        for k,value in binding.items():need(v.get(k)==value,'Source/caller exact binding '+k)
    need(a.get('allowOneIndependentNewBodyReadWithConsumedAdvice')is True and a.get('requiresWholePhase64MiB512MiBAnd60Seconds')is True and a.get('allowsAutomaticRetirement')is False,'Distinct source gate')
    need(sha(control(a['reviewPath']))==a['reviewSHA256'],'Source review bytes')
    for key in ['knownAffectedArchiveActorsHeld','noUnknownAffectedWriter','noHeavyRuntimeConcurrent','priorCopyCompleteAndFsynced']:
        need(d.get(key)is True,'Genuine ROOT coordination '+key)
    baseline=d['phaseBaseline']
    for k in ['time_ns','monotonic_ns','current','maximum','free']:need(type(baseline[k])is int,'External baseline integer '+k)
    need(baseline['maximum']-baseline['current']>=WORK+RESERVE and baseline['free']>=64*1048576,'Pre-wrapper admission')
    need(type(baseline['memoryEvents'])is str,'External event baseline')
    deadline=baseline['time_ns']+60*1000000000;deadline_mono=baseline['monotonic_ns']+60*1000000000
    admission_raw=control(EXTERNAL+'/ADMISSION.json');admission=json.loads(admission_raw)
    need(admission['admitted']is True and admission['work']==WORK and admission['reserve']==RESERVE and admission['stage']==BASE,'External admission identity')
    need(admission['command']==['python3','-I',str(Path(__file__).absolute()),'--declaration',DECL,'--acceptance',args.acceptance],'External exact command')
    need(baseline['time_ns']<=admission['initial']['time_ns']<=time.time_ns()<=deadline and baseline['monotonic_ns']<=time.monotonic_ns()<=deadline_mono,'Whole-phase deadline includes imports')
    pinned={}
    for row in pin['controls']:
        raw=control(row['path']);need(sha(raw)==row['sha256'],'Producer/control drift '+row['path']);pinned[row['path']]=raw
    produced=json.loads(pinned[pin['producerResultPath']]);root=json.loads(pinned[pin['rootOutcomePath']])
    need(produced['old']==ORIGINAL and produced['destination']==TARGET and produced['originalRetained']is True and produced['freshOriginalHash']is True and produced['historicalGoldenHashClaim']is False,'Producer literal paths/fresh-hash qualification')
    need(produced['status']=='BYTE-EXACT COPY VERIFIED; ORIGINAL STILL RETAINED'and produced['bytes']==EXPECTED_SIZE and produced['sha256']==EXPECTED_PRODUCER_SHA and produced['ownArchiveFDsClosed']is True,'Prior producer comparison evidence')
    need(root['newHash']==EXPECTED_PRODUCER_SHA and root['bytes']==EXPECTED_SIZE and root['filesAndDirectoriesFsynced']is True and root['originalStillRetained']is True and root['deletionGranted']is False,'Prior fsynced-copy evidence')
    need(pin['targetMetadata']==produced['destinationMetadata']and pin['originalMetadata']==produced['before'],'Producer/pin metadata')
    process=own_process();proof=None;held=[];rows=[];target_fd=None;facts={'bytesRead':0,'advisedBytes':0,'adviceAttemptedRanges':0,'adviceReturnedRanges':0,'pendingRange':None,'ownTargetFDClosed':False,'originalBodyBytesRead':0,'originalAdvisedBytes':0};close_errors=[]
    last_guard_row=None
    extrema={'samples':0,'minimumHeadroom':None,'maximumAggregateDelta':None,'maximumOwnHWM':0}
    def guarded():
        nonlocal last_guard_row
        cg=Path('/sys/fs/cgroup');current=int((cg/'memory.current').read_text());maximum=int((cg/'memory.max').read_text());events=(cg/'memory.events').read_text();own=own_memory();now=time.time_ns();free=os.statvfs('/workspace/scratch').f_bavail*os.statvfs('/workspace/scratch').f_frsize
        row={'time_ns':now,'monotonic_ns':time.monotonic_ns(),'current':current,'maximum':maximum,'headroom':maximum-current,'delta':current-baseline['current'],'free':free,'ownRSS':own['VmRSS'],'ownHWM':own['VmHWM'],'eventsUnchanged':events==baseline['memoryEvents']}
        last_guard_row=row
        extrema['samples']+=1;extrema['minimumHeadroom']=row['headroom']if extrema['minimumHeadroom']is None else min(extrema['minimumHeadroom'],row['headroom']);extrema['maximumAggregateDelta']=row['delta']if extrema['maximumAggregateDelta']is None else max(extrema['maximumAggregateDelta'],row['delta']);extrema['maximumOwnHWM']=max(extrema['maximumOwnHWM'],own['VmHWM'])
        need(maximum==baseline['maximum']and row['headroom']>=RESERVE and row['delta']<=WORK and own['VmRSS']<=WORK and own['VmHWM']<=WORK and free>=PROOF_CAP+1048576 and events==baseline['memoryEvents'],'Whole-phase64+512/resource/events guard')
        need(baseline['time_ns']<=now<=deadline and baseline['monotonic_ns']<=row['monotonic_ns']<=deadline_mono,'60-second whole-phase deadline')
        return row
    def fresh():
        need(control(DECL)==declared and control(args.acceptance)==accepted and control(EXTERNAL+'/ADMISSION.json')==admission_raw,'Declaration/acceptance/admission drift')
        need(control(str(Path(__file__).absolute()))==source and control(BASE+'/PINS.json')==pinraw and control(BASE+'/CALLER-PROTOCOL.md')==protocol and control(WRAPPER)==wrapper,'Source/caller drift')
        need(sha(control(a['reviewPath']))==a['reviewSHA256'],'Review drift')
        for path,raw in pinned.items():need(control(path)==raw,'Producer control drift')
    def observe_target():
        need(metadata(TARGET,target_fd)==pin['targetMetadata'],'Full target metadata/xattrs')
        need(os.fstat(target_fd)==os.stat(Path(TARGET).name,dir_fd=held[-1],follow_symlinks=False),'New-target path drift');stable(rows)
    def close_archive():
        nonlocal target_fd,held
        if target_fd is not None:
            fd=target_fd;target_fd=None
            try:os.close(fd);facts['ownTargetFDClosed']=True
            except BaseException as e:close_errors.append(repr(e))
        for fd in reversed(held):
            try:os.close(fd)
            except BaseException as e:close_errors.append(repr(e))
        held=[]
    for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,stop)
    try:
        initial_guard=guarded();proof=Proof();guarded();fresh()
        reference(pin['originalMetadata'],pin['originalParents'])
        held,rows=anchor(str(Path(TARGET).parent));need([r for _,_,_,r in rows]==pin['targetParents'],'New-target parent pins')
        target_fd=os.open(Path(TARGET).name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=held[-1]);s=os.fstat(target_fd)
        need(stat.S_ISREG(s.st_mode)and s.st_uid==os.geteuid()and s.st_nlink==1 and s.st_dev==27 and s.st_ino==678628 and s.st_mode==0o100600,'One exact owned new target')
        observe_target()
        proof.write('BEFORE.json',encode({'target':pin['targetMetadata'],'originalMetadataReference':pin['originalMetadata'],'originalBodyBytesRead':0,'sourceSHA256':sha(source),'pinSHA256':sha(pinraw),'exactBindings':binding,'process':process,'externalBaseline':baseline,'deadlineNs':deadline,'deadlineMonotonicNs':deadline_mono,'producerHashQualification':'Fresh producer comparison, not a historical golden hash','plannedConsumedAdviceBytes':EXPECTED_SIZE//RANGE*RANGE,'unadvisedTailBytes':EXPECTED_SIZE%RANGE}))
        digest=hashlib.sha256()
        while True:
            guarded();body=os.read(target_fd,CHUNK)
            if not body:break
            digest.update(body);facts['bytesRead']+=len(body);need(facts['bytesRead']<=EXPECTED_SIZE,'Unexpected enlarged new file')
            end=facts['bytesRead']//RANGE*RANGE
            if end>facts['advisedBytes']:
                observe_target();guarded();need(end-facts['advisedBytes']==RANGE and facts['advisedBytes']%RANGE==0 and end<=facts['bytesRead'],'Only fully consumed aligned2MiB range')
                facts['pendingRange']={'offset':facts['advisedBytes'],'length':RANGE};facts['adviceAttemptedRanges']+=1
                os.posix_fadvise(target_fd,facts['advisedBytes'],RANGE,os.POSIX_FADV_DONTNEED)
                facts['adviceReturnedRanges']+=1;facts['advisedBytes']=end;facts['pendingRange']=None;guarded()
        need(facts['bytesRead']==EXPECTED_SIZE and digest.hexdigest()==EXPECTED_PRODUCER_SHA,'Independent full count/hash mismatch')
        observe_target();reference(pin['originalMetadata'],pin['originalParents']);fresh();guarded()
        close_archive();need(not close_errors and facts['ownTargetFDClosed'],'Own archive/anchor close outcome')
        final=guarded()
        proof.write('RESULT.json',encode({'status':'INDEPENDENT NEW COPY FULL HASH MATCH; ORIGINAL RETAINED','target':TARGET,'original':ORIGINAL,'bytes':facts['bytesRead'],'sha256':digest.hexdigest(),'comparisonProducerSHA256':EXPECTED_PRODUCER_SHA,'historicalGoldenHashClaim':False,'facts':facts,'extrema':extrema,'finalBeforePublication':final,'metadataUnchanged':True,'ownTargetAndArchiveAnchorFDsClosed':True,'process':process,'proofPhysicalBytesBeforeResult':proof.used,'retirementGranted':False,'qualification':'Full independent new stream agrees with prior producer fresh hash; no original body reread, logical/Git validation, unknown-writer atomic exclusion or cache-reclaim guarantee. Receipt FDs close in finally; ROOT requires actual normal wait and post-PID identity check.'}))
        guarded();os.fsync(proof.directory)
        print('Independent new copy whole count/hash match; original retained; no retirement grant.',flush=True)
    except BaseException as error:
        close_archive()
        if proof is not None:
            proof.fail({'status':'VERIFICATION FAILED OR INTERRUPTED; ALL FILES RETAINED','errorType':type(error).__name__,'error':str(error)[:1000],'process':process,'facts':facts,'lastGuardRow':last_guard_row,'extrema':extrema,'closureErrors':close_errors[:8],'scope':'No retry/global advice/cleanup; pending range or incomplete process has unknown advice outcome'})
        raise
    finally:
        close_archive()
        if proof is not None:proof.close()
if __name__=='__main__':main()
