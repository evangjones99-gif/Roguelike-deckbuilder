# Source preparation access and limits

No Node, browser, build, server, Git, game/stage mutation or gameplay was performed for this packet. Full candidate and retained baseline main bodies were read and pinned before their source diff was inspected. Assembly ledgers were consulted as metadata; the full 87 input bodies and compiled output were not independently read/audited here. ROOT must supply those matching runtime gates.

A bounded `rg` source lookup included nonexistent guessed author globs and returned exit 2. It also read candidate main without O_NOATIME. That ordinary read may have changed atime; the earlier intake pinned bytes/size rather than timestamp, so no exact atime invariance is claimed. The final O_NOATIME hash must match the intake body pin. No source bytes were written.

A later small counter/intake read first attempted O_NOATIME on `/sys/fs/cgroup/memory.current`; the kernel refused EPERM before reading subsequent bodies. That failed command is retained here as an access-method failure, not resource admission or body modification. Kernel memory counters may be read normally; frozen source bodies continue using O_NOATIME|O_NOFOLLOW. Existing ADMISSION.json and MAIN-INTAKE.json retain the successful earlier source phases. Final sealing records its own fresh 24 MiB work / 512 MiB reserve admission and actual VmHWM.

Source knowledge and earlier renderer/art authorship limit independence. The coaching main changes are ROOT-authored, and this author did not edit them. The task is independent observation of that coaching change, not independent acceptance of this author's renderer or art. Independent source review of a protocol, if obtained, is not actual play evidence.

R4 pixel-art source/visual findings remain separate: the fixed-study source gate accepted the slot-union repair, while game-art selection remains withheld and above-label height growth over 120 CSS px at 2× can put the readout above the scene. Neither art issue is silently repaired or accepted by this onboarding packet.
