# First 300 seconds: coaching comparison protocol

Prepared source only. Neither stage has been played under this protocol. ROOT owns matching builds, runtime admission and promotion. This protocol can reject the coaching candidate; it grants no game-quality or fun acceptance.

## One hypothesis and its limits

H1: entering the existing fight directly and giving a contextual instruction for an actually legal binding makes the first action easier to find without making binding, commands or enemy response harder to understand.

This is a bundled comparison. Removing the automatic rules dialog and adding the first-binding cue change together, so this protocol cannot attribute an outcome to either change alone. The operator knows the source/rules and authored earlier renderer and art research, but did not author ROOT's coaching main. This is a scoped independent agent play observation, not a novice study, human attention measurement or proof of fun. Do not assign a fun score.

## Source checkpoint

Candidate: `/workspace/scratch/first-five-opening-stage-r2`, recorded source digest `46c1b0ff025847fa69587fdb127e57066d65627399dccdd7e60f1c53d81b6cf5`; main SHA256 `19bf2f6886859234da7629e22c34ba8166a7871db22ecf2a928ab49699f2ccfe`.

Baseline: `/dev/shm/hollowpact-owner-tactile-pc-root-r4`, recorded runtime/source checkpoint `27239b7ea537c4694e345a28f8b8ff94dcf0aac4b50394d81396ceecbc9bea8f`; main SHA256 `c213d5cbcdbe9e2b4154d9187e912c3adbdf96aaaf5df8716fb095cc3b9c51a7`.

The full main-body diff has two behavioral edits. Candidate start no longer automatically opens the full tutorial. Its guidance adds the following only when there is no current selection, floor 1 / turn 1, no allies, and `legalActions` contains an actually legal summon-card play:

> Click a creature card to bind it, or drag it onto the highlighted area. How to play explains the rules.

Optional **How to play**, selected-card target guidance, selected-creature target guidance and the later general instruction remain. A hand with no legal summon correctly does not receive this special cue. Candidate start does not mark the tutorial learned. `MAIN-DELTA.txt` and `MAIN-INTAKE.json` record the exact source intake. Source digests do not establish matching compiled output or served-byte identity.

## Required gate before any play

ROOT must provide a strict candidate build result and exact immutable input/output ledgers, matching the checkpoint above and the actual served bytes. Record the candidate's new compiled-output digest rather than inventing one from its source digest. Confirm the retained baseline source/output/served-byte pins separately. A moving stage, missing build, mismatched main or unknown output identity blocks play.

Each browser phase needs fresh admission of **640 MiB TOTAL work plus 512 MiB reserve**, counting Node imports, any server, Chromium and evidence capture together. Existing resource supervision is not a wall-clock supervisor. ROOT must specify a bounded whole-tree launch/close contract, verified owned process group and closure receipt. The resource guard's 5-second escalation starts after a resource violation; it does not independently guarantee a 300-second or 45-second deadline. No TSX imports, game rebuild, pure-oracle evaluation or second overlapping browser is needed for this play protocol. ROOT grants the exclusive runtime window explicitly.

Preserve failed admission, timeout, partial evidence and teardown failure. An interrupted run stays interrupted even if a later close succeeds. Fully close and account for the whole browser tree and server before the next fresh phase. Do not reuse a warm browser to imply a fresh admission. Check game/audio mute status at entry and record it; no invented audio judgment if muted.

## Primary runs

Use one candidate run followed by one baseline run, each in its own new clean browser context/profile at 1440 × 900, desktop mouse and keyboard. Record this order and its learning bias. Different UI-generated seeds and hands make the result qualitative, not a controlled causal timing comparison. Do not repeat runs until a preferred hand appears. If capacity permits only one, preserve it as a candidate-only observation and leave the comparison unassessed.

1. Open the verified local game URL. Use a fresh empty context, no saved storage state, scripts, fixtures or save injection. Start the 300-second observation clock when the title is first visible and interactive; also record navigation start and battle entry. Time spent reading Help, deciding, being confused and using tools remains elapsed time.
2. Use the ordinary **Initiate** entry with its UI-created seed and default difficulty. Record the seed visible in the actual form and the selected difficulty. Do not override RNG, choose seed 44, preselect Hunter or replace a bad opening. Follow any entry choices that the actual UI presents.
3. Play from the visible goal and rules to keep the hunter alive and make useful choices. No prescribed bind-by-X-seconds target or compulsory action sequence. Before each meaningful action, record what you intend it to do and the visible text/preview that informed that choice. Source knowledge must be disclosed; do not pretend the operator is unfamiliar with the game.
4. Use ordinary pointer and keyboard input without forced clicks. Record rejected clicks, disabled controls, unexpected targeting, hesitation, chosen Help use and uncertainty. An unavailable action is evidence, not a reason to alter a state. Read-only DOM inspection/captures may document the visible UI, but hidden save/engine state must not guide choices during play.
5. Continue until elapsed 300 seconds or an actual loss/terminal screen. If a reward, route choice or next fight arrives early, decide through the UI and continue within the same clock. If the game ends, record the exact elapsed time and terminal screen; do not silently restart to fill five minutes.
6. End the observation at 300 seconds without extending it to manufacture a command, reward or success. Capture the current visible state and write a brief outcome. ROOT's separate tactile cancel/save checks do not become evidence from this protocol.

Use mouse naturally and use Tab/Enter/E/Esc only when the operator chooses or needs them. Preserve the actual key and focused label. A keyboard path not reached in these 300 seconds remains unassessed; do not convert an extra checklist into spontaneous discovery.

## What to record

Keep a chronological JSONL record with monotonic elapsed milliseconds and UTC, not a retrospective success narrative. Record the displayed first instruction, Help/dialog state, hand choices, energy/cost affordances, and visible selected-card/selected-creature/target previews. Quote essential intent type, amount and target when interpreting a hostile action.

Mark, if they actually happen: first meaningful choice; first accepted card play; first binding and its arrival/ready indication; first selected ready creature; intended target and command outcome; End turn and enemy response; consequence understood or misunderstood; reward, loss or subsequent route choice. Absence of a milestone is a result. Document which alternative you considered and why, rather than treating a click alone as evidence of comprehension.

For the special cue, record the visible floor/turn, empty ally row and whether an enabled creature card was present. A later technical check may compare its eligibility with legal actions, but do not claim pure-engine verification from appearance alone. No summon / unaffordable summon is an informative opening and stays in the sample.

Use at most 10 meaningful screenshots per phase and 128 chronological events; preserve entry, first decision, binding/command if reached, enemy consequence, genuine confusion and final state preferentially. Do not capture profiles, video, full traces or repeated art sheets. If this small cap is reached, record the cap and stop additional capture, not the observation. Keep console/error evidence bounded and separate from the action log. Any missing cue/capture is explicitly unknown.

## Optional assisted technical phase

This is not part of the primary unassisted comparison. Only run after a separate ROOT grant and fresh resource admission, if needed to isolate whether the click/drag/command affordance works once explained. A fixed seed 44 / Hunter may be selected through the actual UI here, with the real resulting hand recorded; it does not guarantee a binding is available.

The only manual H1 teaching intervention is to quote the candidate's exact first-binding instruction above, once, outside the game. Record when it was supplied and why. Do not point at a hidden legal action, select a card, force a click, modify a state or coach subsequent decisions. Any actions after the intervention are labelled **assisted**. If an intervention is supplied during a primary run, preserve the pre-intervention segment and mark the rest assisted; it is not a completed unassisted success.

The optional phase may show mechanical access after instruction; it cannot show natural discovery, beginner understanding or greater fun. If it is not run, say so.

## Interpretation and handoff

Report exact stage/build/output pins, phase admissions and closure evidence first. Compare the actually encountered startup dialog/cue, choice reasoning, confusion and consequences, with seed/hand/order differences attached. Do not pool primary, manual-assisted and fixed-seed technical evidence.

The candidate may be rejected or sent back if the first cue is clipped, falsely describes a control, arrives in the wrong context, blocks action, or if observed binding/command/target understanding worsens. A need for Help is not automatically failure; record whether it resolved the actual question. A short successful sequence is not proof of repeat five minutes of fun. If no valid build/window or no complete phase exists, report source preparation only.

Original rules, saves, tested tactile behavior and all pixel-art research remain unchanged. This packet supplies a protocol, not promotion or art selection.
