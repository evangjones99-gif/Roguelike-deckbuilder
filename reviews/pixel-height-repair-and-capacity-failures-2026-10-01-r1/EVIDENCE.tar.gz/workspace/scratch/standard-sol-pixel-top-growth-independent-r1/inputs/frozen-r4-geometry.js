import { ART } from './sprites.js';
export const PHASES=Object.freeze(['hand','bind','ready','command','contact']);
export function layoutScene(phase='ready',scale=2,measured={}) {
 if(!PHASES.includes(phase)||![2,3].includes(scale))throw Error('Known static study phase/integer scale required');
 const result={phase,scale,width:ART.scene.width,height:ART.scene.height,units:[],contact:null};
 const enemy=ART.scene.units.skeleton.home;
 const contactPoint=[enemy[0]+ART.scene.contactTarget[0],enemy[1]+ART.scene.contactTarget[1]];
 for(const id of ['hunter','skeleton','hound']){
  const spec=ART.scene.units[id],actor=ART.actors[id];
  let origin=[...spec.home],frame='idle0';
  if(id==='hound')frame={hand:'idle0',bind:'bind',ready:'idle0',command:'anticipate',contact:'contact'}[phase];
  if(id==='skeleton'&&phase==='contact')frame='hit';
  if(id==='hound'&&phase==='contact')origin=[contactPoint[0]-ART.scene.contactActor[0],contactPoint[1]-ART.scene.contactActor[1]];
  const b=actor.frameBounds[frame],body={left:origin[0]+b.left,top:origin[1]+b.top,width:b.right-b.left,height:b.bottom-b.top};
  const width=Math.min(spec.labelWidth,240/scale),height=measured[id]>0?measured[id]/scale:spec.labelHeight;
  const left=origin[0]+actor.feet[0]-width/2;
  const top=spec.labelSide==='above'?body.top-8-height:origin[1]+actor.feet[1]+8;
  const readout={left,top,width,height};
  const visible=!(id==='hound'&&phase==='hand');
  const unionLeft=Math.min(origin[0],readout.left),unionTop=Math.min(origin[1],readout.top);
  const unionRight=Math.max(origin[0]+actor.width,readout.left+readout.width),unionBottom=Math.max(origin[1]+actor.height,readout.top+readout.height);
  result.units.push(Object.freeze({id,origin,frame,body,readout,visible,
   cell:{left:origin[0],top:origin[1],width:actor.width,height:actor.height},
   slot:{left:unionLeft,top:unionTop,width:unionRight-unionLeft,height:unionBottom-unionTop}}));
  if(visible)result.height=Math.max(result.height,top+height+8);
 }
 if(phase==='contact')result.contact=Object.freeze({actor:'hound',target:'skeleton',point:contactPoint,kind:'Static drawing alignment only; no event callback'});
 return Object.freeze(result);
}
/** One owner at a source pixel, using actual pose indices in painter order. */
export function ownerAt(layout,x,y){
 if(!Number.isFinite(x)||!Number.isFinite(y))return null;
 for(const unit of [...layout.units].reverse()){
  if(!unit.visible)continue;
  const actor=ART.actors[unit.id],sx=Math.floor(x-unit.origin[0]),sy=Math.floor(y-unit.origin[1]);
  if(sx>=0&&sy>=0&&sx<actor.width&&sy<actor.height&&actor.frames[unit.frame][sy][sx]!=='0')return unit.id;
 }
 return null;
}
