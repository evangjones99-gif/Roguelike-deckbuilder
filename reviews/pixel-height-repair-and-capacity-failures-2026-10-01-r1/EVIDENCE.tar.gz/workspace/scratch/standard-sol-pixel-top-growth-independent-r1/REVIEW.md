# Independent top-growth source/math finding

**The common translation fixes negative upper readout coordinates in returned geometry, but reject r1's integer pixel-grid guarantee.** The translation must round upward to a whole native pixel. Preserve r1 and its40 passing Node cases; repair in a new r2. No art, game, live browser or whole-host acceptance follows.

Exact reviewed input: /workspace/scratch/pixel-height-growth-root-author-r1/geometry.js,3370 bytes,SHA2565ef0467efb3b3a528f05c09d1101df166b6d8d75950be96233fd439c6cdf45b7. Compared with frozen pixel-r4 geometry.js2664 bytes,SHA256955cabae55206bb6d45d1d3768d3d30499bb4baa87fdf260da6871d4d76413f7. Full exact copies and root's existing Node admission/result/execution receipts are retained in inputs/ with PRESERVED-INPUTS.json hashes. No source edited, JS/Node/browser/build run or old archive rehashed by this reviewer.

Fresh source24MiB work+512MiB reserve admitted at601456640-byte headroom. Held all shell/Python/image calls during root's requested quiet archive window, then resumed only after explicit release. No global process absence inference.

## Correct behavior in source

The new code finds the minimum visible full-union slot top, translates every unit's origin/body/readout/cell/slot by one common positive offset, translates the contact point, and increases returned scene height. The visible filter determines required growth; even hidden units share the resulting translation. Reverse alpha picking consumes translated origins, preserving relative ownership. With no negative slot top, the new block makes no changes. This addresses the previously identified scene-top clipping geometry, and full slot union remains intact. Default geometry preservation is also supported by root's existing test log.

## Counterexample and required correction

Measured natural CSS heights divided by display scale need not be integers. Current shift=-top therefore becomes fractional, shifting native actor origins/contact off the intended authored grid. READY at3× with200CSS-pixel enemy readout: body.top68native, label top68−8−200/3=−6.666666666666671, shift6.666666666666671, enemy originY70.66666666666667. At2× even a121CSS-pixel height gives shift0.5 and originY64.5. Both are allowed positive height inputs.

The current Canvas host paints1×1 source fillRect pixels; imageSmoothingEnabled=false does not snap fractional rectangle coordinates to integer boundaries. Such origins risk antialiased/mixed boundary pixels and depart from the literal indexed grid. This is a source/mathematical defect; no actual blurred browser screenshot or observed mis-hit is claimed.

Use one common ceil(-minimumTop) native shift. It keeps all original integer art origins/contact on grid and ensures top≥0, adding less than one native pixel of slack. Readout positions may remain fractional CSS/native text coordinates; that does not require moving actor pixels fractionally. Keep origin/body/readout/cell/slot/contact/height consistent and keep defaults unchanged. MATH-COUNTEREXAMPLES.json records direct independent arithmetic for104/120/121CSS at2× and156/200/500/1000CSS at3×. Its contact-equivalent column is a hypothetical shared point under the READY translation, not an actual READY contact (READY has no contact object). Contact phase has its own hit-pose top71native; at3×/200CSS its actual shift is3.666666666666671 and actual pointY112.66666666666667, likewise off grid.

Add meaningful integer origin/contact assertions to the existing positive-top/full-height/contact-owner tests. Include odd/non-divisible natural heights and near-threshold values, not only round even2× samples. A source test can confirm native integers and ownership invariance; actual paint/DOM text still needs later browser evidence.

## Existing test evidence, preserved rather than dismissed

Read root's /workspace/scratch/pixel-height-growth-node-actual-guard-r1/EXECUTION.log: statusPASS,cases40. It covers5 phases×2 scales with defaults unchanged and200/500/1000CSS tall-readout cases. RESULT.json records exit_code0/failure null, a small observed cgroup delta, unchanged memory.events and all child-group processes closed. Root's source qualification expressly excludes browser painting/text, art acceptance, game integration and fun. This reviewer did not rerun those Node cases and did not inspect an absent test-runner source.

Those cases meaningfully support coordinate growth/contact/owner invariants. The logged3× field heights246.666...,346.666...,513.333... also show why that passing scope cannot establish integer native painting. This finding does not erase the passing evidence; it identifies an additional required invariant.

## Host integration conditions, separate from this pure helper

Frozen pixel-r4 lab.js still uses a fixed384×240 canvas backing and ART.scene.height for canvas CSS height, while setting outer scene height from returned layout.height. A later host must resize the actual paint backing/viewport to the grown integer geometry; growing only the outer DOM scene leaves translated art clipped when it exceeds the old240native paint surface. For READY2×/1000CSS, shift440native puts the enemy origin at504 and near units farther below, clearly beyond that backing. This is a future adaptation condition, not a claim root promoted an unchanged host.

Binding ring uses raw ART.scene.units.hound.home; command preview path uses raw hound/skeleton homes; floor seams are also raw scene coordinates. They must consume the common translation/actual published geometry or intentionally remain world-static with a justified mapping. Otherwise tall-text translation moves actors while their bind/preview cues remain at old positions. Return an explicit common shift or derive these cues from translated units; do not privately apply a separate transform. Inspect/pointer mapping and measured readout iteration must agree with the resulting real canvas size.

Root states r1 was never promoted or integrated, and plans a separate Math.ceil r2 plus host inspection. This review permits that narrow correction/recheck; it does not request an anatomy/framework rewrite. Frozen original pixel-r4, its art rejection and game runtime remain unchanged. Browser CLOSED/not launched; actual geometry/painting review still waits for a separate capacity grant.
