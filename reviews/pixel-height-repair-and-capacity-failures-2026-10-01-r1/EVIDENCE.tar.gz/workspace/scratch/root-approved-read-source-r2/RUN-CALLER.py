import os,sys,resource,json,time,hashlib,subprocess,signal,stat
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
B='/workspace/scratch/standard-sol-preflight-new-copy-verification-author-r2'
G='/workspace/scratch/root-approved-read-source-r2'
E='/workspace/scratch/preflight-new-copy-independent-guard-r2'
O='/workspace/scratch/preflight-new-copy-independent-read-r2'
D='/workspace/scratch/preflight-new-copy-ROOT-DECLARATION-r2.json'
W='/workspace/scratch/guard-node-phase-r1.py'
def read(p,cap=65536):
 f=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  before=os.fstat(f);assert stat.S_ISREG(before.st_mode) and before.st_size<=cap
  parts=[];n=0
  while True:
   a=os.read(f,min(65536,cap+1-n))
   if not a:break
   parts.append(a);n+=len(a);assert n<=cap
  assert before==os.fstat(f)==os.stat(p,follow_symlinks=False)
  return b''.join(parts)
 finally:os.close(f)
def write(p,v):
 b=(json.dumps(v,sort_keys=True,indent=2)+'\n').encode();f=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  view=memoryview(b)
  while view:view=view[os.write(f,view):]
  os.fsync(f)
 finally:os.close(f)
def sha(b):return hashlib.sha256(b).hexdigest()
def proc(pid):
 try:
  b=read('/proc/'+str(pid)+'/stat',4096)
 except FileNotFoundError:return {'status':'ABSENT'}
 # /proc stat size is0 but bounded streaming is still valid
 tail=b[b.rfind(b')')+2:].decode().split()
 return {'status':'PRESENT','pid':pid,'startTimeTicks':int(tail[19]),'ppid':int(tail[1]),'pgid':int(tail[2]),'sid':int(tail[3])}
def metadata(expected,parents):
 p=Path(expected['path']);flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC;held=[os.open('/',flags)];rows=[];fd=None
 try:
  for name in p.parent.parts[1:]:
   n=os.open(name,flags,dir_fd=held[-1]);s=os.fstat(n);assert s==os.stat(name,dir_fd=held[-1],follow_symlinks=False)
   rows.append({'name':name,'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid});held.append(n)
  assert rows==parents
  fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK,dir_fd=held[-1]);s=os.fstat(fd)
  row={'path':str(p),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'bytes':s.st_size,'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'xattrs':{k:os.getxattr(fd,k).hex()for k in sorted(os.listxattr(fd))}}
  assert row==expected and s==os.stat(p.name,dir_fd=held[-1],follow_symlinks=False) and os.lseek(fd,0,os.SEEK_CUR)==0
  return row
 finally:
  if fd is not None:os.close(fd)
  for f in reversed(held):os.close(f)
p=json.loads(read(B+'/PINS.json'));a=json.loads(read(G+'/ACCEPTANCE.json'));controls=[B+'/verify_new_copy.py',B+'/PINS.json',B+'/CALLER-PROTOCOL.md',W,G+'/ACCEPTANCE.json',G+'/REVIEW.md']+[r['path']for r in p['controls']]
before={path:sha(read(path))for path in controls};assert before[B+'/verify_new_copy.py']==a['sourceSHA256'] and before[B+'/PINS.json']==a['pinSHA256'] and before[B+'/CALLER-PROTOCOL.md']==a['callerProtocolSHA256'] and before[W]==a['wrapperSHA256']
target_before=metadata(p['targetMetadata'],p['targetParents']);original_before=metadata(p['originalMetadata'],p['originalParents'])
v=os.statvfs('/workspace/scratch');baseline={'time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text()),'free':v.f_bavail*v.f_frsize,'memoryEvents':Path('/sys/fs/cgroup/memory.events').read_text()}
d=json.loads(read(B+'/ROOT-DECLARATION.template.json'));d.pop('NOT_EXECUTABLE_TEMPLATE');d.update({'knownAffectedArchiveActorsHeld':True,'noUnknownAffectedWriter':True,'noHeavyRuntimeConcurrent':True,'priorCopyCompleteAndFsynced':True,'phaseBaseline':baseline,'coordinationOrigin':'ROOT explicit exclusive quiet window and known actor holds; no unknown affected writer observed, not atomic global exclusion'})
write(D,d);controls.append(D);before[D]=sha(read(D))
cmd=['python3','-I',W,B,E,'64','python3','-I',B+'/verify_new_copy.py','--declaration',D,'--acceptance',G+'/ACCEPTANCE.json']
result={'phaseBaseline':baseline,'command':cmd,'retirementGranted':False,'originalRetained':True,'noRetry':True,'targetMetadataBefore':target_before,'originalMetadataBefore':original_before,'archiveBodyBytesReadDuringAdmission':0,'archiveAdviceDuringAdmission':False,'minimumAdmissionHeadroom':603979776};child=None
if baseline['maximum']-baseline['current']<536870912+67108864 or baseline['free']<64*1048576:
 result.update({'status':'PRE-WRAPPER ADMISSION REFUSED','helperLaunched':False})
 write(G+'/CALLER-RESULT.json',result);print(json.dumps(result));sys.exit(3)
try:
 child=subprocess.Popen(cmd,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 wrapper_identity=proc(child.pid);result['wrapperIdentity']=wrapper_identity
 remaining=max(0,(baseline['monotonic_ns']+60_000_000_000-time.monotonic_ns())/1e9)
 stdout,stderr=child.communicate(timeout=remaining)
 result.update({'wrapperReturnCode':child.returncode,'normalOwnedWrapperWaitCompleted':True,'stdout':stdout.decode(errors='replace'),'stderr':stderr.decode(errors='replace'),'wrapperPostWait':proc(child.pid)})
 runtime_end_wall=time.time_ns();runtime_end_mono=time.monotonic_ns()
 result['wholeRuntimeNanoseconds']=runtime_end_mono-baseline['monotonic_ns'];result['runtimeEndTimeNs']=runtime_end_wall
 assert runtime_end_wall<=baseline['time_ns']+60_000_000_000 and runtime_end_mono<=baseline['monotonic_ns']+60_000_000_000
 if child.returncode!=0:
  result['status']='WRAPPER/HELPER FAILED OR REFUSED; NO RETRY'
 else:
  admission=json.loads(read(E+'/ADMISSION.json'));r=json.loads(read(E+'/RESULT.json'));h=json.loads(read(O+'/RESULT.json'));first=json.loads(read(O+'/BEFORE.json'))
  assert admission['admitted'] and admission['work']==67108864 and admission['reserve']==536870912
  assert r['exit_code']==0 and r['failure']is None
  rows=r['samples']+[r['final']];minimum=min(row['headroom']for row in rows);maximum=max(row['current']-baseline['current']for row in rows)
  for row in rows:
   assert row['maximum']==baseline['maximum'] and row['headroom']>=536870912 and row['current']-baseline['current']<=67108864 and row['free']>=1048576 and baseline['time_ns']<=row['time_ns']<=baseline['time_ns']+60_000_000_000
  events=Path('/sys/fs/cgroup/memory.events').read_text();assert r['memory_events_before']==r['memory_events_after']==events==baseline['memoryEvents']
  f=h['facts'];assert h['bytes']==1856041104 and h['sha256']=='e7c40a711ec970e265818d3153b02237efde959231ebc024f13a2b57c21bfef0'
  assert f['bytesRead']==1856041104 and f['adviceAttemptedRanges']==f['adviceReturnedRanges']==885 and f['advisedBytes']==1855979520 and f['pendingRange']is None and f['ownTargetFDClosed'] and f['originalBodyBytesRead']==f['originalAdvisedBytes']==0 and h['ownTargetAndArchiveAnchorFDsClosed']
  identity=h['process'];assert identity==first['process'];post=proc(identity['pid']);assert post['status']=='ABSENT' or post['startTimeTicks']!=identity['startTimeTicks']
  result.update({'status':'ACTUAL INDEPENDENT WHOLE NEW FILE VERIFIED; ORIGINAL RETAINED','allWrapperSamplesAndFinalPassed':True,'sampleCount':len(r['samples']),'minimumHeadroom':minimum,'maximumWholePhaseDelta':maximum,'eventsUnchanged':True,'helperProcess':identity,'helperPostWait':post,'bytes':h['bytes'],'sha256':h['sha256'],'adviceAttemptedRanges':885,'adviceReturnedRanges':885,'advisedBytes':1855979520,'unadvisedTailBytes':61584,'helperArchiveAndAnchorFDsClosed':True,'comparisonIsProducerFreshHashNotGolden':True})
  result['targetMetadataAfter']=metadata(p['targetMetadata'],p['targetParents']);result['originalMetadataAfter']=metadata(p['originalMetadata'],p['originalParents'])
  after={path:sha(read(path))for path in controls};assert before==after;result['controlPosthashes']=after
  proof_bytes=sum(os.stat(O+'/'+name,follow_symlinks=False).st_blocks*512 for name in os.listdir(O));assert proof_bytes<=65536;result['helperProofPhysicalBytes']=proof_bytes
  for folder in [O,E]:
   for name in os.listdir(folder):
    fd=os.open(folder+'/'+name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:os.fsync(fd)
    finally:os.close(fd)
   fd=os.open(folder,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME);os.fsync(fd);os.close(fd)
  result['allProofAndWrapperFilesDirectoriesFsynced']=True
 result['finalCallerWallNs']=time.time_ns();result['finalCallerMonotonicNs']=time.monotonic_ns()
 assert result['finalCallerWallNs']<=baseline['time_ns']+60_000_000_000 and result['finalCallerMonotonicNs']<=baseline['monotonic_ns']+60_000_000_000
except BaseException as error:
 result.update({'status':'CALLER VALIDATION FAILED OR INTERRUPTED; NO RETRY','errorType':type(error).__name__,'error':str(error)})
 if child is not None and child.poll()is None:
  # Stop only this known owned wrapper and any exact still-live recorded helper group.
  try:
   if os.path.exists(O+'/BEFORE.json'):
    ident=json.loads(read(O+'/BEFORE.json'))['process'];seen=proc(ident['pid'])
    if seen['status']=='PRESENT' and seen['startTimeTicks']==ident['startTimeTicks']:os.killpg(ident['pgid'],signal.SIGTERM)
  except BaseException as e:result['helperStopError']=repr(e)
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:child.wait(timeout=3)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGKILL);child.wait()
  result['wrapperTerminatedAndWaited']=True
finally:
 write(G+'/CALLER-RESULT.json',result)
 fd=os.open(G,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME);os.fsync(fd);os.close(fd)
 print(json.dumps(result,sort_keys=True))
