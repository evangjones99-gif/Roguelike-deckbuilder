# Independent original pixel r4 review

**Hunter presence and hound surface continuity improve; current art still falls short of a convincing threatening pixel foundation. Withhold game-art selection.** Retain this as anatomy/layout research and, when capacity permits, a small actual live-UI study. The complete slot union repair is correct. Compact scene arithmetic is more plausible for PC than r3, but above-readout top bounds remain unsafe when natural text height grows.

## Exact evidence

Author seal: /workspace/scratch/standard-sol-pixel-foundation-author-r4/MANIFEST.json SHA256 76ca7d88243b11f6b143af3da63c0d2d8443234f7a53dc81472ce2f8e3aacfd3,27 bodies/180969 bytes. Independently read seal first and verified every named size/hash before body inspection; AUDIT-BEFORE.json records all27 matching.

Fresh24MiB source work+512MiB reserve admission passed with613437440-byte headroom against562036736 required. Root's separate archive-verification quiet window was respected: bounded read-only source, small native image views and metadata/index decoding only. No image transforms, output images, browser, Node/server, JS execution, author/export execution, builds, Git or shared-source edits. No global process absence claim.

Personally viewed five original final assets at native detail:256×128 hunter/hound/skeleton sheets and768×480 READY/contact authored exports. Compared with my earlier personally inspected exact r3/r2/r1 originals and retained findings. These exports contain art only, deliberately excluding live labels/cards, and are not browser screenshots. view_image does not expose O_NOATIME; its access timestamps cannot be guaranteed unchanged. Source/hash/PNG-decode reads used O_NOATIME. Reference metadata discloses a generated nonshipping anatomy reference consulted by author; this reviewer did not inspect that reference here and makes no claim to its pixel/grid quality or human preference.

Final art SHA256: hunter d8bc7ff94db3a2d496100d8915364129b33c7c8a27cd65cd83017a64b7353109; hound19646c1a0e6ffd7f3d2e036d9fa93bc9e93f97b13d3c9f18b94122ad486fde4e; skeletoncaf50ee89eab4e50fa25e9668ead27b1e4ec63c22b9cc61a661c06d686295234; READYad28f00c3234cb199b5a0cad1e275c8710f460793a402f3f04d67135a60f8c2e; contact1c5968edc606baf169f2b9cb570a5b2117073c7524722bc82894d86e54596d91. Author first exports/source remain in the sealed packet; I viewed final assets, not every draft.

## Visible improvements and remaining rejection

Hunter now has adult torso/shin length, broad shoulders, a larger split coat, planted boot shapes and a weighted vertical cleaver. Its opaque READY height is58native/116px at2×, versus57/114px enemy. This is a substantial correction of r3's78px hunter against114px foe. The closed masked hood preserves original identity without a cute exposed face. I accept that this revision addresses relative presence; a pass on proportions is not final character-art acceptance.

Hunter remains a sparse geometric figure. Coat panels, arms and shins have little anatomical/material distinction, and the stance looks diagrammatic rather than loaded with weapon weight. The weapon is identifiable but appears held out as a narrow upright block. Native anticipation/contact drawing changes do not establish believable movement. Death is a supported low coat/hood mass, more legible than r1's flat bar, but needs actual transition inspection and clearer folded limb support.

Hound's two new warm fur values and longer contiguous planes reduce r3's rock segmentation and cold armor impression. Short/scarred ears remove the obvious bunny cue, and the rear/diagonal body remains original, not a mirrored side sprite. That is real progress.

The very long flat upper jaw/head and small mandibular cavity now suggest a long-snouted reptilian creature more than a cohesive canine. The skull reads as an overlong horizontal tan shape atop a thin neck. Body/hip/chest and narrow angled legs remain schematic; large paws and support do not convincingly carry its forward mass. Improve neck/skull proportions, a readable muzzle/mouth/mandible separation and torso-to-limb attachment rather than adding teeth or glow alone. A gravehound can be monstrous, but its threat should derive from connected weight and purposeful anatomy. I still do not see an earned first-binding visual reward from this static drawing.

Skeleton preserves the prior clearly readable sockets/ribs/pelvis and diagonal spear; it is not the main regression. It remains a generic thin foe with limited threat posture. Contact export preserves its head/rib contour better than the early side-view studies, with the hound meeting knee height. The jaw/head still makes the bite difficult to read as a grounded anatomical action; a static coincident marker cannot substitute for motion/contact judgment.

The field is a quiet diagram with four seams and no convincing environmental support/contact shadows. Feet are source-anchored, but this alone does not make the figures visibly grounded in a ruined hunter's world. Develop a deliberate floor plane/compact pixel contact shading and larger environmental forms while leaving the actor band quiet. This is a critique of the visible research composition, not a demand for noisy photoreal detail. Pixel craft can be simple; it still needs intentional shape, material and motion hierarchy.

## Original grid/source integrity

ANALYSIS.json records independent read-only native PNG decode/mask/bounds comparison. All three final sheets are8-bit indexed256×128, seven unique64×64 source drawings per actor, one transparent index0 and15 fully opaque colors. All PNG indices and declared frame bounds match sprites.js. Palette growth from14 to16 entries is explicitly disclosed, not hidden near-color noise. There is no evidence of filtered/generated-raster content in the shipping masks; inspectable original source constructs them directly. The generated anatomy reference is separately labelled nonshipping, and its exact bytes must remain preserved.

Opaque unions (right/bottom exclusive): hunter[10,3,63,61], hound[6,15,59,61], skeleton[8,4,56,62]. All share feet[27,60], but actual body extents differ. The full64×64 cell is128×128 at2×,192×192 at3×; opaque READY heights116/90/114 differ. A common grid does not mean forcing quadruped/humanoid bodies to identical height or cropping contact/death to an idle box.

Read geometry/lab/HTML/CSS differences from frozen r3. The full slot union now uses left/top minima, right/bottom maxima then subtracts common origin. Default enemy originY64, readoutTop8 and fallback52native height give union top8,bottom128,height120, correctly covering the full cell64..128 and readout8..60. This repairs my exact previous finding; no observed r3 mis-target is invented. Current paint and optional alpha point inspection still share published origin/pose and reverse painter ownership; slot extents are not reducer hit authority.

## Compact field and live-text risks

384×240native at default2× yields768×480 art, reduced from r3's608px. Shorter header/toolbar, full natural three-card hand and initially closed supplemental inspector make normal1440×900 hand reach plausible by source arithmetic. Essential field names, illustrative health/Block and complete type/number/target intent remain permanently live at12px+, with natural height measurement and a240px width cap. The collapsed dossier holds supplemental explanation/geometry, not the essential facts. This is a sensible source layout direction, not actual hand visibility, readability or tactical input acceptance.

One deterministic source limit remains: enemy body.top=64+4=68native; above-readout top=68−8−naturalHeightCSS/2. Any measured readout taller than120CSS pixels becomes negative. Default104px reservation fits at top8, but extra name/intent wrapping or larger text can exceed that limit. Merely increasing bottom scene.height cannot expose content above scroll origin. Protect the measured upper margin and move art/readout together or reserve a measured row, retaining complete facts and honest growth. Do not clip essential text to preserve480px. This is source arithmetic under allowed taller metrics, not a claimed observed normal-browser failure.

At3× art alone720px plus UI is intentionally a larger scroll study. The three study buttons have unmodeled rule costs and static stage changes. They are not150px game cards, a deck, drag/play feedback, legal actions or saves. Changing research stage does not automatically open the dossier; Inspect explicitly opens it without forced focus/scroll. Actual native focus, viewport scrolling and large-text behavior still need examination. No motion clock/RAF, timed arrival, READY transition, command resolution or audio is present; reduced motion is static by design. Disposal/fallback remain source contracts.

## Next evidence and decision

Preserve this freeze and all r1/r2/r3/draft/reference evidence. Improve canine neck/jaw/support and hunter stance/material identity in a separate author-owned revision. Resolve above-readout negative-top geometry before integrating longer real names/intents. Art quality remains rejection-capable; correct source and larger figures do not force selection.

A small future actual phase could inspect default2× READY with full live cards/readouts at1440×900, choose Contact with native select, traverse native Tab/Enter Inspect and check point owner, then close under fresh unchanged640MiB total+512MiB reserve guard. Longer-text/3× scope can be a separate short phase if useful and admitted. No browser is currently granted and none launched by this reviewer. No exhaustive mobile matrix or parallel game page.

Even a static lab layout pass would not establish first-binding fun or playable integration. A later frozen game stage needs actual earned binding→READY→legal command with readable cost/rules, canonical UID/occurrence ownership, full facts, corpse/newborn retention, native cancellation/focus, save/reload and real contact/audio timing. No game promotion, human enjoyment, AAA/platform/native or retirement approval follows.
