import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
const baseline='/workspace/scratch/standard-sol-pixel-foundation-author-r4';
const candidate='/workspace/scratch/pixel-height-growth-root-author-r2/geometry.js';
const bytes=fs.readFileSync(candidate);
assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),'6484cf721c7428bcf6a144c92a76ad9d8b37e2108011d2ca5f81201a4c0c224b');
const old=await import(pathToFileURL(baseline+'/geometry.js'));
const art=await import(pathToFileURL(baseline+'/sprites.js'));
const source=bytes.toString().replace("'./sprites.js'",JSON.stringify(pathToFileURL(baseline+'/sprites.js').href));
const fixed=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const rows=[];
for(const phase of old.PHASES)for(const scale of [2,3]){
 const a=old.layoutScene(phase,scale),b=fixed.layoutScene(phase,scale);
 assert.deepEqual(b,a);rows.push({phase,scale,case:'default unchanged'});
 for(const height of [120,121,180,181,200,1000]){
  const before=old.layoutScene(phase,scale,{skeleton:height}),after=fixed.layoutScene(phase,scale,{skeleton:height});
  if(before.units.find(u=>u.id==='skeleton').readout.top>=0)assert.deepEqual(after,before);
  for(const u of after.units.filter(u=>u.visible)){
   assert(u.slot.top>=0);assert(u.readout.top>=0);
   assert(u.origin.every(Number.isInteger));assert(Number.isInteger(u.body.top));
   assert(u.slot.top+u.slot.height<=after.height);
   const actor=art.ART.actors[u.id];
   let first;
   for(let y=0;y<actor.height&&!first;y++)for(let x=0;x<actor.width;x++)if(actor.frames[u.frame][y][x]!=='0'){first=[x,y];break;}
   // Shared geometry keeps painter-order alpha inspection invariant after relocation.
   const prior=before.units.find(v=>v.id===u.id);
   assert.equal(fixed.ownerAt(after,u.origin[0]+first[0],u.origin[1]+first[1]),old.ownerAt(before,prior.origin[0]+first[0],prior.origin[1]+first[1]));
  }
  if(after.contact){
   assert(after.contact.point.every(Number.isInteger));
   const attacker=after.units.find(u=>u.id==='hound'),target=after.units.find(u=>u.id==='skeleton');
   assert.deepEqual(after.contact.point,[attacker.origin[0]+art.ART.scene.contactActor[0],attacker.origin[1]+art.ART.scene.contactActor[1]]);
   assert.deepEqual(after.contact.point,[target.origin[0]+art.ART.scene.contactTarget[0],target.origin[1]+art.ART.scene.contactTarget[1]]);
  }
  rows.push({phase,scale,case:'full tall intent reachable',readoutCSSHeight:height,fieldHeight:after.height});
 }
}
console.log(JSON.stringify({status:'PASS',cases:rows.length,rows,qualification:'Actual Node source geometry/alpha invariants only; no browser text measurement, painting, game integration, art acceptance or human fun.'},null,2));
