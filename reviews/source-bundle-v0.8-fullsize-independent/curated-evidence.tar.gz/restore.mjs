import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { verifyBundle } from '/workspace/scratch/release-bundle-v07/candidate-r2/source-bundle.mjs';
import { sha256File } from '/workspace/scratch/release-bundle-v07/candidate-r2/sha256-file.mjs';
const out = '/workspace/scratch/release-bundle-fullsize-independent-v07-r2';
const root = '/workspace/Roguelike-deckbuilder';
const bundle = '/tmp/hollowpact-v07-bundle-preflight-y4st1n0p/source.bundle';
const commit = 'b065d1044c9486b616f2eb2e95021de18c349ab7';
const expected = '04c31e64dab1b8503746b452717f6cea7a806135ec07c0fa4bcd03d65ab7561c';
const temporary = process.argv[2];
assert(temporary?.startsWith('/tmp/hollowpact-fullsize-independent-r2-'));
assert(!bundle.startsWith(temporary + '/'));
const started = Date.now();
const hash = data => createHash('sha256').update(data).digest('hex');
const write = (name, data) => fs.writeFileSync(path.join(out, name), data, { flag: 'wx' });
const git = (repo, args) => execFileSync('git', args, { cwd: repo, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
const protectedPaths = [
 '/workspace/scratch/release-bundle-v07/preflight-verified.json',
 '/workspace/scratch/release-bundle-v07/preflight-canonical-index.json',
 '/workspace/scratch/release-bundle-independent-v07/REVIEW.md',
 '/workspace/scratch/release-bundle-independent-v07/full-preflight-r2-failure.json',
 '/workspace/scratch/release-bundle-v07/candidate-r2/source-bundle.mjs',
 '/workspace/scratch/release-bundle-v07/candidate-r2/verify-bundle-tree.py',
 '/workspace/scratch/release-bundle-v07/candidate-r2/sha256-file.mjs',
];
try {
 const originals = Object.fromEntries(await Promise.all(protectedPaths.map(async p => [p, await sha256File(p)])));
 assert.equal(originals[protectedPaths[4]], '7d9af128cbe7d9bf2f30e9e3b8a1ab2aeb1f911346b48382df075a5136e38315');
 assert.equal(originals[protectedPaths[5]], 'd5030d125819c2d87a681013361b2ed69caa9d2d7b46d60d327c11857202cc96');
 assert.equal(fs.statSync(bundle).size, 1526523777);
 assert.equal(await sha256File(bundle), expected);
 const proof = await verifyBundle(root, commit, bundle, temporary);
 assert.equal(proof.format, 'git-bundle-v2');
 assert.equal(proof.reachableObjectCount, 3586);
 assert.equal(proof.identity.commit, commit);
 assert.equal(proof.identity.tree, 'aaed2c69d8543f020a863afc3b969cee3148d339');
 assert.equal(proof.identity.files.length, 5904);
 const author = JSON.parse(fs.readFileSync(protectedPaths[0], 'utf8'));
 assert.deepEqual(proof.identity, author.identity);
 assert.deepEqual(proof.refs, author.refs);
 const canonical = proof.identity.files.filter(f => f.path.startsWith('reviews/'));
 assert.equal(canonical.length, 3132);
 const bare = path.join(temporary, 'restored.git');
 const objects = git(bare, ['cat-file', '--batch-all-objects', '--batch-check=%(objectname) %(objecttype) %(objectsize)']);
 assert.equal(objects.trim().split('\n').length, 3586);
 const sourceClosure = git(root, ['rev-list', '--objects', '--no-object-names', commit]).trim().split('\n').sort();
 const restoredClosure = objects.trim().split('\n').map(s => s.split(' ')[0]).sort();
 assert.deepEqual(restoredClosure, sourceClosure);
 const refs = git(bare, ['show-ref']);
 assert.equal(refs.trim(), commit + ' refs/heads/codex/lanternbound-production');
 assert.equal(git(bare, ['symbolic-ref', 'HEAD']).trim(), 'refs/heads/codex/lanternbound-production');
 const inventory = [];
 function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a,b) => a.name.localeCompare(b.name))) {
   const p = path.join(dir, entry.name), st = fs.lstatSync(p);
   if (entry.isDirectory()) walk(p);
   else { assert(entry.isFile()); inventory.push({ path: path.relative(temporary, p), bytes: st.size, mode: st.mode & 0o777 }); }
  }
 }
 walk(temporary);
 for (const row of inventory) row.sha256 = await sha256File(path.join(temporary, row.path));
 const body = Buffer.from(JSON.stringify({ ...proof, objectInventory: objects.trim().split('\n'), restoredFileInventory: inventory }) + '\n');
 const packed = gzipSync(body, { level: 9 });
 write('full-restore-proof.json.gz', packed);
 const finalOriginals = Object.fromEntries(await Promise.all(protectedPaths.map(async p => [p, await sha256File(p)])));
 assert.deepEqual(finalOriginals, originals);
 assert.equal(await sha256File(bundle), expected);
 const receipt = {
  status: 'PASS', scope: 'Independent full-size restoration supplement of original b065 research bundle through exact frozen R2 helper; not current fdb official milestone source or production promotion.',
  sourceCommit: commit, sourceTree: proof.identity.tree, bundlePath: bundle, bundleBytes: fs.statSync(bundle).size, bundleSHA256: expected,
  headerVersion: 2, reachableObjects: 3586, currentTreeBlobs: 5904, canonicalReviewBlobs: 3132,
  refs: proof.refs, symbolicHEAD: 'refs/heads/codex/lanternbound-production', prerequisites: 'None; fresh bare bundle verify/unbundle succeeded',
  strictFsckOutput: proof.fsckOutput, currentBlobComparison: 'Every mode, SHA1 OID, byte size and streamed raw SHA256 matches source and accepted author receipt',
  extraObjects: 0, closureSHA256: hash(sourceClosure.join('\n')+'\n'),
  compressedProof: { path: 'full-restore-proof.json.gz', bytes: packed.length, sha256: hash(packed), decompressedBytes: body.length, decompressedSHA256: hash(body) },
  protectedEvidenceHashesBeforeAndAfter: originals,
  restoredBareInventoryFiles: inventory.length, restoredBareBytes: inventory.reduce((n,x)=>n+x.bytes,0),
  temporaryDerivedBarePath: bare, originalBundleRetained: true, elapsedSeconds: (Date.now()-started)/1000,
 };
 write('full-restore-receipt.json', JSON.stringify(receipt, null, 2)+'\n');
 // Only this new derived bare directory may be removed, after complete proof/inventory.
 assert.equal(fs.realpathSync(bare), bare);
 fs.rmSync(bare, { recursive: true, force: false });
 assert(!fs.existsSync(bare));
 write('derived-bare-cleanup.json', JSON.stringify({ removedOnlyOwnDerivedBare: bare, fullProofWrittenBeforeRemoval: true, inventoryFiles: inventory.length, inventoryBytes: receipt.restoredBareBytes, originalBundleStillPresent: fs.statSync(bundle).size === 1526523777, proofSHA256: hash(packed) }, null, 2)+'\n');
 console.log(JSON.stringify({ status: 'PASS', elapsedSeconds: receipt.elapsedSeconds, objects: 3586, currentBlobs: 5904, inventoryBytes: receipt.restoredBareBytes, compressedBytes: packed.length }));
} catch (error) {
 write('FAILURE.json', JSON.stringify({ status: 'WITHHELD', error: String(error), stack: error.stack, retainedTemporaryPath: temporary, originalBundle: bundle, scope: 'Independent full-sized restore did not complete; preserve original input and own failure material.' }, null, 2)+'\n');
 throw error;
}
