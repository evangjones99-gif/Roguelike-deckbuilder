import gzip,hashlib,json,pathlib
out=pathlib.Path('/workspace/scratch/release-bundle-fullsize-independent-v07-r2')
indexpath=pathlib.Path('/workspace/scratch/release-bundle-v07/preflight-canonical-index.json')
proof=json.loads(gzip.decompress((out/'full-restore-proof.json.gz').read_bytes()))
index=json.loads(indexpath.read_bytes())
assert index['sourceCommit']==proof['sourceCommit']=='b065d1044c9486b616f2eb2e95021de18c349ab7'
restored={r['path']:r for r in proof['identity']['files']}
seen=set()
for row in index['files']:
 assert row['path'] not in seen
 seen.add(row['path'])
 assert row['path'].startswith('reviews/')
 actual=restored[row['path']]
 for key in ('bytes','sha256','gitBlob'):assert row[key]==actual[key],(row['path'],key)
assert seen=={p for p in restored if p.startswith('reviews/')}
pairs=[]
for pair in index['rawGzipPairs']:
 assert pair['compressedPath'] in restored
 raw=restored.get(pair['rawPath'])
 if raw is not None:assert raw['bytes']==pair['rawBytes'] and raw['sha256']==pair['rawSHA256']
 pairs.append({'rawPath':pair['rawPath'],'compressedPath':pair['compressedPath'],'rawPresentInCurrentTree':raw is not None,'compressedBytesMatchedViaCanonicalRows':True})
receipt={'status':'PASS','indexPath':str(indexpath),'indexSHA256':hashlib.sha256(indexpath.read_bytes()).hexdigest(),'sourceCommit':proof['sourceCommit'],'canonicalIndexRowsMatchedToFreshRestoredRawBlobs':len(seen),'priorAuditPairMetadata':pairs,'scope':'All accepted canonical index file OID/SHA256/size rows match this independently restored full tree. Prior audit raw counterparts absent from the current tree are not claimed restored. No new gzip expansion or ZIP audit execution is claimed.'}
with (out/'canonical-index-comparison-r2.json').open('x')as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
