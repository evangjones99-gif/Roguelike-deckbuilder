import hashlib,json,os,pathlib,signal,subprocess,tempfile,time
out=pathlib.Path('/workspace/scratch/release-bundle-fullsize-independent-v07-r2')
bundle=pathlib.Path('/tmp/hollowpact-v07-bundle-preflight-y4st1n0p/source.bundle')
def free(p):
 s=os.statvfs(p);return s.f_bavail*s.f_frsize
size=bundle.stat().st_size
required=2*size+512*1024*1024
before={'bundleBytes':size,'temporaryAvailableBytes':free('/tmp'),'durableAvailableBytes':free('/workspace'),'requiredConservativeTemporaryBytes':required,'budget':'Two full bundle-size derived allocations plus 512 MiB safety margin; original input is already present and excluded from new-allocation budget. Exclusive heavy-operation coordination with root required.','utcStart':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
if before['temporaryAvailableBytes']<required:raise RuntimeError('Refuse restore: conservative temporary reserve unavailable')
temp=tempfile.mkdtemp(prefix='hollowpact-fullsize-independent-r2-',dir='/tmp')
before['ownTemporaryPath']=temp
with (out/'capacity-before.json').open('x') as f:json.dump(before,f,indent=2);f.write('\n')
samples=[];aborted=False
with (out/'execution.log.txt').open('x') as log:
 p=subprocess.Popen(['node',str(out/'restore.mjs'),temp],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  remaining=free('/tmp');samples.append({'monotonic':time.monotonic(),'temporaryAvailableBytes':remaining})
  if remaining<256*1024*1024:
   aborted=True;os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(.1)
 rc=p.wait()
summary={'exitCode':rc,'abortedForCapacityMargin':aborted,'sampleIntervalSeconds':.1,'sampleCount':len(samples),'minimumObservedTemporaryFreeBytes':min(s['temporaryAvailableBytes']for s in samples),'startAvailableBytes':before['temporaryAvailableBytes'],'maximumObservedNetAllocationBytes':before['temporaryAvailableBytes']-min(s['temporaryAvailableBytes']for s in samples),'afterTemporaryAvailableBytes':free('/tmp'),'afterDurableAvailableBytes':free('/workspace'),'scope':'Sampled free-space observations, not proof of minimal peak requirement or a reservation enforced against other users.'}
with (out/'capacity-observed.json').open('x')as f:json.dump(summary,f,indent=2);f.write('\n')
with (out/'capacity-samples.json').open('x')as f:json.dump(samples,f,separators=(',',':'));f.write('\n')
print(json.dumps(summary))
raise SystemExit(rc)
