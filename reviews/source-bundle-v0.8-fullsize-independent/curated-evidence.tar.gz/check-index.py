import gzip,hashlib,json,pathlib
out=pathlib.Path('/workspace/scratch/release-bundle-fullsize-independent-v07-r2')
indexpath=pathlib.Path('/workspace/scratch/release-bundle-v07/preflight-canonical-index.json')
proofbytes=gzip.decompress((out/'full-restore-proof.json.gz').read_bytes())
proof=json.loads(proofbytes)
index=json.loads(indexpath.read_bytes())
assert index['sourceCommit']==proof['sourceCommit']=='b065d1044c9486b616f2eb2e95021de18c349ab7'
restored={r['path']:r for r in proof['identity']['files']}
seen=set()
for row in index['files']:
 assert row['path'] not in seen
 seen.add(row['path'])
 assert row['path'].startswith('reviews/')
 actual=restored[row['path']]
 for key in ('bytes','sha256','gitBlob'):assert row[key]==actual[key],(row['path'],key)
assert seen=={p for p in restored if p.startswith('reviews/')}
for pair in index['rawGzipPairs']:
 raw=restored[pair['rawPath']]
 assert raw['bytes']==pair['rawBytes'] and raw['sha256']==pair['rawSHA256']
 assert pair['compressedPath'] in restored
receipt={'status':'PASS','indexPath':str(indexpath),'indexSHA256':hashlib.sha256(indexpath.read_bytes()).hexdigest(),'sourceCommit':proof['sourceCommit'],'canonicalIndexRowsMatchedToFreshRestoredRawBlobs':len(seen),'rawPairCounterpartIdentitiesMatched':len(index['rawGzipPairs']),'scope':'All accepted canonical index file OID/SHA256/size rows match this independently restored full tree; existing raw-pair raw identities match. No new gzip expansion or ZIP execution is claimed.'}
with (out/'canonical-index-comparison.json').open('x')as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
