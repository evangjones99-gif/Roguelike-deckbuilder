"""Small independent coverage supplement; only exact source/control bytes."""
import pathlib,os,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_DATA,(25165824,25165824))
A=pathlib.Path('/workspace/scratch/standard-sol-tactile-r3-r4-preservation-author-r1')
D=pathlib.Path(__file__).resolve().parent
cg=pathlib.Path('/sys/fs/cgroup')
def guard():
    head=int((cg/'memory.max').read_text())-int((cg/'memory.current').read_text())
    assert head>=562036736
    return head
def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        before=os.fstat(fd);parts=[];length=0
        while b:=os.read(fd,32768):parts.append(b);length+=len(b)
        assert length<=524288 and before==os.fstat(fd)
        return b''.join(parts)
    finally:os.close(fd)
initial=guard();delta=json.loads(read(A/'DELTA-LEDGER.json'))
r4=json.loads(read(A/'body/workspace/scratch/owner-tactile-pc-r4-runtime-freeze-r1.json'))
r3=json.loads(read(A/'body/workspace/scratch/owner-tactile-r3-runtime-freeze-r1.json'))
baseline=json.loads(read(A/'body/workspace/Roguelike-deckbuilder/reviews/owner-playtest-ux-overhaul-2026-10-01/preserved-earned-2f1-independent-r1/body/tmp/standard-sol-owner-ux-gameplay-independent-r1/AUDIT-after.json'))['variants']['baseline']
digests={}
for name,pins,expected in [('r4',r4['inputs'],r4['sourceDigest']),('r3',r3['inputs'],r3['sourceDigest']),('baseline',{k:v['sha256'] for k,v in baseline['inputs'].items()},baseline['sourceDigest'])]:
    digest=hashlib.sha256(json.dumps(dict(sorted(pins.items())),separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    assert digest==expected;digests[name]=digest
closure=[]
for row in delta['closureChecks']:
    matches=[]
    for k in ('baselineReference','r3Reference'):
        p=row.get(k)
        if p is not None:
            assert hashlib.sha256(read(p)).hexdigest()==row['sha256'];matches.append(p)
    closure.append(dict(relative=row['relative'],exactSmallSourceReferences=matches))
tests=[]
for row in delta['testSourceChecks']:
    assert hashlib.sha256(read(row['r3Original'])).hexdigest()==row['sha256'];tests.append(row['r3Original'])
oracle=json.loads(read(A/'body/workspace/scratch/owner-tactile-pc-oracle-r4/MANIFEST.json'))
assert len(oracle['inputs'])==3
for row in oracle['inputs']:assert r4['inputs'][row['path']]==row['sha256']
assert hashlib.sha256(read(A/'body/workspace/scratch/owner-tactile-pc-oracle-r4/engine.mjs')).hexdigest()==oracle['output']['sha256']
result=dict(status='PASS supplemental recorded closure/reference pins',recomputedRuntimeDigests=digests,closureChecks=closure,r3TestSourceChecks=tests,oracleFrozenInputPinsMatched=3,oracleOutputPinMatched=True,oracleExecuted=False,initialHeadroom=initial,finalHeadroom=guard(),unchangedLargeROOTBodiesRead=False)
with (D/'SUPPLEMENT.json').open('xb') as f:f.write((json.dumps(result,indent=2)+'\n').encode());f.flush();os.fsync(f.fileno())
print(json.dumps({'status':result['status'],'digests':digests,'sourceChecks':len(closure)+len(tests)}))
