"""Independent bounded archival byte/reference audit. No original helper is run."""
import os,pathlib,json,hashlib,stat,tarfile,resource,time,collections
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
HERE=pathlib.Path(__file__).resolve().parent
AUTHOR=pathlib.Path('/workspace/scratch/standard-sol-tactile-r3-r4-preservation-author-r1')
CANON=pathlib.Path('/workspace/Roguelike-deckbuilder/reviews/tactile-pc-prototype-source-and-failures-2026-10-01-r1')
EXPECTED='ceea39da5ec77172f4976b61876d62bdcf94cae180d80db22a2ab3bf6d8e395f'
def guard():
    cg=pathlib.Path('/sys/fs/cgroup');maximum=int((cg/'memory.max').read_text());current=int((cg/'memory.current').read_text())
    own={x.split(':')[0]:int(x.split()[1])*1024 for x in pathlib.Path('/proc/self/status').read_text().splitlines() if x.startswith(('VmRSS:','VmHWM:'))}
    assert maximum-current>=536*1048576 and max(own.values())<=24*1048576,'independent resource guard'
    return dict(current=current,maximum=maximum,headroom=maximum-current,own=own)
def meta(s):return dict(dev=s.st_dev,ino=s.st_ino,mode=s.st_mode,size=s.st_size,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,atime_ns=s.st_atime_ns,ctime_ns=s.st_ctime_ns)
def read(p,collect=False):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC)
    try:
        before=os.fstat(fd);assert stat.S_ISREG(before.st_mode) and before.st_size<=16*1048576
        assert not collect or before.st_size<=524288
        h=hashlib.sha256();parts=[];count=0
        while b:=os.read(fd,65536):
            h.update(b);count+=len(b)
            if collect:parts.append(b)
        assert count==before.st_size and meta(before)==meta(os.fstat(fd))==meta(os.stat(p,follow_symlinks=False)),'FD/path drift'
        row=dict(path=str(p),bytes=count,sha256=h.hexdigest(),metadata=meta(before))
        return (row,b''.join(parts)) if collect else row
    finally:os.close(fd)
def js(p):return json.loads(read(p,True)[1])
def write(name,value):
    b=(json.dumps(value,indent=2)+'\n').encode();assert len(b)<=1048576
    with (HERE/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())

try:
    admission=guard();v=os.statvfs(HERE);assert v.f_bavail*v.f_frsize>=2*1048576
    canonical_row,canonical_raw=read(CANON/'PRESERVATION.json',True);manifest=json.loads(canonical_raw)
    assert manifest['bytes']==1079828 and manifest['sha256']==EXPECTED and len(manifest['files'])==145
    expected={row['member']:row for row in manifest['files']};assert len(expected)==145
    archive=read(CANON/'EVIDENCE.tar.gz');assert archive['bytes']==1079828 and archive['sha256']==EXPECTED
    members=[];seen=set();total=0
    fd=os.open(CANON/'EVIDENCE.tar.gz',os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        with os.fdopen(fd,'rb',closefd=False) as stream:
            with tarfile.open(fileobj=stream,mode='r|gz') as tar:
                for member in tar:
                    parts=pathlib.PurePosixPath(member.name).parts
                    assert member.isfile() and not member.name.startswith('/') and '..' not in parts and member.name not in seen
                    assert member.name in expected and 0<=member.size<=16*1048576
                    seen.add(member.name);total+=member.size;assert total<=8*1048576
                    wanted=expected[member.name];assert member.size==wanted['bytes']
                    body=tar.extractfile(member);h=hashlib.sha256();count=0
                    while b:=body.read(65536):h.update(b);count+=len(b)
                    assert count==member.size and h.hexdigest()==wanted['sha256'],'archive body mismatch'
                    members.append(dict(member=member.name,bytes=count,sha256=h.hexdigest(),regular=True))
                    guard()
        assert meta(before)==meta(os.fstat(fd))==meta(os.stat(CANON/'EVIDENCE.tar.gz',follow_symlinks=False))
    finally:os.close(fd)
    assert seen==set(expected)
    retained=[]
    for wanted in manifest['files']:
        row=read(wanted['original']);assert row['bytes']==wanted['bytes'] and row['sha256']==wanted['sha256'],'sealed original mismatch'
        retained.append(row);guard()
    author_manifest=js(AUTHOR/'AUTHOR-MANIFEST.json');pres=js(AUTHOR/'PRESERVATION.json');intake=js(AUTHOR/'INPUT-MANIFEST.json');delta=js(AUTHOR/'DELTA-LEDGER.json')
    assert author_manifest['bodyCount']==pres['files'].__len__()==intake['bodyCount']==134
    assert author_manifest['bodyBytes']==intake['plannedBodyBytes']==2253418
    planned={row['original']:row for row in intake['files']};assert len(planned)==134
    bodycopies=[];atime_deltas=[]
    for row in pres['files']:
        assert row['original'] in planned and row['plannedMetadata']==planned[row['original']]['plannedMetadata']
        assert row['sourceBeforeAndAfterExact']==row['plannedMetadata'] and row['directStreamingReadbackEqual'] is True
        original=read(row['original']);copy=read(row['copy'])
        assert original['bytes']==copy['bytes']==row['bytes'] and original['sha256']==copy['sha256']==row['sha256']==row['expectedSHA256']
        assert copy['metadata']==row['copyBeforeAndAfterExact'],'retained copy metadata changed'
        for k in original['metadata']:
            if k=='atime_ns':
                if original['metadata'][k]!=row['sourceBeforeAndAfterExact'][k]:atime_deltas.append(dict(path=row['original'],recorded=row['sourceBeforeAndAfterExact'][k],now=original['metadata'][k]))
            else:assert original['metadata'][k]==row['sourceBeforeAndAfterExact'][k],'original identity/metadata drift '+row['original']+' '+k
        for k in ('mode','uid','gid','atime_ns','mtime_ns'):assert copy['metadata'][k]==row['sourceBeforeAndAfterExact'][k]
        sealed=expected[row['copy'].lstrip('/')];assert sealed['sha256']==row['sha256'] and sealed['bytes']==row['bytes']
        bodycopies.append(dict(original=original,copy=copy));guard()
    assert sum(row['copy']['bytes'] for row in bodycopies)==2253418
    for row in author_manifest['topLevelFiles']:
        sealed=expected[str(AUTHOR/row['name']).lstrip('/')];assert sealed['sha256']==row['sha256'] and sealed['bytes']==row['bytes']
    frozen4=js(AUTHOR/'body/workspace/scratch/owner-tactile-pc-r4-runtime-freeze-r1.json')
    frozen3=js(AUTHOR/'body/workspace/scratch/owner-tactile-r3-runtime-freeze-r1.json')
    baseline=js(AUTHOR/'body/workspace/Roguelike-deckbuilder/reviews/owner-playtest-ux-overhaul-2026-10-01/preserved-earned-2f1-independent-r1/body/tmp/standard-sol-owner-ux-gameplay-independent-r1/AUDIT-after.json')['variants']['baseline']
    assert frozen4['sourceDigest']==delta['r4SourceDigest']=='27239b7ea537c4694e345a28f8b8ff94dcf0aac4b50394d81396ceecbc9bea8f'
    assert frozen3['sourceDigest']==delta['r3SourceDigest']=='f8f73c598434903f4fca0f4b87e01c0412bc93ab935b6c78575aecae80325c2f'
    assert baseline['sourceDigest']==delta['baselineDigest']=='801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029'
    summary={}
    for version,freeze in [('r4',frozen4),('r3',frozen3)]:
        summary[version]={}
        for domain in ('inputs','outputs'):
            ledger=delta[version][domain];pins=freeze[domain];assert len(ledger)==len(pins)==(87 if domain=='inputs' else 56)
            assert {r['relative']:r['sha256'] for r in ledger}==pins
            counts=dict(collections.Counter(r['kind'] for r in ledger));summary[version][domain]=counts
            for row in ledger:
                resolved=row['reference'] if row['kind']=='exact_R4_body_or_baseline_reference' else row
                assert resolved['sha256']==row['sha256']
                if resolved['kind']=='retained_ROOT_baseline_reference':
                    key=resolved['relative'] if domain=='inputs' else 'dist/'+resolved['relative']
                    assert baseline[domain][key]['sha256']==resolved['sha256']
                    assert os.path.isfile(resolved['original']) # metadata only, no unchanged body read
                else:
                    assert resolved['copy'].lstrip('/') in expected and expected[resolved['copy'].lstrip('/')]['sha256']==resolved['sha256']
    assert summary['r4']['inputs']=={'retained_ROOT_baseline_reference':74,'copied_delta':13}
    assert summary['r4']['outputs']=={'retained_ROOT_baseline_reference':52,'copied_delta':4}
    assert summary['r3']['inputs']=={'exact_R4_body_or_baseline_reference':86,'copied_R3_delta':1}
    assert summary['r3']['outputs']=={'exact_R4_body_or_baseline_reference':53,'copied_R3_delta':3}
    assert len(pres['unchangedBaselineReferences'])==126
    assert len(delta['closureChecks'])==3 and len(delta['testSourceChecks'])==5
    for row in delta['closureChecks']+delta['testSourceChecks']:
        archivepath=str(AUTHOR/'body')+row['copiedOriginal']
        assert expected[archivepath.lstrip('/')]['sha256']==row['sha256']
    final=guard()
    result=dict(status='ACCEPT bounded byte preservation and explicit reference coverage only',archive=archive,canonicalManifest=canonical_row,archiveMemberCount=len(members),archiveRawBytes=total,archiveMembers=members,retainedSealedOriginals=retained,originalAndCopyChecks=bodycopies,legitimateLaterOriginalAtimeDeltas=atime_deltas,coverage=summary,closureBodyCount=3,testSourceBodyCount=5,unchangedROOTReferences=126,unchangedROOTBodiesFreshlyRead=False,completeStandaloneCapsule=False,capturesDecodedOrViewed=0,originalHelperExecutions=0,GitCommands=0,NodeOrBrowserStarted=False,initialGuard=admission,finalGuard=final,independence='No renderer/module/host implementation authored; prior unrelated retirement, preservation, PC plan and cache-proposal tooling only')
    write('RESULT.json',result)
    print(json.dumps({'status':result['status'],'memberCount':len(members),'rawBytes':total,'originalsChecked':len(retained),'sourceCopiesChecked':len(bodycopies),'laterAtimeDeltas':len(atime_deltas),'finalGuard':final}))
except BaseException as e:
    write('FAILURE.json',dict(errorType=type(e).__name__,error=str(e),qualification='Incomplete; no acceptance. Preserve failure before a new method revision.'))
    raise
