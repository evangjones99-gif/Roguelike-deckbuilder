from pathlib import Path
import os,json,hashlib,resource,stat
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
P=Path('/workspace/scratch/r3-two-raw-retirement-post-independent-r1')
def pin(path):
 p=Path(path);a=os.lstat(p);assert stat.S_ISREG(a.st_mode)
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);h=hashlib.sha256();n=0
 try:
  assert os.fstat(fd)==a
  for b in iter(lambda:os.read(fd,65536),b''):h.update(b);n+=len(b)
  assert os.fstat(fd)==a==os.lstat(p)
 finally:os.close(fd)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':n}
def load(path):
 q=pin(path)
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 with os.fdopen(fd) as f:d=json.load(f)
 return q,d
def save(name,d):
 with (P/name).open('x') as f:json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
q,d=load(P/'PROOF.json');guards=load(P/'PROOF-GUARD/RESULT.json')[1]
assert guards['exit_code']==0 and guards['failure'] is None and guards['memory_events_before']==guards['memory_events_after']
assert d['all303BlobsAnd318LogicalRowsVerified'] and d['currentFull88_56BodiesVerified'] and len(d['twoKnownOldPathsAbsent'])==2
assert len(d['knownRetainedActualFilesFullBodiesAndMetadata'])==26 and d['fourOriginalJPEGCount']==4
assert d['protectedZipBodyNeverOpened'] and d['protectedZipFullStatBefore']==d['protectedZipFullStatAfter']
assert d['ownMaxRSSBytes']<24*1048576 and d['noRestoreGitCleanupNodeNativeImageBuild']
controls=[]
for key in ['proposal','beforeGate','confirmedPush','producer','actionBefore','actionProducerCopy','actionResult','actionJournal']:
 old=d[key];fresh=pin(old['path']);assert fresh==old;controls.append(fresh)
for old in d['sourceHoldMapCompleteCallerPins']:
 assert pin(old['path'])==old;controls.append(old)
for g in d['RootGuardControls']:
 for key in ['admission','result','executionLog']:assert pin(g[key]['path'])==g[key]
for path in d['twoKnownOldPathsAbsent']:
 try:os.lstat(path);raise AssertionError('retired path returned')
 except FileNotFoundError:pass
keys=list(d['protectedZipFullStatAfter']);z=os.lstat('/workspace/scratch/retained-original-archives/preflight-bdf273-original-r4.zip')
assert {k:getattr(z,k) for k in keys}==d['protectedZipFullStatAfter']
for old in d['knownRetainedActualFilesFullBodiesAndMetadata']:
 s=os.lstat(old['path']);assert {k:getattr(s,k) for k in old['metadata']}==old['metadata']
cap=d['capsuleFullEncoding'];fresh=pin(cap['path']);assert all(fresh[k]==cap[k] for k in fresh)
proof_guard={k:pin(P/'PROOF-GUARD'/k) for k in ['ADMISSION.json','RESULT.json','EXECUTION.log']}
gate={'decision':'ACCEPT independent POST of exact two R3 loose JSON retirement; no further action authority',
 'proposal':d['proposal'],'beforeGate':d['beforeGate'],'confirmedPush':d['confirmedPush'],'producer':d['producer'],'actionResult':d['actionResult'],'actionBefore':d['actionBefore'],'actionJournal':d['actionJournal'],
 'proof':q,'proofGuard':proof_guard,'review':pin(P/'REVIEW.md'),'reader':pin(P/'verify.py'),'sealer':pin(P/'seal.py'),
 'method':d['sourceHoldMapCompleteCallerPins'][0],'currentHold':d['sourceHoldMapCompleteCallerPins'][4],'selectedMap':d['sourceHoldMapCompleteCallerPins'][5],
 'twoKnownLoosePathsAbsent':d['twoKnownOldPathsAbsent'],'fullArchiveBlobBodies':303,'exactLogicalRows':318,'twoOriginalLogicalBodies':d['twoExactArchivedRawMappings'],
 'selectedFullBodies':144,'selectedCounts':{'inputs':88,'outputs':56},'knownRetainedFilesFullBodiesAndFreshStableMetadata':26,'originalJPEGs':4,
 'protectedZIPFullStatExact':True,'protectedZIPBodyNeverOpened':True,'journalEntries':4,'perLeafDurablePrefixVerified':True,
 'grossAllocationBytes':5005312,'historicalPreResultWindowGainBytes':4984832,'gainLimit':d['gainQualification'],
 'metadataLimit':'Fresh retained-file metadata stable during this proof; original removed inodes/timestamps unavailable, not automatic metadata rollback.',
 'historicalReaderLimit':'Hardcoded historical gameplay/preservation readers require exact NEW reconstructed paths and NEW adapted readers/mapping before replay; restore unexecuted.',
 'coverageLimit':d['preservationLimits'],'nativeAdmission':'Root-reported 72925184 bytes below native 73924608 and outer 73400320; no native authority or attempt from this review.',
 'atomicityLimit':'Two per-leaf durable journal pairs; no all-two atomicity, automatic rollback, universal future consumer or exclusive global FD/mmap claim.',
 'failures':'No POST verifier failure observed; all earlier source/proof failures and receipts retained unchanged.',
 'proofOwnMaxRSSBytes':d['ownMaxRSSBytes'],'allocationBytes':96*1024,'authority':'POST verification only; no further cleanup/restoration/Git/publication/promotion/native/build authority.'}
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576;gate['sealOwnMaxRSSBytes']=rss
save('GATE.json',gate)
files=[]
for path in sorted(P.rglob('*')):
 if path.is_file() and 'SEAL-GUARD' not in path.parts:files.append(pin(path))
actual=sum(path.stat().st_size for path in P.rglob('*') if path.is_file())
receipt={'gate':pin(P/'GATE.json'),'stableFiles':files,'sealGuardAdmission':pin(P/'SEAL-GUARD/ADMISSION.json'),'bytesBeforeFinalReceipt':actual,'packetCapBytes':96*1024,'finalGuardOutputReserveBytes':8192,'ownMaxRSSBytes':rss,'allReaderFileDescriptorsClosed':True,'pendingProductionActions':False,'closureLimit':'Active seal guard EXECUTION.log and final RESULT excluded from immutable ledger; sealer closes normally before outer guard final RESULT is written, final guard completion checked separately.'}
encoded=(json.dumps(receipt,indent=2)+'\n').encode();assert actual+len(encoded)+8192<=96*1024
with (P/'FINAL-SEAL.json').open('xb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
fd=os.open(P,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({'gate':pin(P/'GATE.json'),'finalSeal':pin(P/'FINAL-SEAL.json'),'packetBytesNow':actual+len(encoded),'finalGuardReserve':8192,'ownMaxRSSBytes':rss,'allReaderFileDescriptorsClosed':True}))
