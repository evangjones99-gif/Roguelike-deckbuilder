from pathlib import Path
import os,json,hashlib,stat,resource,tarfile
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
S=Path('/workspace/scratch');R=Path('/workspace/Roguelike-deckbuilder');P=S/'r3-two-raw-retirement-post-independent-r1';A=S/'r3-two-archived-json-retirement-actual-root-r1'
KEYS=['st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_blocks','st_atime_ns','st_mtime_ns','st_ctime_ns']
def md(s):return {k:getattr(s,k) for k in KEYS}
def op(p):
 p=Path(p);fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  for part in p.parent.parts[1:]:
   assert part not in ('','.', '..');n=os.open(part,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=n
  return os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=fd)
 finally:os.close(fd)
def pin(p,body=False):
 p=Path(p);before=md(os.lstat(p));fd=op(p);h=hashlib.sha256();size=0;parts=[]
 try:
  assert stat.S_ISREG(before['st_mode']) and md(os.fstat(fd))==before;attrs={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)}
  for b in iter(lambda:os.read(fd,65536),b''):
   h.update(b);size+=len(b)
   if body:parts.append(b);assert size<300*1024
  assert md(os.fstat(fd))==before==md(os.lstat(p))
 finally:os.close(fd)
 q={'path':str(p),'sha256':h.hexdigest(),'bytes':size,'metadata':before,'xattrs':attrs};return (q,b''.join(parts)) if body else q
def simple(q):return {k:q[k] for k in ['path','sha256','bytes']}
def load(p):
 q,b=pin(p,True);return q,json.loads(b)
def digest(f):
 h=hashlib.sha256();n=0
 for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
 return h.hexdigest(),n
pp,e=load(S/'r3-two-raw-retirement-source-author-r1/PROPOSAL.json');assert pp['sha256']=='46a18623e87d07c6840de918225d38ac9937e050ac546ab842973488bcd1a7c0'
gp,g=load(S/'r3-two-raw-retirement-independent-r1/GATE.json');assert gp['sha256']=='5cc2ae0219710f2551e59ca6d8063d7587e5d8514eac2413ceb1ca9e486691a6'
pushp,push=load(S/'r3-two-raw-retirement-push-root-r1/PUSH-CONFIRMED.json');assert pushp['sha256']=='3b6e3672426d3fb209699ec7654ade9e0239ee3d33b67849fd205bc196325fa8'
jp,j=load(S/'r3-two-raw-retirement-producer-root-r1.json');assert jp['sha256']=='b7a5371df6efd47ddb876962057eb8594ac26841624ff05d99cad5ba7815301a'
bp,before=load(A/'BEFORE.json');rp,res=load(A/'RESULT.json');assert rp['sha256']=='3493ceecb6396448d04d79cefb43dee58d92831749cb0dc67f4d3d39be4673c0'
prod=pin(A/'PRODUCER.json');assert prod['sha256']==jp['sha256']
journalp,b=pin(A/'JOURNAL.jsonl',True);rows=[json.loads(l) for l in b.splitlines()]
assert push['confirmed'] and push['clean'] and push['remote']==push['commit']==j['commit']=='a0d5145de9fccccf816c5cdafce7883a84eac7b8'
assert push['gateSHA256']==j['gateSHA256']==gp['sha256'] and push['proposalSHA256']==j['proposalSHA256']==pp['sha256'] and j['pushSHA256']==pushp['sha256'] and j['oneActionOnly']
assert before['proposalSHA256']==pp['sha256'] and before['gateSHA256']==gp['sha256'] and before['judgmentSHA256']==jp['sha256'] and before['pushSHA256']==pushp['sha256']
controls=[]
for key in ['method','publisher','producer','restore','currentHold','selectedMap','completePreservationGate','latestCallerGate']:
 old=g[key];q=pin(old['path']);assert (q['sha256'],q['bytes'])==(old['sha256'],old['bytes']);controls.append(simple(q))
assert controls[0]['sha256']==push['methodSHA256']==j['methodSHA256'] and controls[-1]['sha256']==push['callerGateSHA256']==j['callerGateSHA256']
D=R/'reviews/r3-two-archived-json-retirement-2026-10-02';assert pin(D/'independent/GATE.json')['sha256']==gp['sha256'] and pin(D/'root-controls'/Path(controls[0]['path']).name)['sha256']==controls[0]['sha256']
guards=[]
for suffix,work,samples in [('publication',256,18),('producer',64,1),('actual',64,3)]:
 root=S/('r3-two-raw-retirement-'+suffix+'-guard-root-r1');adp,ad=load(root/'ADMISSION.json');grp,gr=load(root/'RESULT.json')
 assert ad['admitted'] and ad['work']==work*1048576 and ad['reserve']==512*1048576 and gr['exit_code']==0 and gr['failure'] is None and len(gr['samples'])==samples and gr['memory_events_before']==gr['memory_events_after']
 guards.append({'kind':suffix,'admission':simple(adp),'result':simple(grp),'executionLog':simple(pin(root/'EXECUTION.log')),'samples':samples,'normal':True})
 if suffix=='actual':assert ad['command']==['python',controls[0]['path'],pp['path'],pp['sha256'],gp['path'],gp['sha256'],jp['path'],jp['sha256'],pushp['path'],pushp['sha256']]
assert pushp['metadata']['st_mtime_ns']<=jp['metadata']['st_mtime_ns']<=bp['metadata']['st_mtime_ns'] and len(rows)==4 and [r['utcNs'] for r in rows]==sorted(r['utcNs'] for r in rows)
assert res['normal'] and res['noOtherAction'] and res['protectedOriginalStatExact'] and res['capsuleAndCurrent88_56Exact']
raw=e['rawFiles'];root=S/'target-clear-ghost-comparison-actual-r3';assert len(raw)==2 and {q['path'] for q in raw}==set(res['retiredPaths'])
for i,q in enumerate(raw):
 assert Path(q['path']).parent==root
 try:os.lstat(q['path']);raise AssertionError('retired path present')
 except FileNotFoundError:pass
 z=before['rawFiles'][i];assert z['path']==q['path'] and z['sha256']==q['sha256'] and z['proposalMetadata']==q['fstat']
 assert all(z['currentMetadata'][k]==v for k,v in q['fstat'].items() if k!='st_atime_ns')
 rr=rows[i*2:i*2+2];assert [r['operation'] for r in rr]==['PRE_UNLINK','UNLINK_DURABLE'] and all(r['path']==q['path'] and r['sha256']==q['sha256'] for r in rr)
assert {q['sha256'] for q in raw}==set(res['preservedBodies']) and raw[0]['sha256']!=raw[1]['sha256']
protected=S/'retained-original-archives/preflight-bdf273-original-r4.zip';zbefore=md(os.lstat(protected));assert zbefore==before['protectedZIPStat']==res['protectedZIPBefore']==res['protectedZIPAfter']
cap=pin(e['capsule']['path']);assert (cap['sha256'],cap['bytes'])==(e['capsule']['sha256'],e['capsule']['bytes']) and res['capsuleSHA256']==cap['sha256']
assert all(cap['metadata'][k]==v for k,v in before['capsule']['currentMetadata'].items() if k!='st_atime_ns')
fd=op(cap['path']);manifest=None;blobs={};count=0
with os.fdopen(fd,'rb') as stream,tarfile.open(fileobj=stream,mode='r|gz') as tar:
 for m in tar:
  count+=1;assert count<=800 and m.isfile()
  if m.name=='MANIFEST.json':
   assert manifest is None and m.size<300*1024;b=tar.extractfile(m).read();assert hashlib.sha256(b).hexdigest()==e['manifestSHA256'];manifest=json.loads(b)
  else:
   assert m.name.startswith('blobs/') and m.name not in blobs
   with tar.extractfile(m) as f:h,n=digest(f)
   assert n==m.size and m.name=='blobs/'+h;blobs[m.name]=(h,n)
assert md(os.lstat(cap['path']))==cap['metadata'] and manifest is not None and len(blobs)==303 and len(manifest['rows'])==318
logical=set();expected=set()
for r in manifest['rows']:
 assert len(r)==4 and r[0] in manifest['roots'] and (r[0],r[1]) not in logical;logical.add((r[0],r[1]));assert blobs['blobs/'+r[3]]==(r[3],r[2]);expected.add('blobs/'+r[3])
assert expected==set(blobs)
for x in e['exactLogicalMapping']:
 hits=[r for r in manifest['rows'] if str(Path(manifest['roots'][r[0]])/r[1])==x['originalPath']];assert len(hits)==1;r=hits[0];assert (r[0]+'/'+r[1],r[2],r[3])==(x['logicalPath'],x['bytes'],x['sha256']) and blobs[x['blobMember']]==(x['sha256'],x['bytes'])
known=[];jpeg=0;metadata_snapshots={}
for r in manifest['rows']:
 path=Path(manifest['roots'][r[0]])/r[1]
 if path.is_relative_to(root) and str(path) not in {q['path'] for q in raw}:
  q=pin(path);assert (q['sha256'],q['bytes'])==(r[3],r[2]);metadata_snapshots[q['path']]=q['metadata'];known.append(q)
  if path.suffix.lower() in ('.jpg','.jpeg'):jpeg+=1
assert jpeg==4 and known
selected=json.loads(Path(e['selectedMap']['path']).read_text());assert len(selected['inputs'])==88 and len(selected['outputs'])==56
current=[]
for group,pathroot in [('inputs',R),('outputs',R/'dist')]:
 for rel,h in selected[group].items():
  q=pin(pathroot/rel);assert q['sha256']==h;current.append((group,rel,h,q['bytes']))
assert len(current)==144
for q in known:assert md(os.lstat(q['path']))==metadata_snapshots[q['path']]
zafter=md(os.lstat(protected));assert zafter==zbefore
assert res['grossAllocationBytes']==sum(q['fstat']['st_blocks']*512 for q in raw)==5005312 and res['netWindowGainBytes']==res['windowFreeAfterBeforeResultWrite']-res['windowFreeBefore']==4984832
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576
proof={'proposal':simple(pp),'beforeGate':simple(gp),'confirmedPush':simple(pushp),'producer':simple(jp),'actionBefore':simple(bp),'actionProducerCopy':simple(prod),'actionResult':simple(rp),'actionJournal':simple(journalp),'journalRows':rows,'RootGuardControls':guards,'sourceHoldMapCompleteCallerPins':controls,'twoKnownOldPathsAbsent':res['retiredPaths'],'originalRawMetadataLedger':before['rawFiles'],'capsuleFullEncoding':cap,'manifestSHA256':e['manifestSHA256'],'all303BlobsAnd318LogicalRowsVerified':True,'blobSHARecordDigest':hashlib.sha256(''.join(k+'\0'+str(blobs[k][1])+'\n' for k in sorted(blobs)).encode()).hexdigest(),'twoExactArchivedRawMappings':e['exactLogicalMapping'],'knownRetainedActualFilesFullBodiesAndMetadata':known,'fourOriginalJPEGCount':jpeg,'currentFull144RecordDigest':hashlib.sha256(json.dumps(current,separators=(',',':')).encode()).hexdigest(),'currentFull88_56BodiesVerified':True,'protectedZipFullStatBefore':zbefore,'protectedZipFullStatAfter':zafter,'protectedZipBodyNeverOpened':True,'grossAllocationBytes':5005312,'actionPreResultWindowNetGainBytes':4984832,'gainQualification':'Historical free-space action-window arithmetic, not exclusive actor attribution or final net/native admission guarantee','preservationLimits':'Known old2 absent and declared rawpacket retainedfiles verified; full303 archivebody/318logical mappings exact. Not all unlisted global paths/metadata current or134 external dependency bodies replayed. Historical hardcoded gameplay/preservation require NEW exact restore paths/new adapted readers/mapping; no globalFD/mmap/future dependency absence or metadata rollback/two-unlink atomicity.', 'ownMaxRSSBytes':rss,'allFDsClosed':True,'noRestoreGitCleanupNodeNativeImageBuild':True}
with (P/'PROOF.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'postNormal':True,'twoOldPathsAbsent':True,'fullArchiveBlobs':303,'logicalRows':318,'currentFullBodies':144,'knownRetainedFiles':len(known),'originalJPEGs':jpeg,'gross':5005312,'windowGain':4984832,'ownMaxRSSBytes':rss,'allFDsClosed':True}))
