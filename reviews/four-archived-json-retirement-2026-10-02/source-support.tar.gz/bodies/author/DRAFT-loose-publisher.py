from pathlib import Path
import os,json,hashlib,subprocess,sys,stat
R=Path('/workspace/Roguelike-deckbuilder');S=Path('/workspace/scratch');M=Path(__file__).parent
D=R/'reviews/four-archived-json-retirement-2026-10-02';P=S/'four-archived-raw-retirement-push-root-r2'
def sha(p):
 h=hashlib.sha256();f=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(f,'rb') as r:
  for b in iter(lambda:r.read(65536),b''):h.update(b)
 return h.hexdigest()
gate=S/'four-archived-raw-retirement-independent-r2/GATE.json';g=json.loads(gate.read_text());action=M/'retire-four-archived-json-root-r2.py';proposal=M/'PROPOSAL.json';caller=S/'target-clear-default-caller-independent-r1/GATE.json'
assert len(sys.argv)==2 and sha(gate)==sys.argv[1] and g['decision'].startswith('ACCEPT') and g['replacementBetter'] and g['oldLooseCopiesNoLongerNeeded']
assert g['method']['sha256']==sha(action) and g['proposal']['sha256']==sha(proposal) and g['currentHold']['sha256']==sha(R/'AGENTS.md')
assert sha(caller)=='36ddead7bcd9647706f33c766952732dc3ff7b42455f2c678b125569bde2c31a'
initial_free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
assert not D.exists() and not P.exists()
assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=int(65.5*1048576) #64MiB plus1.5MiB estimated text copies/Git objects; qualified estimate, not OS cap; native threshold unchanged
plan=[]
def walk(root,rel=Path('.')):
 fd=os.open(root/rel,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME|os.O_NOFOLLOW)
 try:
  with os.scandir(fd) as it:rows=[(e.name,e.stat(follow_symlinks=False)) for e in it]
 finally:os.close(fd)
 for n,s in rows:
  assert not stat.S_ISLNK(s.st_mode)
  if stat.S_ISDIR(s.st_mode):yield from walk(root,rel/n)
  else:assert stat.S_ISREG(s.st_mode);yield root/rel/n,rel/n,s.st_size
for source,folder in [(M,'proposal'),(gate.parent,'independent')]:
 for a,rel,n in walk(source):plan.append((a,D/folder/rel,n))
for n in ['retire-four-archived-json-root-r2.py','publish-four-archived-raw-retirement-root-r2.py','judge-four-archived-raw-retirement-root-r2.py']:
 a=M/n;plan.append((a,D/'root-controls'/n,a.stat().st_size))
plan.append((caller,D/'root-controls/DEFAULT-CALLER-GATE.json',caller.stat().st_size));
prior=json.loads((M/'PRIOR-R3-CONTROLS.json').read_text());assert prior['POSTClosed'] and prior['postGateSHA256']==sha(Path(prior['postGatePath']))
for folder in prior['folders']:
 for a,rel,n in walk(Path(folder['path'])):plan.append((a,D/'previous-R3'/folder['label']/rel,n))
for leaf in prior['files']:
 a=Path(leaf['path']);assert sha(a)==leaf['sha256'];plan.append((a,D/'previous-R3'/leaf['label'],a.stat().st_size))
assert sum(n for a,b,n in plan)<768*1024
P.mkdir()
def run(args):
 p=subprocess.run(args,cwd=R,text=True,capture_output=True,timeout=55)
 with (P/'COMMANDS.jsonl').open('a') as f:f.write(json.dumps({'args':args,'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr})+'\n');f.flush();os.fsync(f.fileno())
 assert p.returncode==0,(args,p.stderr);return p.stdout.strip()
assert run(['git','rev-parse','HEAD'])=='a0d5145de9fccccf816c5cdafce7883a84eac7b8'
owned=str(D.relative_to(R))
for line in run(['git','status','--porcelain','--untracked-files=all']).splitlines():assert line[3:]=='AGENTS.md' or line[3:].startswith(owned+'/'),line
D.mkdir();records={}
for a,b,n in plan:
 before=os.lstat(a);fd=os.open(a,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:v=f.read(262145);assert len(v)==n and n<262144 and before==os.fstat(f.fileno())
 assert before==os.lstat(a);b.parent.mkdir(parents=True,exist_ok=True)
 with b.open('xb') as f:f.write(v);f.flush();os.fsync(f.fileno())
 h=hashlib.sha256(v).hexdigest();assert sha(b)==h;records[str(b.relative_to(D))]={'originalPath':str(a),'bytes':n,'sha256':h}
with (D/'COPY-IDENTITIES.json').open('x') as f:json.dump(records,f,indent=2);f.write('\n')
with (D/'README.md').open('x') as f:f.write('Reviewed proposal only: retire exactly four loose historical wait/rejected-R1 rich JSON encodings after current push and separate producer judgment. Distinct full bodies/logical provenance stay in two unchanged published complete capsules. All screenshots/saves/events/source/reviews and protected originals remain. Raw paths/inodes/times would be lost; historical readers require fresh reconstruction and explicit new-reader adaptation. No action, default promotion, native or fun claim.\n')
assert sum(p.stat().st_size for p in D.rglob('*') if p.is_file())<768*1024
run(['git','add','-f','--',owned,'AGENTS.md']);run(['git','-c','gc.auto=0','commit','-m','Preserve reviewed exact four archived raw encoding retirement proposal'])
head=run(['git','rev-parse','HEAD']);run(['git','-c','gc.auto=0','push','origin','HEAD:codex/lanternbound-production']);remote=run(['git','ls-remote','origin','refs/heads/codex/lanternbound-production']).split()[0];assert remote==head and not run(['git','status','--porcelain'])
with (P/'PUSH-CONFIRMED.json').open('x') as f:json.dump({'commit':head,'remote':remote,'confirmed':True,'clean':True,'gateSHA256':sha(gate),'proposalSHA256':sha(proposal),'methodSHA256':sha(action),'callerGateSHA256':sha(caller),'copiedBytes':sum(x['bytes'] for x in records.values()),'initialFree':initial_free,'reserveEstimateBytes':int(1.5*1048576),'sourceCopyCapBytes':768*1024,'priorPostGateSHA256':prior['postGateSHA256'],'finalFreeBeforeReceipt':os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,'noRetirementAction':True},f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
fd=os.open(P,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:os.fsync(fd)
finally:os.close(fd)
print(json.dumps({'confirmed':True,'clean':True,'commit':head,'freeAfterReceipt':os.statvfs(R).f_bavail*os.statvfs(R).f_frsize}))
