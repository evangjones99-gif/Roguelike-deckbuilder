"""SOURCE ONLY. python restore-four-fresh.py wait|rejected RESULT|PROGRESS /absolute/new-file"""
import os,sys,json,hashlib,tarfile
from pathlib import Path
case,which,destination=sys.argv[1:];assert case in ('wait','rejected') and which in ('RESULT','PROGRESS')
R=Path('/workspace/Roguelike-deckbuilder/reviews')
name,archive_sha,manifest_sha,raws={
'wait':('opening-default-wait-cue-2026-10-02','dd9003b676ae49b8a81441f73dfaec51b4309206a3ce32716cb2c8c1fcda169f','bfc53a7026de9e48aeeac0c8e162577c7ee93e255b4205424a364083428a1849',{'RESULT':('2b2f2fb5d95226a0372b86790f91f64cf08ce6a0c5f3f49ab0c645c22bd13588',450138),'PROGRESS':('7f765ffc9413e7e7fe8c940acdabfbfc8e6c9366e1d3da5360c8c4ef83cd0585',450111)}),
'rejected':('opening-target-clear-rejected-2026-10-02','0871ec41c94e39313eb132aa1296385e3e6461e7be0a03e9ef333e4d8453b8a3','c061f51137513fb0bb3553aa6e7d76b6750a2f4abe3a50aa2dea53fddc9e9181',{'RESULT':('a540190d9f800e5d6fdd469dac8dde0eaf351affecbdcbc0f5f15cc99b74fa01',642009),'PROGRESS':('281ab97bb3e829913c39379c8f30f7a5d93cf666dbf31868d99845e7fc4248fd',641982)})}[case]
cp=R/name/'evidence.tar.gz';target_sha,target_size=raws[which];dest=Path(destination)
assert dest.is_absolute() and not dest.exists() and dest.name not in ('','.', '..')
assert not str(dest).startswith(str(R)) and str(dest.parent) not in ('/workspace/scratch/target-wait-default-comparison-actual-r1','/workspace/scratch/target-clear-ghost-comparison-actual-r1')
def open_parent(p):
 fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW)
 for part in p.parent.parts[1:]:
  q=os.open(part,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=q
 return fd
fd=os.open(cp,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW);before=os.fstat(fd);h=hashlib.sha256()
with os.fdopen(os.dup(fd),'rb') as f:
 for b in iter(lambda:f.read(65536),b''):h.update(b)
assert h.hexdigest()==archive_sha and os.fstat(fd)==before;os.lseek(fd,0,0)
seen=False;manifest=False
with os.fdopen(fd,'rb') as f,tarfile.open(fileobj=f,mode='r|gz') as tar:
 for m in tar:
  if m.name=='MANIFEST.json':
   assert m.isfile() and m.size<1048576;v=tar.extractfile(m).read();assert hashlib.sha256(v).hexdigest()==manifest_sha
   entries=json.loads(v)['logicalBodies'];assert sum(e['sha256']==target_sha and e['bytes']==target_size for e in entries.values())>=1;manifest=True
  if m.name=='blobs/'+target_sha:
   assert manifest and not seen and m.isfile() and m.size==target_size
   parent=open_parent(dest);out=os.open(dest.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=parent);h=hashlib.sha256();count=0
   try:
    with os.fdopen(out,'wb') as output,tar.extractfile(m) as source:
     for b in iter(lambda:source.read(65536),b''):output.write(b);h.update(b);count+=len(b)
     output.flush();os.fsync(output.fileno())
   finally:os.close(parent)
   assert h.hexdigest()==target_sha and count==target_size;seen=True
 assert os.fstat(f.fileno())==before
assert manifest and seen and os.lstat(cp)==before
print(json.dumps({'freshPath':str(dest),'sha256':target_sha,'bytes':target_size,'metadataRollback':False}))
