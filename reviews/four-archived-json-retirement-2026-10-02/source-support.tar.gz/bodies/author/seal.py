import os,json,hashlib,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
M=Path(__file__).parent
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read(262145)
for n in ['retire-four-archived-json-root-r2.py','publish-four-archived-raw-retirement-root-r2.py','judge-four-archived-raw-retirement-root-r2.py','restore-four-fresh.py']:compile(read(M/n),str(M/n),'exec')
guards={}
for n in ('PREPARE-GUARD','PROPOSAL-GUARD','METHOD-GUARD','FINALIZE-GUARD'):
 j=json.loads(read(M/n/'RESULT.json'));assert j['exit_code']==0 and j['failure'] is None and j['memory_events_before']==j['memory_events_after'];guards[n]={'exit_code':j['exit_code'],'samples':len(j['samples']),'eventsUnchanged':True,'final':j['final'],'attribution':j['scope']}
files={}
for root,ds,ns in os.walk(M):
 for n in ns:
  p=Path(root)/n
  if 'SEAL-GUARD' in p.parts:continue
  v=read(p);assert len(v)<262144;files[str(p.relative_to(M))]={'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576
seal={'sourceOnly':True,'noActionGitNodeImagesRestoration':True,'files':files,'closedPriorGuards':guards,'ownMaxRSSBytes':rss,'bodyChunkBytes':65536,'packetCapBytes':160*1024,'sourceMethodsSyntaxOnly':True,'sourceSealScope':'This seal excludes its own body and active SEAL-GUARD; outer guard supplies final rows/events/closure.'}
v=(json.dumps(seal,indent=2)+'\n').encode();before=sum(os.stat(root+'/'+n).st_size for root,ds,ns in os.walk(M) for n in ns);assert before+len(v)+6000<=160*1024
with (M/'FINAL-SEAL.json').open('xb') as f:f.write(v)
print(json.dumps({'finalSealSHA256':hashlib.sha256(v).hexdigest(),'RSS':rss,'bytesBeforeFinalOuterGuard':before+len(v),'methodPins':{n:files[n]['sha256'] for n in ['PROPOSAL.json','retire-four-archived-json-root-r2.py','publish-four-archived-raw-retirement-root-r2.py','judge-four-archived-raw-retirement-root-r2.py','restore-four-fresh.py']}}))
