import os,json,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
M=Path(__file__).parent;OLD=Path('/workspace/scratch/r3-two-raw-retirement-source-author-r1')
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'r') as f:return f.read()
replacements=[('r3-two-raw-retirement-source-author-r1',M.name),('r3-two-raw-retirement-independent-r1','four-archived-raw-retirement-independent-r2'),('r3-two-raw-retirement-producer-root-r1','four-archived-raw-retirement-producer-root-r2'),('r3-two-raw-retirement-push-root-r1','four-archived-raw-retirement-push-root-r2'),('r3-two-archived-json-retirement-actual-root-r1','four-archived-json-retirement-actual-root-r2'),('reviews/r3-two-archived-json-retirement-2026-10-02','reviews/four-archived-json-retirement-2026-10-02'),('retire-r3-two-archived-json-root-r1.py','retire-four-archived-json-root-r2.py'),('publish-r3-two-raw-retirement-root-r1.py','publish-four-archived-raw-retirement-root-r2.py'),('judge-r3-two-raw-retirement-root-r1.py','judge-four-archived-raw-retirement-root-r2.py'),('AUTHORIZE_EXACT_TWO_R3_RAW_RETIREMENTS_ONCE','AUTHORIZE_EXACT_FOUR_ARCHIVED_RAW_RETIREMENTS_ONCE')]
def adapt(s):
 for a,b in replacements:s=s.replace(a,b)
 return s
s=adapt(read(OLD/'retire-r3-two-archived-json-root-r1.py'))
s=s[:s.index("raw=e['rawFiles'];root=")]+'''raw=e['rawFiles'];caps=e['capsules']
allowed={str(S/root/name) for root in ['target-wait-default-comparison-actual-r1','target-clear-ghost-comparison-actual-r1'] for name in ['VISUAL-RESULT.json','VISUAL-PROGRESS.json']}
assert len(raw)==4 and {x['path'] for x in raw}==allowed
assert all(x['fstat']['st_dev']==27 and x['fstat']['st_nlink']==1 and not x['xattrs'] for x in raw)
fixed={str(R/'reviews/opening-default-wait-cue-2026-10-02/evidence.tar.gz'):('dd9003b676ae49b8a81441f73dfaec51b4309206a3ce32716cb2c8c1fcda169f','bfc53a7026de9e48aeeac0c8e162577c7ee93e255b4205424a364083428a1849'),str(R/'reviews/opening-target-clear-rejected-2026-10-02/evidence.tar.gz'):('0871ec41c94e39313eb132aa1296385e3e6461e7be0a03e9ef333e4d8453b8a3','c061f51137513fb0bb3553aa6e7d76b6750a2f4abe3a50aa2dea53fddc9e9181')}
assert len(caps)==2 and {c['capsule']['path'] for c in caps}==set(fixed)
handles={}
def verify_capsule(c):
 x=c['capsule'];path=Path(x['path']);fd=handles[x['path']][2]
 check(fd,path.name,x['currentMetadata'],x['sha256'])
 assert (x['sha256'],c['manifestSHA256'])==fixed[x['path']]
 assert sha(Path(c['independentGATE']['path']))==c['independentGATE']['sha256']
 mappings=c['exactLogicalMapping'];assert len(mappings)==2
 assert {v['originalPath'] for v in mappings}<={v['path'] for v in raw}
 wanted={'blobs/'+v['entry']['sha256']:v['entry'] for v in mappings};found={};manifest=None;count=0
 f=os.open(path.name,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW,dir_fd=fd)
 try:
  assert md(os.fstat(f))==x['currentMetadata']
  with os.fdopen(os.dup(f),'rb') as stream,tarfile.open(fileobj=stream,mode='r|gz') as tar:
   for m in tar:
    count+=1;assert count<800
    if m.name=='MANIFEST.json':
     assert manifest is None and m.isfile() and m.size<1048576
     v=tar.extractfile(m).read();assert hashlib.sha256(v).hexdigest()==c['manifestSHA256'];manifest=json.loads(v)
    if m.name in wanted:
     assert m.isfile() and m.name not in found
     with tar.extractfile(m) as body:found[m.name]={'sha256':digest(body),'bytes':m.size}
  assert manifest is not None and set(found)==set(wanted)
  for member,v in wanted.items():assert found[member]=={'sha256':v['sha256'],'bytes':v['bytes']}
  for mapping in mappings:
   entry=mapping['entry'];assert manifest['logicalBodies'][entry['logicalPath']]=={k:entry[k] for k in ('originalPath','bytes','sha256')}
   assert entry['originalPath']==mapping['originalPath']
   v=next(v for v in raw if v['path']==mapping['originalPath']);assert (v['sha256'],v['bytes'])==(entry['sha256'],entry['bytes'])
  assert md(os.fstat(f))==x['currentMetadata']
 finally:os.close(f)
 check(fd,path.name,x['currentMetadata'],x['sha256'])
try:
 for x in [*(c['capsule'] for c in caps),*raw]:
  path=Path(x['path']);fd=parentfd(path);handles[x['path']]=(x,path,fd)
  fresh=md(os.stat(path.name,dir_fd=fd,follow_symlinks=False))
  assert all(fresh[k]==v for k,v in x['fstat'].items() if k!='st_atime_ns')
  x['proposalMetadata']=x['fstat'].copy();x['currentMetadata']=fresh
  check(fd,path.name,fresh,x['sha256'])
 assert {v['originalPath'] for c in caps for v in c['exactLogicalMapping']}==allowed
 for c in caps:verify_capsule(c)
 P=S/'four-archived-json-retirement-actual-root-r2';P.mkdir();ancestor=parentfd(P)
 try:syncfd(ancestor)
 finally:os.close(ancestor)
 save(P/'BEFORE.json',{'rawFiles':raw,'capsules':caps,'initialFree':initial_free,'proposalSHA256':proposal_sha,'gateSHA256':gate_sha,'judgmentSHA256':judgment_sha,'pushSHA256':push_sha,'protectedZIPStat':protected_before})
 save(P/'PRODUCER.json',judged)
 for x in raw:
  path=Path(x['path']);fd=handles[x['path']][2]
  check(fd,path.name,x['currentMetadata'],x['sha256'])
  for c in caps:verify_capsule(c)
  def journal(operation):
   with (P/'JOURNAL.jsonl').open('a') as f:f.write(json.dumps({'utcNs':time.time_ns(),'operation':operation,'path':str(path),'sha256':x['sha256']})+'\\n');f.flush();os.fsync(f.fileno())
   packetfd=parentfd(P/'JOURNAL.jsonl')
   try:syncfd(packetfd)
   finally:os.close(packetfd)
  journal('PRE_UNLINK');os.unlink(path.name,dir_fd=fd);syncfd(fd);journal('UNLINK_DURABLE')
  try:os.stat(path.name,dir_fd=fd,follow_symlinks=False);raise AssertionError('retired path still exists')
  except FileNotFoundError:pass
 for c in caps:verify_capsule(c)
 selected_exact();assert md(os.stat(protected,follow_symlinks=False))==protected_before
 final_free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
 save(P/'RESULT.json',{'normal':True,'retiredPaths':[x['path'] for x in raw],'preservedBodies':[x['sha256'] for x in raw],'capsuleSHA256s':[c['capsule']['sha256'] for c in caps],'grossAllocationBytes':sum(x['fstat']['st_blocks']*512 for x in raw),'windowFreeBefore':initial_free,'windowFreeAfterBeforeResultWrite':final_free,'netWindowGainBytes':final_free-initial_free,'capsulesAndCurrent88_56Exact':True,'protectedZIPBefore':protected_before,'protectedZIPAfter':md(os.stat(protected,follow_symlinks=False)),'protectedOriginalStatExact':True,'noOtherAction':True})
 print(json.dumps({'normal':True,'freeBeforeResultWrite':final_free,'netWindowGain':final_free-initial_free}))
finally:
 for x,path,fd in handles.values():os.close(fd)
'''
# Controls are bounded regular-file bodies, read without changing access times.
s=s.replace("def parentfd(p):", "def body(p):\n fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)\n with os.fdopen(fd,'rb') as f:return f.read(262145)\ndef parentfd(p):")
s=s.replace("json.loads(Path(proposal).read_text())","json.loads(body(Path(proposal)))").replace("json.loads(Path(gate).read_text())","json.loads(body(Path(gate)))").replace("json.loads(Path(push).read_text())","json.loads(body(Path(push)))").replace("json.loads(Path(judgment).read_text())","json.loads(body(Path(judgment)))").replace("json.loads(selected_path.read_text())","json.loads(body(selected_path))")
s=s.replace("(R/'.git/refs/heads/codex/lanternbound-production').read_text().strip()", "body(R/'.git/refs/heads/codex/lanternbound-production').decode().strip()")
s=s.replace("(published/'independent/GATE.json').read_bytes()==Path(gate).read_bytes()","body(published/'independent/GATE.json')==body(Path(gate))").replace("(published/'root-controls'/Path(__file__).name).read_bytes()==Path(__file__).read_bytes()","body(published/'root-controls'/Path(__file__).name)==body(Path(__file__))")
(M/'retire-four-archived-json-root-r2.py').write_text(s)
j=adapt(read(OLD/'judge-r3-two-raw-retirement-root-r1.py')).replace('these two continuously loose copies','these four continuously loose copies').replace('two explicit R3 rich JSON paths','four explicit historical wait/rejected-R1 rich JSON paths').replace('two-leaf','four-leaf')
(M/'judge-four-archived-raw-retirement-root-r2.py').write_text(j)
p=adapt(read(OLD/'publish-r3-two-raw-retirement-root-r1.py')).replace('65*1048576','int(65.5*1048576)').replace('#64floor plus1MiB estimated bounded text copy/Git overhead; no native threshold change','#64MiB plus1.5MiB estimated text copies/Git objects; qualified estimate, not OS cap; native threshold unchanged').replace('512*1024','768*1024').replace('b18e752fc528db4c9e447de071977253375f613e','a0d5145de9fccccf816c5cdafce7883a84eac7b8').replace('two loose R3 rich JSON encodings','four loose historical wait/rejected-R1 rich JSON encodings').replace('the unchanged published complete capsule','two unchanged published complete capsules').replace('exact R3 raw encoding retirement proposal','exact four archived raw encoding retirement proposal')
p=p.replace("plan.append((caller,D/'root-controls/DEFAULT-CALLER-GATE.json',caller.stat().st_size));", "plan.append((caller,D/'root-controls/DEFAULT-CALLER-GATE.json',caller.stat().st_size));\nprior=json.loads((M/'PRIOR-R3-CONTROLS.json').read_text());assert prior['POSTClosed'] and prior['postGateSHA256']==sha(Path(prior['postGatePath']))\nfor folder in prior['folders']:\n for a,rel,n in walk(Path(folder['path'])):plan.append((a,D/'previous-R3'/folder['label']/rel,n))\nfor leaf in prior['files']:\n a=Path(leaf['path']);assert sha(a)==leaf['sha256'];plan.append((a,D/'previous-R3'/leaf['label'],a.stat().st_size))\n")
p=p.replace("assert not D.exists()", "initial_free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize\nassert not D.exists()")
p=p.replace("'finalFreeBeforeReceipt':", "'initialFree':initial_free,'reserveEstimateBytes':int(1.5*1048576),'sourceCopyCapBytes':768*1024,'priorPostGateSHA256':prior['postGateSHA256'],'finalFreeBeforeReceipt':")
(M/'publish-four-archived-raw-retirement-root-r2.py').write_text(p)
for name in ('retire-four-archived-json-root-r2.py','judge-four-archived-raw-retirement-root-r2.py','publish-four-archived-raw-retirement-root-r2.py'):compile(read(M/name),str(M/name),'exec')
print(json.dumps({'methodsSyntaxOnly':True,'actualAction':False,'RSS':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}))
