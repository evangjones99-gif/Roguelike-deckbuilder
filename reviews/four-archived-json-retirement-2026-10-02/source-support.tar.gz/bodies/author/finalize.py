import os,json,hashlib,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
M=Path(__file__).parent;S=Path('/workspace/scratch')
def body(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read(262145)
def pin(p):
 v=body(p);return {'path':str(p),'sha256':hashlib.sha256(v).hexdigest(),'bytes':len(v)}
post=S/'r3-two-raw-retirement-post-independent-r1/GATE.json';assert pin(post)['sha256']=='2e8735abe975b28e42a1ce9d3a178ad6db9c251ca4f1de6acee3a979a361ec97'
folders=[{'path':str(S/n),'label':label} for n,label in [('r3-two-raw-retirement-post-independent-r1','prior-R3-post'),('r3-two-archived-json-retirement-actual-root-r1','prior-R3-actual'),('r3-two-raw-retirement-publication-guard-root-r1','prior-R3-publication-guard'),('r3-two-raw-retirement-producer-guard-root-r1','prior-R3-producer-guard'),('r3-two-raw-retirement-actual-guard-root-r1','prior-R3-actual-guard')]]
files=[]
for n,label,h in [('r3-two-raw-retirement-push-root-r1/PUSH-CONFIRMED.json','PUSH-CONFIRMED.json','3b6e3672426d3fb209699ec7654ade9e0239ee3d33b67849fd205bc196325fa8'),('r3-two-raw-retirement-producer-root-r1.json','PRODUCER-JUDGMENT.json','b7a5371df6efd47ddb876962057eb8594ac26841624ff05d99cad5ba7815301a')]:
 p=pin(S/n);assert p['sha256']==h;p['label']=label;files.append(p)
controls={'POSTClosed':True,'postGatePath':str(post),'postGateSHA256':pin(post)['sha256'],'postFinalSealSHA256':pin(post.parent/'FINAL-SEAL.json')['sha256'],'folders':folders,'files':files,'qualifiedSourcePlanOnly':True}
# Exact immutable source bundle plan: O_NOATIME directory enumeration, no symlink traversal.
def walk(root,rel=Path('.')):
 fd=os.open(root/rel,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME|os.O_NOFOLLOW)
 try:
  with os.scandir(fd) as it:rows=sorted((e.name,e.stat(follow_symlinks=False)) for e in it)
 finally:os.close(fd)
 for n,s in rows:
  if __import__('stat').S_ISDIR(s.st_mode):yield from walk(root,rel/n)
  else:assert __import__('stat').S_ISREG(s.st_mode);yield root/rel/n,rel/n
controls['exactPriorMemberPins']=[dict(pin(a),logicalPath=f['label']+'/'+str(rel)) for f in folders for a,rel in walk(Path(f['path']))]+[dict(x,logicalPath='prior-R3/'+x['label']) for x in files]
assert pin(S/'r3-two-archived-json-retirement-actual-root-r1/RESULT.json')['sha256']=='3493ceecb6396448d04d79cefb43dee58d92831749cb0dc67f4d3d39be4673c0'
(M/'PRIOR-R3-CONTROLS.json').write_text(json.dumps(controls,indent=2)+'\n')
action=M/'retire-four-archived-json-root-r2.py';s=body(action).decode();key="assert (published/'"
at=s.index('initial_free=')
extra="""bundle=p['supportBundle'];assert bundle['roundtripExact'] and Path(bundle['path'])==published/'source-support.tar.gz'
assert sha(published/'source-support.tar.gz')==bundle['sha256']
assert json.loads(body(published/'SUPPORT-BUNDLE.json'))==bundle
assert sha(published/'previous-R3-POST-GATE.json')==p['priorPostGateSHA256']=='2e8735abe975b28e42a1ce9d3a178ad6db9c251ca4f1de6acee3a979a361ec97'
fd=os.open(published/'source-support.tar.gz',os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as f,tarfile.open(fileobj=f,mode='r|gz') as tar:
 m=next(iter(tar));assert m.name=='MANIFEST.json' and m.isfile() and m.size<1048576
 assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==bundle['manifestSHA256']
"""
s=s[:at]+extra+s[at:];action.write_text(s)
j=M/'judge-four-archived-raw-retirement-root-r2.py';s=body(j).decode();s=s.replace("j={'decision'", "assert p['supportBundle']['roundtripExact'] and sha(D/'source-support.tar.gz')==p['supportBundle']['sha256']\nassert sha(D/'previous-R3-POST-GATE.json')==p['priorPostGateSHA256']=='2e8735abe975b28e42a1ce9d3a178ad6db9c251ca4f1de6acee3a979a361ec97'\nj={'decision'")
s=s.replace("'Only the two", "'Only the four");j.write_text(s)
p=M/'publish-four-archived-raw-retirement-root-r2.py';s=body(p).decode();s=s.replace("plan.append((caller,", "for leaf in prior['exactPriorMemberPins']:assert sha(Path(leaf['path']))==leaf['sha256'] and os.lstat(leaf['path']).st_size==leaf['bytes']\nplan.append((caller,")
s=s.replace("readable=[(proposal", "readable=[(Path(prior['postGatePath']),D/'previous-R3-POST-GATE.json'),(proposal")
p.write_text(s)
for n in ['retire-four-archived-json-root-r2.py','publish-four-archived-raw-retirement-root-r2.py','judge-four-archived-raw-retirement-root-r2.py']:compile(body(M/n),str(M/n),'exec')
print(json.dumps({'priorMembers':len(controls['exactPriorMemberPins']),'sourceSyntaxOnly':True,'RSS':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'packetBytes':sum(os.stat(root+'/'+n).st_size for root,ds,ns in os.walk(M) for n in ns)}))
