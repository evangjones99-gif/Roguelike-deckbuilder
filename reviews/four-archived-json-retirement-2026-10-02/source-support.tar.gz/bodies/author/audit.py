import os, sys, json, hashlib, tarfile, stat, resource, time
resource.setrlimit(resource.RLIMIT_DATA, (24*1048576,24*1048576))
ROOT='/workspace/scratch/four-archived-raw-retirement-source-author-r2'
CASES=[('target-wait-default-comparison-actual-r1','opening-default-wait-cue-2026-10-02','dd9003b676ae49b8a81441f73dfaec51b4309206a3ce32716cb2c8c1fcda169f','bfc53a7026de9e48aeeac0c8e162577c7ee93e255b4205424a364083428a1849'),('target-clear-ghost-comparison-actual-r1','opening-target-clear-rejected-2026-10-02','0871ec41c94e39313eb132aa1296385e3e6461e7be0a03e9ef333e4d8453b8a3','c061f51137513fb0bb3553aa6e7d76b6750a2f4abe3a50aa2dea53fddc9e9181')]
def sd(s):
 return {k:getattr(s,'st_'+k) for k in ('dev','ino','mode','uid','gid','nlink','size','blocks','atime_ns','mtime_ns','ctime_ns')}
parents={}
def op(path):
 parts=path.split('/')[1:]; fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW)
 cur=''
 try:
  for p in parts[:-1]:
   n=os.open(p,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=n;cur+='/'+p
   if cur not in parents:
    parents[cur]={'stat':sd(os.fstat(fd)), 'xattrs':{n:os.getxattr('/proc/self/fd/'+str(fd),n).hex() for n in os.listxattr('/proc/self/fd/'+str(fd))}}
  return os.open(parts[-1],os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW,dir_fd=fd)
 finally: os.close(fd)
def inspect(path, retain=False):
 before=sd(os.lstat(path));f=op(path);fs=sd(os.fstat(f));assert before==fs and stat.S_ISREG(fs['mode'])
 attrs={n:os.getxattr(f,n).hex() for n in os.listxattr(f)};h=hashlib.sha256();total=0;pieces=[]
 while True:
  b=os.read(f,65536)
  if not b:break
  h.update(b);total+=len(b)
  if retain:pieces.append(b)
 after=sd(os.fstat(f));os.close(f);assert before==after==sd(os.lstat(path))
 r={'path':path,'sha256':h.hexdigest(),'bytes':total,'lstat':before,'fstat':fs,'after':after,'xattrs':attrs,'allMetadataStable':True}
 return (r,b''.join(pieces)) if retain else r
def decode(path):
 r,b=inspect(path,True);assert len(b)<262144;return r,json.loads(b)
raw=[];caps=[]
for actual, published, expected, expected_manifest in CASES:
 these=[inspect('/workspace/scratch/'+actual+'/'+n) for n in ('VISUAL-RESULT.json','VISUAL-PROGRESS.json')]
 for r in these:assert r['lstat']['nlink']==1 and r['lstat']['dev']==27
 raw.extend(these);base='/workspace/Roguelike-deckbuilder/reviews/'+published
 archive=inspect(base+'/evidence.tar.gz');assert archive['sha256']==expected
 pres,presbody=decode(base+'/PRESERVATION.json');assert presbody['archiveSHA256']==expected and presbody['manifestSHA256']==expected_manifest
 gate,gatebody=decode(base+'/independent-preservation/GATE.json')
 review,reviewbody=inspect(base+'/independent-preservation/REVIEW.md',True)
 assert b'ACCEPT' in reviewbody.upper() or 'ACCEPT' in json.dumps(gatebody).upper()
 f=op(archive['path']);before=sd(os.fstat(f));wanted={r['sha256']:r for r in these};found={};manifest=None;mh=None;membercount=0
 with os.fdopen(f,'rb') as stream:
  with tarfile.open(fileobj=stream,mode='r|gz') as tar:
   for m in tar:
    membercount+=1
    if m.name=='MANIFEST.json':
     b=tar.extractfile(m).read(4*1048576+1);assert len(b)<=4*1048576;mh=hashlib.sha256(b).hexdigest();assert mh==expected_manifest;manifest=json.loads(b)
    elif m.name.startswith('blobs/') and m.name.split('/')[-1] in wanted:
     assert m.isfile();h=hashlib.sha256();count=0
     with tar.extractfile(m) as body:
      while True:
       b=body.read(65536)
       if not b:break
       h.update(b);count+=len(b)
     sha=h.hexdigest();assert sha==m.name.split('/')[-1] and count==wanted[sha]['bytes'];found[sha]={'member':m.name,'sha256':sha,'bytes':count,'streamRoundtripExact':True}
  assert sd(os.fstat(stream.fileno()))==before
 assert sd(os.lstat(archive['path']))==before and manifest is not None
 entries=manifest if isinstance(manifest,list) else manifest.get('entries',manifest.get('files',manifest.get('logicalBodies')))
 if isinstance(entries,dict):entries=[dict(v,logicalPath=k) for k,v in entries.items()]
 assert isinstance(entries,list),str(type(manifest))+' '+str(list(manifest)[:20])
 mapping=[]
 for r in these:
  matches=[e for e in entries if e.get('originalPath')==r['path']]
  assert len(matches)==1,(r['path'],len(matches));e=matches[0]
  assert e['sha256']==r['sha256'] and e.get('bytes',e.get('size'))==r['bytes'];assert r['sha256'] in found
  mapping.append({'originalPath':r['path'],'entry':e,'verifiedBlob':found[r['sha256']]})
 caps.append({'capsule':archive,'manifestSHA256':mh,'exactLogicalMapping':mapping,'archiveMembersSeen':membercount,'preservation':pres,'independentGATE':gate,'independentGateDecision':gatebody,'independentReview':review,'preservationIsNotRetirementAuthority':True})
consumers=[]
checks=[('currentDefault','/workspace/scratch/target-clear-default-caller-author-r1/driver-paired-r1.mjs'),('currentDefault','/workspace/scratch/target-clear-default-caller-author-r1/supervise-paired-r1.py'),('currentDefaultBuild','/workspace/scratch/target-clear-default-build-author-r1/ASSEMBLE-DEFAULT-r1.py'),('current300','/workspace/scratch/ready-default-300-caller-root-r1/driver.mjs'),('current300','/workspace/scratch/ready-default-300-caller-root-r1/supervise.py'),('currentR3','/workspace/scratch/target-clear-ghost-caller-author-r3/driver-paired-r1.mjs'),('currentR3','/workspace/scratch/target-clear-ghost-caller-author-r3/supervise-paired-r1.py'),('currentR3Gameplay','/workspace/scratch/target-clear-ghost-actual-gameplay-independent-r3/read_gameplay.py'),('historicalDefaultGameplay','/workspace/scratch/target-wait-default-actual-gameplay-independent-r1/read_gameplay.py'),('historicalGhostGameplay','/workspace/scratch/target-clear-ghost-actual-gameplay-independent-r1/read_gameplay.py')]
for role,path in checks:
 try:
  pin,b=inspect(path,True);assert len(b)<262144;text=b.decode('utf-8');hits=[]
  for actual,_,_,_ in CASES:
   if actual in text:hits.append(actual)
  consumers.append({'role':role,'pin':pin,'historicalRootLiterals':hits,'genericOutputNames':[n for n in ['VISUAL-RESULT.json','VISUAL-PROGRESS.json'] if n in text]})
 except OSError as e:consumers.append({'role':role,'path':path,'failedLocator':str(e),'assessed':False})
assert all(not c.get('historicalRootLiterals') for c in consumers if c['role'].startswith('current'))
allocated=sum(r['lstat']['blocks']*512 for r in raw);logical=sum(r['bytes'] for r in raw)
selectedPin,selected=decode('/workspace/scratch/target-clear-ghost-promotion-root-r3/RESULT.json');assert selectedPin['sha256']=='e0af37d86a6c67bf1936463fb3f2714457d19646d7a71c5fd2840b1dda62d6c6';assert len(selected['inputs'])==88 and len(selected['outputs'])==56
holdPin,_=inspect('/workspace/Roguelike-deckbuilder/AGENTS.md',True)
callerGate,caller=decode('/workspace/scratch/target-clear-default-caller-independent-r1/GATE.json');assert callerGate['sha256']=='36ddead7bcd9647706f33c766952732dc3ff7b42455f2c678b125569bde2c31a'
headPin,head=inspect('/workspace/Roguelike-deckbuilder/.git/refs/heads/codex/lanternbound-production',True);assert head.decode().strip()=='a0d5145de9fccccf816c5cdafce7883a84eac7b8'
result={'schema':'bounded-four-raw-json-retirement-proposal-r1','recommendation':'CONDITIONAL_PREFER_COMPRESSED_EXACT_SUCCESSOR; NO_ACTION_AUTHORIZED','rawFiles':raw,'capsules':caps,'consumers':consumers,'parentRights':parents,'grossAllocatedBytes':allocated,'logicalBytes':logical,'netRecoveryQualified':'Gross only; publication/proof/Git effects reduce net. Earlier Root retained this small scope when insufficient; that decision remains historical. New measured free72925184B is below native73400320B and stronger73924608B after R3 two-body retirement, so proportional2187264B may admit the next actual. No threshold change or net promise.','noLongerNeededEvidence':'Known current300/currentR3 callers and R3 gameplay reader do not reference the two historical actual roots. Historical direct readers require exact capsule reconstruction into new explicit paths and source adaptation. Original independent gates verified included roundtrip bodies; this audit independently stream-matches all four exact raw bodies. No claim of universal future dependencies, unknown open descriptors, or all unlisted consumers.','retained':'All unique captures, saves, events, source, callers, reviews, rights/provenance and failure receipts unchanged. Existing published capsules remain immutable. Only these four loose physical bodies proposed for retirement.','losses':['The four original raw paths would disappear; old historical hardcoded readers would require reconstruction and deliberate path adaptation.','Original inodes, allocation, raw metadata identity and physical isolation would not survive. Capsule logical paths and full bytes/provenance survive; fresh reconstruction has new metadata.','No OS readonly designation or globally exhaustive consumer proof.','Old capsule noRetirement/all-originals-needed statements describe their original decision; this proposal does not retroactively alter those historical documents.'],'requirementsBeforeAction':['Separate independent review explicitly preferring compressed encoding and finding old four loose bodies no longer needed under qualified reconstruction workflow.','Root producer judgment and fresh confirmed publication/push of completed proposal/review/action controls.','Exact four-path-only action with fresh metadata/body/capsule pins and closure proof; all other old artifacts remain untouched.'],'bootstrapQualification':'Prior tiny unmetered discovery only stat-ed these exact four and read exact capsule headers/guard source; failed old method filename locator retained in bootstrap narrative. All relied-upon evidence here reread under normal64MiB work+512reserve disk64 guard. No relaxed admission.','resources':{'ownMaxRSSBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'rlimitDataBytes':24*1048576,'bodyChunkBytes':65536,'noNodeNoBackendNoGitNoStorageAction':True}}
assert result['resources']['ownMaxRSSBytes']<24*1048576

def prefixed(v):
 if isinstance(v,dict):return {('st_'+k if k in ('dev','ino','mode','uid','gid','nlink','size','blocks','atime_ns','mtime_ns','ctime_ns') else k):prefixed(x) for k,x in v.items()}
 if isinstance(v,list):return [prefixed(x) for x in v]
 return v
result=prefixed(result);result['selectedMap']=prefixed(selectedPin);result['selectedMap'].update(inputKey='inputs',outputKey='outputs');result['currentHold']=prefixed(holdPin);result['currentCallerGate']=prefixed(callerGate);result['currentConfirmedHEAD']=head.decode().strip();result['previousConditionalProposal']={'path':'/workspace/scratch/next-archived-raw-retirement-proposal-r1/PROPOSAL.json','sha256':'fcc32a466e5963e6c6dd10515fdd66b52bca8fcce5786a43717b596e9a194fae','unchanged':True};result['capacityReconsiderationIsNotVersionPreference']=True
with open(ROOT+'/PROPOSAL.json','x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({'rawSHA256':[r['sha256'] for r in raw],'grossAllocatedBytes':allocated,'logicalBytes':logical,'capsules':[a['capsule']['sha256'] for a in caps],'consumers':[{k:c[k] for k in ['role','historicalRootLiterals','assessed','failedLocator'] if k in c} for c in consumers],'ownMaxRSSBytes':result['resources']['ownMaxRSSBytes']}))
