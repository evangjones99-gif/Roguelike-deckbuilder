from pathlib import Path
import os,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
P=Path('/workspace/scratch/four-archived-raw-retirement-independent-r2')
def pin(path):
 p=Path(path);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);h=hashlib.sha256();n=0
 try:
  a=os.fstat(fd)
  for b in iter(lambda:os.read(fd,65536),b''):h.update(b);n+=len(b)
  assert os.fstat(fd)==a==os.lstat(p)
 finally:os.close(fd)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':n}
def load(path):
 q=pin(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 with os.fdopen(fd) as f:d=json.load(f)
 return q,d
def save(name,d):
 with (P/name).open('x') as f:json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
proofp,d=load(P/'PROOF.json');gp,g=load(P/'PROOF-GUARD-r2/RESULT.json')
assert g['exit_code']==0 and g['failure'] is None and g['memory_events_before']==g['memory_events_after']
assert d['ownMaxRSSBytes']<24*1048576 and len(d['fourFreshRawBodiesAndMetadata'])==4
assert [q['fullBlobBodies'] for q in d['capsules']]==[209,249] and [q['logicalRows'] for q in d['capsules']]==[226,264]
for key in ['proposal','authorSeal','currentHold','selectedMap','currentCallerGate','priorR3Controls','priorR3POSTGate']:
 assert pin(d[key]['path'])==d[key]
for q in d['methods']+d['extraCurrentBuildCallerPromotionPins']:assert pin(q['path'])==q
for x in d['currentConsumerSourcePins']:assert pin(x['pin']['path'])==x['pin']
for q in d['fourFreshRawBodiesAndMetadata']+[c['capsule'] for c in d['capsules']]:
 fresh=pin(q['path']);assert all(fresh[k]==q[k] for k in fresh)
 s=os.lstat(q['path']);assert {k:getattr(s,k) for k in q['metadata']}==q['metadata']
z=os.lstat('/workspace/scratch/retained-original-archives/preflight-bdf273-original-r4.zip');assert {k:getattr(z,k) for k in d['protectedZIPFullStatAfter']}==d['protectedZIPFullStatAfter']==d['protectedZIPFullStatBefore']
assert d['publisherModel']['modeledPublishedAllocationUpperBytes']<768*1024 and d['publisherModel']['knownFullRoundtrip']
gate={'decision':'ACCEPT CONDITIONAL exact four archived loose JSON retirement SOURCE eligibility; Root publication/judgment/current confirmed push and fresh actual checks required',
 'replacementBetter':True,'oldLooseCopiesNoLongerNeeded':True,'proposal':d['proposal'],'method':d['methods'][0],'publisher':d['methods'][1],'producer':d['methods'][2],'restore':d['methods'][3],
 'currentHold':d['currentHold'],'selectedMap':d['selectedMap'],'currentCallerGate':d['currentCallerGate'],'priorR3POSTGate':d['priorR3POSTGate'],
 'proof':proofp,'review':pin(P/'REVIEW.md'),'reader':pin(P/'verify-r2.py'),'originalFailedReader':pin(P/'verify.py'),'sealer':pin(P/'seal.py'),
 'proofGuard':{k:pin(P/'PROOF-GUARD-r2'/k) for k in ['ADMISSION.json','RESULT.json','EXECUTION.log']},
 'failedReaderGuard':{k:pin(P/'PROOF-GUARD'/k) for k in ['ADMISSION.json','RESULT.json','EXECUTION.log']},
 'exactFourPaths':[q['path'] for q in d['fourFreshRawBodiesAndMetadata']],'fullRawBodyCount':4,'fullCapsuleBlobCounts':[209,249],'exactLogicalRowCounts':[226,264],'fullCurrentSelectedBodies':144,
 'publisherModel':d['publisherModel'],'grossAllocationBytes':2187264,'logicalRawBytes':2184240,'ownProofMaxRSSBytes':d['ownMaxRSSBytes'],
 'preferenceReason':'Unchanged verified compressed successors preserve all exact bodies/logical names/provenance while four continuously loose copies add no unique body; reviewed current source dependencies do not require those original paths.',
 'historicalNeedQualification':d['necessityLimit'],'metadataLoss':'Original four raw paths/inodes/timestamps/physical isolation disappear; exact fresh reconstruction has new metadata. No metadata rollback.',
 'durabilityQualification':'Observed file/P receipt fsync only for publisher; generated bundle/files/parent entries not all fsynced. Action durable per-leaf journal prefix, no four-leaf atomicity or automatic retry.',
 'authorityLimit':'Source-only eligibility. Root alone publishes exact bound methods/proposal/review, confirms current clean push and records judgment before one exact action. Separate independent POST and fresh native admission required. No other cleanup/restore/Git/media/native authority.',
 'protectedZIPFullStatExact':True,'protectedZIPBodyNeverOpened':True,'preservedFailure':'Original wrong EXPECTED.json locator failed; source/guard retained unchanged, fresh reader corrects only EXPECTED-CANDIDATE.json.',
 'packetCapBytes':128*1024,'closureQualification':'Own readers/FDs close normally; guard shared cgroup samples are not exclusive actor/globalFD absence proof.'}
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576;gate['ownSealMaxRSSBytes']=rss;save('GATE.json',gate)
stable=[pin(p) for p in sorted(P.rglob('*')) if p.is_file() and 'SEAL-GUARD' not in p.parts]
total=sum(p.stat().st_size for p in P.rglob('*') if p.is_file())
final={'gate':pin(P/'GATE.json'),'stableFiles':stable,'sealGuardAdmission':pin(P/'SEAL-GUARD/ADMISSION.json'),'bytesBeforeFinalReceipt':total,'packetCapBytes':128*1024,'finalGuardReserveBytes':8192,'ownMaxRSSBytes':rss,'allOwnReaderFDsClosed':True,'noProductionMethodsExecuted':True,'closure':'Active seal guard log/final RESULT excluded from immutable ledger; final outer guard completion independently checked after exit.'}
encoded=(json.dumps(final,indent=2)+'\n').encode();assert total+len(encoded)+8192<128*1024
with (P/'FINAL-SEAL.json').open('xb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
fd=os.open(P,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({'gate':pin(P/'GATE.json'),'finalSeal':pin(P/'FINAL-SEAL.json'),'packetBytesNow':total+len(encoded),'ownMaxRSSBytes':rss,'allOwnReaderFDsClosed':True}))
