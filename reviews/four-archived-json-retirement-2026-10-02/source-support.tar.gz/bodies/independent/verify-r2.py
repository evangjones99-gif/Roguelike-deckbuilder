from pathlib import Path
import os,json,hashlib,stat,resource,tarfile,gzip,io,ast
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
S=Path('/workspace/scratch');R=Path('/workspace/Roguelike-deckbuilder');M=S/'four-archived-raw-retirement-source-author-r2';P=S/'four-archived-raw-retirement-independent-r2'
K=['st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_blocks','st_atime_ns','st_mtime_ns','st_ctime_ns']
def md(s):return {k:getattr(s,k) for k in K}
def op(path):
 p=Path(path);fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  for part in p.parent.parts[1:]:
   assert part not in ('','.', '..');n=os.open(part,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=n
  return os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=fd)
 finally:os.close(fd)
def pin(path,body=False):
 p=Path(path);a=md(os.lstat(p));fd=op(p);h=hashlib.sha256();n=0;parts=[]
 try:
  assert stat.S_ISREG(a['st_mode']) and md(os.fstat(fd))==a
  attrs={x:os.getxattr(fd,x).hex() for x in os.listxattr(fd)}
  for b in iter(lambda:os.read(fd,65536),b''):
   n+=len(b);h.update(b)
   if body:parts.append(b);assert n<262144
  assert md(os.fstat(fd))==a==md(os.lstat(p))
 finally:os.close(fd)
 q={'path':str(p),'sha256':h.hexdigest(),'bytes':n,'metadata':a,'xattrs':attrs}
 return (q,b''.join(parts)) if body else q
def simple(q):return {k:q[k] for k in ['path','sha256','bytes']}
def load(path):
 q,b=pin(path,True);return q,json.loads(b)
def same(q,old):
 assert (q['sha256'],q['bytes'])==(old['sha256'],old['bytes'])
 assert all(q['metadata'][k]==v for k,v in old['fstat'].items() if k!='st_atime_ns') and q['xattrs']==old['xattrs']
def digest(f):
 h=hashlib.sha256();n=0
 for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
 return h.hexdigest(),n
pp,e=load(M/'PROPOSAL.json');sp,se=load(M/'FINAL-SEAL.json')
assert pp['sha256']=='02a099158000476c103d69959f67dda002e51a6242a20395a81e43560990d3fe' and sp['sha256']=='d5a7a7b783a919ae6130ccefc4a49152ea90a4ad9c6b566ccbe8f9b07a2e0ae2'
sealed=[]
for rel,old in se['files'].items():
 q=pin(M/rel);assert (q['sha256'],q['bytes'])==(old['sha256'],old['bytes']);sealed.append(simple(q))
for name in [x.name for x in M.iterdir() if x.is_dir() and x.name.endswith('GUARD')]:
 _,g=load(M/name/'RESULT.json');assert g['exit_code']==0 and g['failure'] is None and g['memory_events_before']==g['memory_events_after']
raw=[];allowed={str(S/root/name) for root in ['target-wait-default-comparison-actual-r1','target-clear-ghost-comparison-actual-r1'] for name in ['VISUAL-RESULT.json','VISUAL-PROGRESS.json']}
assert len(e['rawFiles'])==4 and {x['path'] for x in e['rawFiles']}==allowed
for old in e['rawFiles']:
 q=pin(old['path']);same(q,old);assert q['metadata']['st_dev']==27 and q['metadata']['st_nlink']==1 and not q['xattrs'];raw.append(q)
assert len({q['sha256'] for q in raw})==4 and sum(q['metadata']['st_blocks']*512 for q in raw)==e['grossAllocatedBytes']==2187264
caps=[];mappings=[]
for c in e['capsules']:
 q=pin(c['capsule']['path']);same(q,c['capsule']);fd=op(q['path']);blobs={};manifest=None;count=0
 with os.fdopen(fd,'rb') as f,tarfile.open(fileobj=f,mode='r|gz') as tar:
  for m in tar:
   count+=1;assert count<800 and m.isfile()
   if m.name=='MANIFEST.json':
    assert manifest is None and m.size<300*1024;b=tar.extractfile(m).read();assert hashlib.sha256(b).hexdigest()==c['manifestSHA256'];manifest=json.loads(b)
   else:
    assert m.name.startswith('blobs/') and m.name not in blobs
    with tar.extractfile(m) as f:h,n=digest(f)
    assert m.name=='blobs/'+h and n==m.size;blobs[m.name]=(h,n)
 assert md(os.lstat(q['path']))==q['metadata'] and manifest is not None
 rows=manifest['logicalBodies'];assert isinstance(rows,dict)
 for logical,row in rows.items():assert blobs['blobs/'+row['sha256']]==(row['sha256'],row['bytes'])
 for x in c['exactLogicalMapping']:
  row=x['entry'];assert rows[row['logicalPath']]=={k:row[k] for k in ['originalPath','sha256','bytes']} and x['originalPath']==row['originalPath']
  original=next(y for y in raw if y['path']==x['originalPath']);assert (original['sha256'],original['bytes'])==(row['sha256'],row['bytes'])==blobs[x['verifiedBlob']['member']];mappings.append(x)
 for key in ['independentGATE','preservation','independentReview']:
  z=pin(c[key]['path']);same(z,c[key])
 caps.append({'capsule':q,'manifestSHA256':c['manifestSHA256'],'fullBlobBodies':len(blobs),'logicalRows':len(rows),'fullRoundtrip':True})
assert {x['originalPath'] for x in mappings}==allowed
consumer=[]
oldroots=['target-wait-default-comparison-actual-r1','target-clear-ghost-comparison-actual-r1']
for x in e['consumers']:
 q,b=pin(x['pin']['path'],True);same(q,x['pin']);text=b.decode();hits=[n for n in oldroots if n in text];assert hits==x['historicalRootLiterals']
 if x['role'].startswith('current'):assert not hits
 consumer.append({'role':x['role'],'pin':simple(q),'oldRootLiterals':hits,'genericVISUALIsNewOutput':x['role'] in ['currentDefault','currentR3'] and 'driver' in q['path']})
extra=[]
for path in [S/'target-clear-ghost-publish-author-r1/promote.py',S/'target-clear-default-build-author-r1/RUNTIME-FREEZE.json',S/'target-clear-default-caller-author-r1/EXPECTED-CANDIDATE.json',S/'target-clear-default-caller-author-r1/MANIFEST.json']:
 q,b=pin(path,True);assert not any(n.encode() in b for n in oldroots);extra.append(simple(q))
selectedp,selected=load(e['selectedMap']['path']);same(selectedp,e['selectedMap']);assert len(selected['inputs'])==88 and len(selected['outputs'])==56
current=[]
for key,root in [('inputs',R),('outputs',R/'dist')]:
 for rel,h in selected[key].items():
  q=pin(root/rel);assert q['sha256']==h;current.append([key,rel,h,q['bytes']])
hold=pin(e['currentHold']['path']);same(hold,e['currentHold']);caller=pin(e['currentCallerGate']['path']);same(caller,e['currentCallerGate'])
assert e['currentConfirmedHEAD']=='a0d5145de9fccccf816c5cdafce7883a84eac7b8'
branchp,b=pin(R/'.git/refs/heads/codex/lanternbound-production',True);assert b.decode().strip()==e['currentConfirmedHEAD']
priorp,prior=load(M/'PRIOR-R3-CONTROLS.json');priorpins=[]
for old in prior['exactPriorMemberPins']:
 q=pin(old['path']);assert (q['sha256'],q['bytes'])==(old['sha256'],old['bytes']);priorpins.append(simple(q))
postp,post=load(prior['postGatePath']);assert prior['POSTClosed'] and postp['sha256']==prior['postGateSHA256']=='2e8735abe975b28e42a1ce9d3a178ad6db9c251ca4f1de6acee3a979a361ec97' and post['decision'].startswith('ACCEPT')
zip_path=S/'retained-original-archives/preflight-bdf273-original-r4.zip';zbefore=md(os.lstat(zip_path));_,postproof=load(S/'r3-two-raw-retirement-post-independent-r1/PROOF.json');assert zbefore==postproof['protectedZipFullStatAfter']
methods=[]
for name in ['retire-four-archived-json-root-r2.py','publish-four-archived-raw-retirement-root-r2.py','judge-four-archived-raw-retirement-root-r2.py','restore-four-fresh.py']:
 q,b=pin(M/name,True);ast.parse(b);methods.append(simple(q))
# Build a deterministic in-memory model of the publisher's complete currently sealed inputs.
# Future independent final packet is represented separately by its explicit128KiB upper bound.
plan=[]
def walk(root,label):
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink()
  if path.is_file():
   q=pin(path);assert q['bytes']<262144;plan.append((path,label+'/'+str(path.relative_to(root)),q))
walk(M,'author')
for f in prior['folders']:walk(Path(f['path']),f['label'])
for f in prior['files']:
 q=pin(f['path']);plan.append((Path(f['path']),'prior-R3/'+f['label'],q))
plan.append((Path(caller['path']),'controls/DEFAULT-CALLER-GATE.json',caller))
assert len(plan)<400 and len({logical for path,logical,q in plan})==len(plan)
records={logical:{'originalPath':str(path),'bytes':q['bytes'],'sha256':q['sha256']} for path,logical,q in plan}
manifest=json.dumps({'schema':'exact-source-support-bundle-r1','logicalBodies':records},sort_keys=True,separators=(',',':')).encode()+b'\n'
buffer=io.BytesIO()
with gzip.GzipFile(filename='',mode='wb',fileobj=buffer,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
 def add(name,v):
  info=tarfile.TarInfo(name);info.size=len(v);info.mode=0o600;info.mtime=0;info.uid=info.gid=0;tar.addfile(info,io.BytesIO(v))
 add('MANIFEST.json',manifest)
 for path,logical,q in plan:
  fresh,v=pin(path,True);assert simple(fresh)==simple(q);add('bodies/'+logical,v)
encoded=buffer.getvalue();seen=set()
with tarfile.open(fileobj=io.BytesIO(encoded),mode='r|gz') as tar:
 for m in tar:
  assert m.isfile()
  if m.name=='MANIFEST.json':assert tar.extractfile(m).read()==manifest;continue
  logical=m.name[7:];assert m.name.startswith('bodies/') and logical not in seen
  with tar.extractfile(m) as f:h,n=digest(f)
  assert (h,n)==(records[logical]['sha256'],records[logical]['bytes']);seen.add(logical)
assert seen==set(records)
source_total=sum(q['bytes'] for path,logical,q in plan)
assert source_total+128*1024<2*1048576 and len(plan)+32<400
# Conservative zlib stored-block upper bound for all incompressible future review bytes,
# per-file tar padding/headers, future manifest identities and the final gzip footer.
bundle_upper=len(encoded)+128*1024+32*1024+24*1024+8192
readable_upper=pp['bytes']+128*1024+caller['bytes']+postp['bytes']+sum(q['bytes'] for q in methods[:3])+8192
allocated_upper=((bundle_upper+4095)//4096*4096)+readable_upper+32*4096
assert allocated_upper<768*1024
assert md(os.lstat(zip_path))==zbefore
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576
proof={'proposal':simple(pp),'authorSeal':simple(sp),'methods':methods,'sealedAuthorRecordCount':len(sealed),'fourFreshRawBodiesAndMetadata':raw,'capsules':caps,'exactLogicalMapping':mappings,'currentConsumerSourcePins':consumer,'extraCurrentBuildCallerPromotionPins':extra,'currentHold':simple(hold),'selectedMap':simple(selectedp),'currentCallerGate':simple(caller),'fullCurrent144BodiesDigest':hashlib.sha256(json.dumps(current,separators=(',',':')).encode()).hexdigest(),'branchSourcePin':simple(branchp),'confirmedHEAD':e['currentConfirmedHEAD'],'priorR3Controls':simple(priorp),'priorR3ExactMemberPinCount':len(priorpins),'priorR3POSTGate':simple(postp),'protectedZIPFullStatBefore':zbefore,'protectedZIPFullStatAfter':md(os.lstat(zip_path)),'protectedZIPBodyNeverOpened':True,'publisherModel':{'exactKnownBodyCount':len(plan),'knownBodyBytes':source_total,'deterministicKnownBundleBytes':len(encoded),'knownBundleSHA256':hashlib.sha256(encoded).hexdigest(),'knownFullRoundtrip':True,'futureIndependentPacketCapBytes':128*1024,'modeledBundleUpperBytes':bundle_upper,'modeledPublishedAllocationUpperBytes':allocated_upper,'hardPublicationAllocationCapBytes':768*1024,'initialPublisherFreeThresholdBytes':int(65.5*1048576),'GitEstimateBytes':int(1.5*1048576),'qualifiedEstimateNotOSBound':True},'grossAllocationBytes':2187264,'logicalRawBytes':2184240,'ownMaxRSSBytes':rss,'scope':'Source BEFORE only, no production methods executed; no Git/restore/cleanup/media decode/Node/native. All own reader FDs closed. Shared cgroup not exclusive accounting.','necessityLimit':'Known current source controls do not consume these historical two roots. Historical hardcoded gameplay/preservation needs exact NEW reconstruction and NEW adapted readers/mappings. No global future consumer or FD/mmap absence proof; live old-path need would block.'}
with (P/'PROOF.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'sourceBeforeNormal':True,'rawBodies':4,'capsuleFullBlobs':[c['fullBlobBodies'] for c in caps],'logicalRows':[c['logicalRows'] for c in caps],'currentBodies':144,'knownPublisherRoundtripBodies':len(plan),'modeledPublicationUpper':allocated_upper,'ownMaxRSSBytes':rss,'allOwnFDsClosed':True}))
