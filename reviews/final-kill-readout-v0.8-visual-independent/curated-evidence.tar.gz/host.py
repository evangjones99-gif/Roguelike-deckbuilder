from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from threading import Thread
import signal
for port,path in [(4520,'/workspace/scratch/hound-jaw-hinge-author-v08-r5/baseline/dist'),(4521,'/workspace/scratch/final-kill-readout-author-v08-r1/prototype/dist')]:
 s=ThreadingHTTPServer(('127.0.0.1',port),partial(SimpleHTTPRequestHandler,directory=path))
 Thread(target=s.serve_forever,daemon=True).start()
signal.pause()
