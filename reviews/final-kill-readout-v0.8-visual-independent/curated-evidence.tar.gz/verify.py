from pathlib import Path
import hashlib,json,sys
p=Path('/workspace/scratch/final-kill-readout-author-v08-r1'); m=json.loads((p/'FROZEN-FILES.json').read_text());assert hashlib.sha256((p/'FROZEN-FILES.json').read_bytes()).hexdigest()=='7b324e01f47fde70bcf98ff3f242be561fd15a3d88217195d981a40756d52dd4'
for n,i in m['files'].items():
 b=(p/n).read_bytes();assert len(b)==i['bytes'] and hashlib.sha256(b).hexdigest()==i['sha256'],n
ident=json.loads((p/'SOURCE-BUILD-IDENTITY.json').read_text());out=Path('/workspace/scratch/final-kill-readout-visual-independent-v08-r1')
roots={'baseline':Path('/workspace/scratch/hound-jaw-hinge-author-v08-r5/baseline/dist'),'candidate':p/'prototype/dist'}
for v,fs in ident['runtimeInputs'].items():
 for n,i in fs.items():
  b=Path(i['input']).read_bytes();assert len(b)==i['bytes'] and hashlib.sha256(b).hexdigest()==i['sha256'],(v,n)
for v,fs in ident['buildOutputs'].items():
 for n,i in fs.items():
  b=(roots[v]/n).read_bytes();assert len(b)==i['bytes'] and hashlib.sha256(b).hexdigest()==i['sha256'],(v,n)
with (out/sys.argv[1]).open('x') as f:json.dump({'authorManifestSha256':hashlib.sha256((p/'FROZEN-FILES.json').read_bytes()).hexdigest(),'authorFiles':len(m['files']),'sourceInputs':{v:len(fs) for v,fs in ident['runtimeInputs'].items()},'buildOutputs':{v:len(fs) for v,fs in ident['buildOutputs'].items()},'hosts':{v:str(x) for v,x in roots.items()},'identity':ident},f,indent=2)
print('Verified author171, source152, output110')
