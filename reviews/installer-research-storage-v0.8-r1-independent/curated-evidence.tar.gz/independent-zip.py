import hashlib,json,pathlib,stat,subprocess,zipfile
base=pathlib.Path(__file__).parent
frozen=base/'frozen-r1';fixtures=base/'independent-zip-fixtures';fixtures.mkdir()
pins=json.loads((frozen/'pins.json').read_text());results=[]
def run(name,mode,archive,spec,expect=True,existing=False):
 request=fixtures/(name+'-spec.json');request.write_text(json.dumps(spec))
 output=fixtures/(name+'-output.bin')
 if existing:output.write_bytes(b'PRESERVE-INDEPENDENT-SENTINEL')
 proc=subprocess.run(['python3',str(frozen/'zip-verifier.py'),mode,str(archive),str(request),str(output)],capture_output=True,timeout=20)
 (fixtures/(name+'-stdout.txt')).write_bytes(proc.stdout);(fixtures/(name+'-stderr.txt')).write_bytes(proc.stderr)
 assert (proc.returncode==0)==expect,(name,proc.stderr.decode())
 if existing:assert output.read_bytes()==b'PRESERVE-INDEPENDENT-SENTINEL'
 results.append({'name':name,'expectedSuccess':expect,'exit':proc.returncode,'passed':True})
for pin in pins:run('actual-failed-evidence-'+str(pin['runId']),'evidence',frozen/'input-receipts'/str(pin['runId'])/'original-native-evidence.zip',pin)
payload=b'Independent actual parser fixture.';spec={'filename':'part-01.bin','bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
for name,method in [('valid-stored',zipfile.ZIP_STORED),('valid-deflated',zipfile.ZIP_DEFLATED)]:
 archive=fixtures/(name+'.zip')
 with zipfile.ZipFile(archive,'w',compression=method) as z:z.writestr(spec['filename'],payload)
 run(name,'part',archive,spec)
 run(name+'-exclusive-output','part',archive,spec,False,True)
valid=fixtures/'valid-stored.zip'
run('wrong-part-sha','part',valid,{**spec,'sha256':'0'*64},False)
run('wrong-part-size','part',valid,{**spec,'bytes':len(payload)+1},False)
for name,entry,compression in [('symlink','part-01.bin',zipfile.ZIP_STORED),('parent-traversal','../part-01.bin',zipfile.ZIP_STORED),('backslash','a\\part-01.bin',zipfile.ZIP_STORED),('bzip-refusal','part-01.bin',zipfile.ZIP_BZIP2)]:
 archive=fixtures/(name+'.zip');info=zipfile.ZipInfo(entry);info.compress_type=compression
 if name=='symlink':info.create_system=3;info.external_attr=(stat.S_IFLNK|0o777)<<16
 with zipfile.ZipFile(archive,'w') as z:z.writestr(info,payload)
 run(name,'part',archive,{**spec,'filename':entry},False)
bad=bytearray(valid.read_bytes());bad[30+len(spec['filename'])]^=1;archive=fixtures/'bad-crc.zip';archive.write_bytes(bad);run('actual-bad-crc','part',archive,spec,False)
pin=pins[0];original=frozen/'input-receipts'/str(pin['runId'])/'original-native-evidence.zip'
member='build-installer/installer-transfer/manifest.json'
with zipfile.ZipFile(original) as z:data={n:z.read(n) for n in z.namelist()}
manifest=json.loads(data[member]);manifest['nativeQAStatus']='passed';data[member]=(json.dumps(manifest,indent=2)+'\n').encode()
archive=fixtures/'failed-origin-cannot-relabel-passed.zip'
with zipfile.ZipFile(archive,'w') as z:
 for name,content in data.items():z.writestr(name,content)
changed=json.loads(json.dumps(pin))
for row in changed['evidence']['members']:
 if row['path']==member:row['bytes']=len(data[member]);row['sha256']=hashlib.sha256(data[member]).hexdigest()
run('failed-origin-cannot-relabel-passed','evidence',archive,changed,False)
(base/'independent-zip-results.json').write_text(json.dumps({'scope':'Independent actual fixed Python ZIP parser on all three original small receipts and own malformed/exclusive fixtures; no artifact code execution or remote writes','passed':len(results),'failures':0,'tests':results},indent=2)+'\n')
print(json.dumps({'passed':len(results),'failures':0}))
