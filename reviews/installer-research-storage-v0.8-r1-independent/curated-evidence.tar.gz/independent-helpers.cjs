const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const base=__dirname,source=fs.readFileSync(path.join(base,'frozen-r1/candidate-script.js'),'utf8');
const prefix=source.slice(0,source.indexOf('// BEGIN EXECUTION:'));
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const results=[];let calls=[];let responseFactory;
const core={getInput:()=> 'FAKE-INDEPENDENT-CREDENTIAL'};
const fetch=async(url,options)=>{calls.push({url,options});return responseFactory(url,options,calls.length);};
const success=(name,details={})=>results.push({name,passed:true,...details});
const rejects=async(name,fn)=>{await assert.rejects(fn);success(name);};
(async()=>{
 const h=await new AsyncFunction('require','core','context','github','fetch',prefix+'\nreturn {PINS,validateRun,validateArtifact,validRedirect,validateEndpoint,binaryResponse,consumeBinary,releaseIdentity,validateRelease,validateTag,coverage};')(require,core,{}, {},fetch);
 for(const hostname of ['productionresults.blob.core.windows.net','productionresultsabc123.blob.core.windows.net','release-assets.githubusercontent.com','objects.githubusercontent.com']){assert.equal(h.validRedirect('https://'+hostname+'/signed?fixture=1'),true);success('allow-trusted-signed-host-'+hostname);}
 for(const url of ['http://objects.githubusercontent.com/a','https://objects.githubusercontent.com.evil.invalid/a','https://objects.githubusercontent.com:444/a','https://user:pass@objects.githubusercontent.com/a','https://productionresultsabc.blob.core.windows.net.evil.invalid/a','https://api.github.com/a','https://evil.invalid/a','file:///tmp/a',null]){assert.equal(h.validRedirect(url),false);success('reject-redirect-'+String(url));}
 for(const [endpoint,purpose] of [['/repos/evangjones99-gif/Roguelike-deckbuilder/actions/artifacts/1/zip','actions-artifact'],['/repos/evangjones99-gif/Roguelike-deckbuilder/releases/assets/2','release-asset']]){h.validateEndpoint(endpoint,purpose);success('allow-fixed-endpoint-'+purpose);}
 for(const endpoint of ['/repos/foreign/Roguelike-deckbuilder/releases/assets/2','/repos/evangjones99-gif/Roguelike-deckbuilder/releases/assets/0','/repos/evangjones99-gif/Roguelike-deckbuilder/releases/assets/1?x=1','https://evil.invalid/a','/repos/evangjones99-gif/Roguelike-deckbuilder/actions/artifacts/2/zip']){assert.throws(()=>h.validateEndpoint(endpoint,'release-asset'));success('reject-endpoint-'+endpoint);}
 for(const pin of h.PINS){
  const run=JSON.parse(fs.readFileSync(path.join(base,'frozen-r1/live-run-'+pin.runId+'.json')));h.validateRun(run,pin);success('actual-failed-run-'+pin.runId);
  for(const [key,value] of [['conclusion','success'],['run_attempt',2],['event','pull_request'],['head_sha','0'.repeat(40)],['head_branch','main']]){assert.throws(()=>h.validateRun({...run,[key]:value},pin));success('reject-run-'+pin.runId+'-'+key);}
  const list=JSON.parse(fs.readFileSync(path.join(base,'frozen-r1/live-artifacts-'+pin.runId+'.json'))).artifacts;
  for(const expected of [...pin.parts,pin.evidence]){const original=list.find(a=>a.id===expected.artifactId);h.validateArtifact(original,pin,expected);success('actual-artifact-'+original.id);for(const [key,value] of [['expired','false'],['digest','sha256:'+'0'.repeat(64)],['id',-1]]){assert.throws(()=>h.validateArtifact({...original,[key]:value},pin,expected));success('reject-artifact-'+original.id+'-'+key);}}
  const identity=h.releaseIdentity(pin),valid={id:5,tag_name:pin.tag,target_commitish:pin.headSHA,draft:true,prerelease:true,...identity};h.validateRelease(valid,pin);success('valid-pinned-draft-'+pin.runId);
  for(const [key,value] of [['draft','true'],['prerelease',false],['target_commitish','0'.repeat(40)],['body',identity.body+'\nforeign'],['id',2**53]]){assert.throws(()=>h.validateRelease({...valid,[key]:value},pin));success('reject-draft-'+pin.runId+'-'+key);}
  const ref={ref:'refs/tags/'+pin.tag,object:{type:'commit',sha:pin.headSHA}};h.validateTag(ref,pin);assert.throws(()=>h.validateTag({...ref,object:{type:'tag',sha:pin.headSHA}},pin));success('reject-annotated-or-foreign-tag-'+pin.runId);
 }
 const endpoint='/repos/evangjones99-gif/Roguelike-deckbuilder/releases/assets/22';
 calls=[];responseFactory=(_url,_opts,index)=>index===1?new Response(null,{status:302,headers:{location:'https://objects.githubusercontent.com/signed?fixture=1'}}):new Response('abc',{status:200,headers:{'content-length':'3'}});
 await h.binaryResponse(endpoint,'release-asset',3);assert.equal(calls.length,2);assert.equal(calls[0].url,'https://api.github.com'+endpoint);assert.equal(calls[0].options.headers.Authorization,'Bearer FAKE-INDEPENDENT-CREDENTIAL');assert.equal(calls[1].options.headers,undefined);success('signed-redirect-drops-all-credentials-and-headers');
 calls=[];responseFactory=()=>new Response(null,{status:302,headers:{location:'https://evil.invalid/a'}});await rejects('evil-redirect-before-second-fetch',()=>h.binaryResponse(endpoint,'release-asset',3));assert.equal(calls.length,1);
 calls=[];responseFactory=(_u,_o,i)=>new Response(null,{status:302,headers:{location:'https://objects.githubusercontent.com/'+i}});await rejects('second-redirect-not-followed',()=>h.binaryResponse(endpoint,'release-asset',3));assert.equal(calls.length,2);
 calls=[];responseFactory=()=>new Response('abc',{status:200,headers:{'content-length':'4'}});await rejects('header-size-above-pin',()=>h.binaryResponse(endpoint,'release-asset',3));
 const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
 await h.consumeBinary(new Response('abc'),3,sha('abc'));success('actual-small-stream-complete-sha');
 await rejects('actual-stream-wrong-sha',()=>h.consumeBinary(new Response('abc'),3,'0'.repeat(64)));
 await rejects('actual-stream-short-body',()=>h.consumeBinary(new Response('ab'),3,sha('abc')));
 await rejects('actual-stream-byte-overrun',()=>h.consumeBinary(new Response('abcd'),3,sha('abcd')));
 const sentinel=path.join(base,'owned-destination-sentinel.bin');fs.writeFileSync(sentinel,'UNCHANGED',{flag:'wx'});await rejects('exclusive-destination-preserves-existing-file',()=>h.consumeBinary(new Response('abc'),3,sha('abc'),sentinel));assert.equal(fs.readFileSync(sentinel,'utf8'),'UNCHANGED');
 fs.writeFileSync(path.join(base,'independent-helpers-results.json'),JSON.stringify({scope:'Independent source/helper tests with actual streams/crypto and fake in-process API/fetch; no live writes or installer execution',passed:results.length,failures:0,tests:results},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({passed:results.length,failures:0}));
})().catch(e=>{console.error(e);process.exitCode=1;});
