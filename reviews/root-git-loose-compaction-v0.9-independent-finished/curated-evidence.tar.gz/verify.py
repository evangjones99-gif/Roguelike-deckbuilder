from pathlib import Path
import os,stat,hashlib,json,gzip,struct,subprocess
P=Path('/workspace/scratch/git-compaction-finished-independent-r1')
R=Path('/workspace/Roguelike-deckbuilder');G=R/'.git'
Q=R/'reviews/root-git-loose-compaction-v0.9/probe-r1'
S=G/'objects/hollowpact-bounded-r1';C='9df113d0f8345ab53202de176f58359847fee9c1';N='pack-'+C
D=S/'published/objects/pack';T=G/'objects/pack';minimum=2**63
def memory():
 global minimum
 b=Path('/sys/fs/cgroup');h=int((b/'memory.max').read_text())-int((b/'memory.current').read_text())
 minimum=min(h,minimum);assert h>=640*1024**2
def free():
 v=os.statvfs(G);return v.f_bavail*v.f_frsize
def meta(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_blocks*512,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024**2):memory();h.update(b)
 return h.hexdigest()
def git(a,data=None,env=None):
 p=subprocess.run(['git',*a],cwd=R,input=data,env=env,capture_output=True)
 assert p.returncode==0,(p.returncode,p.stderr.decode());return p.stdout
start=free();assert start>=1024**2+16384
inp=(Q/'INPUTS.json.gz').read_bytes();pub=(Q/'PUBLISHED.json').read_bytes();fin=(Q/'FINISHED.json').read_bytes()
assert hashlib.sha256(inp).hexdigest()=='8ac82ca3329ae3b46cd6bc07dd48d4a76c2112984647daf4e02cc8ae066d4490'
assert hashlib.sha256(pub).hexdigest()=='a07bcd27be6a33106ffee9f3783365c2eb1f2dea9e4c490a3620585d63b33bef'
assert hashlib.sha256(fin).hexdigest()=='a672823fb05542a05b22b6ad8f02839bc1f4d2e3d35a75422a2d6fb96ab692e1'
assert digest(R/'reviews/root-git-loose-compaction-v0.9/bounded-compaction.py')=='bb5ad7aa1bcdfa6cf4cd5ce7ad6cde25955f1fee2d0ebf12b2b87b1ff2498596'
j=json.loads(gzip.decompress(inp));published=json.loads(pub);finished=json.loads(fin)
allrows=j['inventory'];mapping={r['oid']:r for r in allrows}
selected={r['oid']:{**mapping[r['oid']],**r} for r in j['selected']}
untouched=[r for r in allrows if r['oid'] not in selected]
assert len(allrows)==len(mapping)==1330 and len(selected)==310 and len(untouched)==1020
a=json.loads((Q/'INDEPENDENT-PUBLICATION-ACCEPTANCE.json').read_bytes())
assert a['publishedSHA256']==hashlib.sha256(pub).hexdigest()
assert a['acceptedPackSHA256']==finished['pair']['packSHA256']
assert a['reviewSHA256']=='95c32a86ef771492dc0541e11ad1fc0356a164c04214d3039a74cf4a7bcba2c5'
assert hashlib.sha256(Path(a['reviewPath']).read_bytes()).hexdigest()==a['reviewSHA256']
assert finished['pair']==published['pair'] and finished['objectsRetained']==finished['redundantLooseEncodingsRemoved']==310
actual=[]
for d in sorted((G/'objects').iterdir()):
 if len(d.name)!=2 or any(c not in '0123456789abcdef' for c in d.name):continue
 assert d.is_dir() and not d.is_symlink()
 for p in sorted(d.iterdir()):
  assert len(p.name)==38 and all(c in '0123456789abcdef' for c in p.name)
  actual.append(d.name+p.name)
assert actual==[r['oid'] for r in untouched]
encoded=0
for r in untouched:
 p=G/'objects'/r['oid'][:2]/r['oid'][2:]
 assert meta(p)==r['metadata'] and digest(p)==r['encodedSHA256'] and meta(p)==r['metadata']
 encoded+=r['metadata'][5]
for oid in selected:assert not (G/'objects'/oid[:2]/oid[2:]).exists()
identity=published['identity']
assert (G/'HEAD').read_bytes().hex()==identity['HEAD']
assert git(['for-each-ref','--format=%(refname) %(objectname)']).decode()==identity['refs']
refnames={str(p.relative_to(G)) for p in (G/'refs').rglob('*') if p.is_file()}
if (G/'packed-refs').exists():refnames.add('packed-refs')
assert refnames==set(identity['referenceFiles'])
for n,(m,h) in identity['referenceFiles'].items():assert meta(G/n)==m and digest(G/n)==h
assert set(p.name for p in T.iterdir())==set(identity['packs'])
for n,m in identity['packs'].items():assert meta(T/n)==m
assert set(p.name for p in D.parent.iterdir())=={'pack'}
assert set(p.name for p in D.iterdir())=={N+'.pack',N+'.idx'}
for p in [S,S/'published',D.parent,D]:assert p.is_dir() and not p.is_symlink()
for ext in ['pack','idx']:
 assert meta(T/(N+'.'+ext))==meta(D/(N+'.'+ext))==meta(S/('objects/pack/candidate.'+ext))
 assert meta(T/(N+'.'+ext))[-1]==3
b=(T/(N+'.pack')).read_bytes();i=(T/(N+'.idx')).read_bytes();pair=finished['pair']
assert hashlib.sha256(b).hexdigest()==pair['packSHA256'] and hashlib.sha256(i).hexdigest()==pair['indexSHA256']
assert b[:4]==b'PACK' and struct.unpack('>II',b[4:12])==(2,310)
assert hashlib.sha1(b[:-20]).digest()==b[-20:] and b[-20:].hex()==C
assert i[:8]==b'\xfftOc\0\0\0\2' and hashlib.sha1(i[:-20]).digest()==i[-20:] and i[-40:-20]==b[-20:]
oids=[i[1032+20*n:1052+20*n].hex() for n in range(310)];assert oids==sorted(selected)
native=git(['verify-pack','-v',str(D/(N+'.idx'))]).decode()
entries=[x.split() for x in native.splitlines() if len(x.split()[0])==40 and all(c in '0123456789abcdef' for c in x.split()[0])]
assert len(entries)==310 and {e[0] for e in entries}==set(selected)
env=os.environ.copy()
for k in ['GIT_DIR','GIT_COMMON_DIR','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_REPLACE_REF_BASE','GIT_SHALLOW_FILE']:env.pop(k,None)
env.update(GIT_OBJECT_DIRECTORY=str(D.parent),GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1')
got=git(['cat-file','--batch'],('\n'.join(oids)+'\n').encode(),env);offset=0;rawbytes=0
for oid in oids:
 r=selected[oid];end=got.index(b'\n',offset)
 assert got[offset:end]==f"{oid} {r['type']} {r['size']}".encode()
 offset=end+1;body=got[offset:offset+r['size']];offset+=r['size']
 assert got[offset:offset+1]==b'\n';offset+=1
 assert hashlib.sha256(body).hexdigest()==r['bodySHA256']
 assert hashlib.sha1(f"{r['type']} {r['size']}".encode()+b'\0'+body).hexdigest()==oid
 rawbytes+=len(body)
assert offset==len(got) and rawbytes==336620
assert set(p.name for p in D.iterdir())=={N+'.pack',N+'.idx'}
assert digest(S/'objects/pack/candidate.rev')=='0dd882865851e061c90288b07400fcaa72fe18e5069c6b5203ab9a79e6d8230b'
for n,m in identity['packs'].items():assert meta(T/n)==m
assert (Q/'INPUTS.json.gz').read_bytes()==inp and (Q/'PUBLISHED.json').read_bytes()==pub and (Q/'FINISHED.json').read_bytes()==fin
count=git(['count-objects','-v']).decode()
counts=dict(line.split(': ',1) for line in count.splitlines())
assert counts['count']=='1020' and counts['in-pack']=='3852' and counts['packs']=='2'
assert counts['prune-packable']==counts['garbage']==counts['size-garbage']=='0'
assert free()>=1024**2+16384
result={'scope':'Independent narrow actual finish closure:310 pinned full raw bodies preserved;1020 untouched encodings exact; no all4872 raw/full-history or future batch claim.',
 'finishedSHA256':hashlib.sha256(fin).hexdigest(),'publishedSHA256':hashlib.sha256(pub).hexdigest(),
 'packSHA256':pair['packSHA256'],'indexSHA256':pair['indexSHA256'],
 'selectedFullRawTypeSizeSHA1SHA256Verified':310,'selectedBodyBytes':rawbytes,
 'onlySelectedLoosePathsAbsent':310,'untouchedEncodedSHA256FullMetadata':1020,'untouchedEncodedBytesStreamed':encoded,
 'exactPairMembershipChecksumStandaloneReads':True,'refsHEADRefFilesOldPackMetadataUnchanged':True,
 'gitCountObjects':counts,'rootMeasuredFreeRecoveryPreFinalReceipt':finished['measuredFreeRecovery'],
 'freeBeforeReview':start,'freeAfterChecks':free(),'minimumCgroupHeadroom':minimum,
 'reviewerObjectMutation':False,'acceptedClosureThisBatchOnly':True}
(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');(P/'PINNED-FINISHED.json').write_bytes(fin)
print(json.dumps(result,indent=2))
