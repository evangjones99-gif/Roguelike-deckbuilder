import collections,hashlib,json,os,stat,tarfile,datetime
from pathlib import Path
OUT=Path(__file__).parent;ROOT=Path('/workspace/Roguelike-deckbuilder/reviews/root-tmp-runtime-capacity-v0.8')
AUDIT=Path('/workspace/scratch/tmp-runtime-capacity-independent-v08-r1/AUDIT.json')
OWNER=Path('/workspace/Roguelike-deckbuilder/reviews/tmp-runtime-sharing-v0.8-plan-independent/curated-evidence.tar.gz')
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
inputs=[]
for p in [AUDIT,ROOT/'BEFORE.json',ROOT/'AFTER.json',ROOT/'JOURNAL.jsonl',ROOT/'consolidate.py',OWNER]:inputs.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
audit=json.loads(AUDIT.read_text());before=json.loads((ROOT/'BEFORE.json').read_text());after=json.loads((ROOT/'AFTER.json').read_text())
assert before['auditSHA256']==after['auditSHA256']==sha(AUDIT)
assert sha(ROOT/'consolidate.py')=='577d71a18f3a9b45e8c9abcf20439daf2358ad98c2c687bac4297b9a7a52c283'
with tarfile.open(OWNER) as t:
 raw=t.extractfile('OWNERSHIP-XATTR-READONLY.json').read();assert hashlib.sha256(raw).hexdigest()=='55e066ed7543a0c2f5cad2a2ad4a4a45afe9f0862caa3fc83a1380aeb3633bb9'
 owner=json.loads(raw)
oldowners={r['path']:r for g in owner['groupsAudited'] for r in g['records']};assert len(oldowners)==840
groups=audit['runtime_candidate_duplicate_groups'];eligible={p for g in groups for p in g['paths']};assert len(eligible)==840
rows=[];counts=collections.Counter();groupresults=[];aliases=collections.defaultdict(list)
for inventory in audit['complete_inventories']:
 root=Path(inventory['root']);expected={r['path'] for r in inventory['rows']};actual={str(root),*(str(p) for p in root.rglob('*'))};assert actual==expected==set(before['memberships'][str(root)])
 for r in inventory['rows']:
  p=Path(r['path']);s=p.lstat();typ='file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'other'
  m={'type':typ,'size':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns,'blocks':s.st_blocks,'uid':s.st_uid,'gid':s.st_gid,'xattrs':{n:os.getxattr(p,n,follow_symlinks=False).hex() for n in sorted(os.listxattr(p,follow_symlinks=False))}}
  assert typ==r['before']['type'] and m['mode']==r['before']['mode']
  rootafter=after['after'][str(p)];assert all(m[k]==rootafter[k] for k in ('type','size','mode','device','inode','nlink','mtime_ns','ctime_ns','blocks'))
  row={'path':str(p),'current':m,'atimeReaderChangesQualified':True};counts[typ]+=1
  if typ=='file':
   h=sha(p);assert h==r['sha256'] and s.st_size==r['before']['size'];row['sha256']=h;aliases[(s.st_dev,s.st_ino)].append(str(p))
   if str(p) in eligible:
    prior=oldowners[str(p)];assert m['uid']==prior['uid'] and m['gid']==prior['gid'] and m['xattrs']==prior['xattrs'];row['ownershipXattrsMatchPriorIndependentSnapshot']=True
   else:
    old=before['before'][str(p)];assert all(m[k]==old[k] for k in ('type','size','mode','device','inode','nlink','mtime_ns','ctime_ns','blocks'));row['excludedInodeCtimeNlinkMtimeModeContentUnchanged']=True
  else:
   old=before['before'][str(p)];assert m['mtime_ns']==old['mtime_ns'] and m['device']==old['device'] and m['inode']==old['inode'] and m['nlink']==old['nlink'];row['originalDirectoryMtimeRestored']=True
  rows.append(row)
 print(json.dumps({'root':str(root),'completeContentModeAndMembershipPass':True}),flush=True)
for g in groups:
 members=[next(r for r in rows if r['path']==p) for p in g['paths']];identities={(r['current']['device'],r['current']['inode']) for r in members};assert len(identities)==1
 assert all(r['sha256']==g['sha256'] and r['current']['size']==g['bytes'] and r['current']['mode']==g['mode'] for r in members)
 assert len({(r['current']['uid'],r['current']['gid'],json.dumps(r['current']['xattrs'],sort_keys=True)) for r in members})==1
 groupresults.append({'sha256':g['sha256'],'bytes':g['bytes'],'mode':g['mode'],'device_inode':list(next(iter(identities))),'alias_count':len(members),'allOwnershipXattrsOriginalEqual':True,'paths':g['paths']})
for row in rows:
 if row['current']['type']=='file':assert row['current']['nlink']==len(aliases[(row['current']['device'],row['current']['inode'])])
journal=[json.loads(x) for x in (ROOT/'JOURNAL.jsonl').read_text().splitlines()];assert len(journal)==700==after['operations'];assert len({x['path'] for x in journal})==700
for j in journal:
 assert j['path'] in eligible and j['canonical'] in eligible
 assert before['before'][j['path']]['inode']==j['originalInode'];s=Path(j['path']).stat();assert s.st_ino==j['sharedInode']
 assert next(r['sha256'] for r in rows if r['path']==j['path'])==j['sha256']
assert counts=={'file':942,'directory':39}
for record in inputs:assert sha(Path(record['path']))==record['sha256'],'source receipt changed'
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceInputs':inputs,'all942ContentSizeModesPass':True,'all39DirectoryMembershipModesAndRestoredMtimePass':True,'all140SharingGroupsOneExactOwnershipModeContentInode':True,'all840SharedPathsOwnershipXattrsMatchIndependentPreflight':True,'all102ExcludedFilesContentInodeCtimeNlinkMtimeUntouched':True,'ownershipXattrScopeForExcluded':'Current uid/gid/xattrs recorded; unchanged inode/ctime/source transaction establishes untouched metadata. No nonexistent original owner/xattr sidecar is invented.','all700JournalOperationsMatchActualPaths':True,'rows':rows,'groups':groupresults,'forecastIncrementalAllocatedBytes':audit['incremental_allocated_saving_bytes'],'rootObservedFreeDelta':after['observedFreeDelta'],'observedDeltaIncludesUnrelatedWriters':True,'currentFreeBytes':{p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ('/tmp','/workspace')},'mutationsPerformed':False,'tmpIsDurableBackup':False}
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
