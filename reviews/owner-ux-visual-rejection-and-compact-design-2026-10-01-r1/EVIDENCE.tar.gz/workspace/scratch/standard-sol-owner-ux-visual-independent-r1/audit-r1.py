from pathlib import Path
import json,hashlib,urllib.request,urllib.parse,os,sys
P=Path('/workspace/scratch/standard-sol-owner-ux-visual-independent-r1');H=lambda b:hashlib.sha256(b).hexdigest();data=[]
for name,root,url,digest,count in [('baseline',Path('/tmp/hollowpact-event-availability-v09-root-r2'),sys.argv[2],'801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029',78),('candidate',Path('/dev/shm/hollowpact-owner-ux-overhaul-root-r1'),sys.argv[3],'2f1fd23d0af5d43d7ee1ed9242063404bd242702df44d2db7b15f007e8306629',82)]:
 prov=json.loads((root/'dist/build-provenance.json').read_text());assert prov['sourceDigest']==digest
 names=[]
 for d in ['src','desktop','public']:
  for folder,dirs,files in os.walk(root/d,followlinks=True):names.extend((Path(folder)/n).relative_to(root).as_posix()for n in files)
 names+=['index.html','THIRD-PARTY.md','package.json','package-lock.json','tsconfig.json','vite.config.ts','scripts/build.mjs'];names.sort();assert len(names)==count and names==list(prov['hashes']);sources={n:H((root/n).read_bytes())for n in names};assert sources==prov['hashes'];assert H(json.dumps(sources,separators=(',',':'),ensure_ascii=False).encode())==digest
 outputs=[]
 for f in sorted((root/'dist').rglob('*')):
  if not f.is_file():continue
  n=f.relative_to(root/'dist').as_posix();b=f.read_bytes();r=urllib.request.urlopen(url.rstrip('/')+'/'+urllib.parse.quote(n));assert r.status==200 and r.read()==b;outputs.append({'path':n,'bytes':len(b),'sha256':H(b),'HTTPExact':True})
 assert len(outputs)==56;data.append({'variant':name,'sourceRoot':str(root),'HTTPBase':url,'provenance':prov,'completeSourceNames':names,'outputs':outputs})
f=P/('AUDIT-'+sys.argv[1]+'.json');assert not f.exists();f.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps([{'variant':x['variant'],'inputs':len(x['completeSourceNames']),'outputs':len(x['outputs'])}for x in data]))
