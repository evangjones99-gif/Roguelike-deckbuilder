/** Canvas-relative CSS pixels shared by paint and accessible DOM controls. */
export type BattlefieldSide = 'ally' | 'enemy';
export interface BattlefieldPoint { x: number; y: number }
export interface BattlefieldRect { left: number; top: number; width: number; height: number }
export interface ArenaUnitRegion extends BattlefieldRect {
  uid: string;
  side: BattlefieldSide;
  slot: number;
  feetX: number;
  feetY: number;
  /** Presentation availability only. The reducer remains action authority. */
  disabled: boolean;
  dead: boolean;
  departing: boolean;
  /** Stable slot ownership/readout cell, separate from the moving painted quad. */
  cell?: ArenaFormationCell;
}
export interface ArenaUnitViewport {
  width: number;
  height: number;
  canvasAvailable: boolean;
}

export interface ArenaFormationCell extends BattlefieldRect {
  bodyTop: number;
  bodyHeight: number;
}
export const FIELD_NARROW_WIDTH = 960;
const PAD = 12, GAP = 12, ZONE_GAP = 24;
const INTENT = 52, NAME = 52, STATS = 40, STATUS = 36;
const ALLY_X = [.065, .935, .205, .795, .345, .655] as const;

function metrics(width: number, side: BattlefieldSide, count: number) {
  const narrow = width <= FIELD_NARROW_WIDTH;
  const bodyHeight = narrow ? 88 : 152;
  const columns = narrow ? side === 'enemy' ? 3 : 2 : Math.max(1, count);
  const rows = narrow ? Math.ceil(Math.max(1, count) / columns) : 1;
  const height = bodyHeight + NAME + STATS + (side === 'enemy' ? INTENT + STATUS : STATUS);
  const cellWidth = narrow ? (width - PAD * 2 - GAP * 2) / 3
    : side === 'enemy' ? (width - PAD * 2 - GAP * (columns - 1)) / columns
      : Math.min(160, width * .125);
  return { narrow, bodyHeight, columns, rows, height, cellWidth };
}

/** Host sets this canvas minimum before resize; counts include retained slots. */
export function battlefieldRequiredHeight(width: number, allies: number, enemies: number): number {
  const a = metrics(width, 'ally', allies), e = metrics(width, 'enemy', enemies);
  const extent = (m: ReturnType<typeof metrics>) => m.rows * m.height + (m.rows - 1) * GAP;
  return Math.max(width <= FIELD_NARROW_WIDTH ? 420 : 660,
    PAD * 2 + extent(a) + ZONE_GAP + extent(e));
}

/** Stable legal slot order; narrow allies leave the whole center lane to the hunter. */
export function formationCell(width: number, height: number, side: BattlefieldSide,
  slot: number, count: number): ArenaFormationCell {
  const m = metrics(width, side, count);
  const row = m.narrow ? Math.floor(slot / m.columns) : 0;
  const top = side === 'enemy' ? PAD + row * (m.height + GAP)
    : height - PAD - m.rows * m.height - (m.rows - 1) * GAP + row * (m.height + GAP);
  const left = m.narrow ? side === 'enemy' ? PAD + (slot % 3) * (m.cellWidth + GAP)
    : slot % 2 === 0 ? PAD : width - PAD - m.cellWidth
    : side === 'enemy' ? PAD + slot * (m.cellWidth + GAP)
      : width * (count <= 2 ? slot === 0 ? .22 : .78 : count <= 4
        ? [.12, .88, .32, .68][slot] : ALLY_X[slot]) - m.cellWidth / 2;
  return { left, top, width: m.cellWidth, height: m.height,
    bodyTop: side === 'enemy' ? INTENT : 0, bodyHeight: m.bodyHeight };
}

/** Full original hunter cell fits the reserved lane across every unchanged pose. */
export function battlefieldHunterCellLimit(width: number): number {
  const ally = metrics(width, 'ally', 6);
  return width <= FIELD_NARROW_WIDTH ? width - 2 * (PAD + ally.cellWidth) - GAP
    : width * .31 - ally.cellWidth - GAP;
}

/** Paint, depth, attack endpoints and DOM cells consume the same formation. */
export function formationPosition(width: number, height: number, side: BattlefieldSide,
  slot: number, count: number): BattlefieldPoint {
  const cell = formationCell(width, height, side, slot, count);
  return { x: cell.left + cell.width / 2, y: cell.top + cell.bodyTop + cell.bodyHeight - 24 };
}

export function formationSize(width: number, height: number, side: BattlefieldSide,
  count: number, species: string): number {
  const cell = formationCell(width, height, side, 0, count);
  // Hound crops are 448:384 at 1.1 scale; warleader is 512:448 at 1.1.
  // Portrait cells are square. Reserve recoil/breath and unchanged lower fringe.
  // Future atlases need measured maximum dimensions, not an assumed ratio.
  const authoredScale = /hound|warlord/.test(species) ? 1.1 : 1;
  const aspect = /hound/.test(species) ? 448 / 384 : /warlord/.test(species) ? 512 / 448 : 1;
  return Math.max(0, Math.min((cell.width - 8) / (authoredScale * aspect),
    (cell.bodyHeight - 24) / authoredScale));
}

/** The same source-cell rectangle and transform used by drawImage. */
export function transformedImageRect(origin: BattlefieldPoint, facing: -1 | 1,
  breath: number, width: number, height: number, anchorX: number, anchorY: number): BattlefieldRect {
  const a = -width * anchorX * facing, b = width * (1 - anchorX) * facing;
  return { left: origin.x + Math.min(a, b), top: origin.y - height * anchorY * breath,
    width: Math.abs(b - a), height: height * breath };
}

export function unionRects(a: BattlefieldRect, b: BattlefieldRect): BattlefieldRect {
  const left = Math.min(a.left, b.left), top = Math.min(a.top, b.top);
  const right = Math.max(a.left + a.width, b.left + b.width);
  const bottom = Math.max(a.top + a.height, b.top + b.height);
  return { left, top, width: right - left, height: bottom - top };
}

/** Paint outside the canvas is clipped; its controls use the same viewport. */
export function clipToViewport(rect: BattlefieldRect, width: number, height: number): BattlefieldRect {
  const left = Math.max(0, Math.min(width, rect.left));
  const top = Math.max(0, Math.min(height, rect.top));
  const right = Math.max(left, Math.min(width, rect.left + rect.width));
  const bottom = Math.max(top, Math.min(height, rect.top + rect.height));
  return { left, top, width: right - left, height: bottom - top };
}
