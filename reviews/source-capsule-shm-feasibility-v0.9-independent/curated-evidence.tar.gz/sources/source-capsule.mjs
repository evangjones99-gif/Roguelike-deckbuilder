import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {execFileSync,spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {pipeline} from 'node:stream/promises';
import {Writable,Readable} from 'node:stream';
import {createGunzip} from 'node:zlib';
import {sha256File} from './sha256-file.mjs';
import {verifyBundle} from './source-bundle.mjs';

const branch='refs/heads/codex/lanternbound-production';
const limit=16*1024*1024, margin=512*1024*1024;
const oid=/^[a-f0-9]{40}$/,sha=/^[a-f0-9]{64}$/;
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const check=(value,message)=>{if(!value)throw Error(message);};
const git=(root,args,input)=>execFileSync('git',args,{cwd:root,encoding:'utf8',input,maxBuffer:limit});
const list=text=>text.trim().split('\n').filter(Boolean).sort();
const refs=commit=>[{commit,ref:'HEAD'},{commit,ref:branch}].sort((a,b)=>a.ref.localeCompare(b.ref));
const closure=(root,commit)=>list(git(root,['rev-list','--objects','--no-object-names',commit]));
const objectList=(root)=>list(git(root,['cat-file','--batch-all-objects','--batch-check=%(objectname)']));
const immutableJSON=(file,data)=>fs.writeFileSync(file,JSON.stringify(data,null,2)+'\n',{flag:'wx',mode:0o600});
function baselineDescriptor(pin){
  check(pin&&same(Object.keys(pin).sort(),['archive','bytes','format','schema','sha256','sourceCommit','version'].sort()),'Baseline descriptor keys differ');
  check(pin.schema===1&&pin.format==='git-bundle-v2-full'&&pin.version==='0.8.0','Exactly one full0.8 v2 baseline is required');
  check(oid.test(pin.sourceCommit)&&sha.test(pin.sha256)&&Number.isSafeInteger(pin.bytes)&&pin.bytes>16,'Invalid baseline identity');
  check(typeof pin.archive==='string'&&/^[a-z0-9][a-z0-9-]*-0\.8\.0-source\.bundle$/.test(pin.archive),'Invalid baseline archive basename');
  return {...pin};
}
function regular(file){const s=fs.lstatSync(file);check(s.isFile()&&!s.isSymbolicLink(),'Archive must be a present regular local file');return s;}
async function pinnedFile(file,pin){check(path.basename(file)===pin.archive,'Archive basename differs from descriptor');check(regular(file).size===pin.bytes,'Pinned archive size differs');check(await sha256File(file)===pin.sha256,'Pinned archive whole SHA256 differs');}
export function readV2Header(file){
  const fd=fs.openSync(file,'r'),bytes=Buffer.alloc(128*1024);let n;
  try{n=fs.readSync(fd,bytes,0,bytes.length,0);}finally{fs.closeSync(fd);}
  const b=bytes.subarray(0,n);check(b.subarray(0,16).equals(Buffer.from('# v2 git bundle\n')),'Only exact bundle v2 is supported');
  const split=b.indexOf(Buffer.from('\n\n'),16);check(split>=0&&split<128*1024-12,'Bounded bundle header terminator missing');
  const lines=new TextDecoder('utf-8',{fatal:true}).decode(b.subarray(16,split)).split('\n');
  const prerequisites=[],advertised=[];
  for(const line of lines){
    if(line.startsWith('-')){const m=line.match(/^-([a-f0-9]{40})(?: [^\0\r]*)?$/);check(m,'Malformed prerequisite line');prerequisites.push(m[1]);}
    else{const m=line.match(/^([a-f0-9]{40}) (HEAD|refs\/heads\/codex\/lanternbound-production)$/);check(m,'Unexpected or malformed advertised ref');advertised.push({commit:m[1],ref:m[2]});}
  }
  check(new Set(prerequisites).size===prerequisites.length,'Duplicate bundle prerequisite');
  check(advertised.length===2&&new Set(advertised.map(r=>r.ref)).size===2,'Exactly two unique source refs are required');
  const packStart=split+2;check(b.subarray(packStart,packStart+4).equals(Buffer.from('PACK')),'PACK header missing');
  const packVersion=b.readUInt32BE(packStart+4),packObjects=b.readUInt32BE(packStart+8);check([2,3].includes(packVersion)&&packObjects>0,'Invalid PACK version/count');
  return {format:'git-bundle-v2',advertised:advertised.sort((a,b)=>a.ref.localeCompare(b.ref)),prerequisites:prerequisites.sort(),packStart,packVersion,packObjects};
}
function sourcePlan(root,commit,pin){
  check(oid.test(commit),'Expected source commit must be SHA1');
  check(git(root,['rev-parse','--show-object-format']).trim()==='sha1','Only SHA1 repositories are supported');
  check(git(root,['rev-parse','--is-shallow-repository']).trim()==='false','Shallow source is unsupported');
  check(commit!==pin.sourceCommit,'Capsule must advance the baseline');
  git(root,['merge-base','--is-ancestor',pin.sourceCommit,commit]);
  const baseline=closure(root,pin.sourceCommit),target=closure(root,commit),baseSet=new Set(baseline);
  check(baseline.every(id=>target.includes(id)),'Baseline is not wholly reachable from target');
  const added=target.filter(id=>!baseSet.has(id));check(added.length>0,'Empty incremental source closure');
  const prerequisites=list(git(root,['rev-list','--boundary',commit,'^'+pin.sourceCommit]).split('\n').filter(l=>l.startsWith('-')).map(l=>l.slice(1)).join('\n'));
  check(prerequisites.length>0&&prerequisites.every(id=>oid.test(id)&&baseSet.has(id)),'Prerequisites escape the single baseline');
  const pkg=JSON.parse(git(root,['show',commit+':package.json'])),old=JSON.parse(git(root,['show',pin.sourceCommit+':package.json']));
  check(old.version==='0.8.0'&&old.name===pkg.name,'Baseline version/package identity differs');
  const version=typeof pkg.version==='string'&&pkg.version.match(/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([a-z0-9]+(?:\.[a-z0-9]+)*))?$/);
  check(version&&[version[1],version[2],version[3]].every(v=>Number.isSafeInteger(Number(v)))
    &&(!version[4]||version[4].split('.').every(v=>!/^\d+$/.test(v)||!/^0\d/.test(v)))
    &&(Number(version[1])>0||Number(version[2])>8||(Number(version[2])===8&&Number(version[3])>0)),'New capsule version must advance the stable0.8 baseline');
  check(typeof pkg.name==='string'&&/^[a-z0-9][a-z0-9-]*$/.test(pkg.name),'Unsupported package name');
  check(pin.archive===`${pkg.name}-0.8.0-source.bundle`,'Baseline archive does not name this package');
  const sizes=git(root,['cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],added.join('\n')+'\n').trim().split('\n');
  check(sizes.length===added.length,'Incremental object-size inventory differs');let rawAddedBytes=0;
  for(const line of sizes){const m=line.match(/^([a-f0-9]{40}) (blob|tree|commit) ([0-9]+)$/);check(m&&added.includes(m[1]),'Invalid source object inventory');rawAddedBytes+=Number(m[3]);check(Number.isSafeInteger(rawAddedBytes),'Source byte budget overflow');}
  return {baseline,target,added,prerequisites,rawAddedBytes,pkg};
}
function capacity(directory,required,label){const s=fs.statfsSync(directory,{bigint:true});check(BigInt(required)<=s.bavail*s.bsize,`Insufficient ${label} capacity`);}
// index-pack streams one pack inode then links/renames it, without a full copy.
// An empty-store capsule proof and final import retain two small capsule packs.
function pairBudget(baseBytes,capsuleBytes,baselineObjects,addedObjects){
  const indexes=64*(baselineObjects+2*addedObjects)+3*65536+2*1024*1024;
  const required=baseBytes+2*capsuleBytes+indexes+margin;
  check(Number.isSafeInteger(required),'Pair byte budget overflow');
  return {baselinePackUpperBytes:baseBytes,capsulePackCopies:2,capsulePackUpperBytes:capsuleBytes,
    indexAndBareMetadataUpperBytes:indexes,safetyReserveBytes:margin,requiredTemporaryBytes:required,
    scope:'One full baseline pack plus two independently proved non-thin capsule packs. The 512MiB reserve is unchanged; no baseline input copy or source ZIP is created.'};
}
async function streamedGit(root,args,input,output){
  const child=spawn('git',args,{cwd:root,stdio:['pipe','pipe','pipe']});
  const chunks=[],errors=[];let stdoutBytes=0,stderrBytes=0;
  if(!output)child.stdout.on('data',b=>{stdoutBytes+=b.length;if(stdoutBytes>limit)child.kill();else chunks.push(b);});
  child.stderr.on('data',b=>{stderrBytes+=b.length;if(stderrBytes>limit)child.kill();else errors.push(b);});
  const exited=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});
  const transfers=[pipeline(input,child.stdin)];if(output)transfers.push(pipeline(child.stdout,output));
  const all=await Promise.allSettled([...transfers,exited]),done=all.pop();
  if(done.status==='rejected')throw done.reason;
  const results=all,result=done.value;
  check(stdoutBytes<=limit&&stderrBytes<=limit,'Git stream diagnostic exceeds bounded capture');
  check(result.code===0,`Git stream failed (${result.code??result.signal}): ${Buffer.concat(errors).toString('utf8')}`);
  for(const r of results)if(r.status==='rejected')throw r.reason;
  return {stdout:Buffer.concat(chunks).toString('utf8'),stderr:Buffer.concat(errors).toString('utf8')};
}
async function writeNonThinCapsule(root,file,commit,pin,plan){
  const header='# v2 git bundle\n'+plan.prerequisites.map(id=>`-${id} retained full0.8 baseline dependency\n`).join('')
    +refs(commit).map(r=>`${r.commit} ${r.ref}\n`).join('')+'\n';
  fs.writeFileSync(file,header,{flag:'wx',mode:0o600});
  // bundle create requests --thin. A non-thin pack-objects payload inside a
  // standard v2 header still requires the baseline history. Disable reuse so
  // an existing source thin delta cannot cross that excluded boundary.
  await streamedGit(root,['pack-objects','--stdout','--revs','--no-reuse-delta','--no-reuse-object'],
    Readable.from([commit+'\n^'+pin.sourceCommit+'\n']),fs.createWriteStream(file,{flags:'a'}));
}
async function proveNonThinCapsule(file,header,temporary,plan){
  const bare=path.join(temporary,'capsule-pack.git');git(temporary,['init','--bare',bare]);
  check(objectList(bare).length===0,'Capsule quarantine must contain no objects or alternates');
  // No --fix-thin: external delta bases must fail in this empty store. This
  // checks pack/index bytes; complete history fsck/closure/blob proof follows.
  const result=await streamedGit(bare,['-c','index.version=2','-c','pack.writeReverseIndex=false','index-pack','--stdin'],
    fs.createReadStream(file,{start:header.packStart}));
  check(same(objectList(bare),plan.added),'Non-thin quarantine contains missing or extra incremental objects');
  const dir=path.join(bare,'objects','pack'),packs=fs.readdirSync(dir).filter(n=>n.endsWith('.pack'));
  check(packs.length===1,'Exactly one non-thin quarantine pack required');
  const pack=path.join(dir,packs[0]),bytes=regular(pack).size;
  check(bytes===regular(file).size-header.packStart,'Non-thin import unexpectedly expanded the capsule pack');
  return {nonThinProvedInEmptyStore:true,packBasename:packs[0],packBytes:bytes,packSHA256:await sha256File(pack),
    incrementalObjects:plan.added.length,indexPackOutput:result.stdout,indexPackStderr:result.stderr,
    scope:'Raw PACK indexes without --fix-thin or baseline objects; history requires the pinned baseline. New quarantine retained until successful proof/cleanup.'};
}
function capsuleDescriptor(pin,base,plan,commit){
  const keys=['archive','baseline','bytes','format','fullBackup','gitPrerequisites','schema','sha256','sourceCommit','standalone','version'];
  check(pin&&same(Object.keys(pin).sort(),keys.sort()),'Capsule descriptor keys differ');
  check(pin.schema===1&&pin.format==='git-bundle-v2-incremental'&&pin.standalone===false&&pin.fullBackup===false,'Capsule must be explicitly dependent');
  check(pin.sourceCommit===commit&&pin.version===plan.pkg.version&&pin.archive===`${plan.pkg.name}-${plan.pkg.version}-source-capsule.bundle`,'Capsule target identity differs');
  check(Number.isSafeInteger(pin.bytes)&&pin.bytes>16&&sha.test(pin.sha256),'Invalid capsule whole identity');
  check(same(pin.baseline,base)&&same(pin.gitPrerequisites,plan.prerequisites),'Capsule dependency descriptor differs');return pin;
}
async function canonicalIndex(source,restored,commit,identity,archive){
  const files=identity.files.filter(f=>f.path.startsWith('reviews/'));
  check(files.length>0&&files.every(f=>['100644','100755'].includes(f.mode)),'Missing or unsupported canonical review entries');
  const actual=git(restored,['ls-tree','-r','-z',commit,'--','reviews/']).split('\0').filter(Boolean).map(line=>line.slice(line.indexOf('\t')+1)).sort();
  check(same(actual,files.map(f=>f.path).sort()),'Canonical review path set differs');const rawGzipPairs=[];
  for(const file of files){
    if(!file.path.endsWith('.json.gz'))continue;
    const compressed=path.join(source,file.path),raw=compressed.slice(0,-3);if(!fs.existsSync(raw))continue;
    check(regular(compressed).size===file.bytes&&await sha256File(compressed)===file.sha256,'Working gzip differs from canonical restored bytes');
    const rawSize=regular(raw).size,digest=crypto.createHash('sha256');let total=0;
    await pipeline(fs.createReadStream(compressed),createGunzip(),new Writable({write(chunk,_enc,callback){total+=chunk.length;if(total>rawSize)return callback(Error('Gzip exceeds retained raw size'));digest.update(chunk);callback();}}));
    const result=digest.digest('hex');check(total===rawSize&&result===await sha256File(raw),'Gzip does not reproduce retained raw bytes');
    rawGzipPairs.push({rawPath:file.path.slice(0,-3),compressedPath:file.path,rawBytes:rawSize,rawSHA256:result,rawCurrentGitBlobRequired:false});
  }
  return {schema:1,sourceCommit:commit,sourceArchive:archive,sourceArchiveFormat:'git-bundle-v2-incremental-dependent',canonicalDirectory:'reviews/',
    canonicalBytes:'Exact current Git blobs from an independently restored baseline-plus-capsule pair; no source ZIP/export-filter audit is performed.',
    scope:'Every current committed canonical review blob is in the verified dependent source pair. Original working CI text, unrelated refs and untracked inputs remain at their retained origins.',
    compressedScope:'Every available working raw/JSON.gz pair is lossless checked; absent raw counterpart means compressed canonical bytes only, not an original raw value.',files,rawGzipPairs};
}
export async function verifySourceCapsule({sourceRoot,sourceCommit,baselineFile,baselinePin,capsuleFile,capsulePin,temporary}){
  sourceRoot=path.resolve(sourceRoot);baselineFile=path.resolve(baselineFile);capsuleFile=path.resolve(capsuleFile);temporary=path.resolve(temporary);
  const base=baselineDescriptor(baselinePin),plan=sourcePlan(sourceRoot,sourceCommit,base);
  capsuleDescriptor(capsulePin,base,plan,sourceCommit);await pinnedFile(baselineFile,base);await pinnedFile(capsuleFile,capsulePin);
  const fullHeader=readV2Header(baselineFile),deltaHeader=readV2Header(capsuleFile);
  check(same(fullHeader.advertised,refs(base.sourceCommit))&&fullHeader.prerequisites.length===0&&fullHeader.packObjects===plan.baseline.length,'Baseline is not an exact full source bundle');
  check(same(deltaHeader.advertised,refs(sourceCommit))&&same(deltaHeader.prerequisites,plan.prerequisites)&&deltaHeader.packObjects===plan.added.length,'Capsule refs/prerequisites/new object count differ');
  check(regular(baselineFile).size===base.bytes,'Baseline changed before import');
  check(fs.statSync(temporary).isDirectory()&&fs.readdirSync(temporary).length===0,'Fresh empty verification workspace required');
  const storageBudget=pairBudget(base.bytes,capsulePin.bytes,plan.baseline.length,plan.added.length);
  capacity(temporary,storageBudget.requiredTemporaryBytes,'temporary pair restore');
  const beforeRefs=git(sourceRoot,['show-ref']);
  const nonThinProof=await proveNonThinCapsule(capsuleFile,deltaHeader,temporary,plan);
  const baselineProof=await verifyBundle(sourceRoot,base.sourceCommit,baselineFile,temporary);
  const bare=path.join(temporary,'restored.git');const deltaVerify=git(bare,['bundle','verify',capsuleFile]);
  const unbundled=git(bare,['bundle','unbundle',capsuleFile]).trim().split('\n').map(line=>{const [commit,ref,...rest]=line.split(' ');check(!rest.length&&oid.test(commit),'Malformed unbundle refs');return {commit,ref};}).sort((a,b)=>a.ref.localeCompare(b.ref));
  check(same(unbundled,refs(sourceCommit)),'Unbundle target refs differ');git(bare,['update-ref',branch,sourceCommit]);git(bare,['symbolic-ref','HEAD',branch]);
  const importedPack=path.join(bare,'objects','pack',nonThinProof.packBasename);
  check(regular(importedPack).size===nonThinProof.packBytes&&await sha256File(importedPack)===nonThinProof.packSHA256,'Final capsule pack differs or expanded');
  const fsck=git(bare,['fsck','--full','--strict']);check(git(bare,['rev-parse','HEAD']).trim()===sourceCommit,'Restored target HEAD differs');
  check(same(closure(bare,sourceCommit),plan.target)&&same(objectList(bare),plan.target),'Restored pair object closure differs or contains extras');
  check(same(list(git(bare,['for-each-ref','--format=%(refname)'])),[branch]),'Unexpected restored refs');
  const identity=JSON.parse(execFileSync('python3',[fileURLToPath(new URL('./verify-bundle-tree.py',import.meta.url)),sourceRoot,bare,sourceCommit],{encoding:'utf8',maxBuffer:limit}));
  const index=await canonicalIndex(sourceRoot,bare,sourceCommit,identity,capsulePin.archive);
  await pinnedFile(baselineFile,base);await pinnedFile(capsuleFile,capsulePin);check(git(sourceRoot,['show-ref'])===beforeRefs,'Source refs changed');
  return {schema:1,format:'git-bundle-v2-incremental-dependent',standalone:false,fullBackup:false,baseline:base,capsule:capsulePin,
    baselineHeader:fullHeader,capsuleHeader:deltaHeader,nonThinProof,storageBudget,baselineVerification:baselineProof,targetReachableObjectCount:plan.target.length,
    addedReachableObjectCount:plan.added.length,sourceClosureSHA256:crypto.createHash('sha256').update(plan.target.join('\n')+'\n').digest('hex'),
    restore:'Fresh bare full baseline verify/unbundle/fsck/closure/blob proof, capsule verify/unbundle, fixed target refs, full fsck/closure/current tree/blob and canonical INDEX comparison.',
    actualDeltaVerifyOutput:deltaVerify,actualPairFsckOutput:fsck,identity,index,sourceRefsUnchanged:true,
    limitations:'One exact locally available full0.8 baseline is mandatory; neither capsule alone nor a remote asset is a locally available backup. Other refs/tags/untracked inputs and raw CI normalization are excluded. Temporary capacity and real-sized verification remain separate gates.'};
}
export async function createSourceCapsule({sourceRoot,sourceCommit,baselineFile,baselinePin,outputDirectory,temporaryParent=os.tmpdir()}){
  sourceRoot=path.resolve(sourceRoot);baselineFile=path.resolve(baselineFile);outputDirectory=path.resolve(outputDirectory);temporaryParent=path.resolve(temporaryParent);
  const base=baselineDescriptor(baselinePin),plan=sourcePlan(sourceRoot,sourceCommit,base);
  check(git(sourceRoot,['symbolic-ref','HEAD']).trim()===branch&&git(sourceRoot,['rev-parse','HEAD',branch]).trim().split('\n').every(id=>id===sourceCommit),'Exact source HEAD/production branch required');
  check(git(sourceRoot,['status','--porcelain']).trim()==='','Clean committed source required');
  const beforeRefs=git(sourceRoot,['show-ref']);
  await pinnedFile(baselineFile,base);const header=readV2Header(baselineFile);
  check(same(header.advertised,refs(base.sourceCommit))&&!header.prerequisites.length&&header.packObjects===plan.baseline.length,'Full baseline header differs');
  check(!fs.existsSync(outputDirectory),'Capsule output directory already exists; refuse overwrite');
  const estimate=2*plan.rawAddedBytes+plan.added.length*128+128*1024;
  capacity(path.dirname(outputDirectory),estimate+64*1024*1024,'durable capsule output');
  const storageBudget=pairBudget(base.bytes,estimate,plan.baseline.length,plan.added.length);
  capacity(temporaryParent,storageBudget.requiredTemporaryBytes,'temporary pair restore');
  if(fs.statSync(path.dirname(outputDirectory)).dev===fs.statSync(temporaryParent).dev)
    capacity(temporaryParent,storageBudget.requiredTemporaryBytes+estimate+64*1024*1024,'shared output/temporary filesystem');
  fs.mkdirSync(outputDirectory,{mode:0o700});let temporary=null;
  const archive=`${plan.pkg.name}-${plan.pkg.version}-source-capsule.bundle`,file=path.join(outputDirectory,archive);
  try{
    temporary=fs.mkdtempSync(path.join(temporaryParent,'hollowpact-source-capsule-'));
    await writeNonThinCapsule(sourceRoot,file,sourceCommit,base,plan);fs.chmodSync(file,0o600);
    check(regular(file).size<=estimate,'Created capsule exceeded conservative output estimate');
    const capsulePin={schema:1,format:'git-bundle-v2-incremental',standalone:false,fullBackup:false,version:plan.pkg.version,sourceCommit,archive,bytes:regular(file).size,
      sha256:await sha256File(file),baseline:base,gitPrerequisites:plan.prerequisites};
    const proof=await verifySourceCapsule({sourceRoot,sourceCommit,baselineFile,baselinePin:base,capsuleFile:file,capsulePin,temporary});
    check(git(sourceRoot,['show-ref'])===beforeRefs&&git(sourceRoot,['status','--porcelain']).trim()==='','Source refs or clean state changed during capsule production');
    immutableJSON(path.join(outputDirectory,'source-capsule-manifest.json'),capsulePin);
    immutableJSON(path.join(outputDirectory,'INDEX.json'),proof.index);
    immutableJSON(path.join(outputDirectory,'source-capsule-verification.json'),proof);
    const inventory=[];
    async function inspect(dir){for(const name of fs.readdirSync(dir).sort()){const p=path.join(dir,name),s=fs.lstatSync(p);check(!s.isSymbolicLink(),'Verification store has unexpected symlink');if(s.isDirectory())await inspect(p);else {check(s.isFile(),'Unexpected verification store node');inventory.push({path:path.relative(temporary,p),bytes:s.size,mode:s.mode&0o7777,sha256:await sha256File(p)});}}}
    await inspect(temporary);immutableJSON(path.join(outputDirectory,'derived-verification-store.json'),{schema:1,temporaryDirectory:temporary,files:inventory,
      scope:'Only this newly generated successful pair restoration is recoverable from the unchanged pinned baseline and capsule. Original inputs and old preflights remain untouched.',removalPlannedAfterSuccessfulProof:true});
    fs.rmSync(temporary,{recursive:true});check(!fs.existsSync(temporary),'Derived verification store removal incomplete');
    immutableJSON(path.join(outputDirectory,'CAPSULE-RESULT.json'),{schema:1,status:'verified-dependent-pair',standalone:false,fullBackup:false,
      sourceCommit,baselineSHA256:base.sha256,capsuleSHA256:capsulePin.sha256,temporaryDirectory:temporary,derivedStoreRemovedAfterSuccessfulProof:true});
    return {capsulePin,proof};
  }catch(error){
    // Never delete official partial output, old input or the failed restoration.
    try{immutableJSON(path.join(outputDirectory,'FAILURE.json'),{schema:1,status:'failed',message:String(error.message),temporaryDirectory:temporary,
      officialPartialOutputRetained:true,failedVerificationStoreRetained:temporary!==null&&fs.existsSync(temporary),standalone:false,baseline:base});}catch{}
    throw error;
  }
}
