import fs from 'node:fs';
import {createSourceCapsule,verifySourceCapsule} from './source-capsule.mjs';
const [command,...args]=process.argv.slice(2);
const usage='Usage: create <source-repo> <exact-source-commit> <full0.8-baseline.bundle> <baseline-pin.json> <new-exclusive-output-dir> <tmp-parent> OR verify <source-repo> <exact-source-commit> <full0.8-baseline.bundle> <baseline-pin.json> <capsule.bundle> <capsule-manifest.json> <fresh-empty-tmp-dir>. Capsule requires its exact retained full baseline; never a standalone/full backup.';
function readPin(file){const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink()||s.size>65536)throw Error('Pin must be a bounded regular local JSON file');return JSON.parse(fs.readFileSync(file,'utf8'));}
try{
  if(command==='create'&&args.length===6){
    const [sourceRoot,sourceCommit,baselineFile,baselineJSON,outputDirectory,temporaryParent]=args;
    const result=await createSourceCapsule({sourceRoot,sourceCommit,baselineFile,baselinePin:readPin(baselineJSON),outputDirectory,temporaryParent});
    process.stdout.write(JSON.stringify({status:'verified-dependent-pair',standalone:false,fullBackup:false,sourceCommit,
      baselineSHA256:result.capsulePin.baseline.sha256,capsuleSHA256:result.capsulePin.sha256,capsuleBytes:result.capsulePin.bytes,outputDirectory})+'\n');
  }else if(command==='verify'&&args.length===7){
    const [sourceRoot,sourceCommit,baselineFile,baselineJSON,capsuleFile,capsuleJSON,temporary]=args;
    const result=await verifySourceCapsule({sourceRoot,sourceCommit,baselineFile,baselinePin:readPin(baselineJSON),capsuleFile,capsulePin:readPin(capsuleJSON),temporary});
    process.stdout.write(JSON.stringify({status:'verified-dependent-pair',standalone:false,fullBackup:false,sourceCommit,
      baselineSHA256:result.baseline.sha256,capsuleSHA256:result.capsule.sha256,restoredObjectCount:result.targetReachableObjectCount,
      canonicalReviewFiles:result.index.files.length,verificationStoreRetained:temporary})+'\n');
  }else throw Error(usage);
}catch(error){process.stderr.write(String(error.message)+'\n');process.exitCode=1;}
