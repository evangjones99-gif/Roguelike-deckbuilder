from pathlib import Path
import json,hashlib,urllib.request,sys
A=Path('/workspace/scratch/relic-discovery-author-v09-r2');O=Path('/workspace/scratch/relic-discovery-independent-v09-r2');H=lambda b:hashlib.sha256(b).hexdigest()
assert H((A/'FROZEN-FILES.json').read_bytes())=='b3642e2bf291316845c35c2b6c3ee95264e162afcc4ef74dafa544faf4694f34'
for p,r in json.loads((A/'FROZEN-FILES.json').read_text())['files'].items():
 b=(A/p).read_bytes();assert H(b)==r['sha256'] and len(b)==r['bytes'],p
d=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());rows=[]
for label,stage,port in [('baseline',Path('/tmp/hollowpact-relic-discovery-v09-root-r1'),4597),('candidate',Path(d['stage']),4601)]:
 declared=d[label];actual=json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/build-provenance.json'));assert actual==declared
 for p,h in declared['hashes'].items():assert H((stage/p).read_bytes())==h,p
 assert len(declared['hashes'])==77 and H(json.dumps(declared['hashes'],separators=(',',':')).encode())==declared['sourceDigest']
 outputs={}
 for p in sorted((stage/'dist').rglob('*')):
  if p.is_file():
   name=p.relative_to(stage/'dist').as_posix();b=p.read_bytes();web=urllib.request.urlopen(f'http://127.0.0.1:{port}/{name}').read();assert b==web,name;outputs[name]={'bytes':len(b),'sha256':H(b)}
 assert len(outputs)==55
 if label=='candidate':assert outputs==d['outputs']
 rows.append({'label':label,'stage':str(stage),'port':port,'provenance':actual,'outputs':outputs})
assert [p for p,h in d['baseline']['hashes'].items() if d['candidate']['hashes'][p]!=h]==['src/main.ts']
(O/(sys.argv[1]+'-identity.json')).write_text(json.dumps({'authorFilesVerified':len(json.loads((A/'FROZEN-FILES.json').read_text())['files']),'sourceBodiesPerBuild':77,'HTTPBodiesPerBuild':55,'onlySourceDelta':'src/main.ts','rows':rows},indent=2)+'\n')
print('Verified both77-input/55-output builds and26 frozen author files: '+sys.argv[1])
