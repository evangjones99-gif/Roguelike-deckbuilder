from pathlib import Path
import hashlib,json,difflib,sys
A=Path('/workspace/scratch/installer-v08-current-author-r2')
P=Path('/workspace/scratch/installer-v08-current-author-r1')
R=Path('/workspace/Roguelike-deckbuilder')
O=Path('/workspace/scratch/installer-v08-current-independent-source-r2')
H=lambda b:hashlib.sha256(b).hexdigest()
assert H((A/'MANIFEST.json').read_bytes())=='6ee30a2627d296456ebec283e25226e4cec479ad0ced3931b9c3c7aa62d7a136'
author=[]
for r in json.loads((A/'MANIFEST.json').read_text())['files']:
 b=(A/r['path']).read_bytes();assert len(b)==r['bytes'] and H(b)==r['sha256'],r['path'];author.append(r)
assert len(author)==36
root=json.loads((Path('/workspace/scratch/installer-v08-current-independent-source-r1')/'postflight.json').read_text())['rootInputs']
for r in root:
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes'] and H(b)==r['sha256'],r['path']
assert len(root)==83
proposed=sorted(p.relative_to(A/'proposed').as_posix() for p in (A/'proposed').rglob('*') if p.is_file() and 'node_modules' not in p.parts)
assert len(proposed)==9
unchanged=[];changed=[];diff=[]
for p in proposed:
 old=(P/'proposed'/p).read_bytes();new=(A/'proposed'/p).read_bytes()
 (unchanged if old==new else changed).append(p)
 if old!=new:diff.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='R1/'+p,tofile='R2/'+p))
assert changed==['scripts/windows-installer-current-validation.mjs','scripts/windows-installer-current-validation.test.mjs']
for p in (A/'baseline').rglob('*'):
 if p.is_file():assert p.read_bytes()==(R/p.relative_to(A/'baseline')).read_bytes()
old=(A/'baseline/scripts/windows-installer-guards.mjs').read_text();new=(A/'proposed/scripts/windows-installer-guards.mjs').read_text()
assert old[old.index('export const hash'):]==new[new.index('export const hash'):]
old=(A/'baseline/scripts/windows-installer-smoke.mjs').read_text();new=(A/'proposed/scripts/windows-installer-smoke.mjs').read_text()
for start,end in [('async function native(operation,file)','const readSave='),('  const profileBefore=await snapshot(v.profile)',None)]:
 assert old[old.index(start):old.index(end) if end else None]==new[new.index(start):new.index(end) if end else None]
phase=sys.argv[1]
receipt={'phase':phase,'scope':'Read-only source/asset guard review. No activation or native installation.','authorManifestSHA256':H((A/'MANIFEST.json').read_bytes()),'authorFiles':author,'rootFiles':root,'proposalFiles':proposed,'unchangedFromR1':unchanged,'changedFromR1':changed,'guardFunctionBodiesNativeLaunchAndFullUninstallEqualHistoricalBaseline':True}
(O/(phase+'-audit.json')).write_text(json.dumps(receipt,indent=2)+'\n')
if phase=='before':(O/'R1-R2-independent-diff.patch').write_text(''.join(diff))
print(json.dumps({'phase':phase,'authorFiles':len(author),'rootFiles':len(root),'proposalFiles':len(proposed),'changed':changed}))
