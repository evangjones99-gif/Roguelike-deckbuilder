import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {assertCurrentRuntime,packagedAssetWitness,assertNativeDecodedSounds,decodeInstalledSounds} from '/workspace/scratch/installer-v08-current-author-r2/proposed/scripts/windows-installer-current-validation.mjs';
const ROOT='/workspace/Roguelike-deckbuilder',OUT='/workspace/scratch/installer-v08-current-independent-source-r2';
const require=createRequire(ROOT+'/package.json'),asar=require('@electron/asar'),H=b=>crypto.createHash('sha256').update(b).digest('hex');
const archive='/tmp/hollowpact-linux-v08-width-r1/linux-unpacked/resources/app.asar';
const runtime=JSON.parse(fs.readFileSync(ROOT+'/dist/build-provenance.json'));
const assets=packagedAssetWitness(runtime,p=>asar.extractFile(archive,p.join('/')));
const receipt=()=>({elapsedMs:25,records:assets.sounds.map(s=>({...s,url:'file:///C:/Owned/installation/resources/app.asar/dist/audio/'+s.name}))});
const findings={scope:'Own source-only refusal checks. Synthetic metadata is never a native success receipt; API sentinels test refusal order only.',elapsed:[],foreignReceiptAuthorities:[],renderer:[],localAliases:[]};
test('Own current provenance and complete actual59-leaf packaged payload boundary',()=>{
 assertCurrentRuntime(runtime);assert.equal(runtime.version,'0.8.0');assert.equal(Object.keys(runtime.hashes).length,76);
 assert.equal(H(fs.readFileSync(archive)),'c383c4437ac5467146174c6ea039b2a8b28af43d609701379e8cf695f59d530c');
 const expected=new Set(['package.json']),payload={};
 for(const base of ['dist','desktop']){const walk=dir=>{for(const e of fs.readdirSync(ROOT+'/'+dir,{withFileTypes:true})){
  const p=dir+'/'+e.name;if(e.isDirectory())walk(p);else{assert(e.isFile());expected.add(p);const data=asar.extractFile(archive,p);assert.equal(H(data),H(fs.readFileSync(ROOT+'/'+p)));payload[p]=H(data);}
 }};walk(base);}
 const leaves=asar.listPackage(archive).filter(p=>!asar.statFile(archive,p.replace(/^\//,'')).files).map(p=>p.replace(/^\//,''));
 assert.deepEqual(new Set(leaves),expected);assert.equal(leaves.length,59);for(const p of leaves)assert.equal(asar.statFile(archive,p).link,undefined);
 assert.equal(Object.keys(payload).length,58);
 const packed=JSON.parse(asar.extractFile(archive,'package.json')),source=JSON.parse(fs.readFileSync(ROOT+'/package.json'));
 assert.deepEqual(packed,Object.fromEntries(Object.entries(source).filter(([k])=>!['scripts','keywords','devDependencies','build'].includes(k))));
 fs.writeFileSync(OUT+'/package-readback.json',JSON.stringify({asarSHA256:H(fs.readFileSync(archive)),rawPayloads:payload,normalizedPackage:packed},null,2)+'\n');
});
test('Own elapsed metadata boundaries: finite0–100000 inclusive; impossible values refuse',()=>{
 for(const elapsedMs of [0,-0,Number.MIN_VALUE,1,99999.999,100000]){const r=receipt();r.elapsedMs=elapsedMs;assert.doesNotThrow(()=>assertNativeDecodedSounds(assets,r));}
 for(const elapsedMs of [-1,-Number.MIN_VALUE,-1e-10,100000.001,100001,NaN,Infinity,-Infinity,undefined,null,'0',new Number(3)]){
  const r=receipt();r.elapsedMs=elapsedMs;assert.throws(()=>assertNativeDecodedSounds(assets,r));findings.elapsed.push({value:String(elapsedMs),type:typeof elapsedMs,refused:true});
 }
});
const foreign=['remote-host','remote-host.example','127.0.0.1','[::1]','localhost.example','xn--bcher-kva.example'];
test('Own receipt authorities at first/middle/last cues refuse despite exact PCM and suffix',()=>{
 for(const authority of foreign)for(const index of [0,19,38]){
  const r=receipt();r.records[index].url=`file://${authority}/share/resources/app.asar/dist/audio/${r.records[index].name}`;
  assert.notEqual(new URL(r.records[index].url).hostname,'');assert.throws(()=>assertNativeDecodedSounds(assets,r));
  findings.foreignReceiptAuthorities.push({authority,index,refused:true});
 }
});
test('Own normalized localhost receipt aliases admit local URL semantics without claiming a decode',()=>{
 for(const authority of ['localhost','LOCALHOST']){
  const r=receipt();for(const row of r.records)row.url=`file://${authority}/C:/Owned/resources/app.asar/dist/audio/${row.name}`;
  assert.equal(new URL(r.records[0].url).hostname,'');assert.doesNotThrow(()=>assertNativeDecodedSounds(assets,r));findings.localAliases.push({boundary:'syntheticReceipt',authority,normalizedHostname:'',admitted:true});
 }
});
async function rendererProbe(href,sounds,expectedError){
 const counts={contexts:0,fetches:0};
 const sandbox={URL,location:{href},performance:{now:()=>1},OfflineAudioContext:class{constructor(){counts.contexts++;throw Error('CONTEXT_SENTINEL');}},fetch(){counts.fetches++;throw Error('FETCH_SENTINEL');}};
 const ctx=vm.createContext(sandbox),call=vm.runInContext('('+decodeInstalledSounds.toString()+')',ctx);
 await assert.rejects(()=>call(sounds),expectedError);return counts;
}
test('Own serialized renderer foreign base refuses before count, native constructor and fetch',async()=>{
 for(const authority of foreign)for(const length of [0,38,39,40]){
  const href=`file://${authority}/share/resources/app.asar/dist/index.html`,sounds=Array.from({length},(_,i)=>assets.sounds[i%39]);
  const counts=await rendererProbe(href,sounds,/Not an installed ASAR sound path/);assert.deepEqual(counts,{contexts:0,fetches:0});
  findings.renderer.push({href,length,...counts,refusedAt:'installedURLGate'});
 }
});
test('Own serialized renderer malformed origin/layout refusal and local alias/count order',async()=>{
 for(const href of ['https://remote/resources/app.asar/dist/index.html','file:///C:/Owned/dist/index.html','file:///C:/Owned/resources/app.asar/not-dist/index.html']){
  const counts=await rendererProbe(href,assets.sounds,/Not an installed ASAR sound path/);assert.deepEqual(counts,{contexts:0,fetches:0});findings.renderer.push({href,length:39,...counts,refusedAt:'installedURLGate'});
 }
 for(const authority of ['', 'localhost', 'LOCALHOST']){
  const href=`file://${authority}/C:/Owned/resources/app.asar/dist/index.html`;
  const malformed=await rendererProbe(href,assets.sounds.slice(1),/Wrong fixed decode count/);assert.deepEqual(malformed,{contexts:0,fetches:0});
  const admitted=await rendererProbe(href,assets.sounds,/CONTEXT_SENTINEL/);assert.deepEqual(admitted,{contexts:1,fetches:0});
  findings.localAliases.push({boundary:'serializedRenderer',authority,normalizedHostname:new URL(href).hostname,invalidCountRefused:malformed,validCountReachedOnlyConstructorSentinel:admitted});
 }
});
test('Own unchanged decode receipt exactness still refuses ordering/count/PCM/path tampering',()=>{
 for(const mutate of [r=>r.records.reverse(),r=>r.records.pop(),r=>{r.records[0].peak=Infinity;},r=>{r.records[19].frames++;},r=>{r.records[38].meanSquare+=1e-6;},r=>{r.records[0].url='file:///C:/other/'+r.records[0].name;}]){
  const r=receipt();mutate(r);assert.throws(()=>assertNativeDecodedSounds(assets,r));
 }
});
test('Freeze actual bounded witness and own refusal results with no native-success label',()=>{
 fs.writeFileSync(OUT+'/asset-witness.json',JSON.stringify({scope:'39 actual existing ASAR WAVs/current crypt, not native execution/hearing.',...assets},null,2)+'\n');
 fs.writeFileSync(OUT+'/refusal-results.json',JSON.stringify(findings,null,2)+'\n');
});
