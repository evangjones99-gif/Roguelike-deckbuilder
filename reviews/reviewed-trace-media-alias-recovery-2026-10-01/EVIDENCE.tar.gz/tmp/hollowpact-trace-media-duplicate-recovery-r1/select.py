import os,sys,json,hashlib,pathlib,resource,time
assert sys.flags.isolated and __debug__
BASE=pathlib.Path('/tmp/hollowpact-trace-media-duplicate-recovery-r1')
def rb(p):
 f=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:return os.pread(f,os.fstat(f).st_size,0)
 finally:os.close(f)
def digestfd(f):
 h=hashlib.sha256();off=0
 while True:
  b=os.pread(f,65536,off)
  if not b:break
  h.update(b);off+=len(b)
 return h.hexdigest()
def meta(f):
 a=os.fstat(f);return dict(dev=a.st_dev,ino=a.st_ino,mode=a.st_mode,uid=a.st_uid,gid=a.st_gid,nlink=a.st_nlink,bytes=a.st_size,blocks=a.st_blocks,atimeNs=a.st_atime_ns,mtimeNs=a.st_mtime_ns,ctimeNs=a.st_ctime_ns)
def free(p):
 v=os.statvfs(p);return v.f_bavail*v.f_frsize
def syncdir(p):
 f=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:os.fsync(f)
 finally:os.close(f)
assert int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())-int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())>=536870912+25165824
assert free(BASE)>1048576
pb=rb(BASE/'PLAN.json');plan=json.loads(pb);jb=rb(BASE/'JUDGMENT.json');judgment=json.loads(jb)
assert hashlib.sha256(pb).hexdigest()=='6699c2ce1aea8302f6de7ddcc7e160d835e2f09cc35073158a47fd92f5dac7be'
assert judgment['approved'] is True and judgment['knownActorsHeld'] is True and judgment['sourceSHA256']==hashlib.sha256(rb(BASE/'select.py')).hexdigest()
review=rb(pathlib.Path(judgment['independentReviewPath']));assert hashlib.sha256(review).hexdigest()==judgment['independentReviewSHA256']
assert len(plan['rows'])==8 and judgment['ownerAllowsReviewedRetirement'] is True
out=BASE/('run-'+str(time.time_ns()));out.mkdir(mode=0o700)
jf=os.open(out/'JOURNAL.json',os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);os.posix_fallocate(jf,0,32768)
state={'status':'PREPARED','planSHA256':hashlib.sha256(pb).hexdigest(),'judgmentSHA256':hashlib.sha256(jb).hexdigest(),'rows':[],'availableBefore':free('/workspace')}
def journal():
 b=(json.dumps(state,indent=2)+'\n').encode();assert len(b)<=32768;b=b.ljust(32768,b' ');pos=0
 while pos<len(b):
  n=os.pwrite(jf,b[pos:],pos);assert n>0;pos+=n
 os.fsync(jf)
journal();syncdir(out);syncdir(BASE)
held=[]
try:
 for i,r in enumerate(plan['rows']):
  old=pathlib.Path(r['duplicate']);src=pathlib.Path(r['retainedCanonical'])
  assert old.parent==pathlib.Path('/workspace/scratch/standard-sol-owner-ux-technical-independent-r1/runtime-results/.playwright-artifacts-0/traces/resources')
  assert src.parent==pathlib.Path('/workspace/Roguelike-deckbuilder/public/art') and old.suffix==src.suffix=='.png'
  of=os.open(old,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);sf=os.open(src,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);held=[of,sf]
  assert meta(of)==r['duplicateBefore'] and meta(sf)==r['canonicalBefore']
  assert digestfd(of)==digestfd(sf)==r['sha256']
  assert os.stat(old,follow_symlinks=False).st_ino==os.fstat(of).st_ino and os.stat(src,follow_symlinks=False).st_ino==os.fstat(sf).st_ino
  entry={'duplicate':str(old),'canonical':str(src),'status':'LINK/REPLACE UNKNOWN'};state['rows'].append(entry);journal()
  temp=old.parent/('.reviewed-link-'+str(os.getpid())+'-'+str(i));assert not temp.exists()
  os.link(src,temp,follow_symlinks=False)
  assert os.stat(temp,follow_symlinks=False).st_ino==os.fstat(sf).st_ino
  assert os.stat(old,follow_symlinks=False).st_ino==os.fstat(of).st_ino
  os.replace(temp,old);syncdir(old.parent)
  assert os.stat(old,follow_symlinks=False).st_ino==os.fstat(sf).st_ino and os.fstat(of).st_nlink==0
  os.close(of);held=[sf];entry['status']='REPLACED: identical readable path';entry['canonicalAfter']=meta(sf);journal();os.close(sf);held=[]
 state['status']='PASS: eight identical trace PNG hardlinks; no unique body removed';state['availableAfter']=free('/workspace');state['observedAvailableDelta']=state['availableAfter']-state['availableBefore'];journal()
 assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=25165824
 print(json.dumps({'output':str(out),'status':state['status'],'availableAfter':state['availableAfter']}))
except BaseException as e:
 state['status']='FAILED: inspect individual recorded paths';state['error']=str(e)
 try:journal()
 except BaseException:pass
 raise
finally:
 for f in held:os.close(f)
 os.close(jf)
