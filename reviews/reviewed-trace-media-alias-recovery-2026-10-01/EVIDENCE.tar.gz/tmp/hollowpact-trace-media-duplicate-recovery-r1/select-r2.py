import os,sys,json,hashlib,pathlib,resource,time,stat
assert sys.flags.isolated and __debug__
BASE=pathlib.Path('/tmp/hollowpact-trace-media-duplicate-recovery-r1');held=[]
def ident(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)
def meta(f):
 a=os.fstat(f);assert stat.S_ISREG(a.st_mode)
 return dict(dev=a.st_dev,ino=a.st_ino,mode=a.st_mode,uid=a.st_uid,gid=a.st_gid,nlink=a.st_nlink,bytes=a.st_size,blocks=a.st_blocks,atimeNs=a.st_atime_ns,mtimeNs=a.st_mtime_ns,ctimeNs=a.st_ctime_ns)
def attrs(f):return {n:os.getxattr(f,n).hex() for n in os.listxattr(f)}
def chaincheck(r):
 assert ident(os.stat('/',follow_symlinks=False))==r['chain'][0][3]
 for fd,parent,name,pin in r['chain'][1:]:assert ident(os.fstat(fd))==pin and ident(os.stat(name,dir_fd=parent,follow_symlinks=False))==pin
 return r['chain'][-1][0]
def check(r,pin=None):
 parent=chaincheck(r);assert meta(r['fd'])==(r['pin'] if pin is None else pin) and attrs(r['fd'])==r['attrs']
 a=os.fstat(r['fd']);b=os.stat(r['path'].name,dir_fd=parent,follow_symlinks=False);assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino)
 return parent

def anchor(p):
 p=pathlib.Path(p);assert p.is_absolute() and '..' not in p.parts
 chain=[];fd=None
 try:
  root=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW);chain.append((root,None,'/',ident(os.fstat(root))))
  for name in p.parts[1:-1]:
   parent=chain[-1][0];child=os.open(name,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent);chain.append((child,parent,name,ident(os.fstat(child))))
  fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=chain[-1][0]);r=dict(path=p,fd=fd,chain=chain,pin=meta(fd),attrs=attrs(fd));check(r);held.append(r);return r
 except BaseException:
  if fd is not None:os.close(fd)
  for child,*_ in reversed(chain):os.close(child)
  raise
def rb(p,cap=131072):
 r=anchor(p);b=os.pread(r['fd'],cap+1,0);assert len(b)<=cap;check(r);return b
def digestfd(f):
 h=hashlib.sha256();off=0
 while True:
  b=os.pread(f,65536,off)
  if not b:break
  h.update(b);off+=len(b)
 return h.hexdigest()
def free(p):
 v=os.statvfs(p);return v.f_bavail*v.f_frsize
def syncparent(parent):
 f=os.open('.',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
 try:os.fsync(f)
 finally:os.close(f)
assert int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())-int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())>=536870912+25165824
assert free(BASE)>1048576
pb=rb(BASE/'PLAN.json');plan=json.loads(pb);jb=rb(BASE/'JUDGMENT-r2.json');judgment=json.loads(jb)
assert hashlib.sha256(pb).hexdigest()=='6699c2ce1aea8302f6de7ddcc7e160d835e2f09cc35073158a47fd92f5dac7be'
assert judgment['approved'] is True and judgment['knownActorsHeld'] is True and judgment['sourceSHA256']==hashlib.sha256(rb(BASE/'select-r2.py')).hexdigest()
review=rb(pathlib.Path(judgment['independentReviewPath']));assert hashlib.sha256(review).hexdigest()==judgment['independentReviewSHA256']
assert len(plan['rows'])==8 and judgment['ownerAllowsReviewedRetirement'] is True
out=BASE/('run-'+str(time.time_ns()));out.mkdir(mode=0o700)
jf=os.open(out/'JOURNAL.json',os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);os.posix_fallocate(jf,0,32768)
state={'status':'PREPARED','planSHA256':hashlib.sha256(pb).hexdigest(),'judgmentSHA256':hashlib.sha256(jb).hexdigest(),'rows':[],'availableBefore':free('/workspace')}
def journal():
 b=(json.dumps(state,indent=2)+'\n').encode();assert len(b)<=32768;b=b.ljust(32768,b' ');pos=0
 while pos<len(b):
  n=os.pwrite(jf,b[pos:],pos);assert n>0;pos+=n
 os.fsync(jf)
journal()
for p in [out,BASE]:
 f=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:os.fsync(f)
 finally:os.close(f)
try:
 for i,r in enumerate(plan['rows']):
  old=pathlib.Path(r['duplicate']);src=pathlib.Path(r['retainedCanonical'])
  assert old.parent==pathlib.Path('/workspace/scratch/standard-sol-owner-ux-technical-independent-r1/runtime-results/.playwright-artifacts-0/traces/resources')
  assert src.parent==pathlib.Path('/workspace/Roguelike-deckbuilder/public/art') and old.suffix==src.suffix=='.png'
  oldr=anchor(old);srcr=anchor(src)
  assert oldr['pin']==r['duplicateBefore'] and srcr['pin']==r['canonicalBefore'] and oldr['attrs']==srcr['attrs']=={}
  assert digestfd(oldr['fd'])==digestfd(srcr['fd'])==r['sha256']
  oldparent=check(oldr);srcparent=check(srcr)
  tempname='.reviewed-link-'+str(os.getpid())+'-'+str(i)
  try:os.stat(tempname,dir_fd=oldparent,follow_symlinks=False)
  except FileNotFoundError:pass
  else:raise RuntimeError('Temporary link exists')
  entry={'duplicate':str(old),'canonical':str(src),'temporaryLeaf':tempname,'status':'LINK/REPLACE UNKNOWN'};state['rows'].append(entry);journal()
  check(oldr);check(srcr)
  os.link(src.name,tempname,src_dir_fd=srcparent,dst_dir_fd=oldparent,follow_symlinks=False)
  t=os.stat(tempname,dir_fd=oldparent,follow_symlinks=False);a=os.fstat(srcr['fd']);assert ident(t)==ident(a)
  newpin=meta(srcr['fd']);assert newpin['nlink']==srcr['pin']['nlink']+1
  assert {k:v for k,v in newpin.items() if k not in ('nlink','ctimeNs')}=={k:v for k,v in srcr['pin'].items() if k not in ('nlink','ctimeNs')}
  check(oldr);check(srcr,newpin)
  os.replace(tempname,old.name,src_dir_fd=oldparent,dst_dir_fd=oldparent);syncparent(oldparent)
  b=os.stat(old.name,dir_fd=oldparent,follow_symlinks=False);a=os.fstat(srcr['fd']);assert ident(a)==ident(b) and os.fstat(oldr['fd']).st_nlink==0
  os.close(oldr['fd']);oldr['fd']=None;entry['status']='REPLACED: identical readable path';entry['canonicalAfter']=meta(srcr['fd']);journal()
 state['status']='PASS: eight identical trace PNG hardlinks; no unique body removed';state['availableAfter']=free('/workspace');state['observedAvailableDelta']=state['availableAfter']-state['availableBefore'];journal()
 assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=25165824
 print(json.dumps({'output':str(out),'status':state['status'],'availableAfter':state['availableAfter']}))
except BaseException as e:
 state['status']='FAILED: inspect individual recorded paths';state['error']=str(e)
 try:journal()
 except BaseException:pass
 raise
finally:
 for r in reversed(held):
  if r['fd'] is not None:os.close(r['fd'])
  for child,*_ in reversed(r['chain']):os.close(child)
 os.close(jf)
