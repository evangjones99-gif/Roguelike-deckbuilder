# Independent exact trace-media duplicate preference

PREFER the eight verified retained canonical PNGs as backing for the eight precisely identified generated trace-resource duplicates in PLAN.json, conditionally on ROOT preserving immutability and the genuine known-actor hold through exact atomic alias replacement and inspection. Direct full-byte comparison found no unique content in any of these eight duplicate allocations. No hardlink/replacement/removal was executed by this reviewer. This is not permission for other files or original research to be removed.

The exact plan is /tmp/hollowpact-trace-media-duplicate-recovery-r1/PLAN.json,8888B,SHA2566699c2ce1aea8302f6de7ddcc7e160d835e2f09cc35073158a47fd92f5dac7be. Independent COMPARISON.json13198B,SHA25615d1d36bade00f20890f3c65e5a8385c89c50d239ffccd6cf4b2cbe51ec4394f preserves every full duplicate/canonical path, plan before metadata, independently computed whole hashes, resource samples and successful direct equality.

## Independently executed comparison

Every duplicate and canonical was opened through a held parent chain using O_PATH/O_DIRECTORY/O_NOFOLLOW for directories and O_RDONLY/O_NOFOLLOW/O_NOATIME/O_NONBLOCK for regular leaves. The current full stat fields in the plan matched exactly before reading and still matched after; parent/leaf correspondence and xattrs were rechecked. Every original duplicate is owned0600,nlink1; every retained canonical is owned0600,nlink2; all pairs have equal UID/GID/mode/size and device27 with distinct inodes and empty xattrs. Both streams were compared directly in64KiB chunks through exact EOF, independently SHA256-hashed and matched to the plan. No body was accepted merely by matching an existing report or file size.

Trace resource directory: /workspace/scratch/standard-sol-owner-ux-technical-independent-r1/runtime-results/.playwright-artifacts-0/traces/resources. Canonical directory: /workspace/Roguelike-deckbuilder/public/art. Full absolute paths are preserved in the pinned plan and independent comparison.

| Trace PNG basename | Retained canonical basename | Bytes | SHA256 |
| --- | --- | ---: | --- |
| 179c4ec7c040490768fe69b7b76cfd60a82e2ce9.png | abbey-courtyard.png | 3060309 | 92230fee18818b49a813a50085ecb604b93f157173b994ffe53c520b726e99b3 |
| 53a781f80df85efdbe75e9191cf803f7b8b65acb.png | hound-poses.png | 1702748 | 0f363fb1a22fc6e8ce730eabcc19af7ce61a1c7fdc71d8e52860b0114efe4968 |
| 627ee2d287edc7a897891b7b4091dabd585afc7e.png | hunter-marek-v07-r3.png | 2128117 | 4492577d3bacc868e9b66da0abf25915bdeaf68bc8f5c31ae8a1d8db485f3c53 |
| c4f152d4b8daf87cd2343fa372cef5e077800675.png | companions-atlas.png | 2013487 | 1a59f11b0d3829921beeea823b6b148b9308f94d29cb4956c43d2bf9798290c5 |
| c53c3a9a6cfb3a34eef76c56d7a565bf173c8588.png | adversaries-atlas.png | 1924995 | 5d0ad1963acce4a93e6456d73a840f34d104e2d5b33c82fb491cfcb873801ea5 |
| d7bc876c507d52e7abe6e2de8903e2c102a57720.png | hunter-portrait.png | 2514707 | 28d4bdc56c434590ade5c9d69d650c35e284713fb14f45f37bad54190ea4e988 |
| dafb43a9e10e1b2c9abd4f9ffcccc86289d3367e.png | tool-vignettes.png | 2917100 | 0f5ee14a3f868b9480aaad480d949337cf38ad8e2f258e58857e7cd18f93d0f4 |
| de86018b474b30acea09e41557fe6ab4d48b80c8.png | warleader-poses.png | 2215085 | 3f8c88d72c4efafbba75e7dfa61ba10f04ec4fa11384008e2381edfbce02353b |

Total logical duplicate content18,476,548B; prospective removal of separate allocations18,493,440B. This is potential reclaim, not guaranteed or independently attributed free-space gain. All reviewer-owned read FDs closed after comparison.

## Alias risks, scope and conditions

The useful unique PNG inputs remain at canonical paths; generated trace resource paths and every raw PNG byte remain present after the proposed hardlink replacement. ROOT states these canonical generated PNGs already share backing with ROOT's generated dist and are immutable; the candidate2f1 private public files are unaffected. This review relies on that current producer immutability/actor-hold declaration. Byte equality alone does not prevent future writes.

Hardlinks share future in-place writes, truncation, chmod and xattr changes. Such operations through any canonical/dist/trace alias must remain prohibited. Future changed artwork must use new immutable files or atomic path replacement with new inodes, preserving these trace bytes. Removing or atomically replacing a canonical name does not erase its remaining hardlinked trace name; modifying the shared inode would corrupt historical fidelity. If ROOT cannot maintain that constraint, reject this alias plan and preserve independent copies.

Trace inode identity, nlink and ctime change intentionally; canonical nlink/ctime change intentionally. Trace atime/mtime adopt canonical inode times and old trace times are preserved in plan/COMPARISON instead. ROOT must record those intentional metadata changes, rather than claim all metadata remains unchanged. Current mode/UID/GID and empty xattrs match and must remain so. This does not rewrite the trace/network event records or imply their timestamps changed. No standalone trace archive portability or durable archive roundtrip is claimed: the performed evidence is exact pairwise raw PNG comparison, and every actual resource path must remain readable.

Before each exact atomic replacement, ROOT must recheck the pinned current duplicate and canonical identities/hashes, preserve the plan/review/decision journal, hold known art/trace users and writers, and use anchored no-follow paths with no broad wildcard/recursive operation. Preserve all other captures, unique source/art/research/data, reviews, historical manifests and trace/network files. Replacement and directory persistence must be inspected per row; interrupted partial completion must be recorded honestly and not hidden by an overall success claim. Independently verify all eight resulting trace paths retain these hashes and share the intended canonical inode, canonical bytes/modes/ownership/xattrs are preserved, protected siblings are unchanged, and measured free space after owned FDs close meets the unmodified retirement guard before considering source-ZIP execution.

No action is taken by this preference itself. ROOT supplies its concrete wise decision and executes only the exact reviewed plan, if all actual conditions hold. No approval of source-ZIP retirement is added by the duplicate PNG comparison; r3's distinct conditional source gate and its actual judgment/hold/admission/postreview still govern that separate action.

## Resource and evidence limits

Independent helper used64KiB reads and direct paired comparisons, no entire PNG materialization. Recorded peak RSS10,485,760B, below24MiB; initial cgroup headroom1,393,631,232B and final1,393,307,648B, each above24MiB plus512MiB reserve. These are observed samples, not certified global minimum headroom. Plan/stat/xattr drift would have refused. Source ZIP/archive/Git object bodies were not read; no browser, Node, Git, hints, source mutation, hardlink/replacement or deletion occurred. No decode/visual quality review or game/native/platform/Steam/human-fun approval is claimed.
