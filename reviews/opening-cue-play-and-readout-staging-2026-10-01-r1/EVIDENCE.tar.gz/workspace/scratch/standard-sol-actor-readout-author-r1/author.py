from pathlib import Path
import json, hashlib, difflib, os, time, resource
root=Path('/workspace/scratch/standard-sol-actor-readout-author-r1')
base=Path('/workspace/scratch/first-five-opening-hand-cue-stage-r1')
freeze=Path('/workspace/scratch/first-five-opening-hand-cue-runtime-freeze-root-r1.json')
work=24*1024*1024; reserve=512*1024*1024
limit=int(Path('/sys/fs/cgroup/memory.max').read_text()); initial=int(Path('/sys/fs/cgroup/memory.current').read_text())
rows=[]
def guard(label):
    current=int(Path('/sys/fs/cgroup/memory.current').read_text())
    rss=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmHWM:')))*1024
    row=dict(label=label,current=current,delta=max(0,current-initial),headroom=limit-current,processMaxRSS=rss)
    rows.append(row)
    assert row['headroom']>=reserve and row['delta']<=work and rss<=work,row

def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOATIME)
    with os.fdopen(fd,'rb') as f:return f.read()
def sha(b):return hashlib.sha256(b).hexdigest()

guard('admission')
record=json.loads(read(freeze)); assert record['sourceDigest']=='f2c79a0489325c1afacfbd7e7237394b183eefd4001a6d9a29fff08dae49bcfa'
names=['src/battlefield-layout.ts','src/arena.ts','src/main.ts','src/compact-readout.css']
original={name:read(base/name) for name in names}
for name,data in original.items():assert sha(data)==record['inputs'][name],name
out={name:data.decode() for name,data in original.items()}
def replace(name,old,new):
    assert out[name].count(old)==1,(name,old,out[name].count(old))
    out[name]=out[name].replace(old,new)
layout='src/battlefield-layout.ts'
replace(layout,'intentRows: number; statsRows: number }','intentRows: number; statsRows: number; identityRows?: number }')
replace(layout,'intentRows?: number; statsRows?: number }','intentRows?: number; statsRows?: number; identityRows?: number }')
replace(layout,'intentRows: Math.max(3, rows(config.intentRows)), statsRows: rows(config.statsRows) };','intentRows: Math.max(3, rows(config.intentRows)), statsRows: rows(config.statsRows), identityRows: rows(config.identityRows ?? 1) };')
replace(layout,'a.intentRows === b.intentRows && a.statsRows === b.statsRows;','a.intentRows === b.intentRows && a.statsRows === b.statsRows && (a.identityRows ?? 1) === (b.identityRows ?? 1);')
replace(layout,'const extraStats = (config.statsRows - 1) * 16;','const identityHeight = (config.identityRows ?? 1) * 16;\n  const extraReadout = (config.statsRows - 1) * 16 + identityHeight - 16;')
replace(layout,'budget.canvasHeight + extraStats *','budget.canvasHeight + extraReadout *')
replace(layout,'const inspectHeight = 16 + config.statsRows * 16;','const inspectHeight = identityHeight + config.statsRows * 16;')
replace(layout,'const inspectTop = bodyTop + bodyHeight;','const inspectTop = bodyTop + bodyHeight;\n      // Preserve the allocated body/paint/hit cell. Only attached readouts tighten.\n      const readoutWidth = Math.min(240, cellWidth);\n      const readoutLeft = centerX - readoutWidth / 2;')
for field,oldtop,height in [('intentRect','cellTop',"side === 'enemy' ? intentHeight : 0"),('inspectRect','inspectTop','inspectHeight'),('identityRect','inspectTop','16'),('statsRect','inspectTop + 16','config.statsRows * 16'),('statusRect','inspectTop + inspectHeight',"side === 'ally' ? 16 : 0")]:
    replace(layout,f'{field}: {{ left, top: {oldtop}, width: cellWidth, height: {height} }}',f'{field}: {{ left: readoutLeft, top: {"inspectTop + identityHeight" if field=="statsRect" else oldtop}, width: readoutWidth, height: {"identityHeight" if field=="identityRect" else height} }}')
arena='src/arena.ts'
replace(arena,'intentRows, statsRows: measuredRows.statsRows ?? 1 }), slots };','intentRows, statsRows: measuredRows.statsRows ?? 1, identityRows: measuredRows.identityRows ?? 1 }), slots };')
replace(arena,'const statsRows = metrics.statsRows ?? measuredRows.statsRows;\n    if (intentRows === measuredRows.intentRows && statsRows === measuredRows.statsRows) return;\n    measuredRows = { intentRows, statsRows };','const statsRows = metrics.statsRows ?? measuredRows.statsRows;\n    const identityRows = metrics.identityRows ?? measuredRows.identityRows;\n    if (intentRows === measuredRows.intentRows && statsRows === measuredRows.statsRows && identityRows === measuredRows.identityRows) return;\n    measuredRows = { intentRows, statsRows, identityRows };')
replace(arena,'intentRows: Math.max(layoutConfig.intentRows, desired.config.intentRows), statsRows: Math.max(layoutConfig.statsRows, desired.config.statsRows) });','intentRows: Math.max(layoutConfig.intentRows, desired.config.intentRows), statsRows: Math.max(layoutConfig.statsRows, desired.config.statsRows),\n      identityRows: Math.max(layoutConfig.identityRows ?? 1, desired.config.identityRows ?? 1) });')
main='src/main.ts'
replace(main,"function fieldActor(side: 'allies' | 'enemies', unit: Readonly<Unit>, index: number | null): string {", "function fieldIdentity(unit: Readonly<Unit>, enemy: boolean, index: number | null): string {\n  const position = index === null ? enemy ? 'Hostile down' : 'Binding lost' : `${enemy ? 'Hostile' : 'Binding'} ${index + 1}`;\n  return `${unit.name} · ${position} ⓘ`;\n}\nfunction fieldActor(side: 'allies' | 'enemies', unit: Readonly<Unit>, index: number | null): string {")
replace(main,'<span class="field-identity">${escape(identity)} <span aria-hidden="true">ⓘ</span></span>','<span class="field-identity"><span class="field-nameplate">${escape(fieldIdentity(unit, enemy, index))}</span></span>')
replace(main,'let intentRows = 3, statsRows = 1;','let intentRows = 3, statsRows = 1, identityRows = 1;')
replace(main,"for (const actor of overlay.querySelectorAll<HTMLElement>('[data-actor]')) {\n      const intent", "for (const actor of overlay.querySelectorAll<HTMLElement>('[data-actor]')) {\n      if (actor.hidden) continue;\n      const identity = actor.querySelector<HTMLElement>('.field-nameplate');\n      if (identity) identityRows = Math.max(identityRows, Math.ceil(identity.getBoundingClientRect().height / 16));\n      const intent")
replace(main,'arena.setReadoutMetrics({ intentRows, statsRows });','arena.setReadoutMetrics({ intentRows, statsRows, identityRows });')
replace(main,"const identity = actor.querySelector<HTMLElement>('.field-identity');\n    if (identity && region.canonicalIndex === null && !settlingCombat) identity.textContent = `${region.side === 'enemy' ? 'Hostile down' : 'Binding lost'} ⓘ`;\n  }\n}", "// Reserve the published identity height while measuring only the natural inner text.\n    actor.style.setProperty('--identity-height', `${region.identityRect.height}px`);\n    const identity = actor.querySelector<HTMLElement>('.field-nameplate');\n    if (identity) {\n      const label = fieldIdentity(region.readoutUnit, region.side === 'enemy', region.canonicalIndex);\n      if (identity.textContent !== label) identity.textContent = label;\n    }\n  }\n  // Paint movement alone does not change text flow. Raw readout widths, content,\n  // visibility and newborn/departure publication do; remeasure after positioning.\n  const signature = JSON.stringify([viewport.width, ...regions.map(region => {\n    const actor = Array.from(overlay.querySelectorAll<HTMLElement>('[data-actor]')).find(value => value.dataset.actor === region.uid);\n    return [region.uid, region.intentRect.width, region.inspectRect.width, actor?.textContent];\n  })]);\n  if (overlay.dataset.readoutMeasureSignature !== signature) {\n    overlay.dataset.readoutMeasureSignature = signature;\n    measureFieldReadouts();\n  }\n}")
css='src/compact-readout.css'
out[css]+='''\n/* Actor-attached readouts: widths come from published renderer rectangles.\n   The natural inner name remains measurable when allocation reserves more rows. */\n.compact-field .field-identity{min-height:var(--identity-height,16px);white-space:normal}\n.compact-field .field-nameplate{display:block;font:12px/16px Arial,sans-serif;overflow-wrap:anywhere}\n'''
guard('proposal-ready')
for name in names:
    for folder,data in [('baseline',original[name]),('candidate',out[name].encode())]:
        p=root/folder/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data)
    assert read(base/name)==original[name]
diff=''.join(''.join(difflib.unified_diff(original[name].decode().splitlines(True),out[name].splitlines(True),fromfile='a/'+name,tofile='b/'+name)) for name in names)
(root/'CHANGE.diff').write_text(diff)
(root/'SOURCE-PINS.json').write_text(json.dumps(dict(base=str(base),sourceDigest=record['sourceDigest'],freezeSha256=sha(read(freeze)),files={name:dict(baseline=sha(original[name]),candidate=sha(out[name].encode())) for name in names}),indent=2)+'\n')
guard('final')
(root/'RESOURCE.json').write_text(json.dumps(dict(workBytes=work,reserveBytes=reserve,scope='Source authoring only; no Node/browser/server/build/cleanup',samples=rows),indent=2)+'\n')
print(json.dumps(dict(files=names,diffBytes=len(diff.encode()),resource=rows[-1])))
