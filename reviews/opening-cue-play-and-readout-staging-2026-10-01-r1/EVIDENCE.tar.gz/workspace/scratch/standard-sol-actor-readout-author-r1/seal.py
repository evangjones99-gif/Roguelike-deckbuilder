from pathlib import Path
import os,json,hashlib,difflib
root=Path('/workspace/scratch/standard-sol-actor-readout-author-r1')
work=24*1024*1024;reserve=512*1024*1024
limit=int(Path('/sys/fs/cgroup/memory.max').read_text());initial=int(Path('/sys/fs/cgroup/memory.current').read_text());samples=[]
def guard(label):
    current=int(Path('/sys/fs/cgroup/memory.current').read_text())
    rss=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmHWM:')))*1024
    row=dict(label=label,current=current,delta=max(0,current-initial),headroom=limit-current,processVmHWM=rss);samples.append(row)
    assert row['headroom']>=reserve and row['delta']<=work and rss<=work,row

def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOATIME)
    with os.fdopen(fd,'rb') as f:return f.read()
def sha(b):return hashlib.sha256(b).hexdigest()
guard('admission')
pins=json.loads(read(root/'SOURCE-PINS.json'));base=Path(pins['base']);assert sha(read(Path('/workspace/scratch/first-five-opening-hand-cue-runtime-freeze-root-r1.json')))==pins['freezeSha256']
for name,pin in pins['files'].items():
    assert sha(read(base/name))==pin['baseline']
    assert sha(read(root/'baseline'/name))==pin['baseline']
    assert sha(read(root/'candidate'/name))==pin['candidate']
diff=''.join(''.join(difflib.unified_diff(read(root/'baseline'/name).decode().splitlines(True),read(root/'candidate'/name).decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name)) for name in pins['files'])
assert read(root/'CHANGE.diff')==diff.encode()
notes='''# Actor-attached readout proposal — source only

The hypothesis is that narrower attached labels and actual creature names will make the opening formation read as creatures under command. This is an author hypothesis, not an accepted visual improvement or evidence of human enjoyment. Independent source, actual visual and gameplay reviewers may reject it.

## Exact baseline and scope

Baseline `/workspace/scratch/first-five-opening-hand-cue-stage-r1` is the strict-built 87-input hand-cue candidate, source `f2c79a0489325c1afacfbd7e7237394b183eefd4001a6d9a29fff08dae49bcfa`. Freeze JSON SHA256 is `83c237df55e767adebd7c455a87b19648f2ba1e2b0081c378b5ca3190faef6fe`. SOURCE-PINS.json independently binds the four consulted baseline bodies and four candidate bodies; it does not independently audit all 87 input or 56 output bodies. Matching baseline copies remain in this packet. CHANGE.diff exactly reconstructs those four candidates.

Only candidate/src/battlefield-layout.ts, arena.ts, main.ts and compact-readout.css differ. ROOT, the shared/frozen stages and all other game source remain untouched by this author. No build, TypeScript execution, Node, browser, server, cleanup, game action, engine/rules/save/RNG/sound/card rewrite, new demo or framework. No art is added or selected. Ordinary source/image inspection earlier in the task may have changed access time; byte identity is the claim.

## Design and geometry

The current layout assigns each intent and Inspect panel the full owned cell. The consulted old-H1 1440×900 first-fight capture shows approximately 708px hostile rails around small paintings. The capture is old source `46c1b0ff…`, not the new hand cue; its independent retained visual findings remain at `/workspace/scratch/standard-sol-opening-h1-retained-capture-independent-r1/REVIEW.md`.

The proposal changes readout width to `min(240, cellWidth)` and centers intent, Inspect, identity, stats and ready rectangles on the existing cell center. It does not narrow the allocated body, alter canvas paint fitting or replace the renderer's clipped paint/body intersection as the action hitRect. The renderer still publishes authoritative immutable regions and main positions controls from them. Cell width is always the upper bound, so dense cells are not forced to 240px. At width1440 the sparse two-hostile cell formula yields708px and the proposed readout240px; the fully folded six-unit formula yields209⅓px cells and readouts. These are hand-evaluated source equations, not executed geometry/browser results.

A previous separate 240px centered readout study exists at `/workspace/scratch/standard-sol-pc-owned-readout-author-r1`; the cap concept is not claimed as new. This packet applies that bounded hypothesis against the exact current frozen candidate and adds explicit natural-height identity handling.

Visible identities become actual `unit.name` plus stable canonical side ordinal, for example `Ironjaw Reaver · Hostile 1 ⓘ`. Original complete accessible button labels, Inspect handlers, target IDs, disabled conditions, formation occupancy and optional controls remain. Names wrap without ellipsis or line clamp. A natural inner `.field-nameplate` is measured separately from the allocated `.field-identity` container, allowing reserved empty rows without preventing later shrinkage. `identityRows` is an optional presentation metric, defaulting to one for existing callers. Normalization, comparison, desired allocation, arrival expansion and Inspect height all include it. Required canvas height reserves additional 16px rows in both side extents through the existing row-folding formula; stats begin after the allocated identity height. Natural intent children and stats rows retain their measurements. No essential intent is removed or truncated.

Only visible published actors participate in text measurement. Width, text and UID publication changes schedule measurement after DOM positions are applied, including newborns and retained visible corpses. Expired hidden actors do not impose stale maxima. Raw renderer widths are included; settled paint-only motion does not repeatedly schedule text measurements. Reduced-motion control and renderer allocation timing remain the existing paths.

## Review risks and integration

This is UNBUILT and UNPROMOTED. Syntax/type checking, real font wrapping, dense formation intersection, allocation convergence, scrolling/viewport fit, arrival/attack/death timing, keyboard/controller/mouse/Inspect/cancel behavior and performance remain unverified. Global maximum identity rows intentionally reserve equal vertical space for all actors; wrapped names can increase page height. A newly longer name can require one measurement frame before its increased allocation is published, following the existing intent/stat measurement loop; actual overlap/locking must be examined. Width interpolation can schedule several measurement frames during an allocation transition. The 240px cap is a design choice, not a measured optimum.

The inherited terminal `canonicalIndex === null` → `Binding lost`/`Hostile down` labeling condition remains in this frozen proposal. ROOT's newly observed living-survivor “Binding lost” beside “Survived” defect is NOT fixed or accepted here. The new fieldIdentity helper continues that inherited condition and requires deliberate rebasing onto ROOT's separately owned terminal-label repair. It must not overwrite or evade that repair. Full final-kill/terminal review is still required after any integration.

First obtain distinct source review of all four changes. If accepted, manually merge the relevant hunks onto the independently accepted next baseline; do not wholesale copy candidate main.ts over newer ROOT work. Apply layout/arena/host/CSS metrics together: CSS-only width shrinking leaves published rectangles misleading. A separate strict build and bounded real-PC comparison should inspect first fight, binding, command, six bindings/six hostiles, long compound intent/stats/name wrapping, terminal survivors and departed actors, normal/reduced motion and accessible controls. Capture natural focus, scroll position, document dimensions and topbar/Help/hand reach as the earlier retained reviewer requested. Keep visual judgments, agent gameplay and human feedback distinct.

Rollback is the four exact baseline bodies only when the staged target still matches this frozen baseline; otherwise revert these focused hunks without replacing unrelated later work. No promotion or own UX approval follows from this seal.

## Resource evidence and failure preservation

The first admission stopped before any baseline/candidate copy when getrusage.ru_maxrss reported202,653,696bytes. Exact sampled values and refusal remain in ATTEMPT-r1.json and the tool transcript. Why that high-water value arose was not independently established; inherited pre-exec accounting is a hypothesis. The driver was revised to `/proc/self/status` VmHWM for the running interpreter, without lowering the unchanged24MiB work/512MiB reserve gates. RESOURCE.json records successful admission/proposal/final samples: final interpreter VmHWM13,762,560B, aggregate positive delta1,011,712B, headroom2,349,289,472B. These three point samples do not establish continuous peak aggregate usage. During ROOT's exclusive baseline window all tools/source writes paused; documentation and seal resumed only after ROOT released it. SEAL-RESOURCE.json records fresh documentation/seal point samples.
'''
(root/'PROPOSAL.md').write_text(notes)
guard('documentation-written')
(root/'SEAL-RESOURCE.json').write_text(json.dumps(dict(workBytes=work,reserveBytes=reserve,scope='Documentation/hash-only seal; no runtime execution',samples=samples),indent=2)+'\n')
files=[]
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name!='MANIFEST.json':
        data=read(path);files.append(dict(relative=str(path.relative_to(root)),bytes=len(data),sha256=sha(data)))
manifest=dict(status='SEALED SOURCE PROPOSAL ONLY; UNBUILT; UNPROMOTED; independent review pending',sourceDigest=pins['sourceDigest'],files=files,limitations='No own UX acceptance, gameplay/human-fun claim, full87/56 identity audit or terminal-survivor fix.')
(root/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
guard('final')
print(json.dumps(dict(manifestSha256=sha(read(root/'MANIFEST.json')),members=len(files),scope='four-file source proposal',lastResource=samples[-1])))
