from pathlib import Path
import os,json,hashlib,difflib
root=Path('/workspace/scratch/standard-sol-actor-readout-author-r2')
r1=Path('/workspace/scratch/standard-sol-actor-readout-author-r1')
base=Path('/workspace/scratch/first-five-opening-hand-cue-stage-r1')
terminal=Path('/workspace/scratch/opening-terminal-identity-root-r1/main.ts')
work=24*1024*1024;reserve=512*1024*1024
limit=int(Path('/sys/fs/cgroup/memory.max').read_text());initial=int(Path('/sys/fs/cgroup/memory.current').read_text());samples=[]
def guard(label):
    current=int(Path('/sys/fs/cgroup/memory.current').read_text());rss=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmHWM:')))*1024
    row=dict(label=label,current=current,delta=max(0,current-initial),headroom=limit-current,processVmHWM=rss);samples.append(row)
    assert row['headroom']>=reserve and row['delta']<=work and rss<=work,row

def read(p):
    with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME),'rb') as f:return f.read()
def sha(b):return hashlib.sha256(b).hexdigest()
def replace(text,old,new):
    assert text.count(old)==1,(old,text.count(old));return text.replace(old,new)
def section(text,start,end):return text[text.index(start):text.index(end,text.index(start))]
guard('admission')
oldmanifest=read(r1/'MANIFEST.json');assert sha(oldmanifest)=='3f4bdb6191359e64cf949e4e2fd9d908d096bd6163f82728bc13f7aa0a3368e3'
for entry in json.loads(oldmanifest)['files']:assert sha(read(r1/entry['relative']))==entry['sha256'],entry['relative']
terminalbytes=read(terminal);assert sha(terminalbytes)=='f6ad54bbb22f53b187d6fbcd7745abb09d0f92cee58f7ffe452d250df702ec60'
pins=json.loads(read(r1/'SOURCE-PINS.json'));names=list(pins['files']);before={};after={}
for name in names:
    before[name]=terminalbytes if name=='src/main.ts' else read(base/name)
    if name!='src/main.ts':assert sha(before[name])==pins['files'][name]['baseline']
    after[name]=read(r1/'candidate'/name)
rootmain=terminalbytes.decode();firstmain=after['src/main.ts'].decode();newmain=rootmain
oldmeasure=section(rootmain,'function measureFieldReadouts() {','function positionFieldControls(')
newmeasure=section(firstmain,'function measureFieldReadouts() {','function positionFieldControls(')
newmain=replace(newmain,oldmeasure,newmeasure)
newmain=replace(newmain,'<span class="field-identity">${escape(identity)} <span aria-hidden="true">ⓘ</span></span>','<span class="field-identity"><span class="field-nameplate">${escape(unit.name)} · ${escape(identity)} <span aria-hidden="true">ⓘ</span></span></span>')
oldend="""    const identity = actor.querySelector<HTMLElement>('.field-identity');
    if (identity && region.canonicalIndex === null && !settlingCombat) identity.textContent = `${fieldIdentity(region.side === 'ally' ? 'allies' : 'enemies', region.readoutUnit, region.canonicalIndex)} ⓘ`;
  }
}
function renderBattle()"""
signature=section(firstmain,'  // Paint movement alone does not change text flow.','function renderBattle()')
newend="""    // Keep ROOT's terminal HP distinction and settling guard. Measure natural
    // inner text separately from the globally reserved identity rows.
    actor.style.setProperty('--identity-height', `${region.identityRect.height}px`);
    const identity = actor.querySelector<HTMLElement>('.field-nameplate');
    if (identity && region.canonicalIndex === null && !settlingCombat) {
      const label = `${region.readoutUnit.name} · ${fieldIdentity(region.side === 'ally' ? 'allies' : 'enemies', region.readoutUnit, region.canonicalIndex)} ⓘ`;
      if (identity.textContent !== label) identity.textContent = label;
    }
  }
"""+signature+'function renderBattle()'
newmain=replace(newmain,oldend,newend)
# Byte-preserve ROOT's authority and terminal presentation implementation.
assert section(newmain,'function fieldIdentity(','function fieldActor(')==section(rootmain,'function fieldIdentity(','function fieldActor(')
assert section(newmain,'function updateFinalStrikeReadout(','function render(')==section(rootmain,'function updateFinalStrikeReadout(','function render(')
assert 'const identity = fieldIdentity(side, unit, index);' in newmain
assert 'if (identity && region.canonicalIndex === null && !settlingCombat)' in newmain
assert 'if (unit.hp <= 0) return enemy ? \'Hostile down\' : \'Binding lost\';' in newmain
assert "return enemy ? 'Still standing' : 'Binding survived';" in newmain
after['src/main.ts']=newmain.encode()
guard('proposal-ready')
for name in names:
    for folder,data in [('baseline',before[name]),('candidate',after[name])]:
        path=root/folder/name;path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists();path.write_bytes(data)
diff=''.join(''.join(difflib.unified_diff(before[name].decode().splitlines(True),after[name].decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name)) for name in names)
(root/'CHANGE.diff').write_text(diff)
(root/'SOURCE-PINS.json').write_text(json.dumps(dict(base=str(base),baselineSourceDigest=pins['sourceDigest'],terminalMain=str(terminal),terminalMainSHA256=sha(terminalbytes),r1ManifestSHA256=sha(oldmanifest),files={name:dict(baseline=sha(before[name]),candidate=sha(after[name])) for name in names}),indent=2)+'\n')
notes='''# Readout r2 — terminal-corrected source rebase

This source-only revision preserves ROOT's terminal identity repair and adds the focused attached-readout geometry/identity metrics proposal. It is not built, merged, promoted or UX accepted. Reviewers may reject it.

The baseline is frozen hand-cue source `f2c79a0489325c1afacfbd7e7237394b183eefd4001a6d9a29fff08dae49bcfa`, with ONLY main.ts replaced by `/workspace/scratch/opening-terminal-identity-root-r1/main.ts`, SHA256 `f6ad54bbb22f53b187d6fbcd7745abb09d0f92cee58f7ffe452d250df702ec60`. This composite baseline has no claimed full-game digest or build. Four exact baseline/candidate bodies and their diff are supplied here. Do not apply the r1 main wholesale. The r1 packet and its source-RSS failure remain byte-exact, manifest `3f4bdb6191359e64cf949e4e2fd9d908d096bd6163f82728bc13f7aa0a3368e3`; all16 sealed members were rehashed before this rebase.

ROOT's fieldIdentity helper is byte-preserved: canonical ordinal when present; actual HP<=0 yields Hostile down/Binding lost when absent; positive retained HP yields Still standing/Binding survived. Initial fieldActor identity still calls that helper. The published-identity fallback still requires canonicalIndex===null AND !settlingCombat; it updates only the natural inner nameplate while retaining actual name plus ROOT's HP-based result. The whole updateFinalStrikeReadout-through-render section is byte-preserved, including terminal event-derived HP/stats, Survived/Still standing versus death status and accessible Final impact resolving labels. The ungated r1 identity synchronization was not carried over. No terminal replay or gameplay acceptance follows from those source checks.

The other three candidate files are exact r1 bodies. Shared layout publishes centered readouts at min(240px,actual cell width); body cells, painting and renderer-clipped hitRect ownership remain the existing paths. Actual creature names plus canonical ordinals are live wrapped12px/16px text. identityRows travels through shared normalization, metrics, allocation and required-height formulas; a natural inner nameplate is measured separately from reserved identity height so rows can expand/shrink honestly. Only visible published actors are measured, and width/content/UID publication changes schedule text measurement after positioning. Full intent/stat information, controls, six-unit occupancy and existing reduced-motion paths remain.

No Node, browser, server, build, TypeScript execution, synthetic game scenario, rules/save/RNG/sound/card changes, art integration, cleanup or shared writer. Hash equality and source assertions are the verification scope. No independent87-input/56-output audit is claimed.

Remaining risks are r1's actual font wrapping, global-row page-height growth, first measurement-frame overlap, geometry/DOM convergence, formation transitions, dense six-unit control/readout intersections and performance. The 240px cap is a reversible design hypothesis. Separate technical review must evaluate this exact diff against the terminal-corrected main. Then a separate strict build and real-PC first-fight/binding/command/dense/terminal comparison must inspect all visible intentions, positive-HP survivors and zero-HP deaths, Inspect/cancel/keyboard/controller, normal/reduced motion, document scroll and Help/hand reach. Agent gameplay and visual judgments cannot establish human fun.

Integrate the four focused file changes together only after independent acceptance; do not overwrite newer shared source. Roll back these hunks or the exact composite baseline bodies if the target still matches that baseline. ROOT owns actual merge, build and promotion.

RESOURCE.json retains fresh24MiB work/512MiB reserve point samples using actual interpreter /proc/self/status VmHWM. Original r1 getrusage refusal remains in its unchanged ATTEMPT-r1.json and prior tool output. Point samples do not prove a continuous aggregate peak.
'''
(root/'PROPOSAL.md').write_text(notes)
# Recheck all baseline inputs and the sealed predecessor without writing either.
assert read(terminal)==terminalbytes
for name in names:
    if name!='src/main.ts':assert read(base/name)==before[name]
for entry in json.loads(oldmanifest)['files']:assert sha(read(r1/entry['relative']))==entry['sha256']
guard('final')
(root/'RESOURCE.json').write_text(json.dumps(dict(workBytes=work,reserveBytes=reserve,scope='Source-only rebase and byte/hash assertions',samples=samples),indent=2)+'\n')
files=[]
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name!='MANIFEST.json':
        data=read(path);files.append(dict(relative=str(path.relative_to(root)),bytes=len(data),sha256=sha(data)))
(root/'MANIFEST.json').write_text(json.dumps(dict(status='SEALED SOURCE-ONLY R2; UNBUILT; UNMERGED; UNPROMOTED; independent review pending',files=files),indent=2)+'\n')
print(json.dumps(dict(manifestSHA256=sha(read(root/'MANIFEST.json')),diffSHA256=sha(read(root/'CHANGE.diff')),candidateMainSHA256=sha(after['src/main.ts']),members=len(files),resource=samples[-1])))
