# Independent source review — compact readout R2

Gate: **HOLD R2 for the smallest new source correction.** This is a source-only finding, not playable, visual, gameplay, human-fun or promotion acceptance. The current strict-built terminal hand-cue stage is unaffected.

Reviewed proposal manifest SHA256 `519db71e013fd8596d6a456dff0abe8de651c6769d85dc746e61f4ba022ccd26`. Independent hashing verifies all 13 sealed manifest bodies, exact generated four-file diff, and exact equality of all four baseline bodies with `/workspace/scratch/first-five-opening-hand-cue-terminal-stage-r1` and its frozen input hashes. That retained baseline is source `56834feaf81415b7dfd3a1f03ea4f0a24dc51eaee4bd0dea47c5e81d0b318928`, 87 inputs, 56 outputs, output ledger `8f21094090ad458071abfa078e2e3a6f3680cf7f3667313f72f5bc3156af92ab`. This review did not rehash the other 83 inputs or 56 outputs and does not claim an independent whole-build audit.

The four candidate body pins are:

| File | SHA256 |
| --- | --- |
| src/arena.ts | `77bbca50c42b109372ffb027b1b26826d79b51c89ded3b9aaae5de1a60a4f334` |
| src/battlefield-layout.ts | `1595f72fe8a1fd1a8f9c96302e6d217962098e265046c4d63502e2fb10811840` |
| src/compact-readout.css | `ea7fbf27f0bcf87dcb3e21088251dd91c6c2d297e110b673a9af8ea5f6db868d` |
| src/main.ts | `15f051390aef9a8eeeb3408711bcba6b0903c2ef1272b5cdbbb8ce47584678ac` |

## Blocking source gap

`createBattlefieldLayout` caps target readouts at `min(240, cellWidth)`. However, `interpolateCell` separately interpolates the body cell and all readout rectangles, while `projectCell` separately scales those rectangles. Published transitional readouts therefore do not necessarily obey the proposed width invariant. For example, interpolation from a 320px cell/240px readout to a 180px cell/180px readout produces a 250px cell/210px readout halfway through; the required width is 240px. A viewport growth during an active allocation transition can project the old 240px readout above 240px until the retained transition reaches its target.

The smallest correction should recompute attached readout horizontal bounds from the resulting cell after interpolation/projection, preserving their complete current vertical heights and a common center. Preserve the existing actual painted-body and clipped hit-rectangle ownership. Retain R2 and its finding; publish any correction as a new exterior revision. ROOT explicitly requires this correction before accepting the strict published-width claim.

## Other source findings

The HP-aware `fieldIdentity` helper is byte-identical, including positive-health absent-slot survivors versus actual defeat. The `canonicalIndex === null && !settlingCombat` update guard remains present. The entire `updateFinalStrikeReadout` through the start of `fieldIdentity` block is byte-identical, preserving event-derived terminal HP/stats, Survived/Still standing versus death status, Final impact resolving ARIA text and existing settling behavior. Actual creature names and live ordinals are escaped and retained in the nameplate.

Natural inner nameplate measurement is separate from the outer reserved identity height, avoiding a direct reserved-height feedback loop. Visible actors only are measured. Intent child heights and wrapped stat `scrollHeight` remain measured; width/content/UID changes schedule another measurement after positioning. Identity rows propagate through normalization, normal allocation, pending action allocation and required-height formulas. Slot counts/ownership, existing body fitting, actual paint/hit paths, legal actions, saves, RNG, fallback roster and reduced-motion paths have no new edits in this diff. Global border-box sizing and the inward Inspect border mean horizontal padding is part of the measured available text width. These static observations do not establish browser font fit, grid placement or convergence under motion.

## Required actual cases after correction and a separately admitted build

- Fresh opening with actual first binding and command: complete real names/ordinals, intention lines and stats; inspect the first wrapping measurement frame and hand/guidance/Help reach.
- PC resize during an active allocation transition and at ordinary sparse/dense widths: shared readout centers and complete heights, actual published width cap, no clipped information or stranded input. This is a focused resize case, not a mobile matrix.
- Dense six-allied/six-hostile formation, arrival/departure and an expansion followed by shrink: all occupants remain reachable; natural measured rows converge after width/content changes without repeated allocation locking or accumulating row height.
- Earned terminal clear with positive-health survivors and an actual zero-health death: names/labels/stats/ARIA agree throughout final impact and the retained settling guard prevents stale contradictory identity updates.
- Mouse Inspect/target/cancel, keyboard focus and controller code-path accessibility; normal and reduced motion; no-canvas fallback retains complete controls/readouts. Hardware controller behavior remains unverified unless actually exercised. Preserve real save/Continue behavior.

No Node, TypeScript/JavaScript execution, browser, build, server, source write, shared edit, art selection or cleanup occurred. R1/R2 failures and originals remain retained. Exact-body identity is strict; ordinary reads may change atime, with before/after metadata qualified accordingly in `BYTE-REVIEW.json`. The bounded Python hash/diff proof observed 13,377,536-byte interpreter VmHWM and 835,584-byte cgroup point delta under 24 MiB work with 512 MiB reserve; point samples do not establish a continuous aggregate peak. Earlier shell source reads were ordinary read-only inspections and had no aggregate peak capture.
