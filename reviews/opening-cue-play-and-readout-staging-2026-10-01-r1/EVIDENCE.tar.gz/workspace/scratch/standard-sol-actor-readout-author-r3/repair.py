from pathlib import Path
import os,json,hashlib,difflib
root=Path('/workspace/scratch/standard-sol-actor-readout-author-r3');r2=Path('/workspace/scratch/standard-sol-actor-readout-author-r2')
review=Path('/workspace/scratch/standard-sol-actor-readout-independent-r2/REVIEW.md')
terminalstage=Path('/workspace/scratch/first-five-opening-hand-cue-terminal-stage-r1')
work=24*1024*1024;reserve=512*1024*1024;limit=int(Path('/sys/fs/cgroup/memory.max').read_text());initial=int(Path('/sys/fs/cgroup/memory.current').read_text());samples=[]
def read(p):
    with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME),'rb') as f:return f.read()
def sha(b):return hashlib.sha256(b).hexdigest()
def guard(label):
    current=int(Path('/sys/fs/cgroup/memory.current').read_text());rss=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmHWM:')))*1024
    row=dict(label=label,current=current,delta=max(0,current-initial),headroom=limit-current,processVmHWM=rss);samples.append(row)
    assert row['headroom']>=reserve and row['delta']<=work and rss<=work,row

def replace(text,old,new):
    assert text.count(old)==1,(old,text.count(old));return text.replace(old,new)
guard('admission')
oldmanifest=read(r2/'MANIFEST.json');assert sha(oldmanifest)=='519db71e013fd8596d6a456dff0abe8de651c6769d85dc746e61f4ba022ccd26'
for entry in json.loads(oldmanifest)['files']:assert sha(read(r2/entry['relative']))==entry['sha256'],entry['relative']
reviewbytes=read(review);pins=json.loads(read(r2/'SOURCE-PINS.json'));names=list(pins['files']);before={};old={};after={}
for name in names:
    before[name]=read(r2/'baseline'/name);old[name]=read(r2/'candidate'/name);after[name]=old[name]
    assert sha(before[name])==pins['files'][name]['baseline']
    assert sha(old[name])==pins['files'][name]['candidate']
    assert read(terminalstage/name)==before[name],name
name='src/battlefield-layout.ts';text=old[name].decode()
text=replace(text,'const PAD = 8, GAP = 8;','const PAD = 8, GAP = 8, READOUT_MAX_WIDTH = 240;')
text=replace(text,'const readoutWidth = Math.min(240, cellWidth);','const readoutWidth = Math.min(READOUT_MAX_WIDTH, cellWidth);')
text=replace(text,'export function interpolateCell(a: BattlefieldCell, b: BattlefieldCell, blend: number): BattlefieldCell {\n  return { ...interpolateRect(a, b, blend),','''/** Horizontal readout ownership is derived after every cell transform.
 * Keep transformed vertical extents and body geometry exactly as supplied. */
function centerCellReadouts(cell: BattlefieldCell): BattlefieldCell {
  const width = Math.min(READOUT_MAX_WIDTH, cell.width);
  const left = cell.left + (cell.width - width) / 2;
  const center = (rect: BattlefieldRect): BattlefieldRect => ({ ...rect, left, width });
  return { ...cell, intentRect: center(cell.intentRect), inspectRect: center(cell.inspectRect),
    identityRect: center(cell.identityRect), statsRect: center(cell.statsRect), statusRect: center(cell.statusRect) };
}
export function interpolateCell(a: BattlefieldCell, b: BattlefieldCell, blend: number): BattlefieldCell {
  return centerCellReadouts({ ...interpolateRect(a, b, blend),''')
text=replace(text,'statusRect: interpolateRect(a.statusRect, b.statusRect, blend) };','statusRect: interpolateRect(a.statusRect, b.statusRect, blend) });')
text=replace(text,'return { ...project(cell), bodyRect: project(cell.bodyRect), intentRect: project(cell.intentRect),','return centerCellReadouts({ ...project(cell), bodyRect: project(cell.bodyRect), intentRect: project(cell.intentRect),')
text=replace(text,'statsRect: project(cell.statsRect), statusRect: project(cell.statusRect) };','statsRect: project(cell.statsRect), statusRect: project(cell.statusRect) });')
after[name]=text.encode()
# Only the shared layout changes from R2; helper copies original top/height and body.
for unchanged in names:
    if unchanged!=name:assert after[unchanged]==old[unchanged]
assert 'const center = (rect: BattlefieldRect): BattlefieldRect => ({ ...rect, left, width });' in text
assert 'bodyRect: interpolateRect(a.bodyRect, b.bodyRect, blend)' in text
assert 'bodyRect: project(cell.bodyRect)' in text
guard('repair-ready')
for name in names:
    for folder,data in [('baseline',before[name]),('candidate',after[name])]:
        p=root/folder/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data)
def make_diff(a,b,names,ap,bp):
    return ''.join(''.join(difflib.unified_diff(a[name].decode().splitlines(True),b[name].decode().splitlines(True),fromfile=ap+name,tofile=bp+name)) for name in names)
(root/'CHANGE.diff').write_text(make_diff(before,after,names,'a/','b/'))
(root/'R2-to-R3.diff').write_text(make_diff(old,after,['src/battlefield-layout.ts'],'r2/','r3/'))
(root/'SOURCE-PINS.json').write_text(json.dumps(dict(baselineStage=str(terminalstage),baselineSourceDigestFromIndependentReview='56834feaf81415b7dfd3a1f03ea4f0a24dc51eaee4bd0dea47c5e81d0b318928',baselineIdentityScope='Four baseline source bodies independently rehashed here; no full87/56 audit',r2ManifestSHA256=sha(oldmanifest),holdReview=dict(path=str(review),sha256=sha(reviewbytes)),files={name:dict(baseline=sha(before[name]),r2=sha(old[name]),candidate=sha(after[name])) for name in names}),indent=2)+'\n')
(root/'PROPOSAL.md').write_text('''# Readout r3 — cell-transform horizontal repair

SOURCE ONLY; UNBUILT; UNMERGED; UNPROMOTED. Independent source, visual and gameplay acceptance remain pending; the author cannot approve its UX.

R2 is retained byte-exact with its independent HOLD in `/workspace/scratch/standard-sol-actor-readout-independent-r2/REVIEW.md`. That review found that separately interpolating or scaling existing readout widths did not preserve `min(240,resultingCell.width)`. A 320→180px cell at halfway can have a250px resulting cell with a210px readout when240px is required; projection can temporarily enlarge240px beyond the cap. These are the review's source counterexamples, not executed browser cases.

R3 changes only candidate/src/battlefield-layout.ts relative to R2. `centerCellReadouts` derives width from the resulting cell and centers all five readout rectangles after `interpolateCell` and `projectCell`. It replaces only each attached rectangle's left/width; transformed top/height, cell geometry and bodyRect remain unchanged. The target constructor and the transform repair share READOUT_MAX_WIDTH=240. Thus widths remain bounded by the actual resulting cell rather than being interpolated/scaled as an independent lane. No new framework or presentation timeline.

The other three candidate bodies remain exactly R2: arena identity-row propagation, terminal-corrected main name/measurement integration and CSS. ROOT's HP-aware fieldIdentity helper, final-strike HP/stat/Survived/death statuses, null-index AND !settlingCombat guard, unchanged paint/body/hit ownership and accessible controls are preserved. Complete natural-height intent, identity and stats measurement, six-unit occupancy and reduced motion retain R2's paths.

CHANGE.diff contains the full four-file proposal against the exact terminal-corrected stage `/workspace/scratch/first-five-opening-hand-cue-terminal-stage-r1`; R2-to-R3.diff contains only this repair. All four supplied baseline bodies were rehashed equal to that stage. Its whole source56834fe… digest is quoted from the independent R2 review, not newly established by an87-input/56-output audit. SOURCE-PINS.json gives full baseline/R2/R3 pins and the retained HOLD review body hash. All13 R2 manifest members were rehashed unchanged before and after authoring. R1's original source-RSS failure and previous packets remain retained.

Verification is limited to byte/hash checks and source assertions. No JavaScript/TypeScript execution, Node, browser, build, server, game action, shared source edit, rules/save/RNG/sound/card change, new art or cleanup occurred. RESOURCE.json records24MiB work/512MiB reserve point samples with actual interpreter VmHWM; samples do not establish a continuous aggregate peak.

The independent reviewer must inspect this exact correction. After separately admitted build, existing focused actual fit checks still apply: first fight/binding/command, resize during allocation, dense six-unit occupancy, row expansion/shrink, earned terminal survivors/deaths, full intentions/names/stats, Inspect/cancel and accessible controls, normal/reduced motion. Centered widths can cross the240px threshold during interpolation; text remeasurement/convergence and complete vertical reach remain runtime questions. Real fit testing follows cue-PC acceptance; no new screen matrix or human-fun claim is introduced.

ROOT owns any later merge/promotion. Apply the four focused file changes together after independent acceptance; do not overwrite newer shared source. Revert the focused hunks or exact matching baseline to roll back.
''')
for entry in json.loads(oldmanifest)['files']:assert sha(read(r2/entry['relative']))==entry['sha256']
assert read(review)==reviewbytes
for name in names:assert read(terminalstage/name)==before[name]
guard('final')
(root/'RESOURCE.json').write_text(json.dumps(dict(workBytes=work,reserveBytes=reserve,scope='Source-only R3 repair and byte/hash assertions',samples=samples),indent=2)+'\n')
files=[]
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name!='MANIFEST.json':
        data=read(path);files.append(dict(relative=str(path.relative_to(root)),bytes=len(data),sha256=sha(data)))
(root/'MANIFEST.json').write_text(json.dumps(dict(status='SEALED SOURCE-ONLY R3; UNBUILT; UNMERGED; UNPROMOTED; independent review pending',files=files),indent=2)+'\n')
print(json.dumps(dict(manifestSHA256=sha(read(root/'MANIFEST.json')),repairDiffSHA256=sha(read(root/'R2-to-R3.diff')),layoutSHA256=sha(after['src/battlefield-layout.ts']),members=len(files),resource=samples[-1])))
