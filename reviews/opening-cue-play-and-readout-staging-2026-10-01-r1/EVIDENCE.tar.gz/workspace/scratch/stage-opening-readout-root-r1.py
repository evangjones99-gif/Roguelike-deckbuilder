import os,json,hashlib,shutil,time
from pathlib import Path
base=Path('/workspace/scratch/first-five-opening-hand-cue-terminal-stage-r1');stage=Path('/workspace/scratch/first-five-opening-readout-stage-r1');author=Path('/workspace/scratch/standard-sol-actor-readout-author-r3/candidate')
freeze=json.loads(Path('/workspace/scratch/first-five-opening-hand-cue-terminal-runtime-freeze-root-r1.json').read_text())
def digest(p):
    h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
    try:
        s=os.fstat(fd)
        while b:=os.read(fd,65536):h.update(b)
        assert os.fstat(fd)==s
    finally:os.close(fd)
    return h.hexdigest()
assert freeze['sourceDigest']=='56834feaf81415b7dfd3a1f03ea4f0a24dc51eaee4bd0dea47c5e81d0b318928'
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h,rel
replacements={'src/battlefield-layout.ts': '6bbe1518398964b624bbcc8ce81f7fb36a02c9902fb8286336e9aae34f4d6b58', 'src/arena.ts': '77bbca50c42b109372ffb027b1b26826d79b51c89ded3b9aaae5de1a60a4f334', 'src/main.ts': '15f051390aef9a8eeeb3408711bcba6b0903c2ef1272b5cdbbb8ce47584678ac', 'src/compact-readout.css': 'ea7fbf27f0bcf87dcb3e21088251dd91c6c2d297e110b673a9af8ea5f6db868d'}
for rel,h in replacements.items():assert digest(author/rel)==h
stage.mkdir(mode=0o700)
for current,names,files in os.walk(base,followlinks=False):
    names[:]=[n for n in names if n not in ['dist','node_modules','public']]
    for name in names:assert not (Path(current)/name).is_symlink()
    for name in files:
        source=Path(current)/name;assert not source.is_symlink()
        rel=source.relative_to(base).as_posix();target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
        source=author/rel if rel in replacements else source
        fd=os.open(source,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
        try:
            with target.open('xb') as f:
                while b:=os.read(fd,65536):f.write(b)
                f.flush();os.fsync(f.fileno())
        finally:os.close(fd)
(stage/'public').symlink_to(base.joinpath('public').resolve(),target_is_directory=True)
(stage/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules',target_is_directory=True)
inputs={**freeze['inputs'],**replacements}
for rel,h in inputs.items():assert digest(stage/rel)==h
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h
record={'stage':str(stage),'status':'COMPACT NAMED CREATURE READOUTS STAGED; UNBUILT; UNPROMOTED','baselineStage':str(base),'baselineSourceDigest':freeze['sourceDigest'],'inputs':dict(sorted(inputs.items())),'inputCount':len(inputs),'sourceDigest':hashlib.sha256(json.dumps(dict(sorted(inputs.items())),separators=(',',':')).encode()).hexdigest(),'onlyChangedInputs':list(replacements),'sharedPublicRoot':str(base.joinpath('public').resolve()),'baselineUnchanged':True,'limitations':'No new playable/brower/human-fun/art/release acceptance.'}
p=Path('/workspace/scratch/first-five-opening-readout-assembly-root-r1.json')
with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
for folder in [stage,stage.parent]:fd=os.open(folder,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({k:v for k,v in record.items() if k!='inputs'}))
