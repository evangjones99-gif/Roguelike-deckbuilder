from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image
from scipy.spatial import ConvexHull
p=Path('/workspace/scratch/bone-thrall-variable-pose-visual-independent-v09-r1');raw=Path('/tmp/hollowpact-bone-thrall-variable-pose-v09-author-r1/public/art/bone-thrall-poses-v09-r2.png');b=raw.read_bytes();assert hashlib.sha256(b).hexdigest()=='440bdad1f593538aeb1a5e2a44e5f611bbd8339f36146b11a069a72c4c2f93b2';alpha=np.array(Image.open(raw))[:,:,3];rows=[]
for pose,rect,foot in [('idle',[55,56,506,508],[255,495]),('anticipation',[552,101,951,504],[772,490]),('attack',[1001,105,1524,504],[1235,494]),('recovery',[43,541,522,971],[255,955]),('reaction',[568,533,992,968],[782,954]),('death',[996,745,1534,967],[1260,950])]:
 l,t,r,bot=rect;y,x=np.nonzero(alpha[t:bot,l:r]>=8);pts=np.column_stack([x+l,y+t]);h=ConvexHull(pts);rows.append({'pose':pose,'rect':rect,'plantarPlane':foot,'hullAlpha8':pts[h.vertices].tolist(),'paintedPixelsAlpha8':len(pts)})
(p/'SOURCE-HULLS.json').write_text(json.dumps({'rawPath':str(raw),'sha256':hashlib.sha256(b).hexdigest(),'rows':rows},indent=2)+'\n');print('independent readonly sixalpha8 hulls computed')
