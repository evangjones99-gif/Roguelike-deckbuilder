"""Executes only the exact author prefix before transaction/snapshot/mutation."""
from pathlib import Path
import hashlib,json,ast,traceback,datetime
source_path=Path('/workspace/Roguelike-deckbuilder/reviews/root-tmp-runtime-capacity-v0.8/consolidate.py')
expected='577d71a18f3a9b45e8c9abcf20439daf2358ad98c2c687bac4297b9a7a52c283'
raw=source_path.read_bytes(); assert hashlib.sha256(raw).hexdigest()==expected
source=raw.decode(); boundary=source.index('\nfree_before=')
prefix=source[:boundary]
calls=[]
for node in ast.walk(ast.parse(prefix)):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute):
  assert node.func.attr not in {'write_text','write_bytes','mkdir','unlink','replace','link','utime','fsync'}
  if node.func.attr=='open': assert len(node.args)==1 and isinstance(node.args[0],ast.Constant) and node.args[0].value=='rb'
  calls.append(node.func.attr)
namespace={}
result={'sourceSHA256':expected,'boundary':'before free_before, snapshot writes and all transaction mutations',
        'scope':'Exact source prefix executes read-only full metadata/hash/membership/alias/schema preflight. No consolidation or capacity reclamation; file reads may update atime.',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 exec(compile(prefix,str(source_path)+' [read-only prefix]','exec'),namespace)
 result.update(status='passed',rows=len(namespace['rows']),directories=len(namespace['directories']),groups=len(namespace['groups']),
               files=len(namespace['rows'])-len(namespace['directories']),roots=len(namespace['roots']),
               distinct_candidate_paths=len(namespace['seen']),auditSHA256=namespace['EXPECTED'])
except Exception:
 result.update(status='rejected-first-preflight-failure',failure=traceback.format_exc())
Path(__file__).with_name('READ-ONLY-PREFLIGHT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='failure'}))
if result['status']!='passed':raise SystemExit(1)
