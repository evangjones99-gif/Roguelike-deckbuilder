import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import {validateState,applyAction,createGame,applyActionWithEvents,legalActions,type GameState,type Action} from './source/src/engine.ts';
import {ENEMIES} from './source/src/content.ts';
const OUT='/workspace/scratch/encounter-art-author-v08-r2', BASE='http://127.0.0.1:4461/';
const fixture=JSON.parse(await fs.readFile('/workspace/scratch/crypt-art-study-v08/inputs/fullhand-fixture.json','utf8'));
const provenance=JSON.parse(await fs.readFile('/tmp/hollowpact-encounter-art-v08-r2/dist/build-provenance.json','utf8'));
const crypt='/art/ossuary-crypt-v08-r2.png';
const hash=(bytes:Buffer)=>createHash('sha256').update(bytes).digest('hex');
const nodeRoutes:Record<number,string[]>={1:['battle'],2:['battle','event'],4:['battle','elite'],6:['battle','elite'],8:['elite','battle'],10:['boss']};
function entered(seed:number,node:number,kind:string,generation:1|2=2):GameState {
  let s=createGame(seed,0,{engineKind:generation});s.floor=node-1;s.route=nodeRoutes[node];assert(validateState(s));s=applyAction(s,{type:'travel',choice:kind});assert(validateState(s));
  const pile=[...s.hand,...s.draw,...s.discard];s.hand=['scour','ironward'].map(id=>{const i=pile.indexOf(id);assert(i>=0);return pile.splice(i,1)[0];});s.draw=pile;s.discard=[];assert(validateState(s));return s;
}
function choose(node:number,kind:string,predicate:(s:GameState)=>boolean,generation:1|2=2):GameState {for(let seed=1;seed<300;seed++){const s=entered(seed,node,kind,generation);if(predicate(s))return s;}throw Error('No qualifying actual world');}
const cryptMixed=choose(4,'elite',s=>s.enemies.some(e=>e.cardId==='brood')&&s.enemies.some(e=>e.cardId==='acolyte'));
const courtMixed=choose(2,'battle',s=>s.enemies.some(e=>e.cardId==='raider')&&s.enemies.some(e=>e.cardId==='thrall'));
const spectral=choose(4,'battle',s=>s.enemies.every(e=>['wraith','thrall'].includes(e.species)));
const cryptNormal=choose(4,'battle',s=>s.enemies.some(e=>e.species==='necromancer'));
const legacyMixed=choose(4,'elite',s=>s.enemies.some(e=>e.cardId==='acolyte'),1);
const killable=(input:GameState,id?:string)=>{const s=structuredClone(input);if(id)s.enemies.find(e=>e.cardId===id)!.hp=1;else s.enemies.forEach(e=>e.hp=1);assert(validateState(s));return s;};
const rows:any[]=[];
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
async function open(name:string,s:GameState,environment:string,opts:{motion?:boolean,missing?:boolean,late?:boolean,viewport?:{width:number,height:number}}={}){
  const context=await browser.newContext({viewport:opts.viewport??{width:1280,height:720},reducedMotion:opts.motion?'no-preference':'reduce'});
  await context.addInitScript(({s,motion})=>{
    localStorage.setItem('hollowpact.run.v2',JSON.stringify(s));localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion,mute:true,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');
    (window as any).__authorBack=[];
    const original=CanvasRenderingContext2D.prototype.drawImage;
    CanvasRenderingContext2D.prototype.drawImage=function(...args:any[]){if(args[0] instanceof HTMLImageElement&&/abbey-courtyard|ossuary-crypt/.test(args[0].src))(window as any).__authorBack.push({url:args[0].src,source:[args[0].naturalWidth,args[0].naturalHeight],destination:args.slice(1),at:performance.now()});return original.apply(this,args as any);};
  },{s,motion:opts.motion??false});
  let release:Function|undefined;
  if(opts.missing)await context.route('**'+crypt,r=>r.abort('failed'));
  if(opts.late)await context.route('**'+crypt,async r=>{await new Promise<void>(resolve=>{release=resolve;});await r.continue();});
  const page=await context.newPage();const errors:string[]=[],requests:string[]=[],bodies:any[]=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>requests.push(new URL(r.url()).pathname));
  page.on('response',async r=>{if(r.url().endsWith(crypt)){try{const b=await r.body();bodies.push({status:r.status(),bytes:b.length,sha256:hash(b)});}catch{}}});
  await page.goto(BASE,{waitUntil:opts.late?'domcontentloaded':'load'});await page.locator('[data-ui=resume]').click();
  await page.waitForTimeout(opts.late?100:250);
  assert.equal(await page.getAttribute('#arena','aria-label'),`An illustrated ${environment}. Bound monsters face the forces of the hollow. All combat controls are in the companion and enemy panels.`);
  assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),JSON.stringify(s));
  const row:any={name,initial:s,environment,viewport:opts.viewport??{width:1280,height:720},options:opts,steps:[],errors,requests,bodies};
  async function snapshot(label:string){const data=await page.evaluate(()=>{const c=document.querySelector<HTMLCanvasElement>('#arena')!,r=c.getBoundingClientRect();return{phase:JSON.parse(localStorage.getItem('hollowpact.run.v2')!).phase,label:c.getAttribute('aria-label'),notice:document.querySelector('.arena-art-status')?.textContent,held:document.querySelector('#app')?.classList.contains('settling-combat'),draws:(window as any).__authorBack.slice(-3),canvas:[r.width,r.height],save:localStorage.getItem('hollowpact.run.v2')};});row.steps.push({label,...data});return data;}
  let current=s;
  async function act(action:Action){assert(legalActions(current).some(a=>JSON.stringify(a)===JSON.stringify(action)));const expected=applyActionWithEvents(current,action);
    if(action.type==='play'){await page.locator(`[data-ui=play-card][data-index="${action.index}"]`).click();if(action.target)await page.locator(`[data-unit="${action.target}"]`).click();}
    else if(action.type==='endTurn'){await page.locator('[data-action=endTurn]').click();if(await page.locator('dialog[open] [data-ui=confirm-end]').count())await page.locator('[data-ui=confirm-end]').click();}
    else if(action.type==='reward')await page.locator('[data-action=reward][data-card=""]').click();
    else if(action.type==='travel')await page.locator(`[data-action=travel][data-choice="${action.choice}"]`).click();
    else throw Error('Unimplemented author UI action');
    assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),JSON.stringify(expected.state));
    current=expected.state;row.steps.push({action,expected,canonicalExact:true});return expected;
  }
  async function close(){await snapshot('final');assert.deepEqual(errors,[]);if(!opts.missing&&!opts.late)assert.equal(await page.locator('.arena-art-status').textContent(),'');if(environment==='ruined abbey courtyard')assert(!requests.includes(crypt));else assert(requests.includes(crypt));await context.close();rows.push(row);}
  return{page,row,act,snapshot,close,release:()=>release?.(),current:()=>current};
}
async function reload(h:Awaited<ReturnType<typeof open>>){
  const saved=await h.page.evaluate(()=>localStorage.getItem('hollowpact.run.v2'));
  const before=await h.page.getAttribute('#arena','aria-label');
  await h.page.reload();if(await h.page.locator('[data-ui=resume]').count())await h.page.locator('[data-ui=resume]').click();
  await h.page.waitForTimeout(200);
  assert.equal(await h.page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),saved);
  assert.equal(await h.page.getAttribute('#arena','aria-label'),before);
  h.row.steps.push({reloaded:true,saveExact:true,labelExact:true});await h.snapshot('actual-reload');
}
try{
  for(const[name,s,env]of[
    ['original-mixed-crypt',cryptMixed,'ossuary crypt'],
    ['original-mixed-courtyard',courtMixed,'ruined abbey courtyard'],
    ['original-spectral-crypt',spectral,'ossuary crypt'],
    ['legacy-necromancer-conservative',legacyMixed,'ruined abbey courtyard'],
    ['legacy-cantor-boss',entered(1,10,'boss',1),'ossuary crypt'],
    ['legacy-warlord-boss',entered(3,10,'boss',1),'ruined abbey courtyard'],
  ]as const){const h=await open(name,s,env);await reload(h);await h.close();}
  for(const[name,original,id,env]of[
    ['dead-necromancer-with-live-dragon',cryptMixed,'acolyte','ossuary crypt'],
    ['dead-warlord-with-live-thrall',courtMixed,'raider','ruined abbey courtyard'],
  ]as const){const h=await open(name,killable(original,id),env);const target=h.current().enemies.find(e=>e.cardId===id)!;await h.act({type:'play',index:h.current().hand.indexOf('scour'),target:target.uid});assert.equal(h.current().enemies.length,1);await reload(h);await h.close();}
  {const h=await open('actual-crypt-thrall-reinforcement',cryptNormal,'ossuary crypt');await h.act({type:'endTurn'});assert(h.current().enemies.filter(e=>e.species==='thrall').length>=2);await reload(h);await h.close();}
  {let s=structuredClone(spectral);s.enemies=s.enemies.slice(0,1);s.enemies[0].hp=1;assert(validateState(s));const h=await open('crypt-final-reward-reload',s,'ossuary crypt',{motion:true});await h.act({type:'play',index:h.current().hand.indexOf('scour'),target:h.current().enemies[0].uid});assert.equal(h.current().phase,'reward');assert((await h.snapshot('held-final-death')).held);await h.page.waitForTimeout(1600);await h.snapshot('settled-final-death');await reload(h);await h.act({type:'reward',card:null});await h.act({type:'travel',choice:'battle'});const original=h.current().enemies.map(e=>e.species);const env=original.includes('necromancer')||original.every(e=>e==='wraith'||e==='thrall')?'ossuary crypt':'ruined abbey courtyard';assert((await h.snapshot('next-battle')).label?.includes(env));h.row.nextEnvironment=env;await h.close();}
  {const h=await open('actual-cantor-final-victory',killable(entered(1,10,'boss')),'ossuary crypt',{motion:true});await h.act({type:'play',index:h.current().hand.indexOf('scour'),target:h.current().enemies[0].uid});assert.equal(h.current().phase,'victory');assert((await h.snapshot('held-final-boss-death')).held);await h.page.waitForTimeout(1600);await h.snapshot('settled-victory');await reload(h);await h.close();}
  {const s=structuredClone(cryptMixed);s.hp=1;for(const e of s.enemies)e.intent={damage:e.attack,target:'hunter',label:'Diagnostic lethal existing unit attack'};assert(validateState(s));const h=await open('crypt-defeat-reload',s,'ossuary crypt',{motion:true});await h.act({type:'endTurn'});assert.equal(h.current().phase,'defeat');await h.snapshot('defeat-held');await h.page.waitForTimeout(1600);await reload(h);await h.close();}
  {const h=await open('missing-selected-crypt',cryptNormal,'ossuary crypt',{missing:true});assert((await h.snapshot('missing')).notice);await h.act({type:'play',index:h.current().hand.indexOf('ironward')});await h.close();}
  {const h=await open('late-selected-crypt',cryptNormal,'ossuary crypt',{late:true});assert(!(await h.snapshot('fallback')).draws.some((d:any)=>d.url.endsWith(crypt)));await h.act({type:'play',index:h.current().hand.indexOf('ironward')});h.release();await h.page.waitForTimeout(400);const late=await h.snapshot('loaded');assert(late.draws.some((d:any)=>d.url.endsWith(crypt)));assert.equal(late.notice,'');await h.close();}
  for(const viewport of[{width:1920,height:720},{width:390,height:844}]){const h=await open('crypt-static-'+viewport.width,cryptMixed,'ossuary crypt',{viewport});await h.page.screenshot({path:OUT+'/actual-'+viewport.width+'-html.png'});await h.close();}
  await fs.writeFile(OUT+'/actual-host-r2.json',JSON.stringify({scope:'Author actual built web UI. Engine-sampled real kind2/legacy original formations entered from valid unearned map checkpoints; hand reorder/lethal HP/intent diagnostic modifications explicitly present. Ordinary pointer actions, natural timers and actual reload; exact canonical applyActionWithEvents state/storage oracles. No earned campaign, native install, human fun or independent acceptance.',provenance,rows},null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({cases:rows.length,actions:rows.reduce((n,r)=>n+r.steps.filter((s:any)=>s.action).length,0),reloads:rows.reduce((n,r)=>n+r.steps.filter((s:any)=>s.reloaded).length,0),sourceDigest:provenance.sourceDigest}));
}catch(error){await fs.writeFile(OUT+'/actual-host-failure-r2.json',JSON.stringify({error:String(error),rows},null,2)+'\n',{flag:'wx'});throw error;}finally{await browser.close();}
