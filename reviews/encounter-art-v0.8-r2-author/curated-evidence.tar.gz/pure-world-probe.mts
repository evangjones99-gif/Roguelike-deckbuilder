import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createGame,applyAction,validateState,type GameState} from './source/src/engine.ts';
import {encounterEnvironment} from './source/src/encounter-environment.ts';
const routes:Record<number,string[]>={1:['battle'],2:['battle','event'],4:['battle','elite'],6:['battle','elite'],8:['elite','battle'],10:['boss']};
function freeze<T>(value:T):T {if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;}
const rows:any[]=[];
for(const generation of[1,2]as const)for(let seed=1;seed<=24;seed++)for(const node of[1,2,4,6,8,10])for(const kind of routes[node].filter(r=>['battle','elite','boss'].includes(r))){
  let s=createGame(seed,0,{engineKind:generation});s.floor=node-1;s.route=routes[node];assert(validateState(s));s=applyAction(s,{type:'travel',choice:kind});assert(validateState(s));
  const species=s.enemies.map(e=>e.species);
  const expected=(generation===2||kind==='boss')&&(species.includes('necromancer')||species.every(name=>name==='wraith'||name==='thrall'))?'crypt':'courtyard';
  const serialized=JSON.stringify(s);freeze(s);assert.equal(encounterEnvironment(s),expected);assert.equal(JSON.stringify(s),serialized);
  const contrary=structuredClone(s);contrary.enemies=[];freeze(contrary);assert.equal(encounterEnvironment(contrary),expected);
  // Presentation lookup needs only canonical context, even after the engine
  // has released the formation. Terminal context is tested without inventing
  // a save migration or consuming an action/RNG stream here.
  for(const phase of ['reward','defeat']as const){const terminal=freeze({...s,phase,enemies:[]}) as GameState;assert.equal(encounterEnvironment(terminal),expected);}
  if(kind==='boss'){const victory=freeze({...s,phase:'victory',route:[],enemies:[]}) as GameState;assert.equal(encounterEnvironment(victory),expected);}
  rows.push({generation,seed,node,kind,actualEngineFormation:s.enemies.map(e=>e.cardId),expected,deepFrozenInputExact:true,contraryRosterIgnored:true,terminalContextStable:true});
}
await fs.writeFile('/workspace/scratch/encounter-art-author-v08-r2/pure-world-probe.json',JSON.stringify({scope:'480 actual engine-sampled formations from valid unearned map checkpoints. Frozen-input/contrary-roster and terminal-context probes are presentation-unit observations; empty terminal probe objects are not asserted as legal saves. Actual legal terminal transitions/reloads are separate browser evidence.',rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({contexts:rows.length,crypt:rows.filter(r=>r.expected==='crypt').length,allPassed:true}));
