"""Original r2 indexed pixel drawings, not filters or downsampled painted art.
One-off inspectable source author/export. Execute only in Root's source window.
"""
import json, pathlib, struct, zlib, hashlib, os, time
ROOT=pathlib.Path(__file__).resolve().parent
W,H=64,48
WORK=24*1024*1024;RESERVE=512*1024*1024
PALETTE=[None,'#14171b','#26333c','#43535d','#6b7c80','#6e6552','#b3aa89','#e0d9b0','#626967','#969d92','#795a41','#64393f','#92565b','#e9a25b']
KEYS='0123456789ABCD'
FRAMES=['idle0','idle1','anticipate0','anticipate1','attack0','attack1','contact','recover0','recover1','hit0','hit1','death0','death1','death2']
INITIAL=None;MAXIMUM=None
def guard():
 current=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
 maximum=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
 hwm=int(next(l.split()[1] for l in pathlib.Path('/proc/self/status').read_text().splitlines() if l.startswith('VmHWM:')))*1024
 spent=max(0,current-INITIAL)
 if maximum!=MAXIMUM or hwm>WORK or spent>WORK or maximum-current<RESERVE+max(0,WORK-spent):
  raise RuntimeError(f'Export resource refusal: initial={INITIAL},current={current},maximum={maximum},VmHWM={hwm},work={WORK},reserve={RESERVE}')
 return current,hwm
def grid():return [['0']*W for _ in range(H)]
def pixel(g,x,y,c):
 assert isinstance(x,int) and isinstance(y,int) and 0<=x<W and 0<=y<H,(x,y,c)
 assert c in KEYS;g[y][x]=c
def rect(g,x,y,w,h,c):
 for py in range(y,y+h):
  for px in range(x,x+w):pixel(g,px,py,c)
def mask(g,x,y,rows):
 for dy,row in enumerate(rows):
  for dx,c in enumerate(row):
   if c!='0':pixel(g,x+dx,y+dy,c)
def poly(g,points,c):
 for y in range(min(p[1] for p in points),max(p[1] for p in points)+1):
  for x in range(min(p[0] for p in points),max(p[0] for p in points)+1):
   inside=False;j=len(points)-1
   for i in range(len(points)):
    a,b=points[i],points[j]
    if (a[1]>y+.5)!=(b[1]>y+.5) and x+.5<(b[0]-a[0])*(y+.5-a[1])/(b[1]-a[1])+a[0]:inside=not inside
    j=i
   if inside:pixel(g,x,y,c)
def line(g,a,b,c,width=1):
 x,y=a;tx,ty=b;dx=abs(tx-x);dy=-abs(ty-y);sx=1 if x<tx else -1;sy=1 if y<ty else -1;err=dx+dy;r=width//2
 while True:
  for yy in range(y-r,y+r+1):
   for xx in range(x-r,x+r+1):pixel(g,xx,yy,c)
  if x==tx and y==ty:break
  twice=2*err
  if twice>=dy:err+=dy;x+=sx
  if twice<=dx:err+=dx;y+=sy
def limb(g,a,j,b,fill='3',thickness=3):
 line(g,a,j,'1',thickness+2);line(g,j,b,'1',thickness+2)
 line(g,a,j,fill,thickness);line(g,j,b,fill,thickness)
def boot(g,x,y,fill='8'):
 poly(g,[(x,y-4),(x+4,y-4),(x+5,y-1),(x+8,y-1),(x+8,y+1),(x-1,y+1),(x-1,y-2)],'1')
 rect(g,x,y-2,5,2,fill);rect(g,x+1,y,6,1,fill)
HOOD=['000111111000','001BBBBB2100','01BCCCCBB210','1BCCCBBBBB21','1BCCB1555521','1BCB15566521','1BB215516521','1BB211566521','01BB21111210','001BBBBB2100','000122221000','000011110000']
FALLEN_HOOD=['000111111100','001BBBBBBB10','01BCCB155521','1BCCB15566521','1BBB21156521','01BB21111210','001BBBBB2100','000111111000']
SKULL=['000166666100','001677777610','016777777761','167711771761','167111711761','167711771761','167776776761','016776676610','001671176100','001676676100','000166661000','000011110000']
FALLEN_SKULL=['00166666100','01677777610','16771177761','16711171761','16771177761','01677667610','00167117610','00016666100','00001111000']
def cleaver(g,hand,top,bottom,contact=False):
 # Broad vertical iron head and a short wooden grip. Different from the spear.
 line(g,hand,(top[0]-3,top[1]+5),'1',3);line(g,hand,(top[0]-3,top[1]+5),'A')
 x,y=top;bx,by=bottom
 poly(g,[(x,y),(x+5,y),(bx,by),(bx-5,by),(x-2,y+4)],'1')
 poly(g,[(x+1,y+1),(x+4,y+1),(bx-1,by-1),(bx-4,by-1),(x-1,y+4)],'8')
 line(g,(x+4,y+2),(bx-1,by-2),'9')
 rect(g,hand[0]-1,hand[1]-1,3,3,'A')
 if contact:pixel(g,63,25,'9')

# Each tuple reposes head, coat/hip, elbow, fist, weapon and knee support.
HUNTER={
 'idle0':(24,5,28,30,(36,25),(42,30),(46,25),(48,38),(20,37),(33,38)),
 'idle1':(24,6,28,30,(35,26),(41,31),(45,26),(47,38),(20,37),(33,38)),
 'anticipate0':(23,7,27,33,(30,24),(30,17),(25,7),(25,20),(19,38),(33,39)),
 'anticipate1':(22,8,26,34,(28,25),(25,16),(17,5),(19,18),(17,39),(33,40)),
 'attack0':(25,5,29,30,(38,17),(44,12),(48,4),(54,15),(20,37),(36,38)),
 'attack1':(27,6,31,31,(42,22),(51,21),(56,15),(63,30),(20,38),(38,39)),
 'contact':(28,7,32,32,(43,23),(53,25),(58,18),(63,32),(19,38),(40,40)),
 'recover0':(26,8,30,33,(39,29),(46,33),(50,31),(54,43),(20,39),(36,40)),
 'recover1':(24,6,28,31,(36,27),(42,31),(46,26),(48,39),(20,38),(33,38)),
 'hit0':(19,8,25,33,(27,27),(34,29),(38,22),(42,35),(17,39),(32,39)),
 'hit1':(22,7,27,32,(33,27),(38,31),(42,26),(45,39),(19,38),(33,38))}
def hunter(name):
 g=grid()
 if name.startswith('death'):
  n=int(name[-1])
  if n==0:
   # One knee lands; torso retains coat volume, free forearm braces the fall.
   limb(g,(28,32),(23,40),(18,42),'2',3);limb(g,(32,33),(37,41),(34,42),'2',3)
   poly(g,[(22,23),(34,22),(38,33),(31,42),(18,42),(19,32)],'1')
   poly(g,[(24,25),(32,24),(35,33),(29,40),(20,40),(22,32)],'B')
   poly(g,[(24,26),(27,25),(28,39),(21,40)],'C')
   limb(g,(32,28),(41,34),(42,41),'8',3);boot(g,15,43);boot(g,31,43)
   mask(g,27,14,HOOD);cleaver(g,(42,39),(48,30),(55,43))
  elif n==1:
   # Braced elbow and folded coat form an arch rather than a horizontal bar.
   poly(g,[(13,39),(20,28),(30,27),(39,35),(37,43),(13,44)],'1')
   poly(g,[(16,38),(22,30),(29,30),(35,36),(33,42),(16,42)],'B')
   poly(g,[(18,37),(22,32),(25,31),(23,41),(17,42)],'C')
   limb(g,(20,36),(16,40),(22,42),'2',3);limb(g,(30,34),(39,38),(40,42),'8',3)
   mask(g,35,25,FALLEN_HOOD);boot(g,11,43);line(g,(43,42),(54,40),'A')
   poly(g,[(52,35),(58,35),(60,44),(52,44)],'8');line(g,(58,36),(59,43),'9')
  else:
   # Curled sidefall: folded boots, rounded coat back, head and bent wrist.
   poly(g,[(10,41),(12,35),(19,31),(29,31),(38,36),(42,41),(37,44),(13,44)],'1')
   poly(g,[(14,39),(15,36),(20,33),(28,33),(35,37),(38,41),(34,42),(16,42)],'B')
   poly(g,[(17,36),(21,34),(25,34),(21,41),(15,42)],'C')
   limb(g,(20,37),(13,38),(14,42),'2',3);boot(g,9,43)
   limb(g,(30,38),(37,41),(41,39),'8',3);mask(g,39,33,FALLEN_HOOD)
   poly(g,[(51,39),(58,38),(61,44),(51,44)],'8');line(g,(57,39),(59,43),'9');line(g,(43,43),(52,42),'A')
  return g
 hx,hy,hipx,hipy,elbow,fist,top,bottom,lk,rk=HUNTER[name]
 limb(g,(hipx-3,hipy),lk,(18,41),'2',3);limb(g,(hipx+3,hipy),rk,(35 if name not in ['attack1','contact'] else 41,41),'3',3)
 boot(g,14,43,'8');boot(g,31 if name not in ['attack1','contact'] else 37,43,'8')
 # Heavy split coat: broad shoulders, tapered belt, flared panels, a leg gap.
 poly(g,[(hx-3,hy+12),(hx+10,hy+12),(hipx+7,hipy),(hipx+10,40),(hipx+1,41),(hipx-1,35),(hipx-5,41),(hipx-12,39),(hipx-7,hipy)],'1')
 poly(g,[(hx-1,hy+14),(hx+8,hy+14),(hipx+5,hipy),(hipx+7,38),(hipx+2,39),(hipx,33),(hipx-5,39),(hipx-9,37),(hipx-5,hipy)],'B')
 poly(g,[(hx,hy+15),(hx+3,hy+14),(hipx-2,32),(hipx-5,38),(hipx-8,37),(hipx-4,30)],'C')
 rect(g,hipx-5,hipy-1,11,2,'A');rect(g,hipx+1,hipy-1,2,2,'9')
 limb(g,(hx-1,hy+16),(hx-4,hy+22),(hipx-6,hipy-1),'3',3)
 shoulder=(hx+8,hy+16);limb(g,shoulder,elbow,fist,'8',3)
 rect(g,shoulder[0]-2,shoulder[1]-2,5,3,'8');line(g,(shoulder[0]-2,shoulder[1]-2),(shoulder[0]+1,shoulder[1]-2),'9')
 cleaver(g,fist,top,bottom,name=='contact');mask(g,hx,hy,HOOD)
 return g

# Hound anatomy is a connected, high-shouldered dog. No antlers or equal rods.
HOUND={
 'idle0':(0,0,0,0),'idle1':(0,0,-1,1),'anticipate0':(-2,2,-2,2),'anticipate1':(-3,3,-3,3),
 'attack0':(2,-1,2,4),'attack1':(4,0,4,6),'contact':(5,1,5,7),'recover0':(3,2,2,3),'recover1':(1,1,0,1),
 'hit0':(-3,3,-4,2),'hit1':(-1,2,-2,1)}
def paw(g,x,y,c='4'):
 poly(g,[(x-2,y-3),(x+2,y-3),(x+3,y-1),(x+5,y-1),(x+5,y+1),(x-3,y+1),(x-3,y-1)],'1')
 rect(g,x-1,y-2,3,2,c);rect(g,x-1,y,5,1,c);pixel(g,x+3,y,'6')
def dog_head(g,x,y,mouth=0,contact=False,fallen=False):
 # Canine wedge muzzle, separate upright ear, brow, black nose and lower jaw.
 poly(g,[(x,y+4),(x+4,y),(x+10,y+1),(x+12,y+5),(x+19,y+7),(x+20,y+10),(x+12,y+13),(x+4,y+14),(x-2,y+9)],'1')
 poly(g,[(x+1,y+5),(x+5,y+2),(x+9,y+3),(x+10,y+7),(x+17,y+8),(x+17,y+10),(x+10,y+11),(x+4,y+12),(x,y+8)],'3')
 poly(g,[(x+4,y+3),(x+8,y+3),(x+9,y+6),(x+6,y+7),(x+3,y+6)],'4')
 poly(g,[(x+9,y+8),(x+17,y+8),(x+17,y+10),(x+10,y+11)],'6')
 if not fallen:
  poly(g,[(x+1,y+4),(x+1,y-3),(x+6,y+1)],'1');poly(g,[(x+2,y+2),(x+2,y-1),(x+4,y+1)],'4')
 rect(g,x+16,y+8,3,2,'1');pixel(g,x+8,y+6,'7')
 # Negative mouth notch and a genuine lower mandible, not a contact trail.
 poly(g,[(x+9,y+11),(x+18,y+10),(x+17,y+12+mouth),(x+8,y+14+mouth),(x+5,y+12)],'1')
 line(g,(x+7,y+13+mouth),(x+16,y+11+mouth),'5',1)
 pixel(g,x+14,y+10,'7');pixel(g,x+12,y+12+mouth,'6')
 if contact:
  # Upper jaw's solid triangular wedge reaches x63/y33; no antler/magic ray.
  poly(g,[(x+12,y+8),(62,31),(63,33),(x+13,y+11)],'6')
  pixel(g,63,33,'7')
def hound(name):
 g=grid()
 if name.startswith('death'):
  n=int(name[-1])
  if n==0:
   # Forelegs buckle while a raised haunch and tucked hock still carry weight.
   limb(g,(16,29),(13,36),(18,41),'3',3);paw(g,18,43)
   limb(g,(31,32),(33,39),(38,41),'3',3);paw(g,38,43)
   poly(g,[(7,25),(13,20),(22,23),(29,28),(38,29),(42,35),(35,40),(25,36),(17,34),(9,32)],'1')
   poly(g,[(10,26),(14,23),(20,25),(26,30),(35,31),(38,35),(33,38),(24,33),(16,32),(12,31)],'3')
   poly(g,[(12,25),(15,24),(19,27),(20,31),(14,31)],'4')
   dog_head(g,39,27,1,fallen=True);line(g,(8,28),(4,33),'3',3)
  elif n==1:
   poly(g,[(9,32),(14,27),(23,28),(28,33),(36,32),(42,37),(39,42),(24,43),(12,40)],'1')
   poly(g,[(12,33),(16,30),(21,30),(26,36),(35,35),(38,38),(36,40),(24,41),(15,38)],'3')
   poly(g,[(15,31),(19,31),(21,35),(17,38),(13,37)],'4')
   limb(g,(19,36),(13,40),(20,41),'3',3);paw(g,21,43)
   limb(g,(32,37),(37,41),(42,41),'3',3);paw(g,42,43)
   dog_head(g,39,28,0,fallen=True);line(g,(10,35),(5,39),'3',3)
  else:
   # Curled dog keeps a rounded hip, shoulder ridge, folded paws and skull.
   poly(g,[(7,38),(9,32),(15,28),(23,29),(28,33),(34,34),(40,39),(38,44),(15,44),(8,42)],'1')
   poly(g,[(11,37),(12,33),(16,31),(21,32),(24,36),(33,36),(36,40),(33,42),(16,42),(11,40)],'3')
   poly(g,[(13,33),(16,32),(19,33),(21,36),(18,39),(13,38)],'4')
   limb(g,(19,37),(15,40),(22,41),'3',3);paw(g,24,43)
   limb(g,(31,39),(36,41),(41,41),'3',3);paw(g,40,43)
   dog_head(g,38,28,0,fallen=True);line(g,(9,39),(5,42),'3',3)
  return g
 dx,dy,head,opening=HOUND[name]
 hip=(15+dx,27+dy);chest=(32+dx,28+dy)
 # Rear thigh is visibly broad and bent; foreleg descends from deep chest.
 limb(g,(hip[0]+2,hip[1]),(21+dx,35),(15,41),'2',3);paw(g,15,43,'3')
 limb(g,(chest[0]-3,chest[1]+2),(30+dx,36),(28,41),'2',3);paw(g,28,43,'3')
 limb(g,(hip[0]-2,hip[1]),(10+dx,34),(11 if name not in ['attack1','contact'] else 8,41),'3',3)
 paw(g,11 if name not in ['attack1','contact'] else 8,43)
 forefoot=42 if name not in ['attack1','contact'] else 48
 limb(g,(chest[0]+3,chest[1]),(36+dx,35),(forefoot,41),'3',3);paw(g,forefoot,43)
 # Tail sweeps down; three curved masses form haunch, tucked belly and chest.
 line(g,(11+dx,24+dy),(6+dx,27+dy),'1',5);line(g,(6+dx,27+dy),(4,34),'1',3)
 line(g,(11+dx,24+dy),(6+dx,27+dy),'3',3);line(g,(6+dx,27+dy),(4,34),'4')
 poly(g,[(8+dx,23+dy),(12+dx,18+dy),(20+dx,18+dy),(25+dx,21+dy),(29+dx,19+dy),(36+dx,17+dy),(41+dx,23+dy),(40+dx,31+dy),(35+dx,35+dy),(29+dx,33+dy),(24+dx,29+dy),(18+dx,32+dy),(11+dx,30+dy)],'1')
 poly(g,[(11+dx,23+dy),(14+dx,20+dy),(19+dx,20+dy),(24+dx,24+dy),(30+dx,21+dy),(35+dx,20+dy),(38+dx,24+dy),(37+dx,30+dy),(34+dx,32+dy),(30+dx,30+dy),(25+dx,27+dy),(18+dx,29+dy),(13+dx,28+dy)],'3')
 poly(g,[(13+dx,22+dy),(16+dx,21+dy),(19+dx,22+dy),(20+dx,26+dy),(16+dx,28+dy),(12+dx,26+dy)],'4')
 poly(g,[(30+dx,22+dy),(34+dx,21+dy),(36+dx,24+dy),(35+dx,29+dy),(32+dx,30+dy),(29+dx,27+dy)],'4')
 line(g,(23+dx,23+dy),(29+dx,22+dy),'4');line(g,(24+dx,27+dy),(28+dx,29+dy),'2',3)
 dog_head(g,37+head,17+dy,opening,name=='contact')
 return g

SKELETON={
 'idle0':(24,4,28,30,(37,25),(41,29),(55,17)),
 'idle1':(24,5,28,30,(36,26),(40,30),(54,18)),
 'anticipate0':(21,7,26,32,(29,25),(31,30),(45,19)),
 'anticipate1':(20,8,25,33,(25,25),(27,29),(39,21)),
 'attack0':(24,5,29,31,(35,23),(42,26),(56,24)),
 'attack1':(26,6,31,32,(40,24),(48,26),(62,25)),
 'contact':(27,7,32,33,(41,25),(49,27),(63,25)),
 'recover0':(25,8,30,33,(36,27),(43,31),(56,30)),
 'recover1':(24,5,28,31,(37,26),(41,30),(54,19)),
 'hit0':(19,8,24,34,(28,27),(34,31),(46,24)),
 'hit1':(22,6,27,32,(33,26),(38,30),(51,21))}
def ribs(g,cx,cy,slant=0):
 # Vertebrae and separated curved ribs leave a real open dark cage.
 line(g,(cx,cy),(cx+slant,cy+10),'5',3);line(g,(cx,cy),(cx+slant,cy+10),'7')
 for i in range(3):
  y=cy+i*3;x=cx+(slant*i)//3
  line(g,(x-1,y),(x-6,y+1),'1',3);line(g,(x-6,y+1),(x-4,y+3),'1',3)
  line(g,(x+1,y),(x+6,y+1),'1',3);line(g,(x+6,y+1),(x+4,y+3),'1',3)
  line(g,(x-1,y),(x-5,y+1),'6');line(g,(x-5,y+1),(x-4,y+2),'7')
  line(g,(x+1,y),(x+5,y+1),'6');line(g,(x+5,y+1),(x+4,y+2),'7')
def spear(g,hand,tip,contact=False):
 # Diagonal idle guard becomes a horizontal thrust; no hook or broad cleaver.
 butt=(max(3,hand[0]-13),min(42,hand[1]+6))
 line(g,butt,(tip[0]-5,tip[1]+1),'1',3);line(g,butt,(tip[0]-5,tip[1]+1),'A')
 poly(g,[(tip[0]-7,tip[1]),(tip[0]-3,tip[1]-2),(tip[0],tip[1]),(tip[0]-3,tip[1]+2)],'8')
 line(g,(tip[0]-5,tip[1]),tip,'9');rect(g,hand[0]-1,hand[1]-1,3,3,'6')
 if contact:pixel(g,63,25,'9')
def skeleton(name):
 g=grid()
 if name.startswith('death'):
  n=int(name[-1])
  if n==0:
   limb(g,(25,33),(18,39),(18,42),'6',1);limb(g,(29,33),(35,40),(33,42),'6',1)
   ribs(g,27,25,3);mask(g,25,14,SKULL)
   limb(g,(32,28),(40,35),(40,41),'6',1);spear(g,(39,39),(56,33))
   rect(g,15,43,7,2,'5');rect(g,31,43,6,2,'6')
  elif n==1:
   # Folded cage, pelvis and kneecaps remain distinct; skull turns floorward.
   limb(g,(24,36),(16,40),(19,42),'6',1);limb(g,(29,36),(33,41),(39,42),'6',1)
   ribs(g,26,31,5);mask(g,36,27,FALLEN_SKULL)
   limb(g,(30,33),(38,39),(43,42),'6',1);spear(g,(39,42),(58,41))
   rect(g,15,43,7,2,'5');rect(g,35,43,7,2,'6')
  else:
   # A readable heap of cage and crossed bent bones, never a uniform bar.
   limb(g,(24,37),(14,38),(18,42),'6',1);limb(g,(28,38),(29,42),(39,40),'6',1)
   ribs(g,28,32,4);mask(g,39,32,FALLEN_SKULL)
   line(g,(32,38),(39,41),'6',3);line(g,(32,38),(39,41),'7')
   spear(g,(40,43),(61,42));rect(g,15,43,7,2,'5')
  return g
 hx,hy,hipx,hipy,elbow,hand,tip=SKELETON[name]
 right=38 if name in ['attack1','contact'] else 34
 limb(g,(hipx-4,hipy),(20,38),(18,42),'6',1);limb(g,(hipx+3,hipy),(right,37),(right,42),'6',1)
 rect(g,15,43,7,2,'5');rect(g,right-2,43,7,2,'6');pixel(g,19,38,'7');pixel(g,right,37,'7')
 poly(g,[(hipx-6,hipy-2),(hipx+5,hipy-2),(hipx+6,hipy+2),(hipx+2,hipy+4),(hipx-1,hipy+1),(hipx-4,hipy+4),(hipx-7,hipy+1)],'1')
 poly(g,[(hipx-5,hipy-1),(hipx+4,hipy-1),(hipx+4,hipy+1),(hipx+2,hipy+2),(hipx-1,hipy),(hipx-4,hipy+2)],'6')
 cx=hx+5;cy=hy+15
 ribs(g,cx,cy,(hipx-cx)//2)
 line(g,(cx-6,cy-1),(cx+6,cy),'6',3);line(g,(cx-5,cy-1),(cx+4,cy),'7')
 limb(g,(cx-6,cy),(hx-3,hy+22),(hipx-7,hipy),'6',1)
 limb(g,(cx+6,cy),elbow,hand,'6',1);pixel(g,elbow[0],elbow[1],'7')
 spear(g,hand,tip,name=='contact');mask(g,hx,hy,SKULL)
 poly(g,[(hx+1,hy+2),(hx+3,hy-1),(hx+9,hy-1),(hx+11,hy+2),(hx+7,hy+1),(hx+4,hy+3)],'8')
 line(g,(hx+3,hy),(hx+7,hy),'9')
 if name=='hit0':pixel(g,24,25,'6');pixel(g,24,33,'6')
 return g

# Quiet dark masonry; ground behind legs uses index1 rather than body index3.
TILE=['2222222222222222','1111111211111111','1111111211111111','1111111211111111','1111111211111111','1111111211111111','1111111211111111','1111111111111111','2222222222222222','1112111111111111','1112111111111111','1112111111111111','1112111111111111','1112111111111111','1112111111111111','1111111111111111']
def png_chunk(name,data):return struct.pack('!I',len(data))+name+data+struct.pack('!I',zlib.crc32(name+data)&0xffffffff)
def write_sheet(actor):
 rows=[];sheetw=W*4;sheeth=H*4
 for y in range(sheeth):
  row=[]
  for x in range(sheetw):
   f=(y//H)*4+x//W;c=actor['frames'][FRAMES[f]][y%H][x%W] if f<len(FRAMES) else '0';row.append(KEYS.index(c))
  rows.append(bytes(row))
 plte=b''.join(bytes.fromhex(color[1:]) if color else bytes([0,0,0]) for color in PALETTE)
 raw=b''.join(b'\x00'+row for row in rows)
 png=b'\x89PNG\r\n\x1a\n'+png_chunk(b'IHDR',struct.pack('!IIBBBBB',sheetw,sheeth,8,3,0,0,0))+png_chunk(b'PLTE',plte)+png_chunk(b'tRNS',bytes([0]+[255]*13))+png_chunk(b'IDAT',zlib.compress(raw,9))+png_chunk(b'IEND',b'')
 (ROOT/'assets'/f"{actor['id']}-sheet.png").write_bytes(png)
 return dict(width=sheetw,height=sheeth,columns=4,frameOrder=FRAMES,sha256=hashlib.sha256(png).hexdigest())
def write_contact_study(actors):
 # Authored composition from original masks, not a modified input screenshot.
 sw,sh=224,128;rows=[['1']*sw for _ in range(sh*3)]
 for panel,name in enumerate(['hunter','hound','skeleton']):
  oy=panel*sh
  for y in range(16,104):
   for x in range(sw):rows[oy+y][x]=TILE[(y-16)%16][x%16]
  for x in range(sw):rows[oy+104][x]='2'
  actor=actors[name];victim=actors['hunter' if name=='skeleton' else 'skeleton']
  origin=(64,60);contact=actor['contact'];anchor=victim['hitAnchors'][actor['targetAnchor']]
  tx=origin[0]+contact[0]-(W-1-anchor[0]);ty=origin[1]+contact[1]-anchor[1]
  for frame,x0,y0,mirror in [(actor['frames']['contact'],origin[0],origin[1],False),(victim['frames']['hit0'],tx,ty,True)]:
   for y,row in enumerate(frame):
    for x,c in enumerate(row):
     if c!='0':rows[oy+y0+y][x0+(W-1-x if mirror else x)]=c
  rows[oy+origin[1]+contact[1]][origin[0]+contact[0]]='D'
  guard()
 width,height=sw*3,sh*3*3
 raw=bytearray()
 for row in rows:
  expanded=bytes(KEYS.index(c) for c in row for _ in range(3))
  for _ in range(3):raw.extend(b'\x00');raw.extend(expanded)
 plte=b''.join(bytes.fromhex(color[1:]) if color else bytes([0,0,0]) for color in PALETTE)
 png=b'\x89PNG\r\n\x1a\n'+png_chunk(b'IHDR',struct.pack('!IIBBBBB',width,height,8,3,0,0,0))+png_chunk(b'PLTE',plte)+png_chunk(b'tRNS',bytes([0]+[255]*13))+png_chunk(b'IDAT',zlib.compress(raw,9))+png_chunk(b'IEND',b'')
 (ROOT/'assets'/'contact-study-3x.png').write_bytes(png);guard()
 return dict(width=width,height=height,scale=3,rows=['hunter→skeleton','hound→skeleton','skeleton→hunter'],sha256=hashlib.sha256(png).hexdigest(),kind='Authored indexed static composition, not browser capture')
def export():
 global INITIAL,MAXIMUM
 INITIAL=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());MAXIMUM=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
 if MAXIMUM-INITIAL<WORK+RESERVE:raise SystemExit(f'Fresh source export admission refused: current={INITIAL},maximum={MAXIMUM},work={WORK},reserve={RESERVE}')
 guard();(ROOT/'assets').mkdir(exist_ok=True);actors={}
 for name,make in [('hunter',hunter),('hound',hound),('skeleton',skeleton)]:
  frames={frame:[''.join(row) for row in make(frame)] for frame in FRAMES};guard()
  assert len({''.join(rows) for rows in frames.values()})==len(FRAMES),'Every pose must be a distinct drawing'
  for rows in frames.values():
   assert len(rows)==H and all(len(row)==W for row in rows)
   assert all(c=='0' for row in rows[45:] for c in row),'Ground extent exceeded'
  bounds={}
  for frame,rows in frames.items():
   points=[(x,y) for y,row in enumerate(rows) for x,c in enumerate(row) if c!='0']
   bounds[frame]=dict(left=min(x for x,y in points),top=min(y for x,y in points),right=max(x for x,y in points)+1,bottom=max(y for x,y in points)+1)
  union=dict(left=min(b['left'] for b in bounds.values()),top=min(b['top'] for b in bounds.values()),right=max(b['right'] for b in bounds.values()),bottom=max(b['bottom'] for b in bounds.values()))
  actor=dict(id=name,width=W,height=H,feet=[24,44],contact=[63,33 if name=='hound' else 25],targetAnchor='knee' if name=='hound' else 'chest',hitAnchors=dict(chest=[24,25],knee=[24,33]),nativeFacing='right',frameBounds=bounds,unionBounds=union,frames=frames)
  assert frames['contact'][actor['contact'][1]][63]!='0'
  actors[name]=actor;actor['sheet']=write_sheet(actor);guard()
 assert actors['skeleton']['frames']['hit0'][25][24]!='0' and actors['skeleton']['frames']['hit0'][33][24]!='0'
 assert actors['hunter']['frames']['hit0'][25][24]!='0'
 study=write_contact_study(actors)
 payload=dict(palette=PALETTE,keys=KEYS,cell=[W,H],frameOrder=FRAMES,tile=TILE,actors=actors,contactStudy=study)
 (ROOT/'sprites.js').write_text('// Original indexed r2 drawings; no sampled or filtered image input.\nexport const ART = '+json.dumps(payload,separators=(',',':'))+';\n')
 current,hwm=guard();report=dict(admitted=True,initial_current=INITIAL,maximum=MAXIMUM,current_at_report=current,work=WORK,reserve=RESERVE,actual_VmHWM_bytes=hwm,time_ns=time.time_ns(),scope='Original indexed source author/export only; no JavaScript, Node, browser, server or game build.')
 (ROOT/'EXPORT-RESOURCE.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
if __name__=='__main__':export()
