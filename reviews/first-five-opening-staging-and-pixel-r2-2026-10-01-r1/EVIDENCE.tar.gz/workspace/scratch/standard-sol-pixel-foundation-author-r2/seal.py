"""Bounded original-art source freeze, never JS/browser/game execution."""
import os,pathlib,hashlib,json,time,stat
ROOT=pathlib.Path(__file__).resolve().parent
OLD=ROOT.with_name('standard-sol-pixel-foundation-author-r1')
WORK=24*1024*1024;RESERVE=512*1024*1024
def memory():return int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text()),int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
INITIAL,MAXIMUM=memory()
if MAXIMUM-INITIAL<WORK+RESERVE:raise SystemExit(f'Fresh seal admission refused: current={INITIAL},maximum={MAXIMUM},work={WORK},reserve={RESERVE}')
def guard():
 current,maximum=memory()
 hwm=int(next(l.split()[1] for l in pathlib.Path('/proc/self/status').read_text().splitlines() if l.startswith('VmHWM:')))*1024
 spent=max(0,current-INITIAL)
 if maximum!=MAXIMUM or hwm>WORK or spent>WORK or maximum-current<RESERVE+max(0,WORK-spent):raise RuntimeError(f'Seal refusal: initial={INITIAL},current={current},maximum={maximum},VmHWM={hwm},work={WORK},reserve={RESERVE}')
 return current,hwm
def body(path,keep=False):
 fd=os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd)
  if not stat.S_ISREG(before.st_mode) or before.st_size>1024*1024:raise RuntimeError('Nonregular/oversized source')
  digest=hashlib.sha256();parts=[]
  while chunk:=os.read(fd,32768):
   digest.update(chunk)
   if keep:parts.append(chunk)
   guard()
  after=os.fstat(fd)
  if any(getattr(before,k)!=getattr(after,k) for k in ['st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_atime_ns']):raise RuntimeError('Moving input')
  return {'bytes':before.st_size,'sha256':digest.hexdigest()},b''.join(parts)
 finally:os.close(fd)
def write(name,value):
 with os.fdopen(os.open(ROOT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'w') as file:json.dump(value,file,indent=2);file.write('\n')
oldpin,oldbytes=body(OLD/'MANIFEST.json',True)
if oldpin['sha256']!='ee2d57c54d509c13979719dbf3ddb10e3e7700527757014b9703a0cf06529f53':raise RuntimeError('Old r1 manifest changed')
old=json.loads(oldbytes)
for name,expected in old['files'].items():
 if body(OLD/name)[0]!=expected:raise RuntimeError('Old r1 body changed: '+name)
consulted={}
for name,sha in [('REVIEW.md','87cf6804fd28623cdb6de733ef927be89ed08f0a26b1ad98ba4bb21ccdf5d065'),('RENDERER-MIGRATION-NOTE.txt','a2136a10918e5e3e38070a2a6881d8a8e89f1d82e227595a29bb0e739622ad23')]:
 path=ROOT.with_name('standard-sol-pixel-direction-visual-research-r1')/name
 item=body(path)[0]
 if item['sha256']!=sha:raise RuntimeError('Consulted research changed')
 consulted[str(path)]=item
write('SOURCE-PINS.json',{'preserved_r1_manifest':oldpin,'preserved_r1_body_count':len(old['files']),'preserved_r1_all_bodies_match':True,'consulted_style_and_migration':consulted,
 'scope':'Original side-view anatomy research only. Latest intended near-side rear-three-quarter and far-side front/three-quarter perspectives remain unimplemented. No main/renderer/guard/game edit.',
 'source_boundary':'Prior inspected game interfaces/pins remain in exact r1 SOURCE-PINS.json. No claim that these sources were re-read or integrated in r2.',
 'execution':'Two guarded original indexed Python exports, native sheets and static3x compositions inspected; no JS evaluation/Node/server/browser/build.'})
current,hwm=guard()
write('SEAL-RESOURCE.json',{'admitted':True,'initial_current':INITIAL,'maximum':MAXIMUM,'current_at_report':current,'actual_VmHWM_bytes':hwm,'work':WORK,'reserve':RESERVE,'time_ns':time.time_ns(),'scope':'This 32KiB-stream source seal process only; export resource records are separate. VmHWM is /proc/self/status, not getrusage.'})
files={}
for path in sorted(ROOT.rglob('*')):
 if path.is_symlink():raise RuntimeError('Symlink in packet')
 if path.is_file():files[str(path.relative_to(ROOT))]=body(path)[0]
total=sum(item['bytes'] for item in files.values())
if total>512*1024:raise RuntimeError('Small packet ceiling exceeded')
write('MANIFEST.json',{'kind':'Original pixel foundation r2 SOURCE freeze','scope':'Side-view anatomy research; unexecuted browser lab, no integration/style/fun acceptance. R1 preserved exactly.', 'files':files,'body_count':len(files),'body_bytes':total})
manifest=body(ROOT/'MANIFEST.json')[0]
print(json.dumps({'manifest':manifest,'body_count':len(files),'body_bytes':total,'final_actual_VmHWM_bytes':guard()[1]},indent=2))
