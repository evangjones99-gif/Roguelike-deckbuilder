import { ART } from './sprites.js';
import { createTimeline, CONTACT_MS, END_MS } from './timeline.js';

const get = id => document.getElementById(id);
const stage = get('stage'), context = stage.getContext('2d');
const systemMotion = matchMedia('(prefers-reduced-motion: reduce)');
const listeners = [];
let selected = 'hound', scale = 3, guide = false, disposed = false, raf = 0;
let lastTime = 0, frameState = { actorPose: 'idle0', victimPose: 'idle0', phase: 'idle', sequence: 0, contacts: 0, active: false };
const contactLog = [];
const shelves = Object.fromEntries(Object.keys(ART.actors).map(id => [id, get(`${id}-canvas`)]));
const reduced = () => systemMotion.matches || get('reduce').checked;
function text(id, value) { const node = get(id); if (node.textContent !== value) node.textContent = value; }
function listen(target, event, callback) { target.addEventListener(event, callback); listeners.push([target, event, callback]); }
function flipPoint(actor, point, facing) { return [facing === 'left' ? actor.width - 1 - point[0] : point[0], point[1]]; }
function pair() {
  const actor = ART.actors[selected], victim = ART.actors[selected === 'skeleton' ? 'hunter' : 'skeleton'];
  const origin = [64, 60], contact = flipPoint(actor, actor.contact, 'right');
  const target = flipPoint(victim, victim.hitAnchors[actor.targetAnchor], 'left');
  return { actor, victim, origin, targetOrigin: [origin[0] + contact[0] - target[0], origin[1] + contact[1] - target[1]],
    point: [origin[0] + contact[0], origin[1] + contact[1]] };
}
function indexed(ctx, rows, x, y, facing = 'right') {
  if (!ctx) return;
  ctx.imageSmoothingEnabled = false;
  for (let sy = 0; sy < rows.length; sy++) for (let sx = 0; sx < rows[sy].length; sx++) {
    const index = ART.keys.indexOf(rows[sy][sx]); if (!index) continue;
    ctx.fillStyle = ART.palette[index]; ctx.fillRect(x + (facing === 'left' ? rows[sy].length - 1 - sx : sx), y + sy, 1, 1);
  }
}
function backdrop(ctx) {
  ctx.fillStyle = ART.palette[1]; ctx.fillRect(0, 0, stage.width, stage.height);
  for (let y = 16; y < stage.height; y += 16) for (let x = 0; x < stage.width; x += 16) indexed(ctx, ART.tile, x, y);
  ctx.fillStyle = ART.palette[1]; ctx.fillRect(0, 104, stage.width, 24);
  ctx.fillStyle = ART.palette[2]; ctx.fillRect(0, 104, stage.width, 1);
}
function dot(ctx, point, color) { ctx.fillStyle = color; ctx.fillRect(point[0], point[1], 1, 1); }
function draw(now = lastTime) {
  lastTime = now;
  const idle = !reduced() && !document.hidden && Math.floor(now / 550) % 2 ? 'idle1' : 'idle0';
  const chosenPose = get('pose').value;
  for (const [id, canvas] of Object.entries(shelves)) {
    const ctx = canvas.getContext('2d'); if (!ctx) continue; ctx.clearRect(0, 0, canvas.width, canvas.height);
    indexed(ctx, ART.actors[id].frames[chosenPose === 'loop' ? idle : chosenPose], 0, 0);
    if (guide) { dot(ctx, ART.actors[id].feet, ART.palette[9]); dot(ctx, ART.actors[id].contact, ART.palette[13]); }
  }
  if (!context) return;
  backdrop(context); const placement = pair();
  const study = get('contact-study').checked && !frameState.active;
  const actorPose = study ? 'contact' : frameState.actorPose === 'idle0' ? idle : frameState.actorPose;
  const victimPose = study ? 'hit0' : frameState.victimPose === 'idle0' ? idle : frameState.victimPose;
  indexed(context, placement.victim.frames[victimPose], ...placement.targetOrigin, 'left');
  indexed(context, placement.actor.frames[actorPose], ...placement.origin);
  if (actorPose === 'contact') dot(context, placement.point, ART.palette[13]);
  if (guide) {
    for (let x = 0; x < stage.width; x += 4) { context.fillStyle = ART.palette[9]; context.fillRect(x, 104, 1, 1); }
    const [x, y] = placement.point;
    for (const [dx, dy] of [[-2,0],[-1,0],[0,0],[1,0],[2,0],[0,-2],[0,-1],[0,1],[0,2]]) dot(context, [x+dx,y+dy], ART.palette[13]);
  }
  text('geometry', `Side-view research · native cell 64×48 · ${scale} CSS px/source px · DPR ${devicePixelRatio}. Feet y44. ${selected} ${placement.actor.targetAnchor} contact and mirrored target share (${placement.point.join(', ')}).`);
}
function announce(state) {
  frameState = state;
  text('phase', `${state.phase} · sequence ${state.sequence} · contact callbacks ${contactLog.filter(entry => entry.sequence === state.sequence).length}`);
  draw(performance.now());
}
const timeline = createTimeline({
  onFrame: announce,
  onContact: event => {
    const placement = pair(); contactLog.push({ ...event, point: placement.point, actor: selected, victim: placement.victim.id });
    if (contactLog.length > 16) contactLog.shift();
    text('contact-log', contactLog.map(entry => `#${entry.sequence} ${entry.actor} → ${entry.victim}: (${entry.point.join(',')}), scheduled ${entry.scheduledMs}ms, sampled ${Math.round(entry.observedElapsedMs)}ms`).join('\n'));
    text('phase', `contact · sequence ${event.sequence} · contact callbacks 1`);
  },
  onComplete: result => { text('phase', `Static art result · sequence ${result.sequence} · ${result.contacts} contact callback${result.contacts === 1 ? '' : 's'}. No game damage or rule executed.`); },
});
function stopPump() { if (raf) cancelAnimationFrame(raf); raf = 0; }
function pump(now) {
  raf = 0; if (disposed || document.hidden || reduced()) return;
  timeline.advance(now); if (disposed || document.hidden || reduced()) return;
  draw(now); raf = requestAnimationFrame(pump);
}
function startPump() { if (!raf && !disposed && !document.hidden && !reduced()) raf = requestAnimationFrame(pump); }
function applyScale() {
  for (const canvas of [stage, ...Object.values(shelves)]) { canvas.style.width = `${canvas.width * scale}px`; canvas.style.height = `${canvas.height * scale}px`; }
  text('scale-readout', `${scale}× common integer scale`); draw(performance.now());
}
function motionChange() {
  if (reduced()) { stopPump(); if (timeline.isActive()) timeline.settleStatic('reduced-motion static result'); }
  draw(performance.now()); startPump();
}
listen(get('actor'), 'change', event => { timeline.cancel('actor changed'); selected = event.target.value; draw(performance.now()); });
listen(get('pose'), 'change', () => draw(performance.now()));
listen(get('scale'), 'change', event => { scale = Number(event.target.value); applyScale(); });
listen(get('guides'), 'change', event => { guide = event.target.checked; draw(performance.now()); });
listen(get('contact-study'), 'change', () => {
  timeline.cancel('static contact study changed');
  text('phase', get('contact-study').checked ? 'Static contact drawing · no contact callback or rule event' : 'Idle art study');
  draw(performance.now());
});
listen(get('reduce'), 'change', motionChange); listen(systemMotion, 'change', motionChange);
listen(get('play'), 'click', () => {
  if (disposed || !context) return; get('contact-study').checked = false;
  timeline.start(performance.now(), { reduced: reduced() }); draw(performance.now()); startPump();
});
function cancel() { get('contact-study').checked = false; timeline.cancel('cancelled'); draw(performance.now()); }
listen(get('cancel'), 'click', cancel);
listen(document, 'keydown', event => { if (event.key === 'Escape' && !event.repeat) cancel(); });
listen(document, 'visibilitychange', () => {
  if (document.hidden) { stopPump(); if (timeline.isActive()) timeline.settleStatic('hidden-window static result'); }
  else { draw(performance.now()); startPump(); }
});
function dispose() {
  if (disposed) return; disposed = true; stopPump(); timeline.dispose();
  for (const [target, event, callback] of listeners) target.removeEventListener(event, callback); listeners.length = 0;
  for (const control of document.querySelectorAll('button,input,select')) control.disabled = true;
  text('phase', 'Disposed: animation frame and listeners removed. Static research artwork retained; reload to restart.');
}
listen(get('dispose'), 'click', dispose); listen(window, 'pagehide', dispose);
text('timing', `Authored contact ${CONTACT_MS}ms · attack/recovery 480ms · demo collapse ends ${END_MS}ms. Late samples show contact once before final result.`);
if (!context) { get('play').disabled = true; text('phase', '2D canvas unavailable. Native indexed sheets and readable metadata remain available; animation is unassessed.'); }
applyScale(); startPump();
