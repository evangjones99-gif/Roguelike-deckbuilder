"""One source-only R4 -> opening-r3 staging operation; no build or promotion.

Run under guard-node-phase-r1.py with work64 and reserve512. New stage owns
its source/auxiliary files. Unchanged public assets remain in frozen R4 and
are shared through one explicit symlink; never write through that alias.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

BASE = Path('/dev/shm/hollowpact-owner-tactile-pc-root-r4')
STAGE = Path('/workspace/scratch/first-five-opening-stage-r2')
FREEZE = Path('/workspace/scratch/owner-tactile-pc-r4-runtime-freeze-r1.json')
MAIN = Path('/workspace/scratch/first-five-minute-onboarding-root-author-r3/main.ts')
MAIN_SHA = '19bf2f6886859234da7629e22c34ba8166a7871db22ecf2a928ab49699f2ccfe'
BASE_DIGEST = '27239b7ea537c4694e345a28f8b8ff94dcf0aac4b50394d81396ceecbc9bea8f'
RECEIPT = Path('/workspace/scratch/first-five-opening-assembly-r2.json')
MAXIMUM = int(Path('/sys/fs/cgroup/memory.max').read_text())
INITIAL = int(Path('/sys/fs/cgroup/memory.current').read_text())

def guard():
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    assert MAXIMUM-current >= 512*1048576 and current-INITIAL <= 64*1048576

def read(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME)
    with os.fdopen(fd, 'rb') as f:
        before = os.fstat(f.fileno())
        assert stat.S_ISREG(before.st_mode) and before.st_size <= 8*1048576
        body = f.read()
        assert os.fstat(f.fileno()) == before and path.stat() == before
    guard()
    return body

def digest(body):
    return hashlib.sha256(body).hexdigest()

def runtime_inventory(root):
    result = set()
    for directory in ['src', 'desktop', 'public']:
        for current, names, filenames in os.walk(root/directory, followlinks=False):
            assert all(not (Path(current)/name).is_symlink() for name in names)
            for name in filenames:
                assert not (Path(current)/name).is_symlink()
                result.add((Path(current)/name).relative_to(root).as_posix())
    result.update(['index.html','THIRD-PARTY.md','package.json','package-lock.json',
                   'tsconfig.json','vite.config.ts','scripts/build.mjs'])
    return result

def write(path, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(body); f.flush(); os.fsync(f.fileno())
    guard()

assert sys.argv[1:] == ['--stage-accepted-opening-r3']
assert MAXIMUM-INITIAL >= (64+512)*1048576
assert not STAGE.exists() and not RECEIPT.exists()
freeze_body = read(FREEZE)
assert digest(freeze_body) == 'c6c1974c09d2f17af8560e8a3516adf05c2e384860aa7b9fa2da8d6d67d87eda'
baseline = json.loads(freeze_body)
assert baseline['stage'] == str(BASE) and baseline['sourceDigest'] == BASE_DIGEST
assert len(baseline['inputs']) == baseline['inputCount'] == 87
main = read(MAIN); assert digest(main) == MAIN_SHA
inputs = dict(baseline['inputs'])
assert digest(json.dumps(dict(sorted(inputs.items())), separators=(',', ':')).encode()) == BASE_DIGEST
assert runtime_inventory(BASE) == set(inputs)
for relative, expected in inputs.items():
    assert '..' not in Path(relative).parts and not Path(relative).is_absolute()
    assert digest(read(BASE/relative)) == expected, relative
assert not (BASE/'public').is_symlink()
STAGE.mkdir(mode=0o700)
# Copy compiler configuration, source and test closure, excluding generated
# outputs and dependency/public trees. Each original body remains intact.
auxiliary = {}
for directory, names, filenames in os.walk(BASE, followlinks=False):
    names[:] = sorted(n for n in names if Path(directory)/n not in
                      [BASE/'dist', BASE/'node_modules', BASE/'public'])
    assert all(not (Path(directory)/n).is_symlink() for n in names)
    for name in sorted(filenames):
        source = Path(directory)/name
        relative = source.relative_to(BASE).as_posix()
        body = main if relative == 'src/main.ts' else read(source)
        write(STAGE/relative, body)
        auxiliary[relative] = digest(body)
inputs['src/main.ts'] = MAIN_SHA
assert all(auxiliary[r] == h for r,h in inputs.items() if not r.startswith('public/'))
(STAGE/'public').symlink_to(BASE/'public', target_is_directory=True)
(STAGE/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules', target_is_directory=True)
# Explicitly recheck every shared asset and original input after copying.
for relative, expected in baseline['inputs'].items():
    assert digest(read(BASE/relative)) == expected, relative
assert runtime_inventory(BASE) == set(inputs) == runtime_inventory(STAGE)
assert digest(read(FREEZE)) == digest(freeze_body)
source_digest = digest(json.dumps(dict(sorted(inputs.items())), separators=(',', ':')).encode())
write(RECEIPT, (json.dumps({'status':'SOURCE STAGED; UNBUILT; UNPROMOTED',
    'stage':str(STAGE), 'baselineRuntime':BASE_DIGEST, 'inputs':dict(sorted(inputs.items())),
    'inputCount':len(inputs), 'sourceDigest':source_digest, 'copiedBodies':auxiliary,
    'sharedPublicRoot':str(BASE/'public'), 'mainSHA256':MAIN_SHA,
    'limitations':'No build, output identity, browser, enjoyment or release acceptance. Shared public art must stay immutable.'}, indent=2)+'\n').encode())
for directory in [STAGE, STAGE.parent]:
    fd = os.open(directory, os.O_RDONLY|os.O_DIRECTORY); os.fsync(fd); os.close(fd)
print(json.dumps({'stage':str(STAGE),'sourceDigest':source_digest,'inputs':len(inputs),'built':False}))
