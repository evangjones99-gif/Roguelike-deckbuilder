import os,pathlib,resource,json,hashlib,stat,time,tarfile
resource.setrlimit(resource.RLIMIT_DATA,(25165824,25165824))
C=pathlib.Path('/workspace/Roguelike-deckbuilder/reviews/first-five-pixel-direction-research-2026-10-01-r1')
H=pathlib.Path('/workspace/scratch/standard-sol-first-five-pixel-preservation-independent-r2')
samples=[];base=None
def guard():
 global base
 c=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());m=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
 if base is None:base=c
 v={'time_ns':time.time_ns(),'current':c,'max':m,'headroom':m-c,'workDelta':max(0,c-base)};samples.append(v);assert m-c>=562036736,v;assert c-base<=25165824,v;return v
def meta(s):return {k:getattr(s,k)for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}
def read(p,cap=262144):
 guard();f=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  s=os.fstat(f);assert stat.S_ISREG(s.st_mode) and s.st_size<=cap;b=b''
  while x:=os.read(f,65536):b+=x
  assert s==os.fstat(f)==os.stat(p,follow_symlinks=False);return b,s
 finally:os.close(f)
def save(p,b):
 guard();f=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  view=memoryview(b)
  while view:view=view[os.write(f,view):]
  os.fsync(f)
 finally:os.close(f)
def dump(v):return (json.dumps(v,indent=2)+'\n').encode()
guard();assert os.statvfs(C).f_bavail*os.statvfs(C).f_frsize>1048576;H.mkdir(mode=0o700)
b,s=read(C/'PRESERVATION.json');p=json.loads(b);save(H/'PRESERVATION-COPY.json',b);controls=[{'path':str(C/'PRESERVATION.json'),'sha256':hashlib.sha256(b).hexdigest(),'metadata':meta(s)}]
b,s=read(C/'OUTCOME.md');save(H/'OUTCOME-COPY.md',b);controls.append({'path':str(C/'OUTCOME.md'),'sha256':hashlib.sha256(b).hexdigest(),'metadata':meta(s)})
assert p['bytes']==3391068 and p['sha256']=='afc305fb0b4df338f2e064c3efb6f78ca2e8e69bf67dbcd209a77ac966f76f22'
entries={r['member']:r for r in p['files']};assert len(entries)==len(p['files'])==186
a=C/'EVIDENCE.tar.gz';fd=os.open(a,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);archive=os.fdopen(fd,'rb',closefd=True);rows=[];seen=set();total=0
try:
 s=os.fstat(archive.fileno());assert stat.S_ISREG(s.st_mode) and s.st_size==p['bytes'];raw=hashlib.sha256()
 while x:=archive.read(65536):guard();raw.update(x)
 assert raw.hexdigest()==p['sha256'];archive.seek(0)
 with tarfile.open(fileobj=archive,mode='r|gz') as t:
  for member in t:
   guard();name=member.name;assert member.isfile() and name not in seen and name in entries;assert not name.startswith('/') and '..' not in name.split('/');seen.add(name);row=entries[name]
   assert member.size==row['bytes'] and 0<=member.size<=4194304;assert row['original']=='/'+name
   original=pathlib.Path(row['original']);of=os.open(original,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);ext=t.extractfile(member);assert ext is not None;digest=hashlib.sha256();n=0
   try:
    before=os.fstat(of);assert stat.S_ISREG(before.st_mode) and before.st_size==row['bytes']
    while x:=ext.read(65536):
     guard();y=os.read(of,len(x));assert x==y,(name,n);digest.update(x);n+=len(x)
    assert os.read(of,1)==b'' and n==row['bytes'] and digest.hexdigest()==row['sha256'];assert before==os.fstat(of)==os.stat(original,follow_symlinks=False)
   finally:ext.close();os.close(of)
   total+=n;assert total<=8388608;rows.append({'member':name,'original':str(original),'bytes':n,'sha256':digest.hexdigest(),'metadata':meta(before),'tarMetadata':{'mode':member.mode,'uid':member.uid,'gid':member.gid,'mtime':member.mtime,'pax':member.pax_headers}})
 assert seen==set(entries);assert s==os.fstat(archive.fileno())==os.stat(a,follow_symlinks=False);controls.append({'path':str(a),'sha256':raw.hexdigest(),'metadata':meta(s)})
finally:archive.close()
save(H/'BYTE-RESULT.json',dump({'status':'ALL_186_BYTE_CHECKS_PASS','archiveSHA256':p['sha256'],'archiveBytes':p['bytes'],'members':len(seen),'bodyBytes':total,'allArchiveFDsClosed':True,'inputs':controls,'memberOriginalMetadata':rows,'samples':samples,'final':guard()}))
roots=sorted(set('/'.join(r['original'].split('/')[:4])for r in p['files']));coverage=[]
def list_regular(root):
 result=set();stack=[pathlib.Path(root)]
 while stack:
  d=stack.pop();f=os.open(d,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME)
  try:
   for name in os.listdir(f):
    s=os.stat(name,dir_fd=f,follow_symlinks=False);q=d/name
    if stat.S_ISDIR(s.st_mode):stack.append(q)
    else:assert stat.S_ISREG(s.st_mode),str(q);result.add(str(q))
  finally:os.close(f)
 return result
for root in roots:
 guard();actual=list_regular(root);mapped={r['original']for r in p['files']if r['original'].startswith(root+'/')};assert actual==mapped,(root,sorted(actual-mapped),sorted(mapped-actual));coverage.append({'root':root,'regularCount':len(actual),'completeRegularBodies':True})
save(H/'ARCHIVE-RESULT.json',dump({'verdict':'BYTE_AND_LIST_PRESERVATION_PASS','archiveSHA256':p['sha256'],'archiveBytes':p['bytes'],'members':len(seen),'uncompressedBodyBytes':total,'allMemberBytesEqualRetainedOriginals':True,'allHashesAndLengthsMatchMap':True,'duplicatesLinksUnknownMembers':False,'allMappedSourceDirectoryRegularBodiesCovered':coverage,'inputs':controls,'memberOriginalMetadata':rows,'ownArchiveAndSourceFDsClosed':True,'visualInspection':False,'sourceQualityAcceptance':False,'qualification':'No complete runtime/art capsule claim; only named original source directories and exact mapped bodies. Other external execution helpers not claimed included. Tar metadata observed; no exact original inode/atime restoration claim. Initial ordinary directory list intake did not freeze parent-directory metadata.','samples':samples,'final':guard()}))
print(json.dumps({'packet':str(H),'archiveMembers':len(seen),'archiveBytes':p['bytes'],'bodyBytes':total,'sourceRoots':len(roots),'final':guard(),'ownArchiveAndSourceFDsClosed':True}))
