# Independent preservation and direction review
Verdict: ACCEPT the named archive's byte/list preservation and the corrected current-direction documentation. This is not staged-code, runtime, visual-art, native-release or human-fun acceptance.

Archive: reviews/first-five-pixel-direction-research-2026-10-01-r1/EVIDENCE.tar.gz
Exact size: 3,391,068 bytes.
SHA256: afc305fb0b4df338f2e064c3efb6f78ca2e8e69bf67dbcd209a77ac966f76f22.
Actual regular members: 186, totaling 5,835,878 uncompressed body bytes.

Every member was streamed and compared byte for byte with its retained original, then checked against PRESERVATION.json length/SHA256. Member names are unique, map-complete, safe relative paths and regular files; no linked/unknown/duplicate members were admitted. All 12 named original source directories have complete regular-body enumeration matching the map. Archive/map/original before-after FD/path identities were unchanged during the check. Original FD metadata and tar metadata are recorded; this does not promise restoration of original inode/atime or include unrelated external helpers/profiles/builds.

R1/r2 onboarding source and rejections, r3 source acceptance, framework primary-source copies and acquisition limitations, pixel research inputs, and source/visual findings remain. Current source-only status and qualified rejection are preserved rather than converted into playable success. The archive itself and every original remain unchanged.

Current AGENTS, FIRST-FIVE-MINUTES, PRODUCTION, AAA-CRAFT-REVIEW and the new CONTINUATION prefix record the newer PC/pixel/keep-JS/first-300-seconds direction. PRODUCTION initially appended the new priority below historical material while calling that material “below”; ROOT moved the same block to the top before this final documentation check. The first-five-minute loop is an intended product goal, not a universal proven formula or a player deadline.

The near-allied/far-hostile view, authored rear three-quarter allies, pixel silhouettes and arrival/READY/command/contact/recovery are explicitly intended presentation. They are not claimed to exist in the accepted playable build. Rejected first sprites and unbuilt/uninstalled opening r3 remain qualified; ROOT game 801db and latest sealed 0.8 are not promoted by research. Human fun, AAA/Steam readiness and native shipping remain unproved. Actual prompt readback evidence is retained, but automation configuration does not prove future execution.

Independence qualification: this reviewer did not author the preservation sealer or ROOT direction changes, but contributed the archived framework research and earlier independent onboarding reviews. The review verifies byte/list/direction claims independently; it is not a fresh independent endorsement of the reviewer's own research or of new staged code.

A reviewer-method failure is preserved: the first helper passed its streaming comparisons but then derived directory roots including a filename and raised NotADirectoryError before publishing its complete ledger. No acceptance was taken from that failed run. The original helper and partial packet remain. A distinct corrected helper performed a fresh full bounded verification, published a byte-check checkpoint before directory enumeration, and passed. This was a source review method repair, not a retry of any coverage/cache/retirement operation.

The completed audit used fresh source-only 24 MiB work and 512 MiB reserve admission, live sampled current-memory delta checks and O_NOATIME bounded reads. All archive/source FDs closed. Sealer wrapper32+512 PASS is parent intake, not independently re-audited here; this review's own guarded result establishes its reported preservation check. No Node/browser/Git/build or archive-retirement action occurred. CONTINUATION was read only through its current prefix; the full historical document was not re-reviewed.
