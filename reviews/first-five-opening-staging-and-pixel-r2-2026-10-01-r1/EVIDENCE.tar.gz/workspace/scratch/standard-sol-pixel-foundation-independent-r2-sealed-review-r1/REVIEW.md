# Independent pixel anatomy r2 review

**R2 visibly improves the rejected r1 anatomy. Keep it as a reference for the next original perspective study; do not select it as game art yet.** The hound now reads as canine, the hunter's cleaver differs from the skeleton's spear, and deaths retain folded body mass. I reject the current static contact compositions as final combat presentation: crossing limbs/weapons obscure target anatomy, and the hound's open mouth is less clear than its overall canine silhouette. No rear/front view, binding arrival, READY/command payoff or actual motion is supplied.

This judgment follows personal inspection of the untouched native sheets and the author's original 3× static compositions, compared with the retained rejected r1 native sheets. It is not a browser capture, runtime pass or first-five-minute enjoyment claim.

## Exact scope

Author freeze: /workspace/scratch/standard-sol-pixel-foundation-author-r2/MANIFEST.json SHA256 b20d27a609a5209cc1773e7f67ccaeb1139a22bd644412f78cf9818074a3e2b6, 22 bodies /244,902 bytes. Read the seal first, independently verified every named length/hash, then read source and viewed assets. AUDIT-BEFORE.json records all22 matching. Original r1 manifest remains ee2d57c54d509c13979719dbf3ddb10e3e7700527757014b9703a0cf06529f53.

Fresh source admission passed:603,283,456-byte headroom against24MiB work+512MiB reserve requirement562,036,736. No Node, browser, server, JavaScript evaluation, build, Git or author/export script execution by this reviewer. No game/author/art edits or image transformation. This makes no claim about global process absence or another agent's work. Native view_image does not expose O_NOATIME; hash/source/PNG-decode reads used it, while image-view access timestamps cannot be promised unchanged.

The suggested own destination already existed. mkdir(exist_ok=False) refused before admission/author reads or file writes, so I created this new distinct packet and preserved METHOD-PATH-REFUSAL.txt. The first independent PNG-analysis script had a Python parse error ('else0'); no analysis ran. Corrected it to 'else 0' and preserved ANALYSIS-SYNTAX-FAILURE.txt. Only the successful decode supplies findings.

Read README, masks, author/export source sections, HTML/CSS, full lab/timeline source and differences from r1. Personally viewed r2 hunter, hound and skeleton256×192 native sheets, both final and pre-layer672×1152 authored3× contact compositions, and r1's three native sheets. Those8 inspections are static original assets, not actual browser painting, movement or compositing over the game.

## Improved and still unresolved

| Area | Visible improvement over r1 | Remaining condition |
| --- | --- | --- |
| Hound anatomy | Connected chest/shoulder, rounded haunch, belly tuck, bent support legs and substantial paws; short ear and muzzle replace antlers | Several similar round slate patches give a boulder/armored-mechanical impression. Neck-to-head transition and open lower jaw need clearer negative space and directional weight. |
| Hunter identity | Broad split coat, heavier boots and a broad cleaver; clearer loaded/cutting pose category | Hood/torso still simple and upright. The upper-body load and return should be judged in motion; broad contact blade overlaps the target ribcage. |
| Skeleton identity | Skull/rib cavity, angular pelvis and narrow spear differ from the clothed hunter/cleaver | Thin limbs and horizontal thrust remain schematic. Distinct spear depth and target-facing body orientation are pending. |
| Deaths | Kneeling/curling support and raised shoulder/hip/skull masses replace uniform flattened bars | Final body silhouettes remain very compact and partly merged; motion must make the support loss legible rather than popping between low shapes. |
| Contrast | Quieter dark floor and colder, brighter hound clusters separate it better from the background | Quiet lab tile is a useful test surface, not a finished courtyard; darker recesses can still merge. Future scene lighting must preserve feet, jaws and equipment. |
| Contact ownership | Final striker-front ordering restores the hunter blade/hound jaw/skeleton spear that the pre-layer composition obscured | Always putting a whole striker in front is a lab convention, not a general near/far depth solution. It can trade a hidden weapon for a hidden target. |

The hound no longer has the obvious ungulate/insect reading that caused my r1 rejection. That is a real visible correction, not merely recoloring. Its now canine silhouette is suitable to inform the next perspective drawing. I would still refine the contact jaw: in the enlarged middle composition, the forward head/mouth and target legs form a busy small area; chest/haunch mass is easier to read than the bite. Separate an unmistakable upper muzzle, dark mouth opening and lower mandible with a plausible neck line. Do not add antlers or excessive glowing detail to compensate.

The hunter cleaver has a broad vertical cutting head; the enemy spear is a long narrow thrust. That corrects the shared-hook identity problem. In the top contact composition, the blade overlaps much of the near target torso. In the bottom composition, forearm/spear lines pass through the hunter's extended area. These examples prove the drawings can share a source contact coordinate, but not that a player can instantly distinguish both actors and the actual hit. Preserve the target head and sufficient torso contour; choose contact/depth placement from the actual action and formation. Avoid making contact a long ambiguous pile of limbs.

The r2 static composition is much simpler and more consistent than the high-resolution generated concept: fixed pixel clusters, shared palette and no blur/reflection noise. It loses that concept's rich world material/depth. That is a deliberate study tradeoff, not evidence one overall game art direction is accepted. A well-composed native-resolution environment and live tactical UI still need to carry the final world identity.

## Independent source/asset checks

ASSET-ANALYSIS.json records successful read-only PNG decoding and source comparison. All three native sheets are8-bit indexed PNGs with binary transparency: transparent0 plus13 fully opaque palette entries. Every pixel, palette and published frame bound matches sprites.js; all14 frames per actor differ. The palette itself is unchanged from r1, while actual anatomy masks changed. The final672×1152 contact-study PNG has constant3×3 blocks throughout, confirming this authored export is a literal integer expansion. This does not prove fractional-DPR browser behavior or animation.

Opaque union bounds, right/bottom exclusive: hunter[8,4,64,45], hound[1,13,64,44], skeleton[13,3,64,45]. Shared cells remain64×48; at3× full cells are192×144 and union widths168/189/153px. Contact endpoints now contain steel/bone source indices rather than only the amber marker; the lab adds the small common amber impact point. Source arms/jaws/weapons genuinely change shape. Complete full-pose extents, asymmetric pivots and collision/readout ownership still require actual adapter measurement.

The existing game hunter gap of152px must not be assumed to hold this168px hunter union at3×. Its extent is asymmetric around feet/root, so even a nominal168px region is not a complete proof. Do not crop death/weapon poses or independently stretch actors to fit. The next geometry/perspective study can choose a new coherent scale/cell, but it must disclose how complete drawing bounds coexist with actual readout and input space.

The prior live-region source issue is repaired: lab.js text(id,value) compares current text before assigning, and phase/geometry/contact-log/status paths now use that helper. An unchanged phase message will therefore avoid repeated identical textContent writes across RAF samples. This is source verification; actual screen-reader output remains untested. Meaningful phase/count changes can still announce and should remain concise.

timeline.js differs from r1 only by removing a comment;240ms contact,480ms attack/recovery,760ms synthetic collapse, contactDelivered guard, revision/reentrancy checks, cancellation, static reduced-motion and disposal semantics are unchanged. Lab code adds a public static-contact-study checkbox, default hound selection and striker-front painting. Play clears the static checkbox; Cancel/Escape clears it and resets. Static study itself emits no new contact callback. These are bounded source properties, not executed lifecycle tests.

The unconditional victim collapse remains explicitly synthetic. Do not use it as a rule for real game hits. No binding/arrival/READY lifecycle, actual card selection/drag, engine reducer, save/reload, legal command, audio or terminal gameplay is supplied. The side view is accurately labelled; a mirror is not rear-three-quarter or frontal anatomy.

## Priorities for the next original rear/front study

1. Draw a real near-side rear-three-quarter hound: rump/tail and near hind paw establish depth, shoulders narrow into a visible far head/muzzle, two sides have deliberate different overlap. Keep the jaw/contact direction visible from the player's angle. Do not paste or mirror the side sprite and rename it.
2. Draw a far-side front/three-quarter skeletal foe with skull sockets, rib cavity, pelvis and spear grip/shaft depth. Its threat must be readable toward the player; avoid a narrow sideways line substituted for a frontal pose.
3. Keep hunter identity readable at the flank without stealing the hound's reveal or blocking the near-side cards/readouts. Use measured full-pose bounds and actual art origins, not only64×48 transparent-cell rectangles.
4. Use a quiet floor band and a visible foot/support plane. Grounded overlaps and contact point should distinguish foreground actor and background target while retaining each head/torso silhouette.
5. Include genuine live labels and three representative bottom cards in any scene study. Preserve essential intent number/type/target, names and complete stat/Inspect access at readable size. Own slot/readout linkage must be obvious; do not inflate art presence by omitting tactical information or by turning the field into multiple concealed screens.
6. A labelled synthetic binding→READY→command study may inspect sequence/art timing, but must not impersonate legal game actions or earned state. Actual first binding, command and first300 seconds require a later frozen game stage and independent real play.

These are critique/art-direction constraints, not my implementation or acceptance of the author's future r3. The author retains code/art ownership; I remain rejection-capable.

## Small actual review still pending

No runtime window was granted. The retained r1 small plan stays unexecuted. A future r2 phase can be smaller because static contact is public: at1440×900/DPR1 normal motion inspect default hound3×, toggle static contact and one alternate actor, then play one actual lab sequence and try native Escape before contact. Record real timestamps/counts/captures, close under unchanged640MiB work+512MiB reserve guard. Only if useful/admitted extend to reduced motion, native focus and disposal in a fresh short phase. These are lab checks, not gameplay. Do not warm the full game or run a mobile matrix for this side-view study.

The appropriate next step is the original perspective/readout study using improved r2 anatomy, followed by actual inspected paint and a real opening game slice. R2 can be retained as the improved side-view research reference. No game promotion, palette-wide accessibility certification, human enjoyment, AAA claim or retirement decision follows.
