// Actual synchronous presentation contract checks; no browser or game play.
import assert from 'node:assert/strict';
import { createTimeline } from './standard-sol-pixel-foundation-author-r2/timeline.js';
const passed=[];
function check(name, fn) { fn(); passed.push(name); }
check('one contact despite repeated samples; complete once',()=>{
  const contacts=[],complete=[];
  const t=createTimeline({onContact:x=>contacts.push(x),onComplete:x=>complete.push(x)});
  t.start(100);t.advance(339);assert.equal(contacts.length,0);
  t.advance(340);t.advance(341);t.advance(860);t.advance(900);
  assert.equal(contacts.length,1);assert.equal(complete.length,1);
  assert.equal(t.getState().phase,'complete');assert.equal(t.isActive(),false);
});
check('late sample shows contact pair before settlement',()=>{
  const contacts=[];const t=createTimeline({onContact:x=>contacts.push(x)});
  t.start(0);t.advance(2000);
  assert.equal(t.getState().actorPose,'contact');assert.equal(t.getState().victimPose,'hit0');
  assert.equal(contacts.length,1);assert.equal(contacts[0].observedElapsedMs,2000);
  t.advance(2001);assert.equal(t.getState().phase,'complete');assert.equal(contacts.length,1);
});
check('cancel before contact prevents stale delivery',()=>{
  let contacts=0;const t=createTimeline({onContact:()=>contacts++});
  t.start(0);t.advance(200);t.cancel();t.advance(1000);
  assert.equal(contacts,0);assert.equal(t.isActive(),false);assert.equal(t.getState().actorPose,'idle0');
});
check('restart within contact callback preserves new sequence',()=>{
  let contacts=0;let t;
  t=createTimeline({onContact:()=>{contacts++;if(contacts===1)t.start(300);}});
  t.start(0);t.advance(240);assert.equal(t.getState().elapsed,0);
  t.advance(539);assert.equal(contacts,1);t.advance(540);assert.equal(contacts,2);
});
check('frame callback cancellation prevents contact callback',()=>{
  let contacts=0;let t;
  t=createTimeline({onFrame:s=>{if(s.phase==='contact')t.cancel();},onContact:()=>contacts++});
  t.start(0);t.advance(240);assert.equal(contacts,0);assert.equal(t.isActive(),false);
});
check('reduced motion has static result and no timed contact',()=>{
  let contacts=0,complete=0;const t=createTimeline({onContact:()=>contacts++,onComplete:()=>complete++});
  t.start(0,{reduced:true});t.advance(1000);
  assert.equal(contacts,0);assert.equal(complete,1);assert.equal(t.getState().phase,'static result');
});
check('dispose prevents restart and later callbacks',()=>{
  let contacts=0;const t=createTimeline({onContact:()=>contacts++});
  t.start(0);t.dispose();t.advance(1000);
  assert.equal(t.start(2000),false);assert.equal(contacts,0);assert.equal(t.isDisposed(),true);
});
console.log(JSON.stringify({passed,scope:'Actual Node presentation timeline only; no browser paint, animation feel, game outcome, human fun or platform qualification.'},null,2));
