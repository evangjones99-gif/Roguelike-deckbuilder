import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';import path from 'node:path';import {pathToFileURL} from 'node:url';
const repo='/workspace/Roguelike-deckbuilder';const pkg=repo+'/node_modules/@electron/asar/lib';const {getRawHeader,extractFile}=await import(pathToFileURL(pkg+'/asar.js'));
const originalSource=fs.readFileSync(pkg+'/filesystem.js','utf8');
const qualified=originalSource.replace("import path from 'node:path';","import nativePath from 'node:path'; const path=nativePath.win32;").replace("from './integrity.js'",`from '${pathToFileURL(pkg+'/integrity.js').href}'`).replace("from './wrapped-fs.js'",`from '${pathToFileURL(pkg+'/wrapped-fs.js').href}'`);
assert.notEqual(qualified,originalSource);
const {Filesystem}=await import('data:text/javascript;base64,'+Buffer.from(qualified).toString('base64'));
const asar='/tmp/hollowpact-native-v07/windows-native/win-unpacked/resources/app.asar';const bytes=fs.readFileSync(asar);const sha=b=>crypto.createHash('sha256').update(b).digest('hex');assert.equal(sha(bytes),'e270b1fc9626f6df915449200d00f86cd593e3ca70876832436dd90ef7e6d3da');
const raw=getRawHeader(asar);const cases=[];
for(const name of ['dist/build-provenance.json','dist/art/hunter-marek-v07-r3.png',path.win32.join('dist','art','hunter-marek-v07-r3.png')]){
 const f=new Filesystem('C:\\qualified-header-only\\app.asar');f.setHeader(structuredClone(raw.header),raw.headerSize);try{const info=f.getFile(name);cases.push({name,found:true,size:info.size});}catch(e){cases.push({name,found:false,error:e.message});}
}
assert.equal(cases[0].found,true);assert.equal(cases[1].found,false);assert.equal(cases[2].found,true);
const png=extractFile(asar,'dist/art/hunter-marek-v07-r3.png');assert.equal(sha(png),'4492577d3bacc868e9b66da0abf25915bdeaf68bc8f5c31ae8a1d8db485f3c53');assert.equal(png.length,cases[2].size);
const result={scope:'Linux execution of actual installed ASAR traversal source with ONLY Windows path library substituted; actual retained Windows ASAR/header; no Windows process or installer execution',asarSHA256:sha(bytes),filesystemSourceSHA256:sha(originalSource),windowsLibrary:path.win32.sep,cases,actualHunterBytes:png.length,actualHunterSHA256:sha(png),minimalProposedFix:"path.join('dist','art','hunter-marek-v07-r3.png')"};
fs.writeFileSync('/workspace/scratch/installer-native-independent-run-36803389350/asar-windows-path-diagnostic.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result,null,2));
