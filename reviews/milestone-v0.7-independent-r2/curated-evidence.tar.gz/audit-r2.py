"""Independent read-only audit. Invoke only AFTER root's final seal signal."""
import pathlib,sys,hashlib,json,zipfile,tarfile,subprocess,struct,io,time,gzip
ROOT=pathlib.Path('/workspace/Roguelike-deckbuilder'); OUT=pathlib.Path(__file__).parent
COMMIT='fdb43bd2e2833e2460ffc3776071b9ed82ad79cc';DIGEST='0be4f01d416e6fc4cca3f19b6916b5b65993b9fd426a926a1ede6d8487834a35'
ASAR='e270b1fc9626f6df915449200d00f86cd593e3ca70876832436dd90ef7e6d3da';WIN='256babeb74761b0608ae8be249f30f475522c70f86c0fd377f1bef737fb35fbe'
RELEASE=ROOT/'releases/0.7.0';R={'status':'running','scope':'Independent sealed artifact/source/old milestone audit, no fresh gameplay/native launch','steps':[]}
def checked(c,m):
 if not c:raise AssertionError(m)
def hread(stream,size=None,blob=None):
 sha=hashlib.sha256(); git=hashlib.sha1(('blob '+str(size)+'\0').encode()) if blob else None;n=0
 while b:=stream.read(1024*1024):
  n+=len(b);sha.update(b)
  if git:git.update(b)
 checked(size is None or n==size,'Stream size mismatch')
 if git:checked(git.hexdigest()==blob,'Git blob mismatch')
 return {'bytes':n,'sha256':sha.hexdigest()}
def hfile(p):
 with open(p,'rb') as f:return hread(f,p.stat().st_size)
def git(args):return subprocess.check_output(['git',*args],cwd=ROOT)
def tree(commit,prefix=None):
 args=['ls-tree','-rz',commit]
 if prefix:args+=['--',prefix]
 result={}
 for row in git(args).split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();checked(kind=='blob','Non-blob tree item');
  result[name.decode()]={'mode':mode,'gitBlob':oid}
 return result
def safe_zip(z):
 infos=z.infolist();names=[i.filename for i in infos];checked(len(names)==len(set(names)),'Duplicate ZIP entry')
 for i in infos:
  p=pathlib.PurePosixPath(i.filename);checked(not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and ':' not in i.filename,'Unsafe ZIP path')
 return infos
def asar_payload(data,expected):
 checked(hashlib.sha256(data).hexdigest()==ASAR,'ASAR SHA mismatch'); checked(len(data)<64*1024*1024,'Unexpected ASAR size')
 header_size=struct.unpack('<I',data[4:8])[0];string_size=struct.unpack('<I',data[12:16])[0]
 header=json.loads(data[16:16+string_size]);base=8+header_size;leaves={}
 def visit(node,prefix=''):
  for name,item in node['files'].items():
   checked('/' not in name and '\\' not in name and name not in ['.','..'],'Unsafe ASAR member')
   p=prefix+name
   if 'files' in item:visit(item,p+'/');continue
   checked(not item.get('unpacked') and 'link' not in item,'Unexpected unpacked/link ASAR member')
   start=base+int(item['offset']);end=start+item['size'];checked(base<=start<=end<=len(data),'ASAR range')
   b=data[start:end];leaves[p]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
   if p=='dist/build-provenance.json':checked(json.loads(b)==expected,'ASAR provenance differs from release web')
   elif p=='package.json':
    package=json.loads(b);checked(package['version']=='0.7.0' and package['main']=='desktop/main.cjs','Wrong ASAR package')
   if p.startswith('dist/') or p.startswith('desktop/'):
    relative=p[5:] if p.startswith('dist/') else p
    original=RELEASE/'web'/relative if p.startswith('dist/') else ROOT/relative
    checked(leaves[p]==hfile(original),'ASAR payload/current web or desktop mismatch '+p)
  return leaves
 visit(header);checked(len(leaves)==18,'Unexpected ASAR leaf count');return leaves
if sys.argv[1:]!=['--sealed']:raise SystemExit('Must wait explicit root seal signal, then pass --sealed')
try:
 checked(not (RELEASE/'INCOMPLETE.txt').exists(),'Incomplete release')
 manifest=json.loads((RELEASE/'manifest.json').read_text());R['manifest']=manifest
 checked(manifest['sourceCommit']==COMMIT and manifest['runtimeSourceDigest']==DIGEST,'Wrong release source/runtime')
 checked(manifest['status']=='development-prerelease' and manifest['steamPublished'] is False,'Mislabelled release')
 checked(len(manifest['artifacts'])==5,'Expected exactly five final archives')
 sums={}
 for line in (RELEASE/'SHA256SUMS').read_text().splitlines():
  sha,name=line.split('  ',1);checked(name not in sums and '/' not in name,'Duplicate/unsafe SHA entry');sums[name]=sha
 checked(sums==manifest['artifacts'],'SHA sums/manifest differ')
 checked(set(sums)=={p.name for p in RELEASE.iterdir() if p.name.endswith(('.zip','.tar.gz'))},'Unlisted archives')
 R['metadataBefore']={str(p.relative_to(RELEASE)):hfile(p) for p in [RELEASE/'manifest.json',RELEASE/'SHA256SUMS',RELEASE/'reviews/INDEX.json']}
 R['archives']={}
 for name,sha in sums.items():
  print('Hashing sealed archive',name,flush=True);record=hfile(RELEASE/name);checked(record['sha256']==sha,'Archive SHA mismatch '+name);R['archives'][name]=record
 webzip=next(name for name in sums if name.endswith('-web.zip'));webfiles={}
 with zipfile.ZipFile(RELEASE/webzip) as z:
  for item in safe_zip(z):
   if item.is_dir():continue
   checked(item.filename.startswith('dist/'),'Web archive unexpected prefix')
   with z.open(item) as f:record=hread(f,item.file_size)
   checked(record==hfile(RELEASE/'web'/item.filename[5:]),'Web archive differs from preserved web '+item.filename)
   webfiles[item.filename]=record
 checked(len(webfiles)==15,'Expected15 web distribution files (17 includes desktop)')
 runtime=json.loads((RELEASE/'web/build-provenance.json').read_text());checked(runtime['version']=='0.7.0' and runtime['sourceDigest']==DIGEST and len(runtime['hashes'])==29,'Wrong web provenance')
 checked(hashlib.sha256(json.dumps(runtime['hashes'],separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==DIGEST,'Provenance digest mismatch')
 current={p:hfile(ROOT/p)['sha256'] for p in runtime['hashes']};checked(current==runtime['hashes'],'Current raw runtime source differs');R['runtime']={'version':'0.7.0','sourceDigest':DIGEST,'inputs':29,'webFiles':len(webfiles)}
 prior=json.loads((OUT/'result-r1.json').read_text())
 checked(prior['manifest']==manifest and prior['metadataBefore']==R['metadataBefore'],'Prior source-check identity changed')
 checked(prior['archives']==R['archives'],'Prior source-check exact archive bytes changed')
 checked(prior['source']['allGitBlobsAndReviewIndexMatch'],'Prior source checks did not finish')
 R['source']=prior['source'];R['source']['executionQualification']='Full3433 Git blob/3141 INDEX/5 lossless pairs actually executed in r1 before exact-current native receipt selector failed; r2 rehashes five exact unchanged archives and metadata, reruns affected remaining native/Linux/old-milestone checks only.'
 windows=next(name for name in sums if 'windows-native' in name and 'evidence' not in name)
 checked(R['archives'][windows]['sha256']==WIN and R['archives'][windows]['bytes']==185715968,'Not original Windows native ZIP')
 nativefiles={};windowsasar=None
 with zipfile.ZipFile(RELEASE/windows) as z:
  for item in safe_zip(z):
   if item.is_dir():continue
   with z.open(item) as f:
    if item.filename=='resources/app.asar':windowsasar=f.read();record={'bytes':len(windowsasar),'sha256':hashlib.sha256(windowsasar).hexdigest()}
    else:record=hread(f,item.file_size)
   nativefiles[item.filename]=record
 checked(len(nativefiles)==72 and len({p.casefold() for p in nativefiles})==72,'Windows count/case collision')
 evidencezip=next(name for name in sums if 'evidence' in name);evidenceentries={};native_smoke=[];native_package=[]
 with zipfile.ZipFile(RELEASE/evidencezip) as z:
  for item in safe_zip(z):
   if item.is_dir():continue
   with z.open(item) as f:b=f.read() if item.file_size<16*1024*1024 else None
   if b is None:
    with z.open(item) as f:record=hread(f,item.file_size)
   else:record={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
   evidenceentries[item.filename]=record
   if item.filename=='reviews/windows-native/0.7.0/run-36797759232-1/smoke.json':native_smoke.append(json.loads(b.decode('utf-8-sig')))
   if item.filename=='reviews/windows-native/0.7.0/run-36797759232-1/native-package.json':native_package.append(json.loads(b.decode('utf-8-sig')))
 checked(len(native_smoke)==1 and len(native_package)==1,'Missing/ambiguous original native evidence')
 smoke=native_smoke[0];package=native_package[0]
 checked(smoke['status']=='passed' and smoke['runtimeSourceDigest']==DIGEST and smoke['asarSHA256']==ASAR,'Wrong native smoke')
 checked(smoke['packageFiles']=={p:r['sha256'] for p,r in nativefiles.items()},'Windows bytes differ from original native CI')
 checked(package['archiveSHA256']==WIN and package['runId']=='36797759232' and package['signatureStatus']=='NotSigned','Wrong native ZIP receipt')
 checked(package['commit']=='debf73893c4e1d9acc163784a425bb0c12492ec4','Wrong actual CI checkout')
 checked(manifest['nativeWindows']['actualPRMergeCheckout']==package['commit'] and manifest['nativeWindows']['runId']==int(package['runId']) and manifest['nativeWindows']['originalArchiveSHA256']==WIN and manifest['nativeWindows']['originalEvidenceSHA256']==R['archives'][evidencezip]['sha256'],'Native manifest identity differs from original receipt')
 checked(len(smoke['steps'])==13 and len(smoke['hunterFigure']['draws'])==8,'Original native phase/draw count differs from declared qualification')
 leaves=asar_payload(windowsasar,runtime)
 R['windows']={'archive':windows,'files':72,'originalRun':'36797759232','actualCICheckout':package['commit'],'actualCIReportedStatus':smoke['status'],'unsigned':package['signatureStatus'],'asarSHA256':ASAR,'leafFiles':len(leaves),'all72CIFileHashesMatch':True,'all17WebDesktopPayloadsMatch':True,'newNativeLaunchPerformed':False}
 linux=next(name for name in sums if name.endswith('-linux-x64.tar.gz'));linuxfiles={};linuxasar=None
 with tarfile.open(RELEASE/linux,'r|gz') as t:
  for item in t:
   if item.isdir():continue
   checked(item.isfile() and not item.issym() and not item.islnk(),'Unexpected Linux archive link/special entry')
   name=item.name.removeprefix('./');checked(name not in linuxfiles and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts,'Unsafe/duplicate Linux entry')
   with t.extractfile(item) as f:
    if name=='resources/app.asar':linuxasar=f.read();record={'bytes':len(linuxasar),'sha256':hashlib.sha256(linuxasar).hexdigest()}
    else:record=hread(f,item.size)
   record['mode']=oct(item.mode);linuxfiles[name]=record
 checked(len(linuxfiles)==74,'Expected74 Linux files');checked(windowsasar==linuxasar,'Cross-platform ASAR byte mismatch');asar_payload(linuxasar,runtime)
 preserved=ROOT/'reviews/hunter-v0.7-linux-packaged-r2';receipt=json.loads((preserved/'PRESERVATION.json').read_text())
 checked(hfile(preserved/receipt['archive'])=={'bytes':receipt['archiveBytes'],'sha256':receipt['archiveSHA256']},'Canonical actual-executed Linux evidence bundle hash')
 with tarfile.open(preserved/receipt['archive']) as t:reference=json.load(t.extractfile('package-identity.json'))
 checked(reference['packagedFiles']=={p:r['sha256'] for p,r in linuxfiles.items()},'Linux bytes differ from actual independent executed package')
 checked(int(linuxfiles['hollowpact']['mode'],8)&0o111,'Linux executable lacks execution mode')
 checked(int(linuxfiles['chrome-sandbox']['mode'],8)&0o4000,'Linux sandbox helper setuid mode lost')
 R['linux']={'archive':linux,'files':74,'asarSHA256':ASAR,'all17WebDesktopPayloadsMatch':True,'all74FileHashesMatchPreviouslyExecutedIndependentPackage':True,'executableMode':linuxfiles['hollowpact']['mode'],'sandboxMode':linuxfiles['chrome-sandbox']['mode'],'newNativeLaunchPerformed':False}
 # All older sealed archive bytes are streamed against retained original SHA ledgers.
 old=[]
 for ledger in sorted((ROOT/'releases').glob('*/SHA256SUMS')):
  if ledger.parent==RELEASE:continue
  for line in ledger.read_text().splitlines():
   sha,name=line.split('  ',1);checked('/' not in name,'Unsafe old ledger entry');p=ledger.parent/name;record=hfile(p);checked(record['sha256']==sha,'Old archive changed/missing '+str(p));old.append({'path':str(p.relative_to(ROOT)),**record})
 oldmeta=[]
 for name,value in tree(COMMIT,'releases').items():
  if name.endswith('/manifest.json') or name.endswith('/SHA256SUMS') or name.endswith('/INCOMPLETE.txt'):
   p=ROOT/name
   with open(p,'rb') as f:record=hread(f,p.stat().st_size,value['gitBlob'])
   oldmeta.append({'path':name,**record,'gitBlob':value['gitBlob']})
 R['priorMilestones']={'sealedArchiveFiles':old,'committedMetadata':oldmeta,'allListedArchivesAndMetadataUnchanged':True,'scope':'Original retained SHA ledgers and pinned Git metadata, not an exhaustive reread of every historical unlisted working/review/cache file'}
 after={p:hfile(RELEASE/p) for p in R['metadataBefore']};checked(after==R['metadataBefore'],'Release metadata changed during audit');R['status']='accepted-scoped-development-archive';R['limitations']=['No new executable launch/playtest, installer/update/consumer verification','Native receipt/package correspondence only; platform test scope remains its actual declared scope','No AAA/human-fun consensus/Steam/Steam Deck/physical-controller claim','No future tag/remote publication or preservation receipt asserted']
except Exception as e:
 R['status']='rejected';R['failure']=repr(e);raise
finally:
 (OUT/'result-r2.json').write_text(json.dumps(R,indent=2)+'\n');print('AUDIT',R['status'],flush=True)
