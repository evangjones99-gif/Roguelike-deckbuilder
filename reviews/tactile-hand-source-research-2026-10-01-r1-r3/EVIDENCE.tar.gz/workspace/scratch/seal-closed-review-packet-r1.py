import os,sys,stat,pathlib,hashlib,json,tarfile,io
name,description,*roots=sys.argv[1:]
head=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())-int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
assert head>=(32+512)*1024**2
dest=pathlib.Path('/workspace/Roguelike-deckbuilder/reviews')/name
assert not dest.exists();dest.mkdir()
paths=set()
for root in roots:
    root=pathlib.Path(root)
    if root.is_dir():paths.update(p for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    elif root.is_file() and not root.is_symlink():paths.add(root)
    else:raise ValueError(str(root))
inventory=[];archive=dest/'EVIDENCE.tar.gz'
with archive.open('xb') as raw:
    with tarfile.open(fileobj=raw,mode='w:gz') as tar:
        for path in sorted(paths):
            fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
            try:
                before=os.fstat(fd);assert stat.S_ISREG(before.st_mode) and before.st_size<8*1024**2
                with os.fdopen(os.dup(fd),'rb') as f:data=f.read()
                assert os.fstat(fd)==before and len(data)==before.st_size
            finally:os.close(fd)
            info=tarfile.TarInfo(str(path).lstrip('/'));info.size=len(data);info.mode=stat.S_IMODE(before.st_mode);info.mtime=before.st_mtime
            tar.addfile(info,io.BytesIO(data));inventory.append({'original':str(path),'member':info.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    raw.flush();os.fsync(raw.fileno())
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(inventory)
    for row in inventory:
        data=tar.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
digest=hashlib.sha256()
with archive.open('rb') as f:
    while block:=f.read(65536):digest.update(block)
manifest={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':digest.hexdigest(),'roundtrip':'every archived body exact','originalsRetained':True,'scope':description,'files':inventory}
for filename,data in [('PRESERVATION.json',json.dumps(manifest,indent=2)+'\n'),('OUTCOME.md',description+'\n')]:
    with (dest/filename).open('x') as f:f.write(data);f.flush();os.fsync(f.fileno())
for directory in (dest,dest.parent):
    fd=os.open(directory,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({'packet':str(dest),'members':len(inventory),'bytes':manifest['bytes'],'sha256':manifest['sha256']}))
