# External tactile proposal R3 — SOURCE ONLY

This new packet preserves rejected R1 and R2 unchanged. Independent reviewer caught the R2 document pointerdown registration after attachTactileHand closed, where observePress was inaccessible. This authoring error would fail typecheck and module evaluation. R3 moves that exact registration inside the function alongside the other listeners, paired with its existing disposal removal. No other module or CSS behavior changes in this revision.

No Node, typecheck, browser or test execution has occurred. Independent review and real pointer/input integration tests remain required. R1 canceled-mouse/other-touch failure and R2 scope failure remain retained, rather than treated as passes. Canonical host ownership, stable controller, revision identity and disposal contracts still apply.
