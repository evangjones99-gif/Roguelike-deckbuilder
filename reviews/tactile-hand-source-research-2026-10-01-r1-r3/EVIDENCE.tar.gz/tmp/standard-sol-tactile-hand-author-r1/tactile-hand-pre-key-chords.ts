/** Original local card presentation. Root owns identity, legality and reducer.
 * No engine/storage/audio/controller access; no device vibration or art request. */
export interface TactileCardSource {
  readonly key: string;
  readonly cardId: string;
  readonly revision: string;
  readonly handIndex: number;
}
export interface TactilePoint { readonly x: number; readonly y: number }
export interface TactileDestination {
  readonly kind: 'target' | 'deploy' | 'field';
  readonly key: string;
}
export interface TactilePreview { readonly legal: boolean; readonly label: string }
export interface TactileHandHost {
  /** Snapshot the exact card occurrence and current canonical hand revision. */
  identify(card: HTMLElement): TactileCardSource | null;
  /** Must check revision AND occurrence/index/cardId against current state. */
  isCurrent(source: TactileCardSource): boolean;
  /** Root includes modal, turn/presentation lock, energy and phase admission. */
  isInteractionAllowed(source: TactileCardSource): boolean;
  /** Root uses semantic UID/renderer hit ownership or explicit deploy area.
   * This lookup and getPreview must never dispatch, select or mutate rules. */
  resolveDestination(source: TactileCardSource, point: TactilePoint): TactileDestination | null;
  getPreview(source: TactileCardSource, destination: TactileDestination | null): TactilePreview;
  /** Called at most once per released drag, after fresh identity/legality checks.
   * Revalidate the exact legal action here; return true only if reducer accepts.
   * Never reinterpret a stale source index as the current card at that index. */
  commit(source: TactileCardSource, destination: TactileDestination): boolean;
  /** UI feedback only. null clears any root-owned preview. */
  onPreview?(source: TactileCardSource | null, destination: TactileDestination | null, preview: TactilePreview | null): void;
  onError?(error: unknown): void;
}
export interface TactileHandOptions { cardSelector?: string }
export interface TactileHandController { cancel(): void; dispose(): void }
type Session = {
  pointerId: number; pointerType: string; card: HTMLElement; source: TactileCardSource;
  down: TactilePoint; point: TactilePoint; grab: TactilePoint; width: number; height: number;
  dragging: boolean; attempted: boolean; ghost: HTMLElement | null; label: HTMLElement | null;
  previewKey: string;
};
const owners = new WeakMap<HTMLElement, TactileHandController>();

export function attachTactileHand(root: HTMLElement, host: TactileHandHost, options: TactileHandOptions = {}): TactileHandController {
  owners.get(root)?.dispose();
  const document = root.ownerDocument, view = document.defaultView;
  if (!view) throw new Error('Tactile hand needs an attached document');
  const window = view;
  const selector = options.cardSelector ?? '.hand-cards .game-card[data-index],.game-card[data-index]';
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const priorAttribute = root.getAttribute('data-tactile-hand');
  root.setAttribute('data-tactile-hand', '');
  let active: Session | null = null, disposed = false, frame = 0;
  let suppressed: { pointerId: number; source: HTMLElement; until: number } | null = null;
  const cancelledPointers = new Map<number, HTMLElement>();
  const effects = new Set<{ ghost: HTMLElement; source: HTMLElement; timer: number }>();
  const point = (event: PointerEvent): TactilePoint => Object.freeze({ x: event.clientX, y: event.clientY });
  const reduced = () => motion.matches || document.documentElement.dataset.reducedMotion === 'true';
  const guarded = <T>(fn: () => T, fallback: T): T => {
    try { return fn(); } catch (error) { try { host.onError?.(error); } catch {} return fallback; }
  };
  const sourceSnapshot = (card: HTMLElement): TactileCardSource | null => {
    const source = guarded(() => host.identify(card), null);
    if (!source || typeof source.key !== 'string' || !source.key || typeof source.cardId !== 'string' || !source.cardId
      || typeof source.revision !== 'string' || !source.revision || !Number.isInteger(source.handIndex) || source.handIndex < 0) return null;
    return Object.freeze({ key: source.key, cardId: source.cardId, revision: source.revision, handIndex: source.handIndex });
  };
  const permitted = (session: Session) => !disposed && !document.hidden && session.card.isConnected && root.contains(session.card)
    && !document.querySelector('dialog[open]') && guarded(() => host.isCurrent(session.source), false) === true
    && guarded(() => host.isInteractionAllowed(session.source), false) === true;
  const clearEffects = () => {
    for (const effect of effects) { window.clearTimeout(effect.timer); effect.ghost.remove(); effect.source.classList.remove('tactile-return'); }
    effects.clear();
  };
  const clearPreview = () => { guarded(() => host.onPreview?.(null, null, null), undefined); };
  const observer = new MutationObserver(() => { if (active && !permitted(active)) finish('cancel'); });
  const releaseCapture = (session: Session) => {
    try { if (session.card.hasPointerCapture(session.pointerId)) session.card.releasePointerCapture(session.pointerId); } catch {}
  };
  function finish(reason: 'accepted' | 'return' | 'cancel' | 'tap' | 'scroll', released = false) {
    const session = active; if (!session) return;
    active = null; observer.disconnect(); window.cancelAnimationFrame(frame); frame = 0;
    if (session.dragging || reason === 'cancel') {
      if (released) suppressed = { pointerId: session.pointerId, source: session.card, until: performance.now() + 700 };
      else cancelledPointers.set(session.pointerId, session.card);
    }
    releaseCapture(session);
    session.card.classList.remove('tactile-pressed', 'tactile-source');
    root.classList.remove('tactile-dragging');
    clearPreview();
    const ghost = session.ghost;
    if (!ghost) return;
    if (reason === 'cancel' || reduced()) { ghost.remove(); return; }
    if (reason === 'accepted') {
      ghost.classList.add('tactile-accepted');
      const effect = { ghost, source: session.card, timer: 0 };
      effect.timer = window.setTimeout(() => { ghost.remove(); effects.delete(effect); }, 120);
      effects.add(effect); return;
    }
    if (!session.card.isConnected) { ghost.remove(); return; }
    const rect = session.card.getBoundingClientRect();
    if (!rect.width || !rect.height) { ghost.remove(); return; }
    ghost.classList.add('tactile-returning');
    ghost.style.transform = `translate3d(${rect.left}px,${rect.top}px,0)`;
    session.card.classList.add('tactile-return');
    const effect = { ghost, source: session.card, timer: 0 };
    effect.timer = window.setTimeout(() => { ghost.remove(); session.card.classList.remove('tactile-return'); effects.delete(effect); }, 160);
    effects.add(effect);
  }
  function makeGhost(session: Session) {
    const ghost = document.createElement('div'); ghost.className = 'tactile-ghost'; ghost.setAttribute('aria-hidden', 'true'); ghost.inert = true;
    const phase = session.card.closest('.phase-battle');
    if (phase) for (const name of ['phase-battle', 'direct-field', 'dense-battle']) if (phase.classList.contains(name)) ghost.classList.add(name);
    ghost.style.width = `${session.width}px`; ghost.style.height = `${session.height}px`;
    const copy = session.card.cloneNode(true) as HTMLElement;
    copy.classList.remove('tactile-pressed', 'tactile-source', 'tactile-return'); copy.classList.add('tactile-ghost-card');
    for (const node of [copy, ...copy.querySelectorAll<HTMLElement>('*')]) {
      for (const attribute of [...node.attributes]) if (/^(id|name|tabindex|autofocus|form|data-(ui|action|unit|uid|focus|index))$/.test(attribute.name) || attribute.name.startsWith('on')) node.removeAttribute(attribute.name);
      node.setAttribute('tabindex', '-1');
    }
    copy.querySelectorAll('script,iframe,object,embed,link,audio,video').forEach(node => node.remove());
    const originalCanvases = session.card.querySelectorAll('canvas'), copies = copy.querySelectorAll('canvas');
    originalCanvases.forEach((canvas, index) => {
      const target = copies[index]; if (!target) return;
      target.width = canvas.width; target.height = canvas.height;
      try { target.getContext('2d')?.drawImage(canvas, 0, 0); } catch { /* Decorative copy cannot block a valid input. */ }
    });
    const label = document.createElement('div'); label.className = 'tactile-preview';
    // Retain the actual hand style context; the wrapper is inert and has no
    // layout/scroll padding. Cost/rules text remains cloned ordinary DOM.
    const surface = document.createElement('div'); surface.className = 'hand-cards'; surface.append(copy);
    ghost.append(surface, label); document.body.append(ghost); session.ghost = ghost; session.label = label;
  }
  function readPreview(session: Session) {
    const resolved = guarded(() => host.resolveDestination(session.source, session.point), null);
    const destination = resolved && ['target', 'deploy', 'field'].includes(resolved.kind) && typeof resolved.key === 'string' && resolved.key
      ? Object.freeze({ kind: resolved.kind, key: resolved.key }) : null;
    const supplied = guarded(() => host.getPreview(session.source, destination), { legal: false, label: 'Return to hand' });
    const preview = Object.freeze({ legal: destination !== null && supplied?.legal === true, label: typeof supplied?.label === 'string' ? supplied.label.slice(0, 300) : 'Return to hand' });
    return { destination, preview };
  }
  function update(session: Session) {
    if (!session.ghost) return;
    const x = session.point.x - session.grab.x, y = session.point.y - session.grab.y;
    session.ghost.style.transform = `translate3d(${x}px,${y}px,0)`;
    const { destination, preview } = readPreview(session);
    session.ghost.dataset.legal = String(preview.legal);
    if (session.label) session.label.textContent = preview.label;
    const key = JSON.stringify([destination?.kind, destination?.key, preview.legal, preview.label]);
    if (key !== session.previewKey) { session.previewKey = key; guarded(() => host.onPreview?.(session.source, destination, preview), undefined); }
  }
  function animate() {
    const session = active; if (!session?.dragging) return;
    if (!permitted(session)) { finish('cancel'); return; }
    update(session); if (active === session) frame = window.requestAnimationFrame(animate);
  }
  function down(event: PointerEvent) {
    if (disposed || event.button !== 0 || !event.isPrimary) return;
    if (active) { finish('cancel'); return; }
    cancelledPointers.clear(); suppressed = null;
    const card = event.target instanceof Element ? event.target.closest<HTMLElement>(selector) : null;
    if (!card || !root.contains(card) || card.closest('dialog') || card.matches(':disabled,[aria-disabled="true"]')) return;
    const source = sourceSnapshot(card); if (!source) return;
    const rect = card.getBoundingClientRect(), down = point(event);
    if (!rect.width || !rect.height) return;
    const session: Session = { pointerId: event.pointerId, pointerType: event.pointerType, card, source, down, point: down,
      grab: Object.freeze({ x: down.x - rect.left, y: down.y - rect.top }), width: rect.width, height: rect.height,
      dragging: false, attempted: false, ghost: null, label: null, previewKey: '' };
    if (!permitted(session)) return;
    clearEffects(); active = session; card.classList.add('tactile-pressed');
    observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true,
      attributeFilter: ['open', 'hidden', 'disabled', 'aria-busy', 'data-index', 'data-card', 'data-revision', 'data-reduced-motion'] });
    // No preventDefault/capture before threshold: ordinary click and pan-x work.
  }
  function move(event: PointerEvent) {
    const session = active; if (!session || event.pointerId !== session.pointerId) return;
    if (!permitted(session) || session.pointerType === 'mouse' && !(event.buttons & 1)) { finish('cancel'); return; }
    session.point = point(event);
    if (!session.dragging) {
      const dx = event.clientX - session.down.x, dy = event.clientY - session.down.y;
      if (session.pointerType === 'touch') {
        if (Math.abs(dx) >= 12 && Math.abs(dx) >= Math.abs(dy)) { finish('scroll'); return; }
        if (dy >= 12) { finish('scroll'); return; }
        if (dy > -12 || Math.abs(dy) < Math.abs(dx) * 1.25) return;
      } else if (Math.hypot(dx, dy) < 7) return;
      session.dragging = true;
      try { session.card.setPointerCapture(session.pointerId); } catch { finish('cancel'); return; }
      makeGhost(session); session.card.classList.remove('tactile-pressed'); session.card.classList.add('tactile-source'); root.classList.add('tactile-dragging');
      update(session); if (active === session && !disposed) frame = window.requestAnimationFrame(animate);
    }
    event.preventDefault();
  }
  function up(event: PointerEvent) {
    const cancelled = cancelledPointers.get(event.pointerId);
    if (cancelled) { cancelledPointers.delete(event.pointerId); suppressed = { pointerId: event.pointerId, source: cancelled, until: performance.now() + 700 }; event.preventDefault(); return; }
    const session = active; if (!session || event.pointerId !== session.pointerId) return;
    session.point = point(event);
    if (!session.dragging) {
      if (!permitted(session)) { suppressed = { pointerId: session.pointerId, source: session.card, until: performance.now() + 700 }; event.preventDefault(); finish('cancel', true); }
      else finish('tap', true);
      return;
    }
    event.preventDefault();
    // Release resolves afresh; cached hover, DOM index or painted ghost is never authority.
    if (!permitted(session)) { finish('return', true); return; }
    const { destination, preview } = readPreview(session);
    let accepted = false;
    if (!session.attempted && destination && preview.legal && permitted(session)) {
      session.attempted = true;
      accepted = guarded(() => host.commit(session.source, destination), false) === true;
    }
    if (active === session) finish(accepted ? 'accepted' : 'return', true);
  }
  function pointerCancel(event: PointerEvent) {
    cancelledPointers.delete(event.pointerId);
    if (active?.pointerId === event.pointerId) finish('cancel');
  }
  function lostCapture(event: PointerEvent) { if (active?.dragging && active.pointerId === event.pointerId) finish('cancel'); }
  function click(event: MouseEvent) {
    if (!suppressed || event.detail === 0 || performance.now() > suppressed.until) return;
    const pointerMatch = event instanceof PointerEvent ? event.pointerId === suppressed.pointerId : event.target instanceof Node && suppressed.source.contains(event.target);
    if (!pointerMatch) return;
    suppressed = null; event.preventDefault(); event.stopImmediatePropagation();
  }
  function key(event: KeyboardEvent) {
    if (event.key !== 'Escape' || !active?.dragging) return;
    event.preventDefault(); event.stopImmediatePropagation(); finish('cancel');
  }
  function cancel() { finish('cancel'); clearEffects(); }
  function visibility() { if (document.hidden) cancel(); }
  function nativeDrag(event: DragEvent) { if (active && event.target instanceof Node && active.card.contains(event.target)) event.preventDefault(); }
  root.addEventListener('pointerdown', down);
  root.addEventListener('dragstart', nativeDrag);
  document.addEventListener('pointermove', move, { passive: false });
  document.addEventListener('pointerup', up, { passive: false });
  document.addEventListener('pointercancel', pointerCancel);
  document.addEventListener('lostpointercapture', lostCapture);
  document.addEventListener('click', click, true);
  // Window capture precedes root's existing document Escape capture handler.
  window.addEventListener('keydown', key, true);
  document.addEventListener('visibilitychange', visibility);
  window.addEventListener('resize', cancel);
  window.addEventListener('blur', cancel);
  motion.addEventListener('change', cancel);
  const controller: TactileHandController = { cancel, dispose() {
    if (disposed) return;
    cancel(); disposed = true; observer.disconnect(); cancelledPointers.clear(); suppressed = null;
    root.removeEventListener('pointerdown', down); root.removeEventListener('dragstart', nativeDrag);
    document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', up);
    document.removeEventListener('pointercancel', pointerCancel); document.removeEventListener('lostpointercapture', lostCapture);
    document.removeEventListener('click', click, true); window.removeEventListener('keydown', key, true);
    document.removeEventListener('visibilitychange', visibility); window.removeEventListener('resize', cancel); window.removeEventListener('blur', cancel); motion.removeEventListener('change', cancel);
    if (priorAttribute === null) root.removeAttribute('data-tactile-hand'); else root.setAttribute('data-tactile-hand', priorAttribute);
    if (owners.get(root) === controller) owners.delete(root);
  } };
  owners.set(root, controller); return controller;
}
