import json,gzip,hashlib,datetime,re,urllib.request
from pathlib import Path
P=Path('/workspace/scratch/contextual-scene-independent-visual-v08-r1')
h=lambda b:hashlib.sha256(b).hexdigest()
intake=json.loads((P/'SOURCE-INTAKE.json').read_text())
a=json.loads(gzip.decompress((P/'FAILURE.json.gz').read_bytes()))
b=json.loads(gzip.decompress((P/'r2-results.json.gz').read_bytes()))
rows=a['rows']+b['rows'];out={'verifiedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completedCases':len(rows),'actions':sum('action' in s for r in rows for s in r['steps']),'failureRetained':a['error'],'paired':[],'pngResponses':0,'expectedMissingRequests':0,'sourceFinal':[]}
for v in intake['variants']:
 root=Path(v['path']); prov=v['provenance'];sv=[];ov=[]
 for name,sha in prov['hashes'].items():
  assert h((root/name).read_bytes())==sha,name;sv.append(name)
 for obj in v['outputs']:
  data=(root/'dist'/obj['path']).read_bytes();assert h(data)==obj['sha256'] and len(data)==obj['bytes'];served=urllib.request.urlopen(v['base']+obj['path']).read();assert served==data;ov.append(obj['path'])
 out['sourceFinal'].append({'label':v['label'],'sourceDigest':prov['sourceDigest'],'sourceFilesVerified':len(sv),'servedOutputBodiesVerified':len(ov),'sourceRootResolved':str(root.resolve()),'outputRootResolved':str((root/'dist').resolve())})
for r in rows:
 assert not r['errors']
 for url in r['failed']:
  assert r['opt'].get('missing') and url.endswith('/art/ossuary-crypt-v08-r2.png');out['expectedMissingRequests']+=1
 for resp in r['responses']:
  name='public/art/'+resp['url'].rsplit('/',1)[-1];assert resp['status']==200 and resp['sha256']==r['provenance']['hashes'][name];out['pngResponses']+=1
 for s in r['steps']:
  if 'action' in s:assert s['canonicalExact']
 groups={}
for r in rows:
 key=(r['variant'].startswith('r2-'),r['name'],r['viewport']['width'],r['viewport']['height']);groups.setdefault(key,[]).append(r)
def normalized(o):
 if isinstance(o,str):return re.sub(r'http://127.0.0.1:\d+/','http://HOST/',o)
 if isinstance(o,list):return [normalized(x)for x in o]
 if isinstance(o,dict):return {k:normalized(v)for k,v in o.items()}
 return o
for key,pair in groups.items():
 assert len(pair)==2,key;c=next(r for r in pair if 'candidate' in r['variant']);z=next(r for r in pair if 'baseline' in r['variant']);assert c['initial']==z['initial']
 ca=[s for s in c['steps']if 'action'in s];za=[s for s in z['steps']if 'action'in s];assert ca==za
 cp=[s['sha256']for s in c['steps']if s.get('stage')=='canvas-pixel'];zp=[s['sha256']for s in z['steps']if s.get('stage')=='canvas-pixel'];assert cp==zp,(key,'canvas pixels')
 cs=[s for s in c['steps']if 'save'in s];zs=[s for s in z['steps']if 'save'in s];assert len(cs)==len(zs)
 diffs=[]
 for x,y in zip(cs,zs):
  assert x['stage']==y['stage'];assert x['save']==y['save'];assert x['sceneRect']==y['sceneRect']
  for i,(e,f) in enumerate(zip(x['essential'],y['essential'])):
   ee=normalized(e);ff=normalized(f)
   if ee!=ff:
    if e['className']=='arena-fallback':
     assert {k:v for k,v in ee.items()if k!='backgroundImage'}=={k:v for k,v in ff.items()if k!='backgroundImage'}
     diffs.append({'stage':x['stage'],'essentialIndex':i,'only':'arena-fallback backgroundImage URL'})
    else:
     assert key[1]=='terminal-no-canvas' and x['stage']=='after-action' and e['className']=='game-card spell   large-card'
     assert {k:v for k,v in ee.items()if k!='rect'}=={k:v for k,v in ff.items()if k!='rect'}
     assert max(abs(a-b)for a,b in zip(e['rect'],f['rect']))<1
     diffs.append({'stage':x['stage'],'essentialIndex':i,'only':'naturally sampled animated reward-card rectangle','candidateRect':e['rect'],'baselineRect':f['rect'],'maximumDeltaPx':max(abs(a-b)for a,b in zip(e['rect'],f['rect']))})
 out['paired'].append({'case':list(key),'canonicalActionsExact':len(ca),'snapshotSavesExact':len(cs),'sceneRectsExact':True,'reducedMotionArenaPixelHashesExact':cp,'essentialDifferences':diffs})
receipt=json.loads((P/'r2-RESULTS-RECEIPT.json').read_text());gz=(P/'r2-results.json.gz').read_bytes();raw=gzip.decompress(gz);assert len(raw)==receipt['decodedBytes']and h(raw)==receipt['decodedSHA256']and h(gz)==receipt['gzipSHA256']
# Frozen author gate exact at end; manifest lists relative pathname then original bytes.
manifest=Path('/workspace/scratch/contextual-scene-author-v08-r1/FROZEN-FILES.json');md=json.loads(manifest.read_text());print(type(md),str(md)[:350]);out['authorManifestSHA256Final']=h(manifest.read_bytes());assert out['authorManifestSHA256Final']==intake['authorManifestSHA256']
for f in md['files']:
 assert h((manifest.parent/f['path']).read_bytes())==f['sha256']
out['authorDeclaredFinalExact']=len(md['files']);(P/'AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['paired','sourceFinal']},indent=2));print('All paired pixels/canonical/style/served source records exact.')
