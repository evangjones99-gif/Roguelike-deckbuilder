import collections,datetime,hashlib,json,os,stat
from pathlib import Path
OUT=Path(__file__).parent
ROOTS=['/workspace/scratch/retained-working-linux-0.5.0-cdf4098ab542', '/workspace/scratch/retained-working-linux-0.6.0-0ec0187f0a42', '/workspace/scratch/retained-working-linux-0.6.0-a502ed48dfb6', '/workspace/scratch/retained-working-windows-0.6.0-0ec0187f0a42', '/workspace/scratch/native-windows-v06/run-36789372782-1/native-extracted', '/workspace/scratch/native-windows-v061/run-36791619534-1/native-extracted']
WORKSPACE_DEVICE=Path("/workspace").stat().st_dev
ALLOWED_ROOT_LEAVES={'hollowpact','Hollowpact.exe','chrome-sandbox','chrome_crashpad_handler',
 'chrome_100_percent.pak','chrome_200_percent.pak','resources.pak','icudtl.dat',
 'libvulkan.so.1','libvk_swiftshader.so','libffmpeg.so','snapshot_blob.bin','v8_context_snapshot.bin',
 'vk_swiftshader_icd.json','vulkan-1.dll','vk_swiftshader.dll','ffmpeg.dll','d3dcompiler_47.dll',
 'dxil.dll','dxcompiler.dll','LICENSE.electron.txt','LICENSES.chromium.html'}
def metadata(p):
 s=p.lstat()
 return {'type':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'other',
  'size':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,
  'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns,'blocks':s.st_blocks,'uid':s.st_uid,'gid':s.st_gid,'xattrs':{n:os.getxattr(p,n,follow_symlinks=False).hex() for n in sorted(os.listxattr(p,follow_symlinks=False))}}
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
inventories=[];all_rows=[]
for rootname in ROOTS:
 root=Path(rootname);assert root.is_dir() and not root.is_symlink() and root.resolve().is_relative_to('/workspace/scratch') and root.stat().st_dev==WORKSPACE_DEVICE
 members=[root,*sorted(root.rglob('*'))];before={p.relative_to(root).as_posix():metadata(p) for p in members}
 assert all(x['type'] in ('file','directory') for x in before.values())
 rows=[]
 for p in members:
  name=p.relative_to(root).as_posix();row={'path':str(p),'relative_path':name,'before':before[name]}
  if row['before']['type']=='file':
   row['sha256']=digest(p)
   rel=Path(name)
   row['eligible_runtime_only']=name in ALLOWED_ROOT_LEAVES or (len(rel.parts)==2 and rel.parts[0]=='locales' and rel.suffix=='.pak')
  else:row['eligible_runtime_only']=False
  after=metadata(p);row['after_hash']=after
  assert all(after[k]==before[name][k] for k in ('type','size','mode','device','inode','nlink','mtime_ns','ctime_ns','blocks','uid','gid','xattrs')),(str(p),'changed during hash')
  rows.append(row)
 assert {p.relative_to(root).as_posix() for p in [root,*root.rglob('*')]}==set(before)
 inventories.append({'root':str(root),'files':sum(r['before']['type']=='file' for r in rows),'directories':sum(r['before']['type']=='directory' for r in rows),'rows':rows})
 all_rows.extend(rows)
 print(json.dumps({'root':str(root),'files':inventories[-1]['files'],'directories':inventories[-1]['directories'],'hash_mode_identity_mtime_ctime_unchanged':True}),flush=True)
groups=collections.defaultdict(list)
for r in all_rows:
 if r['eligible_runtime_only']:groups[(r['before']['size'],r['sha256'],r['before']['mode'],r['before']['uid'],r['before']['gid'],json.dumps(r['before']['xattrs'],sort_keys=True))].append(r)
duplicate_groups=[];logical_savings=0;allocated_savings=0
for key,rows in groups.items():
 physical={}
 for r in rows:physical.setdefault((r['before']['device'],r['before']['inode']),r)
 if len(physical)<2:continue
 canonical=rows[0];ids=list(physical);canonical_id=(canonical['before']['device'],canonical['before']['inode'])
 new_save=(len(physical)-1)*key[0];alloc_save=sum(r['before']['blocks']*512 for identity,r in physical.items() if identity!=canonical_id)
 logical_savings+=new_save;allocated_savings+=alloc_save
 duplicate_groups.append({'bytes':key[0],'sha256':key[1],'mode':key[2],'uid':key[3],'gid':key[4],'xattrs':json.loads(key[5]),'canonical_path_forecast_only':canonical['path'],
  'logical_path_count':len(rows),'distinct_current_physical_inodes':len(physical),'incremental_logical_saving':new_save,'incremental_allocated_saving':alloc_save,
  'paths':[r['path'] for r in rows],'current_physical_records':[{'device_inode':list(identity),'nlink':r['before']['nlink'],'blocks':r['before']['blocks']} for identity,r in physical.items()],
  'differing_mtime_in_group':len({r['before']['mtime_ns'] for r in rows})>1})
all_identity=collections.defaultdict(list)
for r in all_rows:
 if r['before']['type']=='file':all_identity[(r['before']['device'],r['before']['inode'])].append(r)
outside_aliases=[]
for identity,rows in all_identity.items():
 nlinks={r['before']['nlink'] for r in rows};assert len(nlinks)==1
 if next(iter(nlinks))!=len(rows):outside_aliases.append({'identity':list(identity),'nlink':next(iter(nlinks)),'observed_paths':len(rows),'paths':[r['path'] for r in rows]})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only DURABLE workspace filesystem native comparison inventories only; stock runtime root leaves/locales candidates grouped by complete size,SHA,mode,uid,gid,xattrs. No TMP/installed tools/officialrelease archives/ASAR/source/game/media/profiles/datasets/art merge.',
 'roots':ROOTS,'regular_files_hashed':sum(r['before']['type']=='file' for r in all_rows),'complete_inventories':inventories,
 'runtime_candidate_duplicate_groups':duplicate_groups,'incremental_logical_saving_bytes':logical_savings,'incremental_allocated_saving_bytes':allocated_savings,
 'outside_inventory_aliases':outside_aliases,'mutations_performed':False,'actual_free_bytes_snapshot':{root:os.statvfs(root).f_bavail*os.statvfs(root).f_frsize for root in ('/tmp','/workspace')},
 'atime_may_change_due_to_reader':True,'directory_metadata_unchanged_claim_scope':'mode,size,device,inode,nlink,mtime,ctime,blocks sampled before/after; subsequent root file-link replacement can change parent directory metadata, which must be recorded/preserved as appropriate.'}
(OUT/'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'regular_files_hashed':result['regular_files_hashed'],'duplicate_groups':len(duplicate_groups),'incremental_logical_saving_bytes':logical_savings,'incremental_allocated_saving_bytes':allocated_savings,'outside_alias_groups':len(outside_aliases)}),flush=True)
