# Independent PC creature nameplate source gate

Decision: ACCEPT the exact Root-authored nameplate delta for NEW combined-stage integration and bounded verification. This is source-scope acceptance only, not an actual game/readability/fun/promotion gate. No definite semantic blocking defect was found in this narrow change.

## Independence and scope

I authored earlier tactile/focus host changes inherited by the frozen PC R4 baseline, and a separate unexecuted card-material study. Root authored this creature-nameplate main/CSS trial; I did not author or mutate its delta. Therefore this review independently assesses the new nameplate change while disclosing the inherited host dependency; it is not an independent reapproval of my own full main or materials. Read the complete supplied diff/CSS, author scope, pertinent main identity/final-hold/focus/Inspect/target routes and renderer UID/readout ownership.

Own NEW packet only: no candidate, frozen R4/ROOT, game/art/build source edits; no Node, browser, compile, tests, Git or archive-body read. Fresh32MiB source allowance+512MiB reserve and streamed exact input identities are preserved. Nothing here is an executed injection/focus/geometry test.

## Exact source binding

Candidate main104188bytes SHA230e7c2e068eedb149e7c7401c5e3b0fe1990212da7aba7c1fd2d4f2dccb7fd0; CSS197bytes SHA2c5534b695462972d87015e69446a240769c28440d400ebc83a02fffc5d6cb87. All four author frozen members matched sizes/hashes. Recomputed full diff byte-equals supplied4365-byte FULL-SOURCE.diff and contains only fieldActor identity/title construction and the existing absent-canonical-region identity update. Baseline mainc213d5cb remains exact. INPUT-PINS records contextual renderer/layout/engine/readout CSS identities.

CSS is an external proposed component and is not yet imported by candidate main. This gate requires the NEW combined stage to bind/import it and the separately reviewed readout clamp explicitly in its complete source/build digest. Source-only acceptance cannot establish that the stylesheet is actually applied in a browser. Do not mutate frozen R4 to integrate it.

## Identity and held UID

fieldActor now uses actual owned unit.name plus H/B(index+1), or down/lost when canonical index is null. Side still comes from the same fieldRoster/renderer side. Visible ordinals are current formation positions, not immutable UID identities across removals/reindexing. Engine actions and main lookup remain exact data-unit/data-uid; no name/ordinal is interpreted as action authority.

Renderer getUnitRegions copies/freeze-owns each figure's readoutUnit under region.uid, supplies canonicalIndex from the current renderer-side canonical list, and marks dead/departing/unowned regions disabled. positionFieldControls matches each actor.dataset.actor to that same region.uid, so the down/lost name comes from the departing actor's owned readout, not the surviving unit at an old index. UID/control/focus attributes and region hit/inspect rectangles are unchanged by the complete diff.

Known terminal-hold scope: while settlingCombat=true, identity remains its previous name+H/B ordinal because the existing absent-canonical update is guarded !settlingCombat. updateFinalStrikeReadout separately writes resolved0health, Quarry down/Binding lost status and exact full final-impact aria; held controls are disabled. This does NOT promise the terminal identity row itself is rewritten to down/lost. Root explicitly clarified that separate status/health/aria are authoritative in this hold, and duplicate down wording in both rows is not required. Ordinary nonsettling departing rows do get owned name+down/lost. These exact limits replace an overly broad reading of author SCOPE, without rewriting the author packet.

## Escaping and accessibility

Initial name/identity is escaped both as visible HTML and quoted title/aria via the existing escape helper covering &,<,>,double/single quote. Post-render held identity uses textContent and title property, so raw name text is not parsed as markup. UID values remain escaped as before. This is source inspection, not a dynamic security test.

Full name/HP/attack/block/intent/status information stays in the Inspect accessible label and title even when the visible name ellipsizes. The new detail concatenation repeats unit.name (name plus identity also includes name) and uses H/B instead of the old full Hostile/Binding phrase; therefore the accessible label is informationally complete, not byte-identical to the old sentence. That minor verbosity/abbreviation deserves actual PC keyboard/assistive review, without being presented as an escaping/UID blocker or demanding cosmetic edits for source acceptance.

## Geometry, long names and focus/target routes

CSS changes only overflow:hidden, text-overflow:ellipsis and white-space:nowrap on the existing identity span. It adds no font/height/padding/border/control/target geometry. Existing current readout CSS establishes16px identity line height and renderer inspect allocation. The proposed separate clamp must receive its own combined-stage gate; I am not accepting unseen changes to it here.

Validated unit names can be up to100characters, so ellipsis is necessary. End ellipsis can hide part/all of a long name's H/B suffix or decorative inspection glyph; title/aria preserve full identity, but universal visible ordinal/full-name fitting is NOT established. Current authored names at1440px require actual measured paint/capture. Do not widen/reflow rows or shrink text just to claim every string fits.

The span remains inside the same Inspect button, and pointer/focus routing uses semantic [data-ui=inspect-unit] ancestry rather than the new text/title. Full diff leaves data-focus, inspect data-uid, button state, UID selection and pure consequence/legalActions paths intact. Existing PC R4 guarded modal close/return behavior and tactile barriers remain inherited, not independently runtime reverified by this source gate.

## Required actual bounded PC verification

Bind a NEW combined source/build at1440x900, same zoom/DPR and exact canonical campaign as clean R4. Verify short/long real names, duplicate species, >=12px readouts,16px identity row and zero owned intersections; native title and full accessible Inspect label must match the same unit UID. Show current ordinals after a nonterminal death/reindex, held corpse name+down/lost, terminal final-hold name/0HP/down status correctness without retargeting.

Use actual slow pointer body→Inspect, click, keyboard focus/Enter and modal Return; exact preview/save must remain stable until a real canonical change. Test selected attacks and targeted tool drag release on the same UID; new name spans cannot intercept or move target ownership. Check missing-art/canvas fallback, readout clamp and reduced motion without replacing actual earned paths with synthetic diagnostics. Any100character/hostile-looking-string stress fixture must be separately labeled diagnostic and validator-checked. Native title/ellipsis/readability/assistive behavior cannot be proved by this report.

Prior failures/rejections, frozen baselines and actual PC quality decisions remain untouched. Reject at the combined/runtime gate if these constraints fail. No AAA, human preference, portable native-host or promotion claim.
