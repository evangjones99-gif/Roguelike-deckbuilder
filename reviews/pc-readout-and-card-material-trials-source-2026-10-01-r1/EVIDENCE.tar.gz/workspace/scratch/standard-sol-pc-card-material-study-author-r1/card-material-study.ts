/** Original source-only material comparison utility. No engine, save, audio,
 * input or art editing. Integrate only into a separately reviewed NEW stage. */
export type CardMaterialVariant = 'baseline' | 'material' | 'frame2';
export interface CardMaterialStudyOptions {
  variant: CardMaterialVariant;
  /** Root's explicit cancellation before any variant change/disposal. */
  cancelInteractions(): void;
  /** Serve the pinned, unedited local original through the research server. */
  frame2OriginalURL?: string;
}
export interface CardMaterialStudyController {
  setVariant(variant: CardMaterialVariant): void;
  refresh(): void;
  dispose(): void;
}
type Snapshot = {
  attribute: string | null; property: string; priority: string;
  rim: HTMLElement | null;
};
const controllers = new WeakMap<HTMLElement, CardMaterialStudyController>();
const attribute = 'data-card-material-study';
const property = '--card-material-study-frame2-url';
export function attachCardMaterialStudy(root: HTMLElement, options: CardMaterialStudyOptions): CardMaterialStudyController {
  controllers.get(root)?.dispose();
  const document = root.ownerDocument;
  const snapshots = new Map<HTMLElement, Snapshot>();
  let variant = options.variant, disposed = false;
  function checkVariant(value: CardMaterialVariant) {
    if (!['baseline', 'material', 'frame2'].includes(value)) throw new Error('Unknown material study variant');
  }
  checkVariant(variant);
  function frameURL(): string {
    if (!options.frame2OriginalURL) throw new Error('Frame2 requires the exact original local asset URL');
    const base = new URL(document.baseURI), url = new URL(options.frame2OriginalURL, base);
    if (!['http:', 'https:'].includes(url.protocol) || url.origin !== base.origin) throw new Error('Frame2 study expects a same-origin research asset');
    return `url("${url.href.replaceAll('"', '%22').replaceAll('\\', '%5C')}")`;
  }
  if (variant === 'frame2') frameURL();
  function restore(card: HTMLElement, snapshot: Snapshot) {
    snapshot.rim?.remove(); snapshot.rim = null;
    if (snapshot.attribute === null) card.removeAttribute(attribute); else card.setAttribute(attribute, snapshot.attribute);
    if (snapshot.property) card.style.setProperty(property, snapshot.property, snapshot.priority);
    else card.style.removeProperty(property);
  }
  function paint(card: HTMLElement) {
    let snapshot = snapshots.get(card);
    if (!snapshot) {
      snapshot = { attribute: card.getAttribute(attribute), property: card.style.getPropertyValue(property), priority: card.style.getPropertyPriority(property), rim: null };
      snapshots.set(card, snapshot);
    }
    if (variant === 'baseline') { restore(card, snapshot); return; }
    card.setAttribute(attribute, variant);
    if (variant === 'frame2') {
      card.style.setProperty(property, frameURL());
      if (!snapshot.rim) {
        const rim = document.createElement('span'); rim.className = 'card-material-study-rim';
        rim.setAttribute('aria-hidden', 'true'); rim.inert = true;
        card.append(rim); snapshot.rim = rim;
      }
    } else {
      snapshot.rim?.remove(); snapshot.rim = null;
      if (snapshot.property) card.style.setProperty(property, snapshot.property, snapshot.priority);
      else card.style.removeProperty(property);
    }
  }
  function refresh() {
    if (disposed) return;
    for (const [card, snapshot] of snapshots) if (!root.contains(card)) { restore(card, snapshot); snapshots.delete(card); }
    root.querySelectorAll<HTMLElement>('.hand-cards [data-ui="play-card"]').forEach(paint);
  }
  const observer = new MutationObserver(refresh);
  // Preserve source occurrence attributes and stable root; root owns rerenders.
  // The tactile ghost clones our inert attribute/rim/style with the live DOM.
  options.cancelInteractions(); refresh();
  observer.observe(root, { childList: true, subtree: true });
  const controller: CardMaterialStudyController = {
    refresh,
    setVariant(next) {
      if (disposed) throw new Error('Material study disposed');
      checkVariant(next); if (next === 'frame2') frameURL();
      options.cancelInteractions(); variant = next; refresh();
    },
    dispose() {
      if (disposed) return;
      try { options.cancelInteractions(); }
      finally {
        disposed = true; observer.disconnect();
        for (const [card, snapshot] of snapshots) restore(card, snapshot);
        snapshots.clear(); if (controllers.get(root) === controller) controllers.delete(root);
      }
    },
  };
  controllers.set(root, controller); return controller;
}
