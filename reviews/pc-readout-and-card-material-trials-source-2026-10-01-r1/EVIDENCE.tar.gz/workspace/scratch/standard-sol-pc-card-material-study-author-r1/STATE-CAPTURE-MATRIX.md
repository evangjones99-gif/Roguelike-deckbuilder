# Sequential PC comparison checklist — UNEXECUTED

Use1440x900/zoom100%/DPR1 and exact identical state+scroll for A/B/C. Each cell below needs real captures/measurements, not an author-generated design render. Preserve failures and resource-refused attempts.

| State | Content | Capture/evidence |
| --- | --- | --- |
| Five-card rest | Actual seeded initial hand, including duplicates | Context+150px crops, cost/rules/fonts/geometry/contrast and blank surface mass |
| Mouse hover | Same summon occurrence, same tool occurrence | Live hover+gutter+portrait/material antialiasing, unchanged preview/save |
| Keyboard focus | Same card after Tab/hand region move | Visible focus distinct from neutral frame, full text, Enter equivalence |
| Selected targeted tool | Actual legal selection before commitment | State cue prominence, target ownership/full primary consequence |
| Valid drag | Same exact canonical target UID/deploy zone | Viewport-only active capture, one inert ghost, exact legal cue and pointer anchor |
| Invalid return | Identical outside release and held Escape | Same save, no accidental physical click, original return timing |
| Accepted play | Identical legal release→canonical result | One commit, actual rerender/ghost fade, exact save and appropriate focus |
| Modal Inspect/Return | Same last hovered target comparison | Exact comparison survives native/explicit close, no state drift |
| Reduced motion | Same ordinary paths | No extra transition/decorative motion; cancellation clears ghost/effects |
| Content extremes | Actual definitions/upgrades/long passive/tool text | Earned path preferred; otherwise explicitly diagnostic valid gallery, no shortened control |

Mark each result PASS/FAIL/UNEXECUTED and its scope. Shipping/readability/playability acceptance cannot be inferred from the preceding independent native frame reviews. PC baseline screenshots are pending current runtime window; historical390px R3 image is context only.
