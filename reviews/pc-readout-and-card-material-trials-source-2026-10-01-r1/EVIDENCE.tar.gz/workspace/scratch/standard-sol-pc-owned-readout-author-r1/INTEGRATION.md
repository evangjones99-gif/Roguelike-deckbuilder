This is a new source-only battlefield-layout.ts candidate based on frozen PC R4, not an edit to R4 or ROOT. No TypeScript build, browser or runtime test has been run. Keep the old R4 immutable for comparison. Existing API/types are unchanged; import this one new file into a later distinct source fork only after independent source selection.

At field widths >=960px, intent, Inspect, identity, stats and status rectangles share width=min(actual canonical cell width,240px), centered on that cell's body allocation. At widths <=760px their geometry is byte-formula equivalent to the baseline. Between760 and960px the readout reduction is continuous. Narrow cells <=240px are identical at every width. Cell rectangles, bodyRect, feet, hunter geometry, art scale/anchors, hit intersection, slot order, attack origins, height formula, legal authority and born/dead UID publication are not edited. The existing interpolateCell/projectCell functions already carry all five published readout rectangles through presentation and resize, and the region comparator notices their changes. This is a subset of each static cell's old readouts; it introduces no new static neighboring readout or body intersection. It does not prove the inherited interpolation sweeps or painter alpha bounds.

The same fixed config/height yields unchanged paint/body geometry; legitimate extra text rows can still increase requiredHeight and reposition formations through the existing phase-latched allocation. Do not suppress those rows to keep a target height. This trial changes neither creature proportions nor the small hunter. The visual empty-space/proportion concern remains for a separate trial.

Essential host integration obligation (root owns main.ts): queue measureFieldReadouts whenever positionFieldControls changes a published intent or Inspect width, after placing the rectangles. Existing host queues a measurement on render, new actors and arena-wrap ResizeObserver, but that observer's one sample can occur during an inherited resize interpolation. Later readout narrowing at the end of that interpolation can create a line wrap without another measurement. Measurement must use the final published narrow DOM width, including real Inspect inner padding, never the full actor/cell width. A minimal change can reuse the existing one-RAF fieldMeasureFrame guard:

```ts
// Alongside fieldMeasureFrame (cache by element, not a permanent UID peak):
const publishedReadoutWidths = new WeakMap<HTMLElement, number>();
// Within positionFieldControls, before the actor loop:
let readoutWidthChanged = false;
// Inside the existing place helper, before assigning element.style.width:
if (element.classList.contains('field-intent') || element.classList.contains('field-inspect')) {
  if (publishedReadoutWidths.get(element) !== rect.width) readoutWidthChanged = true;
  publishedReadoutWidths.set(element, rect.width);
}
element.style.width = `${rect.width}px`;
// ...all existing placements and state/identity handling...
// After the actor loop:
if (readoutWidthChanged) measureFieldReadouts();
```

The measurement callback repositions controls after setReadoutMetrics. Widths unchanged by a metrics-only height adjustment do not requeue; this avoids creating a height-measurement feedback loop merely from calling positionFieldControls. Compare cached raw published numbers, not CSSOM style strings: the browser can normalize fractional pixel serialization and make a string comparison appear changed forever. During a width interpolation, the existing single-frame queue may legitimately remeasure changing widths until stable. Cache by actual published width; do not cache a permanent peak and do not discard a held corpse/newborn UID before its existing renderer availability deadline. Keep intent child actual heights and stats.scrollHeight measurement; overflow remains visible at >=12px until the canonical rows grow. Current source CSS already wraps intent spans and large stat numbers. No CSS/budget replacement is proposed in this packet.

Required later evidence: strict matching build; paired1440x900 sparse screenshots and own Inspect pointer/focus hit checks; 1280/1920 and dense3/4/5/6 column widths; long validated numeric stats and compound semantic intentions wrapping after resize; resize during cues with late-born/held-dead identities; measure settlement without infinite requiredHeight growth or a permanent high row count; no-canvas fallback; pointer vs explicit keyboard focus; and supported PC browser/native timing. Earlier narrow-screen evidence remains history, not the current acceptance critical path. Do not relabel this arithmetic as actual runtime tests, visual quality acceptance or AAA craft.
