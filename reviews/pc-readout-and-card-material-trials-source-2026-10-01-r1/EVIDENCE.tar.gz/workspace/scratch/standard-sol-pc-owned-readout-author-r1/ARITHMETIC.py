"""Independent Python forecast of width formulas only; does not run TS or game."""
import json, math
from pathlib import Path
out=Path('/workspace/scratch/standard-sol-pc-owned-readout-author-r1')
def clamp(x):return max(0,min(1,x))
def mix(a,b,t):return a+(b-a)*t
def widths(width,count,side):
    move=clamp((width-800)/140);fold=clamp((width-940)/220);blend=clamp((width-760)/200)
    result=[]
    for slot in range(count):
        if count<=2:
            if side=='ally':
                cw=(width-16-mix(88,120,fold)-16)/2
                center=8+cw/2 if slot==0 else width-8-cw/2
            else:
                cw=(width-16-8*(count-1))/count;center=8+cw/2+slot*(cw+8)
        else:
            row=slot//3;columns=min(3,count-row*3);column=slot%3
            narrow=(width-32)/3;narrowx=8+(width-16)*(column+.5)/columns
            leftcount=math.ceil(count/2);rightcount=count-leftcount;band=(width-152)/2
            wide=(band-8*(leftcount-1))/leftcount;onleft=slot<leftcount
            groupcount=leftcount if onleft else rightcount;groupcolumn=slot if onleft else slot-leftcount
            bandleft=8 if onleft else width/2+68;groupwidth=groupcount*wide+(groupcount-1)*8
            widex=bandleft+(band-groupwidth)/2+wide/2+groupcolumn*(wide+8)
            cw=mix(narrow,wide,move);center=mix(narrowx,widex,move)
        rw=mix(cw,min(cw,240),blend);left=center-rw/2
        assert 0<rw<=cw+1e-9
        assert left>=center-cw/2-1e-9 and left+rw<=center+cw/2+1e-9
        assert abs(left+rw/2-center)<1e-9
        if width<=760 or cw<=240:assert abs(rw-cw)<1e-9
        if width>=960:assert rw<=240+1e-9
        result.append({'slot':slot,'cell_width':cw,'center_x':center,'readout_width':rw,'readout_left':left})
    return result
forecasts=[]
for width in [360,390,760,761,800,959,960,961,1160,1280,1440,1920]:
    for side in ['ally','enemy']:
        for count in range(1,7):forecasts.append({'width':width,'side':side,'count':count,'slots':widths(width,count,side)})
samples=[x for x in forecasts if (x['side']=='enemy' and x['count']==2 and x['width'] in [760,761,959,960,961,1280,1440,1920]) or (x['width']==1440 and x['count'] in [1,3,4,5,6])]
(out/'ARITHMETIC.json').write_text(json.dumps({'status':'PASS width-formula arithmetic assertions only; no TypeScript execution or rendered geometry proof','asserted_context_count':len(forecasts),'representative_forecasts':samples},indent=2)+'\n')
print(json.dumps({'contexts':len(forecasts),'1440_two_enemy':widths(1440,2,'enemy'),'1440_six_enemy':widths(1440,6,'enemy')}))
