import os,json,pathlib,hashlib,resource
OWN=pathlib.Path(__file__).parent
RUN=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-run-r2')
WRAP=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-ROOT-wrapper-r2')
AUTH=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-author-r2')
REVIEW=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-independent-r2')
PIN=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-author-r1/METADATA-INTAKE.json')
ROOT=pathlib.Path('/workspace/Roguelike-deckbuilder')
def metadata(s):return {k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns')}
def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC)
    try:
        s=os.fstat(fd);assert s.st_size<=32768
        b=os.read(fd,32769);assert len(b)==s.st_size and metadata(os.fstat(fd))==metadata(s)
        return b
    finally:os.close(fd)
def H(b):return hashlib.sha256(b).hexdigest()
def control(p):return {'path':str(p),'bytes':os.stat(p).st_size,'sha256':H(read(p)),'metadata':metadata(os.stat(p))}
files=sorted(list(RUN.iterdir())+list(WRAP.iterdir()))
before=[control(p) for p in files]
c=json.loads(read(RUN/'CONTROL-RECEIPTS.json'));a=json.loads(read(RUN/'AFTER.json'));b=json.loads(read(RUN/'BEFORE.json'));p=json.loads(read(PIN))
assert c['sourceSHA256']==H(read(AUTH/'immutable_pack_hint.py'))=='680b7541bad52071827e9894a4d26b875db2fb578bc4b5c1beb9eb5b06dcdc68'
assert c['pinSHA256']==H(read(PIN))=='0743769386ae0db3829b6f9aa8363e646f211018cb850a4c6eee5bd87b08c965'
assert c['acceptance']==json.loads(read(REVIEW/'INDEPENDENT-ACCEPTANCE.json'))
assert c['acceptance']['reviewSHA256']==H(read(c['acceptance']['reviewPath']))
for k in ('priorPushConfirmed','exclusiveKnownRepoWritersHeld','repositoryMaintenanceHeld','noUnknownAffectedWriter','noUnknownAffectedLockOwner','noHeavyRuntimeConcurrent'):assert c['declaration'][k] is True
assert c['declaration']['confirmedPush']=='e6752a19980472ab338a88eae026c8988d43ac55'
assert b['target']==a['target'] and b['target']['metadata']==p['metadata'] and b['target']['xattrs']==p['xattrs']
assert b['locks']==a['locks'] and a['ownTargetFDClosed'] and not a['packBodiesRead'] and not a['freshWholePackSHA'] and not a['ownToolPackByteWrites']
assert json.loads(read(RUN/'ARMED.json'))=={'advice':'POSIX_FADV_DONTNEED','fdO_RDONLY':True,'length':0,'offset':0,'oneCallOnly':True,'target':p['path']}
assert json.loads(read(RUN/'RETURNED.json'))=={'errno':0,'reclaimGuaranteed':False,'returnedWithoutException':True}
assert json.loads(read(RUN/'FAILURE-SLOT.json'))=={'status':'reserved; no failure recorded'}
assert json.loads(read(WRAP/'RESULT.json'))['exitCode']==0
trace=[json.loads(line) for line in read(WRAP/'stderr.log').decode().splitlines()]
mem=[row for row in trace if row['phase']=='lightweight-admission-before-assertions']
assert len(mem)==6 and all(x['requiredBytes']==92274688 and x['headroomBytes']>=92274688 for x in mem)
assert len({x['memoryEvents'] for x in mem})==1
assert len(a['samples'])==3 and all(s['cgroup']['memory.events']==mem[0]['memoryEvents'] for s in a['samples'])
assert mem[0]['headroomBytes']==176545792 and a['samples'][-1]['headroom']==794333184
fd=None;parents=[]
try:
    flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC;parents.append(os.open('/',flags));chain=[]
    target=pathlib.Path(p['path'])
    for name in target.parent.parts[1:]:
        q=os.open(name,flags,dir_fd=parents[-1]);parents.append(q);s=os.fstat(q)
        chain.append({'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid})
    assert chain==p['parentChain']
    fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=parents[-1])
    fresh=metadata(os.fstat(fd));attrs={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)}
    assert fresh==p['metadata']==metadata(os.stat(target.name,dir_fd=parents[-1],follow_symlinks=False)) and attrs==p['xattrs']
finally:
    if fd is not None:os.close(fd)
    for f in reversed(parents):os.close(f)
after=[control(p) for p in files];assert after==before
docs=[]
for file in ('AGENTS.md','docs/PRODUCTION.md','docs/CONTINUATION.md'):
    path=ROOT/file;fd=os.open(path,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW);h=hashlib.sha256()
    try:
        while chunk:=os.read(fd,4096):h.update(chunk)
    finally:os.close(fd)
    docs.append({'path':str(path),'bytes':os.stat(path).st_size,'sha256':h.hexdigest()})
result={'schema':1,'qualification':'PASS independently inspected recorded metadata-only single-advice execution; no fresh body integrity/reclaim guarantee','originalReceiptsUnchanged':before,'sourceSHA256':c['sourceSHA256'],'pinSHA256':c['pinSHA256'],'ownFreshPackMetadata':fresh,'ownFreshPackXattrs':attrs,'ownDescriptorsClosed':True,'ownAdviceCalls':0,'ownTargetBodyBytesRead':0,'firstObservedHeadroom':mem[0]['headroomBytes'],'lastInternalObservedHeadroom':a['samples'][-1]['headroom'],'intervalChange':a['samples'][-1]['headroom']-mem[0]['headroomBytes'],'intervalExclusiveCausation':False,'memoryEventsUnchanged':True,'guardTraceCount':len(mem),'peakSampledCurrentExecHWM':max(s['ownMemory']['currentExecBytes']['VmHWM'] for s in a['samples']),'documentsReviewed':docs,'ownMaxRSSKiBHistorical':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
out=(json.dumps(result,indent=2)+'\n').encode();assert sum(f.stat().st_size for f in OWN.iterdir())+len(out)<24576
with open(OWN/'RESULT.json','xb') as f:f.write(out)
print(json.dumps({'status':'PASS recorded execution and fresh metadata','receiptFiles':len(files),'ownBytes':sum(f.stat().st_size for f in OWN.iterdir())}))
