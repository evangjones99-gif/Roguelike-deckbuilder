"""Exact old source import + source-derived argparse prefix ONLY; never main/guard."""
import sys
sys.dont_write_bytecode=True
import os,json,resource,hashlib,importlib.util,pathlib
SOURCE='/workspace/scratch/git-immutable-pack-cache-hint-author-r1/immutable_pack_hint.py'
OUT='/workspace/scratch/git-immutable-pack-cache-hint-author-r2/CLI-BOOTSTRAP-DIAGNOSTIC.json'
def metrics():
 s=pathlib.Path('/proc/self/status').read_text();v={l.split(':',1)[0]:l.split(':',1)[1].strip()for l in s.splitlines()if l.startswith(('VmSize:','VmHWM:','VmRSS:','VmPeak:'))}
 c=pathlib.Path('/sys/fs/cgroup');current=int((c/'memory.current').read_text());maximum=int((c/'memory.max').read_text())
 return {'ruMaxRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'status':v,'headroomBytes':maximum-current,'memoryEvents':(c/'memory.events').read_text()}
before=metrics();spec=importlib.util.spec_from_file_location('old_pack_proposal_import_only',SOURCE);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);afterImport=metrics()
import ast
raw=pathlib.Path(SOURCE).read_bytes();tree=ast.parse(raw);main=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='main');prefix=[]
for node in main.body:
 if isinstance(node,ast.Expr)and isinstance(node.value,ast.Call)and isinstance(node.value.func,ast.Name)and node.value.func.id=='guard':break
 prefix.append(node)
assert len(prefix)==4 and isinstance(prefix[-1],ast.Assign) and isinstance(prefix[-1].value,ast.Call)and prefix[-1].value.func.attr=='parse_args'
# Actual supplied CLI path values; argparse parses strings but reads no files.
sys.argv=[SOURCE,'--declaration','/workspace/scratch/git-immutable-pack-cache-hint-ROOT-DECLARATION-r1.json','--acceptance','/workspace/scratch/git-immutable-pack-cache-hint-independent-r1/INDEPENDENT-ACCEPTANCE.json']
ns=module.__dict__.copy();exec(compile(ast.Module(body=prefix,type_ignores=[]),SOURCE+' [argparse-only-prefix]','exec'),ns);afterArgparse=metrics()
r={'scope':'Actual R1 source imported and exact four source-derived argparse statements executed only. main/guard/Receipts/target open/advice never called. Diagnostics measure their own import/AST instrumentation overhead too; not a repeated failed advice invocation.','sourceSHA256':hashlib.sha256(raw).hexdigest(),'sourceBytes':len(raw),'before':before,'afterExactImport':afterImport,'afterExactArgparsePrefix':afterArgparse,'prefixStatements':len(prefix),'argv':sys.argv,'parsedArgs':vars(ns['args']),'pythonExecutable':sys.executable,'pythonExecutableResolved':os.path.realpath(sys.executable),'pythonVersion':sys.version,'pythonFlags':repr(sys.flags),'ownPID':os.getpid(),'targetOpens':0,'adviceCalls':0,'packBodyReads':0,'mainCalls':0,'guardCalls':0,'moduleBodyLimits':{'controlBytes':32768,'procLocksBytes':module.LIMIT,'receiptBytes':49152,'additionalAddressRoomBytes':8*1024**2},'qualification':'R1 failed runtime value was not recorded. This new measurement does not reconstruct it or prove every future bootstrap fits.'}
with open(OUT,'x')as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r))
