import ast, os, json, hashlib, pathlib, resource
OWN=pathlib.Path(__file__).parent
AUTH=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-author-r2')
ORIGINAL=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-author-r1')
def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC)
    try:
        s=os.fstat(fd); assert s.st_size<=32768
        b=os.read(fd,32769); assert len(b)==s.st_size and os.fstat(fd)==s
        return b
    finally: os.close(fd)
def digest(b):return hashlib.sha256(b).hexdigest()
def meta(s):return {k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns')}
def resource_snapshot():
    c=pathlib.Path('/sys/fs/cgroup');v={n:(c/n).read_text() for n in ('memory.current','memory.max','memory.events')}
    v['headroom']=int(v['memory.max'])-int(v['memory.current']);v['maxRSSKiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    with open('/proc/self/status','rb') as f: status=f.read(8193)
    assert len(status)<=8192
    v['processStatus']={l.split(':')[0]:int(l.split()[1])*1024 for l in status.decode('ascii').splitlines() if l.startswith(('VmHWM:','VmRSS:','VmSize:'))}
    print(json.dumps({'admissionObservation':v}),flush=True)
    assert v['headroom']>=88*1024**2 and v['processStatus']['VmHWM']<=24*1024**2 and v['processStatus']['VmRSS']<=24*1024**2
    return v
initial=resource_snapshot()
paths=sorted(p for p in AUTH.iterdir() if p.is_file())
before={str(p):{'sha256':digest(read(p)),'metadata':meta(os.stat(p))} for p in paths}
for manifest in ('FROZEN-FILES.json',):
    for r in json.loads(read(AUTH/manifest))['files']:
        b=read(AUTH/r['path']);assert len(b)==r['bytes'] and digest(b)==r['sha256']
source=read(AUTH/'immutable_pack_hint.py');assert digest(source)=='680b7541bad52071827e9894a4d26b875db2fb578bc4b5c1beb9eb5b06dcdc68'
syntax=ast.parse(source)
calls=[n for n in ast.walk(syntax) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='os' and n.func.attr=='posix_fadvise']
assert len(calls)==1
assert ast.unparse(calls[0])=='os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)'
oldtree=ast.parse(read(ORIGINAL/'immutable_pack_hint.py'))
unchanged=['require','sha','encoded','meta','identity','anchor','stable','control','locks','observe','Receipts']
oldnodes={n.name:ast.dump(n,include_attributes=False) for n in oldtree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
newnodes={n.name:ast.dump(n,include_attributes=False) for n in syntax.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
for name in unchanged: assert newnodes[name]==oldnodes[name]
pin=json.loads(read(ORIGINAL/'METADATA-INTAKE.json'));target=pathlib.Path(pin['path'])
fds=[];chain=[];fd=None
try:
    flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    fds.append(os.open('/',flags))
    for name in target.parent.parts[1:]:
        parent=fds[-1];child=os.open(name,flags,dir_fd=parent);fds.append(child)
        s=os.fstat(child);t=os.stat(name,dir_fd=parent,follow_symlinks=False)
        row={'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid}
        assert (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)==(t.st_dev,t.st_ino,t.st_mode,t.st_uid,t.st_gid)
        chain.append(row)
    assert chain==pin['parentChain']
    fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=fds[-1])
    pack_before=meta(os.fstat(fd));attrs={n:os.getxattr(fd,n).hex() for n in sorted(os.listxattr(fd))}
    assert pack_before==pin['metadata']==meta(os.stat(target.name,dir_fd=fds[-1],follow_symlinks=False)) and attrs==pin['xattrs']
    pack_after=meta(os.fstat(fd));assert pack_after==pack_before
finally:
    if fd is not None:os.close(fd)
    for f in reversed(fds):os.close(f)
prior=[]
for row in pin['priorControlReceipts']:
    b=read(row['path']);assert len(b)==row['bytes'] and digest(b)==row['sha256']
    prior.append({'path':row['path'],'sha256':digest(b),'bytes':len(b)})
failure=json.loads(read('/workspace/scratch/git-closed-cache-hint-run-r1/FAILURE-SLOT.json'))
assert failure['errno']==13 and failure['completedReturnedHints']==0 and failure['pendingOID'] is None
after={str(p):{'sha256':digest(read(p)),'metadata':meta(os.stat(p))} for p in paths};assert after==before
final=resource_snapshot()
result={'schema':1,'scope':'Independent AST and anchored metadata-only review; no tool import/advice/target body read/Git/runtime','sourceSHA256':digest(source),'sourceBytes':len(source),'pinSHA256':digest(read(ORIGINAL/'METADATA-INTAKE.json')),'authorControlsBeforeAfter':before,'packBefore':pack_before,'packAfter':pack_after,'packXattrs':attrs,'parentChain':chain,'allOwnDescriptorsClosed':True,'oneAdviceCallSite':True,'structurallyUnchangedFunctions':unchanged,'targetBytesRead':0,'adviceCallsExecuted':0,'priorControls':prior,'oldFailure':{'errno':failure['errno'],'completedReturnedHints':failure['completedReturnedHints'],'pendingOID':failure['pendingOID']},'resources':[initial,final],'limitations':['No exact historical or fresh whole-pack SHA known','No global process/reader/writer/lock exclusion proof','Static review is not runtime admission or cache recovery']}
b=(json.dumps(result,indent=2)+'\n').encode()
assert sum(p.stat().st_size for p in OWN.iterdir())+len(b)<=24576
with open(OWN/'STATIC-RESULT.json','xb') as f:f.write(b)
print(json.dumps({'status':'PASS independent static intake','rows':len(paths),'maxRSSKiB':final['maxRSSKiB'],'ownBytes':sum(p.stat().st_size for p in OWN.iterdir())}))
