import os,json,hashlib,stat
from pathlib import Path
ROOT=Path('/workspace/scratch')
OUT=ROOT/'standard-sol-command-guidance-gameplay-correctness-independent-r1'
c=Path('/sys/fs/cgroup');head=int((c/'memory.max').read_text())-int((c/'memory.current').read_text())
assert head>=570425344, 'fresh32+512 refused'
pins={}
def read(p):
    p=Path(p); fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
    try:
        st=os.fstat(fd);assert stat.S_ISREG(st.st_mode) and st.st_size<=1048576
        chunks=[]
        while True:
            b=os.read(fd,65536)
            if not b:break
            chunks.append(b)
        body=b''.join(chunks);assert len(body)==st.st_size
        pins[str(p)]={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
        return body
    finally:os.close(fd)
def j(p):return json.loads(read(p))
def digest(m):return hashlib.sha256(json.dumps(dict(sorted(m.items())),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def amap(a):
    assert len({x['path'] for x in a})==len(a)
    return {x['path']:x['sha256'] for x in a}
manifest=j(ROOT/'standard-sol-command-guidance-caller-author-r1/MANIFEST.json')
assert pins[str(ROOT/'standard-sol-command-guidance-caller-author-r1/MANIFEST.json')]['sha256']=='85b8e670b7b5d2768c72ae8026979d7ae27f25bade56bc0e26254563f036432d'
for m in manifest['members']:
    p=ROOT/'standard-sol-command-guidance-caller-author-r1'/m['path'];read(p)
    assert pins[str(p)]=={'bytes':m['bytes'],'sha256':m['sha256']}
allph={}; rawph={}
for phase,freeze in [('baseline','first-five-opening-preview-identity-runtime-freeze-root-r7.json'),('candidate','first-five-opening-command-guidance-runtime-freeze-root-r8.json')]:
    p=ROOT/('standard-sol-command-guidance-actual-'+phase+'-r1');f=j(ROOT/freeze);stage=Path(f['stage'])
    a=j(p/'BYTE-AUDIT-before.json');b=j(p/'BYTE-AUDIT-after.json');served=j(p/'SERVED-BYTE-AUDIT.json')
    assert a['inputs']==b['inputs'] and a['outputs']==b['outputs']
    assert amap(a['inputs'])==f['inputs'] and amap(a['outputs'])==f['outputs'] and amap(served['served'])==f['outputs']
    assert len(f['inputs'])==87 and len(f['outputs'])==56 and digest(f['inputs'])==f['sourceDigest'] and digest(f['outputs'])==f['outputsDigest']
    assert served['sourceDigest']==f['sourceDigest'] and served['outputsDigest']==f['outputsDigest']
    # Fresh small source/core only. Large retained media streams are not repeated.
    fresh=[]
    for name,sha in f['inputs'].items():
        if name.startswith('public/') or name=='desktop/icon.png':continue
        read(stage/name);assert pins[str(stage/name)]['sha256']==sha;fresh.append(name)
    assert len(fresh)==35
    core=[]
    for name,sha in f['outputs'].items():
        if name.startswith(('art/','audio/')):continue
        read(stage/'dist'/name);assert pins[str(stage/'dist'/name)]['sha256']==sha;core.append(name)
    assert len(core)==5
    prov=j(stage/'dist/build-provenance.json');assert prov['hashes']==f['inputs'] and prov['sourceDigest']==f['sourceDigest']
    v=j(p/'VISUAL-RESULT.json');progress=j(p/'VISUAL-PROGRESS.json');r=j(p/'RESULT.json');ad=j(p/'ADMISSION.json');credit=j(p/'INSIDE-PHASE-ACCOUNTING.json');launch=j(p/'OWNED-LAUNCH.json');comp=j(p/'CANONICAL-COMPARISON.json')
    steps=[json.loads(x) for x in read(p/'STEPS.jsonl').splitlines()];life=[json.loads(x) for x in read(p/'LIFECYCLE.jsonl').splitlines()];read(p/'EXECUTION.log')
    assert v['stepObservations']==steps and len(steps)==26 and len(v['actions'])==24
    assert v['sourceDigest']==f['sourceDigest'] and v['outputsDigest']==f['outputsDigest'] and v['completed'] and v['browser']==v['server']=='CLOSED'
    rows=r['samples'];initial=r['initial'];final=r['final'];work=896*1048576;reserve=512*1048576
    assert ad['initial']==initial and ad['work']==work and ad['reserve']==reserve and initial['headroom']>=work+reserve and initial['free']>=64*1048576
    assert credit['sameOuterAdmission'] and not credit['freshAdmission'] and credit['work']==work and credit['reserve']==reserve and credit['spent']+credit['remaining']==work
    for q in rows:
        assert q['delta']==q['current']-initial['current'] and q['headroom']==q['maximum']-q['current']
    resource=lambda q:q['maximum']==initial['maximum'] and q['headroom']>=reserve and q['current']-initial['current']<=work and q['free']>=1048576
    checks={'sampled_resources':bool(rows) and all(resource(q) for q in rows),'final_resources':resource(final),'memory_events_unchanged':r['memory_events_before']==r['memory_events_after'],'whole_within120':r['whole_seconds']<=120,'no_observed_tracked_live_descendants':all(q['state']=='Z' for q in r['post_wait_descendants'].values()) and r['live_remaining']=={},'driver_rc0':r['exit_code']==0,'no_lifecycle_or_cleanup_failure':r['failure'] is None and not r['cleanup_errors']}
    assert checks==r['checks'] and all(checks.values()) and r['normal_wait']
    assert life[-1]['event']=='normal browser and server close' and not life[-1]['errors'] and life[-1]['wholeElapsedMs']<v['wholeElapsedMs']<=90000
    assert str(launch['pid']) in r['owned_observed'] and launch['identities'][str(launch['pid'])]['starttime']==r['owned_observed'][str(launch['pid'])]['starttime']
    assert r['tracked_zombies']==r['post_wait_descendants']
    for pid,q in r['post_wait_descendants'].items():assert q['starttime']==r['owned_observed'][pid]['starttime'] and q['state']=='Z'
    raw={};states={}
    for name,key in [('INITIAL-ACTUAL-SAVE.json','initialRawSHA'),('FIRST-COMMAND-ACTUAL-SAVE.json','firstCommandRawSHA'),('FINAL-ACTUAL-SAVE.json','finalRawSHA')]:
        w=j(p/name);assert w['observedOnly'];raw[key]=w['raw'];states[key]=json.loads(w['raw']);assert hashlib.sha256(w['raw'].encode()).hexdigest()==comp[key]
    assert v['canonicalComparison']=={k:val for k,val in comp.items() if k not in ['observedOnly','sourceDigest','outputsDigest']}
    si,sc,sf=[states[k] for k in ['initialRawSHA','firstCommandRawSHA','finalRawSHA']]
    assert si['rng']==sc['rng']==sf['rng']==1242560205 and si['seed']==sc['seed']==sf['seed']==9592029
    assert si['hand']==['survey','sunder','scour','ironward','cairnhound'] and sc['hand']==['survey','sunder','scour','ironward']
    assert sc['allies'][0]['uid']=='a3' and sc['allies'][0]['acted'] and sc['allies'][0]['hp']==7 and sc['enemies'][1]['uid']=='e2' and sc['enemies'][1]['hp']==2 and sc['energy']==4
    assert sc['stats']['cardsPlayed']==1 and sc['stats']['damageDealt']==5 and sc['discard']==[]
    assert sf['phase']=='battle' and sf['turn']==2 and sf['energy']==5 and sf['hp']==64 and sf['allies'][0]['acted'] and sf['enemies'][0]['uid']=='e1' and sf['enemies'][0]['hp']==16 and len(sf['enemies'])==1
    assert sf['stats']['cardsPlayed']==1 and sf['stats']['damageDealt']==7 and sf['hand']==['ironward','fenstalker','sutures','briarcolossus','scour']
    def step(label):return next(q for q in steps if q['label']==label)
    bound=step('actual Cairn ready with Survey first');assert bound['saveSHA']==comp['boundRawSHA'] and any(q['unit']=='a3' and 'Ready' in q['aria'] for q in bound['actors'])
    for label in ['first genuine Cairn command','earned reduced-motion nonterminal Thrall kill']:
        act=next(q for q in v['actions'] if q['label']==label);assert act['source']=='a3' and act['target']=='e2'
        assert any(e['type']=='keydown' and e['key']=='Enter' and e['trusted'] for e in act['events']) and any(e['type']=='click' and e['trusted'] for e in act['events'])
        owner=step(label+' actual legal commit owner');assert owner['active']['unit']=='e2' and not owner['active']['disabled'] and any(q['unit']=='e2' for q in owner['legalTargets'])
    for act in v['actions']:
        assert all(e.get('trusted') for e in act.get('events',[]))
        if 'key' in act:assert any(e['type']=='keydown' and e.get('key')==act['key'] for e in act['events'])
        if 'beforeSHA' in act and act['label'] not in ['accept fixed seed default Initiate','ordinary native Cairn index4 binding','first genuine Cairn command','ordinary native legal End turn with all commands spent','earned reduced-motion nonterminal Thrall kill']:assert act['beforeSHA']==act['afterSHA']
    post=step('first genuine Cairn command first post-native-Enter observation');assert post['saveSHA']==comp['firstCommandRawSHA'] and any(q['unit']=='a3' and 'Command spent' in q['aria'] for q in post['actors'])
    issued='Command issued: '+v['precommandPreview']['text']
    if phase=='candidate':
        for label in ['first genuine Cairn command first post-native-Enter observation','native Order-preview reading','native Inspect-readout hover','actual empty-field reading']:
            q=step(label);assert q['saveSHA']==comp['firstCommandRawSHA'] and q['preview']['text']==issued and q['preview']['kind']=='issued-command'
    else:assert post['preview']['kind']!='issued-command' and post['preview']['text']=='Forbidden Survey: Draw 2 cards.'
    for label in ['deliberate legal Survey hover','deliberate native H to actual Survey hand focus']:
        q=step(label);assert q['saveSHA']==comp['firstCommandRawSHA'] and q['preview']['kind']=='consequence' and q['preview']['text']=='Forbidden Survey: Draw 2 cards.'
    selected=step('real selected Sunder and visible Cancel');assert selected['selectedCards'][0]['card']=='sunder' and selected['cancel']
    cancel=step('cancel real Sunder without Pause');assert cancel['saveSHA']==comp['firstCommandRawSHA'] and not cancel['selectedCards'] and not cancel['dialogOpen']
    turn=step('actual no-Scour turn2 draw and enemy response');assert turn['saveSHA']==comp['turn2RawSHA'] and turn['nativeReducedMotion']
    assert any(q['unit']=='a3' and 'Ready' in q['aria'] for q in turn['actors']) and any(q['unit']=='e2' and '2 of 7' in q['aria'] for q in turn['actors'])
    reduced=step('reduced-motion ordinary post-command preview');assert reduced['saveSHA']==comp['finalRawSHA'] and reduced['nativeReducedMotion'] and reduced['preview']['kind']=='consequence' and reduced['preview']['text']=='Iron Ward: hunter: gains 7 block'
    for x in v['captures']:
        st=Path(x['path']).stat();assert st.st_size==x['bytes']
    allph[phase]={'sourceDigest':f['sourceDigest'],'outputsDigest':f['outputsDigest'],'inputs':87,'outputs':56,'freshSmallSourceCount':len(fresh),'freshCoreCount':len(core),'resources':{'recomputedChecks':checks,'samples':len(rows),'maxDelta':max(q['current']-initial['current'] for q in rows+[final]),'minHeadroom':min(q['headroom'] for q in rows+[final]),'initialHeadroom':initial['headroom'],'wholeSeconds':r['whole_seconds']},'canonicalComparison':comp,'ownedLaunch':launch,'trackedZombies':r['tracked_zombies'],'firstIssued':v['firstIssued'],'actions':len(v['actions']),'steps':len(steps),'captureMetadataOnly':v['captures']}
    rawph[phase]=raw
assert rawph['baseline']==rawph['candidate']
for key in ['initialRawSHA','boundRawSHA','firstCommandRawSHA','turn2RawSHA','finalRawSHA']:assert allph['baseline']['canonicalComparison'][key]==allph['candidate']['canonicalComparison'][key]
hwm=int(next(x for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmHWM:')).split()[1])*1024;assert hwm<=32*1048576
result={'decision':'PASS_FIXED_NATIVE_UI_COMMAND_CORRECTNESS','freshSourceAdmissionHeadroom':head,'actualOwnVmHWM':hwm,'phases':allph,'rawInitialCommandFinalByteEqual':True,'intermediateHashesEqual':True,'limitations':['no independent fresh large media stream or PNG-body/image judgment','intermediate bound/turn2 raw bodies not retained; hashes and DOM observations only','API observation latency; no dedicated trusted pointermove stream','no universal unobserved escape proof; retained zombies nonlive/unreaped','no300/humanfun/terminal/contactpixel/reload/hardware/native acceptance','inherited tactile/audio authorship; distinct ROOT command delta review']}
(OUT/'INDEPENDENT-RECOMPUTATION.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'READ-PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'decision':result['decision'],'VmHWM':hwm,'resources':{k:v['resources'] for k,v in allph.items()},'readPins':len(pins)}))
