import os,json,hashlib,shutil
from pathlib import Path
root=Path('/workspace/Roguelike-deckbuilder');stage=Path('/workspace/scratch/first-five-opening-command-guidance-stage-r8');packet=Path('/workspace/scratch/root-command-guidance-r8-promotion-r1');packet.mkdir(mode=0o700)
freeze=json.loads(Path('/workspace/scratch/first-five-opening-command-guidance-runtime-freeze-root-r8.json').read_text());assert freeze['sourceDigest']=='7cde12170459c48e771c2192e2d25be6ac7a366ce0c63ed4ca484be488362c4e'
old=json.loads((root/'dist/build-provenance.json').read_text());assert old['sourceDigest']=='f08272bd35c8da907190e95f66b8c24d57a17a5a8b01ff0af247279380fe120a'
def body(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  st=os.fstat(fd);out=b''
  while b:=os.read(fd,65536):out+=b
  assert os.fstat(fd)==st
  return out
 finally:os.close(fd)
def sha(p):return hashlib.sha256(body(p)).hexdigest()
for rel,h in old['hashes'].items():assert sha(root/rel)==h,rel
for rel,h in freeze['inputs'].items():assert sha(stage/rel)==h,rel
for rel,h in freeze['outputs'].items():assert sha(stage/'dist'/rel)==h,rel
changes=[rel for rel,h in freeze['inputs'].items() if old['hashes'].get(rel)!=h];assert all(x.startswith('src/') for x in changes)
assert set(changes)=={'src/main.ts'}
# Preserve exact old source and non-media build bodies; all unchanged public media
# remain in the current tree/Git and have their exact old output identities below.
oldoutputs={f.relative_to(root/'dist').as_posix():sha(f) for f in sorted((root/'dist').rglob('*')) if f.is_file()}
for rel in changes:
 if (root/rel).exists():
  q=packet/'old-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(body(root/rel))
for rel,h in oldoutputs.items():
 if (root/'public'/rel).is_file():assert sha(root/'public'/rel)==h,rel
 else:
  q=packet/'old-build'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(body(root/'dist'/rel))
for rel in changes:
 target=root/rel;tmp=target.with_name(target.name+'.command-r8-tmp');assert not tmp.exists()
 data=body(stage/rel)
 with tmp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.replace(tmp,target)
for rel,h in freeze['inputs'].items():assert sha(root/rel)==h,rel
# Preserve already-used targeted regression tests as production regression tools.
tests=['tests/compact-intent.test.ts','tests/audio-presentation-delay.test.ts'];testpins={}
for rel in tests:
 source=body(stage/rel);target=root/rel
 if target.exists():assert body(target)==source
 else:
  with target.open('xb') as f:f.write(source);f.flush();os.fsync(f.fileno())
 testpins[rel]=hashlib.sha256(source).hexdigest()
r={'status':'Exact source promoted; ROOT strict build/map verification pending; unchanged pure rules111 retained; actual affected interaction verified','producerJudgment':'Scoped first-five issued-command attribution promotion conditional on separately sealed actual gameplay/visual and technical acceptance. Native actual source-target damage survives automatic focus and passive reading; deliberate new previews replace it; genuine cancel and motion-off ordinary preview remain; all five opaque checkpoints match baseline. Only main differs from current R7; pure rules/tests unchanged. No general-game/human-fun/native/pixel-art acceptance.','baselineRuntime':old['sourceDigest'],'baselineCommit':'431eeb280d92d5e545ee603f15f4b5f87ea247fd','candidateRuntime':freeze['sourceDigest'],'candidateOutputsDigest':freeze['outputsDigest'],'sourceChanges':changes,'oldInputs':old['hashes'],'oldOutputs':oldoutputs,'newInputs':freeze['inputs'],'regressionTests':testpins,'preservation':'Old source/nonmedia build bodies copied; exact unchanged media remain in public and Git. Historical releases/stages/images/reviews/data retained. Atomic source replacement; public/trace/old stage bodies never written.'}
(packet/'PROMOTION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['oldInputs','oldOutputs','newInputs']}))
