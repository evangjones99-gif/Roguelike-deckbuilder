"""Original native front-three-quarter Bone Thrall study; no raster inputs or game changes."""
import os,json,struct,zlib,hashlib,time,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(32*1048576,32*1048576))
ROOT='/workspace/scratch/standard-sol-bone-thrall-pixel-assets-author-r1'
PAL=[(0,0,0),(14,20,23),(27,37,42),(43,58,62),(65,81,82),(77,91,88),(108,122,111),(149,158,137),(190,196,164),(57,91,91),(88,125,117),(135,173,145),(194,217,170),(85,75,59),(125,107,75),(213,176,98)]
# Original front three-quarter skeletal anatomy. Polygons/limbs/ribs are drawn per pose.
POSES=[
 dict(name='idle0',role='front-oblique hunched servant; knees bent and claws hanging forward',feet=[[25,61],[41,57]],
 skull=[(30,8),(38,6),(44,10),(45,16),(42,21),(35,23),(29,20),(27,14)],jaw=[(30,20),(34,22),(41,20),(42,24),(38,27),(32,26),(29,23)],
 sockets=[[(29,13),(33,12),(35,15),(32,17),(29,17)],[(38,12),(42,13),(42,16),(39,17)]],nose=[(35,17),(37,18),(36,21),(34,20)],crack=[(35,8),(34,11),(36,13),(35,15)],teeth=[[32,22],[34,23],[37,23],[39,22]],
 torso=[(29,27),(35,25),(42,26),(46,31),(43,38),(38,42),(32,40),(27,35),(26,30)],pelvis=[(31,40),(38,40),(43,43),(40,47),(37,46),(34,44),(30,48),(27,44)],
 bones=[(4,[(40,43),(43,47),(42,51),(44,56),(41,57),(39,51),(39,47)]),(4,[(42,27),(46,27),(50,33),(48,39),(46,38),(46,33)]),(6,[(28,42),(32,44),(30,49),(27,52),(28,57),(25,60),(23,59),(24,53),(27,49)]),(6,[(27,27),(30,29),(26,34),(24,39),(25,43),(22,44),(21,38),(23,32)])],
 ribs=[(7,[(33,29),(29,28),(27,31),(31,33)]),(7,[(33,33),(29,32),(28,35),(32,37)]),(6,[(34,37),(31,37),(32,40)]),(5,[(37,29),(41,29),(43,32),(39,34)]),(5,[(37,34),(41,34),(41,37),(38,39)])],sternum=[(35,27),(35,39)],spine=[(40,24),(39,40)],
 claws=[[(22,42),(19,45),(18,48)],[(24,43),(23,47),(21,49)],[(25,43),(27,46),(26,49)],[(47,37),(49,41),(48,44)],[(48,37),(51,39),(52,43)],[(46,38),(46,42),(44,44)]],toes=[[(25,59),(21,61),(28,61)],[(41,55),(38,57),(44,57)]],impact=[18,48]),
 dict(name='idle1',role='hips settle and near claw curls while ribcage leans toward the player',feet=[[25,61],[42,57]],
 skull=[(29,9),(37,7),(43,11),(44,17),(41,22),(34,24),(28,21),(26,15)],jaw=[(29,21),(33,23),(40,21),(41,25),(37,28),(31,27),(28,24)],
 sockets=[[(28,14),(32,13),(34,16),(31,18),(28,18)],[(37,13),(41,14),(41,17),(38,18)]],nose=[(34,18),(36,19),(35,22),(33,21)],crack=[(34,9),(33,12),(35,14),(34,16)],teeth=[[31,23],[33,24],[36,24],[38,23]],
 torso=[(28,28),(34,26),(41,27),(45,32),(42,39),(37,43),(31,41),(26,36),(25,31)],pelvis=[(31,41),(38,41),(43,44),(40,48),(37,47),(34,45),(30,49),(27,45)],
 bones=[(4,[(40,44),(44,47),(43,51),(45,56),(42,57),(40,52),(40,48)]),(4,[(41,28),(45,28),(49,34),(47,40),(45,39),(45,34)]),(6,[(28,43),(32,45),(30,50),(26,53),(28,57),(25,60),(23,59),(24,54),(27,50)]),(6,[(26,28),(29,30),(25,35),(23,40),(25,43),(23,45),(20,40),(22,33)])],
 ribs=[(7,[(32,30),(28,29),(26,32),(30,34)]),(7,[(32,34),(28,33),(27,36),(31,38)]),(6,[(33,38),(30,38),(31,41)]),(5,[(36,30),(40,30),(42,33),(38,35)]),(5,[(36,35),(40,35),(40,38),(37,40)])],sternum=[(34,28),(34,40)],spine=[(39,25),(38,41)],
 claws=[[(23,43),(20,46),(21,49)],[(24,44),(24,48),(22,50)],[(25,43),(28,46),(27,48)],[(46,38),(48,42),(47,45)],[(47,38),(50,40),(51,44)],[(45,39),(45,43),(43,45)]],toes=[[(25,59),(21,61),(28,61)],[(42,55),(39,57),(45,57)]],impact=[21,49]),
 dict(name='anticipation',role='shoulders coil and near claw draws across ribs above loaded knees',feet=[[23,61],[43,58]],
 skull=[(28,12),(36,9),(43,13),(45,19),(42,24),(35,26),(29,24),(26,18)],jaw=[(29,24),(34,25),(41,23),(43,27),(38,30),(32,29),(28,27)],
 sockets=[[(28,17),(32,15),(35,18),(32,20),(29,21)],[(38,15),(42,16),(42,19),(39,20)]],nose=[(35,20),(37,21),(36,24),(34,23)],crack=[(34,11),(33,14),(36,16),(35,18)],teeth=[[31,26],[34,27],[37,27],[40,25]],
 torso=[(28,31),(35,28),(42,29),(46,34),(44,41),(39,44),(32,43),(26,38),(25,34)],pelvis=[(31,43),(39,43),(44,47),(41,50),(37,48),(34,47),(28,51),(26,47)],
 bones=[(4,[(41,47),(45,50),(44,54),(46,57),(43,58),(40,55),(41,51)]),(4,[(43,30),(48,31),(52,36),(49,40),(46,39),(49,36)]),(6,[(27,45),(32,47),(28,52),(23,55),(25,59),(23,60),(21,59),(21,55),(25,50)]),(6,[(26,31),(29,33),(23,38),(24,42),(29,39),(33,39),(33,42),(29,43),(21,44),(19,39),(21,35)])],
 ribs=[(7,[(33,32),(29,31),(26,34),(31,36)]),(7,[(33,36),(29,35),(28,38),(32,40)]),(6,[(34,40),(31,40),(32,43)]),(5,[(37,32),(42,32),(44,35),(40,37)]),(5,[(37,37),(42,37),(41,40),(38,42)])],sternum=[(35,30),(35,42)],spine=[(40,28),(40,43)],
 claws=[[(31,39),(35,37),(36,34)],[(32,40),(37,40),(39,37)],[(32,42),(36,43),(40,41)],[(48,38),(51,41),(50,44)],[(49,38),(53,40),(54,43)],[(47,39),(47,43),(45,45)]],toes=[[(23,59),(19,61),(26,61)],[(43,56),(40,58),(46,58)]],impact=[36,34]),
 dict(name='contact',role='near claw rakes forward-left with extended shoulder and trailing bent knee',feet=[[25,61],[44,58]],
 skull=[(25,11),(33,8),(40,11),(42,17),(39,23),(32,26),(26,23),(23,17)],jaw=[(26,23),(31,25),(38,22),(40,26),(35,30),(28,29),(25,26)],
 sockets=[[(25,16),(29,14),(32,17),(29,20),(26,20)],[(35,14),(39,15),(39,18),(36,20)]],nose=[(32,20),(34,21),(32,24),(30,23)],crack=[(31,10),(30,13),(33,15),(32,17)],teeth=[[28,25],[31,27],[34,26],[37,24]],
 torso=[(27,31),(34,27),(41,28),(46,33),(43,41),(37,45),(30,42),(24,37),(24,33)],pelvis=[(31,43),(39,43),(44,46),(41,50),(37,48),(34,47),(30,51),(27,48)],
 bones=[(4,[(41,47),(45,50),(46,55),(48,57),(44,58),(43,55),(40,51)]),(4,[(43,29),(47,29),(52,34),(50,39),(47,38),(49,34)]),(6,[(29,46),(33,47),(31,51),(27,54),(28,58),(25,60),(23,59),(24,54),(28,50)]),(7,[(25,30),(28,33),(21,35),(18,40),(14,42),(12,39),(15,35),(20,31)])],
 ribs=[(7,[(32,31),(28,31),(25,34),(29,36)]),(7,[(32,35),(28,35),(27,38),(31,40)]),(6,[(33,39),(30,40),(32,43)]),(5,[(36,31),(40,31),(43,34),(39,36)]),(5,[(36,36),(41,36),(40,40),(37,42)])],sternum=[(34,29),(34,41)],spine=[(40,26),(39,43)],
 claws=[[(14,39),(10,42),(8,46)],[(15,40),(13,45),(11,48)],[(16,41),(17,46),(15,49)],[(49,37),(52,40),(51,44)],[(50,37),(54,39),(54,43)],[(48,38),(48,42),(46,44)]],toes=[[(25,59),(21,61),(28,61)],[(44,56),(41,58),(48,58)]],impact=[8,46]),
 dict(name='recovery',role='rake withdraws; near elbow folds and chest returns over two planted feet',feet=[[26,61],[42,57]],
 skull=[(30,10),(38,8),(44,12),(45,18),(42,23),(35,25),(29,22),(27,16)],jaw=[(30,22),(34,24),(41,22),(42,26),(38,29),(32,28),(29,25)],
 sockets=[[(29,15),(33,14),(35,17),(32,19),(29,19)],[(38,14),(42,15),(42,18),(39,19)]],nose=[(35,19),(37,20),(36,23),(34,22)],crack=[(35,10),(34,13),(36,15),(35,17)],teeth=[[32,24],[34,25],[37,25],[39,24]],
 torso=[(29,29),(36,27),(43,28),(46,33),(43,40),(38,44),(32,42),(27,37),(26,32)],pelvis=[(32,42),(39,42),(43,45),(40,48),(37,47),(35,46),(31,50),(28,46)],
 bones=[(4,[(40,45),(44,48),(43,52),(45,56),(42,57),(40,53),(39,49)]),(4,[(43,29),(47,30),(51,35),(49,40),(46,39),(48,35)]),(6,[(29,44),(33,46),(31,50),(27,53),(29,58),(26,60),(24,59),(25,54),(28,50)]),(6,[(27,29),(30,31),(25,36),(24,41),(28,44),(27,47),(22,44),(21,40),(23,34)])],
 ribs=[(7,[(34,31),(30,30),(27,33),(32,35)]),(7,[(34,35),(30,34),(29,37),(33,39)]),(6,[(35,39),(32,39),(33,42)]),(5,[(38,31),(42,31),(44,34),(40,36)]),(5,[(38,36),(42,36),(41,39),(38,41)])],sternum=[(36,29),(36,41)],spine=[(41,26),(40,42)],
 claws=[[(27,44),(25,48),(23,50)],[(28,45),(29,49),(27,52)],[(29,44),(32,47),(32,50)],[(48,38),(50,42),(49,45)],[(49,38),(53,40),(53,44)],[(47,39),(47,43),(45,45)]],toes=[[(26,59),(22,61),(29,61)],[(42,55),(39,57),(45,57)]],impact=[23,50]),
 dict(name='reaction',role='skull turns away and shoulder buckles while knees brace the hit',feet=[[26,61],[43,58]],
 skull=[(33,13),(41,10),(47,15),(47,21),(43,26),(36,28),(31,24),(30,18)],jaw=[(32,24),(36,26),(43,24),(44,28),(40,31),(34,30),(31,27)],
 sockets=[[(32,18),(36,16),(38,20),(35,22),(32,22)],[(41,16),(45,18),(44,21),(41,22)]],nose=[(38,22),(40,23),(38,26),(36,25)],crack=[(38,12),(37,15),(40,17),(39,19)],teeth=[[34,26],[36,28],[39,28],[42,26]],
 torso=[(30,32),(37,29),(44,31),(48,36),(44,42),(39,46),(32,44),(28,39),(27,35)],pelvis=[(32,44),(40,44),(44,48),(41,51),(38,49),(35,48),(30,52),(27,48)],
 bones=[(4,[(41,48),(45,51),(44,55),(46,57),(43,58),(41,55),(40,51)]),(4,[(45,32),(49,34),(52,39),(49,44),(46,42),(49,39)]),(6,[(28,46),(33,48),(30,52),(26,55),(28,59),(26,60),(23,59),(24,55),(27,51)]),(6,[(29,31),(31,34),(26,38),(24,43),(22,46),(20,44),(21,40),(25,34)])],
 ribs=[(7,[(35,33),(31,32),(28,35),(32,38)]),(7,[(35,37),(31,36),(30,40),(34,42)]),(6,[(36,41),(33,42),(34,44)]),(5,[(39,33),(43,34),(45,37),(41,39)]),(5,[(39,39),(43,39),(42,42),(39,44)])],sternum=[(37,31),(37,43)],spine=[(43,29),(41,44)],
 claws=[[(22,45),(19,48),(18,51)],[(23,46),(23,50),(21,53)],[(24,45),(27,48),(26,51)],[(48,42),(51,45),(50,48)],[(49,42),(53,44),(54,47)],[(47,43),(47,47),(45,49)]],toes=[[(26,59),(22,61),(29,61)],[(43,56),(40,58),(46,58)]],impact=[18,51]),
 dict(name='death',role='broken seated collapse: cranium against ribs, pelvis and limbs splayed on ground',feet=[[24,62],[45,61]],
 skull=[(25,36),(32,34),(38,38),(39,44),(35,49),(29,50),(24,46),(23,41)],jaw=[(25,46),(29,48),(35,47),(36,51),(32,53),(27,52),(24,49)],
 sockets=[[(24,41),(28,39),(30,43),(27,45),(24,44)],[(32,40),(36,41),(36,44),(33,45)]],nose=[(30,45),(32,46),(30,48),(28,47)],crack=[(30,36),(29,39),(32,41),(31,43)],teeth=[[27,49],[29,50],[32,50],[34,49]],
 torso=[(30,44),(36,40),(43,43),(47,48),(43,54),(37,58),(30,56),(26,51),(27,47)],pelvis=[(31,54),(39,54),(43,57),(40,61),(36,59),(33,57),(28,61),(26,58)],
 bones=[(4,[(40,57),(44,56),(48,58),(49,60),(45,61),(42,60),(39,61)]),(4,[(44,44),(48,44),(52,48),(50,52),(47,51),(49,48)]),(6,[(28,57),(31,59),(28,61),(24,61),(20,62),(18,60),(24,58)]),(6,[(27,45),(29,47),(23,51),(21,55),(24,58),(23,60),(19,57),(18,53),(22,48)])],
 ribs=[(7,[(34,46),(30,46),(28,49),(32,51)]),(7,[(34,50),(30,50),(30,53),(34,55)]),(6,[(35,54),(32,55),(34,57)]),(5,[(38,45),(42,46),(44,49),(40,51)]),(5,[(38,51),(42,51),(41,54),(38,56)])],sternum=[(36,44),(36,55)],spine=[(42,41),(40,55)],
 claws=[[(23,57),(19,59),(17,61)],[(24,58),(23,61),(21,62)],[(25,57),(28,60),(27,62)],[(49,50),(52,53),(51,56)],[(50,50),(54,52),(54,55)],[(48,51),(48,55),(46,57)]],toes=[[(24,61),(20,62),(27,62)],[(45,59),(42,61),(48,61)]],impact=[17,61])
]

def guard():
 c=int(Path('/sys/fs/cgroup/memory.current').read_text());m=int(Path('/sys/fs/cgroup/memory.max').read_text());v=os.statvfs(ROOT)
 assert m-c>=512*1048576
 assert c-BASELINE['current']<=32*1048576
 assert v.f_bavail*v.f_frsize>=1048576
 return {'current':c,'maximum':m,'headroom':m-c,'free':v.f_bavail*v.f_frsize}
def line(a,b,col):
 x0,y0=a;x1,y1=b;dx=abs(x1-x0);sx=1 if x0<x1 else -1;dy=-abs(y1-y0);sy=1 if y0<y1 else -1;err=dx+dy
 while True:
  assert 0<=x0<64 and 0<=y0<64;PIX[y0*64+x0]=col
  if x0==x1 and y0==y1:break
  e=2*err
  if e>=dy:err+=dy;x0+=sx
  if e<=dx:err+=dx;y0+=sy
def poly(points,col,outline=None):
 # Integer point-in-polygon sampled at pixel centers, then authored crisp boundary.
 for y in range(min(p[1]for p in points),max(p[1]for p in points)+1):
  for x in range(min(p[0]for p in points),max(p[0]for p in points)+1):
   inside=False;j=len(points)-1
   for i,(xi,yi)in enumerate(points):
    xj,yj=points[j]
    if (yi>y+.5)!=(yj>y+.5)and x+.5<(xj-xi)*(y+.5-yi)/(yj-yi)+xi:inside=not inside
    j=i
   if inside:PIX[y*64+x]=col
 if outline is not None:
  for a,b in zip(points,points[1:]+points[:1]):line(a,b,outline)
def stroke(points,col,shadow=2):
 for a,b in zip(points,points[1:]):
  line((a[0]+1,a[1]),(b[0]+1,b[1]),shadow);line(a,b,col)
def paint(spec):
 global PIX;PIX=bytearray(4096)
 # Far limbs behind the pelvis/chest; open ribs retain visibly dark gaps.
 for col,points in spec['bones'][:2]:poly(points,col,1)
 poly(spec['torso'],2,1);poly(spec['pelvis'],5,1)
 stroke(spec['spine'],4,2)
 for col,points in spec['ribs']:stroke(points,col,3)
 stroke(spec['sternum'],7,5)
 for col,points in spec['bones'][2:]:
  poly(points,col,1);line(points[0],points[1],7)
 for claw in spec['claws']:stroke(claw,6,2)
 for toe in spec['toes']:stroke(toe,7,2)
 poly(spec['skull'],6,1)
 h=spec['skull'];poly([h[0],h[1],(h[1][0],h[1][1]+4),(h[0][0]+1,h[0][1]+4)],7)
 line(h[0],h[1],8);line(h[2],h[3],5)
 poly(spec['jaw'],6,1)
 for socket in spec['sockets']:poly(socket,1)
 poly(spec['nose'],1)
 stroke(spec['crack'],3,5)
 for x,y in spec['teeth']:PIX[y*64+x]=8
 # One recessed warm eye glint, not text/rules; corpse socket stays dark.
 if spec['name']!='death':
  socket=spec['sockets'][0];x,y=socket[0];PIX[(y+1)*64+x+1]=15
 for x,y in spec['feet']+[spec['impact']]:assert PIX[y*64+x],(spec['name'],'opaque foot/claw contact missing',x,y)
 return bytes(PIX)
def chunk(k,b):return struct.pack('>I',len(b))+k+b+struct.pack('>I',zlib.crc32(k+b)&0xffffffff)
def png(w,h,pixels):
 rows=b''.join(b'\0'+pixels[y*w:(y+1)*w]for y in range(h))
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,3,0,0,0))+chunk(b'PLTE',bytes(c for rgb in PAL for c in rgb))+chunk(b'tRNS',bytes([0]+[255]*15))+chunk(b'IDAT',zlib.compress(rows,9))+chunk(b'IEND',b'')
def put(name,b):
 fd=os.open(ROOT+'/'+name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  v=memoryview(b)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
 return {'path':ROOT+'/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def bounds(p):
 coords=[(i%64,i//64)for i,v in enumerate(p)if v]
 return [min(x for x,y in coords),min(y for x,y in coords),max(x for x,y in coords)+1,max(y for x,y in coords)+1]
BASELINE={'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text())}
assert BASELINE['maximum']-BASELINE['current']>=32*1048576+512*1048576
frames=[];records=[];files=[]
for i,spec in enumerate(POSES):
 guard();p=paint(spec);frames.append(p);files.append(put('bone-thrall-'+spec['name']+'.png',png(64,64,p)))
 records.append({'index':i,'name':spec['name'],'role':spec['role'],'cell':[i*64,0,64,64],'opaqueBounds':bounds(p),'opaquePixels':sum(bool(v)for v in p),'nativeIndicesUsed':sorted(set(p)),'footContactPoints':spec['feet'],'clawContactPixelIndex':spec['impact'],'placementAnchor':[32,61],'pixelSHA256':hashlib.sha256(p).hexdigest()})
sheet=b''.join(b''.join(p[y*64:(y+1)*64]for p in frames)for y in range(64));files.append(put('bone-thrall-sheet.png',png(448,64,sheet)))
# Sole preview: original cells at exact native2x, four columns/two rows.
preview=bytearray(512*256)
for i,p in enumerate(frames):
 ox=i%4*128;oy=i//4*128
 for y in range(64):
  for x in range(64):
   for dy in range(2):
    start=(oy+y*2+dy)*512+ox+x*2;preview[start:start+2]=bytes([p[y*64+x]])*2
files.append(put('bone-thrall-preview-2x.png',png(512,256,preview)))
union=[min(r['opaqueBounds'][0]for r in records),min(r['opaqueBounds'][1]for r in records),max(r['opaqueBounds'][2]for r in records),max(r['opaqueBounds'][3]for r in records)]
meta={'name':'Bone Thrall','cardId':'thrall','engineSpecies':'thrall','side':'enemy','identityQualification':'Retained actual ordinary UI save names/cardId/species read-only; no rule changes or UID hardcoding.','orientation':'intended front three-quarter skeletal servant facing southwest/player; visual acceptance pending','nativeCell':[64,64],'sheet':[448,64],'palette':[{'index':i,'rgb':list(c),'alpha':0 if i==0 else 255}for i,c in enumerate(PAL)],'paletteEntryCount':16,'paletteAdditions':0,'paletteSource':'Exact Cairn R5 palette. Cream/mineral7,8 for bone light, cool4,5 for receding bone, dark1,2 for cavity and15 for one recessed warm glint; no colour added.','transparentIndex':0,'sampling':'indexed8/integer native; no antialias','placementAnchor':[32,61],'anchorQualification':'Common floor-plane reference; actual painted support feet are individually recorded. No engine-fit or universal foot placement claim.','fullPoseOpaqueUnion':union,'frames':records,'files':files,'distinctNativePixelHashes':len({r['pixelSHA256']for r in records}),'sequenceCandidates':{'idle':['idle0','idle1'],'attack':['anticipation','contact','recovery'],'reaction':['reaction','recovery'],'death':['death']},'timingsImplemented':False,'engineIntegration':False,'provenance':'Seven new original literal skull/jaw/rib/limb/pelvis/claw drawings. Only own Cairn R5 bounded raster/PNG/writer helpers reused from exactb697869d8de1d40140ae02a7fab11edfdc59fda7ee6e3627a1f8ccbb0f0e9ba7. No raster sampled, image filter, mirrored rear anatomy, franchise input or generated-image tool.','limitations':['Static anatomy study only; not selected art or proved coherent scene.','Seven distinct cells are not a demonstrated complete animation.','No real Arena/first-five fit, timing, command contact, deathhold, reduced-motion or reload evaluation.','Original painted Bone Thrall and Cairn R4/R5 evidence remain unchanged.'],'sourceGuardFinal':guard()}
assert meta['distinctNativePixelHashes']==7
files.append(put('ASSET-METADATA.json',(json.dumps(meta,indent=2,sort_keys=True)+'\n').encode()))
print(json.dumps({'files':files,'fullPoseUnion':union,'distinctPoses':7,'paletteEntries':16,'sourceGuardFinal':guard()}))
