// UNEXECUTED focused fixed-UI-seed R7/R8 issued-command attribution comparison. Separate ROOT grants required.
// Uses a separately reviewed narrow R8 supervisor; no baseline gate is borrowed.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/playwright-core/index.mjs';

const [stage,freezePath,packet,portText]=process.argv.slice(2),port=Number(portText),started=Date.now();
// A single separately reviewed literal parameter file will name ROOT's repaired
// candidate. Pending parameters fail before any server/browser is launched.
const phase=stage==='/workspace/scratch/first-five-opening-preview-identity-stage-r7'?'baseline':'candidate';
const expected=JSON.parse(fs.readFileSync('/workspace/scratch/standard-sol-command-guidance-caller-author-r1/EXPECTED-'+phase.toUpperCase()+'.json'));
assert.equal(expected.status,'FROZEN_FOR_REVIEW','Repaired candidate freeze has not been supplied/reviewed');
assert.equal(stage,expected.stage);assert.equal(freezePath,expected.freezePath);
assert(packet?.startsWith('/workspace/scratch/standard-sol-command-guidance-actual-'));
assert(Number.isInteger(port)&&port>1024&&port<65536);
const hash=b=>createHash('sha256').update(b).digest('hex');
const freezeBytes=fs.readFileSync(freezePath),freeze=JSON.parse(freezeBytes);
assert.equal(hash(freezeBytes),expected.freezeSHA256);
assert.equal(freeze.stage,stage);
assert.equal(freeze.sourceDigest,expected.sourceDigest);
assert.equal(freeze.outputsDigest,expected.outputsDigest);
assert.equal(freeze.inputCount,87);assert.equal(freeze.outputCount,56);
const admission=JSON.parse(fs.readFileSync(path.join(packet,'ADMISSION.json'))),work=896*1048576,reserve=512*1048576;
const current=Number(fs.readFileSync('/sys/fs/cgroup/memory.current','utf8')),maximum=Number(fs.readFileSync('/sys/fs/cgroup/memory.max','utf8'));
const spent=Math.max(0,current-admission.initial.current);
assert(admission.admitted===true&&admission.stage===stage&&admission.freeze===freezePath&&admission.work===work&&admission.reserve===reserve&&admission.initial.maximum===maximum&&admission.initial.headroom>=work+reserve&&spent<=work&&maximum-current>=reserve+Math.max(0,work-spent),'Same outer896+512 accounting rejected');
fs.writeFileSync(path.join(packet,'INSIDE-PHASE-ACCOUNTING.json'),JSON.stringify({work,reserve,current,maximum,spent,remaining:Math.max(0,work-spent),freshAdmission:false,sameOuterAdmission:true})+'\n');
const result={scope:'Focused fixed UI seed9592029 default Initiate issued-command attribution supplement; fresh1440x900/DPR1; no human fun, engine imports, saved-state injection, reroll, pixel integration or whole-game acceptance',sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,phase,seed:9592029,actions:[],captures:[],stepObservations:[],gates:{composition:'UNEXERCISED',settling:'OBSERVATION_ONLY; no forced state or terminal test'},authorRole:'Caller author only; independent actual reviewer decides ROOT command-attribution delta; no independence for earlier own preview helper',browser:'NOT_LAUNCHED',server:'NOT_LAUNCHED',mechanicalPass:false,personallyViewed:false};
let browser,context,page,server,stopReason=null,timer,auditBefore=false,closingPromise=null,closedBrowser=null,closedServer=null;
const K='hollowpact.run.v2',expectedCue='Bind your first creature. Click or drag a BINDING card.';
const stamp=()=>({utc:new Date().toISOString(),wholeElapsedMs:Date.now()-started});
function log(name,data){fs.appendFileSync(path.join(packet,name),JSON.stringify({...stamp(),...data})+'\n');}
function persist(){fs.writeFileSync(path.join(packet,'VISUAL-PROGRESS.json'),JSON.stringify(result,null,2)+'\n');}
function check(){if(stopReason||Date.now()-started>=90000)throw Error(stopReason||'90s visual driver abort');}
async function hashFile(file){const h=createHash('sha256');let bytes=0;for await(const b of fs.createReadStream(file,{flags:fs.constants.O_RDONLY|fs.constants.O_NOATIME|fs.constants.O_NOFOLLOW,highWaterMark:32768})){check();h.update(b);bytes+=b.length;}return {sha256:h.digest('hex'),bytes};}
async function audit(label){
 const row={label,inputs:[],outputs:[]};assert.equal(Object.keys(freeze.inputs).length,87);assert.equal(Object.keys(freeze.outputs).length,56);
 for(const [rel,expected] of Object.entries(freeze.inputs)){check();const actual=await hashFile(path.join(stage,rel));assert.equal(actual.sha256,expected,'Input mismatch '+rel);row.inputs.push({path:rel,...actual});}
 for(const [rel,expected] of Object.entries(freeze.outputs)){check();const actual=await hashFile(path.join(stage,'dist',rel));assert.equal(actual.sha256,expected,'Output mismatch '+rel);row.outputs.push({path:rel,...actual});}
 fs.writeFileSync(path.join(packet,`BYTE-AUDIT-${label}.json`),JSON.stringify(row,null,2)+'\n');
}
async function bounded(promise,ms,label){let t;try{return await Promise.race([promise,new Promise((_,reject)=>{t=setTimeout(()=>reject(Error(label+' timeout')),ms);})]);}finally{clearTimeout(t);}}
async function close(reason){
 if(closingPromise)return closingPromise;
 closingPromise=(async()=>{
  log('LIFECYCLE.jsonl',{event:'close initiated',reason});const errors=[],ownedBrowser=browser,ownedServer=server;
  try{if(ownedBrowser){await bounded(ownedBrowser.close(),8000,'browser close');closedBrowser=ownedBrowser;result.browser='CLOSED';}}catch(e){errors.push(String(e));result.browser='CLOSE_UNCONFIRMED';}
  try{if(ownedServer){ownedServer.closeIdleConnections?.();await bounded(new Promise((resolve,reject)=>ownedServer.close(e=>e?reject(e):resolve())),2000,'server close');closedServer=ownedServer;result.server='CLOSED';}}catch(e){errors.push(String(e));result.server='CLOSE_UNCONFIRMED';}
  if(errors.length){result.closeErrors=errors;result.mechanicalPass=false;process.exitCode=2;}
  log('LIFECYCLE.jsonl',{event:errors.length?'close failures':'normal browser and server close',reason,errors});persist();
 })();return closingPromise;
}
function abort(reason){if(stopReason)return;stopReason=reason;result.abortReason=reason;result.mechanicalPass=false;process.exitCode=2;void close(reason).catch(e=>{result.closeFailure=String(e);process.exitCode=2;});}
process.once('SIGTERM',()=>abort('supervisor SIGTERM'));
timer=setTimeout(()=>abort('90s visual driver abort'),Math.max(0,90000-(Date.now()-started)));
async function rawSave(){check();return page.evaluate(k=>localStorage.getItem(k),K);}
async function settle(){check();await page.waitForTimeout(220);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));check();}
async function owned(locator){
 check();await locator.waitFor();
 // Avoid Playwright's stability-based scroll wait on already visible animated
 // actor bodies. Keep the original scoped scroll path for offscreen controls.
 const existing=await locator.boundingBox(),viewport=page.viewportSize();
 const alreadyFullyVisible=existing&&viewport&&existing.width>0&&existing.height>0&&existing.x>=0&&existing.y>=0&&existing.x+existing.width<=viewport.width&&existing.y+existing.height<=viewport.height;
 if(!alreadyFullyVisible)await locator.scrollIntoViewIfNeeded();await settle();
 let b=await locator.boundingBox();assert(b,'Missing pointer box');await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await settle();
 b=await locator.boundingBox();assert(b,'Owner vanished after hover');const point={x:b.x+b.width/2,y:b.y+b.height/2};
 // Move to the final settled coordinate that will actually be pressed. Do not
 // assert/log a recomputed center while leaving the mouse at the prior center.
 await page.mouse.move(point.x,point.y);await settle();
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},point),'Fresh actual pointer owner missing');
 assert(await locator.evaluate(e=>!e.disabled&&e.getAttribute('aria-disabled')!=='true'),'Unavailable control');return point;
}
async function click(locator,label){
 const p=await owned(locator),before=await rawSave(),n=await page.evaluate(()=>window.__cueVisualEvents.length);
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual press owner changed');await page.mouse.down();await page.waitForTimeout(60);check();assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual release owner changed');
 await page.mouse.up();await settle();const events=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);assert(events.some(e=>e.type==='pointerdown'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1)&&events.some(e=>e.type==='pointerup'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1),'Missing trusted native press/release at actual checked coordinates');
 result.actions.push({label,point:p,beforeSHA:before===null?null:hash(before),afterSHA:await rawSave().then(v=>v===null?null:hash(v)),events});persist();
}
async function shot(label){
 check();assert(result.captures.length<6,'Capture cap exceeded');const file=path.join(packet,`${String(result.captures.length+1).padStart(2,'0')}-${label}.png`);await page.screenshot({path:file,type:'png'});result.captures.push({label,path:file,...await hashFile(file),personallyViewed:false});persist();
}
try{
 await audit('before');auditBefore=true;check();const keys=Object.keys(freeze.outputs).sort();
 server=http.createServer((req,res)=>{try{const pathname=new URL(req.url,'http://localhost').pathname,key=pathname==='/'?'index.html':decodeURIComponent(pathname.slice(1));if(!keys.includes(key)){res.writeHead(404);res.end('Not found');return;}res.setHeader('Content-Type',key.endsWith('.html')?'text/html':key.endsWith('.js')?'text/javascript':key.endsWith('.css')?'text/css':key.endsWith('.png')?'image/png':key.endsWith('.json')?'application/json':'application/octet-stream');const stream=fs.createReadStream(path.join(stage,'dist',key));stream.on('error',()=>res.destroy());stream.pipe(res);}catch{res.writeHead(400);res.end('Bad request');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});result.server='OPEN';
 const served=[];for(const rel of keys){check();const response=await fetch(`http://127.0.0.1:${port}/${rel.split('/').map(encodeURIComponent).join('/')}`,{signal:AbortSignal.timeout(8000)});assert(response.ok,'Serve failed '+rel);const h=createHash('sha256');let bytes=0;for await(const b of response.body){check();h.update(b);bytes+=b.length;}const sha256=h.digest('hex');assert.equal(sha256,freeze.outputs[rel],'Served mismatch '+rel);served.push({path:rel,bytes,sha256});}
 fs.writeFileSync(path.join(packet,'SERVED-BYTE-AUDIT.json'),JSON.stringify({sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,served},null,2)+'\n');
 check();browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox'],timeout:12000});result.browser='OPEN';check();
 context=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'no-preference'});
 // Passive pre-app WINDOW capture sees handled drag Escape before the game
 // stops propagation there; it never prevents, stops or dispatches any input.
 await context.addInitScript(()=>{window.__cueVisualEvents=[];for(const type of ['pointerdown','pointerup','click','focusin','keydown'])window.addEventListener(type,e=>{const card=e.target.closest?.('.hand-cards .game-card');
 // This listener was installed before application handlers. Native pointerdown
 // reads the exact then-visible rect, before tactile-pressed changes transforms.
 const pointerdownSource=type==='pointerdown'&&card?{rect:card.getBoundingClientRect().toJSON(),offsetWidth:card.offsetWidth,offsetHeight:card.offsetHeight,computedWidth:getComputedStyle(card).width,computedHeight:getComputedStyle(card).height,transform:getComputedStyle(card).transform}:undefined;
 window.__cueVisualEvents.push({type,trusted:e.isTrusted,observedAtMs:performance.now(),key:e.key,x:e.clientX,y:e.clientY,ui:e.target.closest?.('[data-ui]')?.dataset.ui,card:e.target.closest?.('[data-card]')?.dataset.card,index:e.target.closest?.('[data-card]')?.dataset.index,pointerdownSource});if(window.__cueVisualEvents.length>1000)window.__cueVisualEvents.splice(0,200);},{capture:true,passive:true});});
 page=await context.newPage();page.setDefaultTimeout(5000);page.on('pageerror',e=>log('ERRORS.jsonl',{kind:'pageerror',error:String(e)}));
// Finite native UI observations; no engine import, fixture, private cue or state writes.
async function step(label){
 check();const raw=await rawSave(),row=await page.evaluate(()=>{
  const active=document.activeElement,p=document.querySelector('#consequence-preview'),d=document.querySelector('#dialog');
  const describe=e=>({unit:e.dataset.unit,uid:e.dataset.uid,focus:e.dataset.focus,card:e.dataset.card,index:e.dataset.index,ui:e.dataset.ui,aria:e.getAttribute('aria-label'),disabled:e.disabled});
  const text=e=>{const c=getComputedStyle(e),range=document.createRange();range.selectNodeContents(e);return {text:e.innerText,rect:e.getBoundingClientRect().toJSON(),glyphRect:range.getBoundingClientRect().toJSON(),fontSize:c.fontSize,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,scrollTop:e.scrollTop,overflowX:c.overflowX,overflowY:c.overflowY};};
  return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio,scrollX,scrollY,documentWidth:document.documentElement.scrollWidth,documentHeight:document.documentElement.scrollHeight},nativeReducedMotion:matchMedia('(prefers-reduced-motion: reduce)').matches,active:active?describe(active):null,dialogOpen:d.open,activeInDialog:!!active&&d.contains(active),preview:p?{...text(p),kind:p.dataset.preview,role:p.getAttribute('role'),live:p.getAttribute('aria-live')}:null,cancel:[...document.querySelectorAll('[data-ui="cancel"]')].filter(e=>e.getClientRects().length).map(describe),selectedCards:[...document.querySelectorAll('.hand-cards .game-card.selected')].map(describe),legalTargets:[...document.querySelectorAll('.field-unit.valid-target:not(:disabled)')].map(describe),hand:[...document.querySelectorAll('.hand-cards .game-card')].map(e=>({...describe(e),unavailable:e.getAttribute('aria-disabled'),name:text(e.querySelector('.card-name')),rules:text(e.querySelector('.card-description')),cost:text(e.querySelector('.card-cost')),kindText:e.querySelector('.card-kind').innerText})),actors:[...document.querySelectorAll('.field-unit')].map(describe),settling:document.querySelector('#app').classList.contains('settling-combat'),directField:!!document.querySelector('#field-controls')&&!document.querySelector('#arena-wrap').classList.contains('arena-fallback')};
 });const evidence={label,...stamp(),phase,saveSHA:raw===null?null:hash(raw),...row};result.stepObservations.push(evidence);log('STEPS.jsonl',evidence);console.log(JSON.stringify({event:'actual-command-guidance-step',...evidence}));persist();return evidence;
}
async function key(keyText,label){
 check();assert(result.actions.length<40);const before=await rawSave(),n=await page.evaluate(()=>window.__cueVisualEvents.length);await page.keyboard.press(keyText);await settle();const events=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);assert(events.some(e=>e.type==='keydown'&&e.trusted&&e.key.toLowerCase()===keyText.toLowerCase()));assert.equal(await rawSave(),before,'Navigation/preview/cancel changed save: '+label);result.actions.push({label,key:keyText,savePure:true,events});persist();return step(label);
}
async function hover(locator,label){
 const before=await rawSave(),point=await owned(locator);assert.equal(await rawSave(),before,'Read-only native hover changed save');result.actions.push({label,nativeMouseMove:true,point,savePure:true});persist();return step(label);
}
function preservesIssued(row,label){if(phase==='candidate'){assert.equal(row.preview?.kind,'issued-command',label+' lost issued marker');assert.equal(row.preview.text,result.firstIssued.text,label+' replaced issued result');}}
async function selectCommand(label){
 let row=await key('b',label+' native B');assert.equal(row.active.unit,cairn.uid);row=await key('Enter',label+' actual ready command selected');assert.equal(row.cancel.length,1,'No real selection/Cancel; stop');assert(row.legalTargets.some(t=>t.unit===thrall.uid));row=await key('t',label+' canonical legal targets');if(row.active.unit!==thrall.uid){assert.equal(row.active.unit,reaver.uid);row=await key('ArrowRight',label+' native Right to Thrall');}assert.equal(row.active.unit,thrall.uid);assert.equal(row.preview?.kind,'consequence');return row;
}
async function commitCommand(label){
 const before=await rawSave(),beforeState=JSON.parse(before),n=await page.evaluate(()=>window.__cueVisualEvents.length);const actual=await step(label+' actual legal commit owner');assert.equal(actual.active.unit,thrall.uid);assert.equal(actual.cancel.length,1);assert(actual.legalTargets.some(t=>t.unit===thrall.uid));
 const nativeCommandStarted=stamp();await page.keyboard.press('Enter');
 // First observation follows the native accepted order without our settle delay.
 const immediate=await step(label+' first post-native-Enter observation');const after=await rawSave(),events=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);assert(events.some(e=>e.type==='keydown'&&e.trusted&&e.key==='Enter'));const afterState=JSON.parse(after);assert.equal(afterState.energy,beforeState.energy,'Free command spent energy');assert.equal(afterState.phase,'battle','Unexpected terminal state');assert(afterState.allies.find(a=>a.uid===cairn.uid)?.acted);result.actions.push({label,nativeCommandStarted,source:cairn.uid,target:thrall.uid,beforeSHA:hash(before),afterSHA:hash(after),events});persist();return {immediate,before,after,beforeState,afterState};
}
 await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded',timeout:12000});await settle();await step('fresh interactive title');await click(page.locator('#scene-ui [data-ui="new"]'),'open ordinary contract');result.originalGeneratedFormSeed=await page.locator('#seed').inputValue();await click(page.locator('[data-hunt-disclosure="hunt-seed-panel"]'),'open native Set a seed');await click(page.locator('#seed'),'focus visible campaign seed');await page.keyboard.press('Control+a');await page.keyboard.type('9592029');assert.equal(await page.locator('#seed').inputValue(),'9592029');assert.equal(await page.locator('input[name="difficulty"]:checked').inputValue(),'0');await click(page.locator('#new-game-form [type="submit"]'),'accept fixed seed default Initiate');await page.waitForTimeout(600);await settle();
 const initialRaw=await rawSave(),initial=JSON.parse(initialRaw);assert.equal(initial.seed,9592029);assert.equal(initial.difficulty,0);assert.equal(initial.phase,'battle');assert.equal(initial.turn,1);assert.deepEqual(initial.hand,['survey','sunder','scour','ironward','cairnhound']);assert.equal(initial.allies.length,0);assert.equal(initial.enemies.length,2);const thrall=initial.enemies.find(e=>e.cardId==='thrall'),reaver=initial.enemies.find(e=>e.cardId==='raider');assert(thrall&&reaver);assert.equal(thrall.hp,7);assert.equal(thrall.block,0);assert(reaver.hp>0);
 fs.writeFileSync(path.join(packet,'INITIAL-ACTUAL-SAVE.json'),JSON.stringify({observedOnly:true,raw:initialRaw})+'\n');result.actualOpening={seed:initial.seed,hand:initial.hand,enemies:initial.enemies,initialRawSHA:hash(initialRaw)};let row=await step('actual known opening before binding');assert(row.directField&&!row.nativeReducedMotion);
 const card=page.locator('.hand-cards .game-card[data-card="cairnhound"][data-index="4"][aria-disabled="false"]');assert.equal(await card.count(),1);await click(card,'ordinary native Cairn index4 binding');await page.waitForTimeout(600);await settle();const boundRaw=await rawSave(),bound=JSON.parse(boundRaw),cairn=bound.allies.find(a=>a.cardId==='cairnhound');assert(cairn&&cairn.hp>0&&!cairn.acted);assert.equal(bound.allies.length,1);assert.equal(bound.energy,4);assert.deepEqual(bound.hand,['survey','sunder','scour','ironward']);await step('actual Cairn ready with Survey first');
 row=await selectCommand('first Cairn command');assert.match(row.preview.text,/5 health damage/);result.precommandPreview=row.preview;const first=await commitCommand('first genuine Cairn command');assert.equal(first.afterState.enemies.find(e=>e.uid===thrall.uid)?.hp,2);assert.equal(first.afterState.hand[0],'survey');result.firstIssued=first.immediate.preview;result.firstCommandSaveSHA=hash(first.after);
 if(phase==='candidate'){assert.equal(first.immediate.preview?.kind,'issued-command','R8 did not show issued attribution');assert.equal(first.immediate.preview.text,'Command issued: '+result.precommandPreview.text);}
 else assert.notEqual(first.immediate.preview?.kind,'issued-command','R7 unexpectedly has issued marker');
 await shot('first-issued-order-observation');
 const readBefore=await rawSave();await click(page.locator('#consequence-preview'),'native read/focus Order preview');assert.equal(await rawSave(),readBefore);row=await step('native Order-preview reading');preservesIssued(row,'Order preview');row=await hover(page.locator(`.field-inspect[data-uid="${cairn.uid}"]`),'native Inspect-readout hover');preservesIssued(row,'Inspect hover');
 const empty=await page.evaluate(()=>{const r=document.querySelector('#arena').getBoundingClientRect();for(const [x,y] of [[.1,.55],[.5,.4],[.9,.55]]){const p={x:r.left+r.width*x,y:r.top+r.height*y};const e=document.elementFromPoint(p.x,p.y);if(e&&p.x>=0&&p.y>=0&&p.x<innerWidth&&p.y<innerHeight&&!e.closest('.field-actor,.hunter-hud,#dock,.battle-guidance,#dialog,button')&&document.querySelector('#arena-wrap').contains(e))return p;}return null;});assert(empty,'No owned empty field point; stop');assert(await page.evaluate(p=>{const e=document.elementFromPoint(p.x,p.y);return e&&!e.closest('.field-actor,.hunter-hud,#dock,.battle-guidance,#dialog,button')&&document.querySelector('#arena-wrap').contains(e);},empty));await page.mouse.move(empty.x,empty.y);await settle();assert.equal(await rawSave(),readBefore);result.actions.push({label:'native empty-field hover',point:empty,savePure:true});row=await step('actual empty-field reading');preservesIssued(row,'Empty field');await shot('read-path-attribution');
 const survey=page.locator('.hand-cards .game-card[data-card="survey"][aria-disabled="false"]');assert.equal(await survey.count(),1);row=await hover(survey,'deliberate legal Survey hover');assert.equal(row.preview?.kind,'consequence');assert(row.preview.text.startsWith('Forbidden Survey:'));row=await key('h','deliberate native H to actual Survey hand focus');assert.equal(row.active.card,'survey');assert.equal(row.preview?.kind,'consequence');assert(row.preview.text.startsWith('Forbidden Survey:'));await shot('deliberate-next-card-preview');
 const cancelBefore=await rawSave(),sunder=page.locator('.hand-cards .game-card[data-card="sunder"][aria-disabled="false"]');assert.equal(await sunder.count(),1);await click(sunder,'select actual Sunder for cancellation');assert.equal(await rawSave(),cancelBefore);row=await step('real selected Sunder and visible Cancel');assert.equal(row.cancel.length,1);assert(row.selectedCards.some(c=>c.card==='sunder'));row=await key('t','actual legal Sunder target preview');assert(row.legalTargets.some(t=>t.unit===row.active.unit));assert.equal(row.cancel.length,1);row=await key('Escape','cancel real Sunder without Pause');assert.equal(row.cancel.length,0);assert.equal(row.selectedCards.length,0);assert(!row.dialogOpen);assert.equal(await rawSave(),cancelBefore);
 // Browser-native system preference only, with the actual canonical save intact.
 const beforeMotion=await rawSave();await page.emulateMedia({reducedMotion:'reduce'});await settle();row=await step('native reduced-motion preference enabled');assert(row.nativeReducedMotion);assert.equal(await rawSave(),beforeMotion);const spent=JSON.parse(beforeMotion);assert(spent.allies.every(a=>a.acted||a.hp<=0),'Unspent binding could trigger End-turn confirmation; stop');
 await click(page.locator('[data-action="endTurn"]'),'ordinary native legal End turn with all commands spent');await page.waitForTimeout(600);await settle();const turn2Raw=await rawSave(),turn2=JSON.parse(turn2Raw);row=await step('actual no-Scour turn2 draw and enemy response');assert(!row.dialogOpen,'Unexpected confirmation; no forced accept');assert.equal(turn2.phase,'battle');assert.equal(turn2.turn,2);assert(turn2.allies.find(a=>a.uid===cairn.uid)?.hp>0&&!turn2.allies.find(a=>a.uid===cairn.uid)?.acted);assert.equal(turn2.enemies.find(e=>e.uid===thrall.uid)?.hp,2);assert(turn2.enemies.find(e=>e.uid===reaver.uid)?.hp>0);result.actualTurn2={hand:turn2.hand,allies:turn2.allies,enemies:turn2.enemies,hunterHp:turn2.hp,energy:turn2.energy,rawSHA:hash(turn2Raw)};
 await selectCommand('earned reduced-motion Cairn command');const second=await commitCommand('earned reduced-motion nonterminal Thrall kill');await settle();row=await step('reduced-motion ordinary post-command preview');assert(!second.afterState.enemies.some(e=>e.uid===thrall.uid),'Actual remaining Thrall was not defeated');assert(second.afterState.enemies.some(e=>e.uid===reaver.uid&&e.hp>0));assert.equal(second.afterState.phase,'battle');assert.notEqual(row.preview?.kind,'issued-command');assert(!row.preview.text.startsWith('Command issued:'));assert(['instruction','consequence'].includes(row.preview.kind)&&row.preview.text.trim().length>0,'Ordinary preview absent');result.reducedMotionPreview={preview:row.preview,active:row.active,actualHand:row.hand};await shot('reduced-motion-ordinary-preview');
 const finalRaw=await rawSave();result.canonicalComparison={seed:9592029,initialRawSHA:hash(initialRaw),boundRawSHA:hash(boundRaw),firstCommandRawSHA:hash(first.after),turn2RawSHA:hash(turn2Raw),finalRawSHA:hash(finalRaw)};fs.writeFileSync(path.join(packet,'CANONICAL-COMPARISON.json'),JSON.stringify({observedOnly:true,sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,...result.canonicalComparison},null,2)+'\n');fs.writeFileSync(path.join(packet,'FIRST-COMMAND-ACTUAL-SAVE.json'),JSON.stringify({observedOnly:true,raw:first.after})+'\n');fs.writeFileSync(path.join(packet,'FINAL-ACTUAL-SAVE.json'),JSON.stringify({observedOnly:true,raw:finalRaw})+'\n');check();result.completed=true;result.mechanicalPass=true;
}catch(e){result.failure=e.stack;result.mechanicalPass=false;process.exitCode=2;log('FAILURE.jsonl',{error:String(e)});}
finally{
 await close(stopReason||'visual checks completed or failed');
 // Cancellation can race async launch/listen. An earlier completed close does
 // not cover a subsequently returned owned browser/server; retire those too.
 if(browser&&browser!==closedBrowser||server&&server!==closedServer){closingPromise=null;await close('final late-created or unconfirmed owned-resource cleanup');}
 if(auditBefore&&!stopReason){try{await audit('after');}catch(e){result.afterAuditFailure=e.stack;result.mechanicalPass=false;process.exitCode=2;}}
 clearTimeout(timer);result.wholeElapsedMs=Date.now()-started;if(stopReason){result.mechanicalPass=false;process.exitCode=2;}
 fs.writeFileSync(path.join(packet,'VISUAL-RESULT.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({browser:result.browser,server:result.server,completed:result.completed,mechanicalPass:result.mechanicalPass,wholeElapsedMs:result.wholeElapsedMs,coverageGap:result.coverageGap,failure:result.failure?.split('\n')[0],abortReason:stopReason}));
}
