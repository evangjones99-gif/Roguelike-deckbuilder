import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/workspace/Roguelike-deckbuilder')
freeze=json.loads(Path('/workspace/scratch/first-five-opening-command-guidance-runtime-freeze-root-r8.json').read_text())
packet=Path('/workspace/scratch/root-command-guidance-r8-promotion-r1')
def sha(p):
    h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        st=os.fstat(fd)
        while b:=os.read(fd,65536):h.update(b)
        assert os.fstat(fd)==st
    finally:os.close(fd)
    return h.hexdigest()
for rel,h in freeze['inputs'].items():assert sha(root/rel)==h,rel
subprocess.run(['python3','-I','/workspace/scratch/guard-node-phase-r1.py',str(root),'/workspace/scratch/root-command-guidance-r8-build-guard-r1','384','node','scripts/build.mjs'],check=True,timeout=60)
guard=json.loads(Path('/workspace/scratch/root-command-guidance-r8-build-guard-r1/RESULT.json').read_text())
assert guard['exit_code']==0 and guard['failure'] is None
assert guard['memory_events_before']==guard['memory_events_after']
for row in guard['samples']+[guard['final']]:
    assert row['headroom']>=512*1048576 and row['current']-guard['initial']['current']<=384*1048576
    assert row['maximum']==guard['initial']['maximum'] and row['free']>=1048576
inputs={rel:sha(root/rel) for rel in freeze['inputs']}
outputs={f.relative_to(root/'dist').as_posix():sha(f) for f in sorted((root/'dist').rglob('*')) if f.is_file()}
assert inputs==freeze['inputs'] and outputs==freeze['outputs']
provenance=json.loads((root/'dist/build-provenance.json').read_text())
assert provenance['hashes']==inputs and provenance['sourceDigest']==freeze['sourceDigest']
receipt={'sourceDigest':freeze['sourceDigest'],'outputsDigest':freeze['outputsDigest'],'inputCount':len(inputs),'outputCount':len(outputs),'inputs':inputs,'outputs':outputs,'strictBuildExit':0,'samples':len(guard['samples']),'allSamplesAndFinalBoundsChecked':True,'pureRulesTests':'Unchanged engine/content/tests; retained fresh R7 111PASS. R8 affected native interaction compared separately. No duplicate unit execution claimed.','limitations':'Compiler numeric child identities not tracked here; wrapper check=True normal wait only. No new native install, primary300, pixel approval or human-fun result.'}
(packet/'ROOT-BUILD-MATCH.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['inputs','outputs']}))
