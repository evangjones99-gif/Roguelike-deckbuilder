import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { createGame, applyAction, validateState, legalActions, CARDS } from '/workspace/Roguelike-deckbuilder/src/engine.ts';
import { encounterEnvironment } from '/workspace/Roguelike-deckbuilder/src/encounter-environment.ts';
const require=createRequire('/workspace/Roguelike-deckbuilder/package.json');
const {chromium}=require('@playwright/test');
const folder='/workspace/scratch/contextual-scene-author-v08-r1';
const key='hollowpact.run.v2';
const sha=(bytes:Buffer|string)=>crypto.createHash('sha256').update(bytes).digest('hex');
function fixture(kind:string,engineKind:1|2=2) {
 const routes=[["battle"],["battle","event"],["camp","shop"],["battle","elite"],["event","shop"],["battle","elite"],["camp","shop"],["elite","battle"],["camp","event"],["boss"]];
 const node=kind==='elite'?3:routes.findIndex(route=>route.includes(kind)); assert(node>=0);
 const map=createGame(2,'normal',{engineKind}); map.floor=node; map.route=routes[node] as any;
 assert(validateState(map)); const s=applyAction(map,{type:'travel',choice:kind as any}); assert(validateState(s)); return s;
}
async function main() {
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const fixtures=[['crypt',fixture('elite')],['legacy',fixture('elite',1)],['battle',fixture('battle')],['map',createGame(2)],['camp',fixture('camp')],['shop',fixture('shop')],['event',fixture('event')]] as const;
 assert.equal(encounterEnvironment(fixtures[0][1]),'crypt');
 const results:any[]=[];
 try {
  for(const [label,s] of fixtures) for(const viewport of [{width:1440,height:900},{width:390,height:844}]) {
   let pair:any[]=[];
   for(const [build,url] of [['baseline','http://127.0.0.1:4173/'],['candidate','http://127.0.0.1:4185/']] as const) {
    const context=await browser.newContext({viewport}), page=await context.newPage(), errors:string[]=[];
    page.on('pageerror',(error:Error)=>errors.push(error.message));
    await page.addInitScript(({s,key}:any)=>{localStorage.setItem(key,JSON.stringify(s));localStorage.setItem('hollowpact.tutorial.v2','yes');localStorage.setItem('hollowpact.settings.v2',JSON.stringify({mute:true,volume:0,motion:false}));},{s,key});
    await page.goto(url); const initial=await page.evaluate(()=>getComputedStyle(document.querySelector('#scene')!,'::before').backgroundImage);
    assert(initial.includes('abbey-courtyard.png'));
    await page.locator('[data-ui="resume"]').click();
    const saved=await page.evaluate((key:string)=>localStorage.getItem(key),key); assert.equal(saved,JSON.stringify(s));
    const image=await page.evaluate(()=>getComputedStyle(document.querySelector('#scene')!,'::before').backgroundImage);
    const expected=build==='candidate' && encounterEnvironment(s)==='crypt'?'ossuary-crypt-v08-r2.png':'abbey-courtyard.png'; assert(image.includes(expected));
    if(label==='crypt') await page.screenshot({path:`${folder}/${build}-crypt-${viewport.width}.png`,fullPage:true});
    const afterReload=await page.reload(); assert(afterReload?.ok()); await page.locator('[data-ui="resume"]').click();
    assert.equal(await page.evaluate((key:string)=>localStorage.getItem(key),key),saved);
    assert((await page.evaluate(()=>getComputedStyle(document.querySelector('#scene')!,'::before').backgroundImage)).includes(expected)); assert.deepEqual(errors,[]);
    pair.push({build,viewport,expected,savedSHA256:sha(saved),environment:encounterEnvironment(s),errors}); await context.close();
   }
   assert.equal(pair[0].savedSHA256,pair[1].savedSHA256); results.push({label,pair});
  }
  for(const fallback of ['none','canvas','image']) for(const [build,url] of [['baseline','http://127.0.0.1:4173/'],['candidate','http://127.0.0.1:4185/']] as const) {
   const s=fixture('elite'); s.enemies=s.enemies.slice(0,1); s.enemies[0].hp=1; s.enemies[0].block=0;
   const pile=[...s.hand,...s.draw,...s.discard], index=pile.indexOf('scour'); assert(index>=0); s.hand=[pile.splice(index,1)[0]];s.draw=pile;s.discard=[]; assert(validateState(s));
   const action=legalActions(s).find(a=>a.type==='play'&&CARDS[s.hand[a.index]].id==='scour');assert(action);const expectedState=applyAction(s,action);assert.equal(expectedState.phase,'reward');
   const context=await browser.newContext({viewport:{width:1440,height:900}}),page=await context.newPage();
   await page.addInitScript(({s,key,fallback}:any)=>{localStorage.setItem(key,JSON.stringify(s));localStorage.setItem('hollowpact.tutorial.v2','yes');localStorage.setItem('hollowpact.settings.v2',JSON.stringify({mute:true,volume:0,motion:true})); if(fallback==='canvas'){const original=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(...args:any[]){if(this.id==='arena')return null;return (original as any).apply(this,args);} as any;}},{s,key,fallback});
   if(fallback==='image') await page.route('**/art/ossuary-crypt-v08-r2.png',(route:any)=>route.abort());
   await page.goto(url);await page.locator('[data-ui="resume"]').click();
   await page.locator('[data-ui="play-card"]').click();await page.locator('.enemy.valid-target').click();
   assert.equal(await page.evaluate((key:string)=>localStorage.getItem(key),key),JSON.stringify(expectedState));
   const style=await page.evaluate(()=>getComputedStyle(document.querySelector('#scene')!,'::before').backgroundImage); assert(style.includes(build==='candidate'?'ossuary-crypt-v08-r2.png':'abbey-courtyard.png'));
   await page.locator('[data-action="reward"]').first().waitFor();
   if(fallback==='canvas') { const fallbackImage=await page.locator('.arena-fallback').evaluate((el:Element)=>getComputedStyle(el).backgroundImage); assert(fallbackImage.includes(build==='candidate'?'ossuary-crypt-v08-r2.png':'abbey-courtyard.png')); }
   if(fallback==='image') assert((await page.locator('.arena-art-status').textContent())?.includes('could not load'));
   const next=applyAction(expectedState,{type:'reward',card:null});await page.locator('[data-action="reward"][data-card=""]').click();
   assert.equal(await page.evaluate((key:string)=>localStorage.getItem(key),key),JSON.stringify(next));assert((await page.evaluate(()=>getComputedStyle(document.querySelector('#scene')!,'::before').backgroundImage)).includes('abbey-courtyard.png'));
   results.push({fallback,build,canonicalKillSHA256:sha(JSON.stringify(expectedState)),canonicalMapSHA256:sha(JSON.stringify(next))}); await context.close();
  }
  fs.writeFileSync(`${folder}/actual-results.json`,JSON.stringify({scope:'Author diagnostic validator-valid unearned checkpoints and real canonical controls; no human, hardware or performance claims.',pairedContexts:28,terminalContexts:6,results},null,2)+'\n',{flag:'wx'});
 } finally {await browser.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
