import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
// Run from the actual retained game root. The helper path is the only varied input.
const helper=await import(pathToFileURL(path.resolve(process.env.HOLLOWPACT_GUARD_HELPER)).href);
const runtime=JSON.parse(fs.readFileSync('dist/build-provenance.json','utf8'));
const witness=helper.packagedAssetWitness(runtime,parts=>fs.readFileSync(path.join(...parts)));
const receipt=()=>({elapsedMs:100,records:witness.sounds.map(sound=>({...sound,url:`file:///C:/QA/installation/resources/app.asar/dist/audio/${sound.name}`}))});
test('negative elapsed receipt is refused',()=>{const result=receipt();result.elapsedMs=-1;assert.throws(()=>helper.assertNativeDecodedSounds(witness,result));});
test('foreign file authority receipt is refused',()=>{const result=receipt();result.records[0].url=`file://remote-host/share/resources/app.asar/dist/audio/${result.records[0].name}`;assert.throws(()=>helper.assertNativeDecodedSounds(witness,result));});
test('foreign renderer authority refuses before count/native/fetch admission',async()=>{
 const original=Object.getOwnPropertyDescriptor(globalThis,'location');
 try{
  Object.defineProperty(globalThis,'location',{configurable:true,value:{href:'file://remote-host/share/resources/app.asar/dist/index.html'}});
  await assert.rejects(()=>helper.decodeInstalledSounds(witness.sounds.slice(1)),/Not an installed ASAR sound path/);
 }finally{if(original)Object.defineProperty(globalThis,'location',original);else delete globalThis.location;}
});
