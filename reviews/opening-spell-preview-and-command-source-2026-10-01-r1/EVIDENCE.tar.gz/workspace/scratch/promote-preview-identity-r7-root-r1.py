import os,json,hashlib,shutil
from pathlib import Path
root=Path('/workspace/Roguelike-deckbuilder');stage=Path('/workspace/scratch/first-five-opening-preview-identity-stage-r7');packet=Path('/workspace/scratch/root-preview-identity-r7-promotion-r1');packet.mkdir(mode=0o700)
freeze=json.loads(Path('/workspace/scratch/first-five-opening-preview-identity-runtime-freeze-root-r7.json').read_text());assert freeze['sourceDigest']=='f08272bd35c8da907190e95f66b8c24d57a17a5a8b01ff0af247279380fe120a'
old=json.loads((root/'dist/build-provenance.json').read_text());assert old['sourceDigest']=='93162336479c7affb874164fc59136c655fae7e5f793b70afbbba4888fe1fcfb'
def body(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  st=os.fstat(fd);out=b''
  while b:=os.read(fd,65536):out+=b
  assert os.fstat(fd)==st
  return out
 finally:os.close(fd)
def sha(p):return hashlib.sha256(body(p)).hexdigest()
for rel,h in old['hashes'].items():assert sha(root/rel)==h,rel
for rel,h in freeze['inputs'].items():assert sha(stage/rel)==h,rel
for rel,h in freeze['outputs'].items():assert sha(stage/'dist'/rel)==h,rel
changes=[rel for rel,h in freeze['inputs'].items() if old['hashes'].get(rel)!=h];assert all(x.startswith('src/') for x in changes)
assert set(changes)=={'src/engine.ts','src/main.ts'}
# Preserve exact old source and non-media build bodies; all unchanged public media
# remain in the current tree/Git and have their exact old output identities below.
oldoutputs={f.relative_to(root/'dist').as_posix():sha(f) for f in sorted((root/'dist').rglob('*')) if f.is_file()}
for rel in changes:
 if (root/rel).exists():
  q=packet/'old-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(body(root/rel))
for rel,h in oldoutputs.items():
 if (root/'public'/rel).is_file():assert sha(root/'public'/rel)==h,rel
 else:
  q=packet/'old-build'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(body(root/'dist'/rel))
for rel in changes:
 target=root/rel;tmp=target.with_name(target.name+'.preview-r7-tmp');assert not tmp.exists()
 data=body(stage/rel)
 with tmp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.replace(tmp,target)
for rel,h in freeze['inputs'].items():assert sha(root/rel)==h,rel
# Preserve already-used targeted regression tests as production regression tools.
tests=['tests/compact-intent.test.ts','tests/audio-presentation-delay.test.ts'];testpins={}
for rel in tests:
 source=body(stage/rel);target=root/rel
 if target.exists():assert body(target)==source
 else:
  with target.open('xb') as f:f.write(source);f.flush();os.fsync(f.fileno())
 testpins[rel]=hashlib.sha256(source).hexdigest()
r={'status':'Exact source promoted; ROOT strict build/integration unit checks pending','producerJudgment':'Scoped first-five targeted-preview promotion conditional on separately sealed actual gameplay and visual acceptance: full actual target name and spell-resistance explanation, native target changes/cancel/commit/canonical comparison. R7 unit and strict build match exact accepted source; only two inputs differ from current R6. No general-game/AAA/human-fun/native/pixel-art acceptance.','baselineRuntime':old['sourceDigest'],'baselineCommit':'6950149fa3e26c9f1cc7a3193d7cd48015ac47b8','candidateRuntime':freeze['sourceDigest'],'candidateOutputsDigest':freeze['outputsDigest'],'sourceChanges':changes,'oldInputs':old['hashes'],'oldOutputs':oldoutputs,'newInputs':freeze['inputs'],'regressionTests':testpins,'preservation':'Old source/nonmedia build bodies copied; exact unchanged media remain in public and Git. Historical releases/stages/images/reviews/data retained. Atomic source replacement; public/trace/old stage bodies never written.'}
(packet/'PROMOTION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['oldInputs','oldOutputs','newInputs']}))
