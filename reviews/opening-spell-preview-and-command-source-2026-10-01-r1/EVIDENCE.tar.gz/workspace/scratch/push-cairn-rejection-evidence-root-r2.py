from pathlib import Path
import subprocess,json
root=Path('/workspace/Roguelike-deckbuilder')
def run(args): return subprocess.run(args,cwd=root,check=True,text=True,capture_output=True)
assert run(['git','branch','--show-current']).stdout.strip()=='codex/lanternbound-production'
run(['git','-c','gc.auto=0','add','docs/CONTINUATION.md','docs/FIRST-FIVE-MINUTES.md'])
run(['git','-c','gc.auto=0','add','-f','reviews/opening-cairn-pixel-rejection-2026-10-01-r2'])
print(run(['git','-c','gc.auto=0','commit','-m','Preserve actual paired pixel rejection and matching preview build']).stdout)
head=run(['git','rev-parse','HEAD']).stdout.strip()
print(run(['git','-c','gc.auto=0','push','origin','HEAD:codex/lanternbound-production']).stderr)
remote=run(['git','ls-remote','origin','refs/heads/codex/lanternbound-production']).stdout.split()[0]
assert head==remote
result={'head':head,'remote':remote,'pushConfirmed':True,'status':run(['git','status','--short']).stdout,'runtimeUnchanged':'93162336479c7affb874164fc59136c655fae7e5f793b70afbbba4888fe1fcfb','scope':'Closed rejected pixel trial evidence; R7 source/build only. No art/runtime promotion, cleanup or release/tag.'}
Path('/workspace/scratch/cairn-rejection-push-confirmation-root-r2.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
