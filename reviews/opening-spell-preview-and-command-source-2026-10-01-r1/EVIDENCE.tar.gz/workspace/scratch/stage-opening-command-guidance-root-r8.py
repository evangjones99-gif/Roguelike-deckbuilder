import os,json,hashlib,shutil,time
from pathlib import Path
base=Path('/workspace/scratch/first-five-opening-preview-identity-stage-r7');stage=Path('/workspace/scratch/first-five-opening-command-guidance-stage-r8');author=Path('/workspace/scratch/command-guidance-root-author-r4')
freeze=json.loads(Path('/workspace/scratch/first-five-opening-preview-identity-runtime-freeze-root-r7.json').read_text())
def digest(p):
    h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
    try:
        s=os.fstat(fd)
        while b:=os.read(fd,65536):h.update(b)
        assert os.fstat(fd)==s
    finally:os.close(fd)
    return h.hexdigest()
assert freeze['sourceDigest']=='f08272bd35c8da907190e95f66b8c24d57a17a5a8b01ff0af247279380fe120a'
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h,rel
replacements={'src/main.ts':'2027b1f73c804ab22bac0a949e26c34ea6bc9d9cd61f416f8e6072bec41d126d'}
for rel,h in replacements.items():assert digest(author/Path(rel).name)==h
stage.mkdir(mode=0o700)
for current,names,files in os.walk(base,followlinks=False):
    names[:]=[n for n in names if n not in ['dist','node_modules','public']]
    for name in names:assert not (Path(current)/name).is_symlink()
    for name in files:
        source=Path(current)/name;assert not source.is_symlink()
        rel=source.relative_to(base).as_posix();target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
        source=author/Path(rel).name if rel in replacements else source
        fd=os.open(source,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
        try:
            with target.open('xb') as f:
                while b:=os.read(fd,65536):f.write(b)
                f.flush();os.fsync(f.fileno())
        finally:os.close(fd)
(stage/'public').symlink_to(base.joinpath('public').resolve(),target_is_directory=True)
(stage/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules',target_is_directory=True)
fixture='reviews/world-rng-v0.5/golden-vectors-r1.json'
fixture_source=Path('/workspace/Roguelike-deckbuilder')/fixture
fixture_target=stage/fixture;fixture_target.parent.mkdir(parents=True,exist_ok=True)
if not fixture_target.exists():shutil.copyfile(fixture_source,fixture_target)
assert digest(fixture_source)==digest(fixture_target)
inputs={**freeze['inputs'],**replacements}
for rel,h in inputs.items():assert digest(stage/rel)==h
for rel,h in freeze['inputs'].items():assert digest(base/rel)==h
record={'stage':str(stage),'status':'COMMAND GUIDANCE R8 STAGED; UNBUILT; UNPROMOTED','baselineStage':str(base),'baselineSourceDigest':freeze['sourceDigest'],'inputs':dict(sorted(inputs.items())),'inputCount':len(inputs),'sourceDigest':hashlib.sha256(json.dumps(dict(sorted(inputs.items())),separators=(',',':')).encode()).hexdigest(),'onlyChangedInputs':list(replacements),'sharedPublicRoot':str(base.joinpath('public').resolve()),'baselineUnchanged':True,'limitations':'No new playable/brower/human-fun/art/release acceptance.'}
p=Path('/workspace/scratch/first-five-opening-command-guidance-assembly-root-r8.json')
with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
for folder in [stage,stage.parent]:fd=os.open(folder,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({k:v for k,v in record.items() if k!='inputs'}))
