// UNEXECUTED focused fixed-UI-seed R6/R7 spell preview comparison. Separate ROOT grants required.
// Uses a separately reviewed narrow R8 supervisor; no baseline gate is borrowed.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/playwright-core/index.mjs';

const [stage,freezePath,packet,portText]=process.argv.slice(2),port=Number(portText),started=Date.now();
// A single separately reviewed literal parameter file will name ROOT's repaired
// candidate. Pending parameters fail before any server/browser is launched.
const phase=stage==='/workspace/scratch/first-five-opening-row-navigation-stage-r6'?'baseline':'candidate';
const expected=JSON.parse(fs.readFileSync('/workspace/scratch/standard-sol-preview-identity-caller-author-r1/EXPECTED-'+phase.toUpperCase()+'.json'));
assert.equal(expected.status,'FROZEN_FOR_REVIEW','Repaired candidate freeze has not been supplied/reviewed');
assert.equal(stage,expected.stage);assert.equal(freezePath,expected.freezePath);
assert(packet?.startsWith('/workspace/scratch/standard-sol-preview-identity-actual-'));
assert(Number.isInteger(port)&&port>1024&&port<65536);
const hash=b=>createHash('sha256').update(b).digest('hex');
const freezeBytes=fs.readFileSync(freezePath),freeze=JSON.parse(freezeBytes);
assert.equal(hash(freezeBytes),expected.freezeSHA256);
assert.equal(freeze.stage,stage);
assert.equal(freeze.sourceDigest,expected.sourceDigest);
assert.equal(freeze.outputsDigest,expected.outputsDigest);
assert.equal(freeze.inputCount,87);assert.equal(freeze.outputCount,56);
const admission=JSON.parse(fs.readFileSync(path.join(packet,'ADMISSION.json'))),work=896*1048576,reserve=512*1048576;
const current=Number(fs.readFileSync('/sys/fs/cgroup/memory.current','utf8')),maximum=Number(fs.readFileSync('/sys/fs/cgroup/memory.max','utf8'));
const spent=Math.max(0,current-admission.initial.current);
assert(admission.admitted===true&&admission.stage===stage&&admission.freeze===freezePath&&admission.work===work&&admission.reserve===reserve&&admission.initial.maximum===maximum&&admission.initial.headroom>=work+reserve&&spent<=work&&maximum-current>=reserve+Math.max(0,work-spent),'Same outer896+512 accounting rejected');
fs.writeFileSync(path.join(packet,'INSIDE-PHASE-ACCOUNTING.json'),JSON.stringify({work,reserve,current,maximum,spent,remaining:Math.max(0,work-spent),freshAdmission:false,sameOuterAdmission:true})+'\n');
const result={scope:'Focused fixed UI seed9845209 default Initiate spell preview supplement; fresh1440x900/DPR1; no human fun, engine imports, saved-state injection, reroll, pixel integration or whole-game acceptance',sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,phase,seed:9845209,actions:[],captures:[],stepObservations:[],gates:{composition:'UNEXERCISED',settling:'OBSERVATION_ONLY; no forced state or terminal test'},authorRole:'Caller author only; independent actual reviewer decides preview/UI acceptance',browser:'NOT_LAUNCHED',server:'NOT_LAUNCHED',mechanicalPass:false,personallyViewed:false};
let browser,context,page,server,stopReason=null,timer,auditBefore=false,closingPromise=null,closedBrowser=null,closedServer=null;
const K='hollowpact.run.v2',expectedCue='Bind your first creature. Click or drag a BINDING card.';
const stamp=()=>({utc:new Date().toISOString(),wholeElapsedMs:Date.now()-started});
function log(name,data){fs.appendFileSync(path.join(packet,name),JSON.stringify({...stamp(),...data})+'\n');}
function persist(){fs.writeFileSync(path.join(packet,'VISUAL-PROGRESS.json'),JSON.stringify(result,null,2)+'\n');}
function check(){if(stopReason||Date.now()-started>=90000)throw Error(stopReason||'90s visual driver abort');}
async function hashFile(file){const h=createHash('sha256');let bytes=0;for await(const b of fs.createReadStream(file,{flags:fs.constants.O_RDONLY|fs.constants.O_NOATIME|fs.constants.O_NOFOLLOW,highWaterMark:32768})){check();h.update(b);bytes+=b.length;}return {sha256:h.digest('hex'),bytes};}
async function audit(label){
 const row={label,inputs:[],outputs:[]};assert.equal(Object.keys(freeze.inputs).length,87);assert.equal(Object.keys(freeze.outputs).length,56);
 for(const [rel,expected] of Object.entries(freeze.inputs)){check();const actual=await hashFile(path.join(stage,rel));assert.equal(actual.sha256,expected,'Input mismatch '+rel);row.inputs.push({path:rel,...actual});}
 for(const [rel,expected] of Object.entries(freeze.outputs)){check();const actual=await hashFile(path.join(stage,'dist',rel));assert.equal(actual.sha256,expected,'Output mismatch '+rel);row.outputs.push({path:rel,...actual});}
 fs.writeFileSync(path.join(packet,`BYTE-AUDIT-${label}.json`),JSON.stringify(row,null,2)+'\n');
}
async function bounded(promise,ms,label){let t;try{return await Promise.race([promise,new Promise((_,reject)=>{t=setTimeout(()=>reject(Error(label+' timeout')),ms);})]);}finally{clearTimeout(t);}}
async function close(reason){
 if(closingPromise)return closingPromise;
 closingPromise=(async()=>{
  log('LIFECYCLE.jsonl',{event:'close initiated',reason});const errors=[],ownedBrowser=browser,ownedServer=server;
  try{if(ownedBrowser){await bounded(ownedBrowser.close(),8000,'browser close');closedBrowser=ownedBrowser;result.browser='CLOSED';}}catch(e){errors.push(String(e));result.browser='CLOSE_UNCONFIRMED';}
  try{if(ownedServer){ownedServer.closeIdleConnections?.();await bounded(new Promise((resolve,reject)=>ownedServer.close(e=>e?reject(e):resolve())),2000,'server close');closedServer=ownedServer;result.server='CLOSED';}}catch(e){errors.push(String(e));result.server='CLOSE_UNCONFIRMED';}
  if(errors.length){result.closeErrors=errors;result.mechanicalPass=false;process.exitCode=2;}
  log('LIFECYCLE.jsonl',{event:errors.length?'close failures':'normal browser and server close',reason,errors});persist();
 })();return closingPromise;
}
function abort(reason){if(stopReason)return;stopReason=reason;result.abortReason=reason;result.mechanicalPass=false;process.exitCode=2;void close(reason).catch(e=>{result.closeFailure=String(e);process.exitCode=2;});}
process.once('SIGTERM',()=>abort('supervisor SIGTERM'));
timer=setTimeout(()=>abort('90s visual driver abort'),Math.max(0,90000-(Date.now()-started)));
async function rawSave(){check();return page.evaluate(k=>localStorage.getItem(k),K);}
async function settle(){check();await page.waitForTimeout(220);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));check();}
async function owned(locator){
 check();await locator.waitFor();
 // Avoid Playwright's stability-based scroll wait on already visible animated
 // actor bodies. Keep the original scoped scroll path for offscreen controls.
 const existing=await locator.boundingBox(),viewport=page.viewportSize();
 const alreadyFullyVisible=existing&&viewport&&existing.width>0&&existing.height>0&&existing.x>=0&&existing.y>=0&&existing.x+existing.width<=viewport.width&&existing.y+existing.height<=viewport.height;
 if(!alreadyFullyVisible)await locator.scrollIntoViewIfNeeded();await settle();
 let b=await locator.boundingBox();assert(b,'Missing pointer box');await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await settle();
 b=await locator.boundingBox();assert(b,'Owner vanished after hover');const point={x:b.x+b.width/2,y:b.y+b.height/2};
 // Move to the final settled coordinate that will actually be pressed. Do not
 // assert/log a recomputed center while leaving the mouse at the prior center.
 await page.mouse.move(point.x,point.y);await settle();
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},point),'Fresh actual pointer owner missing');
 assert(await locator.evaluate(e=>!e.disabled&&e.getAttribute('aria-disabled')!=='true'),'Unavailable control');return point;
}
async function click(locator,label){
 const p=await owned(locator),before=await rawSave(),n=await page.evaluate(()=>window.__cueVisualEvents.length);
 assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual press owner changed');await page.mouse.down();await page.waitForTimeout(60);check();assert(await locator.evaluate((e,p)=>{const t=document.elementFromPoint(p.x,p.y);return t===e||e.contains(t);},p),'Actual release owner changed');
 await page.mouse.up();await settle();const events=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);assert(events.some(e=>e.type==='pointerdown'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1)&&events.some(e=>e.type==='pointerup'&&e.trusted&&Math.abs(e.x-p.x)<=1&&Math.abs(e.y-p.y)<=1),'Missing trusted native press/release at actual checked coordinates');
 result.actions.push({label,point:p,beforeSHA:before===null?null:hash(before),afterSHA:await rawSave().then(v=>v===null?null:hash(v)),events});persist();
}
async function shot(label){
 check();assert(result.captures.length<6,'Capture cap exceeded');const file=path.join(packet,`${String(result.captures.length+1).padStart(2,'0')}-${label}.png`);await page.screenshot({path:file,type:'png'});result.captures.push({label,path:file,...await hashFile(file),personallyViewed:false});persist();
}
try{
 await audit('before');auditBefore=true;check();const keys=Object.keys(freeze.outputs).sort();
 server=http.createServer((req,res)=>{try{const pathname=new URL(req.url,'http://localhost').pathname,key=pathname==='/'?'index.html':decodeURIComponent(pathname.slice(1));if(!keys.includes(key)){res.writeHead(404);res.end('Not found');return;}res.setHeader('Content-Type',key.endsWith('.html')?'text/html':key.endsWith('.js')?'text/javascript':key.endsWith('.css')?'text/css':key.endsWith('.png')?'image/png':key.endsWith('.json')?'application/json':'application/octet-stream');const stream=fs.createReadStream(path.join(stage,'dist',key));stream.on('error',()=>res.destroy());stream.pipe(res);}catch{res.writeHead(400);res.end('Bad request');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});result.server='OPEN';
 const served=[];for(const rel of keys){check();const response=await fetch(`http://127.0.0.1:${port}/${rel.split('/').map(encodeURIComponent).join('/')}`,{signal:AbortSignal.timeout(8000)});assert(response.ok,'Serve failed '+rel);const h=createHash('sha256');let bytes=0;for await(const b of response.body){check();h.update(b);bytes+=b.length;}const sha256=h.digest('hex');assert.equal(sha256,freeze.outputs[rel],'Served mismatch '+rel);served.push({path:rel,bytes,sha256});}
 fs.writeFileSync(path.join(packet,'SERVED-BYTE-AUDIT.json'),JSON.stringify({sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,served},null,2)+'\n');
 check();browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox'],timeout:12000});result.browser='OPEN';check();
 context=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'no-preference'});
 // Passive pre-app WINDOW capture sees handled drag Escape before the game
 // stops propagation there; it never prevents, stops or dispatches any input.
 await context.addInitScript(()=>{window.__cueVisualEvents=[];for(const type of ['pointerdown','pointerup','click','focusin','keydown'])window.addEventListener(type,e=>{const card=e.target.closest?.('.hand-cards .game-card');
 // This listener was installed before application handlers. Native pointerdown
 // reads the exact then-visible rect, before tactile-pressed changes transforms.
 const pointerdownSource=type==='pointerdown'&&card?{rect:card.getBoundingClientRect().toJSON(),offsetWidth:card.offsetWidth,offsetHeight:card.offsetHeight,computedWidth:getComputedStyle(card).width,computedHeight:getComputedStyle(card).height,transform:getComputedStyle(card).transform}:undefined;
 window.__cueVisualEvents.push({type,trusted:e.isTrusted,observedAtMs:performance.now(),key:e.key,x:e.clientX,y:e.clientY,ui:e.target.closest?.('[data-ui]')?.dataset.ui,card:e.target.closest?.('[data-card]')?.dataset.card,index:e.target.closest?.('[data-card]')?.dataset.index,pointerdownSource});if(window.__cueVisualEvents.length>1000)window.__cueVisualEvents.splice(0,200);},{capture:true,passive:true});});
 page=await context.newPage();page.setDefaultTimeout(5000);page.on('pageerror',e=>log('ERRORS.jsonl',{kind:'pageerror',error:String(e)}));
// Finite native UI path; DOM and local save are observed only, never injected.
async function step(label){
 check();const raw=await rawSave(),row=await page.evaluate(()=>{
  const a=document.activeElement,preview=document.querySelector('#consequence-preview'),dialog=document.querySelector('#dialog');
  const describe=e=>({unit:e.dataset.unit,focus:e.dataset.focus,card:e.dataset.card,index:e.dataset.index,aria:e.getAttribute('aria-label'),disabled:e.disabled});
  const text=e=>{const c=getComputedStyle(e),r=document.createRange();r.selectNodeContents(e);return {text:e.innerText,rect:e.getBoundingClientRect().toJSON(),glyphRect:r.getBoundingClientRect().toJSON(),fontSize:c.fontSize,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,scrollTop:e.scrollTop,overflowX:c.overflowX,overflowY:c.overflowY};};
  const selected=[...document.querySelectorAll('.hand-cards .game-card.selected')];
  return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio,scrollX,scrollY,documentWidth:document.documentElement.scrollWidth,documentHeight:document.documentElement.scrollHeight},active:a?describe(a):null,dialogOpen:dialog.open,activeInDialog:!!a&&dialog.contains(a),cancel:[...document.querySelectorAll('[data-ui="cancel"]')].filter(e=>e.getClientRects().length).map(describe),selectedCards:selected.map(e=>({...describe(e),name:text(e.querySelector('.card-name')),cost:text(e.querySelector('.card-cost')),rules:text(e.querySelector('.card-description'))})),preview:preview?{...text(preview),kind:preview.dataset.preview,role:preview.getAttribute('role'),live:preview.getAttribute('aria-live')}:null,legalTargets:[...document.querySelectorAll('.field-unit.valid-target:not(:disabled)')].map(describe),actors:[...document.querySelectorAll('.field-unit')].map(describe),settling:document.querySelector('#app').classList.contains('settling-combat')};
 });const evidence={label,...stamp(),phase,saveSHA:raw===null?null:hash(raw),...row};result.stepObservations.push(evidence);log('STEPS.jsonl',evidence);console.log(JSON.stringify({event:'actual-preview-step',...evidence}));persist();return evidence;
}
async function key(keyText,label){
 check();assert(result.actions.length<40,'Focused action cap exceeded');const before=await rawSave(),n=await page.evaluate(()=>window.__cueVisualEvents.length);
 await page.keyboard.press(keyText);await settle();const events=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);
 assert(events.some(e=>e.type==='keydown'&&e.trusted&&e.key.toLowerCase()===keyText.toLowerCase()),'Missing trusted native key '+keyText);assert.equal(await rawSave(),before,'Preview/navigation/cancel changed canonical save: '+label);
 result.actions.push({label,key:keyText,savePure:true,saveSHA:before===null?null:hash(before),events});persist();return step(label);
}
async function selectSunder(label){
 const before=await rawSave(),card=page.locator('.hand-cards .game-card[data-card="sunder"][aria-disabled="false"]');assert.equal(await card.count(),1,'No unique actual legal Sunder occurrence; no reroll');
 const occurrence=await card.evaluate(e=>({id:e.dataset.card,index:Number(e.dataset.index),name:e.querySelector('.card-name').innerText,rules:e.querySelector('.card-description').innerText,cost:e.querySelector('.card-cost').innerText}));assert.equal(JSON.parse(before).hand[occurrence.index],'sunder');assert.match(occurrence.rules,/3 damage/);result.cardOccurrence=occurrence;
 await click(card,label);assert.equal(await rawSave(),before,'Card selection changed canonical save');const row=await step(label);
 assert.equal(row.cancel.length,1,'Real selection/Cancel absent; stop instead of opening Pause');assert(row.selectedCards.some(c=>c.card==='sunder'&&Number(c.index)===occurrence.index),'Actual Sunder occurrence not selected');assert.equal(row.legalTargets.length,2);return row;
}
async function revenantFocus(label){
 let row=await key('t',label+' native T');if(row.active.unit!==revenant.uid){assert.equal(row.active.unit,other.uid,'Unexpected legal target focus; stop');row=await key('ArrowRight',label+' native Right');}
 assert.equal(row.active.unit,revenant.uid);assert(row.legalTargets.some(t=>t.unit===revenant.uid));assert.equal(row.preview?.kind,'consequence');assert.match(row.preview.text,/1 health damage/);
 if(phase==='candidate'){assert(row.preview.text.includes(fullTarget),'R7 full name/ordinal missing');assert(row.preview.text.includes('spell resistance −2'),'R7 resistance reason missing');}
 else{assert(row.preview.text.includes('hostile 2'));assert(!row.preview.text.includes('spell resistance'),'R6 unexpected resistance explanation');}
 return row;
}
 await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded',timeout:12000});await settle();await step('fresh interactive title');
 await click(page.locator('#scene-ui [data-ui="new"]'),'open ordinary contract');result.originalGeneratedFormSeed=await page.locator('#seed').inputValue();await step('ordinary new contract');
 await click(page.locator('[data-hunt-disclosure="hunt-seed-panel"]'),'open native Set a seed');await click(page.locator('#seed'),'focus visible seed');await page.keyboard.press('Control+a');await page.keyboard.type('9845209');assert.equal(await page.locator('#seed').inputValue(),'9845209');assert.equal(await page.locator('input[name="difficulty"]:checked').inputValue(),'0');await step('native seed typed; default Initiate unchanged');
 await click(page.locator('#new-game-form [type="submit"]'),'accept fixed-seed default Initiate');await page.waitForTimeout(600);await settle();
 const initialRaw=await rawSave(),initial=JSON.parse(initialRaw);assert.equal(initial.seed,9845209);assert.equal(initial.difficulty,0);assert.equal(initial.phase,'battle');assert.equal(initial.turn,1);assert.equal(initial.allies.length,0);assert.deepEqual(initial.hand,['cairnhound','fenstalker','sunder','sutures','survey'],'Actual opening precondition unmet; no reroll');assert.equal(initial.enemies.length,2);
 const revenant=initial.enemies[1],other=initial.enemies[0];assert.equal(revenant.cardId,'revenant');assert.equal(revenant.block,0);assert(revenant.hp>1);const fullTarget=`${revenant.name} · hostile 2`;
 result.actualOpening={seed:initial.seed,difficulty:initial.difficulty,hand:initial.hand,enemies:initial.enemies,allies:initial.allies,saveSHA:hash(initialRaw)};await step('actual deterministic opening; no bindings/commands yet');
 await selectSunder('select actual printed Sunder');let row=await key('t','focus actual legal hostile row');
 if(row.active.unit!==other.uid){assert.equal(row.active.unit,revenant.uid);row=await key('ArrowLeft','Left to other actual legal target');}assert.equal(row.active.unit,other.uid);assert.equal(row.preview?.kind,'consequence');assert.match(row.preview.text,/3 health damage/);result.otherTargetPreview=row.preview;
 row=await revenantFocus('focus resistance target');result.resistantPreview=row.preview;await shot('revenant-live-preview');
 row=await key('Tab','native Tab after target preview');assert(row.active.unit!==revenant.uid,'Native Tab did not move focus');assert.equal(row.cancel.length,1,'Selection disappeared before cancel');
 // Escape is used only after observing the real live Cancel control.
 row=await key('Escape','cancel real selected Sunder');assert.equal(row.cancel.length,0);assert.equal(row.selectedCards.length,0);assert(!row.dialogOpen,'Escape opened Pause instead of cancelling');assert.equal(await rawSave(),initialRaw);await shot('cancel-save-preserved');
 await selectSunder('reselect same preserved Sunder occurrence');row=await revenantFocus('reselect exact resistance target');assert.equal(row.cancel.length,1);assert.equal(await rawSave(),initialRaw);result.precommitPreview=row.preview;
 const n=await page.evaluate(()=>window.__cueVisualEvents.length);assert.equal(row.active.unit,revenant.uid);assert(row.legalTargets.some(t=>t.unit===revenant.uid));await page.keyboard.press('Enter');await page.waitForTimeout(600);await settle();
 const commitEvents=await page.evaluate(n=>window.__cueVisualEvents.slice(n),n);assert(commitEvents.some(e=>e.type==='keydown'&&e.trusted&&e.key==='Enter'),'Missing native legal-target commit');const finalRaw=await rawSave(),final=JSON.parse(finalRaw),afterTarget=final.enemies.find(e=>e.uid===revenant.uid);
 assert(afterTarget);assert.equal(revenant.hp-afterTarget.hp,1,'Actual committed loss differs from live preview');assert.equal(final.energy,initial.energy-1);assert.deepEqual(final.hand,initial.hand.filter((_,i)=>i!==result.cardOccurrence.index));assert.deepEqual(final.allies,initial.allies);assert.deepEqual(final.enemies.find(e=>e.uid===other.uid),other);assert.equal(final.rng,initial.rng);assert.equal(final.phase,'battle');
 result.actions.push({label:'native Enter commits actual Sunder against Revenant',targetUid:revenant.uid,targetName:fullTarget,printedRules:result.cardOccurrence.rules,beforeSHA:hash(initialRaw),afterSHA:hash(finalRaw),healthLoss:revenant.hp-afterTarget.hp,beforeTarget:revenant,afterTarget,events:commitEvents});result.canonicalComparison={seed:9845209,cardOccurrence:result.cardOccurrence,targetUid:revenant.uid,initialRawSHA:hash(initialRaw),finalRawSHA:hash(finalRaw),healthLoss:revenant.hp-afterTarget.hp,beforeEnergy:initial.energy,afterEnergy:final.energy,afterHand:final.hand,afterEnemies:final.enemies};await step('actual committed preview-matching one-health loss');await shot('native-spell-committed');
 await click(page.locator('[data-ui="help"]'),'ordinary optional Help after committed action');row=await step('actual native Help');assert(row.dialogOpen&&row.activeInDialog);await shot('native-help');row=await key('Tab','native Tab inside Help');assert(row.dialogOpen&&row.activeInDialog);row=await key('Escape','native Escape closes actual Help');assert(!row.dialogOpen);assert.equal(await rawSave(),finalRaw);
 fs.writeFileSync(path.join(packet,'CANONICAL-COMPARISON.json'),JSON.stringify({observedOnly:true,sourceDigest:freeze.sourceDigest,outputsDigest:freeze.outputsDigest,...result.canonicalComparison},null,2)+'\n');fs.writeFileSync(path.join(packet,'LAST-ACTUAL-SAVE.json'),JSON.stringify({observedOnly:true,raw:finalRaw})+'\n');check();result.completed=true;result.mechanicalPass=true;
}catch(e){result.failure=e.stack;result.mechanicalPass=false;process.exitCode=2;log('FAILURE.jsonl',{error:String(e)});}
finally{
 await close(stopReason||'visual checks completed or failed');
 // Cancellation can race async launch/listen. An earlier completed close does
 // not cover a subsequently returned owned browser/server; retire those too.
 if(browser&&browser!==closedBrowser||server&&server!==closedServer){closingPromise=null;await close('final late-created or unconfirmed owned-resource cleanup');}
 if(auditBefore&&!stopReason){try{await audit('after');}catch(e){result.afterAuditFailure=e.stack;result.mechanicalPass=false;process.exitCode=2;}}
 clearTimeout(timer);result.wholeElapsedMs=Date.now()-started;if(stopReason){result.mechanicalPass=false;process.exitCode=2;}
 fs.writeFileSync(path.join(packet,'VISUAL-RESULT.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({browser:result.browser,server:result.server,completed:result.completed,mechanicalPass:result.mechanicalPass,wholeElapsedMs:result.wholeElapsedMs,coverageGap:result.coverageGap,failure:result.failure?.split('\n')[0],abortReason:stopReason}));
}
