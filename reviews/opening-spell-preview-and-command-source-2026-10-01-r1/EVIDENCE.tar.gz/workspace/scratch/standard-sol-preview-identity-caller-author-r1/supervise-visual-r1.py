import os,sys,time,json,pathlib,subprocess,signal
stage,freeze,packet,port=sys.argv[1:];p=pathlib.Path(packet);p.mkdir(exist_ok=False)
work=896*1048576;reserve=512*1048576;cgroup=pathlib.Path('/sys/fs/cgroup')
def sample():
 c=int((cgroup/'memory.current').read_text());m=int((cgroup/'memory.max').read_text());return {'time_ns':time.time_ns(),'current':c,'maximum':m,'headroom':m-c,'free':os.statvfs(stage).f_bavail*os.statvfs(stage).f_frsize}
def identities(group):
 allp={}
 for d in pathlib.Path('/proc').iterdir():
  if not d.name.isdigit():continue
  try:
   raw=(d/'stat').read_text();f=raw[raw.rindex(')')+2:].split()
   allp[d.name]={'starttime':f[19],'state':f[0],'ppid':int(f[1]),'pgrp':int(f[2])}
  except (OSError,ValueError,IndexError):pass
 result={pid:v for pid,v in allp.items() if v['pgrp']==group or (pid in owned and v['starttime']==owned[pid]['starttime'])}
 changed=True
 while changed:
  changed=False
  for pid,v in allp.items():
   if pid not in result and str(v['ppid']) in result:result[pid]=v;changed=True
 return result

def stop_owned(sig):
 now=identities(proc.pid);owned.update(now);receipt=[]
 for pid,v in sorted(now.items(),key=lambda x:int(x[0]),reverse=True):
  if v['state']=='Z':continue
  try:
   raw=pathlib.Path('/proc',pid,'stat').read_text();f=raw[raw.rindex(')')+2:].split()
   if f[19]!=v['starttime'] or int(f[2])!=v['pgrp']:continue
   if pathlib.Path('/proc',pid).stat().st_uid!=os.getuid():continue
   fd=os.pidfd_open(int(pid))
   try:
    check=pathlib.Path('/proc',pid,'stat').read_text();check=check[check.rindex(')')+2:].split()
    if check[19]!=v['starttime']:continue
    signal.pidfd_send_signal(fd,sig)
   finally:os.close(fd)
   receipt.append({'pid':pid,'starttime':v['starttime'],'signal':int(sig)})
  except (OSError,ValueError,IndexError):pass
 with (p/'STOP-IDENTITIES.jsonl').open('a') as log:log.write(json.dumps({'time_ns':time.time_ns(),'signals':receipt})+'\n')
initial=sample();before=(cgroup/'memory.events').read_text();admitted=initial['headroom']>=work+reserve and initial['free']>=64*1048576
(p/'ADMISSION.json').write_text(json.dumps({'admitted':admitted,'initial':initial,'work':work,'reserve':reserve,'stage':stage,'freeze':freeze,'whole_wall_ceiling_seconds':120},indent=2)+'\n')
if not admitted:print('REFUSED',json.dumps(initial));sys.exit(75)
rows=[];owned={};failure=None;cleanup_errors=[];proc=None;rootfd=None;rc=None;remaining={};start=time.monotonic();log=None

def error(where,e):
 cleanup_errors.append({'where':where,'error':repr(e)})

def observe():
 now=identities(proc.pid);owned.update(now);return now

def safe_poll():
 try:return proc.poll()
 except BaseException as e:error('child poll',e);return None

def root_signal(sig):
 # A pidfd holds our exact launched child. Before wait/reap, Popen's own
 # unreaped child is also non-reusable if acquiring a pidfd itself failed.
 if proc is None:return
 try:
  if rootfd is not None:signal.pidfd_send_signal(rootfd,sig)
  else:proc.send_signal(sig)
 except ProcessLookupError:pass

try:
 log=(p/'EXECUTION.log').open('xb')
 proc=subprocess.Popen(['node','/workspace/scratch/standard-sol-preview-identity-caller-author-r1/driver-visual-r1.mjs',stage,freeze,packet,port],cwd=stage,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 rootfd=os.pidfd_open(proc.pid)
 launch=observe()
 (p/'OWNED-LAUNCH.json').write_text(json.dumps({'pid':proc.pid,'pgrp':proc.pid,'identities':launch,'utc_ns':time.time_ns()})+'\n')
 while safe_poll() is None:
  if cleanup_errors:failure={'kind':'child poll failed','errors':cleanup_errors.copy()};break
  row=sample();row['delta']=row['current']-initial['current'];row['elapsed']=time.monotonic()-start;rows.append(row);observe()
  if row['headroom']<reserve or row['delta']>work or row['free']<1048576 or row['elapsed']>=110:
   failure={'kind':'resource or 110s cancellation','sample':row};break
  time.sleep(.1)
except BaseException as e:
 failure={'kind':'post-admission lifecycle exception','error':repr(e)}
finally:
 # This path also runs for launch-receipt, sampling, identity, signal-log,
 # wait or execution-log errors. It never signals historical/global zombies.
 if proc is not None:
  try:
   now=observe();live={k:v for k,v in now.items() if v['state']!='Z'}
  except BaseException as e:
   error('initial cleanup observation',e);live=None
  if safe_poll() is None or live or live is None:
   if failure is None:failure={'kind':'live descendants or driver still active at cleanup'}
   try:stop_owned(signal.SIGTERM)
   except BaseException as e:error('scoped TERM',e)
   try:root_signal(signal.SIGTERM)
   except BaseException as e:error('exact launched-child TERM',e)
   term_end=min(time.monotonic()+5,start+115)
   while time.monotonic()<term_end:
    try:
     now=observe();live={k:v for k,v in now.items() if v['state']!='Z'}
     if safe_poll() is not None and not live:break
    except BaseException as e:
     error('TERM observation',e);break
    time.sleep(.1)
   try:stop_owned(signal.SIGKILL)
   except BaseException as e:error('scoped KILL',e)
   try:root_signal(signal.SIGKILL)
   except BaseException as e:error('exact launched-child KILL',e)
  try:
   if safe_poll() is None:
    seconds=min(2,max(0,start+119-time.monotonic()))
    if seconds:rc=proc.wait(timeout=seconds)
    else:rc=safe_poll();error('wait','no deadline margin; child status unresolved')
   else:rc=proc.wait(timeout=0)
  except BaseException as e:
   error('bounded child wait',e)
   try:root_signal(signal.SIGKILL)
   except BaseException as kill_error:error('fallback launched-child KILL',kill_error)
   rc=safe_poll()
  try:remaining=observe()
  except BaseException as e:error('final descendant observation',e);remaining=None
 if rootfd is not None:
  try:os.close(rootfd)
  except BaseException as e:error('pidfd close',e)
 if log is not None:
  try:log.flush();os.fsync(log.fileno())
  except BaseException as e:error('execution log fsync',e)
  try:log.close()
  except BaseException as e:error('execution log close',e)

try:final=sample()
except BaseException as e:error('final resource sample',e);final=None
try:after=(cgroup/'memory.events').read_text()
except BaseException as e:error('final memory.events',e);after=None
live_remaining=None if remaining is None else {k:v for k,v in remaining.items() if v['state']!='Z'}
zombies=None if remaining is None else {k:v for k,v in remaining.items() if v['state']=='Z'}
whole=time.monotonic()-start
checks={
 'sampled_resources':bool(rows) and all(r['maximum']==initial['maximum'] and r['headroom']>=reserve and r['delta']<=work and r['free']>=1048576 for r in rows),
 'final_resources':final is not None and final['maximum']==initial['maximum'] and final['headroom']>=reserve and final['current']-initial['current']<=work and final['free']>=1048576,
 'memory_events_unchanged':after is not None and before==after,
 'whole_within120':whole<=120,
 'no_observed_tracked_live_descendants':live_remaining=={},
 'driver_rc0':rc==0,
 'no_lifecycle_or_cleanup_failure':failure is None and not cleanup_errors,
}
normal=all(checks.values())
result={'exit_code':rc,'failure':failure,'cleanup_errors':cleanup_errors,'checks':checks,'initial':initial,'final':final,'samples':rows,'memory_events_before':before,'memory_events_after':after,'owned_observed':owned,'post_wait_descendants':remaining,'tracked_zombies':zombies,'live_remaining':live_remaining,'normal_wait':normal,'whole_seconds':whole,'scope':'896 total cgroup-delta work plus unchanged512 reserve; observed own descendants across groups retained by PID/starttime; zombies nonlive/unreaped; incomplete identity/write observations remain unknown, no universal unobserved-escape proof'}
try:
 with (p/'RESULT.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
except BaseException as e:
 print(json.dumps({'result_write_failed':repr(e),'normal_wait':False,'pid':None if proc is None else proc.pid,'owned_known':owned,'failure':failure,'cleanup_errors':cleanup_errors}));sys.exit(76)
print(json.dumps({k:v for k,v in result.items() if k not in ['samples','owned_observed','memory_events_before','memory_events_after','post_wait_descendants','tracked_zombies']}));sys.exit(0 if normal else 76)
