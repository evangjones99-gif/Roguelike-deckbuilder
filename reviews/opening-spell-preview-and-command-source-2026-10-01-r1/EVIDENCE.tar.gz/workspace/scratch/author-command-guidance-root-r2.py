from pathlib import Path
import hashlib,json,difflib
root=Path('/workspace/Roguelike-deckbuilder')
base=Path('/workspace/scratch/first-five-opening-preview-identity-stage-r7/src/main.ts')
text=base.read_text(); original=text
assert hashlib.sha256(base.read_bytes()).hexdigest()=='b56e5a6a931c3780f160aee19fd550a27d45a700217f933c8d1e8be8bf897cc4'
out=Path('/workspace/scratch/command-guidance-root-author-r2');out.mkdir(exist_ok=False)
def replace(old,new):
    global text
    assert text.count(old)==1,old
    text=text.replace(old,new,1)
replace("let settlingCombat = false;", "let settlingCombat = false;\n// Automatic focus restoration is not a request to preview the next card.\nlet restoringRenderFocus = false;\nlet renderingIssuedCommand = false;")
replace("  const previous = state;\n  const { state: next, events } = applyActionWithEvents(state, action);", "  const previous = state;\n  let issuedCommand: string | null = null;\n  if (action.type === 'attack') {\n    try { issuedCommand = consequencePreview(action).text; } catch { /* Optional text cannot block an order. */ }\n  }\n  const { state: next, events } = applyActionWithEvents(state, action);")
replace("  render();\n  if (terminalCombat) announceOutcome();", "  renderingIssuedCommand = !!issuedCommand && !terminalCombat && !effectFailed && !!arena && mayAnimateCombat();\n  try { render(); } finally { renderingIssuedCommand = false; }\n  // Rules have resolved; retain their source/target/result while that command\n  // is still visibly playing. A deliberate new focus/hover can replace this.\n  if (!terminalCombat && state.phase === 'battle' && issuedCommand && !effectFailed && mayAnimateCombat()) {\n    let busy = 0;\n    try { busy = Number(arena?.busyMs() || 0); } catch { /* No presentation attribution without a live cue. */ }\n    const output = document.getElementById('consequence-preview');\n    if (Number.isFinite(busy) && busy > 0 && output) {\n      activePreviewKey = '';\n      output.textContent = `Command issued: ${issuedCommand}`;\n      output.dataset.preview = 'issued-command';\n      output.closest('.battle-guidance')?.classList.remove('danger-preview');\n    }\n  }\n  if (terminalCombat) announceOutcome();")
replace("  if (!$<HTMLDialogElement>('dialog').open && (changedScreen || !restoreFocus(reference))) focusScene();", "  // Preserve the same focus target without treating this internal restoration\n  // as an intentional request for a different card's consequence.\n  restoringRenderFocus = true;\n  try {\n    if (!$<HTMLDialogElement>('dialog').open && (changedScreen || !restoreFocus(reference))) focusScene();\n  } finally { restoringRenderFocus = false; }")
replace("  if (title || settlingCombat || state.phase !== 'battle') return false;", "  if (title || settlingCombat || (restoringRenderFocus && renderingIssuedCommand) || state.phase !== 'battle') return false;")
(out/'main.ts').write_text(text)
(out/'EXACT-DIFF.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='R7/main.ts',tofile='candidate/main.ts')))
(out/'PROPOSAL.md').write_text('''# Issued command attribution: source-only candidate

Actual R5 and paired Cairn R2 captures show Survey consequence text while a genuine Cairn strike remains visibly resolving. The shared host renders the canonical result and programmatically restores focus; focusin then previews a newly focused first card. This proposal suppresses consequence generation only during synchronous focus restoration of an accepted nonterminal animated command and, for an accepted nonterminal attack with a live positive arena cue, displays the same pure consequence text captured before canonical mutation, prefixed Command issued. Deliberate subsequent focus/hover/selection remains authoritative; legal actions, saves, clocks, controls and terminal hold are unchanged. There is no new timer, animation lock, end-turn/summon effect or state field. Optional preview failures are caught and cannot prevent dispatch.

The text is a deterministic reducer consequence, not confirmation that a particular animation cel/contact has occurred. Canonical persistence still precedes animation. It may remain as the last-issued order after the optional cue until the next intentional interaction/render, so the wording makes no continuously-playing claim. Review must test actual restore versus deliberate hover/keyboard, cancellation, reduced motion, terminal behavior and live-text fit. Startup, other actions, selection/cancel renders and motion-off paths retain normal automatic focus previews. The issued-command flag is scoped to the synchronous render and reset in finally; its predicate does not lock any controls. No general render-preview suppression is selected. A stationary pointerover after DOM replacement may still supersede the label; actual observation is needed.

Based on immutable R7 main b56e5a6a…, not promoted ROOT. Only a new source file/diff is authored. No source/runtime/stage/public/art mutation, execution, actual improvement, timing, human-fun or promotion claim. Prior R7/root/failed art materials remain.
''')
files=[]
for p in sorted(out.iterdir()):
    b=p.read_bytes(); files.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'MANIFEST.json').write_text(json.dumps({'status':'SOURCE ONLY; independent review and actual comparison pending','baseMain':hashlib.sha256(base.read_bytes()).hexdigest(),'files':files},indent=2)+'\n')
print(json.dumps(files))
