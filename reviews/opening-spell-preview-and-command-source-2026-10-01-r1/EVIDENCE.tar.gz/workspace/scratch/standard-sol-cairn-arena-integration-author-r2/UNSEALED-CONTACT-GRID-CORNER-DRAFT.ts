/** Cairn-only prototype. Original R5 art is an unselected study; independent static review allows a runtime trial only.
 * No rules, RNG, saves, action dispatch or extra clocks live in this module.
 * Half-open native bounds and painted support contacts come from pinned R5 metadata.
 */
import type { Unit } from './engine';
import type { BattlefieldRect } from './battlefield-layout';
import { CREATURE_IMPACT_MS, type CreaturePose } from './art';

export const CAIRN_PIXEL_URL = `${import.meta.env.BASE_URL}art/cairn-hound-pixel-r5.png`;
export const CAIRN_PIXEL_SCALE = 2;
export const CAIRN_PIXEL_SIZE = 64 * CAIRN_PIXEL_SCALE;
export const CAIRN_PIXEL_ANCHOR = [28, 58] as const;
export const CAIRN_PIXEL_UNION = [8, 13, 63, 60] as const;
const leftExtent = (CAIRN_PIXEL_ANCHOR[0] - CAIRN_PIXEL_UNION[0]) * CAIRN_PIXEL_SCALE;
const rightExtent = (CAIRN_PIXEL_UNION[2] - CAIRN_PIXEL_ANCHOR[0]) * CAIRN_PIXEL_SCALE;
const topExtent = (CAIRN_PIXEL_ANCHOR[1] - CAIRN_PIXEL_UNION[1]) * CAIRN_PIXEL_SCALE;
const bottomExtent = (CAIRN_PIXEL_UNION[3] - CAIRN_PIXEL_ANCHOR[1]) * CAIRN_PIXEL_SCALE;
const horizontalExtent = Math.max(leftExtent, rightExtent);
// Native2x union L40/R70 (mirror L70/R40), top90/bottom4.
// Symmetric centre-origin reserve including4px margin:148x102.
export function cairnPixelShapeExtents(facing: -1 | 1) {
  return { left: (facing === 1 ? leftExtent : rightExtent) / CAIRN_PIXEL_SIZE,
    right: (facing === 1 ? rightExtent : leftExtent) / CAIRN_PIXEL_SIZE,
    top: topExtent / CAIRN_PIXEL_SIZE, bottom: bottomExtent / CAIRN_PIXEL_SIZE };
}
export const CAIRN_PIXEL_FRAMES = [
  { name: 'arrival0', bounds: [12,24,58,59], feet: [[22,58],[44,56]], nose: [56,32] },
  { name: 'arrival1', bounds: [11,17,59,59], feet: [[22,58],[44,55]], nose: [57,25] },
  { name: 'idle0', bounds: [11,16,60,59], feet: [[22,58],[44,55]], nose: [58,24] },
  { name: 'idle1', bounds: [12,18,60,59], feet: [[22,58],[45,54]], nose: [58,25] },
  { name: 'anticipation', bounds: [9,21,62,59], feet: [[19,58],[46,56]], nose: [60,28] },
  { name: 'contact0', bounds: [8,13,63,59], feet: [[17,58],[46,51]], nose: [61,22] },
  { name: 'contact1', bounds: [10,17,63,59], feet: [[19,58],[48,53]], nose: [61,25] },
  { name: 'recovery', bounds: [13,19,58,59], feet: [[24,58],[43,55]], nose: [56,29] },
  { name: 'hit', bounds: [13,22,55,59], feet: [[24,58],[45,56]], nose: [53,31] },
  { name: 'death', bounds: [10,40,59,60], feet: [[24,58],[45,56]], nose: [57,50] },
] as const;

export function isPixelCairn(unit: Pick<Unit, 'cardId' | 'species'>, side: 'ally' | 'enemy') {
  return side === 'ally' && unit.cardId === 'cairnhound' && unit.species === 'hound';
}
export function cairnPixelFits(body: BattlefieldRect) {
  // Both target facings reserve the complete pose union at the SAME native2x.
  return body.width >= horizontalExtent * 2 + 8 && body.height >= topExtent + bottomExtent + 8;
}
export function cairnPixelFeet(body: BattlefieldRect) {
  return { x: Math.round(body.left + body.width / 2), y: Math.round(body.top + body.height - bottomExtent - 4) };
}
export function cairnPixelFrame(pose: CreaturePose, now: number, born: number,
  gestureBorn: number | null, reduced: boolean, deadAt: number | null) {
  if (deadAt !== null && now >= deadAt) return 9;
  if (reduced) return 2;
  if (pose === 'reaction') return 8;
  if (pose === 'anticipation') return 4;
  if (pose === 'attack') return gestureBorn !== null && now - gestureBorn >= CREATURE_IMPACT_MS / 1000 ? 6 : 5;
  if (pose === 'recovery') return 7;
  const arrival = now - born;
  if (arrival < .16) return 0;
  if (arrival < .32) return 1;
  return Math.floor(Math.max(0, arrival - .32) / .55) % 2 === 0 ? 2 : 3;
}
export function cairnPixelBounds(index: number, origin: { x: number; y: number }, facing: -1 | 1): BattlefieldRect {
  const [left, top, right, bottom] = CAIRN_PIXEL_FRAMES[index].bounds;
  const x1 = (left - CAIRN_PIXEL_ANCHOR[0]) * CAIRN_PIXEL_SCALE * facing;
  const x2 = (right - CAIRN_PIXEL_ANCHOR[0]) * CAIRN_PIXEL_SCALE * facing;
  return { left: origin.x + Math.min(x1, x2), top: origin.y + (top - CAIRN_PIXEL_ANCHOR[1]) * CAIRN_PIXEL_SCALE,
    width: (right - left) * CAIRN_PIXEL_SCALE, height: (bottom - top) * CAIRN_PIXEL_SCALE };
}
export function cairnPixelContactRoot(target: { x: number; y: number }, body: BattlefieldRect, facing: -1 | 1) {
  // Existing impact selects contact1: nose[61,25]; contact0 nose[61,22]
  // is pre-impact only. Preserve the full union allocation; any gap is honest.
  const [noseX, noseY] = CAIRN_PIXEL_FRAMES[6].nose;
  const left = facing === 1 ? leftExtent : rightExtent;
  const right = facing === 1 ? rightExtent : leftExtent;
  const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
  return { x: clamp(target.x - (noseX - CAIRN_PIXEL_ANCHOR[0]) * CAIRN_PIXEL_SCALE * facing,
      body.left + left + 4, body.left + body.width - right - 4),
    y: clamp(target.y - (noseY - CAIRN_PIXEL_ANCHOR[1]) * CAIRN_PIXEL_SCALE,
      body.top + topExtent + 4, body.top + body.height - bottomExtent - 4) };
}
