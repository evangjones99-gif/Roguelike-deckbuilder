from pathlib import Path
import subprocess,json
root=Path('/workspace/Roguelike-deckbuilder')
def run(args): return subprocess.run(args,cwd=root,check=True,text=True,capture_output=True)
head=run(['git','rev-parse','HEAD']).stdout.strip()
assert head.startswith('6950149') and run(['git','status','--short']).stdout==''
before=run(['git','ls-remote','origin','refs/heads/codex/lanternbound-production']).stdout.split()[0]
if before!=head: print(run(['git','-c','gc.auto=0','push','origin','HEAD:codex/lanternbound-production']).stderr)
after=run(['git','ls-remote','origin','refs/heads/codex/lanternbound-production']).stdout.split()[0]
assert after==head
result={'head':head,'remoteBefore':before,'remoteAfter':after,'pushConfirmed':True,'status':run(['git','status','--short']).stdout,'priorGuard':'48MiB total delta stop retained; commit succeeded, upload was interrupted. New128MiB+unchanged512 reserve for push/readback only; no repeat commit or source changes.'}
Path('/workspace/scratch/cairn-rejection-push-confirmation-root-r3.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
