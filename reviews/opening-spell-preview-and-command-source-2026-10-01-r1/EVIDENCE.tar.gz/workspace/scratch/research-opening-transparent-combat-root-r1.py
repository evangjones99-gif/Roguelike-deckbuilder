from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from html.parser import HTMLParser
import hashlib, json, time

out=Path('/workspace/scratch/opening-transparent-combat-primary-root-r1')
out.mkdir(exist_ok=False)
class Text(HTMLParser):
    def __init__(self): super().__init__(); self.parts=[]; self.hidden=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style'): self.hidden+=1
    def handle_endtag(self,tag):
        if tag in ('script','style'): self.hidden=max(0,self.hidden-1)
        if tag in ('p','div','h1','h2','li','br'): self.parts.append('\n')
    def handle_data(self,data):
        if not self.hidden: self.parts.append(data)
rows=[]
for label,url in [('into-the-breach-official','https://subsetgames.com/itb.html'),('celeste-official','https://www.celestegame.com/')]:
    row={'label':label,'url':url,'requestedAtUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'byteCap':262144}
    try:
        with urlopen(Request(url,headers={'User-Agent':'Hollowpact-design-research/1.0'}),timeout=10) as response:
            body=response.read(262145); row.update(status=response.status,finalURL=response.url)
        if len(body)>262144: raise ValueError('source exceeds declared cap; not inspected')
        (out/(label+'.html')).write_bytes(body)
        parser=Text(); parser.feed(body.decode('utf-8',errors='replace'))
        lines=[' '.join(line.split()) for line in ''.join(parser.parts).splitlines()]
        text='\n'.join(line for line in lines if line)+'\n'
        (out/(label+'.txt')).write_text(text)
        row.update(bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),textBytes=len(text.encode()),retrieved=True)
    except (HTTPError,URLError,TimeoutError,ValueError) as error:
        row.update(retrieved=False,error=str(error))
    rows.append(row)
(out/'FETCH.json').write_text(json.dumps({'scope':'Bounded primary official product text only; no video/playtest/developer interview or causal first-five-minute formula claim','sources':rows},indent=2)+'\n')
print(json.dumps(rows))
