"""Original direct-pixel Cairn Hound anatomy; stdlib only. No external image input.
Every pose supplies its own anatomical polygons. Indexed native64x64, no affine
cutout transform, smoothing, antialias, generated-image sampling or UI text.
"""
import os,json,struct,zlib,hashlib,time,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
ROOT='/workspace/scratch/standard-sol-cairn-pixel-assets-author-r5'
PAL=[(0,0,0),(14,20,23),(27,37,42),(43,58,62),(65,81,82),(77,91,88),(108,122,111),(149,158,137),(190,196,164),(57,91,91),(88,125,117),(135,173,145),(194,217,170),(85,75,59),(125,107,75),(213,176,98)]
# New original anatomy, not prior raster transforms. Each cell has authored contours.
POSES=[
 dict(name='arrival0',role='low rear coalescence with planted shoulder support',feet=[[22,58],[44,56]],
 tail=[(21,45),(16,47),(12,52),(13,55),(17,52),(24,49)],rearFar=[(29,44),(33,48),(31,52),(35,53),(35,55),(30,55),(27,51)],frontFar=[(41,36),(45,38),(46,43),(49,46),(48,49),(44,47)],
 rearNear=[(20,43),(28,45),(28,49),(24,52),(20,55),(22,56),(25,56),(25,58),(20,58),(17,55),(18,50)],frontNear=[(36,39),(42,40),(43,46),(41,51),(46,53),(47,56),(42,56),(38,52),(36,47)],
 body=[(19,39),(24,32),(32,29),(39,31),(45,37),(43,43),(37,48),(28,50),(21,47),(17,44)],rump=[(19,41),(23,36),(28,36),(31,40),(30,46),(26,49),(21,47),(18,44)],
 neck=[(34,34),(39,29),(44,29),(48,33),(46,39),(41,43),(37,42)],earFar=[(47,30),(50,24),(52,31)],earNear=[(41,32),(39,24),(44,27),(46,34)],head=[(40,33),(43,28),(48,27),(52,30),(53,34),(49,38),(44,39),(40,37)],muzzle=[(50,33),(54,30),(57,31),(57,34),(54,37),(50,37)],eye=[53,34],nose=[56,32],
 back=[(23,37),(29,32),(35,31),(39,33),(34,35),(28,39)],rumpLight=[(20,41),(23,38),(26,39),(24,42)],stones=[[(28,33),(30,31),(32,32),(30,34)]],glow=[[(12,56),(14,54),(13,57)]]),
 dict(name='arrival1',role='chest broadens above flexed forelegs while the far shoulder recedes',feet=[[22,58],[44,55]],
 tail=[(21,43),(15,46),(11,51),(12,54),(16,50),(24,47)],rearFar=[(29,42),(33,46),(31,51),(34,52),(35,54),(30,54),(27,49)],frontFar=[(42,31),(46,33),(47,40),(50,43),(49,46),(45,44)],
 rearNear=[(20,41),(28,42),(29,46),(25,50),(21,54),(22,56),(25,56),(25,58),(20,58),(17,54),(19,49)],frontNear=[(35,34),(42,35),(44,41),(42,48),(46,52),(47,55),(42,55),(38,51),(36,43)],
 body=[(19,35),(25,29),(33,25),(40,27),(45,32),(44,39),(38,44),(29,47),(21,45),(17,41)],rump=[(18,37),(23,31),(28,32),(31,37),(30,44),(26,47),(21,45),(17,41)],
 neck=[(33,29),(38,23),(44,23),(49,27),(48,33),(43,38),(38,38),(34,34)],earFar=[(48,23),(50,17),(53,24)],earNear=[(41,25),(39,17),(44,20),(46,27)],head=[(40,26),(43,21),(48,20),(53,23),(54,27),(50,31),(44,33),(40,30)],muzzle=[(51,26),(55,23),(58,24),(58,27),(55,30),(51,31)],eye=[54,27],nose=[57,25],
 back=[(22,33),(29,28),(35,27),(40,29),(34,31),(28,35)],rumpLight=[(19,37),(23,34),(26,35),(24,38)],stones=[[(29,28),(31,26),(33,27),(31,29)]],glow=[[(11,55),(13,53),(12,56)]]),
 dict(name='idle0',role='ready crouched rear-three-quarter canine with thick connected shoulder and skull',feet=[[22,58],[44,55]],
 tail=[(21,42),(16,45),(11,50),(12,54),(16,50),(24,46)],rearFar=[(29,41),(33,46),(31,50),(34,52),(35,54),(30,54),(27,49)],frontFar=[(43,29),(47,32),(48,38),(51,41),(50,45),(46,43)],
 rearNear=[(20,40),(28,42),(29,46),(25,50),(21,54),(22,56),(25,56),(25,58),(20,58),(17,54),(19,49),(22,45)],frontNear=[(35,32),(42,33),(45,40),(43,47),(46,51),(47,55),(42,55),(38,51),(36,43),(33,38)],
 body=[(19,34),(25,28),(33,24),(40,26),(46,31),(45,38),(39,43),(30,46),(22,45),(17,40)],rump=[(18,36),(23,30),(28,31),(31,36),(30,43),(26,46),(21,44),(17,40)],
 neck=[(33,28),(38,22),(45,22),(50,26),(49,32),(44,37),(38,37),(34,33)],earFar=[(49,22),(51,16),(54,23)],earNear=[(41,24),(39,16),(44,19),(47,26)],head=[(40,25),(43,20),(49,19),(54,22),(55,26),(51,31),(45,33),(40,29)],muzzle=[(52,25),(56,22),(59,23),(59,26),(56,30),(52,31)],eye=[55,26],nose=[58,24],
 back=[(22,32),(29,27),(35,26),(41,28),(35,30),(29,34)],rumpLight=[(19,36),(23,33),(26,34),(24,37)],stones=[[(29,27),(31,25),(33,26),(31,28)]],glow=[[(11,55),(13,53),(12,56)]]),
 dict(name='idle1',role='weight remains on near chest while far paw and near ear adjust',feet=[[22,58],[45,54]],
 tail=[(21,43),(16,47),(12,52),(14,54),(17,50),(24,47)],rearFar=[(29,42),(33,46),(31,51),(34,52),(35,54),(30,54),(27,49)],frontFar=[(43,30),(47,32),(48,37),(51,39),(51,42),(47,42)],
 rearNear=[(20,41),(28,43),(29,47),(25,51),(21,54),(22,56),(25,56),(25,58),(20,58),(17,54),(19,50)],frontNear=[(35,33),(42,34),(45,41),(43,47),(48,51),(48,54),(43,54),(39,50),(36,44),(33,39)],
 body=[(19,35),(25,29),(33,25),(40,27),(46,32),(45,39),(39,44),(30,47),(22,46),(17,41)],rump=[(18,37),(23,31),(28,32),(31,37),(30,44),(26,47),(21,45),(17,41)],
 neck=[(33,29),(38,23),(45,23),(50,27),(49,33),(44,38),(38,38),(34,34)],earFar=[(49,23),(52,18),(55,24)],earNear=[(41,25),(38,18),(44,21),(47,27)],head=[(40,26),(43,21),(49,20),(54,23),(55,27),(51,32),(45,34),(40,30)],muzzle=[(52,26),(56,23),(59,24),(59,27),(56,31),(52,32)],eye=[55,27],nose=[58,25],
 back=[(22,33),(29,28),(35,27),(41,29),(35,31),(29,35)],rumpLight=[(19,37),(23,34),(26,35),(24,38)],stones=[[(29,28),(31,26),(33,27),(31,29)]],glow=[[(12,55),(14,53),(13,56)]]),
 dict(name='anticipation',role='loaded haunch and flexed elbows; jaws prepare from a low supported neck',feet=[[19,58],[46,56]],
 tail=[(20,44),(14,46),(9,49),(10,52),(15,50),(24,48)],rearFar=[(29,44),(33,48),(30,51),(33,53),(35,55),(29,55),(26,50)],frontFar=[(44,33),(48,35),(48,41),(52,44),(51,48),(46,45)],
 rearNear=[(19,42),(28,43),(29,48),(24,51),(18,54),(19,56),(23,56),(23,58),(17,58),(15,54),(18,49)],frontNear=[(35,35),(43,36),(46,42),(44,49),(49,53),(49,56),(44,56),(39,52),(36,45),(33,40)],
 body=[(18,37),(24,31),(32,28),(40,29),(47,34),(45,41),(39,46),(29,49),(21,47),(16,42)],rump=[(17,39),(22,33),(28,34),(31,39),(30,46),(25,49),(20,47),(16,43)],
 neck=[(33,32),(39,26),(46,26),(52,29),(51,35),(46,40),(39,40),(34,37)],earFar=[(51,27),(54,22),(56,29)],earNear=[(43,28),(40,21),(46,24),(49,31)],head=[(42,29),(45,24),(51,23),(56,26),(57,30),(53,35),(47,37),(42,33)],muzzle=[(54,29),(58,26),(61,27),(61,30),(58,34),(54,35)],eye=[57,30],nose=[60,28],jaw=[(53,35),(58,34),(60,32),(60,35),(56,38),(52,37)],teeth=[[57,34]],
 back=[(21,35),(28,31),(35,30),(42,32),(35,34),(28,38)],rumpLight=[(18,39),(22,36),(25,37),(23,40)],stones=[[(28,31),(30,29),(32,30),(30,32)]],glow=[[(9,54),(11,52),(10,55)]]),
 dict(name='contact0',role='open threatening bite with clear dark mouth gap; stretched hock drives the chest',feet=[[17,58],[46,51]],
 tail=[(20,41),(13,42),(8,46),(9,49),(15,47),(24,45)],rearFar=[(29,41),(31,45),(28,49),(30,52),(33,53),(28,54),(25,49)],frontFar=[(43,27),(48,29),(49,34),(53,37),(53,41),(48,39)],
 rearNear=[(20,39),(28,42),(27,47),(22,51),(16,54),(17,56),(20,56),(20,58),(14,58),(12,54),(18,48),(21,44)],frontNear=[(35,30),(43,31),(47,37),(45,44),(50,48),(50,51),(45,51),(40,46),(37,39),(33,35)],
 body=[(20,32),(26,26),(34,22),(41,24),(48,28),(46,35),(40,40),(30,45),(22,44),(17,39)],rump=[(19,34),(24,28),(29,30),(32,35),(30,42),(26,45),(21,43),(17,39)],
 neck=[(34,26),(39,20),(46,19),(52,23),(51,29),(46,35),(39,35),(35,31)],earFar=[(51,19),(53,13),(56,21)],earNear=[(43,22),(40,14),(47,18),(49,25)],head=[(42,23),(45,18),(51,17),(56,20),(57,24),(53,29),(47,32),(42,27)],muzzle=[(54,23),(58,20),(62,21),(62,24),(58,28),(54,28)],eye=[57,24],nose=[61,22],jaw=[(52,33),(57,32),(61,28),(61,33),(57,37),(51,37)],mouth=[(53,28),(58,27),(61,25),(61,30),(56,34),(52,33)],teeth=[[57,28],[56,29],[57,34]],
 back=[(23,30),(29,25),(36,24),(43,26),(36,28),(29,32)],rumpLight=[(20,34),(24,31),(27,32),(25,35)],stones=[[(29,25),(31,23),(33,24),(31,26)]],glow=[[(8,51),(10,49),(9,53)]]),
 dict(name='contact1',role='bite clamps shut; forequarters recoil over bent load-bearing elbow',feet=[[19,58],[48,53]],
 tail=[(21,43),(15,45),(10,49),(11,52),(16,49),(25,47)],rearFar=[(30,43),(33,47),(30,51),(33,53),(35,55),(29,55),(27,50)],frontFar=[(45,30),(49,32),(50,38),(54,41),(53,45),(48,42)],
 rearNear=[(20,41),(28,44),(28,48),(23,51),(18,54),(19,56),(23,56),(23,58),(17,58),(15,54),(19,49)],frontNear=[(36,33),(44,34),(48,41),(46,47),(51,50),(51,53),(46,53),(41,49),(38,42),(34,38)],
 body=[(20,34),(26,28),(34,25),(42,27),(49,32),(47,39),(41,44),(31,47),(22,46),(17,41)],rump=[(19,36),(24,30),(29,32),(32,37),(30,44),(26,47),(21,45),(17,41)],
 neck=[(35,29),(40,23),(47,22),(53,26),(52,32),(47,38),(40,38),(36,34)],earFar=[(52,22),(55,17),(57,24)],earNear=[(44,25),(41,18),(48,21),(50,28)],head=[(43,26),(46,21),(52,20),(57,23),(58,27),(54,32),(48,35),(43,30)],muzzle=[(55,26),(59,23),(62,24),(62,27),(59,31),(55,32)],eye=[58,27],nose=[61,25],jaw=[(53,32),(58,31),(61,29),(61,31),(57,34),(53,34)],teeth=[[58,31]],
 back=[(23,32),(30,27),(36,27),(44,29),(37,31),(30,35)],rumpLight=[(20,36),(24,33),(27,34),(25,37)],stones=[[(30,27),(32,25),(34,26),(32,28)]],glow=[[(10,54),(12,52),(11,55)]]),
 dict(name='recovery',role='reweight onto chest and draw head into thick neck after bite',feet=[[24,58],[43,55]],
 tail=[(23,43),(17,47),(13,52),(15,55),(19,50),(26,47)],rearFar=[(31,42),(34,47),(32,51),(35,53),(36,55),(31,55),(28,50)],frontFar=[(42,32),(46,35),(47,41),(50,44),(49,47),(45,45)],
 rearNear=[(22,41),(30,43),(30,47),(26,51),(23,54),(24,56),(28,56),(28,58),(22,58),(20,54),(22,49)],frontNear=[(35,35),(42,36),(44,42),(41,48),(46,52),(46,55),(41,55),(37,51),(35,44),(33,39)],
 body=[(21,35),(27,29),(34,27),(40,29),(46,34),(44,40),(38,45),(30,48),(23,46),(19,42)],rump=[(20,37),(25,31),(30,33),(33,38),(31,45),(27,48),(22,46),(18,42)],
 neck=[(33,31),(37,25),(44,25),(49,29),(47,35),(42,40),(37,40),(33,36)],earFar=[(46,25),(48,19),(51,27)],earNear=[(39,28),(36,21),(42,24),(44,31)],head=[(38,29),(41,24),(47,23),(52,27),(52,31),(48,35),(42,37),(38,33)],muzzle=[(49,30),(53,27),(57,28),(56,31),(53,35),(49,35)],eye=[52,31],nose=[56,29],
 back=[(24,33),(30,29),(35,29),(40,31),(34,33),(29,36)],rumpLight=[(21,37),(25,34),(28,35),(26,38)],stones=[[(30,29),(32,27),(34,28),(32,30)]],glow=[[(13,56),(15,54),(14,57)]]),
 dict(name='hit',role='supported chest twists inward; skull recoils into the mane without losing footing',feet=[[24,58],[45,56]],
 tail=[(24,40),(18,41),(13,45),(14,48),(19,45),(27,45)],rearFar=[(32,41),(35,46),(32,51),(35,53),(36,55),(31,55),(29,50)],frontFar=[(43,33),(47,36),(48,41),(51,44),(50,48),(46,46)],
 rearNear=[(23,41),(31,43),(31,47),(27,51),(23,54),(24,56),(28,56),(28,58),(22,58),(20,54),(22,49)],frontNear=[(36,35),(43,37),(45,43),(43,49),(48,53),(48,56),(43,56),(39,52),(36,45),(34,40)],
 body=[(22,34),(28,28),(35,27),(42,30),(47,35),(45,41),(39,46),(31,48),(24,46),(20,41)],rump=[(21,36),(26,30),(31,33),(34,39),(32,45),(28,48),(23,46),(19,41)],
 neck=[(33,31),(35,25),(42,25),(47,29),(46,36),(41,41),(36,40),(32,35)],earFar=[(44,27),(46,22),(49,30)],earNear=[(35,30),(31,24),(38,27),(40,33)],head=[(34,31),(38,26),(44,25),(49,29),(49,33),(45,37),(39,39),(34,35)],muzzle=[(46,32),(50,29),(54,30),(53,34),(50,37),(46,37)],eye=[49,33],nose=[53,31],
 back=[(25,32),(31,28),(36,29),(42,32),(35,34),(30,37)],rumpLight=[(22,36),(26,33),(29,35),(27,38)],stones=[[(31,28),(33,27),(35,29),(33,30)]],glow=[[(25,29),(27,28),(26,31)],[(47,47),(49,46),(48,49)]]),
 dict(name='death',role='collapsed rear flank and grounded chest; skull rests with folded ears and shut eye',feet=[[24,58],[45,56]],
 tail=[(23,50),(16,52),(10,56),(11,58),(17,56),(27,54)],rearFar=[(32,48),(36,51),(34,54),(39,55),(38,57),(31,56)],frontFar=[(43,43),(47,45),(48,49),(53,51),(52,53),(46,51)],
 rearNear=[(21,49),(30,50),(30,53),(26,55),(22,56),(28,56),(28,58),(21,58),(18,55)],frontNear=[(35,47),(42,48),(44,52),(49,54),(49,56),(43,56),(37,53),(33,50)],
 body=[(22,45),(29,40),(36,40),(43,43),(47,48),(43,53),(36,56),(28,59),(22,56),(18,51)],rump=[(20,47),(25,42),(31,44),(34,49),(31,55),(27,58),(21,55),(17,51)],
 neck=[(34,43),(39,40),(45,42),(49,46),(47,51),(42,54),(36,51)],earFar=[(47,45),(50,44),(52,47)],earNear=[(40,47),(36,44),(43,45),(46,49)],head=[(39,48),(43,44),(48,44),(53,48),(54,51),(50,54),(44,55),(40,52)],muzzle=[(51,50),(55,48),(58,49),(57,52),(54,55),(50,54)],eye=[54,51],nose=[57,50],
 back=[(25,45),(31,41),(37,42),(43,45),(36,47),(30,51)],rumpLight=[(21,48),(25,45),(28,47),(26,50)],stones=[[(31,41),(33,40),(35,42),(33,43)]],glow=[[(11,59),(13,57),(12,59)]])
]

def guard():
 c=int(Path('/sys/fs/cgroup/memory.current').read_text());m=int(Path('/sys/fs/cgroup/memory.max').read_text());v=os.statvfs(ROOT)
 assert m-c>=512*1048576
 assert c-BASELINE['current']<=24*1048576
 assert v.f_bavail*v.f_frsize>=1048576
 return {'current':c,'maximum':m,'headroom':m-c,'free':v.f_bavail*v.f_frsize}
def line(a,b,col):
 x0,y0=a;x1,y1=b;dx=abs(x1-x0);sx=1 if x0<x1 else -1;dy=-abs(y1-y0);sy=1 if y0<y1 else -1;err=dx+dy
 while True:
  assert 0<=x0<64 and 0<=y0<64;PIX[y0*64+x0]=col
  if x0==x1 and y0==y1:break
  e=2*err
  if e>=dy:err+=dy;x0+=sx
  if e<=dx:err+=dx;y0+=sy
def poly(points,col,outline=None):
 # Integer point-in-polygon sampled at pixel centers, then authored crisp boundary.
 for y in range(min(p[1]for p in points),max(p[1]for p in points)+1):
  for x in range(min(p[0]for p in points),max(p[0]for p in points)+1):
   inside=False;j=len(points)-1
   for i,(xi,yi)in enumerate(points):
    xj,yj=points[j]
    if (yi>y+.5)!=(yj>y+.5)and x+.5<(xj-xi)*(y+.5-yi)/(yj-yi)+xi:inside=not inside
    j=i
   if inside:PIX[y*64+x]=col
 if outline is not None:
  for a,b in zip(points,points[1:]+points[:1]):line(a,b,outline)
def paint(spec):
 global PIX;PIX=bytearray(4096)
 for part,col in [('rearFar',2),('frontFar',2),('tail',3),('rearNear',4),('frontNear',4),('body',4),('rump',3),('neck',4),('earFar',2),('head',4),('earNear',4),('muzzle',5)]:
  poly(spec[part],col,1)
 poly(spec['back'],5);poly(spec['rumpLight'],4)
 # Small discontinuous fur clusters follow the diagonal back, not a pale oval.
 a=spec['back'];line(a[0],a[1],6);line(a[2],a[3],4)
 # Near chest retains a dark connected weight plane and split bent foreleg.
 n=spec['frontNear'];line(n[1],n[2],3);line(n[-2],n[-1],2)
 h=spec['head'];line(h[0],h[1],5);line(h[1],h[2],6)
 for stone in spec['stones']:
  poly(stone,6,3);x,y=stone[0];PIX[y*64+x]=7
 for ear in ['earNear','earFar']:
  a,b,d=spec[ear][:3];x=(a[0]+b[0]+d[0])//3;y=(a[1]+b[1]+d[1])//3;PIX[y*64+x]=2
 if 'mouth' in spec:poly(spec['mouth'],1)
 if 'jaw' in spec:poly(spec['jaw'],4,1)
 for x,y in spec.get('teeth',[]):PIX[y*64+x]=8
 ex,ey=spec['eye'];PIX[ey*64+ex]=15 if spec['name']!='death' else 2
 nx,ny=spec['nose'];PIX[ny*64+nx]=1;PIX[(ny+1)*64+nx]=1
 for glow in spec['glow']:
  poly(glow,10);x,y=glow[0];PIX[y*64+x]=12
 for x,y in spec['feet']:assert PIX[y*64+x]!=0,(spec['name'],'foot contact not painted',x,y)
 return bytes(PIX)
def chunk(k,b):return struct.pack('>I',len(b))+k+b+struct.pack('>I',zlib.crc32(k+b)&0xffffffff)
def png(w,h,pixels):
 rows=b''.join(b'\0'+pixels[y*w:(y+1)*w]for y in range(h))
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,3,0,0,0))+chunk(b'PLTE',bytes(c for rgb in PAL for c in rgb))+chunk(b'tRNS',bytes([0]+[255]*15))+chunk(b'IDAT',zlib.compress(rows,9))+chunk(b'IEND',b'')
def put(name,b):
 fd=os.open(ROOT+'/'+name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  v=memoryview(b)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
 return {'path':ROOT+'/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def bounds(p):
 coords=[(i%64,i//64)for i,v in enumerate(p)if v]
 return [min(x for x,y in coords),min(y for x,y in coords),max(x for x,y in coords)+1,max(y for x,y in coords)+1]
BASELINE={'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text())}
assert BASELINE['maximum']-BASELINE['current']>=24*1048576+512*1048576
assert os.path.isdir(ROOT)
frames=[];files=[];records=[]
for i,spec in enumerate(POSES):
 guard();p=paint(spec);frames.append(p)
 files.append(put('cairn-hound-'+spec['name']+'.png',png(64,64,p)))
 records.append({'index':i,'name':spec['name'],'role':spec['role'],'cell':[i*64,0,64,64],'opaqueBounds':bounds(p),'opaquePixels':sum(bool(v)for v in p),'nativeIndicesUsed':sorted(set(p)),'footContactPoints':spec['feet'],'placementAnchor':[28,58],'pixelSHA256':hashlib.sha256(p).hexdigest()})
sheet=b''.join(b''.join(p[y*64:(y+1)*64]for p in frames)for y in range(64))
files.append(put('cairn-hound-sheet.png',png(640,64,sheet)))
# Diagnostic contact sheet is derived from these NEW pixels at exact nearest3x.
preview=bytearray(960*384)
for i,p in enumerate(frames):
 ox=(i%5)*192;oy=(i//5)*192
 for y in range(64):
  for x in range(64):
   for dy in range(3):
    start=(oy+y*3+dy)*960+ox+x*3;preview[start:start+3]=bytes([p[y*64+x]])*3
files.append(put('cairn-hound-preview-3x.png',png(960,384,preview)))
union=[min(r['opaqueBounds'][0]for r in records),min(r['opaqueBounds'][1]for r in records),max(r['opaqueBounds'][2]for r in records),max(r['opaqueBounds'][3]for r in records)]
meta={'species':'Cairn Hound','cardId':'cairnhound','engineSpecies':'hound','side':'ally','orientation':'intended rear three-quarter canine facing northeast; independent visual acceptance pending','nativeCell':[64,64],'sheet':[640,64],'palette':[{'index':i,'rgb':list(c),'alpha':0 if i==0 else 255}for i,c in enumerate(PAL)],'paletteEntryCount':16,'transparentIndex':0,'sampling':'indexed8bit; integer pixels; no antialias','placementAnchor':[28,58],'anchorQualification':'Common floor-plane placement reference; actual painted support contacts are recorded separately per pose. No physics/game fit claim.','fullPoseOpaqueUnion':union,'frames':records,'files':files,'drawnPoseCount':10,'distinctNativePixelHashes':len({r['pixelSHA256']for r in records}),'sequenceCandidates':{'arrival':['arrival0','arrival1','idle0'],'idleReady':['idle0','idle1'],'loadedCommand':['anticipation','contact0','contact1','recovery'],'reaction':['hit','recovery'],'death':['death']},'timingsImplemented':False,'engineIntegration':False,'readyRuleChanged':False,'gameStatsOrRulesDrawn':False,'provenance':'R5 new original explicit per-pose contours. Only integer raster/PNG/writer/bounds/metadata helpers reused from own immutable R4 source SHA03f2bf70e0dba53dbc8db588f67942a7f35e7d49c100cc9fde50fe235d784c1a. No old image pixels read/copied/transformed, external image or generated-image sample. Palette unchanged byte-for-byte. Actual B rejection Root-transmitted; independent visual acceptance pending.','limitations':['Ten hand-authored pose cells are not a demonstrated complete animation or playable payoff.','Rear perspective/canine identity and pixel craft require independent visual rejection-capable review.','R5 not integrated or runtime-tested; its changed full-pose union and head/contact landmarks require fresh adapter geometry, not reuse of R4 bounds/nose.','No Grave Hound/fenstalker/ashwidow/colossus/enemy coverage.'],'sourceGuardFinal':guard()}
assert meta['distinctNativePixelHashes']==10
files.append(put('ASSET-METADATA.json',(json.dumps(meta,sort_keys=True,indent=2)+'\n').encode()))
print(json.dumps({'files':files,'fullPoseUnion':union,'paletteEntries':16,'nativeCell':[64,64],'uniquePoseHashes':10,'sourceGuardFinal':guard()}))
