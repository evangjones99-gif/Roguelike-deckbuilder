import fs from 'node:fs';import assert from 'node:assert/strict';
import { applyActionWithEvents, validateState } from '/workspace/scratch/audio-shipping-v08-r1/candidate/src/engine.ts';
import { contactCues } from '/workspace/scratch/audio-shipping-v08-r1/candidate/src/audio-host.ts';
const fixtures=JSON.parse(fs.readFileSync('/workspace/scratch/audio-native-lifecycle-independent-v08-r2/independent/legacy-fixtures.json','utf8'));
const results=[];
for(const f of fixtures){
 if(!f.transitions){
  assert.ok(validateState(f.before),f.name);const beforeText=JSON.stringify(f.before),r=applyActionWithEvents(f.before,f.action);assert.deepEqual(r.state,f.state);assert.deepEqual(r.events,f.events);assert.equal(JSON.stringify(f.before),beforeText);assert.ok(validateState(r.state));
  const frozen=JSON.stringify({before:f.before,after:r.state,events:r.events,action:f.action});const cues=contactCues(f.before,r.state,r.events,f.action,true);assert.equal(JSON.stringify({before:f.before,after:r.state,events:r.events,action:f.action}),frozen);assert.ok(cues.length<=8);assert.ok(cues.every(c=>Number.isFinite(c.offset)&&c.offset>=0));
  results.push({name:f.name,stateExact:true,eventsExact:true,observerImmutable:true,cues});
 }else{let state=f.before;for(const t of f.transitions){const r=applyActionWithEvents(state,t.action);assert.deepEqual(r.state,t.state);assert.deepEqual(r.events,t.events);state=r.state;}assert.deepEqual(state,f.state);results.push({name:f.name,transitions:f.transitions.length,stateExact:true});}
}
fs.writeFileSync('/workspace/scratch/audio-shipping-independent-v08-r1/fixture-oracles-r2.json',JSON.stringify(results,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({verified:results.length}));
