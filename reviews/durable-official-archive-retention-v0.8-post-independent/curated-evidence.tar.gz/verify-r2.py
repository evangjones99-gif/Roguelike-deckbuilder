from pathlib import Path
import hashlib,json,os,stat,datetime
O=Path('/workspace/scratch/durable-official-archive-retention-post-independent-v08-r1')
A=Path('/workspace/scratch/durable-official-archive-duplicate-independent-v08-r1')
ROOT=Path('/workspace/Roguelike-deckbuilder/reviews/root-v0.8-durable-original-retention')
H=lambda b:hashlib.sha256(b).hexdigest()
assert H((A/'MANIFEST.json').read_bytes())=='116a301e1c354d8080a64493ccc980d8f0f1207c3fe2ecc273ecb83387e0f649'
for row in json.loads((A/'MANIFEST.json').read_text())['files']:
 b=(A/row['path']).read_bytes();assert len(b)==row['bytes'] and H(b)==row['sha256'],row['path']
audit=json.loads((A/'ELIGIBILITY.json').read_text())
before=json.loads((ROOT/'BEFORE.json').read_text());after=json.loads((ROOT/'AFTER.json').read_text())
assert before['eligibilitySHA256']==H((A/'ELIGIBILITY.json').read_bytes())
def meta(p,follow=False):
 s=p.stat() if follow else p.lstat()
 return {'type':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'link','bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'blocks':s.st_blocks,'xattrs':{k:os.getxattr(p,k,follow_symlinks=follow).hex() for k in os.listxattr(p,follow_symlinks=follow)}}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def compare(actual,expected,except_fields=('atime_ns',)):
 for k,v in expected.items():
  if k not in except_fields:assert actual[k]==v,(k,actual[k],v)
def stable(row,fullhash=False):
 p=Path(row['path']);compare(meta(p),row['metadata'])
 result={'path':str(p),'metadata':meta(p)}
 if fullhash:result['sha256']=sha(p);assert result['sha256']==row['sha256'],str(p)
 return result
for key,row in audit['before'].items():
 assert before['before'][key]['path']==row['path'];compare(before['before'][key]['metadata'],row['metadata'])
 assert before['before'][key]['members']==row.get('members') and before['before'][key]['sha256']==row.get('sha256')
src=Path(audit['before']['duplicateOriginal']['path']);target=Path(audit['before']['officialRetained']['path']);expected=audit['expectedSHA256']
assert src.is_symlink() and os.path.isabs(os.readlink(src)) and os.readlink(src)==str(target) and src.resolve(strict=True)==target
assert not target.is_symlink();assert sha(src)==sha(target)==expected
followed=meta(src,True);compare(meta(target),audit['before']['officialRetained']['metadata'])
for field in ['bytes','mode','uid','gid','xattrs']:assert followed[field]==audit['before']['duplicateOriginal']['metadata'][field],field
parent=meta(src.parent);compare(parent,audit['before']['duplicateParent']['metadata'],('atime_ns','ctime_ns'))
assert parent['ctime_ns']>audit['before']['duplicateParent']['metadata']['ctime_ns']
assert sorted(str(p) for p in src.parent.iterdir())==audit['before']['duplicateParent']['members']
compare(meta(target.parent),audit['before']['officialParent']['metadata'])
assert sorted(str(p) for p in target.parent.iterdir())==audit['before']['officialParent']['members']
sidecars=[stable(r,True) for r in audit['sidecars']]
wrappers=[stable(r,True) for r in audit['wrappers']]
excluded=[stable(r) for r in audit['excludedInputs']]
tmpaudit=json.loads((A/'EXCLUDED-TMP-INPUTS.json').read_text());tmp=[stable(r) for r in tmpaudit['files']]
journal=[json.loads(l) for l in (ROOT/'JOURNAL.jsonl').read_text().splitlines()]
assert len(journal)==2 and [j['phase'] for j in journal]==['ready','replaced']
assert journal[0]['original']==str(src) and journal[0]['target']==str(target)
temporary=Path(journal[0]['temporaryAlias']);assert temporary.parent==src.parent and temporary.name=='.hollowpact-retained-0.8.0-original-alias'
assert not temporary.exists() and not temporary.is_symlink() and journal[1]['linkTarget']==str(target)
assert after['status']=='PASS-root-retention' and after['originalPath']==str(src) and after['target']==str(target) and after['sourceSHA256']==expected
compare(after['officialRetained'],meta(target));compare(after['originalParent'],parent)
assert after['observedFreeDelta']==after['freeAfterBytes']-before['freeBeforeBytes']==191729664
assert audit['allocatedDuplicateBytes']==audit['before']['duplicateOriginal']['metadata']['blocks']*512==191819776
owned=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_dir():continue
 assert p.is_file() and not p.is_symlink()
 b=p.read_bytes();owned.append({'path':str(p),'bytes':len(b),'sha256':H(b)})
assert {Path(r['path']).relative_to(ROOT).as_posix() for r in owned}=={'retain.py','BEFORE.json','JOURNAL.jsonl','AFTER.json','COORDINATION.json','actual-retention.txt','__pycache__/retain.cpython-312.pyc'}
# Original root receipts are small: retain exact copies without changing their source.
receiptDir=O/'root-receipt-copies';receiptDir.mkdir(exist_ok=False)
for row in owned:
 p=Path(row['path']);destination=receiptDir/p.relative_to(ROOT);destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(p.read_bytes())
compare(meta(target),audit['before']['officialRetained']['metadata'])
for row in sidecars+wrappers:compare(meta(Path(row['path'])),row['metadata'])
for row in excluded+tmp:compare(meta(Path(row['path'])),row['metadata'])
free=os.statvfs('/workspace')
result={'status':'ACCEPTED-actual-scoped-retention','frozenUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planManifestSHA256':H((A/'MANIFEST.json').read_bytes()),'rootHelperSHA256':next(r['sha256'] for r in owned if r['path'].endswith('/retain.py')),'rootFiles':owned,'originalPath':str(src),'absoluteTarget':str(target),'fullSHA256':expected,'fullBytes':followed['bytes'],'originalAliasLstat':meta(src),'followedAccessMetadata':followed,'officialTargetCurrent':meta(target),'duplicateParentCurrent':meta(src.parent),'officialParentCurrent':meta(target.parent),'fullHashedSidecars':sidecars,'fullHashedWrappers':wrappers,'durableExcludedMetadata':excluded,'TMPExcludedMetadata':tmp,'perPathAllocatedBytesReduction':audit['allocatedDuplicateBytes']-meta(src)['blocks']*512,'rootObservedFreeDeltaBytes':after['observedFreeDelta'],'rootFreeAfterBytes':after['freeAfterBytes'],'currentObservedFreeBytes':free.f_bavail*free.f_frsize,'qualifications':['Reader atime is excluded from stable metadata, including post-utime directory rereads.','Original alias inode/type/link/timestamps changed and are preserved in the frozen plan and fsynced root BEFORE/journal. Parentctime changed; parentmtime restored.','All excluded checks are metadata, not full hash checks of every unique archive/art/dataset.','No global FD absence or OS lock is claimed. Gross per-path blocks and net observed free space have different scopes.','No source/build/native-install/Steam/AAA or future capacity claim. No mutation by reviewer.']}
(O/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'fullBytes':result['fullBytes'],'fullSHA256':expected,'rootHelperSHA256':result['rootHelperSHA256'],'wrappersFullHashed':len(wrappers),'sidecarsFullHashed':len(sidecars),'durableExcludedMetadata':len(excluded),'TMPExcludedMetadata':len(tmp),'perPathAllocatedBytesReduction':result['perPathAllocatedBytesReduction'],'rootObservedFreeDeltaBytes':result['rootObservedFreeDeltaBytes']}))
