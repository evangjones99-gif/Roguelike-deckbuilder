from pathlib import Path
exec(Path('/workspace/scratch/preserve-reviewed-retirements-r1.py').read_text().split('zip_roots = ')[0])
p=Path('/workspace/scratch/v060-source-coverage-actual-independent-r1/STATIC-AUDIT.json')
d=json.loads(read_exact(p)[0]); extra=[]
for path,row in d['inputReceipts'].items():
 body=read_exact(Path(path))[0]
 assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
 extra.append(Path(path))
for name in ('PRESERVED-PARTIAL-TRACE-REFERENCES.json','FROZEN-FILES.json'):
 extra.append(Path('/tmp/standard-sol-owner-ux-technical-independent-r1-handoff')/name)
extra += [Path('/workspace/scratch/preserve-reviewed-retirements-r1.py'), Path(__file__)]
seal('reviewed-retirement-preservation-supplement-2026-10-01-r1',[],extra,
 'Immutable supplement to the two reviewed-retirement packets. Independent preservation review identified omitted bounded historical inputs; this packet preserves every byte-pinned STATIC-AUDIT input receipt, original reachable-object ledger and restore script/result, and the partial-trace identity ledger/frozen handoff inventory. No restore, archive deletion, raw-trace rehash or game acceptance is newly claimed. Original packets remain unchanged. All input receipt bodies were checked against their accepted byte lengths and SHA256 values before archiving; every archived member round-tripped exactly. These review-authoring scripts are preserved too.')
