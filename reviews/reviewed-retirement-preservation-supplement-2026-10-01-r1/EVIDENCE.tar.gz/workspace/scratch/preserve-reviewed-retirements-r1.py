import os, io, json, hashlib, tarfile, pathlib, stat

repo = pathlib.Path('/workspace/Roguelike-deckbuilder')
scratch = pathlib.Path('/workspace/scratch')
headroom = int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text()) - int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
assert headroom >= (24 + 512) * 1024 * 1024

def read_exact(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_size <= 1024 * 1024
        data = b''
        while True:
            block = os.read(fd, 65536)
            if not block: break
            data += block
        after = os.fstat(fd)
        assert before == after and len(data) == before.st_size
        return data, before
    finally: os.close(fd)

def seal(name, roots, extra, outcome):
    destination = repo / 'reviews' / name
    destination.mkdir(exist_ok=False)
    files = set(extra)
    for root in roots:
        for path in root.rglob('*'):
            if path.is_file() and not path.is_symlink(): files.add(path)
    archive = destination / 'EVIDENCE.tar.gz'
    inventory = []
    with archive.open('xb') as raw:
        with tarfile.open(fileobj=raw, mode='w:gz') as tf:
            for path in sorted(files):
                data, metadata = read_exact(path)
                member = str(path).lstrip('/')
                info = tarfile.TarInfo(member)
                info.size, info.mode, info.mtime = len(data), stat.S_IMODE(metadata.st_mode), metadata.st_mtime
                tf.addfile(info, io.BytesIO(data))
                inventory.append({'path':str(path), 'member':member, 'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()})
        raw.flush(); os.fsync(raw.fileno())
    with tarfile.open(archive, 'r:gz') as tf:
        assert len(tf.getmembers()) == len(inventory)
        for row in inventory:
            data = tf.extractfile(row['member']).read()
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    digest = hashlib.sha256()
    with archive.open('rb') as stream:
        while block := stream.read(65536): digest.update(block)
    manifest = {'status':'all archived bodies round-trip verified', 'archive':archive.name, 'bytes':archive.stat().st_size,
        'sha256':digest.hexdigest(), 'files':inventory, 'originals_retained':True, 'scope':outcome}
    (destination/'PRESERVATION.json').write_text(json.dumps(manifest, indent=2)+'\n')
    (destination/'OUTCOME.md').write_text(outcome+'\n')
    print(json.dumps({'packet':str(destination),'members':len(inventory),'bytes':manifest['bytes'],'sha256':manifest['sha256']}))

zip_roots = [p for p in scratch.iterdir() if p.is_dir() and p.name.startswith(('v060-source-coverage-', 'v060-exact-container-retirement-', 'standard-sol-v060-'))]
zip_extra = [p for p in scratch.iterdir() if p.is_file() and p.name.startswith(('v060-source-coverage-ROOT-', 'v060-source-zip-ROOT-'))]
seal('reviewed-v060-source-zip-retirement-2026-10-01', zip_roots, zip_extra,
    'The independently preferred retained 0.8 Git bundle covers every one of the old 0.6 ZIP\'s 5,564 regular files and all historical Git content. Root selectively retired only the exact 2,863,760,699-byte old ZIP after complete coverage, distinct source review, producer judgment and anchored identity checks. The ZIP container encoding is intentionally retired; unique source content and historical manifests remain. Actual postreview accepted the absence, retained successor metadata, 13 unchanged refs and completion receipts. Utility available space rose by 2,863,767,552 bytes; exclusive causal attribution is not claimed. No fresh post-deletion restore or large-body rehash is claimed. Rejected source iterations and audit-method failures are preserved in this packet. This is storage recovery, not a new game milestone.')
trace_roots = [p for p in pathlib.Path('/tmp').iterdir() if p.is_dir() and (p.name.startswith('trace-media-duplicate-') or p.name=='hollowpact-trace-media-duplicate-recovery-r1')]
seal('reviewed-trace-media-alias-recovery-2026-10-01', trace_roots, [],
    'Eight byte-identical generated Playwright trace PNG copies were replaced by hardlinks to their retained canonical art inodes after distinct preference/source reviews and producer judgment. All eight trace paths and pixels remain; no unique evidence or art was removed. Qualified postreview accepted exact pixels, identities and intentional link/time metadata changes. Workspace utility available space rose from zero to 8,302,592 bytes; do not report the 18,493,440-byte released allocation as that usable-space gain. Twenty-seven trace file bodies were hash-checked; four ZIP bodies were checked for path/size only. These public/dist/trace art aliases are immutable: never truncate, chmod, change xattrs or write through them. Future art uses new filenames/inodes or atomic replacement preserving old trace bytes. Originals of all small proof records remain.')
