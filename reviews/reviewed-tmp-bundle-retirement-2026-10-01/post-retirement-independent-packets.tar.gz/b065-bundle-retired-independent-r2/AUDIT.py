"""Post-retirement receipts and preserved originals only; no archive body or unlink."""
import hashlib,json,os,stat
from pathlib import Path
OUT=Path('/workspace/scratch/b065-bundle-retired-independent-r2');rows={}
def need(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(s):return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}
def read(p,limit=65536):
    p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        s=os.fstat(fd);need(stat.S_ISREG(s.st_mode)and s.st_size<=limit,'bounded regular receipt');b=os.read(fd,limit+1);need(len(b)==s.st_size and os.read(fd,1)==b'','complete control read')
        need(meta(s)==meta(os.fstat(fd))==meta(os.stat(p,follow_symlinks=False)),'input metadata');rows[str(p)]={'bytes':len(b),'sha256':sha(b),'metadata':meta(s)};return b
    finally:os.close(fd)
def j(p):return json.loads(read(p))
def memory():
    b=Path('/proc/self/status').read_bytes();need(len(b)<=8192,'status bound');v={}
    for l in b.decode().splitlines():
        if l.startswith(('VmHWM:','VmRSS:')):k,n,u=l.split();need(u=='kB','unit');v[k[:-1]]=int(n)*1024
    head=int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text());need(max(v.values())<=24*1024**2 and head>=88*1024**2,'own24+64 small admission');return {**v,'headroomBytes':head}
try:
    initial=memory();run=Path('/workspace/scratch/b065-bundle-retirement-run-r2');wrap=Path('/workspace/scratch/b065-bundle-retirement-ROOT-wrapper-r2');prepdir=Path('/workspace/scratch/b065-bundle-prepared-independent-r2')
    need({p.name for p in run.iterdir()}=={'REVALIDATED.json','ARMED.json','RETIRED.json','FAILURE-SLOT.json'},'exact retirement files');need({p.name for p in wrap.iterdir()}=={'RESULT.json','stdout.txt','stderr.txt'},'exact wrapper files')
    reval=j(run/'REVALIDATED.json');armed=j(run/'ARMED.json');retired=j(run/'RETIRED.json');failure=j(run/'FAILURE-SLOT.json');wrapper=j(wrap/'RESULT.json');stdout=j(wrap/'stdout.txt');stderr=read(wrap/'stderr.txt');decl=j('/workspace/scratch/b065-bundle-retirement-ROOT-DECLARATION-r2.json');prior=j(prepdir/'RESULT.json');prepared=j('/workspace/scratch/b065-bundle-preparation-run-r2/PREPARED.json');pa=j(prepdir/'ACTUAL-PREPARED-ACCEPTANCE.json');phase=j(prepdir/'RETIRE-SOURCE-ACCEPTANCE.json')
    need(wrapper['exitCode']==0 and wrapper['originalOldExists'] is False and wrapper['retiredReceiptExists'] is True and stdout['retired'] is True and stdout['oneFile']==retired['oldPath'] and stdout['output']==str(run) and stdout['noGitRestoreOrHints'] is True and stderr==b'','actual rc0 one-file outcome')
    need(failure=={'status':'reserved; no failure'},'no recorded failure')
    for k in ['sourceSHA256','oldPath','freshOldSHA256','oldBytes','readCalls','oldMetadata','preferredSuccessorPath','successorSHA256','successorVerificationSHA256','actualSuccessorBodyReviewSHA256','coverage','oldAllocatedPotential']:
        need(reval[k]==prepared[k],'revalidated prepared factual identity: '+k)
    need(reval['kind']=='b065-bundle-revalidation' and reval['oldAllOwnContentFDsClosed'] is True and reval['freshOldSHA256']=='04c31e64dab1b8503746b452717f6cea7a806135ec07c0fa4bcd03d65ab7561c' and reval['oldBytes']==1526523777 and reval['readCalls']==1456,'fresh complete old rehash')
    accepted={'independentReviewSHA256':pa['reviewSHA256'],'path':pa['preparedPath'],'sha256':pa['preparedSHA256']};need(reval['independentlyAcceptedPreparation']==armed['acceptedPreparation']==accepted,'exact accepted preparation before arm')
    need(pa['preparedSHA256']==decl['preparedReceiptSHA256']=='f981c2e486c6ad43ff1ee8700877c788160ff848a097f0a19f430bb402d95331' and sha(read(pa['reviewPath']))==pa['reviewSHA256']=='bf501b35965b60460a20ce57fef64847f00217b93bb5985a53b4ae73ffa965f9','actual prepared review binding')
    need(sha(read(phase['reviewPath']))==phase['reviewSHA256']=='5e2d605803175a52a5abd9b6fc412b277de3de3ada3c0ce1d20d0361066ed37f' and phase['allowSingleB065RetirementAttemptOnly'] is True and pa['allowSingleB065RetirementAttemptOnly'] is True,'phase source acceptance')
    for k in ['retireThisOneFile','actualPreparationIndependentlyAccepted','preferredSuccessorRootwiseAccepted','ownerReviewedRetirementAuthorized','knownAffectedUsersGenuinelyCoordinatedAndHeld','noUnknownAffectedOwner','allProofLogsFailuresHarnessesPreserved']:
        need(decl[k] is True,'renewed root judgment/hold: '+k)
    need(decl['knownLiveAffectedOwners']==[] and decl['rootJudgment'] and decl['issuedUnixSeconds']<=reval['completedUnixSeconds']<=decl['issuedUnixSeconds']+900,'fresh declared window')
    need(armed['coverage']==reval['coverage'] and armed['oldMetadata']==reval['oldMetadata'] and armed['oldPath']==retired['oldPath']==decl['oldPath'] and armed['oldSHA256']==retired['oldSHA256']==decl['oldSHA256'],'arm/outcome identities')
    need(retired['retired'] is True and retired['oldEncodingSupersededNotByteDuplicate'] is True and retired['allOld3586ObjectIdentitiesPreserved'] is True and retired['otherArtifactsTouched'] is False and retired['successorPathUnchanged']==reval['preferredSuccessorPath'],'retirement scoped outcome')
    delta=wrapper['after']['tmpAvailableBytes']-wrapper['before']['tmpAvailableBytes'];need(delta==reval['oldAllocatedPotential']==1526525952,'measured exact tmp availability gain')
    need(len(retired['samples'])==3 and all(v['memory.events']=='low 0\nhigh 0\nmax 290744\noom 0\noom_kill 0\noom_group_kill 0\n' for v in retired['samples']),'post outcome events')
    old=Path(retired['oldPath']);flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC;fds=[os.open('/',flags)]
    try:
        for name in str(old.parent).split('/')[1:]:fds.append(os.open(name,flags,dir_fd=fds[-1]))
        s=os.fstat(fds[-1]);need((s.st_dev,s.st_ino)==(33,1887587),'original parent identity remains')
        try:os.stat(old.name,dir_fd=fds[-1],follow_symlinks=False)
        except FileNotFoundError:absent=True
        else:raise RuntimeError('old exact entry still exists')
    finally:
        for fd in reversed(fds):os.close(fd)
    # Preserve every original listed by the actual preparation audit, including
    # both compressed restore/closure proofs and original failure/source gates.
    for p,row in prior['originals'].items():
        read(p,512*1024);need(rows[p]==row,'preserved original hash/meta '+p)
    successor=j('/workspace/scratch/retained-source-bundle-verify-run-r2/SUCCESSOR-VERIFICATION.json');target=Path(successor['targetPath']);fds=[os.open('/',flags)];fd=None;parents=[]
    try:
        for name in str(target.parent).split('/')[1:]:
            p=fds[-1];fds.append(os.open(name,flags,dir_fd=p));s=os.fstat(fds[-1]);need(s==os.stat(name,dir_fd=p,follow_symlinks=False),'successor parent drift');parents.append({'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid})
        fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=fds[-1]);s=os.fstat(fd);mapping=[('dev','st_dev'),('ino','st_ino'),('mode','st_mode'),('uid','st_uid'),('gid','st_gid'),('nlink','st_nlink'),('bytes','st_size'),('blocks','st_blocks'),('mtimeNS','st_mtime_ns'),('ctimeNS','st_ctime_ns'),('atimeNS','st_atime_ns')];fresh={'metadata':{a:getattr(s,b)for a,b in mapping},'xattrs':{n:os.getxattr(fd,n).hex()for n in os.listxattr(fd)}}
        need(fresh==successor['after'] and parents==successor['parentChainAfter'] and meta(s)==meta(os.fstat(fd))==meta(os.stat(target.name,dir_fd=fds[-1],follow_symlinks=False)),'retained successor currently exact')
    finally:
        if fd is not None:os.close(fd)
        for fd in reversed(fds):os.close(fd)
    snapshot=dict(rows)
    for p,row in snapshot.items():read(p,512*1024);need(rows[p]==row,'postreview readback original drift')
    final=memory();evidence={'decision':'ACCEPT observed one fixed TMP encoding retirement; preserved successor and selected proof originals exact','oldExactPathAbsent':absent,'oldParentStillSame':True,'successorFreshMetadataExact':True,'successorAtimePreserved':True,'observedTmpAvailableBytesBefore':wrapper['before']['tmpAvailableBytes'],'observedTmpAvailableBytesAfter':wrapper['after']['tmpAvailableBytes'],'observedTmpAvailableGainBytes':delta,'cgroupIntervalCurrentDecreaseBytes':wrapper['before']['cgroupCurrentBytes']-wrapper['after']['cgroupCurrentBytes'],'exclusiveCgroupCausalityClaim':False,'preservedPriorOriginals':len(prior['originals']),'allOriginalsBeforeAfterEqual':True,'originalCount':len(snapshot),'originals':snapshot,'noReviewerBodyReadAdviceGitUnlink':True,'allOwnTargetFDsClosed':True,'memoryBefore':initial,'memoryAfter':final}
    with open(OUT/'RESULT.json','x')as f:json.dump(evidence,f,sort_keys=True,separators=(',',':'));f.write('\n')
    print(json.dumps({k:v for k,v in evidence.items()if k!='originals'}))
except BaseException as e:
    with open(OUT/'AUDIT-FAILURE.json','x')as f:json.dump({'error':str(e),'type':type(e).__name__,'originals':rows},f,sort_keys=True,separators=(',',':'));f.write('\n')
    raise
