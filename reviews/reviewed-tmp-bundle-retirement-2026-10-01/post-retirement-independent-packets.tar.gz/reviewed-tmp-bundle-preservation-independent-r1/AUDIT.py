"""Bounded canonical receipt archive validation; no game/archive source body."""
import gzip,hashlib,io,json,os,stat,tarfile
from pathlib import Path
BASE=Path('/workspace/Roguelike-deckbuilder/reviews/reviewed-tmp-bundle-retirement-2026-10-01');OUT=Path('/workspace/scratch/reviewed-tmp-bundle-preservation-independent-r1');inputs={}
def need(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(s):return{k:getattr(s,k)for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}
def read(p):
    p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        s=os.fstat(fd);need(stat.S_ISREG(s.st_mode) and s.st_size<=256*1024,'bounded control');b=os.read(fd,256*1024+1);need(len(b)==s.st_size and os.read(fd,1)==b'','whole small receipt');need(meta(s)==meta(os.fstat(fd))==meta(os.stat(p,follow_symlinks=False)),'metadata drift');inputs[str(p)]={'bytes':len(b),'sha256':sha(b),'metadata':meta(s)};return b
    finally:os.close(fd)
def memory():
    s=Path('/proc/self/status').read_bytes();need(len(s)<=8192,'status bound');v={}
    for l in s.decode().splitlines():
        if l.startswith(('VmHWM:','VmRSS:')):k,n,u=l.split();need(u=='kB','unit');v[k[:-1]]=int(n)*1024
    head=int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text());need(max(v.values())<=24*1024**2 and head>=88*1024**2,'own24+64 reserve');return{**v,'headroomBytes':head}
try:
    initial=memory();preserved=read(BASE/'PRESERVATION.json');p=json.loads(preserved);archive=read(BASE/'original-packets.tar.gz');review=read(BASE/'REVIEW.md')
    need(len(archive)==p['archiveBytes']==117169 and sha(archive)==p['archiveSHA256']=='aa800902333e46b648ae3d2be87ba5273ebaa70665e35e4e59370eb673312af1','archive bytes/SHA')
    files=p['files'];expected={v['member']:v for v in files};need(len(expected)==len(files)==133 and len({v['path']for v in files})==133,'closed unique133-set')
    need(sum(v['bytes']for v in files)==p['rawBytes']==539031,'raw closed total');seen=set();body_total=0
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tar:
        for member in tar:
            need(member.isfile()and not member.issparse() and member.name in expected and member.name not in seen,'closed regular unique archive member')
            row=expected[member.name];need(member.size==row['bytes']and member.size<=256*1024,'member bounds')
            body=tar.extractfile(member).read(member.size+1);need(len(body)==row['bytes']and sha(body)==row['sha256'],'member full rawSHA')
            original=read(row['path']);need(original==body,'archive/original byte equivalence');seen.add(member.name);body_total+=len(body)
    need(seen==set(expected) and body_total==539031,'no missing/extra bodies')
    before=dict(inputs)
    for path,row in before.items():read(path);need(inputs[path]==row,'every original/control beforeafter hash/fullmetadata including atime')
    final=memory();raw=(json.dumps(before,sort_keys=True,separators=(',',':'))+'\n').encode();compressed=gzip.compress(raw,mtime=0)
    with open(OUT/'INPUT-LEDGER.json.gz','xb')as f:f.write(compressed)
    result={'decision':'ACCEPT exact closed133-member canonical preservation and all original equivalence','archiveSHA256':sha(archive),'preservationSHA256':sha(preserved),'initialReviewSHA256':sha(review),'memberCount':133,'rawBodyBytes':539031,'archiveBytes':117169,'originalsAndCanonicalInputs':len(before),'everyBodyOriginalEquivalent':True,'fullOriginalReadbacksAndMetadataExactWithinReview':True,'historicalControlAtimeQualification':'Earlier root declaration read atime change is preserved in separate post-retirement review; this check establishes current-pass exactness only','metadataLedgerRawBytes':len(raw),'metadataLedgerRawSHA256':sha(raw),'metadataLedgerGzipSHA256':sha(compressed),'ownMemoryBefore':initial,'ownMemoryAfter':final,'noExtractionWrites':True,'noSourceBundleReadsAdviceGitRuntime':True}
    with open(OUT/'RESULT.json','x')as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(result))
except BaseException as e:
    with open(OUT/'FAILURE.json','x')as f:json.dump({'error':str(e),'type':type(e).__name__,'inputs':inputs},f,sort_keys=True,separators=(',',':'));f.write('\n')
    raise
