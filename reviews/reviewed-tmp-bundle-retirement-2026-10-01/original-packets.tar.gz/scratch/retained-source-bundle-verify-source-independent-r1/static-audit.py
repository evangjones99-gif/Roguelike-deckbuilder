import os,ast,json,pathlib,hashlib,resource
OWN=pathlib.Path(__file__).parent
AUTH=pathlib.Path('/workspace/scratch/retained-source-bundle-verify-author-r1')
def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC)
    try:
        s=os.fstat(fd);assert s.st_size<=32768
        b=os.read(fd,32769);assert len(b)==s.st_size;return b
    finally:os.close(fd)
def H(b):return hashlib.sha256(b).hexdigest()
def metadata(s):return {k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns')}
files=sorted(AUTH.iterdir())
before=[{'path':str(p),'sha256':H(read(p)),'metadata':metadata(os.stat(p))} for p in files]
source=read(AUTH/'verify_bundle.py');assert H(source)=='50a2040ca19c27cfff135514eeba75a017766e5cf01bbc2e602b9cd080a9fce5'
tree=ast.parse(source);calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='os' and n.func.attr=='posix_fadvise'];assert len(calls)==1
assert ast.unparse(calls[0])=='os.posix_fadvise(fd, advised_end, end - advised_end, os.POSIX_FADV_DONTNEED)'
for row in json.loads(read(AUTH/'FROZEN-FILES.json'))['files']:
    body=read(AUTH/row['path']);assert len(body)==row['bytes'] and H(body)==row['sha256']
pin=json.loads(read(AUTH/'PIN.json'));assert pin['pageBytes']==4096
assert pin['expectedBytes']==1711151088 and pin['expectedHistoricalSHA256']=='fd1310a36be0931bb81537004f87ef751481ca0daa349e58f1576a3c34640b3d'
fd=None;parents=[]
try:
    flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    parents.append(os.open('/',flags));target=pathlib.Path(pin['target']);chain=[]
    for name in target.parent.parts[1:]:
        q=os.open(name,flags,dir_fd=parents[-1]);parents.append(q);s=os.fstat(q)
        chain.append({'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid})
    assert chain==pin['parents']
    fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=parents[-1]);m=metadata(os.fstat(fd));attrs={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)}
    assert m==pin['metadata']==metadata(os.stat(target.name,dir_fd=parents[-1],follow_symlinks=False)) and attrs==pin['xattrs']
    assert metadata(os.fstat(fd))==m
finally:
    if fd is not None:os.close(fd)
    for q in reversed(parents):os.close(q)
for row in pin['priorSmallRestoreReceipts']:
    b=read(row['path']);assert len(b)==row['bytes'] and H(b)==row['sha256']
after=[{'path':str(p),'sha256':H(read(p)),'metadata':metadata(os.stat(p))} for p in files];assert before==after
result={'schema':1,'scope':'Independent AST/control verification and anchored target metadata only; no tool import/hashbody/advice/Git/runtime','sourceSHA256':H(source),'pinSHA256':H(read(AUTH/'PIN.json')),'authorFilesBeforeAfterExact':before,'targetFreshMetadata':m,'targetFreshXattrs':attrs,'ownDescriptorsClosed':True,'targetBodyBytesRead':0,'ownAdviceCalls':0,'oneSourceAdviceCallSite':True,'mathematicalCompleteAlignedExtent':1711151088//4096*4096,'mathematicalUnadvisedTail':1711151088%4096,'maximumCheckpointCount':(1711151088+8388607)//8388608,'maxRSSKiBHistorical':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'actualWholeSHAUnknownCurrent':True,'priorRestoreReferencedNotRerun':pin['priorSmallRestoreReceipts']}
with open(OWN/'STATIC-RESULT.json','x') as f:json.dump(result,f,indent=2)
print(json.dumps({'status':'PASS independent source intake','ownBytes':sum(f.stat().st_size for f in OWN.iterdir())}))
