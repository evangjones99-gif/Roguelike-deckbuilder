import os,ast,pathlib,json,hashlib,zlib,re
OWN=pathlib.Path(__file__).parent
AUTH=pathlib.Path('/workspace/scratch/b065-research-bundle-retirement-author-r2')
def H(b):return hashlib.sha256(b).hexdigest()
def read(p,limit=32768):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC)
    try:
        s=os.fstat(fd);assert s.st_size<=limit;b=os.read(fd,limit+1);assert len(b)==s.st_size;return b
    finally:os.close(fd)
def meta(p):
    s=os.stat(p,follow_symlinks=False);return {k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_size','st_nlink','st_uid','st_gid','st_atime_ns','st_mtime_ns','st_ctime_ns')}
proofs=[pathlib.Path('/workspace/scratch/release-bundle-fullsize-independent-v07-r2/full-restore-proof.json.gz'),pathlib.Path('/workspace/scratch/release-v08-final-independent-r1/REACHABLE-OBJECTS.json.gz'),pathlib.Path('/workspace/scratch/release-v08-final-independent-r1/RESTORE-RESULT.json')]
paths=sorted(list(AUTH.iterdir())+proofs)
before=[{'path':str(p),'metadata':meta(p),'sha256':H(read(p,524288))} for p in paths]
source=read(AUTH/'retire_b065_bundle.py');assert H(source)=='96e0464807309ba79f9f99eaf3f30be7768a4b5a3bc6db2d85f7f79125affec1';tree=ast.parse(source)
for r in json.loads(read(AUTH/'FROZEN-FILES.json'))['files']:assert len(read(AUTH/r['path']))==r['bytes'] and H(read(AUTH/r['path']))==r['sha256']
assert 'consumers_closed' not in {n.name for n in tree.body if isinstance(n,ast.FunctionDef)}
calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='os' and n.func.attr=='unlink'];assert len(calls)==1 and ast.unparse(calls[0])=='os.unlink(name, dir_fd=p)'
def unzip(p,compressedSHA,rawSHA,rawBytes):
    b=read(p,524288);assert H(b)==compressedSHA
    d=zlib.decompressobj(16+zlib.MAX_WBITS);r=d.decompress(b,2097153)
    assert d.eof and not d.unused_data and not d.unconsumed_tail and len(r)==rawBytes and H(r)==rawSHA
    return r
oldraw=unzip(proofs[0],'c963bb9709e584b18c4b6be67e4eda42e4eddf9d47a71aabde8096c3854cea71','ff65e50b40c55f52e095b2ff29dc83b6c8aa98d9227ff85373b48fd7c50cb337',1597701)
old=json.loads(oldraw);oldoids={r.split()[0] for r in old['objectInventory']}
newraw=unzip(proofs[1],'174494893e3e1e605fe9a965bfb117d3cf0c971703d8db3d4080b0b8daa3aac0','22229fe4fe1b74f618ecb7f81f2d5158765e6ad01ac337ce2c568ced41f89703',173963)
newrows=newraw.decode().splitlines();newoids=set(newrows)
assert len(oldoids)==3586 and len(newoids)==len(newrows)==4243 and not oldoids-newoids
assert old['selfContained'] and old['fsckOutput']=='' and old['reachableObjectCount']==3586 and len(old['identity']['files'])==5904
assert old['sourceCommit']=='b065d1044c9486b616f2eb2e95021de18c349ab7' and old['identity']['tree']=='aaed2c69d8543f020a863afc3b969cee3148d339'
assert H(('\n'.join(sorted(oldoids))+'\n').encode())=='aafbaef598420ad1e21075980ec63f73fce95d3a577a242258ab9d5e535fd3f4'
restore=read(proofs[2]);assert H(restore)=='a334dbc8828bf29b4fff892ea176db4f62a4f01d09298f34784cb930c4d83f2f'
after=[{'path':str(p),'metadata':meta(p),'sha256':H(read(p,524288))} for p in paths];assert before==after
r={'schema':1,'status':'PASS independent R2 source/frozen-controls and referenced logical OID coverage','sourceSHA256':H(source),'allAuthorAndSmallProofRawSHAStatUnchanged':before,'oldOIDCount':len(oldoids),'newOIDCount':len(newoids),'missingOldOIDs':len(oldoids-newoids),'oldFileIdentityRows':len(old['identity']['files']),'oldRefsPreservedInProof':old['refs'],'logicalCoverageScope':'Fresh small reference-ledger comparison only; no fresh raw Git objects/restore/bundle body','actualOldOrNewBundleBodyBytesRead':0,'utilityImports':0,'pidScans':0,'preparations':0,'unlinks':0,'independentActualPreparationRequired':True}
with open(OWN/'STATIC-RESULT.json','x') as f:json.dump(r,f,indent=2)
print(json.dumps({'status':'PASS source and small-reference coverage','ownBytes':sum(p.stat().st_size for p in OWN.iterdir())}))
