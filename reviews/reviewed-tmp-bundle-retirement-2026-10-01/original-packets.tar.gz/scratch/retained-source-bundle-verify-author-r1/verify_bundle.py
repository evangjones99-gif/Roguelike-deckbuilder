"""SOURCE ONLY. A separately reviewed root-only whole-bundle hash/cache attempt.
No deletion, replacement, chmod, rename, Git, restoration, or retirement action.
"""
import argparse,hashlib,json,os,re,resource,stat,sys,time
from pathlib import Path
BASE='/workspace/scratch/retained-source-bundle-verify-author-r1'
TARGET='/workspace/Roguelike-deckbuilder/releases/0.8.0/hollowpact-0.8.0-source.bundle'
OUTPUT='/workspace/scratch/retained-source-bundle-verify-run-r1'
EXPECTED_BYTES=1711151088
EXPECTED_SHA='fd1310a36be0931bb81537004f87ef751481ca0daa349e58f1576a3c34640b3d'
SCOPE='One retained0.8 source bundle whole SHA256 with consumed-page-only cache advice; no retirement'
WORK=64*1024**2;RESERVE=512*1024**2;CHUNK=256*1024;CHECKPOINT=8*1024**2
BUDGET=256*1024

def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def meta(s):return{k:getattr(s,k)for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}
def identity(s):return{'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid}
def successor_meta(v):
    return{new:v[old]for new,old in [('dev','st_dev'),('ino','st_ino'),('mode','st_mode'),('uid','st_uid'),('gid','st_gid'),('nlink','st_nlink'),('bytes','st_size'),('blocks','st_blocks'),('mtimeNS','st_mtime_ns'),('ctimeNS','st_ctime_ns'),('atimeNS','st_atime_ns')]}
def anchor(p):
    require(p.startswith('/')and'..'not in p.split('/'),'Literal absolute path required')
    fds=[];rows=[];flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    try:
        fds.append(os.open('/',flags))
        for n in p.split('/')[1:]:
            if not n:continue
            parent=fds[-1];fd=os.open(n,flags,dir_fd=parent);fds.append(fd)
            r=identity(os.fstat(fd));require(r==identity(os.stat(n,dir_fd=parent,follow_symlinks=False)),'Redirected parent')
            rows.append((parent,n,fd,r))
        return fds,rows
    except BaseException:
        for fd in reversed(fds):os.close(fd)
        raise
def stable(rows):
    for p,n,fd,r in rows:require(identity(os.fstat(fd))==r==identity(os.stat(n,dir_fd=p,follow_symlinks=False)),'Parent drift')
def chain_json(rows):return[{'name':n,**r}for _,n,_,r in rows]
def control(p,limit=32768):
    p=Path(p);fds,rows=anchor(str(p.parent));fd=None
    try:
        fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=fds[-1]);s=os.fstat(fd)
        require(stat.S_ISREG(s.st_mode)and s.st_size<=limit,'Control bounds/type')
        b=bytearray()
        while True:
            chunk=os.read(fd,min(4096,limit+1-len(b)))
            if not chunk:break
            b.extend(chunk);require(len(b)<=limit,'Control read limit')
        stable(rows);require(s==os.fstat(fd)==os.stat(p.name,dir_fd=fds[-1],follow_symlinks=False),'Control drift')
        return bytes(b)
    finally:
        if fd is not None:os.close(fd)
        for f in reversed(fds):os.close(f)
def target_observation(fd,parent,leaf):
    # Used on failures even when resource admission no longer holds. No body read.
    a=os.fstat(fd);p=os.stat(leaf,dir_fd=parent,follow_symlinks=False)
    names=sorted(os.listxattr(fd));require(len(names)<=32,'Target xattr count bound')
    attrs={};used=0
    for n in names:
        b=os.getxattr(fd,n);used+=len(b);require(used<=16384,'Target xattr byte bound');attrs[n]=b.hex()
    return{'metadata':meta(a),'pathMetadata':meta(p),'xattrs':attrs,'descriptorStatAfter':meta(os.fstat(fd))}
def exact_target(v,pin):
    expected=pin['metadata'];require(v['metadata']==v['pathMetadata']==v['descriptorStatAfter']==expected and v['xattrs']==pin['xattrs'],'Target full metadata/atime/xattrs drift')
    require(stat.S_ISREG(expected['st_mode'])and expected['st_uid']==os.geteuid()and expected['st_size']==EXPECTED_BYTES,'Owned regular pinned target required')
def memory_sample():
    with open('/proc/self/status','rb')as f:b=f.read(8193)
    require(len(b)<=8192,'Process status bound')
    fields={}
    for line in b.decode('ascii').splitlines():
        if line.startswith(('VmSize:','VmHWM:','VmRSS:','VmPeak:')):
            k,v,u=line.split();require(u=='kB','Unknown process-memory unit');fields[k[:-1]]=int(v)*1024
    c=Path('/sys/fs/cgroup');v={n:(c/n).read_text()for n in ['memory.current','memory.max','memory.stat','memory.events']}
    finite=v['memory.max'].strip()!='max';head=int(v['memory.max'])-int(v['memory.current'])if finite else None
    return{'headroomBytes':head,'ownCurrentExecBytes':fields,'historicalRuMaxRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'cgroup':v}
def guard(sample,verbose=False):
    m=sample['ownCurrentExecBytes'];valid_head=sample['headroomBytes']is not None and sample['headroomBytes']>=WORK+RESERVE
    valid_own=all(k in m for k in ['VmRSS','VmHWM','VmSize'])and m['VmRSS']<=WORK and m['VmHWM']<=WORK
    if verbose or not(valid_head and valid_own):print(json.dumps({'phase':'admission-before-assertions','requiredBytes':WORK+RESERVE,'workBytes':WORK,'reserveBytes':RESERVE,**sample}),file=sys.stderr,flush=True)
    require(sample['headroomBytes']is not None and sample['headroomBytes']>=WORK+RESERVE,'64MiB work +512MiB reserve refused')
    m=sample['ownCurrentExecBytes'];require(all(k in m for k in ['VmRSS','VmHWM','VmSize']),'Own process metrics absent')
    require(m['VmRSS']<=WORK and m['VmHWM']<=WORK,'Own current-exec RSS/HWM exceeds64MiB')
def locks(dev,ino):
    with open('/proc/locks','rb')as f:b=f.read(128*1024+1)
    require(len(b)<=128*1024,'Lock observation bound');target=(os.major(dev),os.minor(dev),ino);count=0
    for line in b.decode('ascii').splitlines():
        if not line.strip():continue
        matches=[m for t in line.split()if(m:=re.fullmatch(r'([0-9a-fA-F]+):([0-9a-fA-F]+):(\d+)',t))]
        require(len(matches)==1,'Unknown lock syntax');m=matches[0];count+=1
        require((int(m[1],16),int(m[2],16),int(m[3]))!=target,'Visible target lock, including blocked lock')
    return{'visibleRows':count,'metadataSHA256':sha(b),'qualification':'Visible namespace only, not atomic global exclusion'}
class Receipts:
    def __init__(self):
        self.fds,self.rows=anchor('/workspace/scratch');self.fd=None;self.failure=None;self.stream=None;self.used=0
        try:
            v=os.statvfs('/workspace/scratch');require(v.f_bavail*v.f_frsize>=1024**2+BUDGET,'Durable receipt reserve')
            os.mkdir(Path(OUTPUT).name,0o700,dir_fd=self.fds[-1]);self.fd=os.open(Path(OUTPUT).name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC,dir_fd=self.fds[-1])
            self.write('FAILURE-SLOT.json',enc({'status':'reserved; no failure recorded'}).ljust(16384,b' '))
            self.failure=os.open('FAILURE-SLOT.json',os.O_WRONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.fd)
            self.stream=os.open('CHECKPOINTS.jsonl',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fd)
            os.fsync(self.stream);os.fsync(self.fd)
        except BaseException:self.close();raise
    def write_fd(self,fd,b):
        require(self.used+len(b)<=BUDGET,'Receipt budget exhausted');view=memoryview(b)
        while view:
            n=os.write(fd,view);require(n>0,'Short receipt write');view=view[n:]
        os.fsync(fd);os.fsync(self.fd);self.used+=len(b)
    def write(self,n,b):
        fd=None
        try:fd=os.open(n,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fd);self.write_fd(fd,b)
        finally:
            if fd is not None:os.close(fd)
    def checkpoint(self,v):self.write_fd(self.stream,enc(v))
    def fail(self,v):
        b=enc(v);require(len(b)<=16384,'Failure slot bound');b=b.ljust(16384,b' ');offset=0
        while offset<len(b):
            n=os.pwrite(self.failure,b[offset:],offset);require(n>0,'Short failure write');offset+=n
        os.fsync(self.failure);os.fsync(self.fd)
    def close(self):
        for key in ['stream','failure','fd']:
            fd=getattr(self,key,None)
            if fd is not None:os.close(fd);setattr(self,key,None)
        for fd in reversed(self.fds):os.close(fd)
        self.fds=[]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--declaration',required=True);p.add_argument('--acceptance',required=True);args=p.parse_args()
    # Wrapper captures all stderr/exit, including creation failure before this slot.
    initial=memory_sample();print(json.dumps({'phase':'bootstrap-observation',**initial}),file=sys.stderr,flush=True)
    r=Receipts();fds=[];fd=None;bytes_read=0;read_calls=0;advice_calls=0;advised_end=0;pending=None;samples=0;before=None;pin=None;minimum=initial['headroomBytes'];maximum_rss=initial['ownCurrentExecBytes'].get('VmHWM',0);started=time.monotonic()
    try:
        guard(initial,True);vm=initial['ownCurrentExecBytes']['VmSize']
        print(json.dumps({'phase':'AS-before-assertion','baselineBytes':vm,'baselineCeilingBytes':64*1024**2,'additionalASRoomBytes':8*1024**2}),file=sys.stderr,flush=True)
        require(vm<=64*1024**2,'Virtual baseline exceeds64MiB');resource.setrlimit(resource.RLIMIT_AS,(vm+8*1024**2,vm+8*1024**2))
        require(all(hasattr(os,k)for k in ['O_PATH','O_NOATIME','POSIX_FADV_DONTNEED','posix_fadvise']),'Required Linux APIs absent')
        source=control(str(Path(__file__).absolute()));pinraw=control(BASE+'/PIN.json');pin=json.loads(pinraw);source_sha=sha(source);pin_sha=sha(pinraw)
        require(pin['target']==TARGET and pin['expectedBytes']==EXPECTED_BYTES and pin['expectedHistoricalSHA256']==EXPECTED_SHA,'Fixed target pin mismatch')
        page=pin['pageBytes'];require(page==os.sysconf('SC_PAGE_SIZE')and page>0 and CHUNK%page==0,'Page/chunk alignment mismatch')
        dbytes=control(args.declaration);abytes=control(args.acceptance);d=json.loads(dbytes);a=json.loads(abytes)
        for v in [d,a]:require(v['sourceSHA256']==source_sha and v['pinSHA256']==pin_sha and v['scope']==SCOPE,'Control source/pin/scope mismatch')
        require(a.get('allowOneWholeHashCacheAttempt')is True and sha(control(a['reviewPath']))==a['reviewSHA256'],'Independent exact-source acceptance absent')
        for k in ['allKnownTargetWritersHeld','targetMaintenanceHeld','noUnknownAffectedWriter','noUnknownAffectedLockOwner','noHeavyRuntimeConcurrent']:
            require(d.get(k)is True,'Genuine root hold absent: '+k)
        def fresh():
            require(control(args.declaration)==dbytes,'Declaration drift');require(-5<=time.time()-d['issuedUnixSeconds']<=300,'Root declaration expired')
        fresh();r.write('CONTROLS.json',enc({'sourceSHA256':source_sha,'pinSHA256':pin_sha,'declaration':d,'acceptance':a,'chunkBytes':CHUNK,'pageBytes':page,'scope':SCOPE}))
        target=Path(TARGET);fds,chain=anchor(str(target.parent));require(chain_json(chain)==pin['parents'],'Pinned parent mismatch')
        fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=fds[-1]);before=target_observation(fd,fds[-1],target.name);exact_target(before,pin);stable(chain);prelocks=locks(pin['metadata']['st_dev'],pin['metadata']['st_ino']);fresh()
        r.write('BEFORE.json',enc({'target':before,'parentChain':chain_json(chain),'locks':prelocks,'memory':initial}))
        h=hashlib.sha256();next_checkpoint=CHECKPOINT
        r.write('ARMED.json',enc({'phase':'complete stream authorized','target':TARGET,'expectedBytes':EXPECTED_BYTES,'expectedSHA256':EXPECTED_SHA,'advice':'fully hashed consumed page-aligned ranges only','interruptedScope':'No whole-hash success unless exclusive final successor receipt exists; hints since last checkpoint may have unknown outcomes'}))
        while bytes_read<EXPECTED_BYTES:
            sample=memory_sample();guard(sample);minimum=min(minimum,sample['headroomBytes']);maximum_rss=max(maximum_rss,sample['ownCurrentExecBytes']['VmHWM'])
            data=os.read(fd,min(CHUNK,EXPECTED_BYTES-bytes_read));read_calls+=1;require(data,'Premature EOF');h.update(data);bytes_read+=len(data)
            end=(bytes_read//page)*page
            if end>advised_end:
                pending={'offset':advised_end,'length':end-advised_end,'hashedBytes':bytes_read}
                # No retry on any advice error. Only fully consumed pages qualify.
                os.posix_fadvise(fd,advised_end,end-advised_end,os.POSIX_FADV_DONTNEED)
                advice_calls+=1;advised_end=end;pending=None
            if bytes_read>=next_checkpoint or bytes_read==EXPECTED_BYTES:
                fresh();stable(chain);exact_target(target_observation(fd,fds[-1],target.name),pin)
                sample=memory_sample();guard(sample);minimum=min(minimum,sample['headroomBytes']);maximum_rss=max(maximum_rss,sample['ownCurrentExecBytes']['VmHWM'])
                r.checkpoint({'bytesRead':bytes_read,'readCalls':read_calls,'adviceCalls':advice_calls,'advisedPageBytes':advised_end,'headroomBytes':sample['headroomBytes'],'ownVmHWMBytes':sample['ownCurrentExecBytes']['VmHWM'],'memoryEvents':sample['cgroup']['memory.events']});samples+=1;next_checkpoint=bytes_read+CHECKPOINT
        read_calls+=1;require(os.read(fd,1)==b'','Unexpected bytes beyond pinned extent');whole_sha=h.hexdigest();require(whole_sha==EXPECTED_SHA,'Whole SHA256 mismatch')
        after=target_observation(fd,fds[-1],target.name);exact_target(after,pin);stable(chain);parent_after=chain_json(chain);postlocks=locks(pin['metadata']['st_dev'],pin['metadata']['st_ino']);fresh()
        os.close(fd);fd=None
        for f in reversed(fds):os.close(f)
        fds=[]
        final=[]
        for i in range(3):
            if i:time.sleep(0.05)
            sample=memory_sample();guard(sample,True);minimum=min(minimum,sample['headroomBytes']);maximum_rss=max(maximum_rss,sample['ownCurrentExecBytes']['VmHWM']);final.append(sample)
        summary={'readCalls':read_calls,'adviceCalls':advice_calls,'advisedPageBytes':advised_end,'unadvisedTailBytes':bytes_read-advised_end,'sampleRows':samples,'minimumObservedHeadroomBytes':minimum,'maximumObservedVmHWMBytes':maximum_rss,'elapsedSeconds':time.monotonic()-started,'reclaimGuaranteed':False}
        r.write('AFTER.json',enc({'target':after,'parentChain':parent_after,'locks':postlocks,'samples':final,'summary':summary,'metadataExact':True,'allOwnTargetFDsClosed':True}))
        result={'schema':1,'kind':'retained-source-bundle-whole-verification','targetPath':TARGET,'bytesRead':bytes_read,'expectedBytes':EXPECTED_BYTES,'expectedSHA256':EXPECTED_SHA,'freshlyStreamedSHA256':whole_sha,'wholeHashMatches':True,'before':{'metadata':successor_meta(before['metadata']),'xattrs':before['xattrs']},'after':{'metadata':successor_meta(after['metadata']),'xattrs':after['xattrs']},'parentChainBefore':pin['parents'],'parentChainAfter':parent_after,'allTargetFDsClosed':True,'sourceSHA256':source_sha,'pinSHA256':pin_sha,'summary':summary,'priorRestoreReceipt':pin['priorSmallRestoreReceipts'][0],'scope':'Fresh whole bundle SHA + exact metadata only; prior full restore proof referenced, not rerun. No retirement/deletion/coverage or causal reclaim approval.'}
        r.write('SUCCESSOR-VERIFICATION.json',enc(result));print(json.dumps({'wholeHashMatches':True,'receipt':OUTPUT+'/SUCCESSOR-VERIFICATION.json','summary':summary}))
    except BaseException as e:
        failure={'errorType':type(e).__name__,'error':str(e)[:1800],'errno':getattr(e,'errno',None),'bytesRead':bytes_read,'readCalls':read_calls,'returnedAdviceCalls':advice_calls,'advisedPageBytes':advised_end,'pendingAdvice':pending,'scope':'Stop; no retry/extra hint/rollback/retirement. Partial digest is not whole-bundle verification.','lastAdmissionSample':locals().get('sample',initial)}
        if fd is not None:
            try:failure['postFailureTarget']=target_observation(fd,fds[-1],Path(TARGET).name)
            except BaseException as secondary:failure['postFailureMetadataError']=str(secondary)[:500]
        else:failure['postFailureTarget']='No own target FD open; no fresh descriptor metadata claim'
        try:failure['memoryAfterFailure']=memory_sample()
        except BaseException as secondary:failure['memorySnapshotError']=str(secondary)[:500]
        if fd is not None:os.close(fd);fd=None
        for f in reversed(fds):os.close(f)
        fds=[];failure['allOwnTargetFDsClosed']=True;r.fail(failure);print(json.dumps(failure),file=sys.stderr,flush=True);raise
    finally:
        if fd is not None:os.close(fd)
        for f in reversed(fds):os.close(f)
        r.close()
if __name__=='__main__':main()
