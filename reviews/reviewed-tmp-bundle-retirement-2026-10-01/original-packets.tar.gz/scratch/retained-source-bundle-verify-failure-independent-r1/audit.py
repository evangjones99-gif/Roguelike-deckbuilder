import os,json,pathlib,hashlib
OWN=pathlib.Path(__file__).parent
RUN=pathlib.Path('/workspace/scratch/retained-source-bundle-verify-run-r1')
WRAP=pathlib.Path('/workspace/scratch/retained-source-bundle-verify-ROOT-wrapper-r1')
PACK=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-run-r4')
PACKWRAP=pathlib.Path('/workspace/scratch/git-immutable-pack-cache-hint-ROOT-wrapper-r4')
AUTH=pathlib.Path('/workspace/scratch/retained-source-bundle-verify-author-r1')
REFUSAL=pathlib.Path('/workspace/scratch/retained-source-bundle-verify-ROOT-preflight-refusal-r1.json')
def H(b):return hashlib.sha256(b).hexdigest()
def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        s=os.fstat(fd);assert s.st_size<=32768;b=os.read(fd,32769);assert len(b)==s.st_size;return b
    finally:os.close(fd)
def meta(s):return {k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_size','st_blocks','st_nlink','st_uid','st_gid','st_atime_ns','st_mtime_ns','st_ctime_ns')}
files=sorted(list(RUN.iterdir())+list(WRAP.iterdir())+list(PACK.iterdir())+list(PACKWRAP.iterdir())+[REFUSAL])
before=[{'path':str(p),'sha256':H(read(p)),'metadata':meta(os.stat(p))} for p in files]
f=json.loads(read(RUN/'FAILURE-SLOT.json'));b=json.loads(read(RUN/'BEFORE.json'));controls=json.loads(read(RUN/'CONTROLS.json'));pin=json.loads(read(AUTH/'PIN.json'))
assert controls['sourceSHA256']==H(read(AUTH/'verify_bundle.py'))=='50a2040ca19c27cfff135514eeba75a017766e5cf01bbc2e602b9cd080a9fce5'
assert controls['pinSHA256']==H(read(AUTH/'PIN.json'))=='ed8614dd640545f608783742986028e38b633beb83fb1a5ceea4ce3773eb42db'
assert f['error']=='64MiB work +512MiB reserve refused' and f['bytesRead']==327417856 and f['readCalls']==1249 and f['returnedAdviceCalls']==1249 and f['advisedPageBytes']==327417856 and f['pendingAdvice'] is None
assert f['bytesRead']==f['readCalls']*262144 and f['allOwnTargetFDsClosed']
rows=[json.loads(line) for line in read(RUN/'CHECKPOINTS.jsonl').splitlines()];assert len(rows)==39
for i,row in enumerate(rows,1):
    assert row['bytesRead']==i*8388608 and row['readCalls']==i*32 and row['adviceCalls']==i*32 and row['advisedPageBytes']==row['bytesRead']
    assert row['headroomBytes']>=603979776 and row['memoryEvents']==b['memory']['cgroup']['memory.events']
assert rows[-1]['bytesRead']==327155712 and rows[-1]['headroomBytes']==609447936
assert f['lastAdmissionSample']['headroomBytes']==601059328 and f['lastAdmissionSample']['headroomBytes']<603979776
assert f['postFailureTarget']==b['target'] and f['postFailureTarget']['metadata']==pin['metadata']
assert f['memoryAfterFailure']['cgroup']['memory.events']==b['memory']['cgroup']['memory.events']
assert json.loads(read(WRAP/'RESULT.json'))=={'exitCode':1,'successorReceiptExists':False}
assert not (RUN/'SUCCESSOR-VERIFICATION.json').exists() and not (RUN/'AFTER.json').exists()
assert json.loads(read(PACKWRAP/'RESULT.json'))['exitCode']==0 and json.loads(read(PACK/'RETURNED.json'))['returnedWithoutException']
assert json.loads(read(PACK/'AFTER.json'))['target']==json.loads(read(PACK/'BEFORE.json'))['target']
fd=None;parents=[]
try:
    flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC;parents.append(os.open('/',flags));target=pathlib.Path(pin['target']);chain=[]
    for name in target.parent.parts[1:]:
        q=os.open(name,flags,dir_fd=parents[-1]);parents.append(q);s=os.fstat(q)
        chain.append({'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid})
    assert chain==pin['parents']
    fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK,dir_fd=parents[-1]);fresh=meta(os.fstat(fd));attrs={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)}
    assert fresh==pin['metadata']==meta(os.stat(target.name,dir_fd=parents[-1],follow_symlinks=False)) and attrs==pin['xattrs']
finally:
    if fd is not None:os.close(fd)
    for q in reversed(parents):os.close(q)
assert [{'path':str(p),'sha256':H(read(p)),'metadata':meta(os.stat(p))} for p in files]==before
result={'schema':1,'decision':'Whole-body qualification WITHHELD; accepted failure/protocol preservation witnesses','originalReceiptsBeforeAfterExact':before,'failureReceiptSHA256':H(read(RUN/'FAILURE-SLOT.json')),'bytesRead':f['bytesRead'],'returnedAdviceCalls':f['returnedAdviceCalls'],'durableCheckpoints':len(rows),'lastCheckpointBytes':rows[-1]['bytesRead'],'lastCheckpointHeadroom':rows[-1]['headroomBytes'],'failedHeadroom':f['lastAdmissionSample']['headroomBytes'],'requiredHeadroom':603979776,'wholeSuccessorReceiptAbsent':True,'recordedFDsClosed':True,'freshOwnTargetMetadata':fresh,'freshOwnTargetXattrs':attrs,'ownTargetDescriptorsClosed':True,'ownTargetBodyBytesRead':0,'ownAdviceCalls':0,'potential2MiBCoalescedConsumedPrefix':f['bytesRead']//2097152*2097152,'prefixWholeHashQualification':False,'eventsUnchangedWithinFailureAttempt':True,'hypothesizedTHPPartialAdviceCauseVerified':False}
with open(OWN/'RESULT.json','x') as h:json.dump(result,h,indent=2)
print(json.dumps({'status':'PASS failure inspection; whole SHA withheld','ownBytes':sum(p.stat().st_size for p in OWN.iterdir())}))
