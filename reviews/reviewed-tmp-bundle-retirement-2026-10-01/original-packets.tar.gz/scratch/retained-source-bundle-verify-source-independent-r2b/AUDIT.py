"""Independent static audit. No candidate imports, bundle reads or advice."""
import ast,hashlib,json,os,stat,difflib,sys
from pathlib import Path
OUT=Path('/workspace/scratch/retained-source-bundle-verify-source-independent-r2b')
BASE=Path('/workspace/scratch/retained-source-bundle-verify-author-r2b')
def require(v,m):
    if not v:raise RuntimeError(m)
def digest(b):return hashlib.sha256(b).hexdigest()
def meta(s):return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}
def own_memory():
    b=Path('/proc/self/status').read_bytes();require(len(b)<=8192,'status bound')
    v={}
    for l in b.decode().splitlines():
        if l.startswith(('VmRSS:','VmHWM:','VmSize:')):
            k,n,u=l.split();require(u=='kB','units');v[k[:-1]]=int(n)*1024
    require(v['VmHWM']<=24*1024**2 and v['VmRSS']<=24*1024**2,'own audit24MiB allowance')
    current=int(Path('/sys/fs/cgroup/memory.current').read_text());maximum=int(Path('/sys/fs/cgroup/memory.max').read_text())
    require(maximum-current>=88*1024**2,'audit24+64 reserve')
    return {**v,'headroomBytes':maximum-current}
inputs={}
def read(p,limit=32768):
    p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd);require(stat.S_ISREG(before.st_mode) and before.st_size<=limit,'bounded regular input')
        b=os.read(fd,limit+1);require(len(b)==before.st_size and len(b)<=limit and os.read(fd,1)==b'','bounded whole small input')
        require(meta(before)==meta(os.fstat(fd))==meta(os.stat(p,follow_symlinks=False)),'input drift')
        inputs[str(p)]={'bytes':len(b),'sha256':digest(b),'metadata':meta(before)}
        return b
    finally:os.close(fd)
try:
    initial=own_memory()
    frozen=read(BASE/'FROZEN-FILES.json');require(digest(frozen)=='1958265a8a4994b00ace9d212b79e1c93eb7368dd4c11bd95781bbf4566eb385','freeze mismatch')
    bodies={}
    for row in json.loads(frozen)['files']:
        b=read(BASE/row['path']);require(len(b)==row['bytes'] and digest(b)==row['sha256'],'frozen body mismatch');bodies[row['path']]=b
    source=bodies['verify_bundle.py'];require(digest(source)=='1757fd8153ce5d8094c0ab5d509c6387f22ae8388271072e41864a7d80d98a8e','source mismatch')
    r2=Path('/workspace/scratch/retained-source-bundle-verify-author-r2')
    prior=read(r2/'verify_bundle.py');require(digest(prior)=='de9405751780da73901d9e1bdd59dd4dd250eb6b3866d7ac577679ad3f6731fd','R2 source mismatch')
    report=read(r2/'AUTHOR.md');require(digest(report)=='251116ed123986d90877f829857bd38e014c327081e42c5659a37f2bfeefbec9','inherited report mismatch')
    f2=read(r2/'FROZEN-FILES.json');require(digest(f2)=='dca823ba4ffd252ef89b549cf931c660b7ed13c59871c427f0c05316b3e869a2','R2 freeze mismatch')
    expected_diff=''.join(difflib.unified_diff(prior.decode().splitlines(True),source.decode().splitlines(True),fromfile='retained-source-bundle-verify-author-r2/verify_bundle.py',tofile='retained-source-bundle-verify-author-r2b/verify_bundle.py')).encode()
    # Independently reconstruct hunks; author header labels are presentation only.
    author_diff=bodies['R2-TO-R2B.diff'].decode().splitlines(True)
    require(expected_diff.decode().splitlines(True)[2:]==author_diff[2:],'lossless R2b diff hunk mismatch')
    tree=ast.parse(source);oldtree=ast.parse(prior)
    def functions(t):return {n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    now,old=functions(tree),functions(oldtree)
    unchanged=[n for n in old if old[n]==now[n]];require(set(now)==set(old) and set(old)-set(unchanged)=={'main'},'unexpected helper mechanism changes')
    advices=[n.lineno for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='os' and n.func.attr=='posix_fadvise']
    require(len(advices)==2,'two closed advice sites expected')
    pinraw=read('/workspace/scratch/retained-source-bundle-verify-author-r1/PIN.json');require(digest(pinraw)=='ed8614dd640545f608783742986028e38b633beb83fb1a5ceea4ce3773eb42db','pin mismatch');pin=json.loads(pinraw)
    failure=read('/workspace/scratch/retained-source-bundle-verify-run-r1/FAILURE-SLOT.json');require(digest(failure)=='55ffeafffc6fc2b7c2ec77cbb506d2543ca7a608d04b5f72646951e26b9f0edc','failure mismatch');f=json.loads(failure)
    controls=read('/workspace/scratch/retained-source-bundle-verify-run-r1/CONTROLS.json');require(digest(controls)=='b795c17e4a936db149bd63ba3f0e456eaddb72bc0f901adfe371b3af8a801b98','controls mismatch');c=json.loads(controls)
    failure_review=read('/workspace/scratch/retained-source-bundle-verify-failure-independent-r1/REVIEW.md');require(digest(failure_review)=='4a392e097f3ddfee67452a0422ddc7a37da9f5be84b4cbb167a0396b26bc90d0','independent failure review mismatch')
    require(f['bytesRead']==f['advisedPageBytes']==327417856 and f['readCalls']==f['returnedAdviceCalls']==1249 and f['pendingAdvice'] is None and f['allOwnTargetFDsClosed'] is True and f['error']=='64MiB work +512MiB reserve refused','prefix evidence')
    require(c['sourceSHA256']=='50a2040ca19c27cfff135514eeba75a017766e5cf01bbc2e602b9cd080a9fce5' and c['pinSHA256']==digest(pinraw),'original source/pin bindings')
    post=f['postFailureTarget'];require(post['metadata']==post['pathMetadata']==post['descriptorStatAfter']==pin['metadata'] and post['xattrs']==pin['xattrs'],'prior failure metadata')
    target=Path(pin['target']);fds=[];rows=[];fd=None
    try:
        flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC;fds.append(os.open('/',flags))
        for name in str(target.parent).split('/')[1:]:
            if not name:continue
            parent=fds[-1];d=os.open(name,flags,dir_fd=parent);fds.append(d);s=os.fstat(d)
            ident={'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid};rows.append(ident)
            require(s==os.stat(name,dir_fd=parent,follow_symlinks=False),'parent identity')
        require(rows==pin['parents'],'fresh pinned parent chain')
        fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=fds[-1]);before=meta(os.fstat(fd));require(before==pin['metadata'],'fresh target metadata')
        attrs={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)};require(attrs==pin['xattrs'],'fresh target xattrs')
        after=meta(os.fstat(fd));require(before==after==meta(os.stat(target.name,dir_fd=fds[-1],follow_symlinks=False)),'metadata-only observation drift')
    finally:
        if fd is not None:os.close(fd)
        for d in reversed(fds):os.close(d)
    hpage=Path('/sys/kernel/mm/transparent_hugepage/hpage_pmd_size').read_bytes();require(len(hpage)<=32 and int(hpage)==2097152,'actual PMD unit')
    consumed=327417856;size=1711151088;unit=2097152;chunk=262144;recovery=consumed//unit*unit;aligned=size//unit*unit
    require(recovery==327155712 and recovery//unit==156 and consumed-recovery==262144 and size-aligned==1972208,'range arithmetic')
    # Re-read every bounded frozen/control input with O_NOATIME. No bundle body.
    snapshot=dict(inputs)
    for path,row in snapshot.items():
        b=read(path);require(inputs[path]==row,'before/after input hash/metadata drift')
    final=own_memory()
    result={'decision':'SCOPED SOURCE ACCEPT; actual execution and whole-body result not granted by this audit','candidateSourceSHA256':digest(source),'frozenSHA256':digest(frozen),'sourceParsedNotImported':True,'authorRuntimeCalls':0,'bundleBodyBytesRead':0,'cacheAdviceCalls':0,'GitCalls':0,'targetFDClosed':True,'targetBefore':before,'targetAfter':after,'targetXattrs':attrs,'parents':rows,'unchangedR2Helpers':unchanged,'adviceCallsiteLines':advices,'prefixRecovery':{'offset':0,'length':recovery,'fullyPriorConsumed2MiBUnits':156,'priorConsumedBytes':consumed,'priorRemainderUntouchedBytes':consumed-recovery},'freshWholeBody':{'expectedBytes':size,'maxDataReadCalls':(size+chunk-1)//chunk,'finalEOFCalls':1,'full2MiBUnits':size//unit,'advisedPrefixBytes':aligned,'unadvisedTailBytes':size-aligned,'maxCheckpointRows':(size+8388608-1)//8388608},'bodyRequiredWorkAndReserveBytes':576*1024**2,'tinyRequiredWorkAndReserveBytes':88*1024**2,'actualKernelPMDBytes':int(hpage),'memoryBefore':initial,'memoryAfter':final,'inputCount':len(snapshot),'inputsBeforeAfterEqual':True,'inputs':snapshot}
    with open(OUT/'STATIC-RESULT.json','x')as stream:json.dump(result,stream,sort_keys=True,indent=2);stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['inputs','parents','targetBefore','targetAfter','targetXattrs','unchangedR2Helpers']}))
except BaseException as e:
    with open(OUT/'AUDIT-FAILURE.json','x')as stream:json.dump({'error':str(e),'type':type(e).__name__,'inputs':inputs},stream,sort_keys=True,indent=2);stream.write('\n')
    raise
