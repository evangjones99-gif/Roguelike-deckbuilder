"""Independent actual preparation audit; no bundle body, advice, Git or unlink."""
import hashlib,json,os,re,stat,zlib
from pathlib import Path
OUT=Path('/workspace/scratch/b065-bundle-prepared-independent-r2');rows={}
def need(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(s):return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}
def read(p,limit=65536):
    p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        s=os.fstat(fd);need(stat.S_ISREG(s.st_mode)and s.st_size<=limit,'bounded regular input');b=os.read(fd,limit+1)
        need(len(b)==s.st_size and os.read(fd,1)==b'','whole small control');need(meta(s)==meta(os.fstat(fd))==meta(os.stat(p,follow_symlinks=False)),'control metadata')
        rows[str(p)]={'bytes':len(b),'sha256':sha(b),'metadata':meta(s)};return b
    finally:os.close(fd)
def j(p):return json.loads(read(p))
def memory():
    b=Path('/proc/self/status').read_bytes();need(len(b)<=8192,'status bounds');v={}
    for l in b.decode().splitlines():
        if l.startswith(('VmHWM:','VmRSS:')):k,n,u=l.split();need(u=='kB','unit');v[k[:-1]]=int(n)*1024
    c=int(Path('/sys/fs/cgroup/memory.current').read_text());m=int(Path('/sys/fs/cgroup/memory.max').read_text());need(max(v.values())<=32*1024**2 and m-c>=96*1024**2,'own32+64 small-proof admission')
    return {**v,'headroomBytes':m-c}
def unzip(b,maxraw):
    d=zlib.decompressobj(31);raw=d.decompress(b,maxraw+1);need(len(raw)<=maxraw and d.eof and not d.unconsumed_tail and not d.unused_data,'closed bounded single gzip');return raw
def observation(p):
    p=Path(p);fds=[];fd=None;parents=[]
    try:
        flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC;fds.append(os.open('/',flags))
        for name in str(p.parent).split('/')[1:]:
            d=os.open(name,flags,dir_fd=fds[-1]);fds.append(d);s=os.fstat(d);need(s==os.stat(name,dir_fd=fds[-2],follow_symlinks=False),'parent drift');parents.append({'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid})
        fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=fds[-1]);s=os.fstat(fd);attrs={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)}
        need(meta(s)==meta(os.fstat(fd))==meta(os.stat(p.name,dir_fd=fds[-1],follow_symlinks=False)),'target observation drift')
        mapping=[('dev','st_dev'),('ino','st_ino'),('mode','st_mode'),('uid','st_uid'),('gid','st_gid'),('nlink','st_nlink'),('bytes','st_size'),('blocks','st_blocks'),('mtimeNS','st_mtime_ns'),('ctimeNS','st_ctime_ns'),('atimeNS','st_atime_ns')]
        return {'metadata':{a:getattr(s,b) for a,b in mapping},'xattrs':attrs},parents
    finally:
        if fd is not None:os.close(fd)
        for d in reversed(fds):os.close(d)
try:
    initial=memory();run=Path('/workspace/scratch/b065-bundle-preparation-run-r2');wrap=Path('/workspace/scratch/b065-bundle-preparation-ROOT-wrapper-r2')
    need({p.name for p in run.iterdir()}=={'PREPARED.json','FAILURE-SLOT.json'},'exact prepare files');need({p.name for p in wrap.iterdir()}=={'RESULT.json','stdout.txt','stderr.txt'},'exact wrapper files')
    raw=read(run/'PREPARED.json');prepared=json.loads(raw);failure=j(run/'FAILURE-SLOT.json');wrapper=j(wrap/'RESULT.json');stdout=j(wrap/'stdout.txt');stderr=read(wrap/'stderr.txt');decl=j('/workspace/scratch/b065-bundle-preparation-ROOT-DECLARATION-r2.json');accept=j('/workspace/scratch/retained-source-bundle-verify-success-independent-r2b/PREPARATION-ACCEPTANCE.json')
    need(wrapper=={'exitCode':0,'preparedReceiptExists':True,'originalOldExists':True} and stdout=={'prepared':True,'retired':False,'output':str(run)} and stderr==b'','actual successful default-only prepare')
    need('error'not in failure,'failure slot unchanged')
    need(sha(read('/workspace/scratch/b065-research-bundle-retirement-author-r2/retire_b065_bundle.py'))==prepared['sourceSHA256']==accept['sourceSHA256']==decl['sourceSHA256']=='96e0464807309ba79f9f99eaf3f30be7768a4b5a3bc6db2d85f7f79125affec1','actual approved source')
    need(sha(read(accept['reviewPath']))==accept['reviewSHA256']=='5e2d605803175a52a5abd9b6fc412b277de3de3ada3c0ce1d20d0361066ed37f','exact source review')
    successor_raw=read('/workspace/scratch/retained-source-bundle-verify-run-r2/SUCCESSOR-VERIFICATION.json');successor=json.loads(successor_raw)
    need(sha(successor_raw)==prepared['successorVerificationSHA256']==accept['successorVerificationSHA256']==decl['successorVerificationSHA256']=='3fbb210cd40c9b74d3c8432e24c7425c701ece4470977d516e8c4c1a6eef0359','actual successor binding')
    need(sha(read(decl['successorActualBodyReviewPath']))==decl['successorActualBodyReviewSHA256']==prepared['actualSuccessorBodyReviewSHA256']=='55f009744a554b3b3bec7974690ff69e9ca94caadee5972870b2d674dd02c19a','distinct actual successor review')
    oldzip=read('/workspace/scratch/release-bundle-fullsize-independent-v07-r2/full-restore-proof.json.gz',512*1024);need(sha(oldzip)=='c963bb9709e584b18c4b6be67e4eda42e4eddf9d47a71aabde8096c3854cea71','old proof compressed SHA')
    oldraw=unzip(oldzip,2*1024**2);need(len(oldraw)==1597701 and sha(oldraw)=='ff65e50b40c55f52e095b2ff29dc83b6c8aa98d9227ff85373b48fd7c50cb337','old full proof raw SHA');old=json.loads(oldraw)
    need(old['selfContained'] is True and old['fsckOutput']=='' and old['reachableObjectCount']==3586 and old['sourceCommit']=='b065d1044c9486b616f2eb2e95021de18c349ab7' and old['identity']['tree']=='aaed2c69d8543f020a863afc3b969cee3148d339' and len(old['identity']['files'])==5904,'historical full actual old restore')
    oldset=set()
    for row in old['objectInventory']:
        f=row.split();need(len(f)==3 and re.fullmatch('[0-9a-f]{40}',f[0]) and f[1]in['blob','tree','commit','tag'] and f[2].isdigit(),'old object inventory');oldset.add(f[0])
    newzip=read('/workspace/scratch/release-v08-final-independent-r1/REACHABLE-OBJECTS.json.gz',128*1024);need(sha(newzip)=='174494893e3e1e605fe9a965bfb117d3cf0c971703d8db3d4080b0b8daa3aac0','new compressed proof')
    newraw=unzip(newzip,256*1024);need(len(newraw)==173963 and sha(newraw)=='22229fe4fe1b74f618ecb7f81f2d5158765e6ad01ac337ce2c568ced41f89703','new raw proof');newlines=newraw.decode().splitlines();newset=set(newlines)
    need(len(oldset)==3586 and len(newset)==len(newlines)==4243 and all(re.fullmatch('[0-9a-f]{40}',v) for v in newset) and not oldset-newset,'all3586 subset4243')
    coverage={'oldCount':3586,'newCount':4243,'missing':0,'oldOIDsSHA256':sha(('\n'.join(sorted(oldset))+'\n').encode()),'oldRefs':old['refs'],'oldCommit':old['sourceCommit'],'oldTree':old['identity']['tree'],'scope':'Fresh small-ledger OID subset only, no new object type/raw-SHA or Git restore execution'}
    need(coverage==prepared['coverage'] and coverage['oldOIDsSHA256']=='aafbaef598420ad1e21075980ec63f73fce95d3a577a242258ab9d5e535fd3f4','independent exact coverage agrees')
    restoraw=read('/workspace/scratch/release-v08-final-independent-r1/RESTORE-RESULT.json');need(sha(restoraw)==decl['priorRestoreReceiptSHA256']=='a334dbc8828bf29b4fff892ea176db4f62a4f01d09298f34784cb930c4d83f2f','new actual restore receipt');restore=json.loads(restoraw)
    need(restore['PASS'] is True and restore['sourceCommit']=='58efb01f4815d8b542711582b87f50168dabde81' and restore['reachableObjects']==4243 and restore['exactSourceReachableClosureAndNoExtras'] is True and restore['noPrerequisites'] is True and restore['noAlternates'] is True and restore['fsckFullStrict'] is True,'actual preferred restore/full closure')
    need(prepared['schema']==2 and prepared['kind']=='b065-bundle-actual-preparation' and prepared['freshOldSHA256']==decl['oldSHA256']=='04c31e64dab1b8503746b452717f6cea7a806135ec07c0fa4bcd03d65ab7561c' and prepared['oldBytes']==1526523777 and prepared['readCalls']==1456 and prepared['oldAllOwnContentFDsClosed'] is True and prepared['originalOldEncodingRetainedUntilExplicitRetire'] is True,'fresh old full stream and closure')
    need(prepared['oldAllocatedPotential']==1526525952 and prepared['actualRAMRecoveryClaim'] is False and prepared['independentlyAcceptedPreparation'] is None,'no premature retirement or reclaim claim')
    freshold,oldparents=observation(prepared['oldPath']);freshnew,newparents=observation(prepared['preferredSuccessorPath']);need(freshold==prepared['oldMetadata'] and freshold['metadata']['nlink']==1 and freshold['xattrs']=={} and freshnew==successor['after'] and newparents==successor['parentChainAfter'],'both currently retained metadata exact')
    need(oldparents[-1]=={'name':'hollowpact-v07-bundle-preflight-y4st1n0p','device':33,'inode':1887587,'mode':16832,'uid':1000,'gid':1000},'old parent identity')
    snapshot=dict(rows)
    for p,v in snapshot.items():read(p,512*1024);need(rows[p]==v,'all original full readbacks exact')
    final=memory()
    evidence={'decision':'ACCEPT actual preparation and prefer verified sealed0.8 successor; conditional one fixed-file retire approval','preparedPath':str(run/'PREPARED.json'),'preparedSHA256':sha(raw),'successorVerificationSHA256':sha(successor_raw),'oldWholeSHAReportedFreshlyStreamed':prepared['freshOldSHA256'],'oldReadCalls':1456,'independentCoverage':coverage,'oldAndNewMetadataFreshExact':True,'originalOldCurrentlyPresent':True,'oldDistinctEncodingWouldBeLost':True,'uniqueOldGitObjectsMissingFromRetainedSuccessor':0,'allocatedOldTmpPotentialBytes':1526525952,'actualReclaimClaim':False,'reviewerBundleBodyReads':0,'reviewerAdviceCalls':0,'reviewerGitCalls':0,'reviewerUnlinks':0,'allOwnTargetFDsClosed':True,'originalCount':len(snapshot),'allOriginalsBeforeAfterEqual':True,'originals':snapshot,'memoryBefore':initial,'memoryAfter':final}
    with open(OUT/'RESULT.json','x')as f:json.dump(evidence,f,sort_keys=True,separators=(',',':'));f.write('\n')
    print(json.dumps({k:v for k,v in evidence.items()if k!='originals'}))
except BaseException as e:
    with open(OUT/'AUDIT-FAILURE.json','x')as f:json.dump({'error':str(e),'type':type(e).__name__,'originals':rows},f,sort_keys=True,separators=(',',':'));f.write('\n')
    raise
