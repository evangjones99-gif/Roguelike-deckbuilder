"""AUTHOR ONLY. Root-only one-file reviewed retirement, not an execution grant.

Default mode is fresh PREPARED only. --retire additionally requires independent
actual-successor/body/source acceptance and genuine explicit owner coordination.
No Git, archive restore/extraction, arbitrary paths, cache hints or recursive
deletion. Original logs/proofs/harnesses/sealed archives stay untouched.
"""
import argparse,gzip,hashlib,json,os,re,stat,sys,time,zlib
from contextlib import contextmanager
from pathlib import Path

OLD='/tmp/hollowpact-v07-bundle-preflight-y4st1n0p/source.bundle'
OLD_SHA='04c31e64dab1b8503746b452717f6cea7a806135ec07c0fa4bcd03d65ab7561c'
OLD_SIZE=1526523777
NEW='/workspace/Roguelike-deckbuilder/releases/0.8.0/hollowpact-0.8.0-source.bundle'
NEW_SHA='fd1310a36be0931bb81537004f87ef751481ca0daa349e58f1576a3c34640b3d'
NEW_SIZE=1711151088
OLD_PROOF='/workspace/scratch/release-bundle-fullsize-independent-v07-r2/full-restore-proof.json.gz'
OLD_PROOF_SHA='c963bb9709e584b18c4b6be67e4eda42e4eddf9d47a71aabde8096c3854cea71'
OLD_RAW_SHA='ff65e50b40c55f52e095b2ff29dc83b6c8aa98d9227ff85373b48fd7c50cb337'
NEW_CLOSURE='/workspace/scratch/release-v08-final-independent-r1/REACHABLE-OBJECTS.json.gz'
NEW_CLOSURE_SHA='174494893e3e1e605fe9a965bfb117d3cf0c971703d8db3d4080b0b8daa3aac0'
NEW_RAW_SHA='22229fe4fe1b74f618ecb7f81f2d5158765e6ad01ac337ce2c568ced41f89703'
OLD_COMMIT='b065d1044c9486b616f2eb2e95021de18c349ab7'
OLD_TREE='aaed2c69d8543f020a863afc3b969cee3148d339'
NEW_COMMIT='58efb01f4815d8b542711582b87f50168dabde81'
NEW_RESTORE_SHA='a334dbc8828bf29b4fff892ea176db4f62a4f01d09298f34784cb930c4d83f2f'
OLD_EXPECTED={'dev':33,'ino':1887588,'mode':33152,'uid':1000,'gid':1000,'nlink':1,
 'bytes':1526523777,'blocks':2981496,'mtimeNS':1790816499457236931,
 'ctimeNS':1790816499481236524,'atimeNS':1790816799172333656}
PARENT_ID={'dev':33,'ino':1887587,'mode':16832,'uid':1000,'gid':1000}
OUTPUT='/workspace/scratch/b065-bundle-retirement-run-r1'
MIB=1024**2
LIMIT=32*1024

def require(ok,message):
    if not ok:raise RuntimeError(message)

def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(value):return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()

def meta(s):
    return {k:getattr(s,v) for k,v in [('dev','st_dev'),('ino','st_ino'),('mode','st_mode'),
      ('uid','st_uid'),('gid','st_gid'),('nlink','st_nlink'),('bytes','st_size'),('blocks','st_blocks'),
      ('mtimeNS','st_mtime_ns'),('ctimeNS','st_ctime_ns'),('atimeNS','st_atime_ns')]}

def xattrs(fd):return {n:os.getxattr(fd,n).hex() for n in sorted(os.listxattr(fd))}

def guard():
    maximum=Path('/sys/fs/cgroup/memory.max').read_text().strip()
    current=int(Path('/sys/fs/cgroup/memory.current').read_text())
    require(maximum!='max' and int(maximum)-current>=640*MIB,'128MiB work +512MiB reserve refused')
    return int(maximum)-current

def measured():
    return {n:Path('/sys/fs/cgroup/'+n).read_text() for n in ['memory.current','memory.max','memory.stat','memory.events']}

@contextmanager
def anchored(path):
    p=Path(path);require(p.is_absolute() and '..' not in p.parts,'Literal absolute path required')
    fds=[];chain=[]
    try:
        fds.append(os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC))
        for n in p.parent.parts[1:]:
            parent=fds[-1];fd=os.open(n,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
            fds.append(fd);a=meta(os.fstat(fd));b=meta(os.stat(n,dir_fd=parent,follow_symlinks=False))
            keys=['dev','ino','mode','uid','gid'];identity={k:a[k] for k in keys}
            require(identity=={k:b[k] for k in keys},'Ancestor redirection')
            require(a['uid'] in [0,os.getuid()] and (not a['mode'] & stat.S_IWOTH or a['mode'] & stat.S_ISVTX),'Unsafe ancestor')
            chain.append((parent,n,fd,identity))
        def stable():
            for parent,n,fd,identity in chain:
                a=meta(os.fstat(fd));b=meta(os.stat(n,dir_fd=parent,follow_symlinks=False))
                require({k:a[k] for k in identity}==identity=={k:b[k] for k in identity},'Ancestor drift')
        stable();yield fds[-1],p.name,stable;stable()
    finally:
        for fd in reversed(fds):os.close(fd)

def syncdir(fd):
    view=os.open('.',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC,dir_fd=fd)
    try:os.fsync(view)
    finally:os.close(view)

@contextmanager
def reading(path):
    with anchored(path) as (parent,name,stable):
        fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=parent)
        try:
            a=meta(os.fstat(fd));b=meta(os.stat(name,dir_fd=parent,follow_symlinks=False))
            require(stat.S_ISREG(a['mode']) and a==b,'Regular FD/path identity refused')
            row={'metadata':a,'xattrs':xattrs(fd)}
            yield fd,row
            stable();after={'metadata':meta(os.fstat(fd)),'xattrs':xattrs(fd)}
            require(after==row and meta(os.stat(name,dir_fd=parent,follow_symlinks=False))==a,'Read metadata/xattr/atime drift')
        finally:os.close(fd)

def small(path,limit):
    with reading(path) as (fd,row):
        require(row['metadata']['bytes']<=limit,'Control cap exceeded')
        result=bytearray()
        while b:=os.read(fd,min(MIB,limit+1-len(result))):
            result.extend(b);require(len(result)<=limit,'Control growth')
        return bytes(result)

def pin(path,expected,limit):
    b=small(path,limit);require(sha(b)==expected,'Control SHA mismatch: '+path);return b

def gunzip(b,limit):
    d=zlib.decompressobj(16+zlib.MAX_WBITS);raw=d.decompress(b,limit+1)
    require(len(raw)<=limit and d.eof and not d.unused_data and not d.unconsumed_tail,'Bounded gzip refused')
    return raw

def closure():
    a=gunzip(pin(OLD_PROOF,OLD_PROOF_SHA,512*1024),2*MIB)
    require(len(a)==1597701 and sha(a)==OLD_RAW_SHA,'Old raw proof pin')
    old=json.loads(a)
    require(old['selfContained'] is True and old['fsckOutput']=='' and old['reachableObjectCount']==3586,
            'Old actual restoration scope mismatch')
    require(old['sourceCommit']==OLD_COMMIT and old['identity']['tree']==OLD_TREE and len(old['identity']['files'])==5904,'Old identity mismatch')
    old_set=set()
    for row in old['objectInventory']:
        fields=row.split();require(len(fields)==3 and re.fullmatch('[0-9a-f]{40}',fields[0]) and
          fields[1] in ['blob','tree','commit','tag'] and fields[2].isdigit(),'Old object row malformed')
        old_set.add(fields[0])
    b=gunzip(pin(NEW_CLOSURE,NEW_CLOSURE_SHA,128*1024),256*1024)
    require(len(b)==173963 and sha(b)==NEW_RAW_SHA,'New raw OID inventory pin')
    new_rows=b.decode().splitlines();new_set=set(new_rows)
    require(len(old_set)==3586 and len(new_set)==4243 and len(new_rows)==4243 and
      all(re.fullmatch('[0-9a-f]{40}',x) for x in new_set),'Exact closure population refused')
    require(not old_set-new_set and OLD_COMMIT in new_set and OLD_TREE in new_set,'Older closure not preserved')
    old_digest=sha(('\n'.join(sorted(old_set))+'\n').encode())
    require(old_digest=='aafbaef598420ad1e21075980ec63f73fce95d3a577a242258ab9d5e535fd3f4','Old closure digest')
    return {'oldCount':3586,'newCount':4243,'missing':0,'oldOIDsSHA256':old_digest,
      'oldRefs':old['refs'],'oldCommit':OLD_COMMIT,'oldTree':OLD_TREE,
      'scope':'Fresh small-ledger OID subset only, no new object type/raw-SHA or Git restore execution'}

def consumers_closed(target):
    """Bounded accessible FD+map observation, not atomic/global absence proof."""
    pids=sorted(int(x) for x in os.listdir('/proc') if x.isdecimal())
    require(len(pids)<=8192,'Process probe bound')
    fds=0;maps=0
    device=(os.major(target['dev']),os.minor(target['dev']))
    for i,pid in enumerate(pids):
        if i%64==0:guard()
        base='/proc/'+str(pid)
        try:
            text=Path(base+'/stat').read_text();fields=text.rsplit(')',1)[1].split()
            require(len(fields)>=20,'Unknown process identity')
            if fields[0] in ['Z','X']:continue
            for n in os.listdir(base+'/fd'):
                try:s=os.stat(base+'/fd/'+n)
                except FileNotFoundError:continue
                fds+=1;require(fds<=16384,'FD probe bound')
                require((s.st_dev,s.st_ino)!=(target['dev'],target['ino']),'Affected live FD owner')
            with open(base+'/maps','rb') as f:body=f.read(512*1024+1)
            require(len(body)<=512*1024,'Mapping probe bound')
            for line in body.splitlines():
                fields=line.split(None,5);require(len(fields)>=5,'Unknown mapping row')
                major,minor=(int(x,16) for x in fields[3].split(b':'))
                inode=int(fields[4]);maps+=1
                require(not ((major,minor)==device and inode==target['ino']),'Affected live mapping owner')
        except FileNotFoundError:
            require(not os.path.exists(base),'Unknown live process race')
    return {'accessibleFDsObserved':fds,'mappingRowsObserved':maps,
      'scope':'Bounded accessible observation; coordination still essential; unknown/inaccessible ownership refuses'}

class Receipts:
    def __init__(self):
        self.used=0
        with anchored(OUTPUT) as (p,n,_):
            v=os.statvfs('/workspace');require(v.f_bavail*v.f_frsize>=8*MIB+LIMIT,'8MiB free reserve +32KiB receipt allowance refused')
            os.mkdir(n,0o700,dir_fd=p);syncdir(p)
        self.write('FAILURE-SLOT.json',b'{"status":"reserved; no failure"}\n'.ljust(8192,b' '))
    def write(self,name,b):
        require(name in ['FAILURE-SLOT.json','PREPARED.json','ARMED.json','RETIRED.json'],'Unknown receipt member')
        require(self.used+len(b)<=LIMIT,'Receipt budget refused')
        with anchored(OUTPUT+'/'+name) as (p,n,_):
            fd=os.open(n,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=p)
            try:
                v=memoryview(b)
                while v:
                    c=os.write(fd,v);require(c>0,'Short receipt write');v=v[c:]
                os.fsync(fd);syncdir(p);self.used+=len(b)
            finally:os.close(fd)
    def failure(self,value):
        b=encoded(value);require(len(b)<=8192,'Failure slot cap')
        with anchored(OUTPUT+'/FAILURE-SLOT.json') as (p,n,_):
            fd=os.open(n,os.O_WRONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=p)
            try:
                s=os.fstat(fd);require(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size==8192,'Unsafe failure slot')
                b=b.ljust(8192,b' ');pos=0
                while pos<len(b):
                    c=os.pwrite(fd,b[pos:],pos);require(c>0,'Short failure write');pos+=c
                os.fsync(fd);syncdir(p)
            finally:os.close(fd)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--declaration',required=True)
    ap.add_argument('--acceptance',required=True)
    ap.add_argument('--successor-verification',required=True)
    ap.add_argument('--retire',action='store_true')
    args=ap.parse_args();r=None;unlinked=False
    try:
        guard()
        source_sha=sha(small(str(Path(__file__).absolute()),32*1024))
        db=small(args.declaration,16*1024);d=json.loads(db)
        a=json.loads(small(args.acceptance,16*1024))
        rb=small(args.successor_verification,32*1024);v=json.loads(rb)
        require(a['sourceSHA256']==source_sha and a.get('allowSingleB065RetirementAttemptOnly') is True and
          a['successorVerificationSHA256']==sha(rb),'Independent exact source +actual successor acceptance missing')
        require(sha(small(a['reviewPath'],64*1024))==a['reviewSHA256'],'Independent review changed')
        require(d['sourceSHA256']==source_sha and d['oldPath']==OLD and d['oldSHA256']==OLD_SHA and
          d['successorVerificationSHA256']==sha(rb),'Root declaration identity mismatch')
        for k in ['ownerReviewedRetirementAuthorized','candidateReadersWritersMappingsClosed','noUnknownCandidateAliasesOrLocks',
                  'preferredSuccessorAndActualBodyIndependentlyAccepted','allProofLogsFailuresHarnessesPreserved']:
            require(d.get(k) is True,'Genuine root declaration required: '+k)
        if args.retire:require(d.get('retireThisOneFile') is True,'This one-file action not declared')
        require(v['schema']==1 and v['kind']=='retained-source-bundle-whole-verification' and
          v['targetPath']==NEW and v['bytesRead']==NEW_SIZE and v['expectedBytes']==NEW_SIZE and
          v['expectedSHA256']==NEW_SHA and v['freshlyStreamedSHA256']==NEW_SHA and
          v['wholeHashMatches'] is True and v['allTargetFDsClosed'] is True,'Fresh actual successor body proof mismatch')
        require(v['before']==v['after'],'Successor metadata drift in producer')
        require(d['successorActualBodyReviewPath']!=a['reviewPath'] and
          sha(small(d['successorActualBodyReviewPath'],64*1024))==d['successorActualBodyReviewSHA256'],
          'Distinct actual successor-body review missing')
        restore=json.loads(pin('/workspace/scratch/release-v08-final-independent-r1/RESTORE-RESULT.json',
          NEW_RESTORE_SHA,16*1024))
        require(d['priorRestoreReceiptSHA256']==NEW_RESTORE_SHA,'Prior restore declared pin mismatch')
        require(restore['PASS'] is True and restore['sourceCommit']==NEW_COMMIT and restore['noPrerequisites'] is True and
          restore['noAlternates'] is True and restore['fsckFullStrict'] is True and
          restore['reachableObjects']==4243 and restore['exactSourceReachableClosureAndNoExtras'] is True,'Preferred self-contained restore gate mismatch')
        def quiet():
            guard();require(small(args.declaration,16*1024)==db,'Root declaration changed')
            require(-5<=time.time()-d['issuedUnixSeconds']<=900,'Candidate ownership window expired')
        def successor_still():
            with reading(NEW) as (_,row):
                require(row==v['after'] and row['metadata']['bytes']==NEW_SIZE,'Fresh successor current metadata no longer exact')
            require(small(args.successor_verification,32*1024)==rb,'Fresh successor receipt changed')
        quiet();successor_still();coverage=closure()
        with anchored(OLD) as (p,_,_):
            parent=meta(os.fstat(p));require({k:parent[k] for k in PARENT_ID}==PARENT_ID,'Exact old parent changed')
        with reading(OLD) as (_,row):
            require(row['metadata']==OLD_EXPECTED and not row['xattrs'],'Pinned old metadata/xattrs changed')
        ownership_before=consumers_closed(OLD_EXPECTED)
        r=Receipts();before=measured()
        with reading(OLD) as (fd,row):
            require(row['metadata']==OLD_EXPECTED and not row['xattrs'],'Old prestream metadata mismatch')
            h=hashlib.sha256();count=0;calls=0
            while part:=os.read(fd,MIB):
                quiet();h.update(part);count+=len(part);calls+=1
            require(count==OLD_SIZE and h.hexdigest()==OLD_SHA,'Fresh old body mismatch')
        # No old content FD remains when checking consumers or unlinking.
        quiet();successor_still();require(closure()==coverage,'Closure proof drift')
        ownership_after=consumers_closed(OLD_EXPECTED)
        prepared={'scope':'Only obsolete temporary b065 research bundle encoding, no sealed release','sourceSHA256':source_sha,
          'oldPath':OLD,'freshOldSHA256':OLD_SHA,'oldBytes':count,'readCalls':calls,'oldMetadata':row,
          'preferredSuccessorPath':NEW,'successorSHA256':NEW_SHA,'successorVerificationSHA256':sha(rb),
          'actualSuccessorBodyReviewSHA256':d['successorActualBodyReviewSHA256'],'coverage':coverage,
          'ownershipBefore':ownership_before,'ownershipAfter':ownership_after,'memoryBefore':before,
          'oldAllOwnContentFDsClosed':True,'oldAllocatedPotential':OLD_EXPECTED['blocks']*512,
          'actualRAMRecoveryClaim':False,'originalOldEncodingRetainedUntilExplicitRetire':True}
        r.write('PREPARED.json',encoded(prepared))
        if not args.retire:
            print(json.dumps({'prepared':True,'retired':False,'output':OUTPUT}));return
        quiet();successor_still();consumers_closed(OLD_EXPECTED)
        with anchored(OLD) as (p,name,stable):
            parent=meta(os.fstat(p));require({k:parent[k] for k in PARENT_ID}==PARENT_ID,'Final old parent identity drift')
            require(meta(os.stat(name,dir_fd=p,follow_symlinks=False))==OLD_EXPECTED,'Final old metadata/type/nlink drift')
            r.write('ARMED.json',encoded({'oldPath':OLD,'oldSHA256':OLD_SHA,'oldMetadata':row,'coverage':coverage,
              'scope':'One exact file only; ambiguous interrupted outcome must be investigated, never blind rerun'}))
            stable();quiet()
            require(meta(os.stat(name,dir_fd=p,follow_symlinks=False))==OLD_EXPECTED,'Old changed after journal fsync')
            os.unlink(name,dir_fd=p);unlinked=True;syncdir(p)
            try:os.stat(name,dir_fd=p,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise RuntimeError('Retired path still present')
        successor_still()
        samples=[]
        for i in range(3):
            if i:time.sleep(0.05)
            samples.append(measured())
        r.write('RETIRED.json',encoded({'retired':True,'oldPath':OLD,'oldSHA256':OLD_SHA,
          'oldEncodingSupersededNotByteDuplicate':True,'allOld3586ObjectIdentitiesPreserved':True,
          'successorPathUnchanged':NEW,'otherArtifactsTouched':False,'samples':samples,
          'scope':'Observed samples only, no guaranteed/causal RAM gain or later gate admission'}))
        print(json.dumps({'retired':True,'oneFile':OLD,'output':OUTPUT,'noGitRestoreOrHints':True}))
    except BaseException as e:
        if r:
            try:r.failure({'error':str(e)[:2000],'type':type(e).__name__,'unlinked':unlinked,
              'scope':'Stop; preserve all receipts; armed-without-return unknown; never blind retry/rollback'})
            except BaseException as second:print(json.dumps({'failureSlotError':str(second)[:500],'originalError':str(e)[:2000]}),file=sys.stderr)
        raise

if __name__=='__main__':main()
