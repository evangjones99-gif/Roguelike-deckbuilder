"""Actual-receipt audit only: no bundle content read, candidate imports or advice."""
import hashlib,json,os,stat
from pathlib import Path
OUT=Path('/workspace/scratch/retained-source-bundle-verify-success-independent-r2b')
RUN=Path('/workspace/scratch/retained-source-bundle-verify-run-r2')
WRAP=Path('/workspace/scratch/retained-source-bundle-verify-ROOT-wrapper-r2b')
rows={}
def need(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(s):return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_blocks','st_nlink','st_atime_ns','st_mtime_ns','st_ctime_ns']}
def read(path,limit=65536):
    p=Path(path);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        s=os.fstat(fd);need(stat.S_ISREG(s.st_mode) and s.st_size<=limit,'bounded regular receipt')
        b=os.read(fd,limit+1);need(len(b)==s.st_size and os.read(fd,1)==b'','complete bounded read')
        need(meta(s)==meta(os.fstat(fd))==meta(os.stat(p,follow_symlinks=False)),'receipt metadata drift')
        rows[str(p)]={'bytes':len(b),'sha256':sha(b),'metadata':meta(s)};return b
    finally:os.close(fd)
def j(p):return json.loads(read(p))
def memory():
    b=Path('/proc/self/status').read_bytes();need(len(b)<=8192,'status bound')
    fields={}
    for l in b.decode().splitlines():
        if l.startswith(('VmHWM:','VmRSS:')):k,n,u=l.split();need(u=='kB','unit');fields[k[:-1]]=int(n)*1024
    head=int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text())
    need(max(fields.values())<=24*1024**2 and head>=88*1024**2,'independent small audit resource gate');return {**fields,'headroomBytes':head}
try:
    initial=memory()
    need({p.name for p in RUN.iterdir()}=={'AFTER.json','ARMED.json','BEFORE.json','CHECKPOINTS.jsonl','CONTROLS.json','FAILURE-SLOT.json','RECOVERY-ARMED.json','RECOVERY-RETURNED.json','SUCCESSOR-VERIFICATION.json'},'exact nine-member receipt set')
    need({p.name for p in WRAP.iterdir()}=={'RESULT.json','stderr.txt','stdout.txt'},'exact wrapper set')
    before=j(RUN/'BEFORE.json');after=j(RUN/'AFTER.json');armed=j(RUN/'ARMED.json');controls=j(RUN/'CONTROLS.json');failure=j(RUN/'FAILURE-SLOT.json');recarm=j(RUN/'RECOVERY-ARMED.json');returned=j(RUN/'RECOVERY-RETURNED.json');result=j(RUN/'SUCCESSOR-VERIFICATION.json')
    checkpoints=[json.loads(l) for l in read(RUN/'CHECKPOINTS.jsonl').splitlines()];wrapper=j(WRAP/'RESULT.json');stderr=[json.loads(l) for l in read(WRAP/'stderr.txt').splitlines()];stdout=j(WRAP/'stdout.txt')
    need(wrapper=={'exitCode':0,'successorReceiptExists':True} and stdout['wholeHashMatches'] is True and stdout['summary']==result['summary'] and stdout['receipt']==str(RUN/'SUCCESSOR-VERIFICATION.json'),'actual rc0 success wrapper')
    need(failure=={'status':'reserved; no failure recorded'},'no recorded failure')
    decl=j('/workspace/scratch/retained-source-bundle-verify-ROOT-DECLARATION-r2b.json');accept=j('/workspace/scratch/retained-source-bundle-verify-source-independent-r2b/SOURCE-ACCEPTANCE.json')
    need(decl==controls['declaration'] and accept==controls['acceptance'],'actual controls bind originals')
    need(sha(read(accept['reviewPath']))==accept['reviewSHA256']=='b3d8fe39fff24fde229c89dab6e1900d213d5d6ea07164b921f8d8b91c692a54','exact source review')
    source=read('/workspace/scratch/retained-source-bundle-verify-author-r2b/verify_bundle.py');need(sha(source)==result['sourceSHA256']==controls['sourceSHA256']=='1757fd8153ce5d8094c0ab5d509c6387f22ae8388271072e41864a7d80d98a8e','actual exact source')
    need(sha(read('/workspace/scratch/b065-research-bundle-retirement-author-r2/retire_b065_bundle.py'))=='96e0464807309ba79f9f99eaf3f30be7768a4b5a3bc6db2d85f7f79125affec1','retirement source pin')
    need(sha(read('/workspace/scratch/b065-research-bundle-retirement-source-independent-r2/REVIEW.md'))=='5e2d605803175a52a5abd9b6fc412b277de3de3ada3c0ce1d20d0361066ed37f','retirement source gate')
    pinraw=read('/workspace/scratch/retained-source-bundle-verify-author-r1/PIN.json');pin=json.loads(pinraw);need(sha(pinraw)==result['pinSHA256']==controls['pinSHA256']=='ed8614dd640545f608783742986028e38b633beb83fb1a5ceea4ce3773eb42db','actual fixed pin')
    for p,s in [('/workspace/scratch/retained-source-bundle-verify-run-r1/FAILURE-SLOT.json',controls['r1FailureSHA256']),('/workspace/scratch/retained-source-bundle-verify-run-r1/CONTROLS.json',controls['r1ControlsSHA256']),('/workspace/scratch/retained-source-bundle-verify-failure-independent-r1/REVIEW.md',controls['r1FailureReviewSHA256'])]:need(sha(read(p))==s,'prior failure binding')
    need(result['wholeHashMatches'] is True and result['bytesRead']==result['expectedBytes']==1711151088 and result['expectedSHA256']==result['freshlyStreamedSHA256']=='fd1310a36be0931bb81537004f87ef751481ca0daa349e58f1576a3c34640b3d','full body result')
    need(recarm['range']=={'offset':0,'length':327155712,'r1ProvenConsumedBytes':327417856} and returned['offset']==0 and returned['length']==327155712 and returned['returnedCalls']==1 and returned['bodyBytesReadThisRun']==recarm['bodyBytesReadThisRun']==0,'exact recovery range and no recovery body reads')
    need(len(checkpoints)==204,'all204 checkpoint rows')
    for i,c in enumerate(checkpoints,1):
        end=min(i*8388608,1711151088);reads=(end+262143)//262144;units=end//2097152
        need(c['bytesRead']==end and c['readCalls']==reads and c['adviceCalls']==units and c['advisedPageBytes']==units*2097152 and c['headroomBytes']>=603979776 and c['ownVmHWMBytes']<=64*1024**2,'closed checkpoint counters and body guard')
        need(c['memoryEvents']=='low 0\nhigh 0\nmax 290744\noom 0\noom_kill 0\noom_group_kill 0\n','checkpoint events unchanged')
    summary=result['summary'];need(summary==after['summary'] and summary['readCalls']==6529 and summary['adviceCalls']==815 and summary['advisedPageBytes']==1709178880 and summary['unadvisedTailBytes']==1972208 and summary['sampleRows']==204 and summary['consumedPrefixRecoveryCalls']==1 and summary['coalescedAdviceUnitBytes']==2097152,'actual summary counters')
    need(summary['minimumObservedHeadroomBytes']==876650496 and summary['maximumObservedVmHWMBytes']==13271040,'actual min and peak')
    mapping=[('dev','st_dev'),('ino','st_ino'),('mode','st_mode'),('uid','st_uid'),('gid','st_gid'),('nlink','st_nlink'),('bytes','st_size'),('blocks','st_blocks'),('mtimeNS','st_mtime_ns'),('ctimeNS','st_ctime_ns'),('atimeNS','st_atime_ns')]
    expected={'metadata':{a:pin['metadata'][b] for a,b in mapping},'xattrs':pin['xattrs']}
    need(result['before']==result['after']==expected and result['parentChainBefore']==result['parentChainAfter']==pin['parents'] and result['allTargetFDsClosed'] is True and after['allOwnTargetFDsClosed'] is True,'successor exact metadata and closure')
    for observation in [before['target'],after['target']]:need(observation['metadata']==observation['pathMetadata']==observation['descriptorStatAfter']==pin['metadata'] and observation['xattrs']==pin['xattrs'],'raw observation exact')
    need(before['parentChain']==after['parentChain']==pin['parents'] and after['metadataExact'] is True,'raw parents exact')
    need(stderr[0]['phase']=='bootstrap-observation' and stderr[0]['headroomBytes']>=92274688,'bootstrap tiny guard')
    heavy=[v for v in stderr if v.get('phase')=='whole-body-admission'];need(len(heavy)==4 and all(v['requiredBytes']==603979776 and v['headroomBytes']>=603979776 for v in heavy),'post-recovery heavy plus3final admissions')
    need(len(after['samples'])==3 and all(v['headroomBytes']>=603979776 for v in after['samples']),'final samples')
    restore=read(result['priorRestoreReceipt']['path']);need(sha(restore)==result['priorRestoreReceipt']['sha256']=='a334dbc8828bf29b4fff892ea176db4f62a4f01d09298f34784cb930c4d83f2f','prior fullrestore reference')
    target=Path(result['targetPath']);fds=[];fd=None;parents=[]
    try:
        flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC;fds.append(os.open('/',flags))
        for name in str(target.parent).split('/')[1:]:
            d=os.open(name,flags,dir_fd=fds[-1]);fds.append(d);s=os.fstat(d);parents.append({'name':name,'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid})
        need(parents==pin['parents'],'fresh parents')
        fd=os.open(target.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=fds[-1]);fresh_before=meta(os.fstat(fd));attrs={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)};fresh_after=meta(os.fstat(fd))
        need(fresh_before==fresh_after==meta(os.stat(target.name,dir_fd=fds[-1],follow_symlinks=False))==pin['metadata'] and attrs==pin['xattrs'],'fresh metadata only')
    finally:
        if fd is not None:os.close(fd)
        for d in reversed(fds):os.close(d)
    snapshot=dict(rows)
    for p,v in snapshot.items():read(p);need(rows[p]==v,'all original readbacks exact')
    final=memory()
    evidence={'decision':'ACCEPT scoped actual complete producer receipt; not independent second body hash','successorReceiptSHA256':rows[str(RUN/'SUCCESSOR-VERIFICATION.json')]['sha256'],'allOriginalsBeforeAfterEqual':True,'checkpointRowsValidated':204,'summary':summary,'noFailureRecorded':True,'freshTargetMetadataExact':True,'freshTargetAtimePreserved':True,'freshTargetFDClosed':True,'bundleBodyBytesReadByReviewer':0,'adviceCallsByReviewer':0,'GitCalls':0,'originalCount':len(snapshot),'originals':snapshot,'auditMemoryBefore':initial,'auditMemoryAfter':final,'bodyAdmissionRows':len(heavy)}
    with open(OUT/'RESULT.json','x')as f:json.dump(evidence,f,sort_keys=True,separators=(',',':'));f.write('\n')
    print(json.dumps({k:v for k,v in evidence.items() if k!='originals'}))
except BaseException as e:
    with open(OUT/'AUDIT-FAILURE.json','x')as f:json.dump({'error':str(e),'type':type(e).__name__,'originals':rows},f,sort_keys=True,separators=(',',':'));f.write('\n')
    raise
