import pathlib,json,gzip,re
P=pathlib.Path('/workspace/scratch/event-availability-gameplay-independent-v09-r1');d=json.load(gzip.open(P/'failure.json.gz','rt'));rows=d['rows'];assert len(rows)==12;assert all('error'not in r and not r['errors'] for r in rows);shifts=[];disabled=[]
for i in range(0,len(rows),2):
 a,b=rows[i:i+2];assert a['spec']==b['spec'];assert a['expected']==b['expected'];assert a['allowed']==b['allowed'];assert a['title']==b['title'];assert a['reloaded']==b['reloaded'];assert a.get('relicDialog')==b.get('relicDialog');assert a['initial']['widths']==b['initial']['widths'];assert a['initial']['topbar']==b['initial']['topbar'];assert a['initial']['hud']==b['initial']['hud']
 for c in a['initial']['choices']:
  z=next(x for x in b['initial']['choices'] if x['id']==c['id']);assert c['disabled']==z['disabled'];assert [(n['part'],n['text'],n['style']['fontSize'],n['style']['lineHeight']) for n in c['nodes'] if n['part']!='SPAN']==[(n['part'],n['text'],n['style']['fontSize'],n['style']['lineHeight']) for n in z['nodes'] if n['part']!='SPAN'];
  if not c['disabled']:
   assert c['style']==z['style'];assert c['rect']['x']==z['rect']['x'];assert c['rect']['width']==z['rect']['width'];dy=z['rect']['y']-c['rect']['y'];dh=z['rect']['height']-c['rect']['height'];assert abs(dy)<=3;assert abs(dh)<=1
   if dy or dh:shifts.append(dict(case=a['spec']['id'],choice=c['id'],deltaY=dy,deltaHeight=dh,baseline=c['rect'],candidate=z['rect']))
  else:disabled.append(dict(case=b['spec']['id'],choice=z['id'],text=next(n['text'] for n in z['nodes'] if n['part']=='SPAN'),style=z['style'],reasonStyle=next(n['style'] for n in z['nodes'] if n['part']=='SPAN')))
 for r in [a,b]:
  assert all(not t['disabled'] and (not t['choice'] or t['choice'] in r['allowed']) for t in r['tabs']);assert all(x['syntheticStaleClickSaveUnchanged'] and not x['programmaticFocus'] for x in r['synthetic'])
 for z in b['initial']['choices']:
  for n in z['nodes']:
   assert n['scrollWidth']<=n['clientWidth']+1
   for g in n['glyphs']:assert g['left']>=z['rect']['left']-.5 and g['right']<=z['rect']['right']+.5 and g['top']>=z['rect']['top']-.5 and g['bottom']<=z['rect']['bottom']+.5

def luminance(color):
 vals=[int(x)/255 for x in re.findall(r'\d+',color)];return sum(w*(x/12.92 if x<=.04045 else((x+.055)/1.055)**2.4) for w,x in zip([.2126,.7152,.0722],vals))
reason=disabled[0];fg=luminance(reason['reasonStyle']['color']);bg=luminance(reason['style']['backgroundColor']);ratio=(max(fg,bg)+.05)/(min(fg,bg)+.05)
res=dict(verdict='scoped development acceptance after assessing preserved exact-geometry comparison failure',completedBrowserContexts=12,pairedCases=6,actualLegalChoices=12,actualReloads=12,productPageErrors=0,nativeTabFocusObservations=sum(len(r['tabs']) for r in rows),syntheticStaleDispatchRefusals=sum(len(r['synthetic']) for r in rows),candidateDisabledReasonObservations=len(disabled),candidateReasons=disabled,enabledGeometryShifts=shifts,largestEnabledVerticalShift=max(abs(x['deltaY'])for x in shifts),largestEnabledHeightChange=max(abs(x['deltaHeight'])for x in shifts),enabledHorizontalGeometryExact=True,enabledStylesExact=True,choiceNamesDescriptionsAndFontsExact=True,titleAndReloadedMapGeometryExact=True,completePairedCanonicalResultsExact=True,ownedRelicDossiers=sum('relicDialog'in r for r in rows),computedReasonOpaqueColorContrast=ratio,captures=len(list(P.glob('*.jpg'))),originalBrowserFinallyClosed=True)
(P/'ANALYSIS-r2.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k not in ['candidateReasons','enabledGeometryShifts']},indent=2))
