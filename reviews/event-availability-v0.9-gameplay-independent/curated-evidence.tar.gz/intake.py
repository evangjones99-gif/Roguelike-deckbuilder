import pathlib,json,hashlib,urllib.request,sys
O=pathlib.Path('/workspace/scratch/event-availability-gameplay-independent-v09-r1');configs=[('baseline',pathlib.Path('/tmp/hollowpact-fallback-cards-v09-root-r1'),4630,'201d90d522c4f170cfc54d22910e718603ff2a88393ac3151ecd4ea6faf6df18'),('candidate',pathlib.Path('/tmp/hollowpact-event-availability-v09-root-r2'),4632,'801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029')];rows=[]
for name,root,port,expected in configs:
 p=json.loads((root/'dist/build-provenance.json').read_bytes());assert p['sourceDigest']==expected
 hashes={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in p['hashes']};assert hashes==p['hashes'];assert len(hashes)==78
 assert hashlib.sha256(json.dumps(hashes,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==expected
 outputs=[]
 for f in sorted((root/'dist').rglob('*')):
  if not f.is_file():continue
  raw=f.read_bytes();rel=f.relative_to(root/'dist').as_posix();body=urllib.request.urlopen(f'http://127.0.0.1:{port}/{rel}',timeout=10).read();assert raw==body;outputs.append(dict(path=rel,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 assert len(outputs)==56;rows.append(dict(name=name,root=str(root),port=port,provenance=p,inputs=hashes,outputs=outputs))
changed=[f for f,h in rows[0]['inputs'].items() if rows[1]['inputs'].get(f)!=h];assert changed==['src/main.ts','src/style.css'];assert set(rows[0]['inputs'])==set(rows[1]['inputs'])
a=pathlib.Path('/workspace/Roguelike-deckbuilder/reviews/root-v0.9-event-availability-author');raw=(a/'FROZEN-FILES.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='33acd7f0e4d79ed20e4c5a0f2f95892254aeb77016fed8f1b48976bc49788c95';m=json.loads(raw)
for path,v in m['files'].items():
 raw=(a/path).read_bytes();assert len(raw)==v['bytes'];assert hashlib.sha256(raw).hexdigest()==v['sha256']
assert len(m['files'])==74
(O/(sys.argv[1]+'.json')).write_text(json.dumps(dict(rows=rows,changed=changed,added=[],authorManifestSHA='33acd7f0e4d79ed20e4c5a0f2f95892254aeb77016fed8f1b48976bc49788c95',authorFiles=len(m['files'])),indent=2)+'\n');print('156 source inputs,112 local/HTTP outputs,74 author frozen files verified')
