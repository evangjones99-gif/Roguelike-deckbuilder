"""Read-only source alpha and recorded Canvas transforms; never writes image pixels."""
import gzip, json
from pathlib import Path
from PIL import Image

packet = Path(__file__).parent
data = json.loads(gzip.decompress((packet / 'run-r4/results.json.gz').read_bytes()))
bone = Image.open(packet / 'candidate-source/public/art/bone-thrall-v09-r1.png').getchannel('A')
atlas = Image.open('/workspace/Roguelike-deckbuilder/public/art/adversaries-atlas.png').getchannel('A')
bounds = {
    'bone-thrall-v09-r1.png': bone.point(lambda value: 255 if value >= 8 else 0).getbbox(),
    'adversaries-atlas.png': atlas.crop((0, 627, 627, 1254)).point(lambda value: 255 if value >= 8 else 0).getbbox(),
}
samples = []
for row in data['rows']:
    for frame in row['frames']:
        draws = frame['draws']
        markers = [i for i, draw in enumerate(draws) if draw['url'].endswith('hunter-marek-v07-r3.png')]
        if not markers:
            continue
        assert markers[-1] == len(draws) - 1, 'Hunter-last premise not observed; refuse latest-frame inference'
        latest = draws[markers[-2] + 1 if len(markers) > 1 else 0:markers[-1] + 1]
        for draw in latest:
            name = draw['url'].rsplit('/', 1)[-1]
            if name not in bounds or draw['alpha'] < .05:
                continue
            sx, sy, sw, sh, dx, dy, width, height = draw['args']
            if name == 'adversaries-atlas.png' and [sx, sy, sw, sh] != [0, 627, 627, 627]:
                continue
            a, b, c, d, tx, ty = draw['matrix']
            x0, y0, x1, y1 = bounds[name]
            corners = []
            for u, v in [(x0, y0), (x1, y0), (x0, y1), (x1, y1)]:
                x, y = dx + u / sw * width, dy + v / sh * height
                corners.append((a * x + c * y + tx, b * x + d * y + ty))
            box = [min(p[0] for p in corners), min(p[1] for p in corners), max(p[0] for p in corners), max(p[1] for p in corners)]
            cw, ch = frame['canvas']
            samples.append({'variant': row['variant'], 'mode': row['mode'], 'width': row['width'], 'frame': frame['label'], 'image': name, 'bounds': box, 'within': box[0] >= 0 and box[1] >= 0 and box[2] <= cw and box[3] <= ch})
assert all(sample['within'] for sample in samples)
print(json.dumps({'latestPaintedDrawObservations': len(samples), 'outside': 0, 'originalAlpha8Bounds': bounds, 'qualification': 'Latest complete hunter-last draw group only. Historical startup draws remain in raw results; no earlier visible-frame proof or GPU pixel certification.'}))
