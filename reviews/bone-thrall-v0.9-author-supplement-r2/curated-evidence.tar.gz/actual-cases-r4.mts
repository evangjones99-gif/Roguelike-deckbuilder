import fs from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import {createGame,applyAction,applyActionWithEvents,legalActions,validateState,type GameState,type Action} from '/workspace/scratch/bone-thrall-art-author-v09-r1/prototype/src/engine.ts';
import {ENEMIES} from '/workspace/scratch/bone-thrall-art-author-v09-r1/prototype/src/content.ts';
const O='/workspace/scratch/bone-thrall-art-author-v09-r1-supplement-r2/run-r4',P='/workspace/scratch/bone-thrall-art-author-v09-r1/prototype',H=(b:any)=>createHash('sha256').update(b).digest('hex');
const baseDigest='23477f68c99d6d60b0b3f82b286a8d33bb6da6f2ca92c103fbecf5663634959f',candidateDigest='751e1267f83e17d2f31d27cf3043e724d7697e6f29821add0a5c738794f60a17';
function entered(){let s=createGame(44,0);s.floor=3;s.route=['battle','elite'];assert(validateState(s));s=applyAction(s,{type:'travel',choice:'elite'});assert(validateState(s));return s;}
function fixture(mode:string):GameState{
 let s=entered();
 if(mode==='dense'||mode==='attack')s=JSON.parse(awaitFull);
 s.schema=3;(s as any).engineKind=2;s.floor=4;s.route=['elite'];
 const kinds=mode==='unchanged'?['revenant']:mode==='mixed'?['revenant','thrall']:mode==='dense'||mode==='attack'?['thrall','revenant','thrall','revenant','thrall','thrall']:['thrall'];
 s.enemies=kinds.map(id=>{const def=ENEMIES[id];return {...def,uid:'e'+s.nextUid++,cardId:id,maxHp:def.hp+1,hp:def.hp+1,block:0,acted:false,intent:{damage:def.attack,target:s.allies[0]?.uid??'hunter',label:'Controlled artwork inspection'}};});
 assert(validateState(s),mode);return s;
}
const awaitFull=await fs.readFile('/workspace/scratch/crypt-art-study-v08/inputs/fullhand-fixture.json','utf8');
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const rows:any[]=[];
async function run(variant:string,mode:string,width:number,fault=''){
 const state=fixture(mode),reduced=mode!=='attack',ctx=await browser.newContext({viewport:{width,height:900},deviceScaleFactor:1,reducedMotion:reduced?'reduce':'no-preference'});
 await ctx.addInitScript(({state,reduced,fault})=>{
  if(!localStorage.getItem('hollowpact.run.v2'))localStorage.setItem('hollowpact.run.v2',JSON.stringify(state));localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion:!reduced,mute:true,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');
  const w=window as any;w.__draws=[];
  const get=HTMLCanvasElement.prototype.getContext;
  if(fault==='no-canvas')HTMLCanvasElement.prototype.getContext=function(...a:any[]){if(this.id==='arena')return null;return get.apply(this,a as any)}as any;
  const draw=CanvasRenderingContext2D.prototype.drawImage;
  CanvasRenderingContext2D.prototype.drawImage=function(...args:any[]){const im=args[0];if(this.canvas.id==='arena'&&im instanceof HTMLImageElement){const m=this.getTransform();w.__draws.push({url:im.src,args:args.slice(1),matrix:[m.a,m.b,m.c,m.d,m.e,m.f],alpha:this.globalAlpha,at:performance.now()});if(w.__draws.length>400)w.__draws.shift();}return draw.apply(this,args as any)};
 },{state,reduced,fault});
 let release:()=>void=()=>{};const delayed=new Promise<void>(r=>release=r);
 if(fault==='missing')await ctx.route('**/bone-thrall-v09-r1.png',r=>r.abort('failed'));
 if(fault==='late')await ctx.route('**/bone-thrall-v09-r1.png',async r=>{await delayed;await r.continue()});
 const page=await ctx.newPage(),errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 const url=`http://127.0.0.1:${variant==='candidate'?4598:4599}/`,prov=await(await ctx.request.get(url+'build-provenance.json')).json();assert.equal(prov.sourceDigest,variant==='candidate'?candidateDigest:baseDigest);
 await page.goto(url,{waitUntil:fault==='late'?'domcontentloaded':'load'});await page.locator('[data-ui=resume]').click();
 let current=state;const row:any={variant,mode,width,fault,provenance:prov,initial:state,errors,frames:[]};
 async function snap(label:string,full=false){const d=await page.evaluate(()=>{const c=document.querySelector<HTMLCanvasElement>('#arena')!;return {save:localStorage.getItem('hollowpact.run.v2'),draws:(window as any).__draws.slice(-100),canvas:[c.width,c.height],png:c.toDataURL(),units:[...document.querySelectorAll('.unit')].map(el=>({text:el.textContent,portrait:(()=>{const p=el.querySelector('.portrait');return p?getComputedStyle(p).backgroundImage:null})()})),fallback:document.querySelector('.arena-fallback')?.textContent,notice:document.querySelector('.arena-art-status')?.textContent}});assert.equal(d.save,JSON.stringify(current));const bytes=Buffer.from(d.png.split(',')[1],'base64');const filename=`${variant}-${mode}-${width}${fault?'-'+fault:''}-${label}.jpg`;if(full)await page.screenshot({path:O+'/'+filename,type:'jpeg',quality:65,fullPage:true});else await page.locator('#arena').screenshot({path:O+'/'+filename,type:'jpeg',quality:84});row.frames.push({label,file:filename,pngSHA256:H(bytes),...Object.fromEntries(Object.entries(d).filter(([k])=>k!=='png'))});}
 if(fault==='late'){await page.waitForTimeout(150);await snap('pending');release();}
 await page.waitForTimeout(1100);await snap('idle',true);
 if(mode==='attack'){
  const action:Action={type:'endTurn'};assert(legalActions(current).some(a=>a.type==='endTurn'));const result=applyActionWithEvents(current,action);row.action=action;row.expected=result;
  await page.locator('[data-action=endTurn]').click();if(await page.locator('[data-ui=confirm-end]').count())await page.locator('[data-ui=confirm-end]').click();current=result.state;
  await page.waitForTimeout(220);await snap('enemy-strike');await page.waitForTimeout(1200);await snap('settled');
 }else if(!fault){const thrall=current.enemies.find(e=>e.cardId==='thrall');const action=thrall&&legalActions(current).find(a=>a.type==='play'&&a.target===thrall.uid);if(action){const result=applyActionWithEvents(current,action);row.action=action;row.expected=result;await page.locator(`[data-ui=play-card][data-index="${(action as any).index}"]`).click();await page.locator(`.valid-target[data-unit="${(action as any).target}"]`).click();current=result.state;await page.waitForTimeout(1000);assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),JSON.stringify(current));}}
 await page.reload({waitUntil:'load'});assert.equal(await page.evaluate(()=>localStorage.getItem('hollowpact.run.v2')),JSON.stringify(current));assert.deepEqual(errors,[]);await ctx.close();rows.push(row);await fs.writeFile(O+'/checkpoint.json',JSON.stringify({cases:rows.length},null,2)+'\n');
}
try{
 for(const width of[1440,390])for(const mode of['single','mixed','dense','attack','unchanged'])for(const variant of['baseline','candidate'])await run(variant,mode,width);
 for(const fault of['missing','late','no-canvas'])await run('candidate','mixed',390,fault);
 const pairs=[];for(const width of[1440,390]){const a=rows.find(r=>r.variant==='baseline'&&r.mode==='unchanged'&&r.width===width),b=rows.find(r=>r.variant==='candidate'&&r.mode==='unchanged'&&r.width===width);assert.equal(a.frames[0].pngSHA256,b.frames[0].pngSHA256);pairs.push({width,pngSHA256:a.frames[0].pngSHA256});}
 await fs.writeFile(O+'/results.json.gz',gzipSync(Buffer.from(JSON.stringify({scope:'Author actual Chromium built-host cases, explicit unearned validated formation diagnostics, natural timers; no independent, native, human or articulated-animation claim',rows,unchangedWraithPixelPairs:pairs},null,2)+'\n')),{flag:'wx'});console.log(JSON.stringify({cases:rows.length,actions:rows.filter(r=>r.action).length,reloads:rows.length,unchangedPairs:pairs.length}));
}catch(e){await fs.writeFile(O+'/FAILURE-r1.json',JSON.stringify({error:String(e),stack:(e as Error).stack,rows},null,2)+'\n',{flag:'wx'});throw e;}finally{await browser.close();}
