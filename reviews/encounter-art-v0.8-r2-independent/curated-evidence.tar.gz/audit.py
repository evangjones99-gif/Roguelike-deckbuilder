from pathlib import Path
import json,hashlib,gzip,os
from PIL import Image
O=Path('/workspace/scratch/encounter-selector-independent-v08-r2');A=Path('/workspace/scratch/encounter-art-author-v08-r2');C=A/'candidate';root=Path('/workspace/Roguelike-deckbuilder')
h=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((A/'FROZEN-FILES.json').read_text())
for p,r in m['files'].items():assert h((A/p).read_bytes())==r['sha256'],p
prov=json.loads((C/'dist/build-provenance.json').read_text())
for p,digest in prov['hashes'].items():assert h((C/p).read_bytes())==digest,p
for p,r in json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text())['actualDistFiles'].items():assert h((C/'dist'/p).read_bytes())==r['sha256'],p
baseline=json.loads((root/'dist/build-provenance.json').read_text())
for p,digest in baseline['hashes'].items():assert h((root/p).read_bytes())==digest,p
results=json.loads((O/'actual-results.json').read_text()); supp=json.loads((O/'asset-supplement.json').read_text())
violations=[]; total=0
for r in results['rows']+supp['rows']:
 for s in r['steps']:
  total+=len(s.get('quads',[]))
  for q in s.get('cellContainmentViolations',[]):violations.append({'case':r['name'],**q})
assert all(q['size']==[390,939] and q['src'].endswith('hunter-marek-v07-r3.png') for q in violations)
mobile={}
for r in results['rows']:
 if r['name'].startswith('visual-390'):
  q=r['steps'][-1]['quads']; settled=[x for x in q if x['size']==[390,220]]
  assert settled
  assert all(all(-1<=p['x']<=391 and -1<=p['y']<=221 for p in x['points'])for x in settled)
  mobile[r['name']]={'settledQuads':len(settled),'transientViolations':[x for x in violations if x['case']==r['name']]}
left=mobile['visual-390-false']['transientViolations'][0];right=mobile['visual-390-true']['transientViolations'][0]
assert left['points']==right['points'] and left['size']==right['size']
im=Image.open(root/'public/art/hunter-marek-v07-r3.png');alpha=im.getchannel('A').crop((0,0,512,512)); bbox=alpha.point(lambda a:255 if a>=10 else 0).getbbox()
minimumX=left['points'][0]['x'];maximumX=left['points'][1]['x'];visible=[minimumX+(maximumX-minimumX)*bbox[0]/512,minimumX+(maximumX-minimumX)*bbox[2]/512]
assert 0<visible[0]<visible[1]<390
assert all(image['sha256']=='ff9818614003e9432ee1868c2f60b336d0b5dfe63f5c01e380832f1e880c4b00'for r in results['rows']+supp['rows']for image in r['images'])
(O/'audit.json').write_text(json.dumps({'authorFilesExact':len(m['files']),'candidateInputsExact':len(prov['hashes']),'baselineInputsExact':len(baseline['hashes']),'sourceDigest':prov['sourceDigest'],'baselineDigest':baseline['sourceDigest'],'cases':results['actualCases']+supp['actualCases'],'actions':results['actions']+supp['actions'],'quadsObservedIncludingRepeatedSnapshots':total,'violations':violations,'mobileSettled':mobile,'idleAlphaThreshold10BBox':bbox,'idleThreshold10ProjectedX':visible,'qualification':'Complete hunter cells overflow inherited startup geometry identically. Threshold10 is an explicit visible-anatomy heuristic, not proof all low-alpha pixels remain inside. Final settled mobile quads are inside. Snapshot label property was overwritten by accessible label in raw main dataset, so its computed reload count is incorrectly0. Twenty actual main reload calls/assertions and three supplemental calls executed by preserved scripts; raw files stay unchanged.'},indent=2)+'\n')
T=Path('/tmp/hollowpact-encounter-selector-independent-v08-r2-raw');T.mkdir(exist_ok=False)
receipts=[]
for name in ['FAILURE.json','FAILURE-r2.json','actual-results.json','asset-supplement.json']:
 p=O/name;b=p.read_bytes();gz=O/(name+'.gz')
 with gz.open('xb')as f:f.write(gzip.compress(b,mtime=0))
 assert gzip.decompress(gz.read_bytes())==b
 t=T/name;p.rename(t);p.symlink_to(t)
 assert p.read_bytes()==b
 receipts.append({'originalPath':str(p),'workingTarget':str(t),'rawBytes':len(b),'rawSHA256':h(b),'durableLosslessGzip':gz.name,'gzipBytes':gz.stat().st_size,'gzipSHA256':h(gz.read_bytes()),'originalWorkingPathStillAccessible':True})
(O/'STORAGE-RECEIPT.json').write_text(json.dumps({'qualification':'Exact unique raw JSON bytes retained durably by lossless gzip, original working paths point at temporary redundant decoded files. TMP is not durable backup. Nothing deleted or overwritten. Independent budget reduction after all browsers closed.','files':receipts},indent=2)+'\n')
print(json.dumps({'cases':results['actualCases']+supp['actualCases'],'actions':results['actions']+supp['actions'],'quads':total,'transientCellViolations':len(violations),'visibleIdleThreshold10X':visible,'rawBytesPreserved':sum(x['rawBytes']for x in receipts),'durableGzipBytes':sum(x['gzipBytes']for x in receipts)}))
