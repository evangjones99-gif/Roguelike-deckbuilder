from pathlib import Path
import json,hashlib,sys
A=Path('/workspace/scratch/installer-asar-platform-author-v09-r1');O=Path('/workspace/scratch/installer-asar-platform-independent-v09-r1');H=lambda b:hashlib.sha256(b).hexdigest();manifest=(A/'MANIFEST.json').read_bytes();assert H(manifest)=='dbd5455bc517f11536cc94bd9bfbb05c0f6064fa58544eb5fd960cefdf93c7f3';m=json.loads(manifest);rows=[]
for r in m['files']:
 p=A/r['path']
 if r['type']=='symlink':
  assert p.is_symlink();assert str(p.readlink())==r['target'];rows.append(r)
 else:
  b=p.read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],r['path'];rows.append(r)
assert len(rows)==72
stage=Path('/tmp/hollowpact-final-kill-v09-root-r1');runtime=json.load(open(stage/'dist/build-provenance.json'));assert len(runtime['hashes'])==77 and H(json.dumps(runtime['hashes'],separators=(',',':')).encode())==runtime['sourceDigest']=='8a33f950ed57093a222baf9b7883a5c1ccf2deb2e8412429ef0fe05d370467cb';sources={}
for n,h in runtime['hashes'].items():
 b=(stage/n).read_bytes();assert H(b)==h;sources[n]={'bytes':len(b),'sha256':h}
outputs={str(p.relative_to(stage/'dist')):{'bytes':p.stat().st_size,'sha256':H(p.read_bytes())}for p in sorted((stage/'dist').rglob('*'))if p.is_file()};assert len(outputs)==55
rootTools=json.load(open(A/'BASELINE-INPUTS.json'))
for r in rootTools:
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],r['path']
binaries=json.load(open(A/'EXTERNAL-BINARY-REFERENCES.json'))
for r in binaries:
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],r['path']
changes=json.load(open(A/'PROPOSED-CHANGES-r1.json'))
for r in changes:
 b=(A/'proposed'/r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256']
for n in ['windows-installer-current-validation.mjs','windows-installer-prepare.mjs','windows-installer-transfer.mjs','windows-installer-guards.test.mjs','windows-installer-transfer.test.mjs']:assert(A/'baseline/scripts'/n).read_bytes()==(A/'proposed/scripts'/n).read_bytes()
result={'authorManifestSHA256':H(manifest),'authorRows':len(rows),'rootTools':rootTools,'sources':sources,'outputs':outputs,'externalBinaryReferences':binaries,'changedFiles':changes,'unchangedBoundaries':['39cue decoder/helper','prepare','transfer','guard test','transfer test'],'runtime':runtime['sourceDigest']}
if sys.argv[1]=='INPUT-AFTER.json':assert result==json.load(open(O/'INPUT-BEFORE.json'))
(O/sys.argv[1]).open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'authorRows':len(rows),'sources':len(sources),'outputs':len(outputs),'rootToolHashes':len(rootTools),'boundaryDecoderUnchanged':True}))
