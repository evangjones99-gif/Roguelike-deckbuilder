Synthetic fixture, not a game-quality test.
