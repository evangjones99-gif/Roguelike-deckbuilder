from pathlib import Path
from PIL import Image
import json
import hashlib

packet = Path('/workspace/scratch/bone-thrall-art-author-v09-r1')
original = Path('/workspace/generated_images/exec-89c24152-3408-45ed-9d7e-00aed9558f4c.png')
data = original.read_bytes()
with (packet / 'generated-original-r1.png').open('xb') as output:
    output.write(data)
image = Image.open(original)
alpha = image.getchannel('A')
thresholds = {}
for threshold in [1, 8, 10, 32, 128, 254]:
    mask = alpha.point(lambda value: 255 if value >= threshold else 0)
    thresholds[str(threshold)] = {
        'bounds': mask.getbbox(),
        'pixels': mask.histogram()[255],
    }
edges = {
    'top': alpha.crop((0, 0, image.width, 1)).getextrema()[1],
    'bottom': alpha.crop((0, image.height - 1, image.width, image.height)).getextrema()[1],
    'left': alpha.crop((0, 0, 1, image.height)).getextrema()[1],
    'right': alpha.crop((image.width - 1, 0, image.width, image.height)).getextrema()[1],
}
record = {
    'generator': 'image_gen.imagegen',
    'rawGeneratedPath': str(original),
    'preservedByteExactCopy': 'generated-original-r1.png',
    'sha256': hashlib.sha256(data).hexdigest(),
    'bytes': len(data),
    'dimensions': image.size,
    'mode': image.mode,
    'requestedSize': '1024 square; actual 1254 square. Requested geometry is not a guarantee.',
    'transparencyRequested': True,
    'actualAlphaExtrema': alpha.getextrema(),
    'actualEdgeAlphaMaxima': edges,
    'request': 'REQUEST-r1.txt',
    'referenceInputHashes': 'INSPECTED-INPUTS.json',
    'imageEditing': 'Exact generator pixels copied unchanged; PIL read-only alpha inspection, no image transformation output.',
    'rights': 'Original AI-assisted concept research; commercial distribution rights/legal/store AI-content disclosure unverified.',
    'quality': 'Author investigation only; separate independent anatomy/alpha/actual-size/contact review pending.',
    'alphaThresholds': thresholds,
    'failure': 'Prior alpha diagnostic failed to parse an else0 typo; no image copy/metadata was created by that failed invocation. Failed fragment/log retained.',
}
with (packet / 'RAW-ORIGINAL-PROVENANCE-r1.json').open('x') as output:
    json.dump(record, output, indent=2)
print(json.dumps({'size': image.size, 'sha256': record['sha256'], 'bytes': len(data), 'bounds8': thresholds['8'], 'edges': edges}))
