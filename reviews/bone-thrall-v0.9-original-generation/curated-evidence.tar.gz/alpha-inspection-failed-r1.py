from pathlib import Path
from PIL import Image
import json,hashlib
p=Path('/workspace/scratch/bone-thrall-art-author-v09-r1');src=Path('/workspace/generated_images/exec-89c24152-3408-45ed-9d7e-00aed9558f4c.png');d=src.read_bytes()
with (p/'generated-original-r1.png').open('xb')as f:f.write(d)
im=Image.open(src);a=im.getchannel('A');rows={}
for t in[1,8,10,32,128,254]:
 mask=a.point(lambda x:255 if x>=t else0);rows[str(t)]={'bounds':mask.getbbox(),'count':sum(mask.histogram()[255:]),'edges':{'top':a.crop((0,0,im.width,1)).getextrema()[1],'bottom':a.crop((0,im.height-1,im.width,im.height)).getextrema()[1],'left':a.crop((0,0,1,im.height)).getextrema()[1],'right':a.crop((im.width-1,0,im.width,im.height)).getextrema()[1]}}
