import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {extractFile,getRawHeader} from '/workspace/Roguelike-deckbuilder/node_modules/@electron/asar/lib/asar.js';
import {assertPackagedAsar} from '/workspace/scratch/installer-asar-native-path-author-v09-r1/proposed/scripts/windows-installer-asar-validation.mjs';
const packet='/workspace/scratch/installer-asar-native-path-independent-v09-r1';
const root='/workspace/Roguelike-deckbuilder';
const archive='/tmp/hollowpact-installer-asar-current801d-producer-author-v09-r1/app.asar';
const sha=b=>createHash('sha256').update(b).digest('hex');
const snapshot=p=>({sha256:sha(fs.readFileSync(p)),bytes:fs.statSync(p).size,mtimeMs:fs.statSync(p).mtimeMs});
const before=snapshot(archive);
const actual=await assertPackagedAsar(archive,root);
assert.equal(actual.leafCount,60);assert.equal(actual.sourceInputs,78);assert.equal(actual.distOutputs,56);
const raw=getRawHeader(archive);
const classFile=root+'/node_modules/@electron/asar/lib/filesystem.js';
const classBytes=fs.readFileSync(classFile),classURL=pathToFileURL(classFile);
assert.equal(sha(classBytes),'ee09465ac5a38e254468d2d479cc0004a6c270b6447f50d62a30268dd997b49f');
const context=vm.createContext({process,Buffer});
const classModule=new vm.SourceTextModule(classBytes.toString(),{context,identifier:classURL.href});
const bridges=[];
await classModule.link(async specifier=>{
 const dependency=specifier==='node:path'?{default:path.win32}:await import(specifier.startsWith('.')?new URL(specifier,classURL).href:specifier);
 bridges.push({specifier,override:specifier==='node:path'?'Actual node:path.win32':'Actual installed namespace'});
 return new vm.SyntheticModule(Object.keys(dependency),function(){for(const n of Object.keys(dependency))this.setExport(n,dependency[n]);},{context});
});
await classModule.evaluate();
const LibraryClass=classModule.namespace.Filesystem;
function instance(){const v=new LibraryClass('C:\\review-fixture');v.setHeader(structuredClone(raw.header),raw.headerSize);return v;}
const headerText=JSON.stringify(raw.header);const rows=[];
for(const leaf of actual.leaves){
 const posixReader=instance(),nativeReader=instance();let posixSuccess=false,posixError=null;
 try{const node=posixReader.getFile(leaf.path,false);assert.equal(node.size,leaf.bytes);posixSuccess=true;}catch(e){posixError=String(e);}
 const parts=leaf.path.split('/');assert.ok(parts.every(p=>p&&p!=='.'&&p!=='..'&&!/[\\/:\x00-\x1f]/.test(p)));
 const nativeArgument=path.win32.join(...parts);const node=nativeReader.getFile(nativeArgument,false);
 assert.equal(node.offset,leaf.offset);assert.equal(node.size,leaf.bytes);assert.equal(JSON.stringify(node.integrity),JSON.stringify(leaf.integrity));
 assert.equal(JSON.stringify(nativeReader.header),headerText);
 const extracted=extractFile(archive,path.join(...parts),false);assert.equal(sha(extracted),leaf.sha256);
 const blocks=[];for(let i=0;i<extracted.length;i+=4194304)blocks.push(sha(extracted.subarray(i,i+4194304)));
 assert.deepEqual(node.integrity,{algorithm:'SHA256',hash:sha(extracted),blockSize:4194304,blocks});
 rows.push({logicalIdentity:leaf.path,nativeWin32Argument:nativeArgument,posixSuccess,posixError,posixMutatesCachedHeader:JSON.stringify(posixReader.header)!==headerText,nativeExactLeaf:true,nativeCachedHeaderUnchanged:true,actualLinuxRawAndBlocksMatch:true});
}
assert.equal(rows.filter(r=>r.posixSuccess).length,7);assert.equal(rows.filter(r=>!r.posixSuccess).length,53);
const failure=rows.find(r=>r.logicalIdentity==='dist/art/PROVENANCE.json');assert.ok(!failure.posixSuccess&&failure.posixMutatesCachedHeader);
assert.ok(rows.find(r=>r.logicalIdentity==='dist/build-provenance.json').posixSuccess);
assert.deepEqual(snapshot(archive),before);assert.equal(sha(fs.readFileSync(classFile)),sha(classBytes));
const report={classification:'Independent actual unchanged installed ASAR4.3.1 class with only Win32 path binding, evaluated on Linux; actual Linux default helper/extraction/integrity, not Windows extractFile/I/O/install',node:process.version,platform:process.platform,classFile,classSHA256:sha(classBytes),sourceUnmodified:true,bridges,archiveBefore:before,archiveAfter:snapshot(archive),defaultGate:actual,rawPosixSuccessful:7,rawPosixFailures:53,nativeWin32Exact:60,independentlyRecomputedIntegrityLeaves:60,rows};
fs.writeFileSync(packet+'/ACTUAL-LIBRARY-AND-DEFAULT-GATE.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({rawPosixSuccessful:7,rawPosixFailures:53,nativeWin32Exact:60,defaultGateInputs:actual.sourceInputs,defaultGateOutputs:actual.distOutputs,defaultGateSHA:actual.asarSHA256,rawAndBlockIntegrityRecomputed:60,archiveUnchanged:true}));
