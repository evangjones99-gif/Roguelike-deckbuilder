from pathlib import Path
import hashlib,json,zipfile,os
P=Path('/workspace/scratch/installer-asar-native-path-independent-v09-r1')
A=Path('/workspace/scratch/installer-asar-native-path-author-v09-r1')
R=Path('/workspace/Roguelike-deckbuilder')
H=lambda b:hashlib.sha256(b).hexdigest()
def row(p):
 b=p.read_bytes();s=p.stat()
 return {'path':str(p),'bytes':len(b),'sha256':H(b),'mtimeNS':s.st_mtime_ns,'mode':s.st_mode,'inode':s.st_ino}
manifest=A/'MANIFEST.json';assert H(manifest.read_bytes())=='3e588a0e756858523b46235ce8d493ac348729ec87d97ef4fed34f10b7f9b10b'
author=json.loads(manifest.read_text())
for r in author['rows']:
 b=(A/r['path']).read_bytes();assert(len(b),H(b))==(r['bytes'],r['sha256']),r['path']
for r in author['aliases']:assert os.readlink(A/r['path'])==r['target']
inputs=[]
for r in json.loads((A/'INPUTS-PRE.json').read_text())['inputs']:
 b=Path(r['path']).read_bytes();assert(len(b),H(b))==(r['bytes'],r['sha256']),r['path'];inputs.append(row(Path(r['path'])))
changes=json.loads((A/'PROPOSED-CHANGES.json').read_text())
for r in changes['changedFiles']:
 assert H((A/'proposed'/r['path']).read_bytes())==r['afterSHA256']
 assert H((R/r['path']).read_bytes())==r['beforeSHA256']
for n in changes['unchangedCompanions']:assert(A/'proposed/scripts'/n).read_bytes()==(R/'scripts'/n).read_bytes()
runtime=json.loads((R/'dist/build-provenance.json').read_text())
assert runtime['sourceDigest']=='801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029'
assert len(runtime['hashes'])==78
assert H(json.dumps(runtime['hashes'],separators=(',',':')).encode())==runtime['sourceDigest']
sources=[]
for n,h in runtime['hashes'].items():
 r=row(R/n);assert r['sha256']==h,n;sources.append(r)
outputs=[row(p)for p in sorted((R/'dist').rglob('*'))if p.is_file()];assert len(outputs)==56
D=R/'reviews/root-v0.9-installer-36819597195-failure';z=D/'ORIGINAL-EVIDENCE.zip'
assert H(z.read_bytes())=='83af6ea90f12c25cec0d5a8f050db6ef6d725b69d82e976a09f74574c92f8e18'
declared=json.loads((D/'ORIGINAL-INTAKE.json').read_text());zipmembers=[]
with zipfile.ZipFile(z)as f:
 assert f.testzip()is None;assert set(f.namelist())=={r['path']for r in declared['members']}
 for r in declared['members']:
  assert not r['path'].startswith('/') and '..'not in r['path'].split('/')
  b=f.read(r['path']);assert(len(b),H(b))==(r['bytes'],r['sha256']);zipmembers.append(r)
receipt=json.loads((D/'installer-smoke.json').read_text());assert receipt['status']=='failed'and receipt['failedPhase']=='preflight'and receipt['steps']==[]
assert '"dist/art/PROVENANCE.json" was not found in this archive'in receipt['failure']
log=Path('/tmp/hollowpact-installer-nativepath-independent-originaljob-r1.log')
assert H(log.read_bytes())=='6506a53295cf15f8a5739bc5ae21fc9285ffa7a3df2e4c8d39cce5e156945993'
fullLog=log.read_text();assert 'failed; evidence D:'in fullLog and 'Process completed with exit code 1.'in fullLog
jobs=json.loads((D/'JOBS-API.json').read_text())['jobs'];j=next(x for x in jobs if x['id']==110232088390)
assert j['conclusion']=='failure';steps={x['number']:x for x in j['steps']};assert steps[7]['conclusion']=='success'and steps[8]['conclusion']=='failure'
archive=Path('/tmp/hollowpact-installer-asar-current801d-producer-author-v09-r1/app.asar')
archiveRow=row(archive);assert(archiveRow['bytes'],archiveRow['sha256'])==(33063240,'6a89d2b61562309f0d8b9974df6a3bb18008dd5626a6001e898491bbba2ce03b')
context=[row(R/p)for p in ['releases/0.8.0/manifest.json','docs/CURRENT-RULES.md']if(R/p).exists()]
out={'schema':1,'classification':'Independent raw intake; Linux, no Windows retry','authorManifest':row(manifest),'authorRows':len(author['rows']),'authorBytes':sum(r['bytes']for r in author['rows']),'authorFreeze':row(A/'FREEZE.json'),'inputs':inputs,'sourceDigest':runtime['sourceDigest'],'sources':sources,'outputs':outputs,'originalZIP':row(z),'originalZIPMembers':zipmembers,'originalReceipt':row(D/'installer-smoke.json'),'originalFailure':receipt['failure'],'completedJobLog':row(log),'logScope':'Independent GitHub refetch of exact decoded completed job log; exception saved in receipt, not echoed in stdout','jobSteps':j['steps'],'producerArchive':archiveRow,'context':context}
(P/'INTAKE-BEFORE-R2.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'authorRows':out['authorRows'],'sourceInputs':len(sources),'distOutputs':len(outputs),'zipMembers':len(zipmembers),'completedJobLogSHA':out['completedJobLog']['sha256'],'failedPhase':receipt['failedPhase']}))
