import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import vm from 'node:vm';
import {Readable} from 'node:stream';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {extractFile,getRawHeader} from '/workspace/Roguelike-deckbuilder/node_modules/@electron/asar/lib/asar.js';
import {assertPackagedAsar} from '/workspace/scratch/installer-asar-native-path-author-v09-r1/proposed/scripts/windows-installer-asar-validation.mjs';
const root='/workspace/Roguelike-deckbuilder',packet='/workspace/scratch/installer-asar-native-path-independent-v09-r1';
const require=createRequire(root+'/package.json');
const producerFile=root+'/node_modules/app-builder-lib/node_modules/@electron/asar/lib/asar.js';
const producer=require(producerFile);
const sha=b=>createHash('sha256').update(b).digest('hex');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'hollowpact-nativepath-independent-small-r1-'));
const cases=[];let serial=0;
const digest=o=>sha(JSON.stringify(o));
async function fixture(){
 const dir=path.join(temp,String(++serial)),source=path.join(dir,'source');fs.mkdirSync(source,{recursive:true});
 const pkg={name:'independent-fixture',version:'0.9.0',description:'Synthetic path test only',main:'desktop/main.cjs',repository:{type:'git',url:'https://example.invalid'},author:'test',license:'UNLICENSED',type:'module',bugs:{url:'https://example.invalid/issues'},homepage:'https://example.invalid',private:true};
 const pb=Buffer.from(JSON.stringify(pkg)),main=Buffer.from('tiny dummy entry'),deep=Buffer.from('tiny dummy nested entry');
 const sources={'desktop/main.cjs':sha(main),'desktop/QA/Nested/Probe.CJS':sha(deep),'package.json':sha(pb)};
 const runtime={version:pkg.version,sourceDigest:digest(sources),hashes:sources,node:process.version};
 const rows=[['desktop/main.cjs',main],['desktop/QA/Nested/Probe.CJS',deep],['dist/build-provenance.json',Buffer.from(JSON.stringify(runtime))],['dist/index.html',Buffer.from('tiny dummy HTML')],['dist/art/PROVENANCE.json',Buffer.from('tiny dummy provenance')],['dist/art/Creatures/BoneThrall.JSON',Buffer.from('tiny dummy creature')],['package.json',pb]];
 for(const [p,b]of rows){const file=path.join(source,...p.split('/'));fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,b);}
 const archive=path.join(dir,'app.asar');
 await producer.createPackageFromStreams(archive,rows.map(([n,b])=>({path:path.join(...n.split('/')),type:'file',unpacked:false,stat:{mode:0o100644,size:b.length},streamGenerator:()=>Readable.from(b)})));
 const raw=getRawHeader(archive);let offset=0;
 const leaves=rows.map(([n,b])=>{const r={path:n,bytes:b.length,sha256:sha(b),offset:String(offset),integrity:{algorithm:'SHA256',hash:sha(b),blockSize:4194304,blocks:[sha(b)]}};offset+=b.length;return r;});
 const expected={version:pkg.version,sourceDigest:runtime.sourceDigest,sourceInputCount:3,sourceHashes:sources,distOutputCount:4,leafCount:7,asarSHA256:sha(fs.readFileSync(archive)),asarBytes:fs.statSync(archive).size,rawHeaderStringSHA256:sha(raw.headerString),normalizedManifest:{keys:Object.keys(pkg),sha256:sha(pb),bytes:pb.length,json:pkg},leaves};
 return {archive,source,expected};
}
function headerChange(f,change){
 const old=fs.readFileSync(f.archive),raw=getRawHeader(f.archive),header=structuredClone(raw.header);change(header);
 const pickle=require('chromium-pickle-js'),p=pickle.createEmpty();p.writeString(JSON.stringify(header));const h=p.toBuffer(),size=pickle.createEmpty();size.writeUInt32(h.length);
 const bytes=Buffer.concat([size.toBuffer(),h,old.subarray(8+raw.headerSize)]),target=f.archive+'.header-mutated';fs.writeFileSync(target,bytes);
 return {...f,archive:target,expected:{...f.expected,asarSHA256:sha(bytes),asarBytes:bytes.length,rawHeaderStringSHA256:sha(JSON.stringify(header))}};
}
async function refused(name,f,pattern){
 let failure=null;try{await assertPackagedAsar(f.archive,f.source,f.expected);}catch(e){failure=String(e);}
 assert.ok(failure,'Expected refusal: '+name);assert.match(failure,pattern);cases.push({name,result:'refused',failure,archive:f.archive});
}
const positive=await fixture();const admitted=await assertPackagedAsar(positive.archive,positive.source,positive.expected);assert.equal(admitted.leafCount,7);cases.push({name:'Independent nested mixed-case seven-leaf strict fixture',result:'admitted',archive:positive.archive,leaves:admitted.leaves.map(r=>r.path)});
for(const bad of ['', '.', '..', 'X/Y', 'X\\Y', 'C:', '\u0000', '\u001f']){
 const f=headerChange(await fixture(),h=>{Object.defineProperty(h.files.desktop.files,bad,{value:h.files.desktop.files.QA,enumerable:true,configurable:true});delete h.files.desktop.files.QA;});
 await refused('unsafe component '+JSON.stringify(bad),f,/Unsafe ASAR path component|invalid entry name/);
}
const wrongCase=headerChange(await fixture(),h=>{const entries=h.files.desktop.files.QA.files.Nested.files;entries['probe.cjs']=entries['Probe.CJS'];delete entries['Probe.CJS'];});
await refused('Mixed-case leaf is an exact logical identity',wrongCase,/Closed ASAR names/);
for(const key of ['link','unpacked','executable']){
 const f=headerChange(await fixture(),h=>{const entries=h.files.desktop.files.QA.files.Nested.files;if(key==='link')entries['Probe.CJS']={link:'package.json'};else entries['Probe.CJS'][key]=true;});
 await refused('Nested '+key+' header refused',f,/Unexpected link\/unpacked\/executable/);
}
const changed=await fixture(),bytes=fs.readFileSync(changed.archive),header=getRawHeader(changed.archive);const leaf=header.header.files.dist.files.art.files.Creatures.files['BoneThrall.JSON'];bytes[8+header.headerSize+Number(leaf.offset)]^=1;changed.archive+='.raw-tampered';fs.writeFileSync(changed.archive,bytes);changed.expected.asarSHA256=sha(bytes);
await refused('Nested raw tamper cannot hide behind rebased outer hash',changed,/Closed ASAR names/);
const extra=await fixture();fs.writeFileSync(path.join(extra.source,'desktop','QA','Nested','Extra.CJS'),'extra');await refused('Extra nested source refused',extra,/Closed local runtime source set/);
const missing=headerChange(await fixture(),h=>{delete h.files.dist.files.art.files.Creatures.files['BoneThrall.JSON'];});await refused('Missing nested serialized payload refused',missing,/Closed ASAR leaf count/);
const nativeProducerPath=root+'/node_modules/app-builder-lib/node_modules/@electron/asar/lib/filesystem.js';
const nativeProducerCode=fs.readFileSync(nativeProducerPath,'utf8'),actualRequire=createRequire(nativeProducerPath),cjsModule={exports:{}};
const wrapper=new vm.Script('(function(exports,require,module,__filename,__dirname){'+nativeProducerCode+'\n})',{filename:nativeProducerPath}).runInNewContext({Buffer,process});
wrapper(cjsModule.exports,name=>name==='path'?path.win32:actualRequire(name),cjsModule,nativeProducerPath,path.dirname(nativeProducerPath));
const NativeProducerClass=cjsModule.exports.default||cjsModule.exports.Filesystem;assert.equal(typeof NativeProducerClass,'function');
const nativeProducer=new NativeProducerClass('C:\\fixture');
for(const r of positive.expected.leaves){const native=path.win32.join(...r.path.split('/'));const node=nativeProducer.searchNodeFromPath(path.win32.join('C:\\fixture',native));node.size=r.bytes;}
const nativeHeader=nativeProducer.getHeader();
assert.equal(nativeHeader.files.desktop.files.QA.files.Nested.files['Probe.CJS'].size,23);
assert.ok(nativeHeader.files.dist.files.art.files.Creatures.files['BoneThrall.JSON']);
assert.ok(!Object.keys(nativeHeader.files).some(k=>k.includes('/')||k.includes('\\')));
const refs=[];function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const f=path.join(d,e.name);if(e.isDirectory())walk(f);else{const b=fs.readFileSync(f);refs.push({path:f,bytes:b.length,sha256:sha(b)});}}}walk(temp);
const report={classification:'Independent tiny synthetic serialized payload refusals and unchanged actual nested3.4.1 Win32 producer node-path simulation on Linux; explicit caller-trusted synthetic ledger; no production archive allocated/nativeWindows execution',temporaryDirectory:temp,cases,positiveCount:1,refusalCount:cases.filter(r=>r.result==='refused').length,producer:{path:producerFile,sha256:sha(fs.readFileSync(producerFile)),filesystemSource:nativeProducerPath,sourceSHA256:sha(Buffer.from(nativeProducerCode)),sourceUnmodified:fs.readFileSync(nativeProducerPath,'utf8')===nativeProducerCode,nativeHeader,scope:'Actual CJS filesystem source evaluated unchanged; only require(path) supplies real path.win32; searchNodeFromPath fixture portability model, not serialized Windows producer run'},fixtureReferences:refs};
fs.writeFileSync(packet+'/INDEPENDENT-NEGATIVE-GATE.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({positive:1,refusals:report.refusalCount,fixtureFiles:refs.length,fixtureBytes:refs.reduce((n,r)=>n+r.bytes,0),nativeProducerClassPathSimulation:true}));
