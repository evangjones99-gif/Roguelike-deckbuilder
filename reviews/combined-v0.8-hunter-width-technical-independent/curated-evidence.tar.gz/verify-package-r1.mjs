import * as asar from '/workspace/Roguelike-deckbuilder/node_modules/@electron/asar/lib/asar.js';
import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const pkg='/tmp/hollowpact-linux-v08-width-r1/linux-unpacked',archive=pkg+'/resources/app.asar',out='/workspace/scratch/combined-v08-width-technical-independent-r1';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const source=JSON.parse(fs.readFileSync(out+'/source-manifest.json')),dist=JSON.parse(fs.readFileSync(out+'/output-manifest.json'));
const expected=Object.fromEntries(Object.entries(dist).map(([n,v])=>['dist/'+n,v.sha256]));for(const n of ['desktop/main.cjs','desktop/audio-lifecycle.cjs','desktop/icon.png'])expected[n]=source.hashes[n];
const files={},dirs=[];
for(const path of asar.listPackage(archive)){const n=path.replace(/^\//,'');const stat=asar.statFile(archive,n);if(stat.files)dirs.push(n);else{assert.ok(!stat.link,'unexpected link '+n);assert.ok(!stat.unpacked,'unexpected unpacked payload '+n);const b=asar.extractFile(archive,n);files[n]={bytes:b.length,sha256:sha(b)};if(n!=='package.json')assert.equal(files[n].sha256,expected[n],n);else{const p=JSON.parse(b);assert.equal(p.version,'0.8.0');assert.equal(p.main,'desktop/main.cjs');}}}
assert.deepEqual(Object.keys(files).filter(n=>n!=='package.json').sort(),Object.keys(expected).sort());assert.equal(Object.keys(files).length,59);
fs.writeFileSync(out+'/package-verification-r1.json',JSON.stringify({archive,archiveSHA256:sha(fs.readFileSync(archive)),actualRegularLeaves:59,all58OriginalPayloadsExact:true,files,executable:pkg+'/hollowpact',executableSHA256:sha(fs.readFileSync(pkg+'/hollowpact')),licenseFiles:['LICENSE.electron.txt','LICENSES.chromium.html'].map(n=>({name:n,sha256:sha(fs.readFileSync(pkg+'/'+n))}))},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({files:59,archiveSHA256:sha(fs.readFileSync(archive))}));
