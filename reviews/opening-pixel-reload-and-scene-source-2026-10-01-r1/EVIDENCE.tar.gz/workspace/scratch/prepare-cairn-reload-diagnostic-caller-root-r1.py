import os,json,hashlib,difflib,ast
from pathlib import Path
base=Path('/workspace/scratch/standard-sol-cairn-paired-comparison-driver-author-r3')
packet=Path('/workspace/scratch/cairn-reload-diagnostic-caller-root-r1');packet.mkdir(mode=0o700)
freezePath=Path('/workspace/scratch/first-five-opening-cairn-reload-eligibility-runtime-freeze-root-r1.json')
freeze=json.loads(freezePath.read_text());assert freeze['sourceDigest']=='e58a3283d1d77a13fd063eb235dd2fb1377eddc5d4e2d649d2a2bfaedec18190'
original=(base/'driver-paired-r3-final.mjs').read_text();driver=original.replace(str(base),str(packet))
driver=driver.replace("await runCase('B-pixel','?pixelCairn=1')","await runCase('B-pixel','?pixelCairn=1&cairnPixelDiagnostic=1')")
needle='const resource=await page.evaluate(()=>({now:performance.now(),'
assert driver.count(needle)==1
replacement="const resource=await page.evaluate(()=>({diagnostic:(()=>{const raw=document.querySelector('canvas')?.dataset.cairnPixelDiagnostic;if(!raw)return {absent:true};try{return JSON.parse(raw);}catch(error){return {parseError:String(error),raw};}})(),now:performance.now(),"
driver=driver.replace(needle,replacement)
needle='assetResources:resource.entries,assetResponseObserved:';assert driver.count(needle)==1
driver=driver.replace(needle,'pixelEligibilityDiagnostic:resource.diagnostic,assetResources:resource.entries,assetResponseObserved:')
driver=driver.replace("scope:'FIXED REPRO supplement, Initiate seed9592029, same frozen89/57 stage queryoff/on.","scope:'FIXED REPRO R8-composite reload eligibility supplement, Initiate seed9592029, same frozen89/57 stage default versus pixel plus explicit read-only diagnostic. Selector evidence is not paint/cel certification.")
(packet/'driver-paired-r1.mjs').write_text(driver)
supervisor=(base/'supervise-paired-r3-final.py').read_text().replace(str(base/'driver-paired-r3-final.mjs'),str(packet/'driver-paired-r1.mjs'))
ast.parse(supervisor);(packet/'supervise-paired-r1.py').write_text(supervisor)
expected=json.loads((base/'EXPECTED-CANDIDATE.json').read_text())
expected.update(stage=freeze['stage'],freezePath=str(freezePath),freezeSHA256=hashlib.sha256(freezePath.read_bytes()).hexdigest(),sourceDigest=freeze['sourceDigest'],outputsDigest=freeze['outputsDigest'],actualPacket='/workspace/scratch/cairn-reload-diagnostic-actual-r1',port=4816,queryModes=['','?pixelCairn=1&cairnPixelDiagnostic=1'],runtimeGranted=False)
(packet/'EXPECTED-CANDIDATE.json').write_text(json.dumps(expected,indent=2)+'\n')
diff=''.join(difflib.unified_diff(original.splitlines(True),driver.splitlines(True),fromfile='retained-R3/driver',tofile='new-R8-diagnostic/driver'))
(packet/'EXACT-DRIVER-DELTA.patch').write_text(diff)
(packet/'SOURCE-REUSE.json').write_text(json.dumps({'oldDriverSHA256':hashlib.sha256(original.encode()).hexdigest(),'oldSupervisorSHA256':hashlib.sha256((base/'supervise-paired-r3-final.py').read_bytes()).hexdigest(),'changes':['new literal control paths and exact R8-composite freeze','explicit B diagnostic query','read-only reload canvas diagnostic snapshot','honest scope label'],'safetySupervisorDelta':'literal driver path only','nativeActionsCaptureBudgetsUnchanged':True,'oldDraftsUnmodified':True,'runtimeExecuted':False},indent=2)+'\n')
protocol='''# R8-composite Cairn reload eligibility comparison

One fresh default/pixel pair uses the exact strict-built89-input/57-output R8 composite. Entire current issued-command main is preserved; only the existing optional study footer is added. The separately source-gated arena From-fit hypothesis and explicit canvas diagnostic are unselected experiments. The native R5 artwork is unchanged and previously rejected; no art selection follows from this test.

The exact retained R3 native seed9592029/default Initiate actions, six PNGs/context/twelve total, native selected cancellation, actual binding/free command/Scour/end-turn response/Inspect/reduced cancellation/local reload+Continue remain unchanged. Both contexts are fresh; no fixture, reducer import, storage write, reroll, forced outcome/asset/geometry or extra browser. Default query is empty; B uses pixelCairn=1&cairnPixelDiagnostic=1. The only new receipt reads optional canvas.dataset.cairnPixelDiagnostic during already-existing initial/natural reload observations. Missing/malformed diagnostics stay recorded; neither mode nor a successful fix is forced. Selector mode/fit/image flags do not certify decoded/painted pixels or a pose; independent original PNG and published geometry inspection is mandatory.

Initial receipt remains after the existing native Continue helper settle, relative to its actual releaseObservedAtMs. Existing at-most-six250ms natural waits and adjacent measured size agreement remain unchanged; response completion/adjacent dimensions are not decode, painted pixels, stable position or contact proof. Requested animation labels remain uncertified. This short source-informed supplement is not a primary300/human-enjoyment measure. Compare new reload outcomes against retained actual R3 fallback honestly; its R7 main is a different source baseline.

All safety/admission/lifecycle supervisor bodies remain exact apart from the new literal driver path:896MiB total aggregate cgroup delta+512MiB reserve, Node heap256, driver90s/whole120s, cancel110/TERM115/reap119, disk/current/max/events and owned PID/start-time/live/Z checks. Fresh admission, independent source/build gates and a ROOT explicit one-attempt grant are required. No automatic retry or next browser. Preserve actual failures and close all tools before review.

Exact future CLI (ungranted):
python3 /workspace/scratch/cairn-reload-diagnostic-caller-root-r1/supervise-paired-r1.py /workspace/scratch/first-five-opening-cairn-reload-eligibility-stage-r1 /workspace/scratch/first-five-opening-cairn-reload-eligibility-runtime-freeze-root-r1.json /workspace/scratch/cairn-reload-diagnostic-actual-r1 4816
'''
(packet/'PROTOCOL.md').write_text(protocol)
rows=[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(packet.iterdir()) if p.is_file()]
(packet/'MANIFEST.json').write_text(json.dumps({'scope':'Source-sealed finite R8-composite reload diagnostic caller, no actual execution','bodies':rows},indent=2)+'\n')
print(json.dumps({'packet':str(packet),'bodies':len(rows),'driverSHA256':hashlib.sha256(driver.encode()).hexdigest(),'supervisorSHA256':hashlib.sha256(supervisor.encode()).hexdigest(),'manifestSHA256':hashlib.sha256((packet/'MANIFEST.json').read_bytes()).hexdigest(),'runtimeExecuted':False}))
