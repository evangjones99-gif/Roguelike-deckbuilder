import os,json,hashlib,shutil
from pathlib import Path
base=Path('/workspace/scratch/first-five-opening-command-guidance-stage-r8')
stage=Path('/workspace/scratch/first-five-opening-cairn-reload-eligibility-stage-r1')
freeze=json.loads(Path('/workspace/scratch/first-five-opening-command-guidance-runtime-freeze-root-r8.json').read_text())
art=Path('/workspace/scratch/first-five-opening-cairn-pixel-sheet-r5-stage-r7')
sources={
 'src/arena.ts':Path('/workspace/scratch/standard-sol-cairn-reload-eligibility-author-r1/candidate/src/arena.ts'),
 'src/main.ts':Path('/workspace/scratch/cairn-reload-r8-main-rebase-root-r1/candidate/src/main.ts'),
 'src/cairn-pixel.ts':art/'src/cairn-pixel.ts',
 'public/art/cairn-hound-pixel-r5.png':art/'public/art/cairn-hound-pixel-r5.png'}
replacements={'src/arena.ts':'35f243bbaef2ba06ea3fc440ed5426d7235550ce45a1059abf8fe44a1fb5fa05','src/main.ts':'1749bfb05468b5d133a6019eb3fb272340918d94dc0b9e1867b0e7b8222f8f4e','src/cairn-pixel.ts':'100c8bb88810f00c5853b4ea785b9f18f5630a452520eed3367c63216690114e','public/art/cairn-hound-pixel-r5.png':'940cd0c47026565346b94490e49743a9a3c67b0565155d0c20e6ec52884ed3a8'}
def sha(p):
 h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 try:
  st=os.fstat(fd)
  while b:=os.read(fd,65536):h.update(b)
  assert os.fstat(fd)==st
 finally:os.close(fd)
 return h.hexdigest()
assert freeze['sourceDigest']=='7cde12170459c48e771c2192e2d25be6ac7a366ce0c63ed4ca484be488362c4e'
for rel,h in freeze['inputs'].items():assert sha(base/rel)==h,rel
for rel,h in replacements.items():assert sha(sources[rel])==h,rel
stage.mkdir(mode=0o700)
for current,names,files in os.walk(base,followlinks=False):
 names[:]=[n for n in names if n not in ['dist','node_modules','public']]
 for name in names:assert not (Path(current)/name).is_symlink()
 for name in files:
  old=Path(current)/name;assert not old.is_symlink()
  rel=old.relative_to(base).as_posix();target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(sources.get(rel,old),target)
for rel,source in sources.items():
 if rel.startswith('public/'):continue
 target=stage/rel
 if not target.exists():target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
# No art edits: link only the existing immutable public directory, never write through it.
(stage/'public').symlink_to((art/'public').resolve(),target_is_directory=True)
(stage/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules',target_is_directory=True)
fixture='reviews/world-rng-v0.5/golden-vectors-r1.json'
target=stage/fixture;target.parent.mkdir(parents=True,exist_ok=True)
if not target.exists():shutil.copyfile(Path('/workspace/Roguelike-deckbuilder')/fixture,target)
inputs=dict(sorted({**freeze['inputs'],**replacements}.items()))
for rel,h in inputs.items():assert sha(stage/rel)==h,rel
for rel,h in freeze['inputs'].items():assert sha(base/rel)==h,rel
record={'stage':str(stage),'status':'CAIRN RELOAD ELIGIBILITY ON R8 COMPOSITE; UNBUILT; UNPROMOTED','baselineStage':str(base),'baselineSourceDigest':freeze['sourceDigest'],'inputs':inputs,'inputCount':len(inputs),'sourceDigest':hashlib.sha256(json.dumps(inputs,separators=(',',':')).encode()).hexdigest(),'onlyChangedInputs':list(replacements),'publicCopyScope':'Read-only reference to exact retained R5 study public; no media/stage aliases written','baselineUnchanged':True,'limitations':'Main preserves entire R8 command plus existing optional study footer. Source-gated arena change is an unconfirmed reload hypothesis; no actual fix or art acceptance.'}
path=Path('/workspace/scratch/first-five-opening-cairn-reload-eligibility-assembly-root-r1.json')
with path.open('x') as f:json.dump(record,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({k:v for k,v in record.items() if k!='inputs'}))
