"""Read-only finite historical dist media identity intake; never links or removes."""
import os, stat, json, hashlib, time, resource
from pathlib import Path
OUT=Path('/workspace/scratch/standard-sol-historical-dist-media-dedup-proposal-r1')
NAMES=['first-five-opening-stage-r2','first-five-opening-hand-cue-stage-r1','first-five-opening-hand-cue-terminal-stage-r1','first-five-opening-readout-stage-r1']
FREEZES=['first-five-opening-runtime-freeze-root-r2.json','first-five-opening-hand-cue-runtime-freeze-root-r1.json','first-five-opening-hand-cue-terminal-runtime-freeze-root-r1.json','first-five-opening-readout-runtime-freeze-root-r1.json']
resource.setrlimit(resource.RLIMIT_DATA,(64*1048576,64*1048576))
CG=Path('/sys/fs/cgroup');BASE=int(os.environ['DEDUP_INTAKE_BASE']);MAX=int((CG/'memory.max').read_text());START=time.monotonic();ROWS=[];FILES=[];CONTROLS=[];PARENTS=[]
def guard(label):
 c=int((CG/'memory.current').read_text());m=int((CG/'memory.max').read_text());v=os.statvfs(OUT)
 row={'label':label,'current':c,'maximum':m,'workDelta':c-BASE,'headroom':m-c,'diskFree':v.f_bavail*v.f_frsize,'elapsed':round(time.monotonic()-START,6)};ROWS.append(row)
 assert m==MAX and MAX-c>=512*1048576 and c-BASE<=64*1048576 and row['diskFree']>=1048576 and row['elapsed']<=60,row
 return row
def meta(s):return {'dev':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'nlink':s.st_nlink,'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'allocated':s.st_blocks*512,'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
def attrs(fd):
 target='/proc/self/fd/'+str(fd)
 return {k:os.getxattr(target,k).hex()for k in sorted(os.listxattr(target))}
def anchor(path):
 fds=[];fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW);fds.append(fd);walk=''
 try:
  for part in Path(path).parts[1:]:
   fd=os.open(part,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);fds.append(fd);walk+='/'+part
   PARENTS.append({'path':walk,'metadata':meta(os.fstat(fd)),'xattrs':attrs(fd)})
  return fds
 except BaseException:
  for fd in reversed(fds):os.close(fd)
  raise
def small(path):
 chain=anchor(str(Path(path).parent))
 try:
  fd=os.open(Path(path).name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=chain[-1])
  try:
   before=meta(os.fstat(fd));assert before['size']<=262144
   data=bytearray()
   while True:
    b=os.read(fd,65536)
    if not b:break
    data.extend(b);guard('control64KiB')
   assert before==meta(os.fstat(fd))
   CONTROLS.append({'path':path,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'metadata':before,'xattrs':attrs(fd)})
   return bytes(data)
  finally:os.close(fd)
 finally:
  for fd in reversed(chain):os.close(fd)
def media(stage,relative,expected):
 path='/workspace/scratch/'+stage+'/dist/'+relative;chain=anchor(str(Path(path).parent))
 try:
  fd=os.open(Path(path).name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=chain[-1])
  try:
   before=meta(os.fstat(fd));a=attrs(fd);assert stat.S_ISREG(before['mode']) and before['nlink']==1
   h=hashlib.sha256();count=0
   while True:
    b=os.read(fd,65536)
    if not b:break
    count+=len(b);h.update(b);guard('media64KiB')
   assert count==before['size'] and before==meta(os.fstat(fd)) and a==attrs(fd)
   assert h.hexdigest()==expected
   FILES.append({'stage':stage,'relative':relative,'path':path,'bytes':count,'sha256':h.hexdigest(),'metadata':before,'xattrs':a,'fdMetadataExactAfterRead':True})
  finally:os.close(fd)
 finally:
  for fd in reversed(chain):os.close(fd)
def publish(name,body):
 data=(json.dumps(body,sort_keys=True,indent=2)+'\n').encode();fd=os.open(OUT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  v=memoryview(data)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
def run():
 assert MAX-BASE>=576*1048576;guard('initial')
 expectedNames=None
 for stage,freeze in zip(NAMES,FREEZES):
  x=json.loads(small('/workspace/scratch/'+freeze));assert x['stage']=='/workspace/scratch/'+stage
  rows={k:v for k,v in x['outputs'].items()if k.startswith(('art/','audio/','dist/art/','dist/audio/'))and k.endswith(('.png','.wav'))}
  rows={k.removeprefix('dist/'):v for k,v in rows.items()}
  assert len(rows)==50,(stage,list(x['outputs'])[:5],len(rows))
  if expectedNames is None:expectedNames=rows
  else:assert rows==expectedNames
  for relative,expected in sorted(rows.items()):media(stage,relative,expected)
 for p in ['/workspace/Roguelike-deckbuilder/AGENTS.md','/workspace/Roguelike-deckbuilder/scripts/build.mjs','/workspace/Roguelike-deckbuilder/vite.config.ts','/workspace/Roguelike-deckbuilder/package.json']:small(p)
 targets=[r for r in FILES if r['stage']!=NAMES[0]]
 same=['dev','mode','uid','gid','size']
 for r in targets:
  a=next(a for a in FILES if a['stage']==NAMES[0]and a['relative']==r['relative'])
  assert all(r['metadata'][k]==a['metadata'][k]for k in same)and r['xattrs']==a['xattrs']
 consumers=[];errors=[]
 for pid in os.listdir('/proc'):
  if not pid.isdecimal():continue
  try:
   for n in os.listdir('/proc/'+pid+'/fd'):
    try:
     dest=os.readlink('/proc/'+pid+'/fd/'+n)
     if any(dest.startswith('/workspace/scratch/'+s+'/')for s in NAMES):consumers.append({'pid':int(pid),'fd':n,'target':dest})
    except (FileNotFoundError,PermissionError)as e:errors.append(type(e).__name__)
  except (FileNotFoundError,PermissionError)as e:errors.append(type(e).__name__)
 final=guard('final')
 publish('IDENTITIES-r2.json',{'status':'read-only exact200 historical media identities; conditional physical dedup proposal only','anchor':NAMES[0],'targetStages':NAMES[1:],'files':FILES,'heldParentObservations':PARENTS,'controls':CONTROLS,'prospectiveAllocatedSavings':sum(r['metadata']['allocated']for r in targets),'prospectiveLogicalDuplicateBytes':sum(r['bytes']for r in targets),'currentOpenConsumerObservations':consumers,'procInspectionErrorCounts':{e:errors.count(e)for e in set(errors)},'consumerQualification':'Single /proc FD observation, not exhaustive absence/writer or future process proof; known actors/holds require Root judgment.','allOwnFDsClosed':True,'finalGuard':final})
 publish('RESOURCE-ROWS-r2.json',{'budgetTotalBytes':67108864,'reserveBytes':536870912,'allRows':ROWS,'qualification':'Recurring sampled cgroup work delta including file-cache effects during own phase, not continuous external child accounting. No advice/cache mutation.'})
 print(json.dumps({'files':len(FILES),'targetFiles':len(targets),'allocatedSavings':sum(r['metadata']['allocated']for r in targets),'rows':len(ROWS),'final':final,'allOwnFDsClosed':True}))
if __name__=='__main__':
 try:run()
 except BaseException as e:
  publish('FAILURE-r2.json',{'error':repr(e),'filesCompleted':FILES,'resourceRows':ROWS,'allOwnFDsClosedAfterFinally':True,'noMutation':True});raise
