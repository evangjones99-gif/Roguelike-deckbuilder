import os,resource,json,zlib,struct,hashlib,ast
resource.setrlimit(resource.RLIMIT_DATA,(32*1048576,32*1048576))
ROOT='/workspace/scratch/standard-sol-bone-thrall-pixel-assets-author-r2'
FINAL=ROOT+'/draw-r2'
OLD='/workspace/scratch/standard-sol-bone-thrall-pixel-assets-author-r1/draw-r2'
C=int(open('/sys/fs/cgroup/memory.current').read());M=int(open('/sys/fs/cgroup/memory.max').read());assert M-C>=32*1048576+512*1048576

def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 try:
  size=os.fstat(fd).st_size;assert size<=65536;return os.read(fd,size+1)
 finally:os.close(fd)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,b):
 if not isinstance(b,bytes):b=(json.dumps(b,indent=2,sort_keys=True)+'\n').encode()
 fd=os.open(ROOT+'/'+n,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:assert os.write(fd,b)==len(b);os.fsync(fd)
 finally:os.close(fd)
def decode(parent,n):
 b=read(parent+'/'+n);assert b[:8]==b'\x89PNG\r\n\x1a\n';pos=8;chunks=[];compressed=b'';pal=None;alpha=None
 while pos<len(b):
  length=struct.unpack('>I',b[pos:pos+4])[0];k=b[pos+4:pos+8];data=b[pos+8:pos+8+length];crc=struct.unpack('>I',b[pos+8+length:pos+12+length])[0];assert zlib.crc32(k+data)&0xffffffff==crc;pos+=length+12;chunks.append(k.decode())
  if k==b'IHDR':w,h,d,t,c,f,i=struct.unpack('>IIBBBBB',data);assert (d,t,c,f,i)==(8,3,0,0,0)
  if k==b'PLTE':pal=data
  if k==b'tRNS':alpha=data
  if k==b'IDAT':compressed+=data
 assert chunks==['IHDR','PLTE','tRNS','IDAT','IEND'] and pos==len(b) and alpha==bytes([0]+[255]*15)
 raw=zlib.decompress(compressed);assert len(raw)==h*(w+1);assert all(raw[y*(w+1)]==0 for y in range(h));p=b''.join(raw[y*(w+1)+1:(y+1)*(w+1)]for y in range(h));assert max(p)<16;return p,[w,h],pal,sha(b)
def chunk(k,b):return struct.pack('>I',len(b))+k+b+struct.pack('>I',zlib.crc32(k+b)&0xffffffff)
def png(w,h,p,pal):
 raw=b''.join(b'\0'+p[y*w:(y+1)*w]for y in range(h))
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,3,0,0,0))+chunk(b'PLTE',pal)+chunk(b'tRNS',bytes([0]+[255]*15))+chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b'')
meta=json.loads(read(FINAL+'/ASSET-METADATA.json'));sheet,size,pal,sheetsha=decode(FINAL,'bone-thrall-sheet.png');old,sizeold,palold,oldsha=decode(OLD,'bone-thrall-sheet.png');assert size==sizeold==[448,64] and pal==palold and sha(pal)=='6a54ed67ecf117cef1ba5306a82e74bdff792a3f1a328871d04cbf568bf6a1dc'
poses=ast.literal_eval(ast.parse(read(FINAL+'/poses-source.py')).body[0].value);rows=[];landmarks=[]
for i,(r,spec)in enumerate(zip(meta['frames'],poses)):
 p,s,p2,h=decode(FINAL,'bone-thrall-'+r['name']+'.png');assert s==[64,64] and p2==pal;assert p==b''.join(sheet[y*448+i*64:y*448+(i+1)*64]for y in range(64));assert sha(p)==r['pixelSHA256'];coords=[(j%64,j//64)for j,v in enumerate(p)if v];bounds=[min(x for x,y in coords),min(y for x,y in coords),max(x for x,y in coords)+1,max(y for x,y in coords)+1];assert bounds==r['opaqueBounds'];assert len(coords)==r['opaquePixels'];assert all(p[y*64+x]for x,y in r['footContactPoints']+[r['clawContactPixelIndex']]);rows.append({'name':r['name'],'pngSHA256':h,'pixelSHA256':sha(p),'opaqueBounds':bounds,'opaquePixels':len(coords),'opaqueFeetAndClaw':True})
 landmarks.append({k:spec[k]for k in ['name','feet','impact','skull','jaw','sockets','nose','crack','torso','ribVoids','ribs','sternum','spine','pelvis','pelvisHoles','bones','knuckles','claws']})
preview,s,p2,previewsha=decode(FINAL,'bone-thrall-preview-2x.png');assert s==[512,256] and p2==pal
for i,r in enumerate(rows):
 p,_,_,_=decode(FINAL,'bone-thrall-'+r['name']+'.png');ox=i%4*128;oy=i//4*128
 for y in range(64):
  for x in range(64):assert all(preview[(oy+y*2+dy)*512+ox+x*2+dx]==p[y*64+x]for dy in range(2)for dx in range(2))
assert len({r['pixelSHA256']for r in rows})==7
comparison=bytearray(896*256)
for row,pixels in enumerate([old,sheet]):
 for y in range(64):
  for x in range(448):
   for dy in range(2):
    start=(row*128+y*2+dy)*896+x*2;comparison[start:start+2]=bytes([pixels[y*448+x]])*2
put('COMPARATIVE-R1-R2-NATIVE-2X.png',png(896,256,comparison,pal))
roundtrip,sz,p2,comparsha=decode(ROOT,'COMPARATIVE-R1-R2-NATIVE-2X.png');assert sz==[896,256]and roundtrip==comparison and p2==pal
union=meta['fullPoseOpaqueUnion'];anchor=meta['placementAnchor'];L=(anchor[0]-union[0])*2;R=(union[2]-anchor[0])*2;T=(anchor[1]-union[1])*2;B=(union[3]-anchor[1])*2
assert (L,R,T,B)==(50,52,112,6)
put('NATIVE-AUDIT.json',{'pass':True,'scope':'CRC/nativeindexed8/palette/transparency/cell-sheet/hash/count/bounds/opaquefeet-claw/exact2xpreview and comparative indices; no artistic/runtime acceptance','sheetSHA256':sheetsha,'previewSHA256':previewsha,'paletteSHA256':sha(pal),'usedIndices':sorted(set(sheet)),'frames':rows,'fullUnion':union,'anchor':anchor,'extents2x':{'left':L,'right':R,'top':T,'bottom':B},'conservativeBothFacingsWith4pxMargin':[max(L,R)*2+8,T+B+8],'runtimeFitProven':False,'comparison':{'path':ROOT+'/COMPARATIVE-R1-R2-NATIVE-2X.png','sha256':comparsha,'top':'exact retained R1 finaldraw-r2','bottom':'new R2 finaldraw-r2','eachNativeScale':2,'oldSHA256':oldsha,'newSHA256':sheetsha,'noFilteringOrArtRepair':True},'maximum':M,'finalCurrent':int(open('/sys/fs/cgroup/memory.current').read())})
put('ANATOMY-LANDMARKS.json',{'nativePixelIndices':True,'timingOrTargetProof':False,'frames':landmarks})
assert int(open('/sys/fs/cgroup/memory.max').read())==M and M-int(open('/sys/fs/cgroup/memory.current').read())>=512*1048576 and int(open('/sys/fs/cgroup/memory.current').read())-C<=32*1048576
print(json.dumps({'nativeAuditPass':True,'sheetSHA256':sheetsha,'previewSHA256':previewsha,'comparisonSHA256':comparsha,'union':union,'envelope':[max(L,R)*2+8,T+B+8]}))
