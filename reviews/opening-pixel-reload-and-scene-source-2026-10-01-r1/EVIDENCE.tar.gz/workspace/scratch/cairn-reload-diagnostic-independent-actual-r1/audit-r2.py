import os,json,hashlib,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
P=Path('/workspace/scratch/cairn-reload-diagnostic-actual-r1')
O=Path('/workspace/scratch/cairn-reload-diagnostic-independent-actual-r1')
C=Path('/workspace/scratch/cairn-reload-diagnostic-caller-root-r1')
F=Path('/workspace/scratch/first-five-opening-cairn-reload-eligibility-runtime-freeze-root-r1.json')
CG=Path('/sys/fs/cgroup');BASE=int((CG/'memory.current').read_text());MAX=int((CG/'memory.max').read_text())
assert MAX-BASE>=(24+512)*1048576
def guard():
 c=int((CG/'memory.current').read_text());assert int((CG/'memory.max').read_text())==MAX and MAX-c>=512*1048576 and c-BASE<=24*1048576
 return dict(current=c,maximum=MAX,headroom=MAX-c,delta=c-BASE,maxRSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  assert os.fstat(fd).st_size<=1048576
  out=bytearray()
  while True:
   x=os.read(fd,32768)
   if not x:break
   out.extend(x)
  return bytes(out)
 finally:os.close(fd)
def pin(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);h=hashlib.sha256();n=0
 try:
  while True:
   x=os.read(fd,32768)
   if not x:break
   n+=len(x);h.update(x)
 finally:os.close(fd)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
def sha(d):return hashlib.sha256(d).hexdigest()
def j(p):return json.loads(read(p))
r=j(P/'RESULT.json');v=j(P/'VISUAL-RESULT.json');f=j(F);b=j(P/'BYTE-AUDIT-before.json');a=j(P/'BYTE-AUDIT-after.json');s=j(P/'SERVED-BYTE-AUDIT.json')
def rows(q):return sorted((x.get('path',x.get('name')),x['bytes'],x['sha256']) for x in q)
for side in ['inputs','outputs']:
 assert rows(b[side])==rows(a[side])
 assert {q['path']:q['sha256'] for q in b[side]}==f[side]
assert rows(b['controls'])==rows(a['controls'])
assert {q['path']:q['sha256'] for q in s['served']}==f['outputs']
assert len(b['inputs'])==89 and len(b['outputs'])==57 and len(s['served'])==57
assert sha(read(F))=='d238582109181c22194bbc4447229fce5afd38c163af063a0f432961d72c9abc'
manifest=j(C/'MANIFEST.json');assert sha(read(C/'MANIFEST.json'))=='f4195e1343c13353134775d39e4047fe27300c649e002ce984b59abaffef1eee'
controls=[]
for q in manifest['bodies']:
 t=pin(C/q['name']);assert t['bytes']==q['bytes'] and t['sha256']==q['sha256'];controls.append(t)
rawpins=[]
for p in sorted(P.iterdir()):
 assert p.is_file();rawpins.append(pin(p));guard()
captures=[]
for q in v['captures']:
 t=pin(Path(q['path']));assert t['sha256']==q['sha256'] and t['bytes']==q['bytes'];captures.append(t)
assert len(captures)==12 and v['browser']==v['server']=='CLOSED' and v['mechanicalPass'] and not v['pageErrors']
canon=[]
for label in ['C0','C1','C2','C2S','C3','C4']:
 aa=read(P/f'A-current-{label}-OPAQUE-SAVE.json');bb=read(P/f'B-pixel-{label}-OPAQUE-SAVE.json');assert aa==bb
 for c,blob in zip(v['contexts'],[aa,bb]):assert blob.decode()==c['checkpoints'][label]['raw'] and sha(blob)==c['checkpoints'][label]['sha256']
 canon.append(dict(label=label,sha256=sha(aa),byteEqual=True))
assert canon==[dict(label=q['label'],sha256=q['aSHA'],byteEqual=q['byteEqual']) for q in v['canonicalComparisons']]
observations=[]
for c in v['contexts']:
 assert c['captureCount']==6 and c['seed']==9592029 and c['reducedSelectedCancel']
 for obs in c['observations']:
  row=obs['row'];assert row['viewport']['width']==1440 and row['viewport']['height']==900 and row['scroll']==dict(x=0,y=0,width=1440,height=900)
 observations.append(dict(case=c['name'],count=len(c['observations']),all1440x900Scroll0=True,binding=c['bindingResult'],command=c['commandResult'],response=c['response']))
trust=[]
for q in v['actions']:
 ev=q.get('events',[])
 if 'point' in q:
  for typ in ['pointerdown','pointerup']:
   matches=[e for e in ev if e['type']==typ and e['trusted']];assert matches
   assert any(abs(e['x']-q['point']['x'])<0.01 and abs(e['y']-q['point']['y'])<0.01 for e in matches)
 elif 'key' in q:assert any(e['type']=='keydown' and e['trusted'] and e['key']==q['key'] for e in ev)
 trust.append(dict(case=q['case'],label=q['label'],point=q.get('point'),key=q.get('key'),beforeSHA=q.get('beforeSHA'),afterSHA=q.get('afterSHA')))
allrows=r['samples']; initial=r['initial'];final=r['final']
resourceChecks=dict(allRowsWork=all(t['current']-initial['current']<=896*1048576 for t in allrows),allRowsReserve=all(t['headroom']>=512*1048576 for t in allrows),allRowsMax=all(t['maximum']==initial['maximum'] for t in allrows),allRowsDisk=all(t['free']>=1048576 for t in allrows),finalWork=final['current']-initial['current']<=896*1048576,finalReserve=final['headroom']>=512*1048576,finalMax=final['maximum']==initial['maximum'],finalDisk=final['free']>=1048576,eventsUnchanged=r['memory_events_before']==r['memory_events_after'])
assert all(resourceChecks.values()) and all(r['checks'].values()) and r['exit_code']==0 and r['normal_wait'] and not r['live_remaining'] and not r['cleanup_errors']
reload=[json.loads(x) for x in read(P/'RELOAD-BOUNDS-ASSET.jsonl').decode().splitlines()]
assert len(reload)==4
bp=[x for x in reload if x['case']=='B-pixel'];assert len(bp)==2 and all(x['publishedCairn']['body']['width']==98 and x['publishedCairn']['body']['height']==86 for x in bp)
for x in bp:
 d=next(q for q in x['pixelEligibilityDiagnostic']['regions'] if q['uid']=='a3')
 assert d['selectedMode']=='pixel' and d['blend']==1 and not d['fromRequired'] and not d['fits']['from'] and d['fits']['current'] and d['fits']['target'] and d['image']==dict(present=True,complete=True,naturalWidth=640,naturalHeight=64)
receipt=dict(scope='One finite independently reviewed R8-composite trial, personal all12PNG judgment is separate from mechanical proof',source=f['sourceDigest'],outputs=f['outputsDigest'],inputCount=89,outputCount=57,freeze=pin(F),callerControls=controls,rawPacketPins=rawpins,rawBodyCount=len(rawpins),rawBytes=sum(q['bytes'] for q in rawpins),maps=dict(beforeAfterFreezeInputs=True,beforeAfterFreezeOutputs=True,servedFreeze57=True,controlsBeforeAfter=True),canonical=canon,observations=observations,trustedNativeActions=trust,captures=captures,reload=reload,resources=dict(recomputed=resourceChecks,samples=len(allrows),peakDelta=max(q['current']-initial['current'] for q in allrows),minHeadroom=min(q['headroom'] for q in allrows),initial=initial,final=final,whole=r['whole_seconds'],normalWait=r['normal_wait'],knownIdentities=len(r['owned_observed']),live=r['live_remaining'],zombies=r['tracked_zombies'],checks=r['checks']),lifecycle=read(P/'LIFECYCLE.jsonl').decode(),sourceReviewAdmission=dict(current=BASE,maximum=MAX,headroom=MAX-BASE,work24MiB=True,reserve512MiB=True),guardFinal=guard(),allOwnFDsClosed=True,atimeQualification='Native view_image may change atime; independent pins assert bodies, not full historical metadata',limits=['No forced state or geometry','No certified animation cels/contact/all10/death','Diagnostic selector/image.complete/resource response do not certify painted pixels or RCA','No300s/humanfun/artselection'])
body=(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode();fd=os.open(O/'RECEIPTS.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
try:
 view=memoryview(body)
 while view:view=view[os.write(fd,view):]
 os.fsync(fd)
finally:os.close(fd)
print(json.dumps(dict(receiptSHA256=sha(body),rawBodies=len(rawpins),rawBytes=sum(q['bytes'] for q in rawpins),nativeActions=len(trust),guardFinal=guard())))
