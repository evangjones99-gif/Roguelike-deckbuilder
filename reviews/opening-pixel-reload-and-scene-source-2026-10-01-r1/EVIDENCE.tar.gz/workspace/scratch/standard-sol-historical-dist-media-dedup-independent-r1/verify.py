import os, json, hashlib, stat, time
from pathlib import Path
OUT=Path(__file__).parent
PROP=Path('/workspace/scratch/standard-sol-historical-dist-media-dedup-proposal-r1')
CG=Path('/sys/fs/cgroup')
BASE=int((CG/'memory.current').read_text()); MAX=int((CG/'memory.max').read_text())
EVENTS=(CG/'memory.events').read_text(); START=time.monotonic(); ROWS=[]; PINS=[]; CONTROL_DRIFT=[]
assert MAX-BASE>=603979776
def guard(label):
 c=int((CG/'memory.current').read_text()); m=int((CG/'memory.max').read_text()); free=os.statvfs(OUT); free=free.f_bavail*free.f_frsize
 hwm=int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmHWM:')))*1024
 row=dict(label=label,current=c,maximum=m,headroom=m-c,delta=c-BASE,free=free,elapsed=time.monotonic()-START,ownVmHWM=hwm); ROWS.append(row)
 assert m==MAX and m-c>=536870912 and c-BASE<=67108864 and hwm<=67108864 and free>=1048576 and row['elapsed']<=60,row
def meta(s):
 return dict(dev=s.st_dev,inode=s.st_ino,mode=s.st_mode,nlink=s.st_nlink,uid=s.st_uid,gid=s.st_gid,size=s.st_size,allocated=s.st_blocks*512,atime_ns=s.st_atime_ns,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def attrs(fd):
 return {k:os.getxattr(fd,k).hex() for k in sorted(os.listxattr(fd))}
def read(path,keep=False,limit=None):
 path=Path(path); chain=[]
 try:
  fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW);chain.append(fd)
  for p in path.parts[1:-1]:
   fd=os.open(p,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);chain.append(fd)
  fd=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=chain[-1]); chain.append(fd)
  before=meta(os.fstat(fd)); a=attrs(fd); assert stat.S_ISREG(before['mode'])
  if limit is not None:assert before['size']<=limit
  h=hashlib.sha256();n=0;data=bytearray()
  while True:
   b=os.read(fd,65536)
   if not b:break
   n+=len(b);h.update(b)
   if keep:data.extend(b)
   guard('read64KiB')
  assert n==before['size'] and meta(os.fstat(fd))==before and attrs(fd)==a
  assert meta(os.stat(path.name,dir_fd=chain[-2],follow_symlinks=False))==before
  pin=dict(path=str(path),sha256=h.hexdigest(),bytes=n,metadata=before,xattrs=a)
  PINS.append(pin);return pin,bytes(data)
 finally:
  for fd in reversed(chain):os.close(fd)
def small(p):return read(p,True,1048576)
def digest(m):return hashlib.sha256(json.dumps(dict(sorted(m.items())),separators=(',',':')).encode()).hexdigest()
def run():
 guard('initial');pin,body=small(PROP/'FROZEN.json');assert pin['sha256']=='a9cb7aac58f13dae6da23fd7d268f0eb1e13cf6778e250c7c2440aabc6552e6f';freeze=json.loads(body)
 bodies={}
 for r in freeze['bodies']:
  pin,b=small(PROP/r['name']);assert pin['sha256']==r['sha256'] and pin['bytes']==r['bytes'];bodies[r['name']]=b
  prior=r['metadata']; delta={k:[v,pin['metadata'][k]] for k,v in prior.items() if pin['metadata'][k]!=v}
  if delta:CONTROL_DRIFT.append(dict(path=pin['path'],delta=delta))
 identities=json.loads(bodies['IDENTITIES-r2.json']); files=identities['files'];assert len(files)==200
 stages=[identities['anchor']]+identities['targetStages'];assert len(stages)==4 and len(set(stages))==4
 maps={};controls=[]
 for control in identities['controls']:
  pin,b=small(control['path']);assert pin['sha256']==control['sha256'] and pin['bytes']==control['bytes']
  delta={k:[v,pin['metadata'][k]]for k,v in control['metadata'].items()if pin['metadata'][k]!=v}
  if delta:CONTROL_DRIFT.append(dict(path=pin['path'],delta=delta))
  if control['path'].endswith('freeze-root-r2.json') or 'runtime-freeze-root-r1.json' in control['path']:
   x=json.loads(b);assert x['stage'].split('/')[-1] in stages
   assert digest(x['inputs'])==x['sourceDigest'] and digest(x['outputs'])==x['outputsDigest']
   assert len(x['inputs'])==x['inputCount']==87 and len(x['outputs'])==x['outputCount']==56
   media={k:v for k,v in x['outputs'].items()if k.startswith(('art/','audio/'))and k.endswith(('.png','.wav'))};assert len(media)==50
   maps[x['stage'].split('/')[-1]]=media;controls.append(dict(path=control['path'],sourceDigest=x['sourceDigest'],outputsDigest=x['outputsDigest'],mediaCount=len(media),inputCount=87,outputCount=56))
 assert set(maps)==set(stages) and all(m==maps[stages[0]]for m in maps.values())
 observed=[];seen=set()
 for r in files:
  assert r['stage'] in stages and r['relative'] in maps[r['stage']]
  assert r['path']=='/workspace/scratch/'+r['stage']+'/dist/'+r['relative']
  assert (r['stage'],r['relative']) not in seen;seen.add((r['stage'],r['relative']))
  pin,_=read(r['path']);assert pin['sha256']==r['sha256']==maps[r['stage']][r['relative']] and pin['bytes']==r['bytes']
  assert pin['metadata']==r['metadata'] and pin['xattrs']==r['xattrs']=={} and pin['metadata']['nlink']==1 and pin['metadata']['mode']==stat.S_IFREG|0o600
  observed.append(pin)
 assert len({(p['metadata']['dev'],p['metadata']['inode'])for p in observed})==200
 target=[p for p in observed if '/'+stages[0]+'/'not in p['path']]
 logical=sum(p['bytes']for p in target);allocated=sum(p['metadata']['allocated']for p in target)
 assert len(target)==150 and allocated==identities['prospectiveAllocatedSavings']==91852800 and logical==identities['prospectiveLogicalDuplicateBytes']==91574463
 rows=json.loads(bodies['RESOURCE-ROWS-r2.json'])['allRows'];assert len(rows)==1966 and rows[-1]==identities['finalGuard']
 baselines={r['current']-r['workDelta']for r in rows};assert len(baselines)==1
 for r in rows:assert r['maximum']==MAX and r['headroom']==MAX-r['current'] and r['workDelta']<=67108864 and r['headroom']>=536870912 and r['diskFree']>=1048576 and 0<=r['elapsed']<=60
 assert MAX-next(iter(baselines))>=603979776
 assert all(rows[i]['elapsed']<=rows[i+1]['elapsed']for i in range(len(rows)-1))
 assert not identities['currentOpenConsumerObservations'] and identities['procInspectionErrorCounts']['PermissionError']==4333
 guard('final');assert (CG/'memory.events').read_text()==EVENTS
 result=dict(status='FULL200_BYTE_METADATA_XATTR_MAP_VERIFICATION_PASS',files=200,recipients=150,anchorMedia=50,artCountPerStage=sum(k.startswith('art/')for k in maps[stages[0]]),audioCountPerStage=sum(k.startswith('audio/')for k in maps[stages[0]]),prospectiveAllocatedSavings=allocated,logicalDuplicateBytes=logical,frozenMaps=controls,controlMetadataDrift=CONTROL_DRIFT,authorResource=dict(rows=1966,maxDelta=max(r['workDelta']for r in rows),minHeadroom=min(r['headroom']for r in rows),wholeSeconds=rows[-1]['elapsed'],eventsReceiptAbsent=True),ownResource=dict(rows=ROWS,eventsBefore=EVENTS,eventsAfter=(CG/'memory.events').read_text(),maxDelta=max(r['delta']for r in ROWS),minHeadroom=min(r['headroom']for r in ROWS),maxVmHWM=max(r['ownVmHWM']for r in ROWS)),allOwnFDsClosed=True,noTargetMutation=True)
 for name,body in [('INDEPENDENT-RECOMPUTATION.json',result),('READ-PINS.json',PINS)]:
  with open(OUT/name,'x')as f:json.dump(body,f,sort_keys=True,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in result.items()if k not in ['ownResource','frozenMaps']}))
if __name__=='__main__':
 try:run()
 except BaseException as e:
  with open(OUT/'METHOD-FAILURE.json','x')as f:json.dump(dict(error=repr(e),rows=ROWS,allOwnFDsClosed=True,noTargetMutation=True),f)
  raise
