"""Original indexed native courtyard. All contours/clusters are direct authored coordinates.
No image inputs, filters, resampling, imported illustration or game/engine access.
"""
import os,struct,zlib,json,hashlib,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(32*1048576,32*1048576))
ROOT='/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r1'
W,H=360,116
# First16 RGB entries exactly match native Cairn/Bone studies; background is opaque.
PAL=[(0,0,0),(14,20,23),(27,37,42),(43,58,62),(65,81,82),(77,91,88),(108,122,111),(149,158,137),(190,196,164),(57,91,91),(88,125,117),(135,173,145),(194,217,170),(85,75,59),(125,107,75),(213,176,98),
 (20,29,35),(32,43,49),(42,52,57),(56,64,65),(76,82,77),(99,102,88),(128,114,78),(170,132,73)]
BASE={'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text())}
assert BASE['maximum']-BASE['current']>=32*1048576+512*1048576
P=bytearray([16])*(W*H)
def guard():
 c=int(Path('/sys/fs/cgroup/memory.current').read_text());m=int(Path('/sys/fs/cgroup/memory.max').read_text());v=os.statvfs(ROOT);assert m==BASE['maximum'] and m-c>=512*1048576 and c-BASE['current']<=32*1048576 and v.f_bavail*v.f_frsize>=1048576;return {'current':c,'maximum':m,'headroom':m-c,'free':v.f_bavail*v.f_frsize}
def dot(x,y,col):
 assert 0<=x<W and 0<=y<H;P[y*W+x]=col

def line(a,b,col):
 x,y=a;xx,yy=b;dx=abs(xx-x);sx=1 if x<xx else -1;dy=-abs(yy-y);sy=1 if y<yy else -1;e=dx+dy
 while True:
  dot(x,y,col)
  if x==xx and y==yy:break
  q=2*e
  if q>=dy:e+=dy;x+=sx
  if q<=dx:e+=dx;y+=sy

def poly(points,col,edge=None):
 for y in range(min(p[1]for p in points),max(p[1]for p in points)+1):
  for x in range(min(p[0]for p in points),max(p[0]for p in points)+1):
   inside=False;j=len(points)-1
   for i,(xi,yi)in enumerate(points):
    xj,yj=points[j]
    if (yi>y+.5)!=(yj>y+.5)and x+.5<(xj-xi)*(y+.5-yi)/(yj-yi)+xi:inside=not inside
    j=i
   if inside:dot(x,y,col)
 if edge is not None:
  for a,b in zip(points,points[1:]+points[:1]):line(a,b,edge)
def cluster(points,col):
 for x,y in points:dot(x,y,col)
# Cold weather: small irregular cloud planes, not noise or a gradient.
poly([(59,8),(76,7),(87,10),(113,9),(127,12),(119,15),(83,14),(71,16),(58,13)],17)
poly([(207,3),(225,2),(237,5),(265,5),(277,8),(259,10),(231,8),(218,9),(204,6)],17)
poly([(91,19),(111,17),(137,18),(152,21),(146,23),(108,22)],2)
poly([(239,18),(265,16),(287,20),(291,23),(250,24)],2)
# Distant central abbey fragment recedes behind the open lane.
poly([(139,24),(141,12),(150,12),(151,4),(157,4),(161,8),(164,8),(164,1),(171,1),(171,13),(183,14),(187,6),(192,6),(192,11),(201,12),(205,20),(215,24)],1)
poly([(147,25),(150,17),(160,15),(169,17),(169,24)],2)
poly([(183,24),(185,18),(195,17),(199,22),(207,24)],2)
line((156,6),(160,10),3);line((167,3),(167,10),2)
# Quiet ground plane begins at the old abbey threshold, about20% down.
poly([(0,25),(94,23),(177,25),(269,23),(359,27),(359,115),(0,115)],17)
# Hand placed perspective slabs. Interior bands stay close in value.
FLOOR=[
 (16,[(0,50),(39,46),(55,49),(55,61),(30,67),(0,64)]),
 (18,[(0,68),(39,65),(55,69),(49,77),(0,81)]),
 (16,[(1,85),(47,80),(61,87),(54,99),(0,99)]),
 (18,[(0,104),(51,102),(62,110),(60,115),(0,115)]),
 (16,[(59,49),(122,47),(132,52),(124,63),(62,65)]),
 (16,[(56,81),(125,80),(135,86),(131,99),(57,98)]),
 (16,[(136,66),(178,63),(214,67),(219,77),(185,81),(139,79)]),
 (18,[(134,86),(160,84),(189,87),(218,84),(226,98),(214,106),(168,103),(135,105)]),
 (16,[(64,104),(130,103),(144,112),(142,115),(61,115)]),
 (16,[(225,51),(290,49),(301,55),(296,65),(233,66)]),
 (16,[(231,81),(299,78),(309,84),(306,99),(234,101)]),
 (16,[(230,105),(301,103),(314,112),(313,115),(230,115)]),
 (18,[(313,49),(359,51),(359,65),(330,68),(308,62)]),
 (16,[(312,72),(347,69),(359,75),(359,87),(326,88),(307,81)]),
 (18,[(313,93),(354,89),(359,93),(359,106),(327,107),(309,102)]),
 (16,[(320,111),(359,108),(359,115),(317,115)])]
for col,points in FLOOR:poly(points,col)
# Sparse joints/chips mainly at perimeter; no uniform texture grid/no random noise.
for a,b in [((0,82),(45,78)),((0,100),(45,99)),((49,80),(55,75)),((127,49),(138,45)),((220,49),(229,46)),((311,70),(348,67)),((320,91),(359,87)),((309,103),(328,108)),((153,113),(203,113))]:line(a,b,16)
# Ruined near-edge abbey blocks frame, rather than filling actor/readout space.
poly([(0,0),(39,0),(39,5),(44,5),(43,18),(51,21),(50,41),(55,42),(52,63),(43,68),(39,54),(0,53)],1)
poly([(0,4),(28,4),(30,13),(27,35),(32,40),(28,52),(0,52)],3)
poly([(31,9),(38,9),(36,16),(41,18),(39,32),(44,35),(40,48),(33,48)],2)
poly([(0,17),(13,18),(12,35),(20,39),(17,48),(0,48)],2)
# Broken lancet recess, not a pristine symmetric graphic.
poly([(6,33),(8,21),(12,15),(17,12),(23,14),(26,21),(24,34),(22,40),(9,40)],1)
line((8,22),(12,16),4);line((12,16),(17,13),4);line((18,13),(23,16),3);line((25,23),(23,35),2)
# Masonry beds/jagged highlights are individual purposeful clusters.
for a,b,col in [((0,10),(24,10),4),((0,24),(6,24),4),((27,23),(30,24),4),((0,38),(7,39),4),((0,51),(27,52),4),((31,10),(36,10),3),((35,36),(41,35),3)]:line(a,b,col)
for points,col in [([(2,7),(5,6),(7,8),(4,9)],4),([(21,5),(24,5),(23,8),(20,7)],2),([(29,35),(31,33),(34,35),(31,38)],3),([(2,45),(6,44),(8,47),(5,48)],3)]:poly(points,col)
# Far-right wall is a broken buttress and sloped rubble, not a mirrored left wall.
poly([(313,0),(339,0),(339,4),(348,4),(347,13),(354,17),(354,29),(359,29),(359,62),(343,60),(337,44),(328,40),(325,26),(309,24)],1)
poly([(320,5),(336,4),(337,13),(342,16),(340,35),(346,43),(345,54),(337,52),(329,36),(324,23)],3)
poly([(346,20),(354,24),(359,23),(359,48),(350,51),(343,42)],2)
poly([(322,13),(327,9),(332,10),(335,15),(334,28),(328,29),(324,24)],1)
line((324,13),(327,10),4);line((332,10),(334,14),4)
for a,b,col in [((321,7),(334,6),4),((335,18),(340,17),4),((329,31),(339,30),4),((340,43),(346,44),4),((349,28),(358,30),3),((352,43),(359,42),3)]:line(a,b,col)
# Collapsed stair at the threshold leads into the central lane, off-centre.
STEPS=[
 (2,[(135,27),(173,25),(193,27),(191,31),(142,32),(134,30)]),
 (3,[(141,32),(192,30),(203,34),(199,38),(144,39),(137,36)]),
 (2,[(137,39),(197,37),(209,40),(205,45),(144,46),(134,43)])]
for col,pts in STEPS:poly(pts,col)
line((136,27),(171,26),4);line((143,33),(188,31),4);line((141,40),(190,38),3)
poly([(165,28),(171,27),(175,30),(171,33),(163,32)],1)
poly([(200,39),(207,39),(212,44),(208,47),(200,45)],3)
# Left rubble and foreground slate edges avoid the reserved body centres.
for pts,col in [([(5,57),(20,54),(34,58),(30,66),(8,68)],3),([(36,59),(42,56),(50,60),(46,68),(35,65)],2),([(10,75),(16,71),(24,74),(22,79),(11,81)],3),([(335,60),(344,56),(353,62),(350,71),(336,69)],3),([(347,74),(354,69),(359,72),(359,82),(348,81)],2),([(3,109),(16,105),(26,109),(24,115),(0,115)],2),([(339,112),(346,107),(359,112),(359,115),(338,115)],2)]:
 poly(pts,col)
 line(pts[0],pts[1],4)
# Sparse weather and small age clusters are deliberately outside creature centres.
for a,b in [((103,3),(101,7)),((128,10),(126,14)),((228,12),(226,16)),((257,1),(255,5)),((296,8),(294,12))]:line(a,b,18)
cluster([(3,9),(4,9),(19,42),(20,42),(22,44),(338,35),(339,34),(341,35),(11,64),(13,65),(345,66)],5)
# Worn angular contract-cut mark in the empty lane; no circular UI glyph/ring.
for a,b in [((160,57),(175,52)),((177,52),(188,57)),((188,59),(185,65)),((180,68),(169,65)),((164,63),(162,59)),((173,55),(170,62)),((175,64),(181,57))]:line(a,b,18)
cluster([(175,51),(176,51),(181,67),(183,66),(165,58)],19)
# Very small original wall sconces and weathered warm points.
for x,y in [(37,35),(327,34)]:
 poly([(x-2,y+2),(x+2,y+2),(x+1,y+6),(x-1,y+6)],13)
 cluster([(x-2,y),(x+2,y),(x,y+2)],14)
 cluster([(x-1,y-1),(x,y-2),(x,y),(x+1,y)],23)
 cluster([(x,y-1),(x,y+1)],15)
# A distant ember at a broken stair, not a central spotlight.
cluster([(199,28),(200,28)],22);dot(199,27,23)
guard()
def chunk(k,b):return struct.pack('>I',len(b))+k+b+struct.pack('>I',zlib.crc32(k+b)&0xffffffff)
def png(w,h,p):
 raw=b''.join(b'\0'+p[y*w:(y+1)*w]for y in range(h))
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,3,0,0,0))+chunk(b'PLTE',bytes(c for rgb in PAL for c in rgb))+chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b'')
def put(n,b):
 fd=os.open(ROOT+'/'+n,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  v=memoryview(b)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
 return {'path':ROOT+'/'+n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
native=bytes(P);files=[];nativePNG=png(W,H,native);files.append(put('pixel-courtyard-study-r1.png',nativePNG));files.append(put('courtyard-preview-1x.png',nativePNG))
preview=bytearray(1440*464)
for y in range(H):
 for x in range(W):
  for dy in range(4):
   start=(y*4+dy)*1440+x*4;preview[start:start+4]=bytes([native[y*W+x]])*4
files.append(put('courtyard-preview-4x.png',png(1440,464,preview)))
zones=[{'name':'far-left combatant and attached readouts','nativeRect':[59,18,70,47]},{'name':'far-right combatant and attached readouts','nativeRect':[232,18,70,47]},{'name':'near-left bindings','nativeRect':[51,63,80,50]},{'name':'near-right bindings','nativeRect':[230,63,80,50]},{'name':'near hunter','nativeRect':[154,65,52,48]}]
meta={'asset':'original opt-in courtyard study, not integrated','nativeSize':[360,116],'intendedIntegerPreview':[1440,464],'nativePixelSHA256':hashlib.sha256(native).hexdigest(),'palette':[{'index':i,'rgb':list(c),'alpha':255}for i,c in enumerate(PAL)],'paletteEntries':24,'opaque':True,'transparentEntries':0,'creaturePalettePrefixSHA256':hashlib.sha256(bytes(c for rgb in PAL[:16]for c in rgb)).hexdigest(),'paletteExpansionReasons':{'16-18':'cool sky/floor slate steps finer than creature ramps, so quiet actor zones stay low in value','19-21':'aged masonry/weathered neutral stone, allowing sparse material edges without bone-colour glare','22-23':'small worn ember/sconce ramp below the existing15 flame core; warm identity is local'},'files':files,'pixelIndicesUsed':sorted(set(native)),'safeCompositionZones':zones,'safeZonesQualification':'Intended native composition only, not actual dynamic Arena cell/body/intent/Inspect/hit/readout fit. Multiple formations/viewport/header allocation untested. Quiet means low texture/contrast, not empty art or hidden controls.','composition':{'coldSkyTopFraction':.2,'farCentres':[[90,41],[270,41]],'nearCentres':[[90,92],[270,92]],'hunterCentre':[180,94],'focalContractFragment':[175,60],'lightSources':[[37,35],[327,34],[199,28]],'asymmetry':'broken left lancet ruin, right buttress/rubble, off-centre collapsed threshold stair'},'provenance':'Direct authored native integer polygons/lines/clusters in supplied source. No existing illustration read/sampled/filtered, generated raster, franchise/reference or stochastic texture. Same first16 creature RGB entries plus8 documented environment ramps. Original painted art and all creature studies remain unchanged.','limitations':['Static native art only; no query adapter, game/stage/root edit, build, browser or actual fit.','No selected-art/complete coherent scene/first-five quality or human-fun claim.','Backdrop at4x and current creature study at2x use nested integer grids; matching visual density/cohesion is untested.','Runtime cover/crop/scaling/fallback/load behaviour needs separate source/actual gates.'],'sourceGuardFinal':guard()}
files.append(put('ASSET-METADATA.json',(json.dumps(meta,indent=2,sort_keys=True)+'\n').encode()))
print(json.dumps({'files':files,'nativeSize':[360,116],'previewSize':[1440,464],'paletteEntries':24,'guard':guard()}))
