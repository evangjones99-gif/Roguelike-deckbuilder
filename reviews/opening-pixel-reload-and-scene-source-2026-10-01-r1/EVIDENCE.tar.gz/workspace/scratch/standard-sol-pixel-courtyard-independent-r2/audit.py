import os, json, struct, zlib, hashlib, resource, ast
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA, (24*1048576,24*1048576))
OUT=Path('/workspace/scratch/standard-sol-pixel-courtyard-independent-r2')
NEW=Path('/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r2')
OLD=Path('/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r1')
CG=Path('/sys/fs/cgroup')
BASE=int((CG/'memory.current').read_text()); MAX=int((CG/'memory.max').read_text())
assert MAX-BASE >= (24+512)*1048576
def guard():
    cur=int((CG/'memory.current').read_text())
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    assert int((CG/'memory.max').read_text())==MAX
    assert MAX-cur >= 512*1048576 and cur-BASE<=24*1048576 and rss<=24*1048576
    return dict(current=cur,maximum=MAX,headroom=MAX-cur,delta=cur-BASE,maxRSS=rss)
def read(path):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        assert os.fstat(fd).st_size<=262144
        data=bytearray()
        while True:
            part=os.read(fd,16384)
            if not part: break
            data.extend(part)
        return bytes(data)
    finally: os.close(fd)
def sha(data): return hashlib.sha256(data).hexdigest()
def seal(root,expected):
    b=read(root/'FROZEN.json'); assert sha(b)==expected
    s=json.loads(b); rows=[]
    for r in s['bodies']:
        d=read(root/r['name']); assert len(d)==r['bytes'] and sha(d)==r['sha256']
        rows.append(dict(name=r['name'],bytes=len(d),sha256=sha(d)))
    guard()
    return dict(frozenSHA256=sha(b),bodies=rows,count=len(rows),bytes=sum(r['bytes'] for r in rows))
def png(path):
    d=read(path); assert d[:8]==b'\x89PNG\r\n\x1a\n'
    pos=8; ids=[]; chunks=[]; palette=None; dims=None
    while pos<len(d):
        n,=struct.unpack('>I',d[pos:pos+4]); k=d[pos+4:pos+8]; b=d[pos+8:pos+8+n]
        assert n<=262144 and pos+n+12<=len(d)
        crc,=struct.unpack('>I',d[pos+8+n:pos+12+n]); assert zlib.crc32(k+b)&0xffffffff==crc
        chunks.append(dict(type=k.decode(),bytes=n,crc32=f'{crc:08x}'))
        if k==b'IHDR':
            w,h,depth,col,comp,filt,inter=struct.unpack('>IIBBBBB',b)
            assert (depth,col,comp,filt,inter)==(8,3,0,0,0); dims=(w,h)
        elif k==b'PLTE': palette=b
        elif k==b'IDAT': ids.append(b)
        else: assert k==b'IEND' and n==0
        pos+=n+12
    assert pos==len(d) and chunks[-1]['type']=='IEND' and palette and len(palette)%3==0
    raw=zlib.decompress(b''.join(ids)); w,h=dims
    assert len(raw)==(w+1)*h
    px=bytearray(w*h)
    for y in range(h):
        assert raw[y*(w+1)]==0
        px[y*w:(y+1)*w]=raw[y*(w+1)+1:(y+1)*(w+1)]
    assert max(px)<len(palette)//3
    row=dict(path=str(path),bytes=len(d),sha256=sha(d),size=list(dims),chunks=chunks,
             paletteEntries=len(palette)//3,paletteSHA256=sha(palette),pixelSHA256=sha(px),
             used=sorted(set(px)),opaqueBounds=[0,0,w,h],transparentEntries=0)
    guard(); return row,palette,bytes(px)
newSeal=seal(NEW,'61c54f41c79ed1574e46cacef526adaeaa71b8e234cf96d764af49e0f0ce5fd6')
oldSeal=seal(OLD,'e9862b0252e00e498809ef7fb2119ae23808847d5dd1d3f011ae3dc36c260039')
n,np,nx=png(NEW/'draw-r2/pixel-courtyard-study-r2.png')
one,op,ox=png(NEW/'draw-r2/courtyard-preview-1x.png')
four,fp,fx=png(NEW/'draw-r2/courtyard-preview-4x.png')
old,oldp,oldx=png(OLD/'pixel-courtyard-study-r1.png')
cmp,cp,cx=png(NEW/'courtyard-r1-r2-comparison-4x.png')
creature,creaturep,_=png(Path('/workspace/scratch/standard-sol-cairn-pixel-assets-author-r5/cairn-hound-sheet.png'))
assert creature['sha256']=='940cd0c47026565346b94490e49743a9a3c67b0565155d0c20e6ec52884ed3a8'
assert n['size']==one['size']==old['size']==[360,116] and four['size']==[1440,464] and cmp['size']==[1440,928]
assert n['sha256']=='0e556245f23fc7693b79e73810062e2249bc1022ba63149ac7d26361f6732fd6'
assert four['sha256']=='0eb5cff51a82456b4f4be504a7ebd0c007b5a53a267b2658d660115b38b91dcb'
assert cmp['sha256']=='f109724cce538bf4878cd1e0b5e15472c2f7f321d1b91fe8011d9fc0e89cb257'
assert np==op==fp and nx==ox and len(np)==72 and len(cp)==96
assert np[:48]==oldp[:48]==creaturep and np[48:]!=oldp[48:]
def expanded(row): return bytes(v for v in row for _ in range(4))
for y in range(116):
    row=expanded(nx[y*360:(y+1)*360])
    for dy in range(4): assert fx[(y*4+dy)*1440:(y*4+dy+1)*1440]==row
for src,pal,ybase in [(oldx,oldp,0),(nx,np,464)]:
    for y in range(116):
        native=src[y*360:(y+1)*360]
        for dy in range(4):
            actual=cx[(ybase+y*4+dy)*1440:(ybase+y*4+dy+1)*1440]
            for x,v in enumerate(native):
                for dx in range(4):
                    q=actual[x*4+dx]; assert cp[q*3:q*3+3]==pal[v*3:v*3+3]
    guard()
meta=json.loads(read(NEW/'draw-r2/ASSET-METADATA.json'))
assert meta['nativePixelSHA256']==n['pixelSHA256'] and meta['pixelIndicesUsed']==n['used']
assert bytes(c for r in meta['palette'] for c in r['rgb'])==np
for zone in meta['safeCompositionZones']:
    x,y,w,h=zone['nativeRect']; assert x>=0 and y>=0 and w>0 and h>0 and x+w<=360 and y+h<=116
tree=ast.parse(read(NEW/'draw-r2/author_courtyard.py'))
counts={}
for node in tree.body:
    if isinstance(node,ast.Assign):
        for target in node.targets:
            if isinstance(target,ast.Name) and target.id in ['SLABS','JOINTS','STEPS']:
                counts[target.id]=len(ast.literal_eval(node.value))
result=dict(scope='Independent static body/PNG/source proof only; no runtime or asset selection',
    admission=dict(current=BASE,maximum=MAX,headroom=MAX-BASE,workBytes=24*1048576,reserveBytes=512*1048576),
    newSeal=newSeal,oldSeal=oldSeal,oldBodyMutationObserved=False,
    images=[n,one,four,old,cmp],creaturePrefix=creature,
    exactNative1x=True,exactEvery4xPixelBlock=True,comparisonEveryOriginalRGBPreserved=True,
    comparison='R1 top/final R2 bottom; 32-entry union palette, not R1 recoloured with R2 environment ramp',
    creatureFirst16RGBExact=True,environment8Revised=True,allCourtyardPixelsOpaque=True,
    sourceGeometryCounts=counts,intendedZones=meta['safeCompositionZones'],
    zonesQualification=meta['safeZonesQualification'],guardFinal=guard(),allOwnFDsClosed=True,
    atimeQualification='ordinary view_image may affect atime; body hashes only are asserted unchanged')
body=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
fd=os.open(OUT/'RECEIPTS.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
try:
    view=memoryview(body)
    while view: view=view[os.write(fd,view):]
    os.fsync(fd)
finally: os.close(fd)
print(json.dumps(dict(status='PASS independent static contracts',receiptSHA256=sha(body),guardFinal=guard())))
