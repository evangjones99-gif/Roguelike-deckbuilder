/** Cairn-only prototype. Original R5 art is an unselected study; independent static review allows a runtime trial only.
 * No rules, RNG, saves, action dispatch or extra clocks live in this module.
 * Half-open native bounds and painted support contacts come from pinned R5 metadata.
 */
import type { Unit } from './engine';
import type { BattlefieldRect } from './battlefield-layout';
import type { CreaturePose } from './art';
import { pixelAtlasFits, pixelAtlasFeet, pixelAtlasShapeExtents, pixelAtlasFrame, pixelAtlasBounds, pixelAtlasContactRoot, type NativePixelAtlas } from './pixel-atlas';

export const CAIRN_PIXEL_URL = `${import.meta.env.BASE_URL}art/cairn-hound-pixel-r5.png`;
export const CAIRN_PIXEL_SCALE = 2;
export const CAIRN_PIXEL_SIZE = 64 * CAIRN_PIXEL_SCALE;
export const CAIRN_PIXEL_ANCHOR = [28, 58] as const;
export const CAIRN_PIXEL_UNION = [8, 13, 63, 60] as const;
export const CAIRN_PIXEL_FRAMES = [
  { name: 'arrival0', bounds: [12,24,58,59], feet: [[22,58],[44,56]], nose: [56,32] },
  { name: 'arrival1', bounds: [11,17,59,59], feet: [[22,58],[44,55]], nose: [57,25] },
  { name: 'idle0', bounds: [11,16,60,59], feet: [[22,58],[44,55]], nose: [58,24] },
  { name: 'idle1', bounds: [12,18,60,59], feet: [[22,58],[45,54]], nose: [58,25] },
  { name: 'anticipation', bounds: [9,21,62,59], feet: [[19,58],[46,56]], nose: [60,28] },
  { name: 'contact0', bounds: [8,13,63,59], feet: [[17,58],[46,51]], nose: [61,22] },
  { name: 'contact1', bounds: [10,17,63,59], feet: [[19,58],[48,53]], nose: [61,25] },
  { name: 'recovery', bounds: [13,19,58,59], feet: [[24,58],[43,55]], nose: [56,29] },
  { name: 'hit', bounds: [13,22,55,59], feet: [[24,58],[45,56]], nose: [53,31] },
  { name: 'death', bounds: [10,40,59,60], feet: [[24,58],[45,56]], nose: [57,50] },
] as const;

export const CAIRN_PIXEL_ATLAS = { url: CAIRN_PIXEL_URL, cell: 64, scale: CAIRN_PIXEL_SCALE, nativeFacing: 1,
  anchor: CAIRN_PIXEL_ANCHOR, union: CAIRN_PIXEL_UNION, frames: CAIRN_PIXEL_FRAMES,
  poses: { idle: [2, 3], arrival: [0, 1], anticipation: 4, attack: [5, 6], recovery: 7, reaction: 8, death: 9 },
  contact: { frame: 6, pixel: CAIRN_PIXEL_FRAMES[6].nose },
} as const satisfies NativePixelAtlas;
export function cairnPixelShapeExtents(facing: -1 | 1) { return pixelAtlasShapeExtents(CAIRN_PIXEL_ATLAS, facing); }

export function isPixelCairn(unit: Pick<Unit, 'cardId' | 'species'>, side: 'ally' | 'enemy') {
  return side === 'ally' && unit.cardId === 'cairnhound' && unit.species === 'hound';
}
export function cairnPixelFits(body: BattlefieldRect) { return pixelAtlasFits(CAIRN_PIXEL_ATLAS, body); }

export function cairnPixelFeet(body: BattlefieldRect) { return pixelAtlasFeet(CAIRN_PIXEL_ATLAS, body); }

export function cairnPixelFrame(pose: CreaturePose, now: number, born: number, gestureBorn: number | null, reduced: boolean, deadAt: number | null) {
  return pixelAtlasFrame(CAIRN_PIXEL_ATLAS, pose, now, born, gestureBorn, reduced, deadAt);
}

export function cairnPixelBounds(index: number, origin: { x: number; y: number }, facing: -1 | 1): BattlefieldRect {
  return pixelAtlasBounds(CAIRN_PIXEL_ATLAS, index, origin, facing);
}

export function cairnPixelContactRoot(target: { x: number; y: number }, body: BattlefieldRect, facing: -1 | 1) {
  return pixelAtlasContactRoot(CAIRN_PIXEL_ATLAS, target, body, facing);
}
