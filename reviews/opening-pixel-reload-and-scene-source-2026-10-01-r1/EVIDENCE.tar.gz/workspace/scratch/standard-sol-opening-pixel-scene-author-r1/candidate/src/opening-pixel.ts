/** Unselected original opening-scene art; exact final R2 native studies. No rules or clock. */
import type { Unit } from './engine';
import type { NativePixelAtlas } from './pixel-atlas';
export const PIXEL_COURTYARD_URL = `${import.meta.env.BASE_URL}art/pixel-courtyard-study-r2.png`;
export const THRALL_PIXEL_ATLAS = {
  url: `${import.meta.env.BASE_URL}art/bone-thrall-pixel-r2.png`, cell: 64, scale: 2, nativeFacing: -1,
  anchor: [32, 61], union: [7, 5, 58, 64],
  frames: [
    { name: 'idle0', bounds: [16, 5, 53, 62] }, { name: 'idle1', bounds: [18, 6, 52, 62] },
    { name: 'anticipation', bounds: [19, 9, 56, 62] }, { name: 'contact', bounds: [7, 8, 56, 62] },
    { name: 'recovery', bounds: [20, 7, 55, 62] }, { name: 'reaction', bounds: [16, 11, 57, 62] },
    { name: 'death', bounds: [16, 36, 58, 64] },
  ],
  poses: { idle: [0, 1], anticipation: 2, attack: [3, 3], recovery: 4, reaction: 5, death: 6 },
  contact: { frame: 3, pixel: [7, 51] },
} as const satisfies NativePixelAtlas;
export function isPixelThrall(unit: Pick<Unit, 'cardId' | 'species'>, side: 'ally' | 'enemy') {
  return side === 'enemy' && unit.cardId === 'thrall' && unit.species === 'thrall';
}
export function paintPixelCourtyard(ctx: CanvasRenderingContext2D, image: HTMLImageElement, width: number, height: number) {
  // Integer cover, centred with honest edge crop; never stretch/filter a native pixel into a painting.
  const scale = Math.max(1, Math.ceil(Math.max(width / 360, height / 116)));
  const w = 360 * scale, h = 116 * scale;
  ctx.save(); ctx.imageSmoothingEnabled = false;
  ctx.drawImage(image, Math.floor((width - w) / 2), Math.floor((height - h) / 2), w, h); ctx.restore();
}
