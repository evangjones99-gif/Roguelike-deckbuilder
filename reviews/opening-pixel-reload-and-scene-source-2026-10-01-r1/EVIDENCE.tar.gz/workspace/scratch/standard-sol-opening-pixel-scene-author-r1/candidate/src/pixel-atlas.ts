/** Small native-pixel presentation primitives; callers supply the existing Arena clock. */
import type { BattlefieldRect } from './battlefield-layout';
import { CREATURE_IMPACT_MS, type CreaturePose } from './art';
export type PixelPoint = { x: number; y: number };
export type NativeBounds = readonly [number, number, number, number];
export interface NativePixelAtlas {
  readonly url: string;
  readonly cell: number;
  readonly scale: number;
  readonly nativeFacing: -1 | 1;
  readonly anchor: readonly [number, number];
  readonly union: NativeBounds;
  readonly frames: readonly { readonly name: string; readonly bounds: NativeBounds }[];
  readonly poses: { readonly idle: readonly [number, number]; readonly anticipation: number;
    readonly attack: readonly [number, number]; readonly recovery: number; readonly reaction: number;
    readonly death: number; readonly arrival?: readonly [number, number] };
  readonly contact: { readonly frame: number; readonly pixel: readonly [number, number] };
}
export function pixelAtlasSize(atlas: NativePixelAtlas) { return atlas.cell * atlas.scale; }
function extents(atlas: NativePixelAtlas) {
  return { left: (atlas.anchor[0] - atlas.union[0]) * atlas.scale,
    right: (atlas.union[2] - atlas.anchor[0]) * atlas.scale,
    top: (atlas.anchor[1] - atlas.union[1]) * atlas.scale,
    bottom: (atlas.union[3] - atlas.anchor[1]) * atlas.scale };
}
export function pixelAtlasFits(atlas: NativePixelAtlas, body: BattlefieldRect) {
  const e = extents(atlas);
  return body.width >= Math.max(e.left, e.right) * 2 + 8 && body.height >= e.top + e.bottom + 8;
}
export function pixelAtlasFeet(atlas: NativePixelAtlas, body: BattlefieldRect): PixelPoint {
  return { x: Math.round(body.left + body.width / 2), y: Math.round(body.top + body.height - extents(atlas).bottom - 4) };
}
export function pixelAtlasShapeExtents(atlas: NativePixelAtlas, facing: -1 | 1) {
  const e = extents(atlas), size = pixelAtlasSize(atlas), flip = facing * atlas.nativeFacing;
  return { left: (flip === 1 ? e.left : e.right) / size, right: (flip === 1 ? e.right : e.left) / size,
    top: e.top / size, bottom: e.bottom / size };
}
export function pixelAtlasFrame(atlas: NativePixelAtlas, pose: CreaturePose, now: number, born: number,
  gestureBorn: number | null, reduced: boolean, deadAt: number | null) {
  const p = atlas.poses;
  if (deadAt !== null && now >= deadAt) return p.death;
  if (reduced) return p.idle[0];
  if (pose === 'reaction') return p.reaction;
  if (pose === 'anticipation') return p.anticipation;
  if (pose === 'attack') return gestureBorn !== null && now - gestureBorn >= CREATURE_IMPACT_MS / 1000 ? p.attack[1] : p.attack[0];
  if (pose === 'recovery') return p.recovery;
  const age = now - born;
  if (p.arrival && age < .16) return p.arrival[0];
  if (p.arrival && age < .32) return p.arrival[1];
  return p.idle[Math.floor(Math.max(0, age - (p.arrival ? .32 : 0)) / .55) % 2];
}
export function pixelAtlasBounds(atlas: NativePixelAtlas, index: number, origin: PixelPoint, facing: -1 | 1): BattlefieldRect {
  const [left, top, right, bottom] = atlas.frames[index].bounds, flip = facing * atlas.nativeFacing;
  const x1 = (left - atlas.anchor[0]) * atlas.scale * flip, x2 = (right - atlas.anchor[0]) * atlas.scale * flip;
  return { left: origin.x + Math.min(x1, x2), top: origin.y + (top - atlas.anchor[1]) * atlas.scale,
    width: (right - left) * atlas.scale, height: (bottom - top) * atlas.scale };
}
export function pixelAtlasContactRoot(atlas: NativePixelAtlas, target: PixelPoint, body: BattlefieldRect, facing: -1 | 1) {
  const e = extents(atlas), flip = facing * atlas.nativeFacing, [x, y] = atlas.contact.pixel;
  const left = flip === 1 ? e.left : e.right, right = flip === 1 ? e.right : e.left;
  const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
  // Painted landmark is a pixel index; align its centre, keeping the entire union inside the victim cell.
  return { x: clamp(target.x - (x + .5 - atlas.anchor[0]) * atlas.scale * flip,
    body.left + left + 4, body.left + body.width - right - 4),
    y: clamp(target.y - (y + .5 - atlas.anchor[1]) * atlas.scale,
      body.top + e.top + 4, body.top + body.height - e.bottom - 4) };
}
export function paintPixelAtlas(ctx: CanvasRenderingContext2D, image: HTMLImageElement, atlas: NativePixelAtlas,
  index: number, origin: PixelPoint, facing: -1 | 1) {
  ctx.save(); ctx.translate(origin.x, origin.y); ctx.scale(facing * atlas.nativeFacing, 1); ctx.imageSmoothingEnabled = false;
  const size = pixelAtlasSize(atlas);
  ctx.drawImage(image, index * atlas.cell, 0, atlas.cell, atlas.cell,
    -atlas.anchor[0] * atlas.scale, -atlas.anchor[1] * atlas.scale, size, size);
  ctx.restore();
}
