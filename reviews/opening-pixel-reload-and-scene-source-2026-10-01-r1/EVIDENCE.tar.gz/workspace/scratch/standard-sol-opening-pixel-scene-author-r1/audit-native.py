from pathlib import Path
import hashlib,json,struct,zlib,os,time
OWN=Path(__file__).parent
THRALL=Path('/workspace/scratch/standard-sol-bone-thrall-pixel-assets-author-r2/draw-r2')
COURT=Path('/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r2/draw-r2')
CG=Path('/sys/fs/cgroup'); start=time.monotonic(); cg0=int((CG/'memory.current').read_text()); events0=(CG/'memory.events').read_text(); samples=[]
def guard():
 cur=int((CG/'memory.current').read_text()); mx=int((CG/'memory.max').read_text()); rss=int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
 row={'elapsed':time.monotonic()-start,'resident':rss,'cgroupDelta':max(0,cur-cg0),'headroom':mx-cur};samples.append(row)
 assert row['elapsed']<60 and rss<=64*1048576 and row['cgroupDelta']<=64*1048576 and row['headroom']>=512*1048576,row
 assert (CG/'memory.events').read_text()==events0
sha=lambda b:hashlib.sha256(b).hexdigest()
def decode(path,expected):
 guard();data=path.read_bytes();assert len(data)<16384 and sha(data)==expected
 assert data[:8]==b'\x89PNG\r\n\x1a\n';pos=8;chunks=[];ids=b'';palette=b'';alpha=b'';w=h=0
 while pos<len(data):
  guard();n=struct.unpack('>I',data[pos:pos+4])[0];kind=data[pos+4:pos+8];body=data[pos+8:pos+8+n];crc=struct.unpack('>I',data[pos+8+n:pos+12+n])[0];assert zlib.crc32(kind+body)&0xffffffff==crc;pos+=n+12;chunks.append({'type':kind.decode(),'crc32':f'{crc:08x}'})
  if kind==b'IHDR':
   w,h,depth,colour,compression,filtering,interlace=struct.unpack('>IIBBBBB',body);assert depth==8 and colour==3 and compression==filtering==interlace==0 and w*h<=50000
  elif kind==b'PLTE':palette=body
  elif kind==b'tRNS':alpha=body
  elif kind==b'IDAT':ids+=body
  elif kind==b'IEND':assert pos==len(data);break
 assert chunks[0]['type']=='IHDR' and chunks[-1]['type']=='IEND' and len(palette)%3==0
 expectedBytes=(w+1)*h;dec=zlib.decompressobj();raw=dec.decompress(ids,expectedBytes+1);assert len(raw)==expectedBytes and dec.eof and not dec.unused_data
 pixels=bytearray();prior=bytearray(w)
 for y in range(h):
  guard();f=raw[y*(w+1)];row=bytearray(raw[y*(w+1)+1:(y+1)*(w+1)]);assert f in range(5)
  for x in range(w):
   a=row[x-1] if x else 0;b=prior[x];c=prior[x-1] if x else 0
   if f==1:pred=a
   elif f==2:pred=b
   elif f==3:pred=(a+b)//2
   elif f==4:
    q=a+b-c;ds=[abs(q-a),abs(q-b),abs(q-c)];pred=[a,b,c][ds.index(min(ds))]
   else:pred=0
   row[x]=(row[x]+pred)&255
  pixels.extend(row);prior=row
 assert max(pixels)<len(palette)//3
 return {'path':str(path),'sha256':sha(data),'bytes':len(data),'size':[w,h],'paletteEntries':len(palette)//3,'paletteSHA256':sha(palette),'pixelSHA256':sha(pixels),'chunks':chunks},bytes(pixels),palette,alpha
result={'status':'FRESH_AUTHOR_NATIVE_AUDIT_NOT_INDEPENDENT_ART_OR_RUNTIME_ACCEPTANCE','workMiB':64,'reserveMiB':512,'wholeCapSeconds':60}
try:
 guard();tm=json.loads((THRALL/'ASSET-METADATA.json').read_text());cm=json.loads((COURT/'ASSET-METADATA.json').read_text());files={Path(r['path']).name:r['sha256'] for r in tm['files']};sheet,pixels,pal,alpha=decode(THRALL/'bone-thrall-sheet.png',files['bone-thrall-sheet.png']);assert sheet['size']==[448,64] and len(pal)==48 and alpha==b'\x00'
 frames=[]
 for i,f in enumerate(tm['frames']):
  n='bone-thrall-'+f['name']+'.png';receipt,px,pp,aa=decode(THRALL/n,files[n]);assert receipt['size']==[64,64] and pp==pal and aa==alpha
  assert px==b''.join(pixels[y*448+i*64:y*448+(i+1)*64] for y in range(64)) and sha(px)==f['pixelSHA256']
  coords=[(j%64,j//64) for j,v in enumerate(px) if v];bounds=[min(x for x,y in coords),min(y for x,y in coords),max(x for x,y in coords)+1,max(y for x,y in coords)+1]
  assert bounds==f['opaqueBounds'] and len(coords)==f['opaquePixels'];assert all(px[y*64+x] for x,y in f['footContactPoints']+[f['clawContactPixelIndex']])
  frames.append({**receipt,'name':f['name'],'bounds':bounds,'opaquePixels':len(coords),'landmarksOpaque':True})
 union=[min(f['bounds'][0] for f in frames),min(f['bounds'][1] for f in frames),max(f['bounds'][2] for f in frames),max(f['bounds'][3] for f in frames)]
 assert union==[7,5,58,64] and tm['placementAnchor']==[32,61] and len({f['pixelSHA256'] for f in frames})==7
 courtFile=cm['files'][0];court,cpx,cp,ca=decode(Path(courtFile['path']),courtFile['sha256']);assert court['size']==[360,116] and len(cp)==72 and not ca
 result.update({'pass':True,'thrallSheet':sheet,'thrallFrames':frames,'fullUnion':union,'anchor':[32,61],'conservative2xFit':[112,126],'deathLastRowOpaque':any(pixels[63*448+384:64*448]),'court':court,'courtFullyOpaque':True,'assetMetadataPins':{'thrall':sha((THRALL/'ASSET-METADATA.json').read_bytes()),'courtyard':sha((COURT/'ASSET-METADATA.json').read_bytes())}})
except Exception as e:
 result.update({'pass':False,'failure':repr(e)});raise
finally:
 try:guard()
 except Exception as e:result.update({'pass':False,'closingGuardFailure':repr(e)})
 result.update({'samples':len(samples),'maxResident':max(x['resident'] for x in samples),'maxCgroupDelta':max(x['cgroupDelta'] for x in samples),'minHeadroom':min(x['headroom'] for x in samples),'wholeSeconds':time.monotonic()-start,'eventsUnchanged':(CG/'memory.events').read_text()==events0,'normalOwnFiniteProcessOnly':'Python returns naturally; no child/Node/browser/server','limits':'Sampled own resident AND cgroup delta, not a continuous aggregate; no visual/art selection/game fit claim'})
 (OWN/'NATIVE-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['pass','samples','maxResident','maxCgroupDelta','minHeadroom','wholeSeconds']}))
