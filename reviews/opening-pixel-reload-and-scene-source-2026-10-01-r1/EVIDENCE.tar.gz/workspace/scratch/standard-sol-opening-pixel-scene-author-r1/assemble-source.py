from pathlib import Path
import difflib
P=Path(__file__).parent
old=(P/'original/src/cairn-pixel.ts').read_text();s=old
s=s.replace("import { CREATURE_IMPACT_MS, type CreaturePose } from './art';", "import type { CreaturePose } from './art';\nimport { pixelAtlasFits, pixelAtlasFeet, pixelAtlasShapeExtents, pixelAtlasFrame, pixelAtlasBounds, pixelAtlasContactRoot, type NativePixelAtlas } from './pixel-atlas';")
a=s.index('const leftExtent');b=s.index('export const CAIRN_PIXEL_FRAMES');s=s[:a]+s[b:]
a=s.index('\nexport function isPixelCairn');s=s[:a]+'''\nexport const CAIRN_PIXEL_ATLAS = { url: CAIRN_PIXEL_URL, cell: 64, scale: CAIRN_PIXEL_SCALE, nativeFacing: 1,
  anchor: CAIRN_PIXEL_ANCHOR, union: CAIRN_PIXEL_UNION, frames: CAIRN_PIXEL_FRAMES,
  poses: { idle: [2, 3], arrival: [0, 1], anticipation: 4, attack: [5, 6], recovery: 7, reaction: 8, death: 9 },
  contact: { frame: 6, pixel: CAIRN_PIXEL_FRAMES[6].nose },
} as const satisfies NativePixelAtlas;
export function cairnPixelShapeExtents(facing: -1 | 1) { return pixelAtlasShapeExtents(CAIRN_PIXEL_ATLAS, facing); }
'''+s[a:]
def replace_export(name,body):
 global s
 a=s.index('export function '+name);b=s.find('\nexport function ',a+1);b=len(s) if b<0 else b;s=s[:a]+body+'\n'+s[b:]
replace_export('cairnPixelFits',"export function cairnPixelFits(body: BattlefieldRect) { return pixelAtlasFits(CAIRN_PIXEL_ATLAS, body); }")
replace_export('cairnPixelFeet',"export function cairnPixelFeet(body: BattlefieldRect) { return pixelAtlasFeet(CAIRN_PIXEL_ATLAS, body); }")
replace_export('cairnPixelFrame',"export function cairnPixelFrame(pose: CreaturePose, now: number, born: number, gestureBorn: number | null, reduced: boolean, deadAt: number | null) {\n  return pixelAtlasFrame(CAIRN_PIXEL_ATLAS, pose, now, born, gestureBorn, reduced, deadAt);\n}")
replace_export('cairnPixelBounds',"export function cairnPixelBounds(index: number, origin: { x: number; y: number }, facing: -1 | 1): BattlefieldRect {\n  return pixelAtlasBounds(CAIRN_PIXEL_ATLAS, index, origin, facing);\n}")
replace_export('cairnPixelContactRoot',"export function cairnPixelContactRoot(target: { x: number; y: number }, body: BattlefieldRect, facing: -1 | 1) {\n  return pixelAtlasContactRoot(CAIRN_PIXEL_ATLAS, target, body, facing);\n}")
(P/'candidate/src/cairn-pixel.ts').write_text(s)
s=(P/'original/src/arena.ts').read_text()
# All edits operate on this retained body only, never on ROOT or a staged file.
def one(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
one("import { CAIRN_PIXEL_URL, CAIRN_PIXEL_SIZE, CAIRN_PIXEL_SCALE, CAIRN_PIXEL_ANCHOR, isPixelCairn, cairnPixelFits, cairnPixelFeet, cairnPixelFrame, cairnPixelBounds, cairnPixelContactRoot, cairnPixelShapeExtents } from './cairn-pixel';", "import { CAIRN_PIXEL_URL, CAIRN_PIXEL_ATLAS, isPixelCairn, cairnPixelFits } from './cairn-pixel';\nimport { THRALL_PIXEL_ATLAS, PIXEL_COURTYARD_URL, isPixelThrall, paintPixelCourtyard } from './opening-pixel';\nimport { pixelAtlasSize, pixelAtlasFits, pixelAtlasFeet, pixelAtlasShapeExtents, pixelAtlasFrame, pixelAtlasBounds, pixelAtlasContactRoot, paintPixelAtlas, type NativePixelAtlas } from './pixel-atlas';")
one("  const pixelCairn = new URLSearchParams(window.location.search).get('pixelCairn') === '1';", "  const pixelOpening = new URLSearchParams(window.location.search).get('pixelOpening') === '1';\n  const pixelCairn = pixelOpening || new URLSearchParams(window.location.search).get('pixelCairn') === '1';")
one("if (url === CAIRN_PIXEL_URL && (image?.naturalWidth !== 640 || image?.naturalHeight !== 64)) missing.add(url);", "const expected = url === CAIRN_PIXEL_URL ? [640, 64] : url === THRALL_PIXEL_ATLAS.url ? [448, 64] : url === PIXEL_COURTYARD_URL ? [360, 116] : null;\n        if (expected && (image?.naturalWidth !== expected[0] || image?.naturalHeight !== expected[1])) missing.add(url);")
one("const relevantMissing = [...missing].some(url => (url !== ARENA_ART.courtyard && url !== ARENA_ART.crypt) || url === ARENA_ART[environment]);", "const relevantMissing = [...missing].some(url => url === PIXEL_COURTYARD_URL ? pixelOpening && environment === 'courtyard' : (url !== ARENA_ART.courtyard && url !== ARENA_ART.crypt) || url === ARENA_ART[environment]);")
one("  if (pixelCairn) imageFor(CAIRN_PIXEL_URL);", "  if (pixelCairn) imageFor(CAIRN_PIXEL_URL);\n  if (pixelOpening) { imageFor(THRALL_PIXEL_ATLAS.url); imageFor(PIXEL_COURTYARD_URL); }")
one("    back.setTransform(ratio, 0, 0, ratio, 0, 0);", "    back.setTransform(ratio, 0, 0, ratio, 0, 0);\n    const pixelBackground = pixelOpening && environment === 'courtyard' ? images.get(PIXEL_COURTYARD_URL) : undefined;\n    if (pixelBackground && loaded(pixelBackground) && pixelBackground.naturalWidth === 360 && pixelBackground.naturalHeight === 116) {\n      paintPixelCourtyard(back, pixelBackground, width, height); return;\n    }")
a=s.index('  function cairnImage(');b=s.index('  function cairnEligibilitySnapshot',a)
s=s[:a]+'''  function pixelAtlasFor(figure: Figure): NativePixelAtlas | null {
    if (pixelCairn && isPixelCairn(figure.unit, figure.side)) return CAIRN_PIXEL_ATLAS;
    if (pixelOpening && isPixelThrall(figure.unit, figure.side)) return THRALL_PIXEL_ATLAS;
    return null;
  }
  function pixelImage(figure: Figure): HTMLImageElement | null {
    const atlas = pixelAtlasFor(figure);
    if (!atlas || (layoutBlend(figure) < 1 && !pixelAtlasFits(atlas, figure.cellFrom.bodyRect)) ||
      !pixelAtlasFits(atlas, figure.cellTarget.bodyRect) || !pixelAtlasFits(atlas, figureCell(figure).bodyRect)) return null;
    const gesture = activeGesture(figure);
    if (gesture?.kind === 'physical') {
      const target = figures.get(gesture.target);
      if (!target || !pixelAtlasFits(atlas, figureCell(target).bodyRect)) return null;
    }
    const image = images.get(atlas.url);
    return image && loaded(image) && image.naturalWidth === atlas.cell * atlas.frames.length && image.naturalHeight === atlas.cell ? image : null;
  }
  function cairnImage(figure: Figure): HTMLImageElement | null {
    return isPixelCairn(figure.unit, figure.side) ? pixelImage(figure) : null;
  }
  function pixelSample(figure: Figure) {
    const image = pixelImage(figure), atlas = pixelAtlasFor(figure); if (!image || !atlas) return null;
    const transform = figureTransform(figure), gesture = activeGesture(figure);
    const index = pixelAtlasFrame(atlas, figure.pose, time, figure.born, gesture?.born ?? null, reduced, figure.dead);
    return { image, atlas, index, origin: transform.origin, rect: pixelAtlasBounds(atlas, index, transform.origin, figure.facing) };
  }
'''+s[b:]
one("    if (cairnImage(figure)) return cairnPixelShapeExtents(figure.facing);", "    const pixel = pixelAtlasFor(figure); if (pixel && pixelImage(figure)) return pixelAtlasShapeExtents(pixel, figure.facing);")
one("    if (cairnImage(figure)) return cairnPixelFeet(cell.bodyRect);", "    const pixel = pixelAtlasFor(figure); if (pixel && pixelImage(figure)) return pixelAtlasFeet(pixel, cell.bodyRect);")
assert s.count("    if (cairnImage(figure)) return CAIRN_PIXEL_SIZE;")==2
s=s.replace("    if (cairnImage(figure)) return CAIRN_PIXEL_SIZE;", "    const pixel = pixelAtlasFor(figure); if (pixel && pixelImage(figure)) return pixelAtlasSize(pixel);")
one("    if (cairnImage(figure)) return cairnPixelFeet(figureCell(figure).bodyRect);", "    const pixel = pixelAtlasFor(figure); if (pixel && pixelImage(figure)) return pixelAtlasFeet(pixel, figureCell(figure).bodyRect);")
one("    if (cairnImage(figure)) {\n      const target = figures.get(strike.target), body = target && figureCell(target).bodyRect;\n      if (!body || !cairnPixelFits(body)) return movement;", "    const pixel = pixelAtlasFor(figure);\n    if (pixel && pixelImage(figure)) {\n      const target = figures.get(strike.target), body = target && figureCell(target).bodyRect;\n      if (!body || !pixelAtlasFits(pixel, body)) return movement;")
one("Math.max(4, CAIRN_PIXEL_SIZE * .04)", "Math.max(4, pixelAtlasSize(pixel) * .04)")
one("const peak = cairnPixelContactRoot(strike.to, body, facing)", "const peak = pixelAtlasContactRoot(pixel, strike.to, body, facing)")
one("    if (cairnImage(figure)) {\n      const origin = figureTransform(figure).origin;", "    if (pixelImage(figure)) {\n      const origin = figureTransform(figure).origin;")
s=s.replace('CAIRN_PIXEL_SIZE * .62','size * .62').replace('CAIRN_PIXEL_SIZE * .72','size * .72')
one('    if (cairnImage(figure)) return { origin: {','    if (pixelImage(figure)) return { origin: {')
assert s.count('const pixel = cairnSample(figure);')==2;s=s.replace('const pixel = cairnSample(figure);','const pixel = pixelSample(figure);')
a=s.index('      ctx.translate(pixel.origin.x');b=s.index('\n    } else {',a)
s=s[:a]+"      paintPixelAtlas(ctx, pixel.image, pixel.atlas, pixel.index, pixel.origin, figure.facing);"+s[b:]
(P/'candidate/src/arena.ts').write_text(s)
s=(P/'original/src/main.ts').read_text();a="${new URLSearchParams(window.location.search).get('pixelCairn') === '1' ? 'Cairn pixel study · fallback available' : 'Playable prototype'}";assert s.count(a)==1
s=s.replace(a,"${new URLSearchParams(window.location.search).get('pixelOpening') === '1' ? 'Opening pixel study · mixed/incomplete art' : new URLSearchParams(window.location.search).get('pixelCairn') === '1' ? 'Cairn pixel study · fallback available' : 'Playable prototype'}")
(P/'candidate/src/main.ts').write_text(s)
diff=''
for f in sorted((P/'candidate/src').glob('*.ts')):
 o=P/'original/src'/f.name;before=o.read_text() if o.exists() else ''
 diff+=''.join(difflib.unified_diff(before.splitlines(True),f.read_text().splitlines(True),fromfile='original/src/'+f.name if o.exists() else '/dev/null',tofile='candidate/src/'+f.name))
(P/'EXACT-DIFF.patch').write_text(diff)
print('Owned five-body source assembled; no compilation/runtime')
