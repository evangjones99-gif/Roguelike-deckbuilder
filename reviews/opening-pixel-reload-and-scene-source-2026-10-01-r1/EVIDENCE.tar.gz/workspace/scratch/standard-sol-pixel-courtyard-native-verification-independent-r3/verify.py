"""One independent fresh-process static verification, no image generation/view or runtime."""
import os, json, struct, zlib, hashlib, ast, resource, threading, time, traceback
from pathlib import Path
OUT=Path('/workspace/scratch/standard-sol-pixel-courtyard-native-verification-independent-r3')
NEW=Path('/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r2')
OLD=Path('/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r1')
CG=Path('/sys/fs/cgroup'); WORK=64*1048576; RESERVE=512*1048576
resource.setrlimit(resource.RLIMIT_DATA,(WORK,WORK))
def noatime(p,cap=262144):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  assert os.fstat(fd).st_size<=cap
  data=bytearray()
  while True:
   x=os.read(fd,16384)
   if not x:break
   data.extend(x)
  return bytes(data)
 finally:os.close(fd)
def sha(d):return hashlib.sha256(d).hexdigest()
def status():
 lines=Path('/proc/self/status').read_text().splitlines(); vals={}
 for l in lines:
  if l.startswith(('VmRSS:','VmHWM:')):
   key,n,unit=l.split();assert unit=='kB';vals[key[:-1]]=int(n)*1024
 assert len(vals)==2
 return vals
def row():
 c=int((CG/'memory.current').read_text());m=int((CG/'memory.max').read_text());disk=os.statvfs(OUT)
 return dict(timeNs=time.time_ns(),elapsed=time.monotonic()-started,current=c,maximum=m,headroom=m-c,
             free=disk.f_bavail*disk.f_frsize,events=(CG/'memory.events').read_text(),**status())
started=time.monotonic();initial=row();inheritedMaxRSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
samples=[];stop=threading.Event();breaches=[];worker=None
def valid(q):
 return (q['maximum']==initial['maximum'] and q['current']-initial['current']<=WORK
         and q['headroom']>=RESERVE and q['free']>=1048576 and q['events']==initial['events']
         and q['VmRSS']<=WORK and q['VmHWM']<=WORK)
def sample():
 while not stop.is_set():
  try:
   q=row();q['delta']=q['current']-initial['current'];samples.append(q)
   if not valid(q):breaches.append(q);stop.set()
  except BaseException as e:breaches.append(dict(error=repr(e)));stop.set()
  stop.wait(.01)
def guard():
 assert not breaches,'live source resource guard breach'
 q=row();assert valid(q),'explicit source resource guard breach'
 return q
def sealed(root,expected,count,bytecount):
 raw=noatime(root/'FROZEN.json');assert sha(raw)==expected
 rec=json.loads(raw)['bodies'];assert len(rec)==count and sum(q['bytes'] for q in rec)==bytecount
 pins=[]
 for q in rec:
  name=q['name'];assert not Path(name).is_absolute() and '..' not in Path(name).parts
  body=noatime(root/name);assert len(body)==q['bytes'] and sha(body)==q['sha256']
  pins.append(dict(name=name,bytes=len(body),sha256=sha(body)));guard()
 return dict(frozenSHA256=sha(raw),count=count,bytes=bytecount,bodies=pins)
def png(path):
 d=noatime(path);assert d[:8]==b'\x89PNG\r\n\x1a\n'
 at=8;ids=[];pal=None;alpha=None;wh=None;chunks=[]
 while at<len(d):
  n,=struct.unpack('>I',d[at:at+4]);k=d[at+4:at+8];b=d[at+8:at+8+n]
  assert n<=262144 and at+n+12<=len(d)
  crc,=struct.unpack('>I',d[at+8+n:at+12+n]);assert (zlib.crc32(k+b)&0xffffffff)==crc
  chunks.append(dict(type=k.decode(),bytes=n,crc32=f'{crc:08x}'))
  if k==b'IHDR':
   w,h,depth,col,comp,filt,inter=struct.unpack('>IIBBBBB',b)
   assert (depth,col,comp,filt,inter)==(8,3,0,0,0) and w<=1440 and h<=928;wh=(w,h)
  elif k==b'PLTE':pal=b
  elif k==b'tRNS':alpha=b
  elif k==b'IDAT':ids.append(b)
  else:assert k==b'IEND' and n==0
  at+=n+12
 assert at==len(d) and chunks[-1]['type']=='IEND' and pal and len(pal)%3==0
 w,h=wh;dec=zlib.decompressobj();raw=dec.decompress(b''.join(ids),(w+1)*h+1)
 assert dec.eof and not dec.unused_data and not dec.unconsumed_tail and len(raw)==(w+1)*h
 px=bytearray(w*h)
 for y in range(h):
  assert raw[y*(w+1)]==0;px[y*w:(y+1)*w]=raw[y*(w+1)+1:(y+1)*(w+1)]
 used=sorted(set(px));assert max(used)<len(pal)//3
 a=(alpha or b'')+b'\xff'*(len(pal)//3-len(alpha or b''))
 result=dict(path=str(path),sha256=sha(d),bytes=len(d),size=[w,h],chunks=chunks,paletteEntries=len(pal)//3,
             paletteSHA256=sha(pal),pixelSHA256=sha(px),used=used,hasTRNS=alpha is not None,
             transparentUsed=[v for v in used if a[v]!=255],fullyOpaque=all(a[v]==255 for v in used))
 guard();return result,pal,bytes(px)
def put(name,obj):
 b=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode();fd=os.open(OUT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:
  v=memoryview(b)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
 return dict(name=name,bytes=len(b),sha256=sha(b))
failure=None;proof=None
try:
 assert initial['headroom']>=WORK+RESERVE and initial['free']>=1048576 and initial['VmRSS']<=WORK and initial['VmHWM']<=WORK,'fresh admission refused'
 worker=threading.Thread(target=sample,daemon=False);worker.start()
 newSeal=sealed(NEW,'61c54f41c79ed1574e46cacef526adaeaa71b8e234cf96d764af49e0f0ce5fd6',24,97880)
 oldSeal=sealed(OLD,'e9862b0252e00e498809ef7fb2119ae23808847d5dd1d3f011ae3dc36c260039',12,37182)
 n,np,nx=png(NEW/'draw-r2/pixel-courtyard-study-r2.png')
 one,op,ox=png(NEW/'draw-r2/courtyard-preview-1x.png')
 four,fp,fx=png(NEW/'draw-r2/courtyard-preview-4x.png')
 old,oldp,oldx=png(OLD/'pixel-courtyard-study-r1.png')
 compare,cp,cx=png(NEW/'courtyard-r1-r2-comparison-4x.png')
 creature,creaturep,_=png(Path('/workspace/scratch/standard-sol-cairn-pixel-assets-author-r5/cairn-hound-sheet.png'))
 assert creature['sha256']=='940cd0c47026565346b94490e49743a9a3c67b0565155d0c20e6ec52884ed3a8'
 assert n['size']==one['size']==old['size']==[360,116] and four['size']==[1440,464] and compare['size']==[1440,928]
 assert n['sha256']=='0e556245f23fc7693b79e73810062e2249bc1022ba63149ac7d26361f6732fd6'
 assert four['sha256']=='0eb5cff51a82456b4f4be504a7ebd0c007b5a53a267b2658d660115b38b91dcb'
 assert compare['sha256']=='f109724cce538bf4878cd1e0b5e15472c2f7f321d1b91fe8011d9fc0e89cb257'
 assert np==op==fp and nx==ox and len(np)==72 and len(cp)==96
 assert np[:48]==oldp[:48]==creaturep and np[48:]!=oldp[48:]
 assert all(q['fullyOpaque'] and not q['hasTRNS'] for q in [n,one,four,old,compare])
 def expanded(r):return bytes(v for v in r for _ in range(4))
 for y in range(116):
  ex=expanded(nx[y*360:(y+1)*360])
  for dy in range(4):assert fx[(y*4+dy)*1440:(y*4+dy+1)*1440]==ex
  guard()
 for src,palette,ybase in [(oldx,oldp,0),(nx,np,464)]:
  for y in range(116):
   nr=src[y*360:(y+1)*360]
   for dy in range(4):
    cr=cx[(ybase+y*4+dy)*1440:(ybase+y*4+dy+1)*1440]
    for x,v in enumerate(nr):
     for dx in range(4):
      q=cr[x*4+dx];assert cp[q*3:q*3+3]==palette[v*3:v*3+3]
   guard()
 metadata=json.loads(noatime(NEW/'draw-r2/ASSET-METADATA.json'))
 assert metadata['nativePixelSHA256']==n['pixelSHA256'] and metadata['pixelIndicesUsed']==n['used']
 assert bytes(v for q in metadata['palette'] for v in q['rgb'])==np
 tree=ast.parse(noatime(NEW/'draw-r2/author_courtyard.py'));counts={};sourcePalette=None
 for node in tree.body:
  if isinstance(node,ast.Assign):
   for target in node.targets:
    if isinstance(target,ast.Name) and target.id in ['PAL','SLABS','JOINTS','STEPS']:
     value=ast.literal_eval(node.value)
     if target.id=='PAL':sourcePalette=bytes(v for q in value for v in q)
     else:counts[target.id]=len(value)
 assert sourcePalette==np and counts==dict(SLABS=20,JOINTS=16,STEPS=3)
 for zone in metadata['safeCompositionZones']:
  x,y,w,h=zone['nativeRect'];assert x>=0 and y>=0 and w>0 and h>0 and x+w<=360 and y+h<=116
 proof=dict(newSeal=newSeal,oldSeal=oldSeal,oldBodyMutationObserved=False,images=[n,one,four,old,compare],creaturePrefix=creature,
             exactEveryNativePreviewPixel=True,exactEvery4xBlock=True,comparisonEveryOriginalRGBPreserved=True,
             comparison='R1 top/final R2 bottom, diagnostic32-entry union palette retains each original RGB; environment entries differ',
             creature16PrefixExact=True,environment8Revised=True,allCourtyardPixelsOpaque=True,sourcePaletteExact=True,
             sourceCounts=counts,intendedZones=metadata['safeCompositionZones'],zonesQualification=metadata['safeZonesQualification'])
 guard()
except BaseException:
 failure=traceback.format_exc()
finally:
 stop.set()
 if worker is not None:worker.join(timeout=1)
 if worker is not None and worker.is_alive():failure=(failure or '')+'\nmonitor thread failed bounded join'
 final=row()
 checks=dict(admission=initial['headroom']>=WORK+RESERVE and initial['VmRSS']<=WORK and initial['VmHWM']<=WORK,
             allSampleRows=all(valid(q) for q in samples),final=valid(final),unchangedMaximum=all(q['maximum']==initial['maximum'] for q in samples+[final]),
             eventsUnchanged=all(q['events']==initial['events'] for q in samples+[final]),noMonitorBreaches=not breaches,
             monitorJoined=worker is None or not worker.is_alive(),wholeWithin30=time.monotonic()-started<=30,proofCompleted=proof is not None and failure is None)
 result=dict(scope='One fresh64MiB cgroup-delta AND actual self RSS/HWM+512reserve process; source/native only, no art selection',
             initial=initial,final=final,checks=checks,samples=samples,breaches=breaches,failure=failure,
             peakCgroupDelta=max([q['current']-initial['current'] for q in samples+[final]]),
             minHeadroom=min(q['headroom'] for q in samples+[final]),peakActualRSS=max(q['VmRSS'] for q in samples+[initial,final]),
             peakActualHWM=max(q['VmHWM'] for q in samples+[initial,final]),
             ruMaxRSSAtAdmission=inheritedMaxRSS,ruMaxRSSAtFinal=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
             rssQualification='Kernel /proc/self/status VmRSS and VmHWM gate this exec; ru_maxrss can retain historical inherited high-water and is recorded separately, not misread as fresh process RSS. Supervisor-free source process: its baseline starts after interpreter startup; absolute actual RSS/HWM are also capped64MiB, so cgroup delta is not claimed to count pre-baseline interpreter memory.',
             wholeSeconds=time.monotonic()-started,pid=os.getpid(),allOwnReadFDsClosed=True,monitorThreadClosed=worker is None or not worker.is_alive(),
             atimeQualification='NOATIME reads only here; prior ordinary image views may have altered atime; unchanged claim is sealed bodies only')
 if proof is not None:proofPin=put('PROOF.json',proof);result['proof']=proofPin
 resultPin=put('RESULT.json',result)
 print(json.dumps(dict(result=resultPin,proof=result.get('proof'),checks=checks,samples=len(samples),failure=failure,
                       peakActualRSS=result['peakActualRSS'],peakCgroupDelta=result['peakCgroupDelta'],minHeadroom=result['minHeadroom'])))
 if not all(checks.values()):raise SystemExit(1)
