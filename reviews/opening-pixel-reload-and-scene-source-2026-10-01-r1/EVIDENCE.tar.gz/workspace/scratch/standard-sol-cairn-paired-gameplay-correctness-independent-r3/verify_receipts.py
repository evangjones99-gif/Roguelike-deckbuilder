import os,json,hashlib
from pathlib import Path
c=Path('/sys/fs/cgroup');head=int((c/'memory.max').read_text())-int((c/'memory.current').read_text());assert head>=570425344
s=Path('/workspace/scratch');out=s/'standard-sol-cairn-paired-gameplay-correctness-independent-r3';p=s/'standard-sol-cairn-paired-comparison-actual-r3-phase1';pins={}
def read(x):
 x=Path(x);fd=os.open(x,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as a:b=a.read(1048577)
 assert len(b)<=1048576;pins[str(x)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};return b
def j(x):return json.loads(read(x))
def digest(m):return hashlib.sha256(json.dumps(dict(sorted(m.items())),separators=(',',':')).encode()).hexdigest()
def mp(a,key='path'):
 assert len({x[key] for x in a})==len(a)
 return {x[key]:x['sha256'] for x in a}
f=j(s/'first-five-opening-cairn-pixel-sheet-r5-runtime-freeze-root-r7.json');assert pins[str(s/'first-five-opening-cairn-pixel-sheet-r5-runtime-freeze-root-r7.json')]['sha256']=='f610ece3508def592aad407a21e39361806a21e82004268abc4859fb6544efa5'
a=j(p/'BYTE-AUDIT-before.json');b=j(p/'BYTE-AUDIT-after.json');served=j(p/'SERVED-BYTE-AUDIT.json')
assert a['inputs']==b['inputs'] and a['outputs']==b['outputs'] and a['controls']==b['controls']
assert mp(a['inputs'])==f['inputs'] and mp(a['outputs'])==mp(served['served'])==f['outputs']
assert len(f['inputs'])==89 and len(f['outputs'])==57 and digest(f['inputs'])==f['sourceDigest'] and digest(f['outputs'])==f['outputsDigest']
src=s/'standard-sol-cairn-paired-comparison-driver-author-r3';m=j(src/'MANIFEST.json');assert pins[str(src/'MANIFEST.json')]['sha256']=='899eebde435c0b859e44675997c482e3d6470747f2ef77d2537b10af51a4c12a'
assert mp(a['controls'],'name')=={x['name']:x['sha256'] for x in m['bodies']}
for x in m['bodies']:
 read(src/x['name']);assert pins[str(src/x['name'])]=={'bytes':x['bytes'],'sha256':x['sha256']}
fresh=[];core=[];stage=Path(f['stage'])
for n,h in f['inputs'].items():
 if n.startswith('public/') or n=='desktop/icon.png':continue
 read(stage/n);assert pins[str(stage/n)]['sha256']==h;fresh.append(n)
assert len(fresh)==36
for n,h in f['outputs'].items():
 if n.startswith(('art/','audio/')):continue
 read(stage/'dist'/n);assert pins[str(stage/'dist'/n)]['sha256']==h;core.append(n)
assert len(core)==5
prov=j(stage/'dist/build-provenance.json');assert prov['hashes']==f['inputs'] and prov['sourceDigest']==f['sourceDigest']
v=j(p/'VISUAL-RESULT.json');j(p/'VISUAL-PROGRESS.json');r=j(p/'RESULT.json');ad=j(p/'ADMISSION.json');credit=j(p/'INSIDE-PHASE-ACCOUNTING.json');launch=j(p/'OWNED-LAUNCH.json');read(p/'EXECUTION.log')
life=[json.loads(x) for x in read(p/'LIFECYCLE.jsonl').splitlines()];reloadlog=[json.loads(x) for x in read(p/'RELOAD-BOUNDS-ASSET.jsonl').splitlines()]
assert v['sourceDigest']==f['sourceDigest'] and v['outputsDigest']==f['outputsDigest'] and v['completed'] and not v['pageErrors'] and v['browser']==v['server']=='CLOSED'
assert len(v['actions'])==34 and len(v['captures'])==12 and len(v['contexts'])==2
work=896*1048576;reserve=512*1048576;initial=r['initial'];final=r['final'];rows=r['samples']
assert ad['initial']==initial and ad['admitted'] and ad['work']==work and ad['reserve']==reserve and initial['headroom']>=work+reserve and initial['free']>=64*1048576
assert credit['sameOuterAdmission'] and not credit['freshAdmission'] and credit['spent']+credit['remaining']==work
def resource(q):return q['maximum']==initial['maximum'] and q['headroom']==q['maximum']-q['current'] and q['headroom']>=reserve and q['current']-initial['current']<=work and q['free']>=1048576
for q in rows:assert q['delta']==q['current']-initial['current']
checks={'sampled_resources':bool(rows) and all(resource(q) for q in rows),'final_resources':resource(final),'memory_events_unchanged':r['memory_events_before']==r['memory_events_after'],'whole_within120':r['whole_seconds']<=120,'no_observed_tracked_live_descendants':all(q['state']=='Z' for q in r['post_wait_descendants'].values()) and r['live_remaining']=={},'driver_rc0':r['exit_code']==0,'no_lifecycle_or_cleanup_failure':r['failure'] is None and not r['cleanup_errors']}
assert checks==r['checks'] and all(checks.values()) and r['normal_wait']
assert life[-1]['event']=='normal browser and server close' and not life[-1]['errors'] and life[-1]['wholeElapsedMs']<v['wholeElapsedMs']<=90000
assert launch['identities'][str(launch['pid'])]['starttime']==r['owned_observed'][str(launch['pid'])]['starttime'] and r['tracked_zombies']==r['post_wait_descendants']
for pid,q in r['post_wait_descendants'].items():assert q['state']=='Z' and q['starttime']==r['owned_observed'][pid]['starttime']
summary=[];raws={};contexts=v['contexts']
for ctx in contexts:
 name=ctx['name'];assert ctx['completed'] and ctx['context']=='CLOSED' and ctx['captureCount']==6 and ctx['cardOccurrence']=={'cardId':'cairnhound','index':'4'} and ctx['cairnUID']=='a3' and ctx['thrallUID']=='e2'
 assert any(e['type']=='keydown' and e['trusted'] and e.get('id')=='seed' for e in ctx['seedInputEvents'])
 cp={};raws[name]={}
 for label in ['C0','C1','C2','C2S','C3','C4']:
  q=j(p/(name+'-'+label+'-OPAQUE-SAVE.json'));assert q['observedOnly'];raw=q['raw'];sha=hashlib.sha256(raw.encode()).hexdigest();assert sha==ctx['checkpoints'][label]['sha256'] and raw==ctx['checkpoints'][label]['raw'];cp[label]=json.loads(raw);raws[name][label]=raw
 i,bind,cmd,scour,end,resume=[cp[k] for k in ['C0','C1','C2','C2S','C3','C4']]
 assert i['seed']==9592029 and i['difficulty']==0 and i['phase']=='battle' and not i['allies'] and i['hand']==['survey','sunder','scour','ironward','cairnhound']
 assert bind['energy']==4 and bind['block']==2 and bind['allies'][0]['uid']=='a3' and bind['allies'][0]['hp']==7 and not bind['allies'][0]['acted']
 assert bind['enemies'][1]['uid']=='e2' and bind['enemies'][1]['hp']==7
 assert cmd['energy']==bind['energy'] and cmd['allies'][0]['acted'] and cmd['allies'][0]['hp']==7 and cmd['enemies'][1]['uid']=='e2' and cmd['enemies'][1]['hp']==2 and cmd['hand']==bind['hand'] and cmd['stats']['damageDealt']==5
 assert ctx['scourPlayed'] and scour['phase']=='battle' and len(scour['enemies'])==1 and scour['enemies'][0]['uid']=='e1' and scour['energy']==3 and 'scour' not in scour['hand'] and scour['discard']==['scour'] and scour['stats']['cardsPlayed']==2 and scour['stats']['damageDealt']==7
 assert end['phase']=='battle' and end['turn']==2 and end['hp']==65 and end['energy']==5 and end['allies'][0]['hp']==7 and not end['allies'][0]['acted'] and end['enemies'][0]['uid']=='e1' and end['enemies'][0]['hp']==16 and end['enemies'][0]['block']==4 and len(end['enemies'])==1 and end==resume
 assert len({q['rng'] for q in cp.values()})==1
 actions=[q for q in v['actions'] if q['case']==name]
 for q in actions:
  events=q['events']
  if 'point' in q:
   assert not q['assertionsPending']
   for kind in ['pointerdown','pointerup']:
    assert any(e['type']==kind and e['trusted'] and abs(e['x']-q['point']['x'])<=1 and abs(e['y']-q['point']['y'])<=1 for e in events)
  else:assert any(e['type']=='keydown' and e['trusted'] and e['key']==q['key'] for e in events)
  if q['label'] not in ['Accept contract with ordinary typed seed','bind actual first legal Cairn occurrence','command actual Cairn into actual Bone Thrall','play actual Scour into surviving Thrall','ordinary native End turn']:assert q['beforeSHA']==q['afterSHA']
 def obs(label):return next(z['row'] for z in ctx['observations'] if z['label']==label)
 inspect=obs('Cairn Inspect');assert inspect['dialog']['open'] and inspect['dialog']['title']=='Cairn Hound · binding 1' and '7/7 health · 3 attack' in inspect['dialog']['text']
 assert obs('actual Thrall consequence preview')['preview']['kind']=='consequence' and '5 health damage' in obs('actual Thrall consequence preview')['preview']['text']
 assert not obs('before ordinary End turn; actual modal and selection')['dialog']['open'] and not obs('after ordinary End turn or visible confirmation')['dialog']['open']
 assert ctx['reducedSelectedCancel'] and obs('native reduced-motion preference')['viewport']['reducedMotion'] and obs('reduced-motion actual pending command')['selection']['unitUIDs']==['a3']
 cancel=obs('reduced-motion command cancelled');assert not cancel['dialog']['open'] and not cancel['selection']['targeting'] and not cancel['selection']['unitUIDs']
 reload=ctx['reloadReceipts'];assert 2<=len(reload)<=7 and ctx['reloadInitialReceipt']==reload[0] and ctx['reloadFinalReceipt']==reload[-1] and ctx['reloadNaturalWaitLimitMs']==1500
 recorded=[{k:z for k,z in q.items() if k!='case'} for q in reloadlog if q['case']==name];assert recorded==reload
 cont=next(q for q in actions if q['label']=='ordinary Continue of this earned run')
 for q in reload:
  assert q['continueObservedAtMs']==cont['releaseObservedAtMs'] and q['elapsedSinceContinueMs']>=0 and q['publishedCairn']['uid']=='a3' and q['viewport']=={'width':1440,'height':900,'dpr':1,'reducedMotion':True} and q['scroll']=={'x':0,'y':0,'width':1440,'height':900}
  assert q['assetResponseObserved']==any(e['responseEnd']>0 for e in q['assetResources'])
 assert ctx['reloadAdjacentSizeAgreement'] and abs(reload[-1]['publishedCairn']['body']['width']-reload[-2]['publishedCairn']['body']['width'])<.5 and abs(reload[-1]['publishedCairn']['body']['height']-reload[-2]['publishedCairn']['body']['height'])<.5
 if ctx['query']:
  assert reload[-1]['assetResponseObserved'] and 'Cairn pixel study' in reload[-1]['footer'] and reload[-1]['assetResources'][0]['encodedBodySize']==2874
 else:assert not reload[-1]['assetResources'] and 'Playable prototype' in reload[-1]['footer']
 caps=[q for q in v['captures'] if q['case']==name];assert [q['label'] for q in caps]==['opening','settled-ready-requested','anticipation-requested','contact-window-requested','recovery-window-requested','ordinary-reload-continue']
 for q in caps:assert not q['pending'] and not q['phaseCertified'] and Path(q['path']).stat().st_size==q['bytes']
 summary.append({'name':name,'checkpoints':{k:ctx['checkpoints'][k]['sha256'] for k in cp},'reloadReceipts':reload,'publishedBodies':[{ 'label':z['label'],'body':next((a['body'] for a in z['row']['actors'] if a['uid']=='a3'),None)} for z in ctx['observations']],'actions':len(actions),'RNG':end['rng']})
assert raws['A-current']==raws['B-pixel']
for q in v['canonicalComparisons']:assert q['byteEqual'] and q['aSHA']==q['bSHA']==contexts[0]['checkpoints'][q['label']]['sha256']
hwm=int(next(q for q in Path('/proc/self/status').read_text().splitlines() if q.startswith('VmHWM:')).split()[1])*1024;assert hwm<=33554432
result={'decision':'ACCEPT_FIXED_CANONICAL_AND_NATIVE_UI_PAIR_ONLY','inputCount':89,'outputCount':57,'sourceDigest':f['sourceDigest'],'outputsDigest':f['outputsDigest'],'freshNonmediaInputs':len(fresh),'freshCoreOutputs':len(core),'rawSixCheckpointsPairByteEqual':True,'contexts':summary,'resourceChecks':checks,'samples':len(rows),'maxDelta':max(q['current']-initial['current'] for q in rows+[final]),'minHeadroom':min(q['headroom'] for q in rows+[final]),'initialHeadroom':initial['headroom'],'wholeSeconds':r['whole_seconds'],'driverMs':v['wholeElapsedMs'],'ownedCount':len(r['owned_observed']),'ownedLaunch':launch,'trackedZombies':r['tracked_zombies'],'freshReviewHeadroom':head,'actualOwnVmHWM':hwm,'limits':['metadata-only PNG receipts; no imagebody/hash/personalview','B-pixel reload body equals baseline despite assetresponse; pixelpaint acceptance withheld','same-size response not decode/paint/fit/cel certification','native keyboard e produces game-handler untrusted click, not caller forcedclick','no300/humanfun/pixelart/contact/terminal/generalnative acceptance']}
(out/'INDEPENDENT-RECOMPUTATION.json').write_text(json.dumps(result,indent=2)+'\n');(out/'READ-PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(out/'REVIEW-PREP-FAILURE.json').write_text(json.dumps({'kind':'Reviewer manually mistyped expected freeze hash in initial bounded read assertion','effect':'AssertionError before game/runtime execution or proof claims','repair':'correct complete immutable f610ece3508def592aad407a21e39361806a21e82004268abc4859fb6544efa5 checked against actual bytes; no candidate failure inferred'},indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['contexts','ownedLaunch','trackedZombies']}))
