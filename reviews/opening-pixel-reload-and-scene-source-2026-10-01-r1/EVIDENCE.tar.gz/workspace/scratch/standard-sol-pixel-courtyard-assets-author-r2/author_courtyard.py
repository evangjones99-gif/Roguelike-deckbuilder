"""Original indexed native courtyard. All contours/clusters are direct authored coordinates.
No image inputs, filters, resampling, imported illustration or game/engine access.
"""
import os,struct,zlib,json,hashlib,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(32*1048576,32*1048576))
ROOT='/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r2'
W,H=360,116
# First16 RGB entries exactly match native Cairn/Bone studies; background is opaque.
PAL=[(0,0,0),(14,20,23),(27,37,42),(43,58,62),(65,81,82),(77,91,88),(108,122,111),(149,158,137),(190,196,164),(57,91,91),(88,125,117),(135,173,145),(194,217,170),(85,75,59),(125,107,75),(213,176,98),
 (24,32,38),(41,50,55),(53,62,66),(69,76,78),(91,98,93),(123,118,97),(104,77,47),(167,118,65)]
BASE={'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text())}
assert BASE['maximum']-BASE['current']>=32*1048576+512*1048576
P=bytearray([16])*(W*H)
def guard():
 c=int(Path('/sys/fs/cgroup/memory.current').read_text());m=int(Path('/sys/fs/cgroup/memory.max').read_text());v=os.statvfs(ROOT);assert m==BASE['maximum'] and m-c>=512*1048576 and c-BASE['current']<=32*1048576 and v.f_bavail*v.f_frsize>=1048576;return {'current':c,'maximum':m,'headroom':m-c,'free':v.f_bavail*v.f_frsize}
def dot(x,y,col):
 assert 0<=x<W and 0<=y<H;P[y*W+x]=col

def line(a,b,col):
 x,y=a;xx,yy=b;dx=abs(xx-x);sx=1 if x<xx else -1;dy=-abs(yy-y);sy=1 if y<yy else -1;e=dx+dy
 while True:
  dot(x,y,col)
  if x==xx and y==yy:break
  q=2*e
  if q>=dy:e+=dy;x+=sx
  if q<=dx:e+=dx;y+=sy

def poly(points,col,edge=None):
 for y in range(min(p[1]for p in points),max(p[1]for p in points)+1):
  for x in range(min(p[0]for p in points),max(p[0]for p in points)+1):
   inside=False;j=len(points)-1
   for i,(xi,yi)in enumerate(points):
    xj,yj=points[j]
    if (yi>y+.5)!=(yj>y+.5)and x+.5<(xj-xi)*(y+.5-yi)/(yj-yi)+xi:inside=not inside
    j=i
   if inside:dot(x,y,col)
 if edge is not None:
  for a,b in zip(points,points[1:]+points[:1]):line(a,b,edge)
def cluster(points,col):
 for x,y in points:dot(x,y,col)
# Cold weather: small irregular cloud planes, not noise or a gradient.
poly([(59,8),(76,7),(87,10),(113,9),(127,12),(119,15),(83,14),(71,16),(58,13)],17)
poly([(207,3),(225,2),(237,5),(265,5),(277,8),(259,10),(231,8),(218,9),(204,6)],17)
poly([(91,19),(111,17),(137,18),(152,21),(146,23),(108,22)],2)
poly([(239,18),(265,16),(287,20),(291,23),(250,24)],2)
# Distant central abbey fragment recedes behind the open lane.
poly([(139,24),(141,12),(150,12),(151,4),(157,4),(161,8),(164,8),(164,1),(171,1),(171,13),(183,14),(187,6),(192,6),(192,11),(201,12),(205,20),(215,24)],1)
poly([(147,25),(150,17),(160,15),(169,17),(169,24)],2)
poly([(183,24),(185,18),(195,17),(199,22),(207,24)],2)
line((156,6),(160,10),3);line((167,3),(167,10),2)
# Quiet ground plane begins at the old abbey threshold, about20% down.
poly([(0,25),(94,23),(177,25),(269,23),(359,27),(359,115),(0,115)],17)
# Continuous walkable slate. Slabs differ by one close value step; dark is narrow grout.
SLABS=[
 (18,[(0,30),(58,28),(61,42),(0,44)]),
 (17,[(61,28),(133,27),(130,43),(62,44)]),
 (18,[(136,28),(217,29),(222,44),(132,45)]),
 (17,[(220,30),(301,31),(307,44),(225,45)]),
 (18,[(305,31),(359,32),(359,45),(308,46)]),
 (17,[(0,47),(50,45),(48,68),(0,70)]),
 (18,[(53,46),(132,46),(122,68),(50,69)]),
 (17,[(135,47),(221,46),(230,67),(125,69)]),
 (18,[(225,48),(309,46),(321,69),(234,69)]),
 (17,[(313,47),(359,48),(359,70),(325,70)]),
 (18,[(0,74),(48,72),(53,96),(0,99)]),
 (17,[(52,73),(121,71),(138,97),(56,98)]),
 (18,[(125,72),(229,71),(238,97),(142,99)]),
 (17,[(234,72),(321,72),(314,97),(242,98)]),
 (18,[(326,74),(359,73),(359,99),(319,99)]),
 (17,[(0,102),(53,101),(58,115),(0,115)]),
 (18,[(57,102),(140,102),(151,115),(62,115)]),
 (17,[(144,103),(239,101),(249,115),(155,115)]),
 (18,[(244,102),(313,101),(309,115),(253,115)]),
 (17,[(318,102),(359,103),(359,115),(314,115)])]
for col,points in SLABS:poly(points,col)
# Native one-pixel perspective grout, interrupted/chipped rather than black panels.
JOINTS=[[(0,45),(48,44),(59,45),(111,44),(130,45)],[(219,45),(271,45),(280,46),(307,45),(359,47)],
 [(0,71),(39,70),(50,71),(104,70),(120,70)],[(124,70),(165,69),(191,70),(232,70)],[(234,70),(283,71),(321,71),(359,72)],
 [(0,100),(36,99),(55,100),(96,99),(136,100)],[(141,101),(194,100),(240,100)],[(242,100),(282,99),(315,100),(359,101)],
 [(59,29),(61,43),(52,46),(49,67)],[(133,29),(130,43),(134,47),(123,67)],[(219,31),(222,44),(224,47),(231,67)],[(301,32),(308,45),(311,48),(322,68)],
 [(49,74),(52,94),(55,98),(57,104),(60,115)],[(122,74),(134,94),(139,100),(146,108),(150,115)],[(231,74),(236,94),(241,100),(247,108),(252,115)],[(323,75),(316,95),(315,101),(311,113)]]
for points in JOINTS:
 for a,b in zip(points,points[1:]):line(a,b,16)
# Short lit edges and tiny chips ground joints; avoid continuous bright lane stripes.
for a,b in [((0,46),(27,46)),((73,45),(96,45)),((244,46),(268,46)),((330,48),(358,49)),
 ((2,74),(23,73)),((57,72),(78,72)),((151,71),(171,71)),((259,73),(280,73)),((335,74),(358,74)),
 ((0,102),(29,101)),((64,101),(86,101)),((172,102),(197,101)),((268,101),(293,101)),((330,103),(354,103))]:line(a,b,19)
for points,col in [([(47,70),(49,69),(52,71),(50,73)],19),([(130,44),(133,43),(136,46),(133,47)],19),([(306,45),(309,44),(312,47),(309,48)],19),([(314,99),(318,98),(320,101),(316,103)],19),([(137,98),(140,97),(142,100),(138,102)],19)]:poly(points,col)
cluster([(14,47),(16,46),(45,70),(131,46),(309,46),(316,100),(342,104)],20)
# Worn central contract paving stone: seated in ground with a narrow occluded edge.
poly([(155,48),(191,46),(205,51),(202,69),(189,75),(157,72)],16)
poly([(157,48),(190,47),(202,51),(200,67),(188,72),(158,70)],18)
line((158,48),(185,47),19);line((203,53),(201,66),17)
poly([(158,68),(166,69),(168,71),(157,70)],17)
poly([(190,48),(193,49),(191,51),(188,50)],19)
cluster([(159,49),(161,48),(193,50),(199,67)],20)
# Ruined near-edge abbey blocks frame, rather than filling actor/readout space.
poly([(0,0),(39,0),(39,5),(44,5),(43,18),(51,21),(50,41),(55,42),(52,63),(43,68),(39,54),(0,53)],1)
poly([(0,4),(28,4),(30,13),(27,35),(32,40),(28,52),(0,52)],3)
poly([(31,9),(38,9),(36,16),(41,18),(39,32),(44,35),(40,48),(33,48)],2)
poly([(0,17),(13,18),(12,35),(20,39),(17,48),(0,48)],2)
# Broken lancet recess, not a pristine symmetric graphic.
poly([(6,33),(8,21),(12,15),(17,12),(23,14),(26,21),(24,34),(22,40),(9,40)],1)
line((8,22),(12,16),4);line((12,16),(17,13),4);line((18,13),(23,16),3);line((25,23),(23,35),2)
# Masonry beds/jagged highlights are individual purposeful clusters.
for a,b,col in [((0,10),(24,10),4),((0,24),(6,24),4),((27,23),(30,24),4),((0,38),(7,39),4),((0,51),(27,52),4),((31,10),(36,10),3),((35,36),(41,35),3)]:line(a,b,col)
for points,col in [([(2,7),(5,6),(7,8),(4,9)],4),([(21,5),(24,5),(23,8),(20,7)],2),([(29,35),(31,33),(34,35),(31,38)],3),([(2,45),(6,44),(8,47),(5,48)],3)]:poly(points,col)
# Far-right wall is a broken buttress and sloped rubble, not a mirrored left wall.
poly([(313,0),(339,0),(339,4),(348,4),(347,13),(354,17),(354,29),(359,29),(359,62),(343,60),(337,44),(328,40),(325,26),(309,24)],1)
poly([(320,5),(336,4),(337,13),(342,16),(340,35),(346,43),(345,54),(337,52),(329,36),(324,23)],3)
poly([(346,20),(354,24),(359,23),(359,48),(350,51),(343,42)],2)
poly([(322,13),(327,9),(332,10),(335,15),(334,28),(328,29),(324,24)],1)
line((324,13),(327,10),4);line((332,10),(334,14),4)
for a,b,col in [((321,7),(334,6),4),((335,18),(340,17),4),((329,31),(339,30),4),((340,43),(346,44),4),((349,28),(358,30),3),((352,43),(359,42),3)]:line(a,b,col)
# Collapsed stair at the threshold leads into the central lane, off-centre.
STEPS=[
 (2,[(135,27),(173,25),(193,27),(191,31),(142,32),(134,30)]),
 (3,[(141,32),(192,30),(203,34),(199,38),(144,39),(137,36)]),
 (2,[(137,39),(197,37),(209,40),(205,45),(144,46),(134,43)])]
for col,pts in STEPS:poly(pts,col)
line((136,27),(171,26),4);line((143,33),(188,31),4);line((141,40),(190,38),3)
poly([(165,28),(171,27),(175,30),(171,33),(163,32)],1)
poly([(200,39),(207,39),(212,44),(208,47),(200,45)],3)
# Left rubble and foreground slate edges avoid the reserved body centres.
for pts,col in [([(5,57),(20,54),(34,58),(30,66),(8,68)],3),([(36,59),(42,56),(50,60),(46,68),(35,65)],2),([(10,75),(16,71),(24,74),(22,79),(11,81)],3),([(335,60),(344,56),(353,62),(350,71),(336,69)],3),([(347,74),(354,69),(359,72),(359,82),(348,81)],2),([(3,109),(16,105),(26,109),(24,115),(0,115)],2),([(339,112),(346,107),(359,112),(359,115),(338,115)],2)]:
 poly(pts,col)
 line(pts[0],pts[1],4)
# Sparse weather and small age clusters are deliberately outside creature centres.
for a,b in [((103,3),(101,7)),((128,10),(126,14)),((228,12),(226,16)),((257,1),(255,5)),((296,8),(294,12))]:line(a,b,18)
cluster([(3,9),(4,9),(19,42),(20,42),(22,44),(338,35),(339,34),(341,35),(11,64),(13,65),(345,66)],5)
# A broken contract-cut rune is incised into the paving stone, no loop/target badge.
for a,b in [((165,55),(173,51)),((175,51),(184,55)),((174,54),(172,64)),((168,58),(181,60)),((181,60),(186,55)),((177,64),(183,65))]:
 line(a,b,16);line((a[0],a[1]+1),(b[0],b[1]+1),19)
cluster([(173,53),(174,59),(180,61),(182,64),(168,57)],18)
# Hard stepped warm light is local to walls and narrow floor wedges.
for pts,col in [([(31,30),(45,29),(52,34),(52,44),(46,48),(32,46)],13),
 ([(34,32),(43,31),(48,35),(47,43),(41,46),(33,42)],22),
 ([(37,34),(43,33),(46,37),(44,41),(37,41)],23),
 ([(315,30),(332,31),(345,36),(347,46),(339,51),(319,46)],13),
 ([(320,32),(331,33),(341,37),(341,46),(333,49),(321,44)],22),
 ([(327,35),(334,35),(338,39),(335,44),(327,42)],23),
 ([(24,56),(43,54),(53,59),(51,66),(32,69),(20,63)],13),
 ([(28,57),(43,56),(49,60),(46,64),(31,65),(25,62)],22),
 ([(311,57),(332,55),(347,60),(345,69),(327,71),(309,65)],13),
 ([(315,58),(331,57),(341,61),(337,66),(324,67),(314,63)],22)]:poly(pts,col)
# Wall stone lit by those sconces still retains bed joints and chipped material edges.
for a,b,col in [((33,33),(46,33),21),((32,40),(40,40),14),((44,44),(48,43),21),((322,35),(336,36),21),((335,44),(342,45),14),((321,43),(328,45),21),((26,61),(37,59),14),((317,63),(330,61),14)]:line(a,b,col)
cluster([(34,34),(36,33),(45,36),(46,37),(323,36),(325,37),(338,39),(340,42),(31,63),(328,66)],21)
# Left iron backplate, bracket and basket: solid functional geometry, original pixels.
poly([(33,31),(37,31),(38,44),(35,46),(32,44)],2,1)
line((34,33),(35,41),4)
poly([(35,40),(42,39),(44,41),(43,43),(35,43)],3,1)
poly([(38,38),(45,38),(44,43),(40,44)],3,1)
line((39,39),(44,39),20);line((40,41),(43,41),4)
poly([(40,39),(38,36),(40,34),(41,30),(43,34),(43,36),(45,38),(43,40)],23)
poly([(41,38),(40,36),(42,33),(43,36),(42,38)],15)
cluster([(42,35),(42,36)],8)
# Right fixture differs in angle/height and sits over its own cast-light steps.
poly([(323,32),(328,33),(327,47),(324,48),(321,45)],2,1)
line((325,35),(324,43),4)
poly([(325,43),(333,41),(337,43),(335,45),(325,46)],3,1)
poly([(330,41),(337,41),(336,46),(332,47)],3,1)
line((331,42),(336,42),20);line((332,44),(335,44),4)
poly([(332,42),(329,39),(331,37),(332,34),(335,37),(334,39),(337,41),(334,43)],23)
poly([(333,41),(331,39),(333,36),(335,39),(334,41)],15)
cluster([(333,38),(334,39)],8)
# Threshold underlip/edge occlusion grounds the collapsed stair in the continuous floor.
line((143,46),(192,46),16);line((149,47),(183,47),2)
cluster([(146,33),(148,33),(190,39),(207,43)],20)
# A tiny far ember remains secondary to the readable architecture.
cluster([(199,28),(200,28)],22);dot(199,27,23)
guard()
def chunk(k,b):return struct.pack('>I',len(b))+k+b+struct.pack('>I',zlib.crc32(k+b)&0xffffffff)
def png(w,h,p):
 raw=b''.join(b'\0'+p[y*w:(y+1)*w]for y in range(h))
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,3,0,0,0))+chunk(b'PLTE',bytes(c for rgb in PAL for c in rgb))+chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b'')
def put(n,b):
 fd=os.open(ROOT+'/'+n,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  v=memoryview(b)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
 return {'path':ROOT+'/'+n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
native=bytes(P);files=[];nativePNG=png(W,H,native);files.append(put('pixel-courtyard-study-r2.png',nativePNG));files.append(put('courtyard-preview-1x.png',nativePNG))
preview=bytearray(1440*464)
for y in range(H):
 for x in range(W):
  for dy in range(4):
   start=(y*4+dy)*1440+x*4;preview[start:start+4]=bytes([native[y*W+x]])*4
files.append(put('courtyard-preview-4x.png',png(1440,464,preview)))
zones=[{'name':'far-left combatant and attached readouts','nativeRect':[59,18,70,47]},{'name':'far-right combatant and attached readouts','nativeRect':[232,18,70,47]},{'name':'near-left bindings','nativeRect':[51,63,80,50]},{'name':'near-right bindings','nativeRect':[230,63,80,50]},{'name':'near hunter','nativeRect':[154,65,52,48]}]
meta={'asset':'original opt-in courtyard study, not integrated','nativeSize':[360,116],'intendedIntegerPreview':[1440,464],'nativePixelSHA256':hashlib.sha256(native).hexdigest(),'palette':[{'index':i,'rgb':list(c),'alpha':255}for i,c in enumerate(PAL)],'paletteEntries':24,'opaque':True,'transparentEntries':0,'creaturePalettePrefixSHA256':hashlib.sha256(bytes(c for rgb in PAL[:16]for c in rgb)).hexdigest(),'paletteExpansionReasons':{'16':'narrow grout/cool shadow, never a broad floor void','17-18':'close continuous slate value rhythm preserving quiet actor zones','19-20':'small lit/chipped material edges rather than flat panel outlines','21':'weathered masonry warmed by local hard cast-light steps','22-23':'warmer cast-light/flame envelope around recognizable iron sconces, below15/8 flame core'},'files':files,'pixelIndicesUsed':sorted(set(native)),'safeCompositionZones':zones,'safeZonesQualification':'Intended native composition only, not actual dynamic Arena cell/body/intent/Inspect/hit/readout fit. Multiple formations/viewport/header allocation untested. Quiet means low texture/contrast, not empty art or hidden controls.','composition':{'coldSkyTopFraction':.2,'farCentres':[[90,41],[270,41]],'nearCentres':[[90,92],[270,92]],'hunterCentre':[180,94],'focalContractFragment':[175,59],'lightSources':[[42,36],[333,39],[199,28]],'asymmetry':'broken left lancet ruin, right buttress/rubble, off-centre collapsed threshold stair'},'provenance':'R2 direct authored native polygons/lines/clusters; unchanged original Gothic perimeter coordinates/raster helpers reused from own sealed R1 source83d2d4008e020df9041e64eedc975535a44b3d1455de41270e2beb55486990a9. Floor/material/contract/fixtures/cast-light contours substantively redrawn; no existing image raster sampled/filtered, generated input, franchise/reference or stochastic texture. Same first16 creature RGB entries plus8 documented environment ramps. Original painted art and all creature studies remain unchanged.','limitations':['Static native art only; no query adapter, game/stage/root edit, build, browser or actual fit.','No selected-art/complete coherent scene/first-five quality or human-fun claim.','Backdrop at4x and current creature study at2x use nested integer grids; matching visual density/cohesion is untested.','Runtime cover/crop/scaling/fallback/load behaviour needs separate source/actual gates.'],'sourceGuardFinal':guard()}
files.append(put('ASSET-METADATA.json',(json.dumps(meta,indent=2,sort_keys=True)+'\n').encode()))
print(json.dumps({'files':files,'nativeSize':[360,116],'previewSize':[1440,464],'paletteEntries':24,'guard':guard()}))
