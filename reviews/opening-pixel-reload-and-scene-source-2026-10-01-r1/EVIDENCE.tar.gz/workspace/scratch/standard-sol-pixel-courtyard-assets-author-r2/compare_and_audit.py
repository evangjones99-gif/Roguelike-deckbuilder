"""Bounded native PNG audit; old raster used only for exact diagnostic comparison."""
import os, json, hashlib, struct, zlib, resource
from pathlib import Path
ROOT=Path('/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r2')
OLD=Path('/workspace/scratch/standard-sol-pixel-courtyard-assets-author-r1')
NEW=ROOT/'draw-r2'
resource.setrlimit(resource.RLIMIT_DATA,(32*1024*1024,32*1024*1024))
CG=Path('/sys/fs/cgroup')
BASE=int((CG/'memory.current').read_text())
MAX=int((CG/'memory.max').read_text())
assert MAX-BASE>=544*1024*1024
def guard():
    current=int((CG/'memory.current').read_text())
    assert int((CG/'memory.max').read_text())==MAX
    assert MAX-current>=512*1024*1024 and current-BASE<=32*1024*1024
    fs=os.statvfs(ROOT); assert fs.f_bavail*fs.f_frsize>=1024*1024
    return {'current':current,'maximum':MAX,'headroom':MAX-current,'delta':current-BASE}
def read(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        assert os.fstat(fd).st_size<=262144
        out=bytearray()
        while True:
            b=os.read(fd,65536)
            if not b:break
            out.extend(b)
        return bytes(out)
    finally:os.close(fd)
def sha(d):return hashlib.sha256(d).hexdigest()
def png(p):
    d=read(p); assert d[:8]==b'\x89PNG\r\n\x1a\n'
    i=8; chunks=[]; ids=[]; pal=None; wh=None
    while i<len(d):
        n=struct.unpack('>I',d[i:i+4])[0]; kind=d[i+4:i+8]; body=d[i+8:i+8+n]
        assert n<=262144 and i+n+12<=len(d)
        crc=struct.unpack('>I',d[i+8+n:i+12+n])[0]
        assert zlib.crc32(kind+body)&0xffffffff==crc
        chunks.append({'type':kind.decode(),'bytes':n,'crc32':f'{crc:08x}'})
        if kind==b'IHDR':
            w,h,depth,color,comp,filt,inter=struct.unpack('>IIBBBBB',body)
            assert (depth,color,comp,filt,inter)==(8,3,0,0,0);wh=(w,h)
        elif kind==b'PLTE':pal=body
        elif kind==b'IDAT':ids.append(body)
        else:assert kind==b'IEND' and n==0
        i+=n+12
    assert i==len(d) and chunks[-1]['type']=='IEND' and pal is not None
    raw=zlib.decompress(b''.join(ids));w,h=wh
    assert len(raw)==(w+1)*h and len(pal)%3==0
    pix=bytearray()
    for y in range(h):
        assert raw[y*(w+1)]==0
        pix.extend(raw[y*(w+1)+1:(y+1)*(w+1)])
    assert max(pix)<len(pal)//3
    return {'bytes':len(d),'sha256':sha(d),'size':list(wh),'paletteSHA256':sha(pal),'paletteEntries':len(pal)//3,'pixelSHA256':sha(pix),'chunks':chunks,'opaqueBounds':[0,0,w,h],'transparentEntries':0},pal,bytes(pix)
def chunk(kind,d):return struct.pack('>I',len(d))+kind+d+struct.pack('>I',zlib.crc32(kind+d)&0xffffffff)
def write(p,d):
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        view=memoryview(d)
        while view:view=view[os.write(fd,view):]
        os.fsync(fd)
    finally:os.close(fd)
def expanded(row):return bytes(v for v in row for _ in range(4))
def main():
    freeze=read(OLD/'FROZEN.json'); records=json.loads(freeze)['bodies']
    for item in records:
        body=read(OLD/item['name']);assert len(body)==item['bytes'] and sha(body)==item['sha256']
    old,op,ox=png(OLD/'pixel-courtyard-study-r1.png')
    new,np,nx=png(NEW/'pixel-courtyard-study-r2.png')
    one,pp,px=png(NEW/'courtyard-preview-1x.png')
    four,fp,fx=png(NEW/'courtyard-preview-4x.png')
    assert old['size']==new['size']==one['size']==[360,116]
    assert four['size']==[1440,464] and np==pp==fp and nx==px
    for y in range(116):
        row=expanded(nx[y*360:(y+1)*360])
        for yy in range(4):assert fx[(y*4+yy)*1440:(y*4+yy+1)*1440]==row
    assert op[:48]==np[:48] and len(op)==len(np)==72
    combined=op+np[48:]
    scan=bytearray()
    for pixels,isnew in [(ox,False),(nx,True)]:
        for y in range(116):
            row=pixels[y*360:(y+1)*360]
            if isnew:row=bytes(v if v<16 else v+8 for v in row)
            scaled=expanded(row)
            for _ in range(4):scan.extend(b'\0'+scaled)
            guard()
    data=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',1440,928,8,3,0,0,0))+chunk(b'PLTE',combined)+chunk(b'IDAT',zlib.compress(scan,9))+chunk(b'IEND',b'')
    path=ROOT/'courtyard-r1-r2-comparison-4x.png';write(path,data)
    audit,cp,cx=png(path);assert cp==combined
    for pixels,palette,ybase,isnew in [(ox,op,0,False),(nx,np,464,True)]:
        for y in range(116):
            source=pixels[y*360:(y+1)*360]
            mapped=bytes(v if not isnew or v<16 else v+8 for v in source)
            for a,b in zip(source,mapped):assert palette[a*3:a*3+3]==cp[b*3:b*3+3]
            row=expanded(mapped)
            for yy in range(4):assert cx[(ybase+y*4+yy)*1440:(ybase+y*4+yy+1)*1440]==row
    receipt={'oldFrozenSHA256':sha(freeze),'oldBodiesRehashed':len(records),'oldBytesRehashed':sum(r['bytes'] for r in records),'oldBodyMutationObserved':False,'oldAtimeQualification':'Earlier ordinary image viewers may have changed atime; this audit uses NOATIME and makes a body-integrity claim only.','native':new,'preview1x':one,'preview4x':four,'comparison':audit,'comparisonLayout':'R1 top, final R2 bottom; exact4x blocks; all original RGB triplets preserved using diagnostic32-entry union palette. No creative drawing samples the old raster.','palettePrefixExact':True,'alpha':'All native indices opaque, no tRNS chunk; full bound360x116.','limits':'Static author audit, not independent visual acceptance, actual fit, density cohesion, runtime or fun.','guardFinal':guard(),'allOwnFDsClosed':True}
    write(ROOT/'NATIVE-AUDIT.json',(json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode())
    print(json.dumps({'status':'PASS native bytes/CRC/palette/exactinteger previews','comparison':audit,'guardFinal':guard()},sort_keys=True))
if __name__=='__main__':main()
