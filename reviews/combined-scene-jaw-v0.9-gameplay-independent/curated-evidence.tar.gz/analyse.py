import json,gzip,pathlib,hashlib
O=pathlib.Path('/workspace/scratch/combined-scene-jaw-gameplay-independent-v09-r1'); x=json.loads(gzip.decompress((O/'results.json.gz').read_bytes())); rows=x['rows']; pairs=[]
for i in range(0,len(rows),2):
 a,b=rows[i:i+2]; assert a['name']==b['name']; assert a['expected']==b['expected']; assert a['final']==b['final']
 for label in ['active','settled']:
  ar=next(r for r in a['reads'] if r['label']==label);br=next(r for r in b['reads'] if r['label']==label);assert ar['units']==br['units'],(a['name'],label)
 pairs.append(dict(name=a['name'],stateSHA256=hashlib.sha256(json.dumps(a['final'],separators=(',',':')).encode()).hexdigest(),eventCount=len(a['expected']['events']),stableRosterEqual=True))
custom={}
for row in rows:
 if row['name'].startswith('hound-'):
  draws=[d for r in row['reads'] for d in r.get('houndDraws',[])]; helper=[d for d in draws if d['args']==[1024,0,512,512,0,0,512,512]]
  custom[row['variant']+'-'+row['name']]=len(helper)
assert custom['candidate-hound-normal']>0
assert custom['baseline-hound-normal']==0
assert custom['candidate-hound-reduced']==0
assert custom['candidate-hound-canvas']==0
assert custom['candidate-hound-missing']==0
result=dict(pairs=pairs,contexts=len(rows),actions=len(rows)+sum('follow'in r for r in rows),reloads=len(rows),expectedEvents=sum(len(r['expected']['events']) for r in rows),blockedStaleKeyboardChecks=sum(r.get('blockedStaleKeyboard',False)for r in rows),customDrawObservations=custom,pageErrors=sum(len(r['errors'])for r in rows),scope='Natural-RAF draw records overlap across snapshots and are not unique draws, exact-age contacts or FPS. Pure expected events plus actual canonical saves/logs are checked; internal production event dispatch is not intercepted. Stable active/settled HTML rosters compare exact across all35 pairs.')
(O/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['pairs','customDrawObservations']})); print(custom)
