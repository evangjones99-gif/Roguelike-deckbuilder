import pathlib,json,hashlib,urllib.request
O=pathlib.Path('/workspace/scratch/combined-scene-jaw-gameplay-independent-v09-r1')
configs=[('baseline',pathlib.Path('/workspace/scratch/contextual-scene-author-v08-r1/baseline'),4590,'23477f68c99d6d60b0b3f82b286a8d33bb6da6f2ca92c103fbecf5663634959f'),('candidate',pathlib.Path('/tmp/hollowpact-scene-jaw-v09-root-r1'),4173,'efef7131d1c0cbb5cc0420c70e3d2afd9c9dfaf3013dfb8761e6bb8b00d3b525')]
rows=[]
for name,root,port,expected in configs:
 p=json.loads((root/'dist/build-provenance.json').read_bytes()); assert p['sourceDigest']==expected
 hashes={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in p['hashes']}; assert hashes==p['hashes']
 assert hashlib.sha256(json.dumps(hashes,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==expected
 outputs=[]
 for f in sorted((root/'dist').rglob('*')):
  if not f.is_file(): continue
  raw=f.read_bytes(); relative=f.relative_to(root/'dist').as_posix(); body=urllib.request.urlopen(f'http://127.0.0.1:{port}/{relative}',timeout=10).read(); assert raw==body
  outputs.append(dict(path=relative,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 assert len(outputs)==55
 rows.append(dict(name=name,root=str(root),port=port,provenance=p,inputs=hashes,outputs=outputs))
changed=[f for f,h in rows[0]['inputs'].items() if rows[1]['inputs'].get(f)!=h]
assert changed==['package-lock.json','package.json','src/arena.ts','src/main.ts','src/style.css'],changed
assert set(rows[1]['inputs'])-set(rows[0]['inputs'])=={'src/hound-jaw.ts'}
phase=__import__('sys').argv[1]; (O/(phase+'.json')).write_text(json.dumps(dict(rows=rows,changed=changed,added=['src/hound-jaw.ts']),indent=2)+'\n'); print(phase,'153 source files and 110 actual HTTP build bodies checked')
