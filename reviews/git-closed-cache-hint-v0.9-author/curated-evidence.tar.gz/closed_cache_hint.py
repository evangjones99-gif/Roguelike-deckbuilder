"""Root-only, separately reviewed metadata-gated hint; never reads Git bodies.

Authoring this tool authorizes no execution. See AUTHOR.md for declaration and
independent acceptance schemas. Advice may recover nothing or cause writeback.
"""
import argparse, gzip, hashlib, json, os, re, stat, time
from pathlib import Path

REPOSITORY = '/workspace/Roguelike-deckbuilder'
OBJECTS = REPOSITORY+'/.git/objects'
ALLOWLIST_SHA = '3e6280ec7a1825f0b43e92f87f4bcd44ef37d9397064563bb037ebdf5f834bd6'
INPUT_SHA = '8ac82ca3329ae3b46cd6bc07dd48d4a76c2112984647daf4e02cc8ae066d4490'
FINISH_SHA = 'a672823fb05542a05b22b6ad8f02839bc1f4d2e3d35a75422a2d6fb96ab692e1'
FINISH_REVIEW_SHA = '8dfecded2b70774c6562d30532419a07fd1afc04b6eb4c195c2bc08fc21d2e2b'
RESERVE, WORK, MEMORY_RESERVE = 1024**2, 128*1024**2, 512*1024**2
TOTAL_RECEIPT_BUDGET, STREAM_BUDGET = 768*1024, 512*1024
SCOPE = 'Only pinned1020 immutable loose encodings; no bodies read; no other files advised'

def require(ok, message):
    if not ok: raise RuntimeError(message)

def sha(b): return hashlib.sha256(b).hexdigest()

def compact(value): return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()

def close_all(fds):
    for fd in reversed(fds): os.close(fd)

def anchors(path):
    """O_PATH performs no data read/atime update on root-owned ancestors.

    Readable directory/leaf descriptors additionally require O_NOATIME. No
    fallback may silently use normal reads if the kernel refuses these flags.
    """
    require(path.startswith('/') and '..' not in path.split('/'), 'Absolute literal path required')
    flags=os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    fds=[];chain=[]
    try:
        fds.append(os.open('/',flags))
        for name in [x for x in path.split('/') if x]:
            parent=fds[-1];fd=os.open(name,flags,dir_fd=parent)
            fds.append(fd);s=os.fstat(fd);p=os.stat(name,dir_fd=parent,follow_symlinks=False)
            require(stat.S_ISDIR(s.st_mode) and (s.st_dev,s.st_ino,s.st_mode)==(p.st_dev,p.st_ino,p.st_mode),'Directory redirection')
            chain.append((parent,name,fd,s.st_dev,s.st_ino,s.st_mode))
        return fds,chain
    except BaseException:
        close_all(fds);raise

def anchored_stable(chain):
    for parent,name,fd,dev,ino,mode in chain:
        a=os.fstat(fd);b=os.stat(name,dir_fd=parent,follow_symlinks=False)
        require((a.st_dev,a.st_ino,a.st_mode)==(dev,ino,mode)==(b.st_dev,b.st_ino,b.st_mode),'Anchored path changed')

def flags_leaf(): return os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC|os.O_NONBLOCK

def read_control(path,limit):
    # Only explicit small control files use os.read; object descriptors never do.
    p=Path(path);require(p.is_absolute(),'Control path must be absolute')
    fds,chain=anchors(str(p.parent));leaf=None
    try:
        leaf=os.open(p.name,flags_leaf(),dir_fd=fds[-1]);s=os.fstat(leaf)
        require(stat.S_ISREG(s.st_mode) and s.st_size<=limit,'Control exceeds limit/nonregular')
        b=bytearray()
        while part:=os.read(leaf,min(4096,limit+1-len(b))):
            b.extend(part);require(len(b)<=limit,'Control exceeds read limit')
        anchored_stable(chain)
        t=os.fstat(leaf);u=os.stat(p.name,dir_fd=fds[-1],follow_symlinks=False)
        require(s==t==u,'Control metadata changed')
        return bytes(b)
    finally:
        if leaf is not None:os.close(leaf)
        close_all(fds)

def state(s,attrs):
    return {'metadata':[s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,
            s.st_blocks*512,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink],
            'atimeNs':s.st_atime_ns,'xattrs':attrs}

def observe(fd,parent,name,row):
    a=os.fstat(fd);p=os.stat(name,dir_fd=parent,follow_symlinks=False)
    require(stat.S_ISREG(a.st_mode) and stat.S_ISREG(p.st_mode),'Nonregular object')
    attrs={n:os.getxattr(fd,n).hex() for n in sorted(os.listxattr(fd))}
    b=os.fstat(fd);q=os.stat(name,dir_fd=parent,follow_symlinks=False)
    expected={k:row[k] for k in ['metadata','atimeNs','xattrs']}
    require(state(a,attrs)==state(b,attrs)==state(p,attrs)==state(q,attrs)==expected,'Object metadata/atime/xattrs mismatch')
    return expected

def open_object(base,row):
    fan=leaf=None
    try:
        fan=os.open(row['oid'][:2],os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=base)
        leaf=os.open(row['oid'][2:],flags_leaf(),dir_fd=fan)
        return fan,leaf
    except BaseException:
        if leaf is not None:os.close(leaf)
        if fan is not None:os.close(fan)
        raise

def fan_stable(base,row,fan):
    a=os.fstat(fan);b=os.stat(row['oid'][:2],dir_fd=base,follow_symlinks=False)
    require(stat.S_ISDIR(a.st_mode) and (a.st_dev,a.st_ino,a.st_mode)==(b.st_dev,b.st_ino,b.st_mode),'Fanout path changed')

def membership(base):
    result=[];listing=None
    try:
        listing=os.open('.',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC,dir_fd=base)
        for name in sorted(os.listdir(listing)):
            if not re.fullmatch('[0-9a-f]{2}',name):continue
            fan=None
            try:
                fan=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC,dir_fd=base)
                for tail in sorted(os.listdir(fan)):
                    require(re.fullmatch('[0-9a-f]{38}',tail) is not None,'Unexpected fanout entry')
                    s=os.stat(tail,dir_fd=fan,follow_symlinks=False)
                    require(stat.S_ISREG(s.st_mode),'Nonregular fanout leaf')
                    result.append(name+tail)
            finally:
                if fan is not None:os.close(fan)
        return result
    finally:
        if listing is not None:os.close(listing)

def memory_guard():
    p=Path('/sys/fs/cgroup');maximum=(p/'memory.max').read_text().strip()
    require(maximum!='max','Measured cgroup maximum required')
    current=int((p/'memory.current').read_text());headroom=int(maximum)-current
    require(headroom>=WORK+MEMORY_RESERVE,'128MiB work+512MiB reserve not available')
    return headroom

def snapshot():
    p=Path('/sys/fs/cgroup')
    return {name:(p/name).read_text() for name in ['memory.current','memory.max','memory.stat','memory.events']}

def syncdir(fd):
    # O_PATH cannot be fsynced; open an owned readable no-atime view temporarily.
    readable=os.open('.',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC,dir_fd=fd)
    try:os.fsync(readable)
    finally:os.close(readable)

def live_fd_probe(targets, permitted_own_fd=None):
    """Bounded live-FD observation only, not mappings or an atomic reader lock.

    Permission-incomplete/unknown probes refuse. Zombies have no live readers.
    Concurrent descriptor changes remain covered by root's explicit quiet hold.
    """
    pids=sorted(int(n) for n in os.listdir('/proc') if n.isdecimal())
    require(len(pids)<=8192,'Process observation exceeds bounded window')
    examined=0
    for index,pid in enumerate(pids):
        if index%64==0:memory_guard()
        base='/proc/'+str(pid)
        try:
            with open(base+'/stat','r') as f:process=f.read(4096)
            require(')' in process,'Unreadable process identity')
            fields=process.rsplit(')',1)[1].split()
            require(len(fields)>=20,'Incomplete process identity')
            if fields[0] in ('Z','X'):continue
            for name in os.listdir(base+'/fd'):
                require(name.isdecimal(),'Unknown process FD entry')
                if pid==os.getpid() and int(name)==permitted_own_fd:continue
                try:s=os.stat(base+'/fd/'+name)
                except FileNotFoundError:continue  # FD closed before observation.
                examined+=1;require(examined<=16384,'FD observation exceeds bound')
                require((s.st_dev,s.st_ino) not in targets,'Live FD consumes an affected inode')
        except FileNotFoundError:
            require(not os.path.exists(base),'Unknown live process race')
            continue
    return {'liveFDsObserved':examined,'scope':'Current accessible live FDs only; no mapping/global-reader-absence claim'}

class Receipts:
    def __init__(self,path):
        p=Path(path)
        require(p.parent==Path('/workspace/scratch') and re.fullmatch('git-closed-cache-hint-run-[a-zA-Z0-9_-]+',p.name),'New scratch run path required')
        self.fds,self.chain=anchors(str(p.parent));self.fd=None;self.stream=None;self.failure=None
        self.used=0;self.stream_bytes=0
        try:
            os.mkdir(p.name,0o700,dir_fd=self.fds[-1])
            self.fd=os.open(p.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME|os.O_CLOEXEC,dir_fd=self.fds[-1])
            syncdir(self.fd);syncdir(self.fds[-1])
            self.space(TOTAL_RECEIPT_BUDGET)
            self.write('FAILURE-SLOT.json',compact({'status':'reserved; no failure recorded'})+b' '* (16384-len(compact({'status':'reserved; no failure recorded'}))))
            self.failure=os.open('FAILURE-SLOT.json',os.O_WRONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.fd)
        except BaseException:
            if self.fd is not None:os.close(self.fd)
            close_all(self.fds);raise
    def space(self,n):
        v=os.fstatvfs(self.fd);block=v.f_frsize
        need=((n+block-1)//block)*block+2*block
        require(v.f_bavail*block>=RESERVE+need,'Durable receipt reserve refused')
        require(self.used+n<=TOTAL_RECEIPT_BUDGET,'Total receipt allowance exhausted')
    def write(self,name,b):
        self.space(len(b));fd=None
        try:
            fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fd)
            view=memoryview(b)
            while view:
                n=os.write(fd,view);require(n>0,'Short receipt write');view=view[n:]
            os.fsync(fd);syncdir(self.fd);self.used+=len(b)
            self.space(0)
        finally:
            if fd is not None:os.close(fd)
    def begin_stream(self):
        self.stream=os.open('PER-FILE.jsonl',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fd)
        os.fsync(self.stream);syncdir(self.fd)
    def record(self,value):
        b=compact(value);require(len(b)<=1024,'Per-file record too large')
        require(self.stream_bytes+len(b)<=STREAM_BUDGET,'Per-file budget exhausted')
        self.space(len(b));view=memoryview(b)
        while view:
            n=os.write(self.stream,view);require(n>0,'Short stream write');view=view[n:]
        os.fsync(self.stream);self.used+=len(b);self.stream_bytes+=len(b);self.space(0)
    def close(self):
        if self.failure is not None:os.close(self.failure)
        if self.stream is not None:os.close(self.stream)
        if self.fd is not None:os.close(self.fd)
        close_all(self.fds)
    def failed(self,value):
        b=compact(value);require(len(b)<=16384,'Failure exceeds preallocated slot')
        b+=b' '*(16384-len(b));pos=0
        while pos<len(b):
            n=os.pwrite(self.failure,b[pos:],pos);require(n>0,'Failure slot write refused');pos+=n
        os.fsync(self.failure);syncdir(self.fd)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ['allowlist','declaration','acceptance','output']:parser.add_argument('--'+name,required=True)
    args=parser.parse_args();receipts=Receipts(args.output)
    roots=[];chain=[];successes=0;armed=None;advice_returned=False
    try:
        require(all(hasattr(os,x) for x in ['O_PATH','O_NOATIME','posix_fadvise','POSIX_FADV_DONTNEED']),'Required Linux APIs unavailable')
        memory_guard()
        allow=read_control(args.allowlist,96*1024);require(sha(allow)==ALLOWLIST_SHA,'Allowlist hash mismatch')
        data=json.loads(gzip.decompress(allow));rows=data['objects']
        require(data['inputSHA256']==INPUT_SHA and data['rootFinishedSHA256']==FINISH_SHA,'Prior proof mismatch')
        require(len(rows)==1020 and [r['oid'] for r in rows]==sorted({r['oid'] for r in rows}),'Exact1020 unique sorted OIDs required')
        for r in rows:
            require(re.fullmatch('[0-9a-f]{40}',r['oid']) is not None,'Invalid OID')
            require(re.fullmatch('[0-9a-f]{64}',r['encodedSHA256FromPriorProof']) is not None,'Invalid prior SHA reference')
            require(len(r['metadata'])==10 and r['metadata'][-1]==1,'Pinned single-link metadata required')
        source=read_control(str(Path(__file__).absolute()),64*1024);source_sha=sha(source)
        declaration=read_control(args.declaration,16*1024);d=json.loads(declaration)
        acceptance=read_control(args.acceptance,16*1024);a=json.loads(acceptance)
        require(d['repository']==REPOSITORY and d['sourceSHA256']==source_sha and d['allowlistSHA256']==ALLOWLIST_SHA,'Declaration identity mismatch')
        require(d['scope']==SCOPE and d['finishReviewSHA256']==FINISH_REVIEW_SHA,'Declaration scope/finish review mismatch')
        for name in ['affectedReadersClosed','affectedWritersAndMaintenanceHeld','affectedInodeAliasesQuiescent','noUnknownAffectedLockOwner','runtimeProcessesClosed']:
            require(d.get(name) is True,'Explicit root closure declaration missing: '+name)
        require(a['sourceSHA256']==source_sha and a['allowlistSHA256']==ALLOWLIST_SHA and a.get('allowHintAttemptOnly') is True,'Independent implementation acceptance mismatch')
        reviewed=read_control(a['reviewPath'],64*1024);require(sha(reviewed)==a['reviewSHA256'],'Independent review hash mismatch')
        finish_review=read_control('/workspace/scratch/git-compaction-finished-independent-r1/REVIEW.md',16*1024)
        require(sha(finish_review)==FINISH_REVIEW_SHA,'Finish closure review changed')
        proof=REPOSITORY+'/reviews/root-git-loose-compaction-v0.9/probe-r1/'
        require(sha(read_control(proof+'FINISHED.json',16*1024))==FINISH_SHA,'FINISHED changed')
        require(sha(read_control(proof+'INPUTS.json.gz',256*1024))==INPUT_SHA,'INPUTS changed')
        def fresh_declaration():
            require(read_control(args.declaration,16*1024)==declaration,'Declaration changed')
            age=time.time()-d['issuedUnixSeconds'];require(-5<=age<=300,'Root closure declaration expired')
        fresh_declaration()
        receipts.write('ALLOWLIST.json.gz',allow)
        receipts.write('ROOT-DECLARATION.json',declaration);receipts.write('INDEPENDENT-ACCEPTANCE.json',acceptance)
        receipts.write('BEFORE.json',compact({'cgroup':snapshot(),'headroom':memory_guard(),'sourceSHA256':source_sha,'scope':SCOPE}))
        roots,chain=anchors(OBJECTS);base=roots[-1];expected=[r['oid'] for r in rows]
        require(membership(base)==expected,'Current membership mismatch')
        usage=live_fd_probe({(r['metadata'][0],r['metadata'][1]) for r in rows})
        observed=[]
        for r in rows:
            memory_guard();fresh_declaration();anchored_stable(chain)
            fan,fd=open_object(base,r)
            try:
                s=observe(fd,fan,r['oid'][2:],r);fan_stable(base,r,fan)
                observed.append({'oid':r['oid'],**s})
            finally:os.close(fd);os.close(fan)
        require(membership(base)==expected,'Membership changed during preflight')
        preflight=gzip.compress(compact({'scope':'Complete metadata-only preflight; no fresh object-byte SHA','objects':observed}),mtime=0)
        require(len(preflight)<=96*1024,'Preflight receipt exceeds allowance')
        receipts.write('PREFLIGHT.json.gz',preflight)
        receipts.write('PREFLIGHT-ACCEPTED.json',compact({'objects':1020,'metadataOnly':True,'preflightSHA256':sha(preflight),'allowlistSHA256':ALLOWLIST_SHA,'allHintsStillHeld':True,'liveFDProbe':usage}))
        receipts.begin_stream()
        for r in rows:
            memory_guard();fresh_declaration();anchored_stable(chain)
            fan,fd=open_object(base,r);armed=r['oid'];advice_returned=False
            try:
                before=observe(fd,fan,r['oid'][2:],r);fan_stable(base,r,fan)
                live_fd_probe({(r['metadata'][0],r['metadata'][1])},permitted_own_fd=fd)
                memory_guard();fresh_declaration();anchored_stable(chain)
                before=observe(fd,fan,r['oid'][2:],r);fan_stable(base,r,fan)
                receipts.record({'oid':armed,'phase':'armed','metadataOnlySHA256':sha(compact(before))})
                os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED);advice_returned=True
                after=observe(fd,fan,r['oid'][2:],r);fan_stable(base,r,fan);anchored_stable(chain)
                receipts.record({'oid':armed,'phase':'returned','errno':0,'metadataOnlySHA256':sha(compact(after))})
                successes+=1;armed=None;advice_returned=False
            finally:os.close(fd);os.close(fan)
        # Final metadata/membership check is not a body read or fresh byte SHA.
        require(membership(base)==expected,'Post-advice membership mismatch')
        for r in rows:
            memory_guard();fresh_declaration();anchored_stable(chain)
            fan,fd=open_object(base,r)
            try:observe(fd,fan,r['oid'][2:],r);fan_stable(base,r,fan)
            finally:os.close(fd);os.close(fan)
        close_all(roots);roots=[]
        samples=[]
        for i in range(3):
            if i:time.sleep(0.05)
            samples.append({'cgroup':snapshot(),'headroom':memory_guard()})
        receipts.write('AFTER.json',compact({'successfullyReturnedHints':successes,'samples':samples,'allOwnObjectFDsClosed':True,
            'objectBodiesRead':False,'freshObjectSHAClaim':False,'scope':'Metadata preserved; advice return is not measured object residency/reclaim or admission for another operation'}))
        print(json.dumps({'completed':True,'returnedHints':successes,'noObjectBodiesRead':True,'allOwnObjectFDsClosed':True}))
    except BaseException as e:
        close_all(roots);roots=[]
        failure={'errorType':type(e).__name__,'error':str(e)[:2000],'errno':getattr(e,'errno',None),
            'completedReturnedHints':successes,'pendingOID':armed,'pendingAdviceReturnedBeforeFailure':advice_returned,
            'scope':'Stop; earlier armed/returned hints remain recorded. No rollback/extra hints/global flush or fresh object-byte proof.'}
        try:failure['cgroup']=snapshot()
        except BaseException as secondary:failure['snapshotError']=str(secondary)[:500]
        receipts.failed(failure);raise
    finally:
        close_all(roots);receipts.close()

if __name__=='__main__':main()
