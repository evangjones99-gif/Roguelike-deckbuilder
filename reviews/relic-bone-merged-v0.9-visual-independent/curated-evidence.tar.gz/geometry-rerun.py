from pathlib import Path
from PIL import Image
import gzip,json,hashlib,math
P=Path.cwd(); art=Path('/tmp/hollowpact-relic-bone-v09-root-r1/public/art')

def hull(points):
 p=sorted(set(points))
 def cross(o,a,b):return(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
 lo=[];hi=[]
 for x in p:
  while len(lo)>=2 and cross(lo[-2],lo[-1],x)<=0:lo.pop()
  lo.append(x)
 for x in reversed(p):
  while len(hi)>=2 and cross(hi[-2],hi[-1],x)<=0:hi.pop()
  hi.append(x)
 return lo[:-1]+hi[:-1]
cache={};assets={};out=[]
for f in sorted(P.glob('*case-*.json.gz')):
 r=json.load(gzip.open(f));seen=set()
 for step in r['steps']:
  for d in step.get('draws',[])+[e['draw']for e in step.get('early',[])]:
   key=json.dumps(d,sort_keys=True)
   if key in seen:continue
   seen.add(key)
   name=d['url'].rsplit('/',1)[-1];sx,sy,sw,sh,dx,dy,dw,dh=d['args'];k=(name,sx,sy,sw,sh)
   if k not in cache:
    im=Image.open(art/name).convert('RGBA');a=im.getchannel('A').crop((sx,sy,sx+sw,sy+sh));points=[];pix=a.load()
    for y in range(int(sh)):
     xs=[x for x in range(int(sw))if pix[x,y]>=8]
     if xs:points += [(min(xs)+sx,y+sy),(max(xs)+sx+1,y+sy+1)]
    cache[k]=hull(points)
    if name not in assets:assets[name]={'sha256':hashlib.sha256((art/name).read_bytes()).hexdigest(),'size':im.size,'alpha1':im.getchannel('A').point(lambda x:255 if x>=1 else 0).getbbox(),'alpha8':im.getchannel('A').point(lambda x:255 if x>=8 else 0).getbbox()}
   a,b,c,e,tx,ty=d['matrix'];pts=[]
   for x,y in cache[k]:
    xx=dx+(x-sx)*dw/sw;yy=dy+(y-sy)*dh/sh;pts.append((a*xx+c*yy+tx,b*xx+e*yy+ty))
   xs,ys=zip(*pts);bbox=[min(xs),min(ys),max(xs),max(ys)];w,h=d['canvas'];loss=[max(0,-bbox[0]),max(0,-bbox[1]),max(0,bbox[2]-w),max(0,bbox[3]-h)]
   out.append({'case':f.name,'variant':r['v'],'mode':r['mode'],'width':r['width'],'asset':name,'sourceRect':[sx,sy,sw,sh],'at':d['at'],'canvas':d['canvas'],'alpha':d['alpha'],'bbox':bbox,'overflow':loss})
summary={'method':'Read-only alpha8 pixel-edge convex hull, actual same-draw affine matrix and canvas W/H; distinct timestamps per context, all retained completed records. Not threshold1 fringe or later canvas dimensions. Hull endpoint convention up to1sourcepixel conservative. No alpha-alpha collisions or frame-rate proof.','assets':assets,'draws':len(out),'boneDraws':sum(x['asset'].startswith('bone')for x in out),'overflowCount':sum(max(x['overflow'])>.01 for x in out),'maximumOverflow':max([max(x['overflow'])for x in out],default=0),'byGroup':{},'rows':out}
for x in out:
 k=f"{x['variant']}/{x['mode']}/{x['width']}/{x['asset']}";g=summary['byGroup'].setdefault(k,{'draws':0,'overflowCount':0,'maxOverflow':0,'canvases':[]});g['draws']+=1;g['overflowCount']+=max(x['overflow'])>.01;g['maxOverflow']=max(g['maxOverflow'],max(x['overflow']));
 if x['canvas']not in g['canvases']:g['canvases'].append(x['canvas'])
(P/'GEOMETRY-rerun.json.gz').write_bytes(gzip.compress((json.dumps(summary,indent=2)+'\n').encode(),compresslevel=9,mtime=0));print(json.dumps({k:v for k,v in summary.items()if k not in['rows','byGroup']}))
