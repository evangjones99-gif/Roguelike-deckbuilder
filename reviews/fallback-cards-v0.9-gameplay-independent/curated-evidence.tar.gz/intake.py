import pathlib,json,hashlib,urllib.request
O=pathlib.Path('/workspace/scratch/fallback-cards-gameplay-independent-v09-r1')
configs=[('baseline',pathlib.Path('/tmp/hollowpact-relic-bone-v09-root-r1'),4605,'4bfa417ad790dd88a18868e10e7574666ae8bfc3187bdab1df4947c31231de61'),('candidate',pathlib.Path('/tmp/hollowpact-fallback-cards-v09-root-r1'),4630,'201d90d522c4f170cfc54d22910e718603ff2a88393ac3151ecd4ea6faf6df18')]
rows=[]
for name,root,port,expected in configs:
 p=json.loads((root/'dist/build-provenance.json').read_bytes()); assert p['sourceDigest']==expected
 hashes={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in p['hashes']}; assert hashes==p['hashes']
 assert hashlib.sha256(json.dumps(hashes,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==expected
 outputs=[]
 for f in sorted((root/'dist').rglob('*')):
  if not f.is_file(): continue
  raw=f.read_bytes(); relative=f.relative_to(root/'dist').as_posix(); body=urllib.request.urlopen(f'http://127.0.0.1:{port}/{relative}',timeout=10).read(); assert raw==body
  outputs.append(dict(path=relative,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 assert len(outputs)==56
 rows.append(dict(name=name,root=str(root),port=port,provenance=p,inputs=hashes,outputs=outputs))
changed=[f for f,h in rows[0]['inputs'].items() if rows[1]['inputs'].get(f)!=h]
assert changed==['src/arena.ts', 'src/style.css'],changed
assert set(rows[1]['inputs'])-set(rows[0]['inputs'])==set()
phase=__import__('sys').argv[1]; (O/(phase+'.json')).write_text(json.dumps(dict(rows=rows,changed=changed,added=[]),indent=2)+'\n'); print(phase,'156 source files and 112 actual HTTP build bodies checked')
