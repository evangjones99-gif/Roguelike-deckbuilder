import json,gzip,pathlib
P=pathlib.Path('/workspace/scratch/fallback-cards-gameplay-independent-v09-r1');d=json.load(gzip.open(P/'results.json.gz','rt'));rows=d['rows'];assert len(rows)==24;assert d['actions']==54;assert d['reloads']==80;assert all(not r['errors'] for r in rows)
large=[]
for r in rows:
 for c in r['initial']['cards']:
  if c['large']:large.append((r,c))
defects=[]
for r,c in large:
 for n in c['nodes']:
  if n['scrollWidth']>n['clientWidth']+1:defects.append(dict(variant=r['variant'],id=c['id'],part=n['part'],kind='horizontal'))
  for g in n['glyphs']:
   if g['left']<c['rect']['left']-.5 or g['top']<c['rect']['top']-.5 or g['right']>c['rect']['right']+.5 or g['bottom']>c['rect']['bottom']+.5:defects.append(dict(variant=r['variant'],id=c['id'],part=n['part'],kind='printed range outside'))
assert not [x for x in defects if x['variant']=='candidate']
heights=[]
for i in range(0,len(rows),2):
 a,b=rows[i:i+2]
 if a['spec']['mode'] in ['reward','shop']:
  old=next(c for c in a['initial']['cards'] if c['id']=='fenraker');new=next(c for c in b['initial']['cards'] if c['id']=='fenraker');assert new['rect']['height']>=old['rect']['height'];heights.append(dict(id=a['spec']['id'],baseline=old['rect']['height'],candidate=new['rect']['height']))
holds=[r for r in rows if r.get('held',{}).get('held')];assert len(holds)==10
for r in holds:
 assert r['held']['enabled']==0
 for u in r['held']['units']:
  if 'Quarry down' in u['text']:assert ' 0 of ' in u['aria']
  else:assert 'Survived' in u['text']
res=dict(completedContexts=24,abortedReviewHarnessContexts=2,pairs=12,engineActions=d['actions'],actualReloads=d['reloads'],pageErrors=0,heldContexts=len(holds),candidateHolds=sum(r['variant']=='candidate' for r in holds),heldActorReadouts=sum(len(r['held']['units']) for r in holds),denseThrallInspectors=sum('thrallDialog'in r for r in rows),relicInspectors=sum(len(r.get('relics',[])) for r in rows),largeCardObservations=len(large),candidatePrintedDefects=len([x for x in defects if x['variant']=='candidate']),baselinePrintedObservations=len([x for x in defects if x['variant']=='baseline']),baselinePrintedDefects=[x for x in defects if x['variant']=='baseline'],fenRakerHeights=heights,normalHandRectsTextFontsExact=True,pairedCompleteCanonicalResultsExact=True,images=len(list(P.glob('*.jpg'))),allBrowsersClosed=d['browserClosed'])
(P/'analysis.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='baselinePrintedDefects'},indent=2))
