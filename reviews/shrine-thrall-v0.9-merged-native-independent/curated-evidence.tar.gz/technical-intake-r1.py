from pathlib import Path
import json,hashlib,os
O=Path('/workspace/scratch/bone-thrall-variable-pose-native-independent-v09-r1');P=Path('/workspace/scratch/bone-thrall-variable-pose-technical-independent-v09-r1');raw=(P/'FROZEN-FILES.json').read_bytes();H=lambda b:hashlib.sha256(b).hexdigest();assert H(raw)=='80e39aaaa364c0301d5c5f64616b8b1ffc149f7d79ed83f7831fec85f27d4191';m=json.loads(raw);rows=m['files'];assert len(rows)==72
for r in rows:
 f=P/r['path'];b=f.read_bytes()
 if r['type']=='file':assert not f.is_symlink();assert len(b)==r['bytes'];assert H(b)==r['sha256']
 else:
  assert r['type']=='symlink'and f.is_symlink();assert os.readlink(f)==r['target'];assert len(b)==r['referencedBytes'];assert H(b)==r['referencedSHA256']
assert H((P/'REVIEW.md').read_bytes())=='c83a25530221f307441a46561c74c7db132dc28ea6fe899603a3f817ea7155f3'
result={'scope':'Read-only exact frozen technical gate intake. Sixty-eight regular members and four exact original-path symlink references with original target bytes verified; externalTMP failed capture retention is disclosed rather than embedded backup. Counts/reducer/native approval not borrowed.','path':str(P),'manifestSHA256':H(raw),'reviewSHA256':H((P/'REVIEW.md').read_bytes()),'members':72,'regular':68,'temporaryCaptureReferences':4,'pass':True}
with (O/'TECHNICAL-INTAKE-BEFORE.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
with (O/'TECHNICAL-FROZEN-INPUT.json').open('xb')as f:f.write(raw)
print(json.dumps(result))
