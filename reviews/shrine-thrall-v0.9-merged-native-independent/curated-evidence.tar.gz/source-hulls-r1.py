from pathlib import Path
from PIL import Image
import json,hashlib
O=Path('/workspace/scratch/bone-thrall-variable-pose-native-independent-v09-r1');P=Path('/tmp/hollowpact-bone-thrall-variable-pose-v09-author-r1/public/art/bone-thrall-poses-v09-r2.png');img=Image.open(P);assert img.mode=='RGBA' and img.size==(1536,1024);assert hashlib.sha256(P.read_bytes()).hexdigest()=='440bdad1f593538aeb1a5e2a44e5f611bbd8339f36146b11a069a72c4c2f93b2'
frames=[('idle',[55,56,506,508],[255,495]),('anticipation',[552,101,951,504],[772,490]),('attack',[1001,105,1524,504],[1235,494]),('recovery',[43,541,522,971],[255,955]),('reaction',[568,533,992,968],[782,954]),('death',[996,745,1534,967],[1260,950])]
def convex(points):
 p=sorted(set(map(tuple,points)))
 def cross(o,a,b):return(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
 lo=[]
 for xy in p:
  while len(lo)>1 and cross(lo[-2],lo[-1],xy)<=0:lo.pop()
  lo.append(xy)
 hi=[]
 for xy in reversed(p):
  while len(hi)>1 and cross(hi[-2],hi[-1],xy)<=0:hi.pop()
  hi.append(xy)
 return lo[:-1]+hi[:-1]
rows=[]
for pose,rect,feet in frames:
 l,t,r,b=rect;points=[];count=0
 for y in range(t,b):
  xs=[x for x in range(l,r)if img.getpixel((x,y))[3]>=8];count+=len(xs)
  if xs:points.extend([(xs[0],y),(xs[-1],y),(xs[0],y+1),(xs[-1]+1,y+1)])
 hull=convex(points);assert hull
 rows.append({'pose':pose,'rect':rect,'plantarPlane':feet,'scale':(b-t)/480,'sourceAxisDensityPerFigureSize':1/480,'hullAlpha8':hull,'significantPixelCount':count,'boundsAlpha8':[min(x for x,y in hull),min(y for x,y in hull),max(x for x,y in hull),max(y for x,y in hull)]})
result={'scope':'Independent read-only direct raw RGBA source alpha>=8 pixel-edge convex hulls for exact six authored variable windows; original raster unchanged. Pixel boundaries include +1 extents; no clinical anatomy, every omitted-alpha fragment or runtime claim. Metadata/actual runtime correspondence remains to be tested.','rawSourceSHA256':hashlib.sha256(P.read_bytes()).hexdigest(),'rawBytes':P.stat().st_size,'dimensions':img.size,'decodedRGBACapacityBytes':1536*1024*4,'rows':rows,'clawSource':[1513,209],'clawRGBA':img.getpixel((1513,209)),'deathToIdleHeightRatio':222/452}
with (O/'OWN-SOURCE-HULLS.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'poses':len(rows),'sourceSHA256':result['rawSourceSHA256'],'clawRGBA':result['clawRGBA'],'decodedRGBACapacityBytes':result['decodedRGBACapacityBytes'],'pass':True}))
