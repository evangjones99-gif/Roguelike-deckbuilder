from pathlib import Path
import hashlib,json,os
O=Path('/workspace/scratch/bone-thrall-variable-pose-native-independent-v09-r1');S=Path('/tmp/hollowpact-bone-thrall-variable-pose-v09-author-r1');B=Path('/tmp/hollowpact-fallback-cards-v09-root-r1')
def H(b):return hashlib.sha256(b).hexdigest()
def audit(stage,n):
 p=json.loads((stage/'dist/build-provenance.json').read_bytes());h={k:H((stage/k).read_bytes()) for k in p['hashes']};assert h==p['hashes'];assert len(h)==n
 assert H(json.dumps(h,separators=(',',':'),ensure_ascii=False).encode())==p['sourceDigest']
 sources={k:{'sha256':v,'bytes':(stage/k).stat().st_size,'regular':(stage/k).is_file() and not(stage/k).is_symlink(),'alias':{'literal':os.readlink(stage/k),'resolved':str((stage/k).resolve())}if(stage/k).is_symlink()else None}for k,v in h.items()}
 dist={str(f.relative_to(stage/'dist')):{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size,'regular':f.is_file() and not f.is_symlink()}for f in sorted((stage/'dist').rglob('*'))if f.is_file()};assert len(dist)==n-22
 return {'stage':str(stage),'provenance':p,'sources':sources,'dist':dist}
c=audit(S,79);b=audit(B,78);assert c['provenance']['sourceDigest']=='bf950632b1fef8d9d0ec955aaaea4c431e022a5262dd09f8dff5c95d38804ee8';changes=[k for k,v in c['provenance']['hashes'].items()if b['provenance']['hashes'].get(k)!=v];assert changes==['THIRD-PARTY.md','public/art/PROVENANCE.json','public/art/bone-thrall-poses-v09-r2.png','src/art.ts']
packets=[]
for label,stage,file,expected in [('author',Path('/workspace/scratch/bone-thrall-variable-pose-author-v09-r1'),'MANIFEST.json','f92866d2326c4bae07830376323222a645ff7d414685e305f6e3e2929d793a14'),('independent visual',Path('/workspace/scratch/bone-thrall-variable-pose-visual-independent-v09-r1'),'FROZEN.json',None)]:
 raw=(stage/file).read_bytes();m=json.loads(raw);rows=m['files'];rows=rows if isinstance(rows,list) else [{'path':p,**r}for p,r in rows.items()]
 if expected:assert H(raw)==expected
 for r in rows:
  f=stage/r['path'];v=f.read_bytes();assert f.is_file() and not f.is_symlink();assert len(v)==r['bytes'];assert H(v)==r['sha256']
 packets.append({'label':label,'path':str(stage),'manifest':file,'manifestSHA256':H(raw),'members':len(rows),'reportSHA256':H((stage/('PROPOSAL.md'if label=='author'else'REVIEW.md')).read_bytes())})
old=json.loads(Path('/workspace/scratch/mobile-roster-visual-native-independent-v09-r1/IDENTITY-BEFORE.json').read_bytes());P=Path(old['package']);stock={}
for name,r in old['packagedFiles'].items():
 f=P/name;s=f.lstat();assert f.is_file()and not f.is_symlink();assert H(f.read_bytes())==r['sha256'];checks={'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'mode':s.st_mode&4095,'uid':s.st_uid,'gid':s.st_gid,'bytes':s.st_size,'mtimeMs':s.st_mtime_ns/1e6,'ctimeMs':s.st_ctime_ns/1e6}
 for k,v in checks.items():assert abs(v-r[k])<0.001 if k.endswith('Ms')else v==r[k],(name,k,v,r[k])
 stock[name]={'sha256':r['sha256'],**checks}
result={'scope':'Read-only static pre-intake while launches and package assembly are held. Candidate79/baseline78 source and57/56 outputs locally hashed; author and independent visual packets verified; all74 CLOSED latestmobile93e2 stock file bytes/metadata verified. New technical freeze and coordinated native window still pending. No runtime/package/HTTP acceptance borrowed.','candidate':c,'baseline':b,'changes':changes,'priorPackets':packets,'stockBaseline':str(P),'stock':stock,'freeTMP':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'freeWorkspace':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'pass':True}
with (O/'STATIC-INTAKE-BEFORE.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'candidate':c['provenance']['sourceDigest'],'changes':changes,'sources':[79,78],'outputs':[57,56],'priorPackets':packets,'stock74Exact':True,'freeTMP':result['freeTMP'],'pass':True}))
