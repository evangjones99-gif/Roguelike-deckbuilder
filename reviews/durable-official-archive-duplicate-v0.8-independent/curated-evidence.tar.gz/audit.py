from pathlib import Path
import hashlib,json,os,stat,time,datetime
O=Path('/workspace/scratch/durable-official-archive-duplicate-independent-v08-r1')
R=Path('/workspace/Roguelike-deckbuilder')
SRC=Path('/workspace/retained-native-experiments/windows-run-36806506465/hollowpact-0.8.0-windows-native-x64.zip')
DST=R/'releases/0.8.0/hollowpact-0.8.0-windows-native-x64.zip'
EXPECTED='1ce6c74baea02686183e833c28738e04d19f80d5826218a0d732eff304dce563'
def meta(p):
 s=p.lstat()
 return {'type':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'link' if stat.S_ISLNK(s.st_mode) else 'other','bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'blocks':s.st_blocks,'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'xattrs':{k:os.getxattr(p,k,follow_symlinks=False).hex() for k in os.listxattr(p,follow_symlinks=False)}}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def row(p,hashed=False):
 r={'path':str(p),'beforeReadMetadata':meta(p)}
 if hashed:r['sha256']=sha(p)
 r['metadata']=meta(p)
 if p.is_dir():r['members']=sorted(str(q) for q in p.iterdir())
 return r
before={k:row(p,True if k in ('duplicateOriginal','officialRetained') else False) for k,p in [('duplicateOriginal',SRC),('officialRetained',DST),('duplicateParent',SRC.parent),('officialParent',DST.parent)]}
for k in ('duplicateOriginal','officialRetained'):
 r=before[k];assert r['sha256']==EXPECTED and r['metadata']['bytes']==191814688 and r['metadata']['type']=='file' and r['metadata']['nlink']==1
for k in ('mode','uid','gid','xattrs'):
 assert before['duplicateOriginal']['metadata'][k]==before['officialRetained']['metadata'][k],k
assert before['duplicateOriginal']['metadata']['device']==before['officialRetained']['metadata']['device']
assert before['duplicateOriginal']['metadata']['inode']!=before['officialRetained']['metadata']['inode']
manifest=R/'releases/0.8.0/manifest.json'
assert json.loads(manifest.read_text())['artifacts'][DST.name]==EXPECTED
recovery=SRC.parent/'RECOVERY.json';recovered=json.loads(recovery.read_text())
assert recovered['archive']==str(SRC) and recovered['sha256']==EXPECTED and recovered['bytes']==191814688
original=SRC.parent/'manifest.original.json';origin=json.loads(original.read_text())
assert origin['archive']==SRC.name and origin['bytes']==191814688 and origin['sha256']==EXPECTED and origin['runId']=='36806506465' and origin['attempt']=='1'
sidecars=[row(p,True) for p in sorted(SRC.parent.iterdir()) if p!=SRC]
wrappers=[]
for declared in recovered['wrappers']:
 p=Path(declared['path']);r=row(p,True);assert r['metadata']['bytes']==declared['bytes'] and r['sha256']==declared['sha256'];wrappers.append(r)
assert len(wrappers)==8
# Bound the exclusion inventory honestly to actual archive inputs and their parent
# metadata. This is not a filesystem-wide backup or hash audit of every dataset.
excluded={}
for base in [Path('/workspace/retained-native-experiments'),Path('/workspace/attachments')]:
 for p in sorted(base.rglob('*')):
  if p==SRC:continue
  s=p.lstat()
  if stat.S_ISREG(s.st_mode) or stat.S_ISLNK(s.st_mode):excluded[str(p)]={'path':str(p),'metadata':meta(p)}
for base in [R/'releases',Path('/tmp/hollowpact-v07-bundle-preflight-y4st1n0p')]:
 for p in sorted(base.rglob('*')):
  if p==DST:continue
  if p.is_file() and (p.name.endswith(('.zip','.tar.gz','.bundle')) or p.name in ('manifest.json','SHA256SUMS','VERIFICATION.json','source-bundle-verification.json','INDEX.json')):
   excluded[str(p)]={'path':str(p),'metadata':meta(p)}
for p in Path('/tmp').glob('hollowpact*'):
 if p.is_file() and p.name.endswith(('.zip','.tar.gz','.bundle')):excluded[str(p)]={'path':str(p),'metadata':meta(p)}
identities={(before[k]['metadata']['device'],before[k]['metadata']['inode']):k for k in ('duplicateOriginal','officialRetained')}
fd={'scope':'Point-in-time visible /proc descriptors/maps only. Permission denial and process races are retained; not an exclusive lock or global absence proof.','processesSeen':0,'fdDirectoriesRead':0,'fdDirectoriesDenied':0,'fdsRead':0,'fdsDenied':0,'fdsGone':0,'mapsRead':0,'mapsDenied':0,'mapsGone':0,'matchingDescriptors':[],'matchingMappings':[],'deniedProcessSamples':[]}
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 fd['processesSeen']+=1
 try:fds=list((proc/'fd').iterdir());fd['fdDirectoriesRead']+=1
 except PermissionError:
  fd['fdDirectoriesDenied']+=1
  if len(fd['deniedProcessSamples'])<128:fd['deniedProcessSamples'].append(proc.name)
  fds=[]
 except FileNotFoundError:fd['fdsGone']+=1;fds=[]
 for f in fds:
  try:
   s=f.stat();fd['fdsRead']+=1
   if (s.st_dev,s.st_ino) in identities:fd['matchingDescriptors'].append({'pid':proc.name,'fd':f.name,'identity':identities[(s.st_dev,s.st_ino)]})
  except PermissionError:fd['fdsDenied']+=1
  except FileNotFoundError:fd['fdsGone']+=1
 try:
  maps=(proc/'maps').read_text();fd['mapsRead']+=1
  for line in maps.splitlines():
   if str(SRC) in line or str(DST) in line:fd['matchingMappings'].append({'pid':proc.name,'mapping':line})
 except PermissionError:fd['mapsDenied']+=1
 except FileNotFoundError:fd['mapsGone']+=1
assert not fd['matchingDescriptors'] and not fd['matchingMappings'],'Observed active archive reader; hold proposal'
for k,p in [('duplicateOriginal',SRC),('officialRetained',DST)]:
 assert sha(p)==EXPECTED
 for field,value in before[k]['metadata'].items():
  if field!='atime_ns':assert meta(p)[field]==value,(k,field)
for k,p in [('duplicateParent',SRC.parent),('officialParent',DST.parent)]:
 assert sorted(str(q) for q in p.iterdir())==before[k]['members']
 for field,value in before[k]['metadata'].items():
  if field not in ('atime_ns',):assert meta(p)[field]==value,(k,field)
free=os.statvfs('/workspace');freebytes=free.f_bavail*free.f_frsize
eligibility={'status':'CONDITIONAL-ONLY-no-mutation','frozenUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'One exactly official-covered redundant current0.8 original path only. New independently measured gate; prior0.7 gate not borrowed.','expectedBytes':191814688,'expectedSHA256':EXPECTED,'before':before,'sidecars':sidecars,'wrappers':wrappers,'excludedInputs':list(excluded.values()),'fdInspection':fd,'allocatedDuplicateBytes':before['duplicateOriginal']['metadata']['blocks']*512,'workspaceFreeObservedBytes':freebytes,'allowedFutureOperation':{'original':str(SRC),'absoluteTarget':str(DST),'method':'Root may atomically replace only the redundant original regular path with an absolute symlink after fresh full SHA/metadata/reader coordination and durable preflight/journal. Official target must remain byte/inode/mode/owner/xattr/mtime/ctime/nlink/blocks unchanged; reader atime is qualified. Original parent membership/mode/owner/inode/xattrs and atime/mtime must be retained; ctime necessarily changes and must be disclosed.','forbidden':'No official file replacement/chmod, no wrapper/sidecar/source/review/art/dataset deletion, no outside unique-input replacement.','qualification':'Original path/full bytes/followed access metadata retained; old inode/type/ctime/blocks lost only from redundant path and preserved in permanent sidecar. Immutable by usage contract, not an OS lock.','nextGate':'Distinct actual before/after review required; current free bytes and block forecast do not guarantee future package/archive capacity.'}}
(O/'ELIGIBILITY.json').write_text(json.dumps(eligibility,indent=2)+'\n')
print(json.dumps({'bothFullSHA':EXPECTED,'bytes':191814688,'allocatedDuplicateBytes':eligibility['allocatedDuplicateBytes'],'mode':before['duplicateOriginal']['metadata']['mode'],'uid':before['duplicateOriginal']['metadata']['uid'],'gid':before['duplicateOriginal']['metadata']['gid'],'excludedInputs':len(excluded),'wrappers':len(wrappers),'fdInspection':fd,'workspaceFreeObservedBytes':freebytes}))
