from pathlib import Path
import subprocess,json,os,stat,hashlib
O=Path('/workspace/scratch/durable-official-archive-duplicate-independent-v08-r1')
def meta(p):
 s=p.lstat()
 return {'type':'file' if stat.S_ISREG(s.st_mode) else 'link' if stat.S_ISLNK(s.st_mode) else 'other','bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'blocks':s.st_blocks,'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'xattrs':{k:os.getxattr(p,k,follow_symlinks=False).hex() for k in os.listxattr(p,follow_symlinks=False)}}
r=subprocess.run(['rg','--files','--hidden','--no-ignore','/tmp'],capture_output=True,text=True);assert r.returncode==0,r.stderr
rows=[];gone=[]
for name in r.stdout.splitlines():
 if not name.endswith(('.zip','.tar.gz','.bundle')):continue
 p=Path(name)
 try:rows.append({'path':name,'metadata':meta(p),'eligibleForThisTransaction':False})
 except FileNotFoundError:gone.append(name)
existing=json.loads((O/'ELIGIBILITY.json').read_text())
for row in existing['excludedInputs']:
 actual=meta(Path(row['path']))
 for key,value in row['metadata'].items():
  if key!='atime_ns':assert actual[key]==value,(row['path'],key)
for row in rows:
 actual=meta(Path(row['path']))
 for key,value in row['metadata'].items():
  if key!='atime_ns':assert actual[key]==value,(row['path'],key)
out={'scope':'Own fresh TMP suffix archive inventory, all excluded. This records stable metadata, not full hashes of unique TMP originals or every artwork/dataset. Prior0.7 scan is not borrowed as proof.','scanCommand':['rg','--files','--hidden','--no-ignore','/tmp'],'scanExitCode':r.returncode,'scanStderr':r.stderr,'regularPathsEnumerated':len(r.stdout.splitlines()),'concurrentlyGone':gone,'files':rows,'durableExcludedInputsRereadStable':len(existing['excludedInputs'])}
(O/'EXCLUDED-TMP-INPUTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'pathsEnumerated':out['regularPathsEnumerated'],'TMPArchiveInputs':len(rows),'concurrentlyGone':len(gone),'durableExcludedInputsStable':len(existing['excludedInputs'])}))
