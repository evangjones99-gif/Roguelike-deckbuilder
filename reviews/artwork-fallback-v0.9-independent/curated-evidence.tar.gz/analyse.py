import json,gzip,pathlib,re,hashlib,math
P=pathlib.Path('/workspace/scratch/artwork-fallback-independent-v09-r1');ds=[json.loads(gzip.decompress((P/x).read_bytes())) for x in ['results-r2.json.gz','results-min360.json.gz']];rows=[r for d in ds for r in d['rows']]
assert len(rows)==40
holds=[r for r in rows if r['terminal']['held']];assert len(holds)==28
for r in holds:
 t=r['terminal']; dead=[u for u in t['units'] if 'Quarry down' in u['text']];assert len(dead)==1;assert ' 0 of ' in dead[0]['aria']; assert t['enabled']==0
 for u in t['units']:
  if u not in dead: assert 'Survived' in u['text']
for r in rows:
 if r['mode']=='normal':assert r['initial']['status']['text']==''
 if r['v']=='candidate' and r['mode'] not in ['canvas','normal','late']:
  t=r['initial'];assert t['status']['rect']['bottom']<=t['wrap']['bottom']+.1;assert t['status']['rect']['top']>=t['canvas']['bottom']-.1
  assert abs((t['wrap']['height']-t['canvas']['height'])-29.796875)<.1
  assert t['status']['styles']['fontSize']=='12px'
 if r['mode']!='canvas':assert r['recovered']['status']['text']==''
 assert r['reward']['wrapStyles']['opacity']=='0'
def lum(rgb):
 vals=[int(x)/255 for x in re.findall(r'\d+',rgb)];return sum(w*(x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4) for w,x in zip([.2126,.7152,.0722],vals))
style=next(r['initial']['status']['styles'] for r in rows if r['v']=='candidate' and r['mode']=='pose');a,b=lum(style['color']),lum(style['backgroundColor']);ratio=(max(a,b)+.05)/(min(a,b)+.05)
result=dict(contexts=len(rows),pairs=len(rows)//2,actions=sum(d['actions'] for d in ds),actualReloads=sum(d['reloads'] for d in ds),heldContexts=len(holds),candidateHeldContexts=sum(r['v']=='candidate' for r in holds),checkedHeldActorReadouts=sum(len(r['terminal']['units']) for r in holds),pageErrors=sum(len(r['errors']) for r in rows),faultNoticeContrastFromComputedOpaqueColors=ratio,contrastStyle=style,actorReadoutStates={'Survived':sum('Survived' in u['text'] for r in holds for u in r['terminal']['units']),'Quarry down':sum('Quarry down' in u['text'] for r in holds for u in r['terminal']['units'])},faultCanvasHeights=sorted(set(r['initial']['canvas']['height'] for r in rows if r['v']=='candidate' and r['mode'] not in ['normal','late','canvas'])),normalCanvasHeights=sorted(set(r['initial']['canvas']['height'] for r in rows if r['v']=='candidate' and r['mode']=='normal')),noticeHeights=sorted(set(r['initial']['status']['rect']['height'] for r in rows if r['v']=='candidate' and r['mode'] not in ['normal','late','canvas'])),images=len(list(P.glob('*.jpg'))),allBrowsersClosed=all(d['browserClosed'] for d in ds),houndSpecies=rows[0]['expected']['events'],unearnedDiagnosticFixtures=True)
(P/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='houndSpecies'},indent=2))
