import pathlib,json,hashlib,urllib.request
O=pathlib.Path('/workspace/scratch/artwork-fallback-independent-v09-r1')
configs=[('baseline',pathlib.Path('/tmp/hollowpact-final-kill-v09-root-r1'),4610,'8a33f950ed57093a222baf9b7883a5c1ccf2deb2e8412429ef0fe05d370467cb'),('candidate',pathlib.Path('/tmp/hollowpact-artwork-fallback-v09-author-r1'),4624,'bddfb0eca2aea0be37f554036cfcd32beeaf0ef8e187b4b8541ec9843563c73c')]
rows=[]
for name,root,port,expected in configs:
 p=json.loads((root/'dist/build-provenance.json').read_bytes()); assert p['sourceDigest']==expected
 hashes={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in p['hashes']}; assert hashes==p['hashes']
 assert hashlib.sha256(json.dumps(hashes,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==expected
 outputs=[]
 for f in sorted((root/'dist').rglob('*')):
  if not f.is_file(): continue
  raw=f.read_bytes(); relative=f.relative_to(root/'dist').as_posix(); body=urllib.request.urlopen(f'http://127.0.0.1:{port}/{relative}',timeout=10).read(); assert raw==body
  outputs.append(dict(path=relative,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 assert len(outputs)==55
 rows.append(dict(name=name,root=str(root),port=port,provenance=p,inputs=hashes,outputs=outputs))
changed=[f for f,h in rows[0]['inputs'].items() if rows[1]['inputs'].get(f)!=h]
assert changed==['src/arena.ts', 'src/style.css'],changed
assert set(rows[1]['inputs'])-set(rows[0]['inputs'])==set()
phase=__import__('sys').argv[1]; (O/(phase+'.json')).write_text(json.dumps(dict(rows=rows,changed=changed,added=[]),indent=2)+'\n'); print(phase,'154 source files and 110 actual HTTP build bodies checked')

a=pathlib.Path("/workspace/scratch/artwork-fallback-author-v09-r1"); manifest=json.loads((a/"FROZEN-FILES.json").read_text()); checked=[]
for f in manifest["files"]:
 raw=(a/f["path"]).read_bytes(); assert len(raw)==f["bytes"] and hashlib.sha256(raw).hexdigest()==f["sha256"]; checked.append(f)
print("author frozen files verified",len(checked))
