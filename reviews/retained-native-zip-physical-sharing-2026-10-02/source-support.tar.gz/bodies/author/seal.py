import os,json,hashlib,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576));M=Path(__file__).parent
def body(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read(262145)
guards={}
for n in ('PAIR-GUARD','PROPOSAL-GUARD','ACTION-SOURCE-GUARD','PUBLICATION-SOURCE-GUARD','SOURCE-CHECK-GUARD'):
 j=json.loads(body(M/n/'RESULT.json'));assert j['exit_code']==0 and j['failure'] is None and j['memory_events_before']==j['memory_events_after'];guards[n]={'normal':True,'samples':len(j['samples']),'eventsUnchanged':True,'initial':j['initial'],'final':j['final'],'scope':j['scope']}
files={}
for root,ds,ns in os.walk(M):
 for n in ns:
  p=Path(root)/n
  if 'SEAL-GUARD' in p.parts:continue
  v=body(p);assert len(v)<262144;files[str(p.relative_to(M))]={'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576
v=(json.dumps({'sourceOnlyNoSharingOrGit':True,'files':files,'closedGuards':guards,'ownMaxRSSBytes':rss,'hashPhaseWork512MiBQualified':True,'sourceWork64MiBOwnRSS24':True,'noFurtherLargeZIPReads':True,'packetCapBytes':160*1024,'sourceMethodsSyntaxOnly':True,'sealScope':'Outer SEAL-GUARD supplies final rows/events/closure, excluded here.'},indent=2)+'\n').encode()
assert sum(os.stat(root+'/'+n).st_size for root,ds,ns in os.walk(M) for n in ns)+len(v)+6000<=160*1024
with (M/'FINAL-SEAL.json').open('xb') as f:f.write(v)
print(json.dumps({'finalSealSHA256':hashlib.sha256(v).hexdigest(),'RSS':rss,'pins':{n:files[n]['sha256'] for n in ['PROPOSAL.json','AGENTS.planned.md','share-retained-native-zip-root-r1.py','publish-retained-native-zip-sharing-root-r1.py','judge-retained-native-zip-sharing-root-r1.py']}}))
