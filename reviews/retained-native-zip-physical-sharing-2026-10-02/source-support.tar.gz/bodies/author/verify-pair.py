import os,json,hashlib,stat,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576));M=Path(__file__).parent
R=Path('/workspace/Roguelike-deckbuilder');A=R/'releases/0.6.1/hollowpact-0.6.1-windows-native-x64.zip';C=Path('/workspace/scratch/native-windows-v061/run-36791619534-1/hollowpact-0.6.1-windows-native-x64.zip')
def md(s):return {'st_'+k:getattr(s,'st_'+k) for k in ('dev','ino','nlink','mode','uid','gid','size','blocks','atime_ns','mtime_ns','ctime_ns')}
parents={}
def op(p):
 fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW);cur=Path('/')
 try:
  for n in p.parent.parts[1:]:
   q=os.open(n,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=q;cur/=n
   parents[str(cur)]={'fstat':md(os.fstat(fd)),'xattrs':{n:os.getxattr('/proc/self/fd/'+str(fd),n).hex() for n in os.listxattr('/proc/self/fd/'+str(fd))}}
  return os.open(p.name,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW,dir_fd=fd)
 finally:os.close(fd)
def inspect(p,retain=False):
 before=md(os.lstat(p));fd=op(p)
 try:
  assert before==md(os.fstat(fd)) and stat.S_ISREG(before['st_mode']);attrs={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)};h=hashlib.sha256();size=0;parts=[]
  while True:
   b=os.read(fd,65536)
   if not b:break
   h.update(b);size+=len(b)
   if retain:parts.append(b)
  assert before==md(os.fstat(fd))==md(os.lstat(p));assert attrs=={n:os.getxattr(fd,n).hex() for n in os.listxattr(fd)}
 finally:os.close(fd)
 out={'path':str(p),'sha256':h.hexdigest(),'bytes':size,'lstat':before,'fstat':before,'after':before,'xattrs':attrs,'metadataStable':True,'O_NOATIME':True}
 return (out,b''.join(parts)) if retain else out
a=inspect(A);c=inspect(C);equal=a['sha256']==c['sha256'] and a['bytes']==c['bytes']
assert a['fstat']['st_dev']==c['fstat']['st_dev']==27 and a['fstat']['st_nlink']==c['fstat']['st_nlink']==1 and a['fstat']['st_ino']!=c['fstat']['st_ino']
locators=[]
for root in (A.parent,C.parent):
 fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME|os.O_NOFOLLOW)
 try:
  with os.scandir(fd) as it:
   for e in it:
    s=e.stat(follow_symlinks=False)
    if stat.S_ISREG(s.st_mode) and e.name!=A.name:locators.append({'path':str(root/e.name),'bytes':s.st_size})
 finally:os.close(fd)
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576
j={'decision':'BYTE_EQUAL_PROVENANCE_AND_HOLD_REVIEW_STILL_REQUIRED' if equal else 'REJECT_DIFFERENT_ZIP_BODIES','anchor':a,'candidate':c,'wholeContainerBytesEqual':equal,'candidateAllocatedBytes':c['fstat']['st_blocks']*512,'knownPhysicalAliases':'Both nlink1 independent inodes: no other hardlink aliases exist at this fresh check. Path traversal held nofollow parent descriptors; no symlink dirs.','parentRights':parents,'companionLocatorsMetadataOnly':locators,'resources':{'ownMaxRSSBytes':rss,'approvedWorkBytes':512*1048576,'reserveBytes':512*1048576,'bodyChunkBytes':65536,'allInputFDsClosed':True,'scope':'Shared cgroup/file-cache guard; own RSS is not cache attribution. No unzip/cachehints/Git/links/action/protected ZIP body.'}}
with (M/'PAIR-PROOF.json').open('x') as f:json.dump(j,f,indent=2);f.write('\n')
print(json.dumps({'decision':j['decision'],'sha256s':[a['sha256'],c['sha256']],'candidateAllocatedBytes':j['candidateAllocatedBytes'],'RSS':rss,'companionLocators':locators}))
