import os,json,hashlib,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576));M=Path(__file__).parent
def body(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read(262145)
action=M/'share-retained-native-zip-root-r1.py';v=body(action).decode().replace('subprocess,stat','subprocess,stat,tarfile')
key="assert sha(D/'previous-four-POST-GATE.json')=="
at=v.index('\noldroot=',v.index(key))
extra="""
assert Path(bundle['path'])==D/'source-support.tar.gz'
fd=os.open(D/'source-support.tar.gz',os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as stream,tarfile.open(fileobj=stream,mode='r|gz') as tar:
    first=next(iter(tar));assert first.name=='MANIFEST.json' and first.isfile() and first.size<1048576
    assert hashlib.sha256(tar.extractfile(first).read()).hexdigest()==bundle['manifestSHA256']
"""
v=v[:at]+extra+v[at:];action.write_text(v)
pins={}
for n in ['share-retained-native-zip-root-r1.py','publish-retained-native-zip-sharing-root-r1.py','judge-retained-native-zip-sharing-root-r1.py']:
 v=body(M/n);compile(v,str(M/n),'exec');pins[n]=hashlib.sha256(v).hexdigest()
proposal=json.loads(body(M/'PROPOSAL.json'));planned=body(M/'AGENTS.planned.md');baseline=body(Path('/workspace/Roguelike-deckbuilder/AGENTS.md'));assert planned.endswith(baseline) and hashlib.sha256(baseline).hexdigest()==proposal['currentHold']['sha256']
old=json.loads(body(Path('/workspace/scratch/target-clear-ghost-promotion-root-r3/RESULT.json')));assert 'AGENTS.md' not in old['inputs']
j={'sourceSyntaxOnly':True,'methods':pins,'plannedHoldExactBaselineRemainder':True,'fullRuntimeMapExcludesAGENTSDocs':True,'protectedZIPBodyRead':False,'largeZIPReadsRepeated':False,'ownMaxRSSBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
assert j['ownMaxRSSBytes']<24*1048576
with (M/'SOURCE-CHECK.json').open('x') as f:json.dump(j,f,indent=2);f.write('\n')
print(json.dumps(j))
