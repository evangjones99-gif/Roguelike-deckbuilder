from pathlib import Path
import hashlib,os
p=Path('/workspace/scratch/four-raw-retirement-post-independent-r2/verify.py')
fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as f:b=f.read()
assert hashlib.sha256(b).hexdigest()=='964c52a2015a48a5d97fd7346fdae994e24e71d7cf56ccf716b37308d66bd176'
s=b.decode();old="ad['command']==['python',g['method']['path']";new="ad['command']==['python3',g['method']['path']"
assert s.count(old)==1
exec(compile(s.replace(old,new),str(p)+'[exact-python3-admission-rebind]','exec'))
