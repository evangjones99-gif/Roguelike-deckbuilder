from pathlib import Path
import os,json,hashlib,stat,resource,tarfile
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
S=Path('/workspace/scratch');R=Path('/workspace/Roguelike-deckbuilder');P=S/'four-raw-retirement-post-independent-r2';A=S/'four-archived-json-retirement-actual-root-r2';M=S/'four-archived-raw-retirement-source-author-r2';D=R/'reviews/four-archived-json-retirement-2026-10-02'
K=['st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_blocks','st_atime_ns','st_mtime_ns','st_ctime_ns']
def md(s):return {k:getattr(s,k) for k in K}
def op(path):
 p=Path(path);fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  for part in p.parent.parts[1:]:
   assert part not in ('','.', '..');q=os.open(part,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=q
  return os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=fd)
 finally:os.close(fd)
def pin(path,body=False):
 p=Path(path);a=md(os.lstat(p));fd=op(p);h=hashlib.sha256();n=0;parts=[]
 try:
  assert stat.S_ISREG(a['st_mode']) and md(os.fstat(fd))==a
  attrs={x:os.getxattr(fd,x).hex() for x in os.listxattr(fd)}
  for b in iter(lambda:os.read(fd,65536),b''):
   n+=len(b);h.update(b)
   if body:parts.append(b);assert n<262144
  assert md(os.fstat(fd))==a==md(os.lstat(p))
 finally:os.close(fd)
 q={'path':str(p),'sha256':h.hexdigest(),'bytes':n,'metadata':a,'xattrs':attrs}
 return (q,b''.join(parts)) if body else q
def simple(q):return {k:q[k] for k in ['path','sha256','bytes']}
def load(path):
 q,b=pin(path,True);return q,json.loads(b)
def digest(f):
 h=hashlib.sha256();n=0
 for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
 return h.hexdigest(),n
pp,e=load(M/'PROPOSAL.json');gp,g=load(S/'four-archived-raw-retirement-independent-r2/GATE.json')
assert pp['sha256']=='02a099158000476c103d69959f67dda002e51a6242a20395a81e43560990d3fe' and gp['sha256']=='650ccfad11abc9f6a10cf6aad63db0c68821d816f0ff53b323cbe179e9edcc56'
pushp,push=load(S/'four-archived-raw-retirement-push-root-r2/PUSH-CONFIRMED.json');jp,j=load(S/'four-archived-raw-retirement-producer-root-r2.json')
assert pushp['sha256']=='e78a3ddc4c68d7059cf894adec8c17430681d467c95f42a296a1a6b270f422f2' and jp['sha256']=='177e1045d7b4cbc641645a8a35e29924bf7d5a98058f7f27b6609eb199721511'
bp,before=load(A/'BEFORE.json');rp,result=load(A/'RESULT.json');prod=pin(A/'PRODUCER.json');jr,b=pin(A/'JOURNAL.jsonl',True);journal=[json.loads(x) for x in b.splitlines()]
assert rp['sha256']=='da96a21598804c67e24077c25faf383400d76ff1b8d2c0e6a996338010e8484f' and prod['sha256']==jp['sha256']
assert result['normal'] and result['noOtherAction'] and result['capsulesAndCurrent88_56Exact'] and result['protectedOriginalStatExact']
assert push['confirmed'] and push['clean'] and push['commit']==push['remote']==j['commit']=='6a8f435c4249828a799e7ccc29a310223a214831'
assert push['gateSHA256']==j['gateSHA256']==gp['sha256'] and push['proposalSHA256']==j['proposalSHA256']==pp['sha256'] and j['pushSHA256']==pushp['sha256'] and j['oneActionOnly']
for k,v in [('proposalSHA256',pp['sha256']),('gateSHA256',gp['sha256']),('judgmentSHA256',jp['sha256']),('pushSHA256',pushp['sha256'])]:assert before[k]==v
assert pushp['metadata']['st_mtime_ns']<=jp['metadata']['st_mtime_ns']<=bp['metadata']['st_mtime_ns']
controls=[]
for key in ['method','publisher','producer','restore','currentHold','selectedMap','currentCallerGate','priorR3POSTGate']:
 old=g[key];q=pin(old['path']);assert simple(q)==old;controls.append({'key':key,**simple(q)})
assert push['methodSHA256']==j['methodSHA256']==g['method']['sha256'] and push['callerGateSHA256']==j['callerGateSHA256']==g['currentCallerGate']['sha256']
readable=[(pp,D/'PROPOSAL.json'),(gp,D/'independent/GATE.json'),(g['currentCallerGate'],D/'root-controls/DEFAULT-CALLER-GATE.json'),(g['priorR3POSTGate'],D/'previous-R3-POST-GATE.json')]+[(g[key],D/'root-controls'/Path(g[key]['path']).name) for key in ['method','publisher','producer']]
published=[]
for original,path in readable:
 q=pin(path);assert (q['sha256'],q['bytes'])==(original['sha256'],original['bytes']);published.append(simple(q))
assert len(e['rawFiles'])==4 and [q['path'] for q in e['rawFiles']]==result['retiredPaths'] and [q['sha256'] for q in e['rawFiles']]==result['preservedBodies']
assert len(journal)==8 and [r['utcNs'] for r in journal]==sorted(r['utcNs'] for r in journal)
for i,q in enumerate(e['rawFiles']):
 try:os.lstat(q['path']);raise AssertionError('retired path exists')
 except FileNotFoundError:pass
 x=before['rawFiles'][i];assert x['path']==q['path'] and x['sha256']==q['sha256'] and x['proposalMetadata']==q['fstat']
 assert all(x['currentMetadata'][k]==v for k,v in q['fstat'].items() if k!='st_atime_ns') and x['xattrs']==q['xattrs']=={}
 pair=journal[2*i:2*i+2];assert [r['operation'] for r in pair]==['PRE_UNLINK','UNLINK_DURABLE'] and all(r['path']==q['path'] and r['sha256']==q['sha256'] for r in pair)
protected=S/'retained-original-archives/preflight-bdf273-original-r4.zip';zipbefore=md(os.lstat(protected));assert zipbefore==before['protectedZIPStat']==result['protectedZIPBefore']==result['protectedZIPAfter']
caps=[];rawmaps=[];atimediffs=[]
for i,c in enumerate(e['capsules']):
 q=pin(c['capsule']['path']);assert (q['sha256'],q['bytes'])==(c['capsule']['sha256'],c['capsule']['bytes']) and q['xattrs']==c['capsule']['xattrs']
 old=before['capsules'][i]['capsule']['currentMetadata'];assert all(q['metadata'][k]==v for k,v in old.items() if k!='st_atime_ns')
 if old['st_atime_ns']!=q['metadata']['st_atime_ns']:atimediffs.append({'path':q['path'],'actionAtimeNs':old['st_atime_ns'],'postAtimeNs':q['metadata']['st_atime_ns'],'cause':'unconfirmed; no reset'})
 fd=op(q['path']);manifest=None;blobs={}
 with os.fdopen(fd,'rb') as f,tarfile.open(fileobj=f,mode='r|gz') as tar:
  for m in tar:
   assert m.isfile()
   if m.name=='MANIFEST.json':
    assert manifest is None and m.size<300*1024;b=tar.extractfile(m).read();assert hashlib.sha256(b).hexdigest()==c['manifestSHA256'];manifest=json.loads(b)
   else:
    assert m.name.startswith('blobs/') and m.name not in blobs
    with tar.extractfile(m) as f:h,n=digest(f)
    assert m.name=='blobs/'+h and n==m.size;blobs[m.name]=(h,n)
 assert md(os.lstat(q['path']))==q['metadata'] and manifest is not None
 for logical,x in manifest['logicalBodies'].items():assert blobs['blobs/'+x['sha256']]==(x['sha256'],x['bytes'])
 for x in c['exactLogicalMapping']:
  r=x['entry'];assert manifest['logicalBodies'][r['logicalPath']]=={k:r[k] for k in ['originalPath','sha256','bytes']} and blobs[x['verifiedBlob']['member']]==(r['sha256'],r['bytes']);rawmaps.append(r)
 caps.append({'encoding':q,'manifestSHA256':c['manifestSHA256'],'fullBlobs':len(blobs),'logicalRows':len(manifest['logicalBodies'])})
assert [c['fullBlobs'] for c in caps]==[209,249] and [c['logicalRows'] for c in caps]==[226,264]
assert {x['originalPath'] for x in rawmaps}==set(result['retiredPaths'])
bundle=pin(D/'source-support.tar.gz');expected=push['supportBundle'];assert expected['roundtripExact'] and (bundle['sha256'],bundle['bytes'])==(expected['sha256'],expected['bytes'])
_,declared=load(D/'SUPPORT-BUNDLE.json');assert declared==expected
fd=op(bundle['path']);manifest=None;seen=set();private=0
with os.fdopen(fd,'rb') as f,tarfile.open(fileobj=f,mode='r|gz') as tar:
 for m in tar:
  assert m.isfile()
  if m.name=='MANIFEST.json':
   assert manifest is None and m.size<300*1024;b=tar.extractfile(m).read();assert hashlib.sha256(b).hexdigest()==expected['manifestSHA256'];manifest=json.loads(b);continue
  assert manifest is not None and m.name.startswith('bodies/');logical=m.name[7:];assert logical not in seen;r=manifest['logicalBodies'][logical]
  with tar.extractfile(m) as source:h,n=digest(source)
  assert (h,n)==(r['sha256'],r['bytes']) and n==m.size
  q=pin(r['originalPath']);assert (q['sha256'],q['bytes'])==(h,n);private+=1;seen.add(logical)
assert len(seen)==private==expected['logicalBodies']==73 and seen==set(manifest['logicalBodies']) and md(os.lstat(bundle['path']))==bundle['metadata']
selectedp,selected=load(g['selectedMap']['path']);assert simple(selectedp)==g['selectedMap'];current=[]
for key,root in [('inputs',R),('outputs',R/'dist')]:
 assert len(selected[key])=={'inputs':88,'outputs':56}[key]
 for rel,h in selected[key].items():
  q=pin(root/rel);assert q['sha256']==h;current.append([key,rel,h,q['bytes']])
guards=[]
for kind,folder,work in [('publication','four-raw-publication-guard-root-r2',256),('producer','four-raw-producer-guard-root-r2',64),('actual','four-raw-retirement-actual-guard-root-r2',64)]:
 adp,ad=load(S/folder/'ADMISSION.json');grp,gr=load(S/folder/'RESULT.json');assert ad['admitted'] and ad['work']==work*1048576 and ad['reserve']==512*1048576 and gr['exit_code']==0 and gr['failure'] is None and gr['memory_events_before']==gr['memory_events_after']
 guards.append({'kind':kind,'admission':simple(adp),'result':simple(grp),'executionLog':simple(pin(S/folder/'EXECUTION.log')),'samples':len(gr['samples'])})
 if kind=='actual':assert ad['command']==['python',g['method']['path'],pp['path'],pp['sha256'],gp['path'],gp['sha256'],jp['path'],jp['sha256'],pushp['path'],pushp['sha256']]
assert result['grossAllocationBytes']==sum(q['fstat']['st_blocks']*512 for q in e['rawFiles'])==2187264
assert result['netWindowGainBytes']==result['windowFreeAfterBeforeResultWrite']-result['windowFreeBefore']==2134016
assert md(os.lstat(protected))==zipbefore and push['publicationAllocatedBytes']<=768*1024
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576
proof={'proposal':simple(pp),'beforeGate':simple(gp),'confirmedPush':simple(pushp),'producer':simple(jp),'actionBefore':simple(bp),'actionResult':simple(rp),'actionProducerCopy':simple(prod),'actionJournal':simple(jr),'controls':controls,'publishedReadableControls':published,'retiredFourPaths':result['retiredPaths'],'originalRawMetadataControl':simple(bp),'fullExactFourArchivedBodyLogicalMappings':rawmaps,'capsules':caps,'capsuleAtimeOnlyActionToPOSTDifferences':atimediffs,'journalRows':journal,'fullSupportBundle':bundle,'supportManifestSHA256':expected['manifestSHA256'],'fullSupportBodyAndPrivateOriginalCount':73,'allSupportBodiesRoundtripExact':True,'currentSelectedFullBodyCount':144,'currentFull144RecordDigest':hashlib.sha256(json.dumps(current,separators=(',',':')).encode()).hexdigest(),'protectedZIPFullStatBefore':zipbefore,'protectedZIPFullStatAfter':md(os.lstat(protected)),'protectedZIPBodyNeverOpened':True,'RootGuardControls':guards,'publicationAllocatedBytes':push['publicationAllocatedBytes'],'grossAllocationBytes':2187264,'historicalActionPreResultWindowGainBytes':2134016,'ownMaxRSSBytes':rss,'limitations':'Exact4 oldpaths absent; archive fullbody/logical coverage, not all unlisted original paths/metadata nor all excluded external dependency bodies. Historical hardcoded gameplay/preservation need NEW reconstruction/adapted readers/mappings. Original inode/time loss; durable per-leaf prefix not all4 atomicity/metadata rollback/automatic retry/globalFD or futureconsumer absence. Windowgain not exclusive attribution/final net/native admission.','noGitRestoreCleanupNodeNativeMediaDecode':True,'allOwnReaderFDsClosed':True}
with (P/'PROOF.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'postNormal':True,'fourOldPathsAbsent':True,'fullCapsuleBlobs':[209,249],'logicalRows':[226,264],'supportFullRoundtripBodies':73,'currentFullBodies':144,'journalRows':8,'atimeOnlyDifferences':len(atimediffs),'ownMaxRSSBytes':rss,'allOwnReaderFDsClosed':True}))
