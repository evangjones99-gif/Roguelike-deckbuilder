from pathlib import Path
import os,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
P=Path('/workspace/scratch/four-raw-retirement-post-independent-r2')
def pin(path):
 p=Path(path);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);h=hashlib.sha256();n=0
 try:
  a=os.fstat(fd)
  for b in iter(lambda:os.read(fd,65536),b''):h.update(b);n+=len(b)
  assert os.fstat(fd)==a==os.lstat(p)
 finally:os.close(fd)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':n}
def load(path):
 q=pin(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 with os.fdopen(fd) as f:d=json.load(f)
 return q,d
def save(name,d):
 with (P/name).open('x') as f:json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
qp,d=load(P/'PROOF.json');gr=load(P/'PROOF-GUARD-r2/RESULT.json')[1]
assert gr['exit_code']==0 and gr['failure'] is None and gr['memory_events_before']==gr['memory_events_after']
assert d['ownMaxRSSBytes']<24*1048576 and d['currentSelectedFullBodyCount']==144 and d['fullSupportBodyAndPrivateOriginalCount']==73 and d['allSupportBodiesRoundtripExact']
assert len(d['journalRows'])==8 and [x['fullBlobs'] for x in d['capsules']]==[209,249]
for key in ['proposal','beforeGate','confirmedPush','producer','actionBefore','actionResult','actionProducerCopy','actionJournal']:
 assert pin(d[key]['path'])==d[key]
for q in d['controls']:
 assert pin(q['path'])=={k:q[k] for k in ['path','sha256','bytes']}
for q in d['publishedReadableControls']:assert pin(q['path'])==q
for q in [d['fullSupportBundle']]+[x['encoding'] for x in d['capsules']]:
 f=pin(q['path']);assert all(f[k]==q[k] for k in f)
 s=os.lstat(q['path']);assert {k:getattr(s,k) for k in q['metadata']}==q['metadata']
for path in d['retiredFourPaths']:
 try:os.lstat(path);raise AssertionError('oldpath returned')
 except FileNotFoundError:pass
z=os.lstat('/workspace/scratch/retained-original-archives/preflight-bdf273-original-r4.zip');assert {k:getattr(z,k) for k in d['protectedZIPFullStatAfter']}==d['protectedZIPFullStatAfter']==d['protectedZIPFullStatBefore']
gate={'decision':'ACCEPT independent POST exact four archived loose JSON retirements; no further action authority','beforeGate':d['beforeGate'],'proposal':d['proposal'],'confirmedPush':d['confirmedPush'],'producer':d['producer'],'actionResult':d['actionResult'],'proof':qp,'review':pin(P/'REVIEW.md'),'reader':pin(P/'verify-r2.py'),'preservedFailedReader':pin(P/'verify.py'),'sealer':pin(P/'seal.py'),'proofGuard':{k:pin(P/'PROOF-GUARD-r2'/k) for k in ['ADMISSION.json','RESULT.json','EXECUTION.log']},'exactFourOldPathsAbsent':d['retiredFourPaths'],'fullCapsuleBlobs':[209,249],'exactLogicalRows':[226,264],'publishedSupportRoundtripBodies':73,'selectedFullCurrentBodies':144,'journalRows':8,'protectedZIPFullStatExact':True,'protectedZIPBodyNeverOpened':True,'capsuleMetadataAtimeDifferences':d['capsuleAtimeOnlyActionToPOSTDifferences'],'RootGuardsNormal':True,'grossAllocationBytes':2187264,'historicalPreResultWindowGainBytes':2134016,'proofOwnRSSBytes':d['ownMaxRSSBytes'],'limits':d['limitations'],'nativeLimit':'Root reported73666560B below driver73924608B; no native admission or attempt from this review.','preservedFailure':'Original reader assumed python; exact actual launcher is python3. Tiny pinned correction reader normal; source/failed guard retained.','packetCapBytes':48*1024,'authority':'POST verification only; no additional retirement/restoration/Git/promotion/build/native authority.'}
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576;gate['sealOwnRSSBytes']=rss;save('GATE.json',gate)
stable=[pin(p) for p in sorted(P.rglob('*')) if p.is_file() and 'SEAL-GUARD' not in p.parts]
total=sum(p.stat().st_size for p in P.rglob('*') if p.is_file())
final={'gate':pin(P/'GATE.json'),'stableFiles':stable,'sealGuardAdmission':pin(P/'SEAL-GUARD/ADMISSION.json'),'bytesBeforeFinalReceipt':total,'packetCapBytes':48*1024,'finalGuardReserveBytes':2048,'ownRSSBytes':rss,'allOwnReaderFDsClosed':True,'closure':'Active seal guard log/final RESULT excluded from immutable ledger; outer normal completion checked after exit.'}
encoded=(json.dumps(final,indent=2)+'\n').encode();assert total+len(encoded)+2048<=48*1024
with (P/'FINAL-SEAL.json').open('xb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
fd=os.open(P,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({'gate':pin(P/'GATE.json'),'finalSeal':pin(P/'FINAL-SEAL.json'),'packetBytesNow':total+len(encoded),'ownRSSBytes':rss,'allOwnReaderFDsClosed':True}))
