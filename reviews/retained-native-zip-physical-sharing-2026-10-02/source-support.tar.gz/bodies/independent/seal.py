from pathlib import Path
import os,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
P=Path('/workspace/scratch/retained-native-zip-sharing-independent-r1')
def pin(path):
 p=Path(path);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME);h=hashlib.sha256();n=0
 try:
  a=os.fstat(fd)
  for b in iter(lambda:os.read(fd,65536),b''):h.update(b);n+=len(b)
  assert os.fstat(fd)==a==os.lstat(p)
 finally:os.close(fd)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':n}
def load(path):
 q=pin(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 with os.fdopen(fd) as f:d=json.load(f)
 return q,d
def save(name,d):
 with (P/name).open('x') as f:json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
qp,d=load(P/'PROOF.json');grp,gr=load(P/'PROOF-GUARD/RESULT.json');ad=load(P/'PROOF-GUARD/ADMISSION.json')[1]
assert ad['work']==512*1048576 and ad['reserve']==512*1048576 and gr['exit_code']==0 and gr['failure'] is None and gr['memory_events_before']==gr['memory_events_after']
assert d['wholeContainerEquality'] and len(d['pairFullBodiesMetadataXattrs'])==2 and d['prependOnlyBaselineBodyExact'] and d['ownMaxRSSBytes']<24*1048576
for key in ['proposal','authorSeal','currentHold','plannedHold','selectedMap','currentCallerGate','priorFourControls','priorFourPOSTGate']:
 assert pin(d[key]['path'])==d[key]
for q in d['methods']+d['provenancePins']:assert pin(q['path'])==q
for x in d['knownHistoricalConsumers']:assert pin(x['pin']['path'])==x['pin']
for q in d['pairFullBodiesMetadataXattrs']:
 s=os.lstat(q['path']);assert {k:getattr(s,k) for k in q['metadata']}==q['metadata']
 assert {n:os.getxattr(q['path'],n).hex() for n in os.listxattr(q['path'])}==q['xattrs']
z=os.lstat('/workspace/scratch/retained-original-archives/preflight-bdf273-original-r4.zip');assert {k:getattr(z,k) for k in d['protectedZIPFullStatAfter']}==d['protectedZIPFullStatAfter']==d['protectedZIPFullStatBefore']
assert d['publisherModel']['modeledPublishedAllocationUpperBytes']<512*1024 and d['publisherModel']['knownFullRoundtrip']
gate={'decision':'ACCEPT CONDITIONAL source eligibility for exact one retained native ZIP physical sharing; publish planned hold/current confirmed push/Root judgment required before action',
 'replacementBetter':True,'oldIndependentEncodingNoLongerNeeded':True,'proposal':d['proposal'],'method':d['methods'][0],'publisher':d['methods'][1],'producer':d['methods'][2],
 'currentHold':d['currentHold'],'plannedHold':d['plannedHold'],'selectedMap':d['selectedMap'],'currentCallerGate':d['currentCallerGate'],'priorFourPOSTGate':d['priorFourPOSTGate'],
 'proof':qp,'review':pin(P/'REVIEW.md'),'reader':pin(P/'verify.py'),'sealer':pin(P/'seal.py'),'proofGuard':{k:pin(P/'PROOF-GUARD'/k) for k in ['ADMISSION.json','RESULT.json','EXECUTION.log']},
 'candidateGroup':'/workspace/scratch/native-windows-v061/run-36791619534-1','exactPairPaths':[q['path'] for q in d['pairFullBodiesMetadataXattrs']],'wholeContainerSHA256':d['wholeSHA256'],'wholeContainerBytes':183597187,
 'sourceResourceProfile':d['sourceResourceProfile'],'ownProofRSSBytes':d['ownMaxRSSBytes'],'publisherModel':d['publisherModel'],'plannedPrependOnly':True,'freshFullCurrentBodies':144,'protectedZIPFullStatExact':True,'protectedZIPBodyNeverOpened':True,
 'preference':'Both logical paths and archive bytes remain needed. Verified held canonical container provides identical retained body/provenance with one fewer private physical encoding; duplicate scratch private encoding no longer needed under published fresh-stage workflow.',
 'necessityLimits':d['necessity'],'metadataLoss':'Scratch inode525659/time/write isolation lost; canonical inode1448589 retained, nlink1 becomes2/ctime changes. Shared writes/corruption affect both paths. Original metadata ledger retained, no inode/metadata rollback.',
 'durabilityLimits':'One atomic candidate pathname replacement after durable hardlink/journal prefix. Failure may leave named temp; no automatic retry/cleanup. Publisher generated-files/parent fsync and AGENTS update do not establish whole-publication power-loss atomicity.',
 'scopeLimits':'Container equality/provenance only, no unpacked rights/license audit/fresh Windows validation/current game improvement/native capacity guarantee. All versions/archives/parts/wrappers/extracted/art/datasets/reviews retained; no protectedZIP body.',
 'actionResource':'Root exact action512MiB work+512reserve/disk64; separate independent POST and fresh native grant required. Native70/70.5 unchanged.',
 'noProductionMethodsExecuted':True,'failures':'No source verifier failure observed. Prior failure receipts/source versions remain unchanged.','logicalPacketCapBytes':96*1024,'allocatedPacketCapBytes':128*1024,'publisherReviewMemberCap':32,
 'authority':'Source gate only; Root publishes exact proposal/review/methods/hold, confirms current clean push, records judgment, then may perform one exact sharing action. No other sharing/retirement/Git/restore/unzip/Node/native/cachehint authority.'}
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576;gate['ownSealRSSBytes']=rss;save('GATE.json',gate)
stable=[pin(p) for p in sorted(P.rglob('*')) if p.is_file() and 'SEAL-GUARD' not in p.parts]
total=sum(p.stat().st_size for p in P.rglob('*') if p.is_file());allocated=sum(p.stat().st_blocks*512 for p in P.rglob('*'))+P.stat().st_blocks*512
final={'gate':pin(P/'GATE.json'),'stableFiles':stable,'sealGuardAdmission':pin(P/'SEAL-GUARD/ADMISSION.json'),'bytesBeforeFinalReceipt':total,'allocatedBeforeFinalReceipt':allocated,'logicalCapBytes':96*1024,'allocatedCapBytes':128*1024,'finalGuardLogicalReserveBytes':8192,'finalGuardAllocatedReserveBytes':16384,'ownRSSBytes':rss,'allOwnReaderFDsClosed':True,'noProductionMethodsExecuted':True,'closure':'Active final guard log/RESULT excluded from immutable ledger; final outer normal completion checked after exit.'}
encoded=(json.dumps(final,indent=2)+'\n').encode();assert total+len(encoded)+8192<=96*1024 and allocated+((len(encoded)+4095)//4096*4096)+16384<=128*1024
with (P/'FINAL-SEAL.json').open('xb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
fd=os.open(P,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({'gate':pin(P/'GATE.json'),'finalSeal':pin(P/'FINAL-SEAL.json'),'packetBytesNow':total+len(encoded),'ownRSSBytes':rss,'allOwnReaderFDsClosed':True}))
