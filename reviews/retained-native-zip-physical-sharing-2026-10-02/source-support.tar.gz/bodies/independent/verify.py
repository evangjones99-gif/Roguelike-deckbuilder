from pathlib import Path
import os,json,hashlib,stat,resource,tarfile,gzip,io,ast
resource.setrlimit(resource.RLIMIT_DATA,(24*1048576,24*1048576))
S=Path('/workspace/scratch');R=Path('/workspace/Roguelike-deckbuilder');M=S/'retained-native-zip-sharing-source-author-r1';P=S/'retained-native-zip-sharing-independent-r1'
K=['st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_blocks','st_atime_ns','st_mtime_ns','st_ctime_ns']
def md(s):return {k:getattr(s,k) for k in K}
def op(path):
 p=Path(path);fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  for part in p.parent.parts[1:]:
   assert part not in ('','.', '..');q=os.open(part,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=q
  return os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=fd)
 finally:os.close(fd)
def pin(path,body=False):
 p=Path(path);a=md(os.lstat(p));fd=op(p);h=hashlib.sha256();n=0;parts=[]
 try:
  assert stat.S_ISREG(a['st_mode']) and md(os.fstat(fd))==a;attrs={x:os.getxattr(fd,x).hex() for x in os.listxattr(fd)}
  for b in iter(lambda:os.read(fd,65536),b''):
   n+=len(b);h.update(b)
   if body:parts.append(b);assert n<262144
  assert md(os.fstat(fd))==a==md(os.lstat(p))
 finally:os.close(fd)
 q={'path':str(p),'sha256':h.hexdigest(),'bytes':n,'metadata':a,'xattrs':attrs}
 return (q,b''.join(parts)) if body else q
def simple(q):return {k:q[k] for k in ['path','sha256','bytes']}
def load(path):
 q,b=pin(path,True);return q,json.loads(b)
def digest(f):
 h=hashlib.sha256();n=0
 for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
 return h.hexdigest(),n
pp,e=load(M/'PROPOSAL.json');fp,final=load(M/'FINAL-SEAL.json')
assert pp['sha256']=='a796297e764218fa2bc798eed638b67e44aa5d334b97a898d8a00c237b62516c' and fp['sha256']=='169d6b81716064a5660445dfcf2212cf308bd4b71fd24566c35f7060a8abaf02'
authorFiles=[]
for rel,x in final['files'].items():
 q=pin(M/rel);assert (q['sha256'],q['bytes'])==(x['sha256'],x['bytes']);authorFiles.append(simple(q))
authorGuards=[]
for folder in sorted(M.iterdir()):
 if folder.is_dir() and folder.name.endswith('GUARD'):
  adp,ad=load(folder/'ADMISSION.json');rp,res=load(folder/'RESULT.json');assert ad['admitted'] and res['exit_code']==0 and res['failure'] is None and res['memory_events_before']==res['memory_events_after']
  authorGuards.append({'name':folder.name,'workBytes':ad['work'],'result':simple(rp),'samples':len(res['samples']),'sharedCgroupScope':res['scope']})
assert len(e['pairs'])==1
pair=e['pairs'][0];bodies=[];atime=[]
for key in ['anchor','candidate']:
 old=pair[key];q=pin(old['path']);assert (q['sha256'],q['bytes'])==(old['sha256'],old['bytes'])==(e['wholeContainerSHA256'],183597187)
 assert q['xattrs']==old['xattrs']=={} and all(q['metadata'][k]==v for k,v in old['fstat'].items() if k!='st_atime_ns')
 assert q['metadata']['st_dev']==27 and q['metadata']['st_nlink']==1 and q['metadata']['st_uid']==q['metadata']['st_gid']==1000
 if q['metadata']['st_atime_ns']!=old['fstat']['st_atime_ns']:atime.append({'key':key,'original':old['fstat']['st_atime_ns'],'fresh':q['metadata']['st_atime_ns'],'cause':'unconfirmed; no timestamp reset'})
 bodies.append(q)
assert bodies[0]['metadata']['st_ino']==1448589 and bodies[1]['metadata']['st_ino']==525659 and bodies[0]['metadata']['st_mode']==bodies[1]['metadata']['st_mode']==33152
assert Path(bodies[0]['path']).parent==R/'releases/0.6.1' and Path(bodies[1]['path']).parent==S/'native-windows-v061/run-36791619534-1'
assert bodies[1]['metadata']['st_blocks']*512==e['grossAllocationBytes']==183603200
hold,h=pin(e['currentHold']['path'],True);plannedp,planned=pin(e['plannedHold']['path'],True)
assert simple(hold)=={k:e['currentHold'][k] for k in ['path','sha256','bytes']} and simple(plannedp)=={k:e['plannedHold'][k] for k in ['path','sha256','bytes']}
assert planned.endswith(h) and len(planned)>len(h) and planned.count(h)==1
prepend=planned[:-len(h)].decode();assert prepend.startswith('## Immutable retained native 0.6.1 ZIP aliases') and all(q['path'] in prepend for q in bodies)
assert all(x in prepend for x in ['Never write, truncate, chmod','NEW directory, pathname and inode','not OS-enforced','producer judgment and confirmed current push'])
prov=[];data=[]
for old in e['provenancePins']:
 q,b=pin(old['path'],True);assert simple(q)=={k:old[k] for k in ['path','sha256','bytes']};prov.append(simple(q));data.append(b)
release=json.loads(data[0]);transfer=json.loads(data[1]);sha=e['wholeContainerSHA256']
assert release['artifacts'][Path(bodies[0]['path']).name]==release['nativeWindows']['originalArchiveSHA256']==transfer['archiveSHA256']==sha
assert transfer['archiveBytes']==183597187 and transfer['originalArchive']==bodies[1]['path']
assert release['runtimeSourceDigest']==transfer['sourceDigest']=='8720a38701aa78ccae894ba4ca7cb8656cc3072d5b023cdd9cc3d9d2b3d4c22d'
assert release['nativeWindows']['actualPRMergeCheckout']==transfer['actualPRMergeCheckout']=='913577b23eede5acec79be1b6938dbb86dad0ab7' and release['nativeWindows']['files']==transfer['files']==72
assert (sha+'  '+Path(bodies[0]['path']).name).encode() in data[2] and sha.encode() in data[3] and transfer['status']=='transfer-verified-not-yet-native-independent-accepted'
consumers=[]
for name in ['verify-transfer.py','verify-transfer-r2.py','audit.mjs']:
 q,b=pin(R/'reviews/technical-v0.6.1-native-evidence'/name,True);consumers.append({'pin':simple(q),'oldRootReferenced':b'native-windows-v061/run-36791619534-1' in b,'qualification':'Source reads preserved ZIP/extracted/parts/evidence; reviewer outputs must be fresh on replay. No rerun executed.'})
tmp=Path(bodies[1]['path']+'.root-share-retained-native-zip-r1.tmp')
try:os.lstat(tmp);raise AssertionError('action temporary path already present')
except FileNotFoundError:pass
selectedp,selected=load(e['selectedMap']['path']);assert simple(selectedp)=={k:e['selectedMap'][k] for k in ['path','sha256','bytes']};current=[]
for key,root in [('inputs',R),('outputs',R/'dist')]:
 assert len(selected[key])=={'inputs':88,'outputs':56}[key]
 for rel,h in selected[key].items():
  q=pin(root/rel);assert q['sha256']==h;current.append([key,rel,h,q['bytes']])
callerp=pin(e['currentCallerGate']['path']);assert simple(callerp)=={k:e['currentCallerGate'][k] for k in ['path','sha256','bytes']}
headp,head=pin(R/'.git/refs/heads/codex/lanternbound-production',True);assert head.decode().strip()==e['expectedCurrentHEAD']=='6a8f435c4249828a799e7ccc29a310223a214831'
priorp,prior=load(M/'PRIOR-FOUR-CONTROLS.json');priorpins=[]
for x in prior['exactPriorMemberPins']+prior['files']:
 q=pin(x['path']);assert (q['sha256'],q['bytes'])==(x['sha256'],x['bytes']);priorpins.append(simple(q))
postp,post=load(prior['postGatePath']);assert postp['sha256']==prior['postGateSHA256']=='57ac409802290271a2b6ef32f6f8aa5e08738ddb03f17c9750c325cba5dde5b7' and prior['POSTClosed'] and post['decision'].startswith('ACCEPT')
_,postproof=load(S/'four-raw-retirement-post-independent-r2/PROOF.json');zip_path=S/'retained-original-archives/preflight-bdf273-original-r4.zip';zipbefore=md(os.lstat(zip_path));assert zipbefore==postproof['protectedZIPFullStatAfter']
methods=[]
for name in ['share-retained-native-zip-root-r1.py','publish-retained-native-zip-sharing-root-r1.py','judge-retained-native-zip-sharing-root-r1.py']:
 q,b=pin(M/name,True);ast.parse(b);methods.append(simple(q))
plan=[]
def walk(root,label):
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink()
  if path.is_file():
   q=pin(path);assert q['bytes']<262144;plan.append((path,label+'/'+str(path.relative_to(root)),q))
walk(M,'author')
for x in prior['folders']:walk(Path(x['path']),x['label'])
for x in prior['files']:
 q=pin(x['path']);plan.append((Path(x['path']),'prior-four/'+x['label'],q))
plan.append((Path(callerp['path']),'controls/DEFAULT-CALLER-GATE.json',callerp))
assert len(plan)<400 and len({l for p,l,q in plan})==len(plan)
records={l:{'originalPath':str(p),'bytes':q['bytes'],'sha256':q['sha256']} for p,l,q in plan}
manifest=json.dumps({'schema':'exact-source-support-bundle-r1','logicalBodies':records},sort_keys=True,separators=(',',':')).encode()+b'\n';buf=io.BytesIO()
with gzip.GzipFile(filename='',mode='wb',fileobj=buf,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
 def add(n,v):
  info=tarfile.TarInfo(n);info.size=len(v);info.mode=0o600;info.mtime=0;info.uid=info.gid=0;tar.addfile(info,io.BytesIO(v))
 add('MANIFEST.json',manifest)
 for p,l,q in plan:
  fresh,v=pin(p,True);assert simple(fresh)==simple(q);add('bodies/'+l,v)
encoded=buf.getvalue();seen=set()
with tarfile.open(fileobj=io.BytesIO(encoded),mode='r|gz') as tar:
 for m in tar:
  assert m.isfile()
  if m.name=='MANIFEST.json':assert tar.extractfile(m).read()==manifest;continue
  assert m.name.startswith('bodies/');l=m.name[7:];assert l in records and l not in seen
  with tar.extractfile(m) as f:h,n=digest(f)
  assert (h,n)==(records[l]['sha256'],records[l]['bytes']);seen.add(l)
assert seen==set(records)
known=sum(q['bytes'] for p,l,q in plan);future=96*1024;assert known+future<2*1048576 and len(plan)+32<400
bundle_upper=len(encoded)+future+32*1024+24*1024+8192
readable_upper=pp['bytes']+future+callerp['bytes']+postp['bytes']+sum(q['bytes'] for q in methods)+8192
allocation_upper=((bundle_upper+4095)//4096*4096)+readable_upper+32*4096;assert allocation_upper<512*1024
assert md(os.lstat(zip_path))==zipbefore
for q in bodies:assert md(os.lstat(q['path']))==q['metadata']
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert rss<24*1048576
proof={'proposal':simple(pp),'authorSeal':simple(fp),'pairFullBodiesMetadataXattrs':bodies,'atimeOnlyAuthorToIndependentDifferences':atime,'wholeContainerEquality':True,'wholeSHA256':sha,'wholeBytes':183597187,'grossAllocationBytes':183603200,'currentHold':simple(hold),'plannedHold':simple(plannedp),'prependOnlyBaselineBodyExact':True,'provenancePins':prov,'provenanceAgrees':{'runtimeSourceDigest':release['runtimeSourceDigest'],'actualPRMergeCheckout':transfer['actualPRMergeCheckout'],'files':72,'historicalTransferStatusRetained':transfer['status']},'knownHistoricalConsumers':consumers,'selectedMap':simple(selectedp),'currentCallerGate':simple(callerp),'current144FullBodyRecordDigest':hashlib.sha256(json.dumps(current,separators=(',',':')).encode()).hexdigest(),'expectedHEADSourcePin':simple(headp),'priorFourControls':simple(priorp),'priorFourExactMemberCount':len(priorpins),'priorFourPOSTGate':simple(postp),'protectedZIPFullStatBefore':zipbefore,'protectedZIPFullStatAfter':md(os.lstat(zip_path)),'protectedZIPBodyNeverOpened':True,'methods':methods,'authorSealedFileCount':len(authorFiles),'authorGuards':authorGuards,'publisherModel':{'knownBodies':len(plan),'knownBodyBytes':known,'knownGzipBytes':len(encoded),'knownGzipSHA256':hashlib.sha256(encoded).hexdigest(),'knownFullRoundtrip':True,'futureReviewLogicalCapBytes':future,'futureReviewMemberCap':32,'modeledPublishedAllocationUpperBytes':allocation_upper,'hardPublicationAllocationCapBytes':512*1024,'publisherInitialFloorBytes':int(65.5*1048576),'GitCopyEstimateBytes':int(1.5*1048576),'estimateNotOSBound':True},'ownMaxRSSBytes':rss,'sourceResourceProfile':'Original guard512MiB work+512reserve/disk64, ownRSS24 for two183MB encoded filecache streams; no other reader claimed exclusive globally. Root coordinated CSSguard closure before this audit.','necessity':'Both path/container bodies still needed; old separate scratch physical encoding unnecessary under published exact immutable/fresh-stage hold. Known archive readers retain paths. Future download/reassembly/rebuild and reviewer outputs require new stages; no global futurewriter/FD absence proof.','scope':'No sharing/link/unzip/Git/native/Node/protectedZIPbody/cachehint/othercleanup executed; all own readerFDs closed.'}
with (P/'PROOF.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'sourceBeforeNormal':True,'fullZipBodies':2,'wholeSHA':sha,'wholeBytes':183597187,'currentFullBodies':144,'priorMemberPins':len(priorpins),'knownPublisherFullRoundtripBodies':len(plan),'publisherAllocationUpper':allocation_upper,'ownRSSBytes':rss,'allOwnReaderFDsClosed':True}))
