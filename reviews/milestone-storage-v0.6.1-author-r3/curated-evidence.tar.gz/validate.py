from pathlib import Path
import json, yaml, hashlib, subprocess, zipfile, warnings
p=Path(__file__).parent; root=Path('/workspace/Roguelike-deckbuilder'); y=yaml.load((p/'preserve-v061.yml').read_text(),Loader=yaml.BaseLoader)
assert set(y['on'])=={'workflow_dispatch','push'}
assert y['on']['push']=={'branches':['codex/lanternbound-production'],'paths':['.github/workflows/preserve-v061.yml']}
assert set(y['on']['workflow_dispatch']['inputs'])=={'confirm_draft_preservation'}
assert y['on']['workflow_dispatch']['inputs']['confirm_draft_preservation']['type']=='boolean'
assert y['permissions']=={}
assert set(y['jobs'])=={'preserve-v061'}
j=y['jobs']['preserve-v061'];assert j['permissions']=={'contents':'write','actions':'read'} and j['timeout-minutes']=='15' and j['runs-on']=='ubuntu-24.04'
assert [s['uses'] for s in j['steps']]==['actions/github-script@f28e40c7f34bde8b3046d885e986cb6290c5673b','actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02']
assert j['steps'][1]['with']['path']=='preservation/report.json' and j['steps'][1]['if']=='always()' and j['steps'][1]['with']['retention-days']=='30'
assert not any('run' in s for s in j['steps'])
assert (p/'workflow-script.js').read_text()==j['steps'][0]['with']['script']
assert hashlib.sha256((root/'.github/workflows/preserve-milestones.yml').read_bytes()).hexdigest()=='90d317a7207b8a6e66e52b016d4e8024a4244730719b0157863ce0b71d31f81f'
assert not (root/'.github/workflows/preserve-v061.yml').exists()
source=(p/'extraction.py').read_text();compile(source,'exact-runtime-extraction','exec')
q=p/'zip-probes';q.mkdir(exist_ok=True); results=[]
cases=[('valid-nested',[('release/native.zip',b'original'),('extra/evidence.txt',b'not-executed')],8,True),('valid-empty-unrelated',[('native.zip',b'original'),('empty/',b'')],8,True),('wrong-size',[('native.zip',b'original')],7,False),('no-target',[('other.zip',b'original')],8,False),('empty-wrapper',[],8,False),('duplicate-target',[('native.zip',b'original'),('other/native.zip',b'original')],8,False),('parent-traversal',[('native.zip',b'original'),('../evil',b'bad')],8,False),('absolute-member',[('native.zip',b'original'),('/evil',b'bad')],8,False),('backslash-member',[('native.zip',b'original'),('folder\\evil',b'bad')],8,False),('target-directory',[('native.zip/',b'')],0,False)]
for name,entries,bound,ok in cases:
 z=q/(name+'.zip');o=q/(name+'.out')
 with warnings.catch_warnings():
  warnings.simplefilter('ignore')
  with zipfile.ZipFile(z,'w') as a:
   for key,value in entries:a.writestr(key,value)
 proc=subprocess.run(['python3',str(p/'extraction.py'),str(z),str(o),'native.zip',str(bound)],capture_output=True,text=True)
 assert (proc.returncode==0)==ok,(name,proc.stderr)
 if ok:assert o.read_bytes()==b'original'
 results.append({'name':name,'passed':True,'expectedSuccess':ok,'exit':proc.returncode,'stderr':proc.stderr})
z=q/'truncated.zip';z.write_bytes((q/'valid-nested.zip').read_bytes()[:32]);proc=subprocess.run(['python3',str(p/'extraction.py'),str(z),str(q/'truncated.out'),'native.zip','8'],capture_output=True,text=True);assert proc.returncode!=0;results.append({'name':'truncated-zip','passed':True,'expectedSuccess':False,'exit':proc.returncode,'stderr':proc.stderr})
z=q/'bad-crc.zip';z.write_bytes((q/'valid-nested.zip').read_bytes().replace(b'original',b'corrupt!'));proc=subprocess.run(['python3',str(p/'extraction.py'),str(z),str(q/'bad-crc.out'),'native.zip','8'],capture_output=True,text=True);assert proc.returncode!=0;results.append({'name':'bad-member-crc','passed':True,'expectedSuccess':False,'exit':proc.returncode,'stderr':proc.stderr})
(p/'zip-probes.json').write_text(json.dumps({'method':'Execute exact embedded Python extraction, unchanged. Direct synthetic invocation supplies tiny native.zip name/byte bound, rather than production hardcoded arguments. No artifact code executes.', 'cases':results},indent=2)+'\n')
checks=[]
for name in ['manifest.json','SHA256SUMS','hollowpact-0.6.1-windows-native-x64.zip','hollowpact-0.6.1-native-evidence-36791619534-1.zip']:
 file=root/'releases/0.6.1'/name; h=hashlib.sha256()
 with file.open('rb') as f:
  while block:=f.read(1024*1024):h.update(block)
 checks.append({'name':name,'bytes':file.stat().st_size,'sha256':h.hexdigest(),'method':'Read existing local file in 1MiB chunks; no new copy or download'})
m=json.loads((p/'manifest.json').read_text())
for c in checks:
 if c['name'] in m['artifacts']:assert c['sha256']==m['artifacts'][c['name']]
(p/'local-original-hashes.json').write_text(json.dumps(checks,indent=2)+'\n')
(p/'syntax-policy.json').write_text(json.dumps({'yamlSyntax':True,'exactScriptCorrespondence':True,'pinnedActions':True,'newPathAbsentFromProduction':True,'oldV040ByteUnchanged':True,'workflowPrivilegesAndTriggers':True,'pythonSyntax':True,'zipProbeCases':len(results)},indent=2)+'\n')
print(json.dumps({'policy':'PASS','zipProbes':len(results),'localOriginalHashes':'PASS'}))
