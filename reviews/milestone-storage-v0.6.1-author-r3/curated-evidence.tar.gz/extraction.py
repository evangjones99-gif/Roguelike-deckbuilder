import sys, zipfile
from pathlib import PurePosixPath
with zipfile.ZipFile(sys.argv[1]) as archive:
 entries = archive.infolist()
 assert all(not PurePosixPath(e.filename).is_absolute() and ".." not in PurePosixPath(e.filename).parts and "\\" not in e.filename for e in entries)
 selected = [e for e in entries if PurePosixPath(e.filename).name == sys.argv[3]]
 bound = int(sys.argv[4])
 assert len(selected) == 1 and not selected[0].is_dir() and selected[0].file_size == bound
 with archive.open(selected[0]) as source, open(sys.argv[2], "wb") as output:
  total = 0
  while True:
   chunk = source.read(min(1024 * 1024, bound - total + 1))
   if not chunk: break
   total += len(chunk)
   assert total <= bound
   output.write(chunk)
  assert total == bound