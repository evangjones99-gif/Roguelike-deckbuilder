import json,hashlib,pathlib,urllib.request,sys
P=pathlib.Path('/workspace/scratch/large-card-layout-author-v09-r1')
rows=[]
for label,stage,port in [('baseline','/tmp/hollowpact-relic-bone-v09-root-r1',4626),('candidate','/tmp/hollowpact-large-card-v09-author-r1',4625)]:
 d=pathlib.Path(stage); prov=json.loads((d/'dist/build-provenance.json').read_text()); hashes={}
 for name,expected in prov['hashes'].items():
  f=d/name; actual=hashlib.sha256(f.read_bytes()).hexdigest(); assert actual==expected,(name,actual,expected);hashes[name]=actual
 digest=hashlib.sha256(json.dumps(hashes,separators=(',',':')).encode()).hexdigest();assert digest==prov['sourceDigest']
 outputs=[]
 for f in sorted((d/'dist').rglob('*')):
  if not f.is_file():continue
  name=str(f.relative_to(d/'dist')); raw=f.read_bytes();remote=urllib.request.urlopen(f'http://127.0.0.1:{port}/'+name).read(); assert raw==remote,name
  outputs.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 rows.append({'label':label,'stage':stage,'port':port,'version':prov['version'],'sourceDigest':digest,'inputs':hashes,'outputs':outputs})
assert rows[0]['sourceDigest']=='4bfa417ad790dd88a18868e10e7574666ae8bfc3187bdab1df4947c31231de61'
changed=[k for k in rows[0]['inputs'] if rows[0]['inputs'][k]!=rows[1]['inputs'][k]];assert changed==['src/style.css'],changed
assert [len(r['inputs']) for r in rows]==[78,78]; assert [len(r['outputs'])for r in rows]==[56,56]
(P/sys.argv[1]).write_text(json.dumps({'changedInputs':changed,'rows':rows},indent=2)+'\n')
print('VERIFIED',rows[1]['sourceDigest'],changed)
