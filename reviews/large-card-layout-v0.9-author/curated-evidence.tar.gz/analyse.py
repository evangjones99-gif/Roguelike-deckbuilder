import json,gzip,pathlib,hashlib
p=pathlib.Path('/workspace/scratch/large-card-layout-author-v09-r1');sets={'main':[],'short':[],'controls':[]}
for name,dirs in [('main',['r2','r5','r6']),('short',['short-height']),('controls',['controls'])]:
 for d in dirs:
  for f in sorted((p/d).glob('case-*.json.gz')):
   r=json.loads(gzip.decompress(f.read_bytes()));r['receipt']=str(f.relative_to(p));sets[name].append(r)
main=sets['main'];short=sets['short'];assert len(main)==290 and len(short)==116 and len(sets['controls'])==10
seen=set()
for r in main:
 key=(r['width'],r['variant'],r['phase'],r['batch']);assert key not in seen;seen.add(key)
allrows=main+short;fonts=[];layouts=[];long=[]
for height,rs in [(900,main),(720,short)]:
 for width in sorted(set(r['width']for r in rs)):
  for phase in ['reward','shop','deck']:
   bs=[r for r in rs if r['width']==width and r['variant']=='baseline'and r['phase']==phase]
   cs=[r for r in rs if r['width']==width and r['variant']=='candidate'and r['phase']==phase]
   assert sorted(c['id']for r in cs for c in r['before']['cards'])==sorted(json.loads((p/'CATALOGUE.json').read_text()))
   for b,c in zip(sorted(bs,key=lambda r:r['batch']),sorted(cs,key=lambda r:r['batch'])):
    assert b['before']['save']==c['before']['save'];assert not c['overflow']
    for bc,cc in zip(b['before']['cards'],c['before']['cards']):
     assert bc['id']==cc['id']
     for bn,cn in zip(bc['nodes'],cc['nodes']):assert bn['text']==cn['text']and bn['font']==cn['font']
     if bc['id']=='fenraker':layouts.append({'width':width,'height':height,'phase':phase,'baselineCardHeight':bc['box']['h'],'candidateCardHeight':cc['box']['h'],'baselineReceipt':b['receipt'],'candidateReceipt':c['receipt']})
  for variant in ['baseline','candidate']:
   r=next(r for r in rs if r['width']==width and r['variant']==variant and r['phase']=='long-battle');long.append({'width':width,'height':height,'variant':variant,'document':r['before']['body'],'receipt':r['receipt']})
for r in sets['controls']:assert len(r['checks'])==4 and not r['errors']
a={'catalogueCards':48,'completedRenderedStates':406,'completedBrowserProfilesMain':12,'completedBrowserProfilesShort':4,'completedBrowserProfilesControls':10,'totalActualProfilesIncludingFailedAttempts':29,'mainRuleActions':sum('actualAction'in r for r in main),'shortRuleActions':sum('actualAction'in r for r in short),'controlRuleActions':40,'actualRuleActions':68,'captures':len(list(p.rglob('*.jpg'))),'candidateLargeCardMeasurements':sum(len(r['before']['cards'])for r in allrows if r['variant']=='candidate'),'candidateOutsideOrTruncatedPrintedContentObservations':sum(len(r['overflow'])for r in allrows if r['variant']=='candidate'),'baselineOutsideOrTruncatedPrintedContentObservations':sum(len(r['overflow'])for r in allrows if r['variant']=='baseline'),'pairedFontsAndTextExact':True,'normalAndLongSavedNameHandGeometryPairExact':True,'fenrakerLayouts':layouts,'longSavedNameInheritedOverflow':long,'browsersClosedBeforeFreeze':True,'limitations':'Unearned diagnostic saves. Enhanced reward/shop stress IDs are validator-valid but not normally generated. Unit saved names are100 chars; catalogue card names are static. Bounds and pointer hit tests are software evidence, not human/native/AAA/accessibility certification.'}
(p/'AUTHOR-ANALYSIS.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps({k:a[k]for k in ['completedRenderedStates','actualRuleActions','captures','candidateLargeCardMeasurements','baselineOutsideOrTruncatedPrintedContentObservations','candidateOutsideOrTruncatedPrintedContentObservations']},indent=2))
