// Read-only actual-run/report/API audit. No SDK writes or large downloads.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const yaml=require('/workspace/Roguelike-deckbuilder/node_modules/yaml');
const root=__dirname,read=name=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'));
const sourceDir='/workspace/scratch/installer-research-remote-preservation-author-v08-r3';
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
const workflow=fs.readFileSync(path.join(root,'actual-activation-workflow.yml'),'utf8');
assert.equal(hash(workflow),'fbc0afde71858071fa35ff5d582d886d3aaff009997b2d644decb961cb32a9a7');
const parsed=yaml.parse(workflow),source=parsed.jobs['preserve-installer-research'].steps[0].with.script;
assert.equal(source.trimEnd(),fs.readFileSync(path.join(sourceDir,'candidate-script.js'),'utf8').trimEnd());
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const prefix=source.slice(0,source.indexOf('// BEGIN EXECUTION:'));
const run=read('run-final.json'),jobs=read('jobs-final.json'),artifact=read('artifacts-final.json').artifacts[0],report=read('raw-report.json');
assert.equal(run.id,36807179943);assert.equal(run.head_sha,'40b7104f18c8ae4c1cdb66b1b73a9ea111336951');
assert.equal(run.path,'.github/workflows/preserve-installer-research.yml');assert.equal(run.event,'push');
assert.equal(run.head_branch,'codex/lanternbound-production');assert.equal(run.status,'completed');assert.equal(run.conclusion,'success');
assert.equal(run.run_attempt,1);assert.equal(jobs.total_count,1);assert.equal(jobs.jobs[0].id,110194027033);
assert.equal(jobs.jobs[0].conclusion,'success');assert(jobs.jobs[0].steps.every(s=>s.conclusion==='success'));
assert.equal(artifact.id,11138436206);assert.equal(artifact.size_in_bytes,1492);
assert.equal(artifact.digest,'sha256:4ef5f3045c1903d5be7c1a2300b1f0b8ec0efa872dbb354f785b9a3ea2850c5a');assert.equal(artifact.expired,false);
assert.equal(report.schema,1);assert.equal(report.status,'passed-four-installer-research-draft-preservation');assert.equal(report.phase,'complete');
assert.equal(report.scope,'four-installer-research-drafts-three-failed-one-isolated-QA-pass');
for(const key of ['officialGameRelease','newNativeGameplayVerificationPerformed','newUninstallVerificationPerformed','commercialQualityAccepted','steamPublished'])assert.equal(report[key],false);
assert.equal(report.cases.length,4);assert.deepEqual(report.cases.map(c=>c.originalNativeQAStatus),['failed','failed','failed','passed']);
(async()=>{
 const h=await new AsyncFunction('require','core',prefix+'\nreturn {PINS,validateRun,validateArtifact,validateRelease,validateTag,coverage,releaseIdentity};')(require,{getInput:()=> 'UNUSED-READONLY-HELPER-FIXTURE'});
 const audit=[];let totalParts=0,totalReadbackBytes=0,totalAssets=0;
 const coverageDir=path.join(root,'expected-deterministic-coverage');fs.mkdirSync(coverageDir);
 for(let i=0;i<h.PINS.length;i++){
  const pin=h.PINS[i],item=report.cases[i];
  assert.equal(item.runId,pin.runId);assert.equal(item.sourceCommit,pin.headSHA);assert.equal(item.runtimeSourceDigest,pin.sourceDigest);
  assert.equal(item.originalNativeQAStatus,pin.nativeQAStatus);assert.equal(item.status,'passed-research-partial-preservation');assert.equal(item.tag,pin.tag);assert.equal(item.newResearchTagCreated,true);
  const origin=read('origin-run-'+pin.runId+'.json');h.validateRun(origin,pin);
  const originArtifacts=read('origin-artifacts-'+pin.runId+'.json');assert.equal(originArtifacts.total_count,6);assert.equal(originArtifacts.artifacts.length,6);
  const verifiedInputs=[];
  for(const expected of [...pin.parts,pin.evidence]){
   const matches=originArtifacts.artifacts.filter(a=>a.id===expected.artifactId);assert.equal(matches.length,1);h.validateArtifact(matches[0],pin,expected);
   verifiedInputs.push({artifactID:expected.artifactId,bytes:expected.wrapperBytes??expected.bytes,sha256:expected.wrapperSHA256??expected.sha256,currentAPIIdentityDigestExact:true});
  }
  totalParts+=pin.parts.length;assert.equal(pin.parts.reduce((s,p)=>s+p.bytes,0),pin.bytes);
  const originalEvidence=fs.readFileSync(path.join(sourceDir,'input-receipts',String(pin.runId),'original-native-evidence.zip'));
  assert.equal(originalEvidence.length,pin.evidence.bytes);assert.equal(hash(originalEvidence),pin.evidence.sha256);
  const release=read('release-'+pin.runId+'.json'),tag=read('tag-'+pin.runId+'.json'),assets=read('assets-'+pin.runId+'.json');
  h.validateRelease(release,pin);h.validateTag(tag,pin);assert.equal(release.id,item.releaseId);
  assert.equal(release.published_at,null);assert.equal(assets.length,3);assert.equal(release.assets.length,3);assert.equal(new Set(assets.map(a=>a.id)).size,3);
  const coverage=h.coverage(pin),coverageBytes=Buffer.from(JSON.stringify(coverage,null,2)+'\n');
  const coveragePath=path.join(coverageDir,String(pin.runId)+'.json');fs.writeFileSync(coveragePath,coverageBytes,{flag:'wx'});
  assert.equal(coverage.statusOfOriginalNativeQA,pin.nativeQAStatus);assert.equal(coverage.officialGameRelease,false);assert.equal(coverage.newNativeGameplayVerificationPerformed,false);
  const expected=[{name:pin.installerAssetName,bytes:pin.bytes,sha256:pin.sha256},
   {name:pin.evidenceAssetName,bytes:pin.evidence.bytes,sha256:pin.evidence.sha256},
   {name:'preservation-coverage.json',bytes:coverageBytes.length,sha256:hash(coverageBytes)}];
  assert.equal(item.assets.length,3);
  for(const e of expected){
   const matches=item.assets.filter(a=>a.name===e.name);assert.equal(matches.length,1);const receipt=matches[0];
   assert.equal(receipt.bytes,e.bytes);assert.equal(receipt.sha256,e.sha256);assert.equal(receipt.fullReadBackVerified,true);
   const current=assets.filter(a=>a.id===receipt.assetId&&a.name===e.name);assert.equal(current.length,1);const a=current[0];
   assert.equal(a.size,e.bytes);assert.equal(a.digest,'sha256:'+e.sha256);assert.equal(a.state,'uploaded');
   const embedded=release.assets.filter(x=>x.id===a.id);assert.equal(embedded.length,1);assert.deepEqual(embedded[0],a);
   totalReadbackBytes+=e.bytes;totalAssets++;
  }
  audit.push({runId:pin.runId,originalNativeQAStatus:pin.nativeQAStatus,sourceCommit:pin.headSHA,runtimeSourceDigest:pin.sourceDigest,
   releaseID:release.id,draft:release.draft,prerelease:release.prerelease,publishedAt:release.published_at,
   exactCurrentTagTarget:tag.object.sha,originalInstallerBytes:pin.bytes,originalInstallerSHA256:pin.sha256,
   allSixOriginInputMetadataDigestsCurrentAndExact:true,verifiedOriginInputs:verifiedInputs,
   actualReviewedJobReconstructionAndFullReadbackEstablishedByControlFlowAndReceipt:true,
   allThreeCurrentServerAssetSHA256Exact:true,assetIDs:item.assets.map(a=>a.assetId),coverageSHA256:hash(coverageBytes),
   ownLargeOriginalDownloaded:false,ownCoverageBinaryDownloaded:false});
 }
 assert.equal(totalParts,20);assert.equal(totalAssets,12);
 const result={schema:1,status:'accepted-actual-four-original-partial-research-preservation',utc:new Date().toISOString(),
  actualStorageRun:run.id,actualStorageSourceCommit:run.head_sha,actualWorkflowSHA256:hash(workflow),
  originalSourceStatusOracle:['failed','failed','failed','passed'],originalPartCount:totalParts,storedAssetCount:totalAssets,
  actualJobFullReadbackBytes:totalReadbackBytes,cases:audit,
  scope:'Actual exact-reviewed-source successful storage job plus original diagnostic CRC/hash, all four current origin identities/24 artifact digests, and current twelve server asset IDs/sizes/SHA256 and exact draft/tag ownership. Actual reviewed workflow downloads/reconstructs/verifies originals and performs complete remote byte/SHA read-backs; reviewer independently inspects that control flow and real run outputs, not mocked fixtures. Reviewer did not download large original binaries or stored coverage bodies. Deterministic coverage bytes independently regenerated and matched to real server digest and actual diagnostic.',
  wholeInstallerBytesDurablyMirroredAsResearchDraftAssets:true,completeGameVersionSourceDatasetOrFullCIInputMirror:false,
  publicPublicationOrNewNativeAcceptance:false,sourceRepairFixturesBorrowedAsActualStorageProof:false};
 fs.writeFileSync(path.join(root,'INDEPENDENT-ACTUAL-AUDIT.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({status:result.status,origins:4,parts:totalParts,assets:totalAssets,actualJobFullReadbackBytes:totalReadbackBytes,ownLargeDownload:false}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
