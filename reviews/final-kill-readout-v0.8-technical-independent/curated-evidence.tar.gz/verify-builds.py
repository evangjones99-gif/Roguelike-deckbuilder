import hashlib,json
from pathlib import Path
A=Path('/workspace/scratch/final-kill-readout-author-v08-r1');O=Path(__file__).parent
id=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());rows=[]
for variant in ['baseline','candidate']:
 d=Path('/tmp/final-kill-independent-technical-'+variant+'-r1/dist');expected=id['buildOutputs'][variant];actual={p.relative_to(d).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in d.rglob('*')if p.is_file()}
 assert actual==expected,(variant,[k for k in actual if actual[k]!=expected.get(k)])
 rows.append({'variant':variant,'outputs':actual})
(O/'REPRODUCED-BUILDS.json').write_text(json.dumps(rows,indent=2)+'\n');print('All 55 outputs match for each fresh strict build')
