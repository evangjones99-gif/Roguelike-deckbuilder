from pathlib import Path
import hashlib,json,shutil
A=Path('/workspace/scratch/final-kill-readout-author-v08-r1');O=Path(__file__).parent
h=lambda b:hashlib.sha256(b).hexdigest()
f=A/'FROZEN-FILES.json';assert h(f.read_bytes())=='7b324e01f47fde70bcf98ff3f242be561fd15a3d88217195d981a40756d52dd4'
manifest=json.loads(f.read_text())['files']
for rel,r in manifest.items():
 b=(A/rel).read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256'],rel
identity=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());rows=[]
for variant in ['baseline','candidate']:
 dst=Path('/tmp')/('final-kill-independent-technical-'+variant+'-r1');dst.mkdir()
 records=identity['runtimeInputs'][variant]
 for rel,r in records.items():
  b=Path(r['input']).read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256'],(variant,rel)
  q=dst/rel;q.parent.mkdir(parents=True,exist_ok=True)
  if r['externalImmutableMedia']:q.symlink_to(r['input'])
  else:q.write_bytes(b)
 digest=h(json.dumps({rel:r['sha256']for rel,r in records.items()},separators=(',',':')).encode());assert digest==identity[variant+'Digest']
 for rel in ['tests','reviews','scripts/simulate.ts']:
  source=A/'prototype'/rel;target=dst/rel
  if source.is_dir():shutil.copytree(source,target,symlinks=True)
  else:shutil.copy2(source,target)
 (dst/'node_modules').symlink_to('/workspace/Roguelike-deckbuilder/node_modules',target_is_directory=True)
 rows.append({'variant':variant,'digest':digest,'inputs':records,'destination':str(dst),'extraCompileInputs':'Frozen author test/review/simulate fixtures; not runtime inputs','media':'Verified explicit external original aliases, not copied inputs'})
source=(A/'prototype/src/main.ts').read_text();a=source.index('function finalStrikeRoster(');z=source.index('\nfunction updateFinalStrikeReadout',a)
(O/'exact-projection.ts').write_text("import type { GameState, TransitionEvent } from '/tmp/final-kill-independent-technical-candidate-r1/src/engine.ts';\nexport "+source[a:z]+'\n')
(O/'INPUT-VERIFICATION-BEFORE.json').write_text(json.dumps({'authorManifestSha':h(f.read_bytes()),'verifiedAuthorFiles':len(manifest),'variants':rows},indent=2)+'\n')
print(json.dumps({'authorFiles':len(manifest),'variants':[(r['variant'],r['digest'],len(r['inputs']))for r in rows]}))
