import type { GameState, TransitionEvent } from '/tmp/final-kill-independent-technical-candidate-r1/src/engine.ts';
export function finalStrikeRoster(previous: GameState, resolved: GameState, events: readonly TransitionEvent[]) {
  const shown = {
    allies: previous.allies.map(unit => ({ ...unit })),
    enemies: previous.enemies.map(unit => ({ ...unit })),
  };
  const byUid = new Map([...shown.allies, ...shown.enemies].map(unit => [unit.uid, unit]));
  const nonnegative = (value: number) => Number.isFinite(value) && value >= 0;
  for (const event of events) {
    if (event.type === 'summon' && event.target === event.unit.uid && !byUid.has(event.target)) {
      const unit = { ...event.unit };
      shown[event.side === 'ally' ? 'allies' : 'enemies'].push(unit);
      byUid.set(unit.uid, unit);
    }
    const unit = byUid.get(event.target);
    if (!unit) continue;
    if ((event.type === 'hit' || event.type === 'heal') && nonnegative(event.afterHp)) {
      unit.hp = Math.min(unit.maxHp, event.afterHp);
      if (event.type === 'hit' && nonnegative(event.blocked)) unit.block = Math.max(0, unit.block - event.blocked);
    } else if (event.type === 'death') unit.hp = 0;
    else if (event.type === 'ward' && nonnegative(event.amount)) unit.block += event.amount;
    else if (event.type === 'buff' && nonnegative(event.after)) unit.attack = event.after;
  }
  // Surviving canonical actors also include untraced turn resets, such as block.
  // Absence alone never means death: victory deliberately clears the whole party.
  for (const unit of [...resolved.allies, ...resolved.enemies]) {
    const held = byUid.get(unit.uid);
    if (held) Object.assign(held, unit);
  }
  return shown;
}
