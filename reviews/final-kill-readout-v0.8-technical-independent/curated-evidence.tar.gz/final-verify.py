from pathlib import Path
import hashlib,json,urllib.request,urllib.parse,os,signal,time
A=Path('/workspace/scratch/final-kill-readout-author-v08-r1');O=Path(__file__).parent;h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((A/'FROZEN-FILES.json').read_text())['files'];id=json.loads((A/'SOURCE-BUILD-IDENTITY.json').read_text());rows=[]
assert h((A/'FROZEN-FILES.json').read_bytes())=='7b324e01f47fde70bcf98ff3f242be561fd15a3d88217195d981a40756d52dd4'
for p,r in m.items():
 b=(A/p).read_bytes();assert len(b)==r['bytes']and h(b)==r['sha256'],p
for variant,port in [('baseline',4510),('candidate',4511)]:
 sources={};outputs={};http={};fresh=Path('/tmp/final-kill-independent-technical-'+variant+'-r1')
 for p,r in id['runtimeInputs'][variant].items():
  for q in [Path(r['input']),fresh/p]:
   b=q.read_bytes();assert len(b)==r['bytes']and h(b)==r['sha256'],str(q)
  sources[p]={'bytes':r['bytes'],'sha256':r['sha256']}
 for p,r in id['buildOutputs'][variant].items():
  b=(fresh/'dist'/p).read_bytes();assert len(b)==r['bytes']and h(b)==r['sha256'];outputs[p]=r
  response=urllib.request.urlopen(f'http://127.0.0.1:{port}/'+urllib.parse.quote(p));b=response.read();actual={'bytes':len(b),'sha256':h(b)};assert actual==r,p;http[p]={'status':response.status,**actual}
 assert set(outputs)=={p.relative_to(fresh/'dist').as_posix()for p in (fresh/'dist').rglob('*')if p.is_file()}
 rows.append({'variant':variant,'sourceDigest':id[variant+'Digest'],'sources':sources,'outputs':outputs,'HTTP':http})
(O/'FINAL-IMMUTABILITY.json').write_text(json.dumps({'authorManifestSha':h((A/'FROZEN-FILES.json').read_bytes()),'authorFilesVerifiedUnchanged':len(m),'variants':rows},indent=2)+'\n')
(O/'source-inspection').mkdir()
for name,src in [('baseline-main.ts','/tmp/final-kill-independent-technical-baseline-r1/src/main.ts'),('candidate-main.ts','/tmp/final-kill-independent-technical-candidate-r1/src/main.ts'),('unchanged-engine.ts','/tmp/final-kill-independent-technical-candidate-r1/src/engine.ts')]:
 (O/'source-inspection'/name).write_bytes(Path(src).read_bytes())
servers=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:argv=(p/'cmdline').read_bytes().split(b'\0');argv=[s.decode()for s in argv if s]
 except (PermissionError,FileNotFoundError):continue
 if argv in [['python','-m','http.server',str(port),'--bind','127.0.0.1','--directory',f'/tmp/final-kill-independent-technical-{variant}-r1/dist']for variant,port in [('baseline',4510),('candidate',4511)]]:
  servers.append({'pid':int(p.name),'argv':argv});os.kill(int(p.name),signal.SIGTERM)
assert len(servers)==2,len(servers)
(O/'OWN-SERVER-CLOSURE.json').write_text(json.dumps({'closedOwnedServers':servers,'browserClosure':'Each own Playwright browser closes in finally; contexts close sequentially. No system-wide reader/agent absence claim.','derivedBuilds':'Fresh independent TMP source/dist trees remain retained; explicit original-media aliases and installed dependencies declared.'},indent=2)+'\n')
print(json.dumps({'frozenAuthorFiles':len(m),'runtimeInputsReverified':152,'freshOutputsReverified':110,'HTTPBodiesReverified':110,'serversClosed':len(servers)}))
