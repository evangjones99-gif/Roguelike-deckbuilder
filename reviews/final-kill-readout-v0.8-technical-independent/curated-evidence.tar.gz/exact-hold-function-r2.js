function holdFinalStrike(previous, events) {
  if (!mayAnimateCombat() || !arena) return false;
  let busy = 0;
  try {
    busy = Math.max(0, Math.min(1200, Number(arena.busyMs?.() || 0)));
  } catch {
    return false;
  }
  if (!Number.isFinite(busy) || busy <= 0) return false;
  const epoch = ++presentationEpoch;
  settlingCombat = true;
  $("app").classList.add("settling-combat");
  $("scene-ui").setAttribute("aria-busy", "true");
  const hint = document.querySelector(".keyboard-hint");
  if (hint) hint.innerHTML = inputHints();
  updateFinalStrikeReadout(previous, events);
  document.querySelectorAll("#scene-ui button, #dock button").forEach((button) => {
    button.disabled = true;
  });
  const guidance = document.querySelector(".battle-guidance>span");
  if (guidance) guidance.textContent = state.phase === "defeat" ? "The pact breaks. The final impact is resolving." : "Contract cleared. Final strike resolving.";
  const cancel = document.querySelector(".battle-guidance>button");
  if (cancel) cancel.hidden = true;
  const caption = document.querySelector(".arena-caption>small");
  if (caption) caption.textContent = state.phase === "defeat" ? "PACT BROKEN" : "WARRANT CLOSED";
  const endButton = document.querySelector('[data-action="endTurn"]');
  if (endButton) endButton.textContent = state.phase === "defeat" ? "Contract failed" : "Contract cleared";
  document.querySelectorAll(".unit.selected, .unit.valid-target").forEach((unit) => unit.classList.remove("selected", "valid-target"));
  $("announcer").textContent = state.phase === "defeat" ? "The hunter has fallen." : "Contract cleared.";
  presentationDeadline = setTimeout(() => finishPresentation(epoch), Math.min(1200, Math.ceil(busy) + 30));
  try {
    const waiting = arena.waitForPresentation?.();
    if (waiting) void waiting.then(() => finishPresentation(epoch), () => finishPresentation(epoch));
  } catch {
    finishPresentation(epoch);
  }
  return true;
}
