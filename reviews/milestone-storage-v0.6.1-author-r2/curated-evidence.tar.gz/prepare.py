from pathlib import Path
import json, hashlib, yaml, shutil
root=Path('/workspace/Roguelike-deckbuilder'); out=Path('/workspace/scratch/milestone-storage-v061-proposal')
original=(root/'.github/workflows/preserve-milestones.yml').read_bytes()
(out/'v040-original.yml').write_bytes(original)
s=original.decode()
replacements={'Preserve verified development milestone':'Preserve exact v0.6.1 development native archives','0.4.0':'0.6.1','preserve-v040':'preserve-v061','preserve-milestones.yml':'preserve-v061.yml','36772521612':'36791619534','33b8325452622f7be745fa88d69818896cc8b34a':'cb1c3964d4865ae729807fcb3208b6d856bd25fc','dae9758ea40f849b36d9891c859b7bf6df09d242':'83d75e30a90db65db743a4522288607cf45682b1','59b252300f50244d06ea0d40e6d4e2318a02806bcfa5d719a2ca7186217fbb67':'6999e88dfc4b19626e50734571e997c9fd19b1a5c2e4ce9439159343160fd500','0b227baad42e6529cff939598903533171a24b078e792536cfcebbaadb38c0b4':'66ea71f543eb0c2bd29bcb80538b41db22eb21c655c28dafaf18aa54fc5542c1','da553781de9d57a2ca3a0c6260082335e7db65ad423c8cfd647e84d4055f5425':'8720a38701aa78ccae894ba4ca7cb8656cc3072d5b023cdd9cc3d9d2b3d4c22d','hollowpact-0.6.1-windows-native-tested-x64.zip':'hollowpact-0.6.1-windows-native-x64.zip','hollowpact-0.6.1-windows-native-evidence.zip':'hollowpact-0.6.1-native-evidence-36791619534-1.zip','ec5203567cf15bcae28c6b1b4e908469fd075197bba6b67cfab2185f2b9d8927':'06e48cce30ccd2a8fcfcc7a829ec79d3fa6b628541a19effa368852df0bce90b','55f967466653acda8fe52545892590de663629f8ed28c8e697d7b0c9f07dcd3a':'1741107cb452d08eb9c2f33a02f8ff1c64076776892b512cd075747adff6f047','11123973383':'11132128179','180306034':'192975515','d3fac04b38713ad006ae33d4fc710fc0b51df28b850b74ef8511a6e8bc818cea':'ee181194451f10e601742fa4a570303e7ed6e66c79a2a7c58555bb2feb91b8d4','178481506':'183597187','11123858254':'11131988966','1993027':'9545515'}
for a,b in replacements.items(): s=s.replace(a,b)
# The only input is confirmation; all payload/identity values are constants.
a=s.index('      version:'); b=s.index('      confirm_draft_preservation:');s=s[:a]+s[b:]
s=s.replace("(github.event_name == 'workflow_dispatch' && inputs.version == '0.6.1' &&\n        inputs.native_run == '36791619534' && inputs.confirm_draft_preservation))", "(github.event_name == 'workflow_dispatch' && inputs.confirm_draft_preservation))")
s=s.replace("            const nativeRun = 36791619534;", "            const nativeRun = 36791619534;\n            const nativeHead = '9e6e7d7e76a2ce606acae24d2f6a27c903b54a5f';")
s=s.replace("if (declared) check(Number(declared) <= limit", "if (declared !== null) check(/^[0-9]+$/.test(declared) && Number.isSafeInteger(Number(declared)) && Number(declared) <= limit")
s=s.replace("location.protocol === 'https:' && allowed.some", "location.protocol === 'https:' && !location.username && !location.password && (!location.port || location.port === '443') && allowed.some")
s=s.replace("await fetch(location, {signal: AbortSignal.timeout(180000)})", "await fetch(location, {redirect: 'manual', signal: AbortSignal.timeout(180000)})")
s=s.replace("check(redirected.ok,", "check(redirected.status === 200,")
s=s.replace("data.workflow_run?.id === nativeRun,", "data.id === id && data.workflow_run?.id === nativeRun && data.workflow_run.head_sha === nativeHead && data.workflow_run.head_branch === 'codex/lanternbound-production',")
s=s.replace("              if (data.digest) check", "              check")
s=s.replace("check(context.repo.owner === owner && context.repo.repo === repo, 'Repository mismatch');", "check(context.repo.owner === owner && context.repo.repo === repo, 'Repository mismatch');\n              check(context.ref === 'refs/heads/codex/lanternbound-production' &&\n                (context.eventName === 'push' || (context.eventName === 'workflow_dispatch' &&\n                  [true, 'true'].includes(context.payload.inputs?.confirm_draft_preservation))), 'Trigger/ref/confirmation mismatch');")
s=s.replace("manifest.nativeWindows.runId === nativeRun && manifest.steamPublished", "manifest.nativeWindows.runId === nativeRun && manifest.nativeWindows.attempt === 1 && manifest.nativeWindows.headSourceCheckpoint === nativeHead && manifest.steamPublished")
s=s.replace("workflow.data.conclusion === 'success'", "workflow.data.id === nativeRun && workflow.data.status === 'completed' && workflow.data.head_sha === nativeHead && workflow.data.head_branch === 'codex/lanternbound-production' && workflow.data.conclusion === 'success'")
s=s.replace("for (const [filename, digest] of Object.entries(manifest.artifacts)) check(sumsData.toString('utf8').includes(`${digest}  ${filename}\\n`), `Checksums missing ${filename}`);", "check(Object.keys(manifest.artifacts).length === 6 &&\n                ['linux-x64.tar.gz', 'source.zip', 'web.zip', 'windows-x64.zip'].every(suffix =>\n                  /^[a-f0-9]{64}$/.test(manifest.artifacts[`hollowpact-${version}-${suffix}`])), 'Expected six-archive manifest coverage mismatch');\n              check(sumsData.toString('utf8') === Object.entries(manifest.artifacts).map(([filename, digest]) => `${digest}  ${filename}\\n`).join(''), 'Exact checksums/manifest mismatch');")
a=s.index("                'import sys, zipfile, shutil',");b=s.index("              check(hash(fs.readFileSync",a)
s=s[:a]+'''                'import sys, zipfile',
                'from pathlib import PurePosixPath',
                'with zipfile.ZipFile(sys.argv[1]) as archive:',
                ' entries = archive.infolist()',
                ' assert all(not PurePosixPath(e.filename).is_absolute() and ".." not in PurePosixPath(e.filename).parts and "\\\\\\\\" not in e.filename for e in entries)',
                ' selected = [e for e in entries if PurePosixPath(e.filename).name == sys.argv[3]]',
                ' bound = int(sys.argv[4])',
                ' assert len(selected) == 1 and not selected[0].is_dir() and selected[0].file_size == bound',
                ' with archive.open(selected[0]) as source, open(sys.argv[2], "wb") as output:',
                '  total = 0',
                '  while True:',
                '   chunk = source.read(min(1024 * 1024, bound - total + 1))',
                '   if not chunk: break',
                '   total += len(chunk)',
                '   assert total <= bound',
                '   output.write(chunk)',
                '  assert total == bound',
              ].join('\\n'), wrapperPath, path.join(directory, nativeName), nativeName, '183597187'], {timeout: 120000});
''' +s[b:]
s=s.replace("check(hash(fs.readFileSync(path.join(directory, nativeName))) === nativeSHA", "check(fs.statSync(path.join(directory, nativeName)).size === 183597187 && hash(fs.readFileSync(path.join(directory, nativeName))) === nativeSHA")
s=s.replace("report.status = 'failed'; report.error = error.message;\n              core.setFailed(error.message);", "report.status = 'failed'; report.error = String(error.message).split(token).join('[redacted]');\n              core.setFailed(report.error);")
s=s.replace("check(final.data.draft && final.data.prerelease,", "check(final.data.draft && final.data.prerelease && final.data.tag_name === tag && final.data.body?.includes(marker),")
(out/'preserve-v061.yml').write_text(s)
y=yaml.load(s,Loader=yaml.BaseLoader); script=y['jobs']['preserve-v061']['steps'][0]['with']['script']; (out/'workflow-script.js').write_text(script)
for name in ['manifest.json','SHA256SUMS']:(out/name).write_bytes((root/'releases/0.6.1'/name).read_bytes())
(out/'author-diff.patch').write_text(__import__('difflib').unified_diff(original.decode().splitlines(True),s.splitlines(True),fromfile='frozen-v040',tofile='proposed-new-v061').__str__()) if False else None
(out/'author-diff.patch').write_text(''.join(__import__('difflib').unified_diff(original.decode().splitlines(True),s.splitlines(True),fromfile='frozen-v040',tofile='proposed-new-v061')))
print(json.dumps({'workflow':hashlib.sha256(s.encode()).hexdigest(),'old':hashlib.sha256(original).hexdigest(),'scriptBytes':len(script)},indent=2))
