import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
// Only loaded after actual campaign decisions, voluntary feedback export and browser closure.
// No actions, legality oracle or simulator is imported or executed.
import {validateState} from '/tmp/hollowpact-relic-bone-v09-root-r1/src/engine.ts';
const p='/workspace/scratch/agent-ui-playtest-v09-seed381027';
const raw=fs.readFileSync(p+'/FINAL-SAVE.json','utf8'),state=JSON.parse(raw);
assert(validateState(state));assert.equal(JSON.stringify(state),raw);assert.equal(state.phase,'victory');assert.equal(state.seed,381027);assert.equal(state.difficulty,1);assert.equal(state.schema,3);assert.equal(state.engineKind,2);
const result={scope:'AFTER all gameplay decisions and browser closure only; validation, no engine decisions/oracle',valid:true,serializerExact:true,finalSaveSHA256:createHash('sha256').update(raw).digest('hex'),bytes:Buffer.byteLength(raw),phase:state.phase,seed:state.seed,difficulty:state.difficulty,schema:state.schema,engineKind:state.engineKind,health:[state.hp,state.maxHp],gold:state.gold,deck:state.deck,relics:state.relics,stats:state.stats};
fs.writeFileSync(p+'/FINAL-VALIDATION.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
