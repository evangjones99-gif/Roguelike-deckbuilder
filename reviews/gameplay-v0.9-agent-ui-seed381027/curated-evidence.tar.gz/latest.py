import gzip,json,pathlib
p=pathlib.Path('/workspace/scratch/agent-ui-playtest-v09-seed381027')
f=sorted(p.glob('decision-*.gz'))[-1];d=json.loads(gzip.decompress(f.read_bytes()));o=d['after'];print(f.name)
for k in ['hud','guidance','panel','hand','units','dialog','announcer']:print(k,json.dumps(o.get(k)))
print('choice controls',json.dumps([x for x in o['controls'] if x.get('action') or x.get('ui') in ['relic','upgrade','buy','event','rest','train','finish','continue']]))
