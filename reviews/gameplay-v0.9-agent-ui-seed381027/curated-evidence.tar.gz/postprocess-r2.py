import pathlib,json,gzip,hashlib
p=pathlib.Path('/workspace/scratch/agent-ui-playtest-v09-seed381027')
rows=[json.loads(gzip.decompress(f.read_bytes()))for f in sorted(p.glob('decision-*.gz'))]
audit=json.loads((p/'FINAL-VALIDATION.json').read_text());feedback=json.loads((p/'AGENT-LABELLED-LOCAL-FEEDBACK.json').read_text());export=json.loads((p/'EXPORT-SAVE-IMMUTABILITY.json').read_text())
assert feedback['responses']['confusion'].startswith('[AGENT NOT HUMAN]')
assert feedback['responses']['interestingChoice'].startswith('[AGENT NOT HUMAN]')
assert export['before']==export['after'];assert hashlib.sha256(export['after'].encode()).hexdigest()==audit['finalSaveSHA256']
assert json.loads((p/'FINAL-UI.json').read_text())['errors']==[]
ops=[];saves=[];inspections=[]
for row in rows:
 command=row['command'];ops.append({'sequence':row['sequence'],'operation':command,'beforeScreen':row['before']['screen'],'afterScreen':row['after']['screen'],'beforeHUD':row['before'].get('hud'),'afterHUD':row['after'].get('hud')})
 saves.append({'sequence':row['sequence'],'before':row['saveBefore'],'after':row['saveAfter']})
 if command['op']=='click' and any(t in command.get('selector','')for t in ['data-ui=deck','data-ui=inspect','data-ui=relic']):
  assert row['saveBefore']==row['saveAfter'];inspections.append(row['sequence'])
 def write(name,body): (p/name).write_text(body)
write('UI-OPERATIONS.jsonl',''.join(json.dumps(o,separators=(',',':'))+'\n'for o in ops))
write('SAVE-CHECKPOINTS.json',json.dumps({'scope':'Actual serialized local gameplay save hashes read without parsing state during UI play; not oracle decisions; repeated hashes retained, no reload continuity test claimed','operations':len(rows),'hashReadings':2*len(rows),'uniqueSHAs':len({y['saveSHA256']for row in saves for y in [row['before'],row['after']]}),'dossierInspectionSaveEqualitySequences':inspections,'rows':saves},indent=2)+'\n')
write('FEEDBACK-CLASSIFICATION.json',json.dumps({'classification':'AGENT NOT HUMAN','participantType':'synthetic agent','includeInHumanFeedbackDataset':False,'humanMLEnjoymentLabel':False,'canonicalExportPreserved':'AGENT-LABELLED-LOCAL-FEEDBACK.json','canonicalKind':feedback['kind'],'channelMetadataDoesNotProveNativeInstallation':True,'bothFreeformFieldsExplicitlyLabelled':True,'replayIntent':feedback['responses']['replayIntent'],'nothingSubmittedExternally':True,'gameplaySaveUnchangedDuringExport':True,'exactSaveSHA256':audit['finalSaveSHA256']},indent=2)+'\n')
write('POSTPROCESS-CORRECTION-r2.txt',"R1's failed reader guessed meaningfulChoice. Its follow-up annotation also incorrectly guessed choice. The actual preserved schema field is interestingChoice, established by fresh JSON read and used by this executed R2 reader. Both labels and immutability pass. No original feedback, source or browser result was changed.\n")
print(json.dumps({'operations':len(rows),'hashReadings':2*len(rows),'uniqueSaveSHAs':len({y['saveSHA256']for row in saves for y in [row['before'],row['after']]}),'inspectionsSaveUnchanged':inspections,'browserErrors':[],'feedbackBothLabels':True,'exportSaveSame':True}))
