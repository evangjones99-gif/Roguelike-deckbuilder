from pathlib import Path
import json,hashlib,urllib.request,sys
O=Path('/workspace/scratch/agent-ui-playtest-v09-seed381027');H=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for label,stage,port,digest,count,outCount in [('candidate',Path('/tmp/hollowpact-relic-bone-v09-root-r1'),4605,'4bfa417ad790dd88a18868e10e7574666ae8bfc3187bdab1df4947c31231de61',78,56)]:
 p=json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/build-provenance.json'));assert p['sourceDigest']==digest and len(p['hashes'])==count
 assert H(json.dumps(p['hashes'],separators=(',',':')).encode())==digest
 for f,h in p['hashes'].items():assert H((stage/f).read_bytes())==h,f
 outputs={}
 for f in sorted((stage/'dist').rglob('*')):
  if f.is_file():
   name=f.relative_to(stage/'dist').as_posix();b=f.read_bytes();assert urllib.request.urlopen(f'http://127.0.0.1:{port}/{name}').read()==b,name;outputs[name]={'bytes':len(b),'sha256':H(b)}
 assert len(outputs)==outCount
 rows.append({'label':label,'stage':str(stage),'port':port,'provenance':p,'outputs':outputs})
(O/(sys.argv[1]+'-identity.json')).write_text(json.dumps({'scope':'Own complete actual source/local/HTTP output verification; no source edits or engine decision oracle','rows':rows},indent=2)+'\n')
print('Verified 78 sources and 56 complete local/HTTP outputs: '+sys.argv[1])
