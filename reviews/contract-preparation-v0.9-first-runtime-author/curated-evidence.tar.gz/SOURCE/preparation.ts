/** Optional new-contract preparation. Never transforms an existing campaign. */
import { createGame, validateState, type GameState } from './engine';
import { STARTER_DECK } from './content';

export type Preparation = 'standard' | 'recall' | 'severance';
export const PREPARATIONS = Object.freeze({
  standard: Object.freeze({ added: null }),
  recall: Object.freeze({ added: 'killcommand' }),
  severance: Object.freeze({ added: 'silence' }),
});
const RECIPE = Object.freeze(['cairnhound', 'cairnhound', 'fenstalker', 'ashwidow',
  'briarcolossus', 'scour', 'scour', 'ironward', 'ironward', 'sutures', 'sunder', 'survey']);

export function isPreparation(value: unknown): value is Preparation {
  return typeof value === 'string' && Object.hasOwn(PREPARATIONS, value);
}
export function preparedDeck(value: unknown): string[] {
  if (!isPreparation(value)) throw new Error('Choose a listed preparation.');
  if (STARTER_DECK.length !== RECIPE.length || STARTER_DECK.some((id, i) => id !== RECIPE[i]))
    throw new Error('The supplied recipe changed. Preparation is unavailable.');
  const deck = STARTER_DECK.slice();
  if (value !== 'standard') deck[5] = PREPARATIONS[value].added!;
  return deck;
}
export function createPreparedContract(seed: number, difficulty = 0,
  preparation: Preparation = 'standard', engineKind: 1 | 2 = 2): GameState {
  if (!isPreparation(preparation)) throw new Error('Choose a listed preparation.');
  if (engineKind !== 1 && engineKind !== 2) throw new Error('Unsupported rules generation.');
  if (engineKind === 1 && preparation !== 'standard')
    throw new Error('Specialist preparation is for new generation2 contracts only.');
  const deck = preparedDeck(preparation);
  const next = createGame(seed, difficulty, { engineKind });
  if (next.deck.length !== RECIPE.length || next.deck.some((id, i) => id !== RECIPE[i]))
    throw new Error('The initial campaign recipe changed.');
  if (preparation === 'standard') return next;
  next.deck = deck;
  if (!validateState(next)) throw new Error('The prepared campaign is invalid.');
  return next;
}
