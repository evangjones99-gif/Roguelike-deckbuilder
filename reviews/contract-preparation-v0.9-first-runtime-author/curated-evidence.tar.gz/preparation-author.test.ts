import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createGame, applyActionWithEvents, legalActions, validateState, type GameState } from './src/engine';
import { createPreparedContract, preparedDeck } from './src/preparation';

test('supplied state stays byte exact for both generations and normalization boundaries', () => {
  for (const engineKind of [1,2] as const) for (const seed of [0,1,74201,0xffffffff,-1,3.9,NaN]) for (const difficulty of [0,1,2,-1,3,NaN]) {
    assert.equal(JSON.stringify(createPreparedContract(seed,difficulty,'standard',engineKind)), JSON.stringify(createGame(seed,difficulty,{engineKind})));
  }
});
test('untrusted and legacy preparation never transforms its argument', () => {
  const existing = createGame(68002,1,{engineKind:1}), before = JSON.stringify(existing);
  for (const bad of [null,undefined,0,{},[],new String('recall'),'__proto__','constructor','toString','RECALL','']) {
    // Missing argument is deliberately the constructor default, not a submitted form choice.
    if (bad === undefined) continue;
    assert.throws(() => createPreparedContract(1,0,bad as never));
    assert.throws(() => preparedDeck(bad));
  }
  assert.throws(() => createPreparedContract(1,0,'recall',1));
  assert.throws(() => createPreparedContract(1,0,'severance',1));
  assert.equal(JSON.stringify(existing),before);
});
function conservation(s: GameState) {
  if (s.phase !== 'battle' && s.phase !== 'defeat') return;
  assert.deepEqual([...s.hand,...s.draw,...s.discard,...s.allies.map(x=>x.cardId)].sort(),s.deck.slice().sort());
}
test('each specialist survives actual legal combat and JSON reload with every card conserved', () => {
  for (const choice of ['recall','severance'] as const) {
    let state = createPreparedContract(68002,1,choice);
    assert.equal(state.deck.length,12); assert.equal(state.deck.filter(x=>x==='scour').length,1);
    assert.deepEqual(state.deck.filter(x=>x!=='killcommand' && x!=='silence'),preparedDeck('standard').filter((_,i)=>i!==5));
    assert.ok(validateState(JSON.parse(JSON.stringify(state))));
    const travel = legalActions(state).find(x=>x.type==='travel' && x.choice==='battle'); assert.ok(travel);
    state=applyActionWithEvents(state,travel).state;
    for (let i=0;i<16 && state.phase==='battle';i++) {
      conservation(state);
      const choices=legalActions(state);
      const action=choices.find(x=>x.type==='play') || choices.find(x=>x.type==='attack') || choices.find(x=>x.type==='endTurn');
      assert.ok(action);
      const original=applyActionWithEvents(state,action), reload=applyActionWithEvents(JSON.parse(JSON.stringify(state)),action);
      assert.deepEqual(original,reload); assert.ok(validateState(original.state)); conservation(original.state); state=original.state;
    }
  }
});
