from pathlib import Path
import json,hashlib,urllib.request,sys
O=Path('/workspace/scratch/bone-thrall-variable-pose-technical-independent-v09-r1');A=Path('/workspace/scratch/bone-thrall-variable-pose-author-v09-r1');H=lambda b:hashlib.sha256(b).hexdigest();b=(A/'MANIFEST.json').read_bytes();assert H(b)=='f92866d2326c4bae07830376323222a645ff7d414685e305f6e3e2929d793a14';m=json.loads(b)
for r in m['files']:
 b=(A/r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256']
rows=[]
for label,stage,port,digest,count,outputs in [('baseline',Path('/tmp/hollowpact-fallback-cards-v09-root-r1'),4630,'201d90d522c4f170cfc54d22910e718603ff2a88393ac3151ecd4ea6faf6df18',78,56),('candidate',Path('/tmp/hollowpact-bone-thrall-variable-pose-v09-author-r1'),4661,'bf950632b1fef8d9d0ec955aaaea4c431e022a5262dd09f8dff5c95d38804ee8',79,57)]:
 p=json.loads((stage/'dist/build-provenance.json').read_bytes());assert len(p['hashes'])==count and p['sourceDigest']==H(json.dumps(p['hashes'],separators=(',',':')).encode())==digest;sources={};aliases=[]
 for f,h in p['hashes'].items():
  b=(stage/f).read_bytes();assert H(b)==h;sources[f]={'bytes':len(b),'sha256':h}
  if(stage/f).is_symlink():aliases.append({'path':f,'target':str((stage/f).readlink())})
 ledger={}
 for f in sorted((stage/'dist').rglob('*')):
  if f.is_file():
   n=f.relative_to(stage/'dist').as_posix();b=f.read_bytes();assert urllib.request.urlopen(f'http://127.0.0.1:{port}/{n}',timeout=15).read()==b;ledger[n]={'bytes':len(b),'sha256':H(b)}
 assert len(ledger)==outputs;rows.append({'label':label,'stage':str(stage),'provenance':p,'sources':sources,'outputs':ledger,'rawFileAliases':aliases,'dependencyAlias':str((stage/'node_modules').readlink())})
a,b=rows;changed=[f for f in a['sources']if b['sources'][f]!=a['sources'][f]];added=sorted(set(b['sources'])-set(a['sources']));assert set(changed)=={'src/art.ts','public/art/PROVENANCE.json','THIRD-PARTY.md'};assert added==['public/art/bone-thrall-poses-v09-r2.png'];raw=Path('/workspace/generated_images/exec-2c9f5f2a-2e28-46f1-b395-fca77952bf7c.png');assert H(raw.read_bytes())==b['sources'][added[0]]['sha256']=='440bdad1f593538aeb1a5e2a44e5f611bbd8339f36146b11a069a72c4c2f93b2';pr=json.loads((Path(b['stage'])/'public/art/PROVENANCE.json').read_bytes());image=next(x for x in pr['images']if x['file']=='bone-thrall-poses-v09-r2.png');request=Path(image['exactRequest']);assert request.exists();references=[{'path':str(raw),'bytes':raw.stat().st_size,'sha256':H(raw.read_bytes())},{'path':str(request),'bytes':request.stat().st_size,'sha256':H(request.read_bytes())}];result={'authorRows':len(m['files']),'authorManifest':H((A/'MANIFEST.json').read_bytes()),'changed':changed,'added':added,'rows':rows,'imageProvenance':image,'references':references}
if sys.argv[1]=='after.json':assert result==json.load(open(O/'before.json'))
(O/sys.argv[1]).open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'authorRows':len(m['files']),'sources':[len(x['sources'])for x in rows],'outputs':[len(x['outputs'])for x in rows],'localHTTPExact':True,'actualRawRequestVerified':True}))
