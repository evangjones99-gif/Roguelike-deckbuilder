from pathlib import Path
import json,gzip,sys,math
from PIL import Image
import numpy as np
O=Path('/workspace/scratch/bone-thrall-variable-pose-technical-independent-v09-r1');raw=json.loads(gzip.decompress((O/sys.argv[1]).read_bytes()));rows=raw['rows']+([raw['current']]if raw.get('current')else[]);hulls=json.load(open(O/'OWN-SOURCE-HULLS.json'))['rows'];metrics=[];poses=set();maxover=0;maxplane=0;maxaxis=0;contacts=[]
def transform(d,p):
 sx,sy,sw,sh=d['source'];dx,dy,dw,dh=d['dest'];a,b,c,dd,e,f=d['matrix'];x=dx+(p[0]-sx)*dw/sw;y=dy+(p[1]-sy)*dh/sh;return[a*x+c*y+e,b*x+dd*y+f]
def invert(d,p):
 sx,sy,sw,sh=d['source'];dx,dy,dw,dh=d['dest'];a,b,c,dd,e,f=d['matrix'];det=a*dd-b*c;x=(dd*(p[0]-e)-c*(p[1]-f))/det;y=(-b*(p[0]-e)+a*(p[1]-f))/det;return[sx+(x-dx)*sw/dw,sy+(y-dy)*sh/dh]
for r in rows:
 if r['variant']!='candidate':continue
 rd=[]
 for d in r.get('allDraws',[]):
  if d['url']!='bone-thrall-poses-v09-r2.png':continue
  assert len(d['source'])==len(d['dest'])==4
  sx,sy,sw,sh=d['source'];h=next(h for h in hulls if abs(h['rect'][0]-sx)<1e-8 and abs(h['rect'][1]-sy)<1e-8);assert abs(sw-(h['rect'][2]-sx))<1e-8 and abs(sh-(h['rect'][3]-sy))<1e-8;pts=[transform(d,p)for p in h['hull']];xmin=min(p[0]for p in pts);xmax=max(p[0]for p in pts);ymin=min(p[1]for p in pts);ymax=max(p[1]for p in pts);over=max(0,-xmin,-ymin,xmax-d['canvas'][0],ymax-d['canvas'][1]);plane=transform(d,h['plantarPlane']);err=math.dist(plane,d['matrix'][4:]);axis=abs(d['dest'][2]/sw-d['dest'][3]/sh);maxover=max(maxover,over);maxplane=max(maxplane,err);maxaxis=max(maxaxis,axis);poses.add(h['pose']);rd.append({'pose':h['pose'],'at':d['at'],'overshoot':over,'canvas':d['canvas'],'axisDelta':axis,'rootAnchorDelta':err})
 metrics.append({'kind':r['kind'],'mode':r['mode'],'draws':len(rd),'poses':sorted(set(x['pose']for x in rd)),'maxOvershoot':max([0]+[x['overshoot']for x in rd])})
 if r['mode']=='hunter':
  step=next(x for x in r['steps']if x['label']=='first-240');ds=step['draws'];attacks=[d for d in ds if d['url']=='bone-thrall-poses-v09-r2.png'and abs(d['source'][0]-1001)<1e-8];hunter=[d for d in ds if d['url']=='hunter-marek-v07-r3.png'];samples=[]
  for d in attacks:
   tip=transform(d,[1513,209]);w,h=d['canvas'];desired=h*.36;inset=min(2,w/4,h/4);body=min(desired,(w-inset*2)*418/512,(h-inset*2)*418/(502+512-441));cell=body*512/418;floor=max(inset+cell*502/512,min(h*.935,h-inset-cell*(512-441)/512));torso=[w*.5,h*.8 if body==desired else floor-(floor-h*.8)*body/desired];pix=np.array(Image.open('/tmp/hollowpact-bone-thrall-variable-pose-v09-author-r1/public/art/hunter-marek-v07-r3.png'))
   for hd in hunter:
    q=invert(hd,tip);x,y=[round(t)for t in q];sample=pix[y,x].tolist()if 0<=x<pix.shape[1]and 0<=y<pix.shape[0]else None;samples.append({'source':q,'RGBA':sample})
   contacts.append({'kind':r['kind'],'tipWorld':tip,'nominalTorso':torso,'torsoGap':math.dist(tip,torso),'actualPaintedHunterSamples':samples,'anyOpaqueOverlap':any(s['RGBA']and s['RGBA'][3]>=128 for s in samples),'qualification':'Actual unchanged hunter source pixels at claw overlap; not exact torso-center contact or named anatomical-joint certification.'})
result={'scope':'Independent same-draw Canvas dimensions/source/transform; alpha8 convex sample hulls, not final-size aggregate or FPS proof','rows':metrics,'drawCount':sum(x['draws']for x in metrics),'poses':sorted(poses),'maxOvershoot':maxover,'maxPlantarAnchorWorldError':maxplane,'maxUnequalSourceAxisScale':maxaxis,'hunterContacts':contacts};(O/sys.argv[2]).open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['rows','hunterContacts']},indent=2))
