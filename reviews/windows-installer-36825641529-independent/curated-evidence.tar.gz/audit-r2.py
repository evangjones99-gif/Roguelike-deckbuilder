#!/usr/bin/env python3
"""Static original-evidence/source/PCM audit; never executes game or Git."""
import hashlib, json, os, pathlib, struct, urllib.parse, zipfile
ROOT=pathlib.Path('/workspace/Roguelike-deckbuilder')
BASE=ROOT/'reviews/root-v0.9-installer-36825641529-success'
STAGE=pathlib.Path('/tmp/hollowpact-event-availability-v09-root-r2')
OUT=pathlib.Path(__file__).parent
DIGEST='801db1ce4000c15268569cb047e7388148a65105c7b86208611ceb3aff40f029'
COMMIT='ede39817a5b10d0788beda6acd69a96ada8d7bc2'
ASAR='6a89d2b61562309f0d8b9974df6a3bb18008dd5626a6001e898491bbba2ce03b'
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return pathlib.Path(p).read_bytes()
def compact(v): return json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()
def guard():
 current=int(read('/sys/fs/cgroup/memory.current')); limit=int(read('/sys/fs/cgroup/memory.max'))
 assert limit-current>=640*1024*1024, '128MiB work + 512MiB reserve'
 return {'current':current,'max':limit,'headroom':limit-current}
def fileproof(p):
 p=pathlib.Path(p);s=p.stat();return {'path':str(p),'resolved':str(p.resolve()),'bytes':s.st_size,'sha256':sha(read(p)),
  'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mode':s.st_mode,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}
start=guard()
pins={str(p):fileproof(p) for p in sorted(BASE.iterdir()) if p.is_file()}
zip_path=BASE/'ORIGINAL-EVIDENCE.zip'
assert pins[str(zip_path)]['bytes']==1261794 and pins[str(zip_path)]['sha256']=='8f0c6c146d802e0a72b128c52fc5f95431b2ec7e63f3490805589eabd98933cd'
assert pins[str(BASE/'RETURNED-JOB-TEXT.txt')]['bytes']==65821 and pins[str(BASE/'RETURNED-JOB-TEXT.txt')]['sha256']=='f1391303858aca081f05bccc4a1157b049468dd394a31a876acb646a1c3a1dcb'
intake=json.loads(read(BASE/'ORIGINAL-INTAKE.json'));download=fileproof(intake['sourceDownload'])
assert (download['device'],download['inode'])==(pins[str(zip_path)]['device'],pins[str(zip_path)]['inode'])
assert download['sha256']==pins[str(zip_path)]['sha256']
members={}
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None and len(z.infolist())==11 and len(set(z.namelist()))==11
 for i in z.infolist():
  assert not i.is_dir() and not i.filename.startswith('/') and '..' not in pathlib.PurePosixPath(i.filename).parts
  b=z.read(i.filename);members[i.filename]={'bytes':len(b),'sha256':sha(b),'crc32':i.CRC}
 def member(suffix):
  names=[n for n in z.namelist() if n.endswith(suffix)];assert len(names)==1
  return z.read(names[0])
 smoke=json.loads(member('/installer-smoke.json'));request=json.loads(member('build-installer/request.json'))
 assert smoke['status']=='passed' and smoke['errors']==[] and len(smoke['steps'])==8
 assert smoke['request']==request and request['commit']==COMMIT and request['sourceDigest']==DIGEST
 assert str(request['runId'])=='36825641529' and str(request['attempt'])=='1'
 assert smoke['signature']=='NotSigned' and smoke['asarSHA256']==ASAR
 ledger=json.loads(read(ROOT/'scripts/windows-installer-asar-payload.json'))
 assert ledger['sourceDigest']==DIGEST and ledger['asarSHA256']==ASAR
 assert (ledger['sourceInputCount'],ledger['distOutputCount'],ledger['leafCount'])==(78,56,60)
 assert smoke['stagedAsarPayload']==smoke['installedAsarPayload']
 payload=smoke['installedAsarPayload']
 for key,expected in [('sourceDigest',DIGEST),('sourceInputs',78),('distOutputs',56),('leafCount',60),('asarSHA256',ASAR),('asarBytes',33063240),('headerStringSHA256',ledger['rawHeaderStringSHA256']),('normalizedManifestSHA256',ledger['normalizedManifest']['sha256']),('leaves',ledger['leaves'])]:
  assert payload[key]==expected,key
 source={k:sha(read(STAGE/k)) for k in ledger['sourceHashes']}
 assert source==ledger['sourceHashes'] and sha(compact(source))==DIGEST
 closed=set()
 for directory in ['src','desktop','public']:
  closed.update(str(p.relative_to(STAGE)) for p in (STAGE/directory).rglob('*') if p.is_file())
 closed.update(k for k in source if not k.startswith(('src/','desktop/','public/')))
 assert closed==set(source)
 source_rows=[fileproof(STAGE/k) for k in source]
 dist={str(p.relative_to(STAGE)):fileproof(p) for p in (STAGE/'dist').rglob('*') if p.is_file()}
 assert len(dist)==56 and set(dist)=={l['path'] for l in ledger['leaves'] if l['path'].startswith('dist/')}
 for leaf in ledger['leaves']:
  assert leaf['integrity']['algorithm']=='SHA256' and leaf['integrity']['hash']==leaf['sha256']
  if leaf['path']=='package.json':b=json.dumps(ledger['normalizedManifest']['json'],ensure_ascii=False,indent=2).encode()
  else:b=read(STAGE/leaf['path'])
  assert len(b)==leaf['bytes'] and sha(b)==leaf['sha256'],leaf['path']
  assert [sha(b[o:o+4194304]) for o in range(0,len(b),4194304)]==leaf['integrity']['blocks']
 provenance=member('dist/build-provenance.json');assert provenance==read(STAGE/'dist/build-provenance.json')
 sounds=smoke['packagedAssets']['sounds'];records=smoke['nativeSoundDecode']['records']
 assert len(sounds)==len(records)==39 and len({r['name'] for r in records})==39
 def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
 positive=f32(1/32767);negative=f32(1/32768);sound_rows=[]
 for s,r in zip(sounds,records):
  guard();b=read(STAGE/s['source']);assert sha(b)==s['sha256']==r['rawSHA256']==source[s['source']]
  assert r['name']==s['name'] and len(b)==s['bytes']==r['bytes']
  u=urllib.parse.urlsplit(r['url']);assert u.scheme=='file' and not u.netloc and u.path.endswith('/resources/app.asar/dist/audio/'+s['name'])
  assert b[:4]==b'RIFF' and b[8:12]==b'WAVE' and b[12:16]==b'fmt ' and b[36:40]==b'data'
  assert struct.unpack_from('<IHHIIHH',b,16)==(16,1,2,48000,192000,4,16)
  assert len(b)==44+struct.unpack_from('<I',b,40)[0] and (len(b)-44)%4==0
  frames=(len(b)-44)//4;pcm=bytearray();peak=0.;square=0.
  for c in range(2):
   for f in range(frames):
    v=struct.unpack_from('<h',b,44+(f*2+c)*2)[0];x=f32(v*(negative if v<0 else positive))
    pcm.extend(struct.pack('<f',x));peak=max(peak,abs(x));square+=x*x
  expected=s['decodedPCM'];assert sha(pcm)==expected['sha256']==r['pcmSHA256'] and len(pcm)==expected['bytes']==r['pcmBytes']
  assert r['frames']==s['frames']==frames and r['channels']==2 and r['sampleRate']==48000
  for k,v in [('duration',frames/48000),('peak',peak),('meanSquare',square/(frames*2))]:assert abs(r[k]-v)<=1e-10
  sound_rows.append({'name':s['name'],'rawSHA256':sha(b),'pcmSHA256':sha(pcm),'frames':frames,'source':s['source'],'nativeURL':r['url']})
 assert 0<=smoke['nativeSoundDecode']['elapsedMs']<=100000
 saves={}
 for suffix,witness in [('saved-seed121-campaign.json',smoke['canonical']),('saved-campaign.json',smoke['cryptCanonical'])]:
  b=member('/'+suffix);assert b.endswith(b'\n') and sha(b[:-1])==witness['saveSHA256'] and witness['exactState'] is True
  state=json.loads(b);assert state['seed']==witness['seed'] and state['schema']==2
  saves[suffix]={'memberSHA256':sha(b),'canonicalStringSHA256':sha(b[:-1]),'seed':state['seed'],'phase':state['phase'],'floor':state['floor']}
 trace=smoke['cryptCanonical']['rows'];assert len(trace)==14 and smoke['cryptCanonical']['earnedOnlyViaUI'] is True
 assert all(trace[i]['afterSHA256']==trace[i+1]['beforeSHA256'] for i in range(13))
 feedback=json.loads(member('/synthetic-negative-feedback.json'))
 assert feedback['context']['build']['sourceDigest']==DIGEST and feedback['responses']['replayIntent']=='no'
 assert feedback['responses']['confusion'].startswith('[AUTOMATED INSTALLER QA — not human feedback]')
 manifest=json.loads(member('build-installer/installer-transfer/manifest.json'))
 assert manifest['commit']==COMMIT and manifest['sourceDigest']==DIGEST and manifest['nativeQAStatus']=='passed'
 assert manifest['sha256']==smoke['installerSHA256'] and manifest['bytes']==128286624 and len(manifest['parts'])==6
 assert sum(p['bytes'] for p in manifest['parts'])==manifest['bytes']
 config=json.loads(member('build-installer/qa-config.json'))
 assert sha(member('build-installer/qa-config.json'))==request['configSHA256'] and sha(member('build-installer/qa-only.nsh'))==request['includeSHA256']
 for k in ['perMachine','allowElevation','packElevateHelper','runAfterFinish','deleteAppDataOnUninstall','createDesktopShortcut','createStartMenuShortcut','differentialPackage']:assert config['nsis'][k] is False
 assert config['nsis']['oneClick'] is True and config['publish'] is None and config['forceCodeSigning'] is False
 assert smoke['defaultCacheBefore']==smoke['defaultCacheAfterUninstall']=={'exists':False}
 assert smoke['generatorBefore']=={'exists':True,'entries':[]}
 assert smoke['ownedInstallerCache']['sha256']==manifest['sha256']
 assert smoke['install']['exitCode']==smoke['uninstall']['exitCode']==0
 for k in ['completeUniqueDirectoryRemoved','profilePreserved','sentinelPreserved']:assert smoke['uninstall'][k] is True
 assert len(smoke['stagedFiles'])==72 and len(smoke['installedFiles'])==73
 assert all(smoke['installedFiles'][k]==v for k,v in smoke['stagedFiles'].items())
 extra=set(smoke['installedFiles'])-set(smoke['stagedFiles']);assert len(extra)==1 and next(iter(extra)).startswith('Uninstall ')
 for rows in [smoke['registryBefore'],smoke['registryUninstalled']]:assert len(rows)==4 and all(not r['install'] and not r['uninstall'] for r in rows)
 assert len(smoke['registryInstalled'])==4
 for r in smoke['registryInstalled']:assert r['install']==r['uninstall']==(r['hive']=='CurrentUser')
 assert len(smoke['launches'])==2 and all(l['sandbox'] and l['contextIsolation'] and not l['nodeIntegration'] for l in smoke['launches'])
 captures=[]
 for n in ['installed-earned-crypt.png','installed-resumed.png']:
  b=member('/'+n);assert struct.unpack('>II',b[16:24])==(1008,689)
  temp=pathlib.Path('/dev/shm/hollowpact-windows-evidence-native-independent-r1')/n
  assert read(temp)==b
  captures.append({'member':n,'bytes':len(b),'sha256':sha(b),'width':1008,'height':689,'viewedOriginal':True,'temporaryPath':str(temp)})
jobs=json.loads(read(BASE/'JOBS-API.json'))['jobs'];assert len(jobs)==1
job=jobs[0];assert job['id']==110250601974 and job['run_id']==36825641529 and job['status']=='completed' and job['conclusion']=='success'
assert all(s['conclusion']=='success' for s in job['steps'] if s['number'] not in [17,18])
assert all(s['conclusion']=='skipped' for s in job['steps'] if s['number'] in [17,18])
artifacts=json.loads(read(BASE/'ARTIFACTS-API.json'))['artifacts'];assert len(artifacts)==7
for a in artifacts:assert not a['expired'] and a['workflow_run']['head_sha']==COMMIT and a['workflow_run']['id']==36825641529
run=json.loads(json.loads(read(BASE/'RUNS-API.json'))['content']);assert run['head_sha']==COMMIT
log=read(BASE/'RETURNED-JOB-TEXT.txt').decode()
assert COMMIT in log and DIGEST in log and 'passed; evidence ' in log and 'Retained exact original installer in 6 bounded parts; native status passed.' in log
assert 'Microsoft Windows Server 2022' in log
repair={'scripts/windows-installer-asar-validation.mjs':'716d5c1b763c8d34ea04f504eeb02472290993ea469471d7e7298f1766dd9ca4','scripts/windows-installer-asar-validation.test.mjs':'2ee456b0a7b7f3c0a031a574ae96c76299f18ceef8ac7757719bc48ec6bd746a','scripts/windows-installer-smoke.mjs':'19689fb40d41426c2dfa29e3da3e70df4c4865ed0835e4bb254d644fa1cb74a8'}
assert all(sha(read(ROOT/k))==v for k,v in repair.items())
prior=json.loads(read(ROOT/'reviews/root-v0.9-installer-36819597195-failure/installer-smoke.json'))
assert prior['status']=='failed' and prior['steps']==[] and prior['phase']=='preflight'
assert 'dist/art/PROVENANCE.json' in str(prior)
after={str(p):fileproof(p) for p in sorted(BASE.iterdir()) if p.is_file()};assert pins==after
assert all(fileproof(STAGE/pathlib.Path(r['path']).relative_to(STAGE))==r for r in source_rows)
assert all(fileproof(STAGE/k)==v for k,v in dist.items())
result={'status':'PASS: scoped original hosted Windows evidence intake; no local runtime','guardBefore':start,'guardAfter':guard(),
 'originalFiles':pins,'qualifiedOriginalDownloadHardlink':download,'zipMembers':members,'sourceDigest':DIGEST,'sourceInputCount':78,'distOutputCount':56,
 'sourceRows':source_rows,'distRows':list(dist.values()),'payloadWitness':payload,'sourceRepairHashes':repair,'sounds':sound_rows,'saves':saves,
 'cryptTraceRows':trace,'nativeCaptures':captures,'job':{'id':job['id'],'status':job['status'],'conclusion':job['conclusion'],'steps':job['steps']},
 'runSnapshot':{'status':run['status'],'conclusion':run['conclusion'],'head_sha':run['head_sha']},'remoteOnlyArtifacts':artifacts,
 'originalTransferManifest':manifest,'priorFailure':{'status':prior['status'],'phase':prior['phase'],'steps':prior['steps']},
 'scope':'Actual hosted-run assertions/receipts corroborated against original ZIP, current repair files and independently hashed frozen801db source. No installer binary reconstruction, no reviewer native rerun, no game/Node execution or Git writes.'}
with (OUT/'STATIC-AUDIT.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'status':result['status'],'source':78,'outputs':56,'payloadLeaves':60,'sounds':39,'screenshots':2,'originalMembers':11,'durableResultBytes':(OUT/'STATIC-AUDIT.json').stat().st_size}))
