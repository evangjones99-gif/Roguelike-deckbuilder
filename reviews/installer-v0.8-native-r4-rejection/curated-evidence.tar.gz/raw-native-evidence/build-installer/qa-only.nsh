; QA ONLY: exact run identity, no process kills, no app-data removal.
!macro customHeader
  !undef KF_FLAG_CREATE
  !define KF_FLAG_CREATE 0
  !ifdef BUILD_UNINSTALLER
    InstallDir "C:\Users\runneradmin\AppData\Local\HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\uninstaller-generator"
  !else
    InstallDir "C:\Users\runneradmin\AppData\Local\HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\installation"
  !endif
  !ifdef APP_INSTALLER_STORE_FILE
    !undef APP_INSTALLER_STORE_FILE
  !endif
  !define APP_INSTALLER_STORE_FILE "HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\installer-cache\installer.exe"
!macroend
!macro customCheckAppRunning
  nsProcess::_FindProcess /NOUNLOAD "${APP_EXECUTABLE_FILENAME}"
  Pop $0
  IntCmp $0 603 +3
    SetErrorLevel 86
    Quit
!macroend
!macro customInit
  IfSilent +3
    SetErrorLevel 81
    Quit
  StrCmp $installMode "CurrentUser" +3
    SetErrorLevel 82
    Quit
  StrCmp $INSTDIR "C:\Users\runneradmin\AppData\Local\HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\installation" +3
    SetErrorLevel 83
    Quit
  System::Call 'kernel32::GetFileAttributesW(w "$INSTDIR") i .r0'
  IntCmp $0 -1 attrsDone
  IntOp $0 $0 & 0x400
  IntCmp $0 0 attrsDone
    SetErrorLevel 84
    Quit
  attrsDone:
  ClearErrors
  FileOpen $0 "C:\Users\runneradmin\AppData\Local\HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\owner-token.txt" r
  IfErrors badOwner
  FileRead $0 $1
  FileClose $0
  StrCmp $1 "7c7d1b14e4e7cc0517880758b194384d$\n" goodOwner
  badOwner:
    SetErrorLevel 85
    Quit
  goodOwner:
  ReadRegStr $0 HKCU "${INSTALL_REGISTRY_KEY}" InstallLocation
  StrCmp $0 "" +3
    SetErrorLevel 87
    Quit
  ReadRegStr $0 HKLM "${INSTALL_REGISTRY_KEY}" InstallLocation
  StrCmp $0 "" +3
    SetErrorLevel 88
    Quit
  FindFirst $0 $1 "$INSTDIR\*.*"
  checkEmpty:
    StrCmp $1 "" emptyDone
    StrCmp $1 "." emptyNext
    StrCmp $1 ".." emptyNext
    FindClose $0
    SetErrorLevel 89
    Quit
  emptyNext:
    FindNext $0 $1
    Goto checkEmpty
  emptyDone:
    FindClose $0
!macroend
!macro customUnInit
  IfSilent +3
    SetErrorLevel 81
    Quit
  StrCmp $installMode "CurrentUser" +3
    SetErrorLevel 82
    Quit
  StrCmp $INSTDIR "C:\Users\runneradmin\AppData\Local\HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\installation" +3
    SetErrorLevel 83
    Quit
  System::Call 'kernel32::GetFileAttributesW(w "$INSTDIR") i .r0'
  IntCmp $0 -1 attrsDone
  IntOp $0 $0 & 0x400
  IntCmp $0 0 attrsDone
    SetErrorLevel 84
    Quit
  attrsDone:
  ClearErrors
  FileOpen $0 "C:\Users\runneradmin\AppData\Local\HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\owner-token.txt" r
  IfErrors badOwner
  FileRead $0 $1
  FileClose $0
  StrCmp $1 "7c7d1b14e4e7cc0517880758b194384d$\n" goodOwner
  badOwner:
    SetErrorLevel 85
    Quit
  goodOwner:
!macroend
!macro customRemoveFiles
  StrCmp $INSTDIR "C:\Users\runneradmin\AppData\Local\HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\installation" +3
    SetErrorLevel 90
    Quit
  SetOutPath $TEMP
  RMDir /r "C:\Users\runneradmin\AppData\Local\HollowpactInstallerQA\7c7d1b14e4e7cc0517880758b194384d\installation"
!macroend
