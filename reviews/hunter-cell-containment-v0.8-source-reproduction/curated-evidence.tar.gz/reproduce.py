"""Assemble a new fully regular runtime source copy; never mutate frozen inputs."""
from pathlib import Path
import argparse, hashlib, json, shutil

parser=argparse.ArgumentParser()
parser.add_argument('--variant',choices=['baseline','candidate'],required=True)
parser.add_argument('--dest',required=True)
args=parser.parse_args()
author=Path('/workspace/scratch/hunter-cell-containment-author-v08-r1')
media=Path('/workspace/Roguelike-deckbuilder')
dest=Path(args.dest)
if not dest.is_absolute() or dest.parent.resolve()!=Path('/tmp'):
    raise SystemExit('Destination must be a new direct child of /tmp')
if dest.exists() or dest.is_symlink():
    raise SystemExit('Refusing existing destination')
provenance=json.loads((author/(args.variant+'-build-provenance.json')).read_text())
pins={}
for relative,expected in provenance['hashes'].items():
    # Text/JSON/code are copied from the frozen author snapshot. Original PNG
    # media are referenced explicitly from retained project inputs and verified.
    source=(media if relative.endswith('.png') else author/args.variant)/relative
    raw=source.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected:
        raise SystemExit('Input identity mismatch: '+relative)
    pins[relative]=(raw,str(source))
dest.mkdir(exist_ok=False)
for relative,(raw,source) in pins.items():
    target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle:handle.write(raw)
(dest/'node_modules').symlink_to(media/'node_modules',target_is_directory=True)
hashes={relative:hashlib.sha256((dest/relative).read_bytes()).hexdigest() for relative in sorted(pins)}
digest=hashlib.sha256(json.dumps(hashes,separators=(',',':')).encode()).hexdigest()
if digest!=provenance['sourceDigest']:
    raise SystemExit('Complete source digest mismatch')
receipt={'variant':args.variant,'completeRegularRuntimeFiles':len(hashes),
    'sourceDigest':digest,'sourceWorkspace':str(dest),'externalDependencies':str(media/'node_modules'),
    'mediaRequirement':'Retained original PNG/icon bytes are required and checked by the frozen expected hashes. No mutable live root code/config/PROVENANCE is read.',
    'inputSources':{relative:source for relative,(_,source) in pins.items()}}
print(json.dumps(receipt,indent=2))
