from pathlib import Path
import hashlib,json,difflib
A=Path('/workspace/scratch/installer-v08-current-author-r1');R=Path('/workspace/Roguelike-deckbuilder');O=Path('/workspace/scratch/installer-v08-current-independent-source-r1');H=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((A/'MANIFEST.json').read_text());records={r['path']:r for r in m['files']};assert len(records)==36
for p,r in records.items():b=(A/p).read_bytes();assert len(b)==r['bytes'] and H(b)==r['sha256'],p
baseline=[p.relative_to(A/'baseline').as_posix() for p in sorted((A/'baseline').rglob('*')) if p.is_file()];unchanged=[];changed=[];added=[];root={}
for p in baseline:
 b=(A/'baseline'/p).read_bytes();q=(A/'proposed'/p).read_bytes();assert (R/p).read_bytes()==b,(p,'root baseline drift');root[p]=H(b)
 (unchanged if b==q else changed).append(p)
for p in sorted((A/'proposed').rglob('*')):
 if p.is_file() and 'node_modules' not in p.parts and p.relative_to(A/'proposed').as_posix() not in baseline:added.append(p.relative_to(A/'proposed').as_posix())
assert changed==['.github/workflows/windows-installer-validation.yml','scripts/windows-installer-guards.mjs','scripts/windows-installer-prepare.mjs','scripts/windows-installer-smoke.mjs'];assert added==['scripts/windows-installer-current-validation.mjs','scripts/windows-installer-current-validation.test.mjs']
old=(A/'baseline/scripts/windows-installer-guards.mjs').read_text();new=(A/'proposed/scripts/windows-installer-guards.mjs').read_text();assert old[old.index('export const hash'):]==new[new.index('export const hash'):]
old=(A/'baseline/scripts/windows-installer-smoke.mjs').read_text();new=(A/'proposed/scripts/windows-installer-smoke.mjs').read_text()
for start,end in [('async function native(operation,file)','const readSave='),('  const profileBefore=await snapshot(v.profile)',None)]:
 a=old[old.index(start):old.index(end) if end else None];b=new[new.index(start):new.index(end) if end else None];assert a==b,(start,'guard/native body drift')
(O/'source-boundary.json').write_text(json.dumps({'authorManifestSHA256':H((A/'MANIFEST.json').read_bytes()),'filesVerified':36,'unchanged':unchanged,'changed':changed,'added':added,'rootBaselineUnchanged':root,'guardFunctionsAfterConstantsExact':True,'nativeLaunchBodiesExact':True,'fullUninstallCatchFinallyExact':True,'prospectiveVersion':'0.8.0','prospectiveRuntime':'23477f68c99d6d60b0b3f82b286a8d33bb6da6f2ca92c103fbecf5663634959f','prospectiveAsar':'c383c4437ac5467146174c6ea039b2a8b28af43d609701379e8cf695f59d530c'},indent=2)+'\n');print({'files':36,'changed':changed,'new':added,'rootBaselineFiles':len(root)})
