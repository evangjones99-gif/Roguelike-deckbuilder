import json, hashlib, zipfile, shutil, subprocess
from pathlib import Path
from datetime import datetime, timezone
D=Path(__file__).parent
R=Path('/workspace/Roguelike-deckbuilder')
A=R/'reviews/milestone-storage-v0.6.1-actual/run-36797748556-1'
H=lambda b: hashlib.sha256(b).hexdigest()
def response(name):
 j=json.loads((D/(name+'-response.json')).read_text())
 if 'received' in j: j=j['received']
 assert not j.get('isError',False)
 return j['structuredContent']
def api(name): return json.loads(response(name)['content'])
def raw(name): return response(name)['content'].encode()
for filename in ['report.json','milestone-preservation-v0.6.1-36797748556-1.zip','release-api-snapshot.json','root-snapshot-r1-error.txt']:
 shutil.copyfile(A/filename,D/('root-'+filename))
reportBytes=(D/'root-report.json').read_bytes(); report=json.loads(reportBytes)
wrapper=(D/'root-milestone-preservation-v0.6.1-36797748556-1.zip').read_bytes()
artifact=response('diagnostic-artifacts')['artifacts']
assert len(artifact)==1
artifact=artifact[0]
assert artifact['id']==11134083866 and artifact['size_in_bytes']==850 and artifact['expired'] is False
assert len(wrapper)==850 and artifact['digest']=='sha256:'+H(wrapper)
with zipfile.ZipFile(D/'root-milestone-preservation-v0.6.1-36797748556-1.zip') as z:
 assert z.namelist()==['report.json']
 assert z.read('report.json')==reportBytes
run=api('run'); release=api('release'); ref=api('tag-ref'); tag=api('tag-object')
assert run['id']==36797748556 and run['head_sha']=='bdf27374358eb176e62f832cb50261cb3334d8df'
assert run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
assert run['event']=='push' and run['head_branch']=='codex/lanternbound-production' and run['path']=='.github/workflows/preserve-v061.yml'
assert ref['object']=={'sha':'cb1c3964d4865ae729807fcb3208b6d856bd25fc','type':'tag','url':ref['object']['url']}
assert tag['tag']=='v0.6.1' and tag['object']['type']=='commit' and tag['object']['sha']=='83d75e30a90db65db743a4522288607cf45682b1'
workflow=raw('workflow')
assert H(workflow)=='a9641339213d6a42808df1d1504ed49f1eda3d9e18f8e2bbfb8ec735d759aa9d'
assert workflow==(R/'.github/workflows/preserve-v061.yml').read_bytes()
assert workflow==Path('/workspace/scratch/milestone-storage-v061-proposal-r4/preserve-v061.yml').read_bytes()
manifestData=raw('manifest'); sumsData=raw('sums'); manifest=json.loads(manifestData)
assert H(manifestData)==report['manifestSHA']=='6999e88dfc4b19626e50734571e997c9fd19b1a5c2e4ce9439159343160fd500'
assert H(sumsData)=='66ea71f543eb0c2bd29bcb80538b41db22eb21c655c28dafaf18aa54fc5542c1'
assert sumsData==''.join(f'{digest}  {name}\n' for name,digest in manifest['artifacts'].items()).encode()
assert len(manifest['artifacts'])==6 and manifest['steamPublished'] is False
native=api('native-run')
assert native['id']==36791619534 and native['conclusion']=='success' and native['status']=='completed' and native['run_attempt']==1
assert native['head_sha']==manifest['nativeWindows']['headSourceCheckpoint']=='9e6e7d7e76a2ce606acae24d2f6a27c903b54a5f'
assert native['path']=='.github/workflows/windows-validation.yml' and native['head_branch']=='codex/lanternbound-production'
nativeArtifacts={a['id']:a for a in response('native-artifacts')['artifacts']}
for ident,size,sha in [(11132128179,192975515,'ee181194451f10e601742fa4a570303e7ed6e66c79a2a7c58555bb2feb91b8d4'),(11131988966,9545515,'1741107cb452d08eb9c2f33a02f8ff1c64076776892b512cd075747adff6f047')]:
 a=nativeArtifacts[ident]
 assert a['size_in_bytes']==size and a['digest']=='sha256:'+sha and a['expired'] is False
 assert a['workflow_run']['id']==36791619534 and a['workflow_run']['head_sha']==native['head_sha']
assert report['status']=='passed-draft-partial-preservation' and report['coverage']=='partial-native-windows-and-original-evidence'
assert report['tagObject']==ref['object']['sha'] and report['tagCommit']==tag['object']['sha'] and report['nativeRun']==36791619534
assert release['id']==report['releaseId']==400547880 and release['draft'] is True and release['prerelease'] is True and release['tag_name']==report['tag']=='v0.6.1'
assert release['published_at'] is None and 'Partial binary coverage:' in release['body'] and 'No Steam publication.' in release['body']
assert report['releaseURL']==release['html_url']
assets={a['name']:a for a in release['assets']}
assert len(assets)==len(release['assets'])==len(report['assets'])==5
nativeName='hollowpact-0.6.1-windows-native-x64.zip'; evidenceName='hollowpact-0.6.1-native-evidence-36791619534-1.zip'
missing=[n for n in manifest['artifacts'] if n not in [nativeName,evidenceName]]
coverage={'version':'0.6.1','tag':'v0.6.1','manifestSHA':report['manifestSHA'],'runtimeSourceDigest':manifest['runtimeSourceDigest'],'nativeRun':36791619534,'preservedArchiveNames':[nativeName,evidenceName],'notUploadedArchiveNames':missing,'reason':'These exact native artifacts are available from the successful Windows run. Linux/source/web/repacked Windows bytes remain in the workspace; this workflow does not recreate or invent them.','draft':True,'developmentOnly':True,'commercialQualityAccepted':False,'steamPublished':False}
coverageBytes=(json.dumps(coverage,indent=2)+'\n').encode()
assert len(coverageBytes)==884 and H(coverageBytes)=='53c5043cf2c3443a3eebb684130f6da55695f7dafe1f0253cf293c88b37fbf4e'
expectedHashes={**manifest['artifacts'],'manifest.json':H(manifestData),'SHA256SUMS':H(sumsData),'preservation-coverage.json':H(coverageBytes)}
expectedIds={nativeName:602099580,evidenceName:602099837,'manifest.json':602099865,'SHA256SUMS':602099879,'preservation-coverage.json':602099901}
expectedSizes={nativeName:183597187,evidenceName:9545515,'manifest.json':2754,'SHA256SUMS':607,'preservation-coverage.json':884}
for a in report['assets']:
 live=assets[a['name']]
 assert a['assetId']==live['id']==expectedIds[a['name']]
 assert a['bytes']==live['size']==expectedSizes[a['name']] and live['state']=='uploaded'
 assert a['sha256']==expectedHashes[a['name']] and live['digest']=='sha256:'+a['sha256'] and a['readBackVerified'] is True
assert not any(n in assets for n in missing)
jobs=response('storage-jobs')['jobs']
assert len(jobs)==1 and jobs[0]['conclusion']=='success' and all(s['conclusion']=='success' for s in jobs[0]['steps'])
for name,blob in [('approved-workflow.yml',workflow),('pinned-manifest.json',manifestData),('pinned-SHA256SUMS',sumsData),('reconstructed-coverage.json',coverageBytes)]: (D/name).write_bytes(blob)
old=Path('/workspace/scratch/milestone-storage-v061-independent')
for src,dst in [(old/'REVIEW-R3.md','retained-R3-review.md'),(old/'upload-name-witness/mock-results/wrong-upload-name-accepted-witness.json','retained-R3-wrong-name-witness.json'),Path('/workspace/scratch/milestone-storage-v061-proposal-r3/preserve-v061.yml') and (Path('/workspace/scratch/milestone-storage-v061-proposal-r3/preserve-v061.yml'),'retained-R3-workflow.yml')]: shutil.copyfile(src,D/dst)
assert H((D/'retained-R3-workflow.yml').read_bytes())=='70a5bb168df51a5c3b2caa532af89bdce0911e6f21aa26259c2759e5457776ba'
out={'verifiedAtUTC':datetime.now(timezone.utc).isoformat(),'verdict':'accepted-actual-partial-draft-storage','run':run['id'],'head':run['head_sha'],'workflowSHA256':H(workflow),'diagnosticArtifact':{'id':artifact['id'],'bytes':len(wrapper),'sha256':H(wrapper),'reportSHA256':H(reportBytes),'ZIPmemberMatchesRawReport':True},'release':{'id':release['id'],'draft':release['draft'],'prerelease':release['prerelease'],'published_at':release['published_at'],'assets':report['assets']},'missingArchives':missing,'coverageVerification':'reconstructed from exact approved source + pinned manifest; hash/size match live asset digest and workflow readback report; no independent remote coverage-body fetch','independentNetworkScope':'GET-only connector metadata and exact small pinned source files; no release binary downloads/uploads; full asset readbacks performed by successful approved workflow','storageJobId':jobs[0]['id'],'limits':'Not full mirror/immutable backup/public release/platform gameplay/AAA/fun/Steam proof; live draft state may later change.'}
(D/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'verdict':out['verdict'],'assetCount':len(assets),'verifiedAtUTC':out['verifiedAtUTC'],'job':jobs[0]['id'],'reportSHA256':H(reportBytes)}))
