#!/usr/bin/env python3
"""Prospective read-only source-retirement coverage audit. Never unlinks inputs."""
import base64, binascii, gzip, hashlib, io, json, os, pathlib, stat, struct
import subprocess, sys, time, traceback, unicodedata, zipfile

ROOT=pathlib.Path('/workspace/Roguelike-deckbuilder')
OLD=ROOT/'releases/0.6.0/hollowpact-0.6.0-source.zip'
BUNDLE=ROOT/'releases/0.8.0/hollowpact-0.8.0-source.bundle'
OLD_COMMIT='26286ec6acb7d95ad28446962349fdf4d5cfa702'
NEW_COMMIT='58efb01f4815d8b542711582b87f50168dabde81'
OLD_SHA='076fc29bccc706b85666c2e2b7a4e4d620a93784dcd84f6931d7ced50c4c722c'
BUNDLE_SHA='fd1310a36be0931bb81537004f87ef751481ca0daa349e58f1576a3c34640b3d'
CLOSURE=pathlib.Path('/workspace/scratch/release-v08-final-independent-r1/REACHABLE-OBJECTS.json.gz')
CLOSURE_SHA='174494893e3e1e605fe9a965bfb117d3cf0c971703d8db3d4080b0b8daa3aac0'
RESTORE_RESULT=pathlib.Path('/workspace/scratch/release-v08-final-independent-r1/RESTORE-RESULT.json')
RESTORE_SHA='a334dbc8828bf29b4fff892ea176db4f62a4f01d09298f34784cb930c4d83f2f'
MIB=1048576
WORK=64*MIB
RESERVE=512*MIB
PROOF_LIMIT=2*MIB
MAX_CENTRAL=16*MIB
MAX_ENTRIES=20000
MAX_INFLATED=32*1024*MIB
CHUNK=256*1024
HERE=pathlib.Path(__file__).resolve().parent
samples=[]
commands=[]
phase='initial-admission'
output=None
before=None
watch=[]
entry_rows=0
last_sample=0

def digest(b):return hashlib.sha256(b).hexdigest()
def meta(p):
    p=pathlib.Path(p);s=p.lstat()
    assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),f'Only existing regular input:{p}'
    attrs={n:base64.b64encode(os.getxattr(p,n,follow_symlinks=False)).decode() for n in os.listxattr(p,follow_symlinks=False)}
    return {'path':str(p),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,
            'bytes':s.st_size,'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'xattrs':attrs}
def no_links(p):
    p=pathlib.Path(p)
    for q in [p,*p.parents]:assert not q.is_symlink(),f'No original path-component aliases:{q}'
def opened(p):
    no_links(p)
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    s=os.fstat(fd);assert stat.S_ISREG(s.st_mode)
    return os.fdopen(fd,'rb')
def guarded(label,force=True):
    global last_sample
    now=time.monotonic()
    if not force and now-last_sample<0.1:return
    c=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());m=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
    v=os.statvfs(HERE);r={'label':label,'time':now,'memoryCurrent':c,'memoryMax':m,'headroom':m-c,
                       'durableFree':v.f_bavail*v.f_frsize,'events':pathlib.Path('/sys/fs/cgroup/memory.events').read_text()}
    if len(samples)<128:samples.append(r)
    else:samples[-1]=r
    last_sample=now
    assert m-c>=WORK+RESERVE,'Require fresh64MiB work +512MiB reserve; no lowering/advice'
    assert r['durableFree']>=PROOF_LIMIT+MIB,'Require2MiB proof budget +1MiB durable reserve'
def write(name,value):
    assert output
    b=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    assert len(b)<=MIB
    allocated=sum(p.stat().st_size for p in output.iterdir() if p.is_file())
    assert allocated+len(b)<=PROOF_LIMIT,'Bound all own receipts before allocation'
    with (output/name).open('xb') as f:f.write(b)
def small(p,maximum=MIB):
    with opened(p) as f:
        b=f.read(maximum+1);assert len(b)<=maximum
        return b
def stream_hash(p):
    h=hashlib.sha256();total=0
    with opened(p) as f:
        while b:=f.read(CHUNK):
            h.update(b);total+=len(b)
            guarded('stream:'+p.name,False)
    return {'bytes':total,'sha256':h.hexdigest()}
def git(args,max_output=4*MIB,expected=(0,)):
    # Metadata/ancestry only; no blob bodies or object/ref mutations. No shell.
    guarded('before-Git-metadata')
    env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1')
    with subprocess.Popen(['git','--no-replace-objects','-c','core.fsmonitor=false',*args],cwd=ROOT,env=env,
                          stdout=subprocess.PIPE,stderr=subprocess.PIPE) as child:
        try:
            stdout,stderr=child.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            child.kill();stdout,stderr=child.communicate()
            commands.append({'args':args,'timeout':True,'stderr':stderr.decode(errors='replace')[:8192]})
            raise RuntimeError('Only owned metadata child timed out; no other process killed')
    assert len(stdout)<=max_output and len(stderr)<=65536,'Bound Git metadata output'
    commands.append({'args':args,'returncode':child.returncode,'stdoutBytes':len(stdout),'stdoutSHA256':digest(stdout),
                     'stderr':stderr.decode(errors='replace')})
    assert child.returncode in expected,commands[-1]
    guarded('after-Git-metadata')
    return stdout
def safe_name(name,is_dir=False):
    assert isinstance(name,str) and name and not name.startswith('/') and '\\' not in name and ':' not in name
    assert not any(ord(c)<32 for c in name),'Control-name layout unsupported; preserve, do not retire'
    if is_dir:
        assert name.endswith('/');name=name[:-1]
    else:assert not name.endswith('/')
    assert all(p and p not in ['.','..'] for p in name.split('/'))
    return name
def zip_admission(f):
    f.seek(0,2);size=f.tell();f.seek(max(0,size-65557));tail=f.read(65557)
    # Reject unsupported layouts, rather than treating them as corrupt material.
    pos=tail.rfind(b'PK\x05\x06');assert pos>=0,'No admitted legacy ZIP EOCD found'
    fields=struct.unpack_from('<4s4H2IH',tail,pos)
    _,disk,start_disk,disk_count,count,central_size,central_offset,comment_size=fields
    assert disk==start_disk==0 and disk_count==count
    assert count!=65535 and central_size!=0xffffffff and central_offset!=0xffffffff,'ZIP64 requires separate reviewed parser'
    assert count<=MAX_ENTRIES and central_size<=MAX_CENTRAL
    assert pos+22+comment_size==len(tail),'Admit closed EOCD/comment/EOF only'
    assert central_offset+central_size==size-len(tail)+pos,'Closed central-directory coverage'
    return {'entries':count,'centralBytes':central_size,'centralOffset':central_offset,'comment':tail[pos+22:].decode('ascii')}

try:
    assert sys.argv[1:]==['--approved-read-only-coverage-window'],'Explicit reviewed read-only serial window required'
    guarded('initial')
    output=pathlib.Path(__import__('tempfile').mkdtemp(prefix='executed-r1-',dir=HERE))
    phase='original-proof-input-freeze'
    pins=json.loads(small(HERE/'PINS.json'))
    watch=[OLD,BUNDLE,CLOSURE,RESTORE_RESULT,*[pathlib.Path(p) for p in pins['smallEvidence']]]
    before=[meta(p) for p in watch];write('BEFORE.json',before)
    for p,h in pins['smallEvidence'].items():assert digest(small(p))==h,p
    closure_compressed=small(CLOSURE);assert digest(closure_compressed)==CLOSURE_SHA
    with gzip.GzipFile(fileobj=io.BytesIO(closure_compressed)) as g:
        closure_bytes=g.read(512*1024+1);assert len(closure_bytes)<=512*1024 and not g.read(1)
    ids=closure_bytes.decode('ascii').splitlines();assert len(ids)==len(set(ids))==4243
    assert ids==sorted(ids) and all(len(i)==40 and all(c in '0123456789abcdef' for c in i) for i in ids)
    closure=set(ids)
    assert OLD_COMMIT in closure and NEW_COMMIT in closure,'Old262 must exist in actual restored retained closure'
    restore_bytes=small(RESTORE_RESULT);assert digest(restore_bytes)==RESTORE_SHA
    restore=json.loads(restore_bytes)
    assert restore['PASS'] and restore['sourceCommit']==NEW_COMMIT and restore['noPrerequisites'] and restore['noAlternates']
    assert restore['fsckFullStrict'] and restore['exactSourceReachableClosureAndNoExtras'] and restore['reachableObjects']==4243
    phase='fresh-retained-source-bundle-body-pin'
    new_hash=stream_hash(BUNDLE);assert new_hash=={'bytes':1711151088,'sha256':BUNDLE_SHA}
    phase='actual-old-ancestor-tree-metadata'
    refs_before=git(['show-ref','--head'])
    git(['merge-base','--is-ancestor',OLD_COMMIT,NEW_COMMIT])
    commit=git(['cat-file','commit',OLD_COMMIT],max_output=MIB)
    assert hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==OLD_COMMIT
    old_tree=commit.splitlines()[0].decode().removeprefix('tree ');assert old_tree in closure and len(old_tree)==40
    raw_tree=git(['ls-tree','-r','-t','-z',OLD_COMMIT])
    expected={};dirs=set();tree_rows=[]
    for raw in raw_tree.split(b'\0'):
        if not raw:continue
        fields,name=raw.split(b'\t',1);mode,kind,oid=fields.decode('ascii').split();name=name.decode('utf8');safe_name(name)
        assert oid in closure,'Every old tree/blob identity must exist in retained bundle closure'
        assert name not in expected and name not in dirs
        row={'path':name,'mode':mode,'type':kind,'oid':oid,'retainedInVerifiedBundleClosure':True};tree_rows.append(row)
        if kind=='tree':assert mode=='040000';dirs.add(name)
        else:
            assert kind=='blob' and mode in ['100644','100755'],'Submodule/symlink/unsupported old tree requires separate preservation'
            expected[name]=row
    assert len(expected)==5564,'Actual historical source membership must match independently retained oracle'
    write('OLD-TREE.json.gz',gzip.compress(json.dumps({'commit':OLD_COMMIT,'rootTree':old_tree,'entries':tree_rows},separators=(',',':')).encode()))
    phase='fresh-complete-old-archive-body-pin'
    old_hash=stream_hash(OLD);assert old_hash=={'bytes':2863760699,'sha256':OLD_SHA}
    phase='complete-old-logical-content-coverage'
    seen=set();folded=set();matched=set();total_bytes=0;producer=None;zip_info=None
    mapping=output/'COVERAGE.jsonl.gz'
    with mapping.open('xb') as raw_proof,gzip.GzipFile(fileobj=raw_proof,mode='wb',mtime=0) as proof,opened(OLD) as af:
        zip_info=zip_admission(af)
        assert zip_info['comment']==OLD_COMMIT,'Actual Git archive source comment must match pinned262'
        af.seek(0)
        with zipfile.ZipFile(af) as z:
            infos=z.infolist();assert len(infos)==zip_info['entries']
            assert sum(i.file_size for i in infos)<=MAX_INFLATED,'Bound declared total inflation'
            for info in infos:
                guarded('before-member:'+str(entry_rows),False)
                name=safe_name(info.filename,info.is_dir());assert name not in seen;seen.add(name)
                fold=unicodedata.normalize('NFC',name).casefold();assert fold not in folded;folded.add(fold)
                assert not info.flag_bits&1 and info.compress_type in [zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED]
                mode=info.external_attr>>16;kind=stat.S_IFMT(mode)
                if info.is_dir():
                    assert name in dirs and info.file_size==0 and kind in [0,stat.S_IFDIR]
                    with z.open(info) as f:assert f.read(1)==b''
                    assert info.CRC==0,'Empty directory CRC must match its actual zero-byte payload'
                    row={'path':name,'type':'directory','mode':mode,'retainedTree':True,'crc32':info.CRC}
                else:
                    assert name in expected and kind in [0,stat.S_IFREG],'Every regular member needs exact old-tree coverage'
                    wanted=expected[name]
                    if mode:assert bool(mode&0o111)==(wanted['mode']=='100755'),'Preserve executable source semantics'
                    sha=hashlib.sha256();blob=hashlib.sha1(b'blob '+str(info.file_size).encode()+b'\0');crc=0;size=0;small_producer=bytearray()
                    with z.open(info) as f:
                        while b:=f.read(CHUNK):
                            size+=len(b);assert size<=info.file_size
                            sha.update(b);blob.update(b);crc=binascii.crc32(b,crc)
                            if name=='scripts/release.mjs':
                                assert size<=65536;small_producer.extend(b)
                            guarded('stream-member:'+str(entry_rows),False)
                    assert size==info.file_size and crc&0xffffffff==info.CRC
                    assert blob.hexdigest()==wanted['oid'],'Exact full old member differs from canonical historical Git blob'
                    matched.add(name);total_bytes+=size
                    row={'path':name,'type':'regular','bytes':size,'crc32':crc&0xffffffff,'sha256':sha.hexdigest(),
                         'blobSHA1':blob.hexdigest(),'gitMode':wanted['mode'],'zipMode':mode,
                         'retainedBundleSHA256':BUNDLE_SHA,'retainedBlobOID':wanted['oid'],'retainedViaAncestor':OLD_COMMIT}
                    if name=='scripts/release.mjs':producer=bytes(small_producer)
                proof.write((json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n').encode());entry_rows+=1
                assert raw_proof.tell()<=PROOF_LIMIT-MIB,'Bound mapping allocation; preserve partial proof on refusal'
            assert matched==set(expected),'No old raw/source/review/art/dataset member omitted'
    assert producer is not None;write('HISTORIC-RELEASE.mjs',producer)
    phase='readback-originals-and-final-proof'
    assert git(['show-ref','--head'])==refs_before,'Source refs changed during read-only audit'
    after=[meta(p) for p in watch];write('AFTER.json',after);assert after==before,'Original bytes identity metadata changed during audit'
    guarded('final')
    proof_hash=stream_hash(mapping)
    write('RESULT.json',{'schema':1,'status':'PASS: exact old logical contents retained; no retirement executed',
        'oldArchive':str(OLD),'oldWholeHash':old_hash,'retainedSourceBundle':str(BUNDLE),'retainedWholeHash':new_hash,
        'oldCommit':OLD_COMMIT,'oldRootTree':old_tree,'retainedSourceCommit':NEW_COMMIT,'retainedClosureObjects':4243,
        'freshAncestorVerified':True,'oldTreeRegularFiles':5564,'matchedRegularMembers':len(matched),'totalZIPEntries':entry_rows,
        'allMemberCRCsPassed':True,'allCanonicalGitBlobRawBodiesEqual':True,'everyOldTreeIdentityInRetainedClosure':True,
        'unexplainedUniqueMembers':0,'totalInflatedBytes':total_bytes,'actualZIPStructure':zip_info,
        'producerExtractedSHA256':digest(producer),'originalMetadataAndRefsUnchanged':True,'coverageProof':proof_hash,
        'commands':commands,'resourceSamples':samples,
        'limits':['No fresh1.7GB restore: actual prior independent complete restore tied to fresh unchanged bundle body/closure receipt',
                  'Canonical Git SHA1 correspondence supplemented by full member SHA256/CRC/byte counts',
                  'Retiring old ZIP would discard exact container encoding, not these retained raw contents',
                  'Root and separate result inspection still judge retirement; this program never unlinks/renames/rewrites inputs']})
    print(json.dumps({'status':'PASS coverage only; root retirement judgment pending','output':str(output),'entries':entry_rows,'regular':len(matched)}))
except BaseException as error:
    failure={'schema':1,'status':'REFUSED/FAILED: retirement withheld','phase':phase,'error':traceback.format_exc(),
             'output':str(output) if output else None,'completedMemberRows':entry_rows,'commands':commands,'samples':samples}
    if output:
        try:write('FAILURE.json',failure)
        except BaseException as secondary:failure['failureReceiptError']=repr(secondary)
        post={'status':'UNKNOWN: failure postflight not completed'}
        try:
            guarded('failure-metadata-postflight')
            assert before is not None,'No complete prior input snapshot'
            after=[meta(p) for p in watch];write('FAILED-AFTER.json',after);assert after==before
            post={'status':'PASS: source archive/bundle/proof metadata unchanged after failed attempt','wholeBodiesRehashedAfterFailure':False}
        except BaseException as secondary:post={'status':'UNKNOWN/REFUSED: postflight incomplete','secondaryError':traceback.format_exc()}
        try:write('FAILED-POSTFLIGHT.json',post)
        except BaseException as secondary:post['receiptError']=repr(secondary)
        print(json.dumps(post),file=sys.stderr)
    print(json.dumps(failure),file=sys.stderr);sys.exit(1)
