"""One reviewed ZIP encoding."""
import base64,hashlib,json,os,pathlib,resource,stat,sys,time,traceback
if not __debug__ or not sys.flags.isolated:
    raise RuntimeError('Require python -I, no -O')
HERE=pathlib.Path(__file__).resolve().parent
OLD=pathlib.Path('/workspace/Roguelike-deckbuilder/releases/0.6.0/hollowpact-0.6.0-source.zip')
NEW=pathlib.Path('/workspace/Roguelike-deckbuilder/releases/0.8.0/hollowpact-0.8.0-source.bundle')
LIMIT=65536
held=[];out=None;armed=False;unlinked=False;oc=False;phase='admission'
def sha(b):return hashlib.sha256(b).hexdigest()
def identity(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)
def metadata(fd,p):
    s=os.fstat(fd);assert stat.S_ISREG(s.st_mode)
    return dict(path=str(p),dev=s.st_dev,ino=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,
        bytes=s.st_size,blocks=s.st_blocks,atimeNs=s.st_atime_ns,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,
        xattrs={n:base64.b64encode(os.getxattr(fd,n)).decode() for n in os.listxattr(fd)})
def anchor(p):
    p=pathlib.Path(p);assert p.is_absolute() and '..' not in p.parts
    chain=[];fd=None
    try:
        r=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW);chain.append((r,None,'/',identity(os.fstat(r))))
        for name in p.parts[1:-1]:
            parent=chain[-1][0];child=os.open(name,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
            chain.append((child,parent,name,identity(os.fstat(child))))
            assert identity(os.stat(name,dir_fd=parent,follow_symlinks=False))==chain[-1][3]
        fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME|os.O_NONBLOCK,dir_fd=chain[-1][0])
        row=dict(path=p,fd=fd,chain=chain,pin=metadata(fd,p));check(row);held.append(row);return row
    except BaseException:
        if fd is not None:os.close(fd)
        for child,*_ in reversed(chain):os.close(child)
        raise
def check(row):
    assert metadata(row['fd'],row['path'])==row['pin'],'Meta drift'
    assert os.fstat(row['fd'])==os.stat(row['path'].name,dir_fd=row['chain'][-1][0],follow_symlinks=False)
    assert identity(os.stat('/',follow_symlinks=False))==row['chain'][0][3]
    for child,parent,name,pin in row['chain'][1:]:
        assert identity(os.fstat(child))==pin and identity(os.stat(name,dir_fd=parent,follow_symlinks=False))==pin
    return row['pin']
def read(p,cap=131072):
    row=anchor(p);b=os.pread(row['fd'],cap+1,0);assert len(b)<=cap;check(row);return b
def guard():
    peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;assert peak<=24*1048576
    current=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());maximum=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
    v=os.statvfs(HERE);free=v.f_bavail*v.f_frsize
    assert maximum-current>=24*1048576+512*1048576 and free>=LIMIT+1048576
    return dict(monotonicNs=time.monotonic_ns(),durableFree=free,memoryCurrent=current,memoryMax=maximum,peakRSS=peak)
def syncdir(p):
    fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:os.fsync(fd)
    finally:os.close(fd)
def receipt(name,value):
    guard();b=(json.dumps(value,indent=2,default=str)+'\n').encode();assert len(b)<=16384
    physical=out.stat().st_blocks*512+sum(p.stat().st_blocks*512 for p in out.iterdir())
    assert physical+((len(b)+4095)//4096+1)*4096<=LIMIT
    fd=os.open(out/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        assert os.write(fd,b)==len(b);os.fsync(fd)
    finally:os.close(fd)
    syncdir(out);syncdir(HERE)
    assert out.stat().st_blocks*512+sum(p.stat().st_blocks*512 for p in out.iterdir())<=LIMIT
    return sha(b)
try:
    assert len(sys.argv)==3 and sys.argv[1]=='--root-approved-one-container-retirement'
    initial=guard();source=read(pathlib.Path(__file__),8192);pb=read(HERE/'PINS.json',8192);pins=json.loads(pb)
    jb=read(pathlib.Path(sys.argv[2]),16384);judge=json.loads(jb)
    assert judge['sourceSHA256']==sha(source) and judge['pinsSHA256']==sha(pb)
    assert judge['action']=='retire_exact_old_source_zip_encoding' and judge['target']==str(OLD) and judge['successor']==str(NEW)
    assert judge['ownerAllowsReviewedRetirement'] is True and judge['knownActorsHeld'] is True
    assert judge['globalAbsenceClaim'] is False and judge['rootJudgementApproved'] is True
    assert isinstance(judge['rationale'],str) and 40<=len(judge['rationale'])<=2048
    controls={}
    for key in ['coverageResult','coverageAfter','actualReview']:
        pin=pins[key];body=read(pathlib.Path(pin['path']));assert sha(body)==pin['sha256'] and len(body)==pin['bytes'];controls[key]=body
    assert judge['actualReviewSHA']==pins['actualReview']['sha256']
    review=read(pathlib.Path(judge['sourceReviewPath']));assert sha(review)==judge['sourceReviewSHA']
    assert judge['sourceReviewAccepted'] is True
    result=json.loads(controls['coverageResult']);after=json.loads(controls['coverageAfter'])
    assert result['status']=='PASS: exact old logical contents retained; no retirement executed'
    assert result['oldArchive']==str(OLD) and result['retainedSourceBundle']==str(NEW)
    assert result['oldWholeHash']==pins['oldWholeHash'] and result['retainedWholeHash']==pins['retainedWholeHash']
    assert result['oldTreeRegularFiles']==result['matchedRegularMembers']==5564 and result['totalZIPEntries']==5911
    assert result['retainedClosureObjects']==4243 and result['unexplainedUniqueMembers']==0
    for key in ['freshAncestorVerified','allMemberCRCsPassed','allRawCompressedPayloadsConsumedAtExactEOF','allCanonicalGitBlobRawBodiesEqual','everyOldTreeIdentityInRetainedClosure','originalMetadataAndRefsUnchanged']:assert result[key] is True
    ex={r['path']:r for r in after};old=anchor(OLD);new=anchor(NEW)
    for row in [old,new]:
        assert row['pin']==ex[str(row['path'])]
        assert row['pin']['uid']==os.geteuid() and row['pin']['nlink']==1
    phase='arming';out=HERE/('run-'+str(time.time_ns()));out.mkdir(mode=0o700);syncdir(HERE)
    arming=guard()
    armed_hash=receipt('ARMED.json',dict(status='ARMED: no unlink',
        sourceSHA256=sha(source),pinsSHA256=sha(pb),judgeSHA=sha(jb),
        actualReviewSHA=pins['actualReview']['sha256'],sourceReviewSHA=sha(review),
        target=old['pin'],successor=new['pin'],admission=initial,
        limit='Accepted complete hashes + unchanged metadata + genuine actor hold; no fresh body rehash'))
    armed=True;phase='last-check'
    for row in held:check(row)
    pre=guard();parent=old['chain'][-1][0]
    check(old);check(new);phase='literal-unlink'
    os.unlink('hollowpact-0.6.0-source.zip',dir_fd=parent);unlinked=True
    assert os.fstat(old['fd']).st_nlink==0,'Link survives'
    fs=os.open('.',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
    try:os.fsync(fs)
    finally:os.close(fs)
    orphan=metadata(old['fd'],OLD);os.close(old['fd']);old['fd']=None;oc=True
    for row in held:
        if row is not old:check(row)
    try:os.stat(OLD.name,dir_fd=parent,follow_symlinks=False)
    except FileNotFoundError:pass
    else:raise RuntimeError('Path survives')
    post=guard();phase='receipt'
    receipt('RETIRED.json',dict(status='RETIRED: container only; history retained',
        target=str(OLD),successor=check(new),armedSHA256=armed_hash,oldHash=pins['oldWholeHash'],
        successorHash=pins['retainedWholeHash'],orphanBeforeClose=orphan,
        preUnlink=pre,postClose=post,
        observedFreeDelta=post['durableFree']-pre['durableFree'],targetAllocation=old['pin']['blocks']*512,
        limit='Known-actor hold; no atomic compare/unlink or exclusive attribution'))
    print(json.dumps(dict(status='RETIRED',output=str(out))))
except BaseException:
    failure=dict(status='FAILED/REFUSED',phase=phase,armed=armed,unlinkIssued=unlinked,ownOldFDClosed=oc,error=traceback.format_exc())
    if out:
        try:receipt('FAILURE.json',failure)
        except BaseException:failure['receiptFailure']=traceback.format_exc()
    print(json.dumps(failure),file=sys.stderr);sys.exit(1)
finally:
    for row in reversed(held):
        if row['fd'] is not None:os.close(row['fd'])
        for child,*_ in reversed(row['chain']):os.close(child)
