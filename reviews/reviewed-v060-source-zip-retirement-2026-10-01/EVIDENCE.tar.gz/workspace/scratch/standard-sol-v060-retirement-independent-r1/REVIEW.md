# Independent source gate: REJECT frozen retirement r1

Source-only review of the frozen single-file transaction. Do not execute this generation. The underlying independently reviewed old-content retention preference remains conditional and is not rejected here. Two transaction defects require a new frozen source and renewed independent review before any deletion.

## Blocking findings

1. **No durable failure slot before deletion (retire.py:88–99,118–122).** The transaction fsyncs ARMED.json and the containing directories, but creates no preallocated, fsynced failure/status slot before unlink. FAILURE.json is first created after an exception, through receipt(). That function starts with guard(), allocates/serializes a new body, checks a newly estimated allocation budget, creates a new file and directory entry, then writes/fsyncs them. The very memory/free-space/receipt-allocation failure being reported can prevent this path from recording anything durably. A partly created RETIRED.json also consumes the shared budget. Only stderr and an earlier ARMED record may then survive. This does not satisfy the requested fsynced ARMED/failure-slot precondition. Reserve and durably initialize a bounded status/failure slot before unlink; make the post-unlink emergency update independent of another admission/resource guard or new file allocation. Treat an incomplete transaction as requiring independent inspection, never as proved non-deletion.

2. **The failure receipt can falsely report no unlink (retire.py:99,119).** `unlinked=True` is assigned after os.unlink returns, while BaseException catches KeyboardInterrupt and other asynchronous exceptions. An interrupt may be delivered after the syscall has removed the name and before that Python assignment. The resulting failure says `unlinkIssued: false` despite an issued and potentially effective unlink. The same general window applies to the close/oc bookkeeping. Record the attempt conservatively before the syscall; distinguish attempted, returned-success, and independently observed final state. A false success flag must not be presented as proof that deletion was never issued. The required emergency slot should preserve this distinction across interruption.

These are source findings, not executed failure reproductions. No candidate import, compile, synthetic run, mutation, unlink, archive-body read, Git operation, browser, Node process or cache-hint call occurred.

## Verified favorable properties

The code requires isolated Python with assertions active. Its literal OLD and NEW paths are fixed; only `os.unlink('hollowpact-0.6.0-source.zip', dir_fd=parent)` can delete. Admission reads the actual RESULT, AFTER, and distinct independent actual review at their pinned hashes/sizes, checks complete-result PASS and the specific 5564/5911/4243 counts and coverage booleans, and ties accepted whole-container hashes to unchanged full old/successor metadata.

Anchoring opens every parent with O_PATH/O_DIRECTORY/O_NOFOLLOW, opens leaves O_RDONLY/O_NOFOLLOW/O_NOATIME/O_NONBLOCK, holds those FDs, and checks parent identities, full metadata including nanosecond times/allocated blocks/xattrs, and current leaf correspondence. Old and successor must exactly match accepted AFTER, be regular, owned by the current euid and nlink1. Their accepted mode is 0600. The final checks immediately precede the one literal dirfd unlink. Current reviewer metadata-only O_NOATIME observations also match the accepted AFTER exactly for both files.

On its successful path the old directory is fsynced through an anchored parent-relative directory FD; its own old descriptor is closed before the measured post-close free-space sample. RETIRED reports observed free-space delta and recorded target allocation separately and explicitly disclaims exclusive attribution/global FD absence. Every other held input is rechecked after unlink. The writer/reader hold remains indispensable because metadata checks and unlink are separate syscalls. Scratch output and the old/successor directories currently all have st_dev27; the program does not enforce that measured statvfs(HERE) is always the target filesystem.

## Exact pins checked

Author packet: /workspace/scratch/v060-exact-container-retirement-author-r1; 30,552 total logical bytes including FROZEN-FILES.json. All six listed member sizes/SHA256 values matched the 1,056-byte frozen manifest. The preserved oversize drafts were hash-checked as historical packet members, not promoted to executable candidates.

- retire.py: 8,167 B, SHA256 5fc650aa53e8baf27ab3d4d726fbf9e6f1081a32d4153a235a11fc2e7ed27040.
- FROZEN-FILES.json: 1,056 B, SHA256 4f2d4273c3502acc76eab5a6b4ff541a39d75d9716091a556ab8d974ac1e89be.
- PINS.json: 948 B, SHA256 269e77e992620887794f32b3b756e21ec4b639a30b4f540942a12fd32579098d.
- Actual RESULT.json: 115,541 B, SHA256 038f150ed4733cebe76a5facc8c231d186802acf754763f04bc81b1c7b6311de.
- Actual AFTER.json: 5,417 B, SHA256 17385a1ef9d162fe57e3300cd63bcbdf666ba7e54a5044fdaeca7ee6b6aa4c35.
- Distinct actual independent REVIEW.md: 7,729 B, SHA256 0cb7ba318cca3dcc2213e7726f5a2b4f74e6d31b4adf6a3964ad89f4f50829f0.

Actual RESULT/AFTER are under /workspace/scratch/v060-source-coverage-checker-author-r4/executed-r4-5uzdc7cv. Actual independent review is under /workspace/scratch/v060-source-coverage-actual-independent-r1. Its small MANIFEST.json and FROZEN.json were read for context; its already completed coverage comparison was not rerun in this review.

Old: /workspace/Roguelike-deckbuilder/releases/0.6.0/hollowpact-0.6.0-source.zip; 2,863,760,699 B; SHA256 076fc29bccc706b85666c2e2b7a4e4d620a93784dcd84f6931d7ced50c4c722c; dev27/inode1180878/uid1000/gid1000/mode33152/nlink1/blocks5593296/xattrs{}. Allocated bytes 2,863,767,552. Accepted atimeNs1790811058741336717, mtimeNs1790810683107395589, ctimeNs1790810683107395589.

Successor: /workspace/Roguelike-deckbuilder/releases/0.8.0/hollowpact-0.8.0-source.bundle; 1,711,151,088 B; SHA256 fd1310a36be0931bb81537004f87ef751481ca0daa349e58f1576a3c34640b3d; dev27/inode1448693/uid1000/gid1000/mode33152/nlink1/blocks3342104/xattrs{}. Allocated bytes 1,711,157,248. Accepted atimeNs1790824401736282082, mtimeNs1790824401684282911, ctimeNs1790824401716282403.

## External gates and limits

AGENTS.md was read first. Its 1 October owner instruction permits selective retirement only when a thorough independent review prefers the verified successor and the producer judges removal wise, while preserving unique source/art/data, rollback baselines, historical manifests and reviews. No producer removal judgment was made by this reviewer. The program requires explicit ROOT judgment fields and a minimum-length rationale; these assertions cannot establish freshness or a genuine known-actor hold. ROOT must independently establish the current hold for target/successor/proofs/control/ref users and writers, preserve protected history and receipts, and inspect final target/successor/proof/sibling identities and hashes after a separately accepted transaction. Source review does not prove global absence of open readers, atomic compare/unlink, stable resource headroom, eventual reclaim or power-loss recovery.

Hash checks consumed bounded small proof files only; the largest was 115,541 B. Metadata opens consumed no old/successor archive bodies. Reviewer helper processes recorded peak RSS at most 10,354,688 B, below the 32 MiB ceiling. No full archive rehash or rerestore was performed; whole-container hashes and complete content coverage are accepted from the exact pinned completed audit and its distinct independent review. No game, visual, native/platform, Steam, human-fun or broader cleanup approval is conferred. This reject gate cannot be used as sourceReviewAccepted=true.
