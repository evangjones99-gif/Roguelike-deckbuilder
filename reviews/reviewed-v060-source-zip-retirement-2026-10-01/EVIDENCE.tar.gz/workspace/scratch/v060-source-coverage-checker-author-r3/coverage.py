#!/usr/bin/env python3
"""Prospective read-only source-retirement coverage audit. Never unlinks inputs."""
import base64, binascii, gzip, hashlib, io, json, os, pathlib, stat, struct
import selectors, subprocess, sys, time, traceback, unicodedata, zipfile, zlib

if not __debug__ or not sys.flags.isolated:
    raise RuntimeError('Require an isolated Python -I invocation without -O/PYTHONOPTIMIZE; no input/proof allocation authorized')

ROOT=pathlib.Path('/workspace/Roguelike-deckbuilder')
OLD=ROOT/'releases/0.6.0/hollowpact-0.6.0-source.zip'
BUNDLE=ROOT/'releases/0.8.0/hollowpact-0.8.0-source.bundle'
OLD_COMMIT='26286ec6acb7d95ad28446962349fdf4d5cfa702'
NEW_COMMIT='58efb01f4815d8b542711582b87f50168dabde81'
OLD_SHA='076fc29bccc706b85666c2e2b7a4e4d620a93784dcd84f6931d7ced50c4c722c'
BUNDLE_SHA='fd1310a36be0931bb81537004f87ef751481ca0daa349e58f1576a3c34640b3d'
CLOSURE=pathlib.Path('/workspace/scratch/release-v08-final-independent-r1/REACHABLE-OBJECTS.json.gz')
CLOSURE_SHA='174494893e3e1e605fe9a965bfb117d3cf0c971703d8db3d4080b0b8daa3aac0'
RESTORE_RESULT=pathlib.Path('/workspace/scratch/release-v08-final-independent-r1/RESTORE-RESULT.json')
RESTORE_SHA='a334dbc8828bf29b4fff892ea176db4f62a4f01d09298f34784cb930c4d83f2f'
MIB=1048576
WORK=64*MIB
RESERVE=512*MIB
PROOF_LIMIT=2*MIB
MAX_CENTRAL=16*MIB
MAX_ENTRIES=20000
MAX_INFLATED=32*1024*MIB
CHUNK=256*1024
HERE=pathlib.Path(__file__).resolve().parent
samples=[]
commands=[]
phase='initial-admission'
output=None
before=None
watch=[]
entry_rows=0
last_sample=0
archive_pins={}
advice_raw=None
advice_writer=None
advice_calls=0
advice_attempts=0
advice_requested_bytes=0
advice_ledgered=0
advice_durable=0
last_hint=None
advice_bytes=0
archive_open_ordinal=0
ADVICE_LIMIT=512*1024
ledger_counts={}

def digest(b):return hashlib.sha256(b).hexdigest()
def fd_meta(fd,p):
    s=os.fstat(fd);assert stat.S_ISREG(s.st_mode)
    attrs={n:base64.b64encode(os.getxattr(fd,n)).decode() for n in os.listxattr(fd)}
    return {'path':str(p),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,
            'bytes':s.st_size,'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'xattrs':attrs}
def directory_identity(s):
    return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)
def anchored_open(p,read=False):
    # Original absolute parent components are held as descriptors. Parent
    # namespace/inode/type/mode/ownership are checked; directory times can change
    # for unrelated sibling receipts and are deliberately not frozen.
    p=pathlib.Path(p);assert p.is_absolute() and '..' not in p.parts
    chain=[];fd=None
    try:
        rootfd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW)
        chain.append((rootfd,None,'/',directory_identity(os.fstat(rootfd))))
        for name in p.parts[1:-1]:
            parent=chain[-1][0]
            child=os.open(name,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
            pin=directory_identity(os.fstat(child));chain.append((child,parent,name,pin))
            assert pin==directory_identity(os.stat(name,dir_fd=parent,follow_symlinks=False))
        parent=chain[-1][0]
        # Metadata-only descriptors are never read and therefore do not update atime.
        # Actual reads require O_NOATIME and may refuse non-owned inputs.
        flags=os.O_RDONLY|os.O_NOFOLLOW|(os.O_NOATIME if read else 0)
        fd=os.open(p.name,flags,dir_fd=parent)
        pinned=fd_meta(fd,p)
        assert os.fstat(fd)==os.stat(p.name,dir_fd=parent,follow_symlinks=False),'Opened original path binding changed'
        return fd,chain,pinned
    except BaseException:
        if fd is not None:os.close(fd)
        for row in reversed(chain):os.close(row[0])
        raise
def anchored_check(fd,chain,p,pinned):
    assert fd_meta(fd,p)==pinned,'Input FD full metadata/xattrs changed'
    assert os.fstat(fd)==os.stat(pathlib.Path(p).name,dir_fd=chain[-1][0],follow_symlinks=False),'Input leaf binding changed'
    assert directory_identity(os.stat('/',follow_symlinks=False))==chain[0][3]
    for child,parent,name,pin in chain[1:]:
        assert directory_identity(os.fstat(child))==pin
        assert directory_identity(os.stat(name,dir_fd=parent,follow_symlinks=False))==pin,'Original parent binding changed'
def anchored_close(fd,chain):
    try:os.close(fd)
    finally:
        for row in reversed(chain):os.close(row[0])
def meta(p):
    fd,chain,pinned=anchored_open(p)
    try:anchored_check(fd,chain,p,pinned);return pinned
    finally:anchored_close(fd,chain)
def fd_identity(s):
    return {k:getattr(s,'st_'+k) for k in ['dev','ino','mode','uid','gid','nlink','size','mtime_ns','ctime_ns','atime_ns']}
class AnchoredRegularReader(io.FileIO):
    def __init__(self,p):
        self.path=pathlib.Path(p)
        fd,self.chain,self.pinned=anchored_open(self.path,read=True)
        try:super().__init__(fd,'rb',closefd=True)
        except BaseException:anchored_close(fd,self.chain);raise
    def close(self):
        if not self.closed:
            try:anchored_check(self.fileno(),self.chain,self.path,self.pinned)
            finally:
                try:super().close()
                finally:
                    for row in reversed(self.chain):os.close(row[0])
active_proof_files=set()
FAILURE_RESERVE=64*1024
GZIP_BUFFER_RESERVE=64*1024
BLOCK=4096

def fsync_owned_dirs():
    # Only own new proof namespace/parent; never any original input directory.
    for directory in [output,HERE]:
        if directory is not None:
            fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
            try:os.fsync(fd)
            finally:os.close(fd)

def proof_budget(extra=0,failure=False):
    assert output
    physical=output.stat().st_blocks*512+sum(p.stat().st_blocks*512 for p in output.iterdir() if p.is_file())
    pending=len(active_proof_files)*GZIP_BUFFER_RESERVE
    projected=physical+pending+((extra+BLOCK-1)//BLOCK)*BLOCK+(BLOCK if extra else 0)
    assert projected<=PROOF_LIMIT-(0 if failure else FAILURE_RESERVE),'Aggregate block-rounded own proof cap including pending gzip/footer buffers'
    v=os.statvfs(HERE)
    assert v.f_bavail*v.f_frsize>=MIB+((extra+BLOCK-1)//BLOCK)*BLOCK,'Fresh durable1MiB reserve for every receipt operation'
    return physical
class BudgetFile(io.FileIO):
    # Exclusive unbuffered owned receipts only; never wraps an input FD.
    def __init__(self,p,failure=False):
        self.failure=failure;proof_budget(BLOCK,failure)
        super().__init__(p,'xb');active_proof_files.add(self)
        proof_budget(failure=failure)
    def write(self,b):
        proof_budget(len(b),self.failure)
        n=super().write(b);assert n==len(b),'Owned receipt short write'
        proof_budget(failure=self.failure);return n
    def close(self):
        if not self.closed:
            try:
                super().flush();os.fsync(self.fileno())
            finally:
                try:super().close()
                finally:active_proof_files.discard(self)
            proof_budget(failure=self.failure);fsync_owned_dirs()
def ledger_row(writer,raw,row,limit):
    b=(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n').encode();assert len(b)<=65536
    writer.write(b)
    ledger_counts[raw]=ledger_counts.get(raw,0)+1
    if ledger_counts[raw]%128==0:writer.flush(zlib.Z_SYNC_FLUSH)
    assert raw.tell()+GZIP_BUFFER_RESERVE<=limit,'Bound compressed mapping/advice including final footer'
    proof_budget()
class ConsumedArchiveReader(io.RawIOBase):
    # Only the exact two archives, under a root-declared closed-reader window.
    # A read copies bytes to bounded user buffers; releasing kernel cache does
    # not discard these buffers or change file bytes. Residency is unguaranteed.
    def __init__(self,p):
        global archive_open_ordinal
        super().__init__();self.fd=None;self.chain=[];self.p=pathlib.Path(p)
        assert str(self.p) in archive_pins and advice_writer is not None
        assert meta(self.p)==archive_pins[str(self.p)]
        self.fd,self.chain,self.full_pin=anchored_open(self.p,read=True)
        assert self.full_pin==archive_pins[str(self.p)]
        st=os.fstat(self.fd);assert stat.S_ISREG(st.st_mode)
        self.pin=fd_identity(st)
        wanted=archive_pins[str(self.p)]
        assert (st.st_dev,st.st_ino,st.st_size,st.st_mode,st.st_mtime_ns,st.st_ctime_ns)==(wanted['dev'],wanted['ino'],wanted['bytes'],wanted['mode'],wanted['mtimeNs'],wanted['ctimeNs'])
        self.position=0;self.tail_start=0;self.tail_end=-1;self.page=os.sysconf('SC_PAGE_SIZE')
        assert self.page>0 and CHUNK%self.page==0
        archive_open_ordinal+=1;self.ordinal=archive_open_ordinal
        ledger_row(advice_writer,advice_raw,{'open':self.ordinal,'target':'oldZIP' if self.p==OLD else 'retainedBundle',
                    'dev':self.pin['dev'],'ino':self.pin['ino'],'pageSize':self.page,
                    'subsequentArrays':['open','offset','length','latestReadStart','latestReadEnd'],'order':'returned hint invocation order'},ADVICE_LIMIT)
    def readable(self):return True
    def seekable(self):return True
    def writable(self):return False
    def tell(self):return self.position
    def seek(self,offset,whence=0):
        base=0 if whence==0 else self.position if whence==1 else self.pin['size'] if whence==2 else None
        assert base is not None and 0<=base+offset<=self.pin['size']
        self.position=base+offset;return self.position
    def read(self,n=-1):
        global advice_calls,advice_bytes,advice_attempts,advice_requested_bytes,advice_ledgered,last_hint
        if n==-1:n=self.pin['size']-self.position
        assert 0<=n<=MAX_CENTRAL,'Only explicitly bounded reads or bounded EOF-tail reads admitted on originals'
        start=self.position;b=os.pread(self.fd,n,start);self.position+=len(b)
        if b:
            # Join only adjacent consumed spans to release their shared page.
            consumed_start=self.tail_start if start==self.tail_end else start
            first=((consumed_start+self.page-1)//self.page)*self.page
            end=(self.position//self.page)*self.page
            if end>first:
                assert end<=self.position and first>=consumed_start and first%self.page==end%self.page==0
                anchored_check(self.fd,self.chain,self.p,self.full_pin)
                assert fd_identity(os.fstat(self.fd))==self.pin,'Pinned read-only FD metadata changed before advice'
                last_hint={'attempt':advice_attempts+1,'open':self.ordinal,'offset':first,'length':end-first,
                           'returnedSuccessfully':False,'ledgerOperationCompleted':False}
                advice_attempts+=1;advice_requested_bytes+=end-first
                os.posix_fadvise(self.fd,first,end-first,os.POSIX_FADV_DONTNEED)
                advice_calls+=1;advice_bytes+=end-first;last_hint['returnedSuccessfully']=True
                anchored_check(self.fd,self.chain,self.p,self.full_pin)
                assert fd_identity(os.fstat(self.fd))==self.pin,'Pinned read-only FD metadata changed after advice'
                row=[self.ordinal,first,end-first,start,self.position]
                ledger_row(advice_writer,advice_raw,row,ADVICE_LIMIT)
                advice_ledgered+=1;last_hint['ledgerOperationCompleted']=True
                self.tail_start=end
            else:self.tail_start=consumed_start
            self.tail_end=self.position
        return b
    def close(self):
        if not self.closed:
            try:
                if self.fd is not None:anchored_check(self.fd,self.chain,self.p,self.full_pin)
            finally:
                if self.fd is not None:anchored_close(self.fd,self.chain);self.fd=None
                super().close()
def opened(p):
    p=pathlib.Path(p)
    if p in [OLD,BUNDLE]:return ConsumedArchiveReader(p)
    return AnchoredRegularReader(p)
def guarded(label,force=True):
    global last_sample
    now=time.monotonic()
    if not force and now-last_sample<0.1:return
    c=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());m=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())
    v=os.statvfs(HERE);r={'label':label,'time':now,'memoryCurrent':c,'memoryMax':m,'headroom':m-c,
                       'durableFree':v.f_bavail*v.f_frsize,'events':pathlib.Path('/sys/fs/cgroup/memory.events').read_text()}
    if len(samples)<128:samples.append(r)
    else:samples[-1]=r
    last_sample=now
    assert m-c>=WORK+RESERVE,'Require fresh64MiB work +512MiB reserve; no guard lowering'
    assert r['durableFree']>=PROOF_LIMIT+MIB,'Require2MiB proof budget +1MiB durable reserve'
def write(name,value):
    assert output
    b=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    assert len(b)<=MIB
    with BudgetFile(output/name,failure=name.startswith(('FAILURE','FAILED-'))) as f:f.write(b)
def small(p,maximum=MIB):
    with opened(p) as f:
        b=f.read(maximum+1);assert len(b)<=maximum
        return b
def stream_hash(p):
    h=hashlib.sha256();total=0
    with opened(p) as f:
        while b:=f.read(CHUNK):
            h.update(b);total+=len(b)
            guarded('stream:'+p.name,False)
    return {'bytes':total,'sha256':h.hexdigest()}
def git(args,max_output=4*MIB,expected=(0,)):
    # Metadata/ancestry only. Enforce stdout/stderr caps during reads, not after.
    guarded('before-Git-metadata')
    redirects=[k for k in os.environ if k.startswith('GIT_')]
    assert not redirects,'Inherited Git environment redirects/config are unsupported: '+repr(redirects)
    assert not (ROOT/'.git/info/grafts').exists() and not (ROOT/'.git/shallow').exists(),'Grafts/shallow metadata unsupported'
    assert not (ROOT/'.git/objects/info/alternates').exists(),'Alternate object store unsupported'
    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
    config=small(ROOT/'.git/config',65536).lower()
    compact=bytes(c for c in config if c not in b' \t\r\n')
    assert b'[include' not in compact,'Included local Git config unsupported in closed no-fetch trust boundary'
    assert b'promisor' not in config and b'partialclone' not in config,'Promisor/partial-clone config unsupported; no lazy object fetch'
    env.update(GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null')
    child=subprocess.Popen(['/usr/bin/git','--git-dir='+str(ROOT/'.git'),'--work-tree='+str(ROOT),'--no-replace-objects',
                            '-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null','-c','maintenance.auto=false','-c','gc.auto=0',*args],cwd=ROOT,env=env,
                           stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    selector=selectors.DefaultSelector();selector.register(child.stdout,selectors.EVENT_READ,'out');selector.register(child.stderr,selectors.EVENT_READ,'err')
    buffers={'out':bytearray(),'err':bytearray()};caps={'out':max_output,'err':65536};started=time.monotonic()
    try:
        while selector.get_map():
            assert time.monotonic()-started<=60,'Only owned Git metadata child deadline exceeded'
            for key,_ in selector.select(0.2):
                part=os.read(key.fileobj.fileno(),min(65536,caps[key.data]-len(buffers[key.data])+1))
                if not part:selector.unregister(key.fileobj);continue
                assert len(buffers[key.data])+len(part)<=caps[key.data],'Git metadata cap enforced before accumulation'
                buffers[key.data].extend(part)
            guarded('during-Git-metadata',False)
        child.wait(timeout=max(0.1,60-(time.monotonic()-started)))
    except BaseException:
        if child.poll() is None:child.kill()
        child.wait(timeout=5)
        commands.append({'args':args,'returncode':child.returncode,'boundedAbort':True,'stdoutBytes':len(buffers['out']),
                         'stderr':bytes(buffers['err']).decode(errors='replace')})
        raise
    finally:
        selector.close();child.stdout.close();child.stderr.close()
    stdout=bytes(buffers['out']);stderr=bytes(buffers['err'])
    commands.append({'args':args,'returncode':child.returncode,'stdoutBytes':len(stdout),'stdoutSHA256':digest(stdout),
                     'stderr':stderr.decode(errors='replace')})
    assert child.returncode in expected,commands[-1]
    guarded('after-Git-metadata')
    return stdout
def safe_name(name,is_dir=False):
    assert isinstance(name,str) and name and not name.startswith('/') and '\\' not in name and ':' not in name
    assert not any(ord(c)<32 for c in name),'Control-name layout unsupported; preserve, do not retire'
    if is_dir:
        assert name.endswith('/');name=name[:-1]
    else:assert not name.endswith('/')
    assert all(p and p not in ['.','..'] for p in name.split('/'))
    return name
def checked_raw_tree(root_oid,closure):
    cache={};rows=[];paths=set();trees=set()
    def descend(oid,prefix,ancestry):
        assert oid in closure and oid not in ancestry,'Unretained/cyclic tree identity'
        if oid not in cache:
            body=git(['cat-file','tree',oid],max_output=MIB)
            assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==oid,'Raw tree Git identity differs'
            entries=[];at=0;names=set()
            while at<len(body):
                space=body.index(b' ',at);zero=body.index(b'\0',space+1);end=zero+21;assert end<=len(body)
                mode=body[at:space].decode('ascii');name=body[space+1:zero].decode('utf8');child=body[zero+1:end].hex()
                assert mode in ['40000','100644','100755'] and '/' not in name
                safe_name(name);assert name not in names;names.add(name)
                entries.append((mode,name,child));at=end
            assert at==len(body);cache[oid]=entries;trees.add(oid)
        for mode,name,child in cache[oid]:
            path=prefix+name;safe_name(path);assert path not in paths;paths.add(path)
            assert child in closure
            is_tree=mode=='40000'
            rows.append({'path':path,'mode':'040000' if is_tree else mode,'type':'tree' if is_tree else 'blob','oid':child,'retainedInVerifiedBundleClosure':True})
            assert len(rows)<=MAX_ENTRIES
            if is_tree:descend(child,path+'/',ancestry|{oid})
    descend(root_oid,'',set())
    return rows,trees

def extra_layout(extra):
    at=0
    while at<len(extra):
        assert at+4<=len(extra),'Closed extra-field TLV required'
        ident,length=struct.unpack_from('<HH',extra,at);at+=4
        assert at+length<=len(extra) and ident!=1,'ZIP64 extras require separately reviewed parser'
        assert ident==0x5455 and length in [1,5,9,13],'Only known Git extended-time metadata admitted; unknown extra contents require separate retention audit'
        assert extra[at]&~7==0
        at+=length
    assert at==len(extra)
def member_layout(info,af):
    assert info.orig_filename==info.filename,'ZIP original name differs/truncates: unsupported canonical layout'
    safe_name(info.orig_filename,info.is_dir())
    assert info.file_size!=0xffffffff and info.compress_size!=0xffffffff and info.header_offset!=0xffffffff
    extra_layout(info.extra)
    original_position=af.tell()
    try:
        af.seek(info.header_offset);header=af.read(30);assert len(header)==30
        sig,version,flags,method,clock,day,crc,compressed,size,name_size,extra_size=struct.unpack('<4s5H3I2H',header)
        assert sig==b'PK\x03\x04' and flags==info.flag_bits and method==info.compress_type
        assert compressed!=0xffffffff and size!=0xffffffff,'Local ZIP64 sentinel unsupported'
        raw_name=af.read(name_size);local_extra=af.read(extra_size)
        assert len(raw_name)==name_size and len(local_extra)==extra_size
        name=raw_name.decode('utf8' if flags&0x800 else 'cp437')
        assert name==info.orig_filename;safe_name(name,info.is_dir());extra_layout(local_extra)
        local_end=info.header_offset+30+name_size+extra_size+info.compress_size
        if flags&8:
            assert crc in [0,info.CRC] and compressed in [0,info.compress_size] and size in [0,info.file_size]
            # Closed legacy descriptor, never silently admit a ZIP64 local form.
            af.seek(info.header_offset+30+name_size+extra_size+info.compress_size)
            first=af.read(4);assert len(first)==4
            values=af.read(12) if first==b'PK\x07\x08' else first+af.read(8)
            local_end+=16 if first==b'PK\x07\x08' else 12
            assert len(values)==12 and struct.unpack('<III',values)==(info.CRC,info.compress_size,info.file_size)
        else:assert (crc,compressed,size)==(info.CRC,info.compress_size,info.file_size)
        return (info.header_offset,local_end,info.header_offset+30+name_size+extra_size)
    finally:af.seek(original_position)

def exact_member_bytes(info,af,data_start):
    # Validate the complete raw compressed stream rather than ZipExtFile's
    # truncation to declared file_size. No unexplained DEFLATE tail is admitted.
    af.seek(data_start);remaining=info.compress_size;inflated=0
    if info.compress_type==zipfile.ZIP_STORED:
        assert info.compress_size==info.file_size,'Stored member sizes differ'
        while remaining:
            b=af.read(min(CHUNK,remaining));assert b and len(b)<=remaining
            remaining-=len(b);yield b
        return
    assert info.compress_type==zipfile.ZIP_DEFLATED
    decoder=zlib.decompressobj(-15)
    while remaining:
        data=af.read(min(CHUNK,remaining));assert data and len(data)<=remaining
        remaining-=len(data);guarded('compressed-member-stream',False)
        while data:
            prior=data;b=decoder.decompress(data,CHUNK);data=decoder.unconsumed_tail
            assert not decoder.unused_data,'Unexplained bytes after DEFLATE EOF require preservation'
            assert b or data!=prior,'No-progress compressed stream refused'
            inflated+=len(b);assert inflated<=info.file_size,'Undeclared inflated raw contents require preservation'
            if b:yield b
            if decoder.eof:assert remaining==0 and not data,'Trailing compressed payload requires preservation'
    while not decoder.eof:
        b=decoder.decompress(b'',CHUNK)
        assert b and not decoder.unused_data,'Incomplete DEFLATE EOF refused'
        inflated+=len(b);assert inflated<=info.file_size
        yield b
    assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
    assert inflated==info.file_size,'Complete inflater size differs from declaration'

def zip_admission(f):
    f.seek(0,2);size=f.tell();f.seek(max(0,size-65557));tail=f.read(65557)
    # Reject unsupported layouts, rather than treating them as corrupt material.
    pos=tail.rfind(b'PK\x05\x06');assert pos>=0,'No admitted legacy ZIP EOCD found'
    fields=struct.unpack_from('<4s4H2IH',tail,pos)
    _,disk,start_disk,disk_count,count,central_size,central_offset,comment_size=fields
    assert disk==start_disk==0 and disk_count==count
    assert count!=65535 and central_size!=0xffffffff and central_offset!=0xffffffff,'ZIP64 requires separate reviewed parser'
    assert count<=MAX_ENTRIES and central_size<=MAX_CENTRAL
    assert pos+22+comment_size==len(tail),'Admit closed EOCD/comment/EOF only'
    assert central_offset+central_size==size-len(tail)+pos,'Closed central-directory coverage'
    return {'entries':count,'centralBytes':central_size,'centralOffset':central_offset,'comment':tail[pos+22:].decode('ascii')}

try:
    assert len(sys.argv)==3 and sys.argv[1]=='--approved-read-only-coverage-and-consumed-range-advice-window','Explicit separately reviewed serial archive-read/advice window required'
    declaration_path=pathlib.Path(sys.argv[2]);assert declaration_path.is_absolute()
    declaration=json.loads(small(declaration_path))
    assert declaration['checkerSHA256']==digest(small(pathlib.Path(__file__)))
    assert declaration['knownRepositoryWritersHeld'] is True and declaration['knownArchiveReadersClosed'] is True
    assert declaration['globalReaderAbsenceClaim'] is False
    assert declaration['oldArchive']==str(OLD) and declaration['retainedBundle']==str(BUNDLE)
    assert declaration['adviceScope']=='fully consumed page-aligned ranges on the exact two read-only archive FDs only'
    assert hasattr(os,'posix_fadvise') and hasattr(os,'POSIX_FADV_DONTNEED')
    guarded('initial')
    output=pathlib.Path(__import__('tempfile').mkdtemp(prefix='executed-r3-',dir=HERE));fsync_owned_dirs()
    phase='original-proof-input-freeze'
    pins=json.loads(small(HERE/'PINS.json'))
    watch=[OLD,BUNDLE,CLOSURE,RESTORE_RESULT,declaration_path,ROOT/'.git/config',pathlib.Path('/usr/bin/git'),*[pathlib.Path(p) for p in pins['smallEvidence']]]
    before=[meta(p) for p in watch];write('BEFORE.json',before)
    for p,h in pins['smallEvidence'].items():assert digest(small(p))==h,p
    closure_compressed=small(CLOSURE);assert digest(closure_compressed)==CLOSURE_SHA
    with gzip.GzipFile(fileobj=io.BytesIO(closure_compressed)) as g:
        closure_bytes=g.read(512*1024+1);assert len(closure_bytes)<=512*1024 and not g.read(1)
    ids=closure_bytes.decode('ascii').splitlines();assert len(ids)==len(set(ids))==4243
    assert ids==sorted(ids) and all(len(i)==40 and all(c in '0123456789abcdef' for c in i) for i in ids)
    closure=set(ids)
    assert OLD_COMMIT in closure and NEW_COMMIT in closure,'Old262 must exist in actual restored retained closure'
    restore_bytes=small(RESTORE_RESULT);assert digest(restore_bytes)==RESTORE_SHA
    restore=json.loads(restore_bytes)
    assert restore['PASS'] and restore['sourceCommit']==NEW_COMMIT and restore['noPrerequisites'] and restore['noAlternates']
    assert restore['fsckFullStrict'] and restore['exactSourceReachableClosureAndNoExtras'] and restore['reachableObjects']==4243
    archive_pins={r['path']:r for r in before if r['path'] in [str(OLD),str(BUNDLE)]}
    advice_raw=BudgetFile(output/'CONSUMED-RANGE-ADVICE.jsonl.gz')
    advice_writer=gzip.GzipFile(fileobj=advice_raw,mode='wb',mtime=0)
    phase='fresh-retained-source-bundle-body-pin'
    new_hash=stream_hash(BUNDLE);assert new_hash=={'bytes':1711151088,'sha256':BUNDLE_SHA}
    phase='actual-old-ancestor-tree-metadata'
    refs_before=git(['show-ref','--head'])
    git(['merge-base','--is-ancestor',OLD_COMMIT,NEW_COMMIT])
    commit=git(['cat-file','commit',OLD_COMMIT],max_output=MIB)
    assert hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==OLD_COMMIT
    old_tree=commit.splitlines()[0].decode().removeprefix('tree ');assert old_tree in closure and len(old_tree)==40
    independently_checked_rows,checked_tree_oids=checked_raw_tree(old_tree,closure)
    raw_tree=git(['ls-tree','-r','-t','-z',OLD_COMMIT])
    expected={};dirs=set();tree_rows=[]
    for raw in raw_tree.split(b'\0'):
        if not raw:continue
        fields,name=raw.split(b'\t',1);mode,kind,oid=fields.decode('ascii').split();name=name.decode('utf8');safe_name(name)
        assert oid in closure,'Every old tree/blob identity must exist in retained bundle closure'
        assert name not in expected and name not in dirs
        row={'path':name,'mode':mode,'type':kind,'oid':oid,'retainedInVerifiedBundleClosure':True};tree_rows.append(row)
        if kind=='tree':assert mode=='040000';dirs.add(name)
        else:
            assert kind=='blob' and mode in ['100644','100755'],'Submodule/symlink/unsupported old tree requires separate preservation'
            expected[name]=row
    assert sorted(tree_rows,key=lambda r:r['path'])==sorted(independently_checked_rows,key=lambda r:r['path']),'Recursive raw-tree identities and listing disagree'
    assert len(expected)==5564,'Actual historical source membership must match independently retained oracle'
    write('OLD-TREE.json.gz',gzip.compress(json.dumps({'commit':OLD_COMMIT,'rootTree':old_tree,'entries':tree_rows,'rawTreeOIDsVerified':sorted(checked_tree_oids)},separators=(',',':')).encode()))
    phase='fresh-complete-old-archive-body-pin'
    old_hash=stream_hash(OLD);assert old_hash=={'bytes':2863760699,'sha256':OLD_SHA}
    phase='complete-old-logical-content-coverage'
    seen=set();folded=set();matched=set();total_bytes=0;producer=None;zip_info=None;local_ranges=[]
    mapping=output/'COVERAGE.jsonl.gz'
    with BudgetFile(mapping) as raw_proof,gzip.GzipFile(fileobj=raw_proof,mode='wb',mtime=0) as proof,opened(OLD) as af:
        zip_info=zip_admission(af)
        assert zip_info['comment']==OLD_COMMIT,'Actual Git archive source comment must match pinned262'
        af.seek(0)
        with zipfile.ZipFile(af) as z:
            infos=z.infolist();assert len(infos)==zip_info['entries']
            assert sum(i.file_size for i in infos)<=MAX_INFLATED,'Bound declared total inflation'
            for info in infos:
                guarded('before-member:'+str(entry_rows),False)
                local_ranges.append(member_layout(info,af))
                name=safe_name(info.orig_filename,info.is_dir());assert name not in seen;seen.add(name)
                fold=unicodedata.normalize('NFC',name).casefold();assert fold not in folded;folded.add(fold)
                assert not info.flag_bits&1 and info.compress_type in [zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED]
                mode=info.external_attr>>16;kind=stat.S_IFMT(mode)
                if info.is_dir():
                    assert name in dirs and info.file_size==0 and kind in [0,stat.S_IFDIR]
                    for b in exact_member_bytes(info,af,local_ranges[-1][2]):assert not b
                    assert info.CRC==0,'Empty directory CRC must match its actual zero-byte payload'
                    row={'path':name,'type':'directory','mode':mode,'retainedTree':True,'crc32':info.CRC}
                else:
                    assert name in expected and kind in [0,stat.S_IFREG],'Every regular member needs exact old-tree coverage'
                    wanted=expected[name]
                    if mode:assert bool(mode&0o111)==(wanted['mode']=='100755'),'Preserve executable source semantics'
                    sha=hashlib.sha256();blob=hashlib.sha1(b'blob '+str(info.file_size).encode()+b'\0');crc=0;size=0;small_producer=bytearray()
                    for b in exact_member_bytes(info,af,local_ranges[-1][2]):
                        size+=len(b);assert size<=info.file_size
                        sha.update(b);blob.update(b);crc=binascii.crc32(b,crc)
                        if name=='scripts/release.mjs':
                            assert size<=65536;small_producer.extend(b)
                        guarded('stream-member:'+str(entry_rows),False)
                    assert size==info.file_size and crc&0xffffffff==info.CRC
                    assert blob.hexdigest()==wanted['oid'],'Exact full old member differs from canonical historical Git blob'
                    matched.add(name);total_bytes+=size
                    row={'path':name,'type':'regular','bytes':size,'crc32':crc&0xffffffff,'sha256':sha.hexdigest(),
                         'blobSHA1':blob.hexdigest(),'gitMode':wanted['mode'],'zipMode':mode,
                         'retainedBundleSHA256':BUNDLE_SHA,'retainedBlobOID':wanted['oid'],'retainedViaAncestor':OLD_COMMIT}
                    if name=='scripts/release.mjs':producer=bytes(small_producer)
                ledger_row(proof,raw_proof,row,MIB);entry_rows+=1
            assert matched==set(expected),'No old raw/source/review/art/dataset member omitted'
            end=0
            for start,stop,data_start in sorted(local_ranges):
                assert start==end and stop>=start,'Unexplained local ZIP prefix/gap/overlap requires preservation'
                end=stop
            assert end==zip_info['centralOffset'],'Unexplained bytes before central directory require preservation'
    assert producer is not None;write('HISTORIC-RELEASE.mjs',producer)
    advice_writer.close();advice_writer=None;advice_raw.close();advice_raw=None;advice_durable=advice_ledgered
    phase='readback-originals-and-final-proof'
    assert git(['show-ref','--head'])==refs_before,'Source refs changed during read-only audit'
    after=[meta(p) for p in watch];write('AFTER.json',after);assert after==before,'Original bytes identity metadata changed during audit'
    guarded('final')
    proof_hash=stream_hash(mapping)
    write('RESULT.json',{'schema':1,'status':'PASS: exact old logical contents retained; no retirement executed',
        'oldArchive':str(OLD),'oldWholeHash':old_hash,'retainedSourceBundle':str(BUNDLE),'retainedWholeHash':new_hash,
        'oldCommit':OLD_COMMIT,'oldRootTree':old_tree,'retainedSourceCommit':NEW_COMMIT,'retainedClosureObjects':4243,
        'freshAncestorVerified':True,'canonicalRawTreeOIDsVerified':sorted(checked_tree_oids),'oldTreeRegularFiles':5564,'matchedRegularMembers':len(matched),'totalZIPEntries':entry_rows,
        'allMemberCRCsPassed':True,'allRawCompressedPayloadsConsumedAtExactEOF':True,'allCanonicalGitBlobRawBodiesEqual':True,'everyOldTreeIdentityInRetainedClosure':True,
        'unexplainedUniqueMembers':0,'totalInflatedBytes':total_bytes,'actualZIPStructure':zip_info,
        'producerExtractedSHA256':digest(producer),'originalMetadataAndRefsUnchanged':True,'proofPhysicalBytesBeforeResult':proof_budget(),'coverageProof':proof_hash,
        'commands':commands,'resourceSamples':samples,'adviceAttemptCount':advice_attempts,'completedReturnedAdviceCalls':advice_calls,'completedLedgerOperations':advice_ledgered,
             'durableLedgeredCalls':advice_durable,'lastHint':last_hint,'requestedHintRangeBytes':advice_requested_bytes,'returnedHintRangeBytes':advice_bytes,
        'adviceScope':'Only already-read fully consumed page-aligned ranges on pinned read-only oldZIP/bundle FDs; repeated ranges may overlap; residency/recovery/causality unguaranteed',
        'limits':['No fresh1.7GB restore: actual prior independent complete restore tied to fresh unchanged bundle body/closure receipt',
                  'Canonical Git SHA1 correspondence supplemented by full member SHA256/CRC/byte counts',
                  'Retiring old ZIP would discard exact container encoding, not these retained raw contents',
                  'Root and separate result inspection still judge retirement; this program never unlinks/renames/rewrites inputs']})
    print(json.dumps({'status':'PASS coverage only; root retirement judgment pending','output':str(output),'entries':entry_rows,'regular':len(matched)}))
except BaseException as error:
    original_trace=traceback.format_exc()
    advice_close_error=None
    try:
        if advice_writer:advice_writer.close();advice_writer=None
        if advice_raw:advice_raw.close();advice_raw=None;advice_durable=advice_ledgered
    except BaseException as secondary:advice_close_error=repr(secondary)
    failure={'schema':1,'status':'REFUSED/FAILED: retirement withheld','phase':phase,'error':original_trace,'adviceReceiptCloseError':advice_close_error,'adviceAttemptCount':advice_attempts,'completedReturnedAdviceCalls':advice_calls,'completedLedgerOperations':advice_ledgered,
             'durableLedgeredCalls':advice_durable,'lastHint':last_hint,'requestedHintRangeBytes':advice_requested_bytes,'returnedHintRangeBytes':advice_bytes,
             'output':str(output) if output else None,'completedMemberRows':entry_rows,'commands':commands,'samples':samples}
    if output:
        try:write('FAILURE.json',failure)
        except BaseException as secondary:failure['failureReceiptError']=repr(secondary)
        post={'status':'UNKNOWN: failure postflight not completed'}
        try:
            guarded('failure-metadata-postflight')
            assert before is not None,'No complete prior input snapshot'
            after=[meta(p) for p in watch];write('FAILED-AFTER.json',after);assert after==before
            post={'status':'PASS: source archive/bundle/proof metadata unchanged after failed attempt','wholeBodiesRehashedAfterFailure':False}
        except BaseException as secondary:post={'status':'UNKNOWN/REFUSED: postflight incomplete','secondaryError':traceback.format_exc()}
        try:write('FAILED-POSTFLIGHT.json',post)
        except BaseException as secondary:post['receiptError']=repr(secondary)
        print(json.dumps(post),file=sys.stderr)
    print(json.dumps(failure),file=sys.stderr);sys.exit(1)
