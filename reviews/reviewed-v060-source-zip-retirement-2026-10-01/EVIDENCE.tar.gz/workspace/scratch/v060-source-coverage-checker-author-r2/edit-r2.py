from pathlib import Path
p=Path('/workspace/scratch/v060-source-coverage-checker-author-r2/coverage.py')
s=p.read_text()
s=s.replace('import selectors, subprocess, sys, time, traceback, unicodedata, zipfile','import selectors, subprocess, sys, time, traceback, unicodedata, zipfile, zlib')
a=s.index('def meta(p):');b=s.index('class ConsumedArchiveReader',a)
s=s[:a]+'''def fd_meta(fd,p):
    s=os.fstat(fd);assert stat.S_ISREG(s.st_mode)
    attrs={n:base64.b64encode(os.getxattr(fd,n)).decode() for n in os.listxattr(fd)}
    return {'path':str(p),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,
            'bytes':s.st_size,'blocks':s.st_blocks,'atimeNs':s.st_atime_ns,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'xattrs':attrs}
def directory_identity(s):
    return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)
def anchored_open(p):
    # Original absolute parent components are held as descriptors. Parent
    # namespace/inode/type/mode/ownership are checked; directory times can change
    # for unrelated sibling receipts and are deliberately not frozen.
    p=pathlib.Path(p);assert p.is_absolute() and '..' not in p.parts
    chain=[];fd=None
    try:
        rootfd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME)
        chain.append((rootfd,None,'/',directory_identity(os.fstat(rootfd))))
        for name in p.parts[1:-1]:
            parent=chain[-1][0]
            child=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=parent)
            pin=directory_identity(os.fstat(child));chain.append((child,parent,name,pin))
            assert pin==directory_identity(os.stat(name,dir_fd=parent,follow_symlinks=False))
        parent=chain[-1][0]
        fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=parent)
        pinned=fd_meta(fd,p)
        assert os.fstat(fd)==os.stat(p.name,dir_fd=parent,follow_symlinks=False),'Opened original path binding changed'
        return fd,chain,pinned
    except BaseException:
        if fd is not None:os.close(fd)
        for row in reversed(chain):os.close(row[0])
        raise
def anchored_check(fd,chain,p,pinned):
    assert fd_meta(fd,p)==pinned,'Input FD full metadata/xattrs changed'
    assert os.fstat(fd)==os.stat(pathlib.Path(p).name,dir_fd=chain[-1][0],follow_symlinks=False),'Input leaf binding changed'
    assert directory_identity(os.stat('/',follow_symlinks=False))==chain[0][3]
    for child,parent,name,pin in chain[1:]:
        assert directory_identity(os.fstat(child))==pin
        assert directory_identity(os.stat(name,dir_fd=parent,follow_symlinks=False))==pin,'Original parent binding changed'
def anchored_close(fd,chain):
    try:os.close(fd)
    finally:
        for row in reversed(chain):os.close(row[0])
def meta(p):
    fd,chain,pinned=anchored_open(p)
    try:anchored_check(fd,chain,p,pinned);return pinned
    finally:anchored_close(fd,chain)
def fd_identity(s):
    return {k:getattr(s,'st_'+k) for k in ['dev','ino','mode','uid','gid','nlink','size','mtime_ns','ctime_ns','atime_ns']}
class AnchoredRegularReader(io.FileIO):
    def __init__(self,p):
        self.path=pathlib.Path(p)
        fd,self.chain,self.pinned=anchored_open(self.path)
        try:super().__init__(fd,'rb',closefd=True)
        except BaseException:anchored_close(fd,self.chain);raise
    def close(self):
        if not self.closed:
            try:anchored_check(self.fileno(),self.chain,self.path,self.pinned)
            finally:
                try:super().close()
                finally:
                    for row in reversed(self.chain):os.close(row[0])
active_proof_files=set()
FAILURE_RESERVE=64*1024
GZIP_BUFFER_RESERVE=64*1024
BLOCK=4096

def proof_budget(extra=0,failure=False):
    assert output
    physical=output.stat().st_blocks*512+sum(p.stat().st_blocks*512 for p in output.iterdir() if p.is_file())
    pending=len(active_proof_files)*GZIP_BUFFER_RESERVE
    projected=physical+pending+((extra+BLOCK-1)//BLOCK)*BLOCK+(BLOCK if extra else 0)
    assert projected<=PROOF_LIMIT-(0 if failure else FAILURE_RESERVE),'Aggregate block-rounded own proof cap including pending gzip/footer buffers'
    v=os.statvfs(HERE)
    assert v.f_bavail*v.f_frsize>=MIB+((extra+BLOCK-1)//BLOCK)*BLOCK,'Fresh durable1MiB reserve for every receipt operation'
    return physical
class BudgetFile(io.FileIO):
    # Exclusive unbuffered owned receipts only; never wraps an input FD.
    def __init__(self,p,failure=False):
        self.failure=failure;proof_budget(BLOCK,failure)
        super().__init__(p,'xb');active_proof_files.add(self)
        proof_budget(failure=failure)
    def write(self,b):
        proof_budget(len(b),self.failure)
        n=super().write(b);assert n==len(b),'Owned receipt short write'
        proof_budget(failure=self.failure);return n
    def close(self):
        if not self.closed:
            try:
                super().flush();os.fsync(self.fileno())
            finally:
                try:super().close()
                finally:active_proof_files.discard(self)
            proof_budget(failure=self.failure)
def ledger_row(writer,raw,row,limit):
    b=(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\\n').encode();assert len(b)<=65536
    writer.write(b);writer.flush(zlib.Z_SYNC_FLUSH)
    assert raw.tell()+32<=limit,'Bound compressed mapping/advice including final footer'
    proof_budget()
''' +s[b:]
s=s.replace("super().__init__();self.p=pathlib.Path(p);no_links(self.p)","super().__init__();self.p=pathlib.Path(p)")
s=s.replace("        self.fd=os.open(self.p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)\n        st=os.fstat(self.fd);assert stat.S_ISREG(st.st_mode)","        self.fd,self.chain,self.full_pin=anchored_open(self.p)\n        assert self.full_pin==archive_pins[str(self.p)]\n        st=os.fstat(self.fd);assert stat.S_ISREG(st.st_mode)")
s=s.replace("                assert fd_identity(os.fstat(self.fd))==self.pin,'Pinned read-only FD metadata changed before advice'", "                anchored_check(self.fd,self.chain,self.p,self.full_pin)\n                assert fd_identity(os.fstat(self.fd))==self.pin,'Pinned read-only FD metadata changed before advice'")
s=s.replace("                assert fd_identity(os.fstat(self.fd))==self.pin,'Pinned read-only FD metadata changed after advice'", "                anchored_check(self.fd,self.chain,self.p,self.full_pin)\n                assert fd_identity(os.fstat(self.fd))==self.pin,'Pinned read-only FD metadata changed after advice'")
s=s.replace("                advice_writer.write((json.dumps(row,separators=(',',':'))+'\\n').encode())\n                assert advice_raw.tell()<=ADVICE_LIMIT,'Bound and preserve completed advice receipts'", "                ledger_row(advice_writer,advice_raw,row,ADVICE_LIMIT)")
s=s.replace("            try:assert fd_identity(os.fstat(self.fd))==self.pin\n            finally:\n                os.close(self.fd);super().close()", "            try:anchored_check(self.fd,self.chain,self.p,self.full_pin)\n            finally:\n                anchored_close(self.fd,self.chain);super().close()")
a=s.index('    no_links(p)',s.index('def opened(p):'));b=s.index('def guarded(',a)
s=s[:a]+"    return AnchoredRegularReader(p)\n"+s[b:]
a=s.index("    allocated=sum(",s.index('def write('));b=s.index('def small(',a)
s=s[:a]+"    with BudgetFile(output/name,failure=name.startswith(('FAILURE','FAILED-'))) as f:f.write(b)\n"+s[b:]
s=s.replace("    env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1')\n    child=subprocess.Popen(['git','--no-replace-objects','-c','core.fsmonitor=false',*args],cwd=ROOT,env=env,", "    redirects=[k for k in os.environ if k.startswith('GIT_')]\n    assert not redirects,'Inherited Git environment redirects/config are unsupported: '+repr(redirects)\n    assert not (ROOT/'.git/info/grafts').exists() and not (ROOT/'.git/shallow').exists(),'Grafts/shallow metadata unsupported'\n    assert not (ROOT/'.git/objects/info/alternates').exists(),'Alternate object store unsupported'\n    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}\n    env.update(GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null')\n    child=subprocess.Popen(['git','--git-dir='+str(ROOT/'.git'),'--work-tree='+str(ROOT),'--no-replace-objects',\n                            '-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null','-c','maintenance.auto=false','-c','gc.auto=0',*args],cwd=ROOT,env=env,")
a=s.index('def zip_admission(')
s=s[:a]+'''def checked_raw_tree(root_oid,closure):
    cache={};rows=[];paths=set();trees=set()
    def descend(oid,prefix,ancestry):
        assert oid in closure and oid not in ancestry,'Unretained/cyclic tree identity'
        if oid not in cache:
            body=git(['cat-file','tree',oid],max_output=MIB)
            assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\\0'+body).hexdigest()==oid,'Raw tree Git identity differs'
            entries=[];at=0;names=set()
            while at<len(body):
                space=body.index(b' ',at);zero=body.index(b'\\0',space+1);end=zero+21;assert end<=len(body)
                mode=body[at:space].decode('ascii');name=body[space+1:zero].decode('utf8');child=body[zero+1:end].hex()
                assert mode in ['40000','100644','100755'] and '/' not in name
                safe_name(name);assert name not in names;names.add(name)
                entries.append((mode,name,child));at=end
            assert at==len(body);cache[oid]=entries;trees.add(oid)
        for mode,name,child in cache[oid]:
            path=prefix+name;safe_name(path);assert path not in paths;paths.add(path)
            assert child in closure
            is_tree=mode=='40000'
            rows.append({'path':path,'mode':'040000' if is_tree else mode,'type':'tree' if is_tree else 'blob','oid':child,'retainedInVerifiedBundleClosure':True})
            assert len(rows)<=MAX_ENTRIES
            if is_tree:descend(child,path+'/',ancestry|{oid})
    descend(root_oid,'',set())
    return rows,trees

def member_layout(info):
    assert info.orig_filename==info.filename,'ZIP original name differs/truncates: unsupported canonical layout'
    safe_name(info.orig_filename,info.is_dir())
    assert info.file_size!=0xffffffff and info.compress_size!=0xffffffff and info.header_offset!=0xffffffff
    extra=info.extra;at=0
    while at<len(extra):
        assert at+4<=len(extra),'Closed extra-field TLV required'
        ident,length=struct.unpack_from('<HH',extra,at);at+=4
        assert at+length<=len(extra) and ident!=1,'Member ZIP64 extras require separately reviewed parser'
        at+=length
    assert at==len(extra)

''' +s[a:]
s=s.replace("prefix='executed-r1-'","prefix='executed-r2-'")
s=s.replace("advice_raw=(output/'CONSUMED-RANGE-ADVICE.jsonl.gz').open('xb')","advice_raw=BudgetFile(output/'CONSUMED-RANGE-ADVICE.jsonl.gz')")
s=s.replace("    raw_tree=git(['ls-tree','-r','-t','-z',OLD_COMMIT])", "    independently_checked_rows,checked_tree_oids=checked_raw_tree(old_tree,closure)\n    raw_tree=git(['ls-tree','-r','-t','-z',OLD_COMMIT])")
s=s.replace("    assert len(expected)==5564", "    assert sorted(tree_rows,key=lambda r:r['path'])==sorted(independently_checked_rows,key=lambda r:r['path']),'Recursive raw-tree identities and listing disagree'\n    assert len(expected)==5564")
s=s.replace("'entries':tree_rows}","'entries':tree_rows,'rawTreeOIDsVerified':sorted(checked_tree_oids)}")
s=s.replace("with mapping.open('xb') as raw_proof", "with BudgetFile(mapping) as raw_proof")
s=s.replace("                name=safe_name(info.filename,info.is_dir());", "                member_layout(info)\n                name=safe_name(info.orig_filename,info.is_dir());")
s=s.replace("                proof.write((json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\\n').encode());entry_rows+=1\n                assert raw_proof.tell()<=PROOF_LIMIT-MIB,'Bound mapping allocation; preserve partial proof on refusal'", "                ledger_row(proof,raw_proof,row,MIB);entry_rows+=1")
s=s.replace("'freshAncestorVerified':True,", "'freshAncestorVerified':True,'canonicalRawTreeOIDsVerified':sorted(checked_tree_oids),")
s=s.replace("'originalMetadataAndRefsUnchanged':True,", "'originalMetadataAndRefsUnchanged':True,'proofPhysicalBytesBeforeResult':proof_budget(),")
p.write_text(s)
