# Source-only exact v0.6 container retirement r3

New, independently owned author packet. Original r1/r2 source, size failures,
drafts, rejecting reviews and every archive/proof/history input remain in place. This
candidate has not been imported, compiled or executed. Author work reads source
and the rejection only: no archive bodies, Git, cache hints, browser, Node,
restore, deletion or transaction execution.

The sole destructive instruction remains the literal parent-dirfd unlink of
`/workspace/Roguelike-deckbuilder/releases/0.6.0/hollowpact-0.6.0-source.zip`.
The retained successor remains the literal v0.8 source bundle. PINS.json is
byte-identical to r1: accepted complete RESULT/AFTER and actual independent
coverage review, whole hashes, counts and coverage booleans remain mandatory.
Anchored no-follow parents, noatime read-only leaves, held descriptors, unchanged
full metadata/xattrs, ownership and nlink1 for old and successor remain mandatory.
Scratch, old and successor must now share a device so free-space measurements
refer to the target filesystem.

The two blocking r1 source findings are addressed as follows:

* Before ARMED and before any destructive attempt, reserve an exclusive 0600
  regular owned nlink1 `FAILURE-SLOT.json`, physically allocate its entire
  16 KiB with posix_fallocate, initialize padded valid JSON, fsync the slot and
  output/author directories, and check allocation against the 64 KiB budget.
  Unsupported or failed preallocation refuses before unlink. Hold its descriptor
  through the transaction. Each update writes exactly the existing 16 KiB and
  fsyncs; exception reporting invokes no resource guard, metadata guard, receipt
  creation, directory entry creation or file extension. Error text is bounded to
  1024 Unicode characters so worst-case JSON escaping fits the slot. A partly
  created RETIRED receipt cannot consume the reserved slot.
* Set the in-memory unlink result to `unknown` and durably record the same state
  before calling unlink. `unlinkIssued` is false only for `not-attempted`, null
  for `unknown`, and true when the syscall returned either success or an OSError.
  Returned success is durably checkpointed before postconditions. An asynchronous
  exception between the syscall and assignment therefore reports unknown, never
  false. Defer INT/TERM/HUP/QUIT/USR1/USR2/ALRM only through this narrow checkpoint
  and restore the prior mask afterward. Close bookkeeping also distinguishes
  not-attempted, unknown and returned-success; do not retry a potentially completed
  close. Before clearing the held descriptor or invoking close, fsync a durable
  close-UNKNOWN checkpoint. If that write fails, the descriptor stays in the held
  list for finally cleanup. After close returns, fsync returned-success before
  postconditions. This fixes the independent r2 finding that only in-memory close
  state changed before close. Independently observed path absence has its own
  nullable field.

Resource policy is unchanged: per-operation 24 MiB RSS, at least the operation
budget plus 512 MiB cgroup reserve, at most 64 KiB physically allocated output
receipts including directory allocation, and at least that receipt budget plus
1 MiB filesystem free space at admission/normal guards. The source-read ceiling
is explicitly revised from 8 KiB to 16 KiB to contain the safety repair clearly.
The whole author packet remains at most 48 KiB logical bytes. No broader runtime
or storage authority is added.

ROOT integration, only after a fresh distinct source acceptance:

1. Have the separate standard_sol_retirement_review reviewer inspect the frozen
   FROZEN-FILES.json and exact source hash. Its accepted review must contain the
   candidate source SHA256 literally. Earlier r1/r2 reviews cannot authorize
   this candidate. This author makes no source acceptance or producer judgment.
2. Establish a genuine narrow known-actor hold for old/successor, proof/control
   readers and writers, output directory, and repository ref writers. Independently
   verify the ref hold and decide that removing this one encoding is wise while
   preserving unique source/art/data, rollback baselines, manifests and reviews.
   JSON assertions alone cannot create these holds or establish global absence.
3. Create an external retained judgment JSON with sourceSHA256, pinsSHA256,
   sourceReviewPath, sourceReviewSHA, sourceReviewAccepted=true, actualReviewSHA,
   action=retire_exact_old_source_zip_encoding, literal target and successor,
   ownerAllowsReviewedRetirement=true, knownActorsHeld=true,
   globalAbsenceClaim=false, rootJudgementApproved=true, and a concrete rationale
   of 40–2048 characters. Bind all fields to this freeze and the actual acceptance.
4. While the genuine hold remains active, ROOT alone may invoke:
   `python -I /workspace/scratch/standard-sol-v060-retirement-author-r3/retire.py --root-approved-one-container-retirement /absolute/retained-judgment.json`.
   Keep assertions enabled. No author or source reviewer runs this transaction.
5. Inspect ARMED.json, FAILURE-SLOT.json, any RETIRED.json, the actual target
   absence, retained successor/proof/sibling identities and hashes, and protected
   refs. Preserve every receipt, including incomplete runs. Release the hold only
   after inspection. A completed FAILURE-SLOT.json says RETIRED and binds the
   RETIRED receipt hash; an incomplete slot never substitutes for inspection.

Limits remain explicit. No atomic compare/unlink, global open-FD absence,
guaranteed reclaimed amount, exclusive attribution or automatic rollback is
claimed. SIGKILL, power loss, hardware/filesystem I/O failure and other abrupt
termination cannot guarantee a final failure report. A slot overwrite can be
torn or unparsable after abrupt failure; a durable UNKNOWN checkpoint is a
conservative attempt marker, not a recovery protocol. Even a returned-success
checkpoint precedes parent fsync and subsequent postconditions. Any interrupted,
unknown, malformed or failed transaction requires independent inspection and
must never be interpreted as proof that no deletion was issued. Signal masking
does not remove the need for genuine actor holds.
