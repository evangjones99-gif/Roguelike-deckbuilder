"""Retire only 150 verified redundant backup links after a separate source gate.

Every historical served media path and byte stays. No directory removal, body
write, permissions/xattrs/timestamp operation, broad glob deletion or retry.
"""
import hashlib, importlib.util, json, os, stat, subprocess, sys
from pathlib import Path

REPO=Path('/workspace/Roguelike-deckbuilder')
OUT=Path('/workspace/scratch/historical-dist-media-dedup-transaction-root-r1')
BACK=OUT/'BACKUPS'
SOURCE=Path('/workspace/scratch/historical-dist-media-dedup-root-r2.py')
SOURCE_SHA='5ce1eb59a1a5d887107f9547cdc321628bcb2e1b5629be081268808d6f8f688c'
PLAN=Path('/workspace/scratch/standard-sol-historical-dist-media-dedup-proposal-r1/IDENTITIES-r2.json')
PLAN_SHA='5927df801b483e3cab163b1813502d4d761e2c225bc76318fead9a766798cbbb'
OWN_OUT_ID=None
REMOVED=[]

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(name,body):
    current=os.stat(OUT,follow_symlinks=False)
    assert OWN_OUT_ID==(current.st_dev,current.st_ino) and stat.S_ISDIR(current.st_mode)
    with (OUT/name).open('x') as f:
        json.dump(body,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    fd=os.open(OUT,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME)
    try:os.fsync(fd)
    finally:os.close(fd)

def git(args):
    return subprocess.run(['git','-c','gc.auto=0',*args],cwd=REPO,check=True,
                          capture_output=True,text=True,timeout=45).stdout.strip()

def run():
    global OWN_OUT_ID
    judgment_path,gate_path=map(Path,sys.argv[1:])
    judgment=json.loads(judgment_path.read_bytes());gate=json.loads(gate_path.read_bytes())
    assert judgment['decision']=='AUTHORIZE_ONLY_150_POSTVERIFIED_REDUNDANT_BACKUP_LINKS'
    assert judgment['allKnownWritersPaused'] and judgment['acceptNoOriginalInodeOrCtimeRollback']
    assert gate['decision']=='ACCEPT_EXACT_150_BACKUP_RETIREMENT_SCRIPT_FOR_SEPARATE_EXECUTION'
    assert gate['scriptSHA256']==digest(__file__) and gate['judgmentSHA256']==digest(judgment_path)
    assert digest(judgment['postGatePath'])==judgment['postGateSHA256']
    assert digest(SOURCE)==SOURCE_SHA and digest(PLAN)==PLAN_SHA
    assert not git(['status','--porcelain'])
    head=git(['rev-parse','HEAD']);assert head==judgment['pushedHead']
    assert git(['ls-remote','origin','refs/heads/codex/lanternbound-production']).split()[0]==head
    spec=importlib.util.spec_from_file_location('immutable_dedup_inspection',SOURCE)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    rows=json.loads(PLAN.read_bytes())['files']
    assert len(rows)==200
    original=json.loads((OUT/'RESULT.json').read_bytes())
    assert original['normal'] and original['failure'] is None and len(original['replaced'])==150
    assert original['originalBackupsRetained']
    targets=[r for r in rows if r['stage']!='first-five-opening-stage-r2']
    anchors={r['relative']:r for r in rows if r['stage']=='first-five-opening-stage-r2'}
    assert len(targets)==150 and len(anchors)==50
    assert sorted(os.listdir(BACK))==[f'{i:03d}.original' for i in range(150)]
    current_records=[];backup_records=[]
    for row in rows:
        current=helper.inspect(row['path']);anchor=anchors[row['relative']]
        assert current['sha256']==row['sha256'] and current['bytes']==row['bytes']
        assert current['metadata']['inode']==anchor['metadata']['inode'] and current['metadata']['nlink']==4
        assert current['xattrs']==anchor['xattrs']
        for k in ('dev','mode','uid','gid','size','atime_ns','mtime_ns'):
            assert current['metadata'][k]==anchor['metadata'][k]
        current_records.append(current)
    for i,row in enumerate(targets):
        old=helper.inspect(BACK/f'{i:03d}.original')
        assert old['sha256']==row['sha256'] and old['bytes']==row['bytes'] and old['metadata']['nlink']==1
        assert old['xattrs']==row['xattrs']
        for k in ('dev','inode','mode','uid','gid','size','allocated','atime_ns','mtime_ns'):
            assert old['metadata'][k]==row['metadata'][k]
        record=original['replaced'][i]
        assert record['index']==i and record['original']==row and record['backup']==str(BACK/f'{i:03d}.original')
        backup_records.append(old)
    # Output ownership becomes established only after every preflight passes.
    assert not (OUT/'RETIREMENT-BEFORE.json').exists() and not (OUT/'RETIREMENT-RESULT.json').exists()
    held=os.stat(OUT,follow_symlinks=False);OWN_OUT_ID=(held.st_dev,held.st_ino)
    write('RETIREMENT-BEFORE.json',{'head':head,'judgment':judgment,'gate':gate,
                                  'currentFiles':current_records,'backupFiles':backup_records})
    chain=helper.parents(BACK)
    try:
        parent=chain[-1]
        for i,old in enumerate(backup_records):
            name=f'{i:03d}.original'
            observed=os.stat(name,dir_fd=parent,follow_symlinks=False)
            assert helper.metadata(observed)==old['metadata']
            # Each unlink intent is durable before the finite, exact leaf action.
            write(f'RETIREMENT-PREPARED-{i:03d}.json',{'index':i,'backup':old,'action':'unlink one verified redundant backup link'})
            os.unlink(name,dir_fd=parent);helper.fsync_parent(parent)
            REMOVED.append({'index':i,'path':old['path'],'oldSHA256':old['sha256']})
            write(f'RETIREMENT-COMPLETE-{i:03d}.json',REMOVED[-1])
        assert not os.listdir(BACK)
    finally:
        for fd in reversed(chain):os.close(fd)
    after=[]
    for row in rows:
        current=helper.inspect(row['path']);anchor=anchors[row['relative']]
        assert current['sha256']==row['sha256'] and current['bytes']==row['bytes']
        assert current['metadata']['inode']==anchor['metadata']['inode'] and current['metadata']['nlink']==4
        after.append(current)
    write('RETIREMENT-RESULT.json',{'normal':True,'removed':REMOVED,'currentFiles':after,
                                   'all200PathsAndBytesPreserved':True,
                                   'originalInodesRetired':150,'originalCtimeRollbackImpossible':True,
                                   'diskFreeObservedAfter':os.statvfs(OUT).f_bavail*os.statvfs(OUT).f_frsize,
                                   'qualification':'Measured filesystem delta includes own journals/other allocation; original distinct-inode encoding is no longer retained. Unique sources/art/reviews/releases and all served paths remain.'})
    print(json.dumps({'normal':True,'retiredRedundantBackupLinks':150,'mediaPathsPreserved':200}))

if __name__=='__main__':
    try:run()
    except BaseException as error:
        if OWN_OUT_ID is not None:write('RETIREMENT-FAILURE.json',{'error':repr(error),'removed':REMOVED,'noAutomaticRetryOrCleanup':True})
        raise
