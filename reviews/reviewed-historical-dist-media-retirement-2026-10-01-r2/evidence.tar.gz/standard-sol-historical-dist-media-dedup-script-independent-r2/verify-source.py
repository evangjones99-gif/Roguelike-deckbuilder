import os,json,hashlib,ast,threading,time,resource,subprocess,traceback
from pathlib import Path
O=Path('/workspace/scratch/standard-sol-historical-dist-media-dedup-script-independent-r2')
S=Path('/workspace/scratch/historical-dist-media-dedup-root-r2.py');J=Path('/workspace/scratch/historical-dist-media-dedup-judgment-root-r1.json')
P=Path('/workspace/scratch/standard-sol-historical-dist-media-dedup-proposal-r1/IDENTITIES-r2.json');R=Path('/workspace/Roguelike-deckbuilder')
CG=Path('/sys/fs/cgroup');W=64*1048576;RES=512*1048576;resource.setrlimit(resource.RLIMIT_DATA,(W,W))
start=time.monotonic()
def row():
 q={};s=Path('/proc/self/status').read_text()
 for line in s.splitlines():
  if line.startswith(('VmRSS:','VmHWM:')):k,n,u=line.split();assert u=='kB';q[k[:-1]]=int(n)*1024
 c=int((CG/'memory.current').read_text());m=int((CG/'memory.max').read_text());f=os.statvfs(O)
 return dict(elapsed=time.monotonic()-start,current=c,maximum=m,headroom=m-c,free=f.f_bavail*f.f_frsize,events=(CG/'memory.events').read_text(),**q)
initial=row();assert initial['headroom']>=W+RES and initial['VmRSS']<=W and initial['VmHWM']<=W
samples=[];stop=threading.Event();breaches=[]
def valid(t):return t['maximum']==initial['maximum'] and t['events']==initial['events'] and t['current']-initial['current']<=W and t['headroom']>=RES and t['free']>=1048576 and t['VmRSS']<=W and t['VmHWM']<=W
def monitor():
 while not stop.is_set():
  t=row();samples.append(t)
  if not valid(t):breaches.append(t);stop.set()
  stop.wait(.01)
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  cap=1048576 if p==P else 262144
  assert os.fstat(fd).st_size<=cap;out=bytearray()
  while True:
   b=os.read(fd,16384)
   if not b:break
   out.extend(b)
  return bytes(out)
 finally:os.close(fd)
def h(d):return hashlib.sha256(d).hexdigest()
def git(*args):return subprocess.run(['git','-c','gc.auto=0',*args],cwd=R,check=True,capture_output=True,timeout=15).stdout
t=threading.Thread(target=monitor);t.start();failure=None;proof=None
try:
 sb=read(S);jb=read(J);pb=read(P)
 assert h(sb)=='5ce1eb59a1a5d887107f9547cdc321628bcb2e1b5629be081268808d6f8f688c'
 assert len(pb)==581175
 assert h(jb)=='6fbee42d877e5d48df0b5df1d52f4cfce513a40c5776c4824bf1059f6a2966fa'
 assert h(pb)=='5927df801b483e3cab163b1813502d4d761e2c225bc76318fead9a766798cbbb'
 j=json.loads(jb);p=json.loads(pb);tree=ast.parse(sb);names=['first-five-opening-stage-r2','first-five-opening-hand-cue-stage-r1','first-five-opening-hand-cue-terminal-stage-r1','first-five-opening-readout-stage-r1']
 assert j['immutableFreshStageOnly']==names and j['amendedControls']=={str(R/'AGENTS.md'):'7407aa5f2336bd21981f7a6d484fb44fdd3dc14fcd083a8eb6982f26dae6b189'}
 assert j['pushedHead']=='d853e9e33b51a933c8d547ff50a692b596863fb7' and j['backupRetirementAuthorized'] is False
 assert len(p['files'])==200 and p['anchor']==names[0] and p['targetStages']==names[1:]
 sets={name:{q['relative'] for q in p['files'] if q['stage']==name} for name in names};assert all(len(v)==50 for v in sets.values()) and all(v==sets[names[0]] for v in sets.values())
 assert len({(q['metadata']['dev'],q['metadata']['inode']) for q in p['files']})==200
 anchors={q['relative']:q for q in p['files'] if q['stage']==names[0]}
 for q in p['files']:
  rel=Path(q['relative']);assert len(rel.parts)==2 and rel.parts[0] in ('art','audio') and rel.suffix in ('.png','.wav')
  assert q['path']==str(Path('/workspace/scratch')/q['stage']/'dist'/rel) and q['sha256']==anchors[q['relative']]['sha256'] and q['metadata']['nlink']==1
 controls=[]
 for c in p['controls']:
  b=read(Path(c['path']));expected=j['amendedControls'].get(c['path'],c['sha256']);assert h(b)==expected
  controls.append(dict(path=c['path'],sha256=h(b),bytes=len(b),amended=c['path'] in j['amendedControls']))
 current=read(R/'AGENTS.md');old=git('show','2380db3:AGENTS.md');hold=current.replace(old,b'',1) if old in current else None
 paragraph=b'Four historical scratch `dist` media trees are now designated immutable and fresh-stage-only:'
 assert current.count(paragraph)==1
 lines=current.splitlines(keepends=True);idx=next(i for i,l in enumerate(lines) if l.startswith(paragraph));assert lines[idx+1].strip()==b''
 reconstructed=b''.join(lines[:idx]+lines[idx+2:]);assert reconstructed==old
 assert git('rev-parse','HEAD').strip().decode()==j['pushedHead'] and not git('status','--porcelain')
 remote=git('ls-remote','origin','refs/heads/codex/lanternbound-production').decode().strip()
 assert remote.split()==[j['pushedHead'],'refs/heads/codex/lanternbound-production']
 calls=[]
 for n in ast.walk(tree):
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute):
   if isinstance(n.func.value,ast.Name):calls.append(n.func.value.id+'.'+n.func.attr)
 assert not any(c in calls for c in ['os.unlink','os.remove','os.chmod','os.utime','os.setxattr','os.removexattr','shutil.rmtree'])
 assert calls.count('os.link')==2 and calls.count('os.replace')==1
 assert not os.path.lexists('/workspace/scratch/historical-dist-media-dedup-transaction-root-r1')
 proof=dict(scriptSHA256=h(sb),judgmentSHA256=h(jb),planSHA256=h(pb),controls=controls,sourceSyntaxParsedNotExecuted=True,planBytes=len(pb),planInputCap=1048576,otherInputCap=262144,cliRemote=remote,
            planPaths=200,anchors=50,recipients=150,distinctPlannedOriginalInodes=200,noMediaBodiesRead=True,
            onlyAGENTSHoldParagraphAppended=True,holdParagraph=lines[idx].decode().strip(),localHead=j['pushedHead'],localClean=True,
            absentTransactionObserved=True,mutatorSummary=dict(osLink=calls.count('os.link'),osReplace=calls.count('os.replace'),forbiddenMediaMutatorsAbsent=True))
 assert not breaches and valid(row())
except BaseException as e:failure=traceback.format_exc()
finally:
 stop.set();t.join(1);final=row();checks=dict(allSampleRows=all(valid(q) for q in samples),final=valid(final),eventsUnchanged=final['events']==initial['events'],maxUnchanged=final['maximum']==initial['maximum'],monitorJoined=not t.is_alive(),noBreaches=not breaches,proofComplete=proof is not None and failure is None)
 result=dict(initial=initial,final=final,samples=samples,checks=checks,breaches=breaches,failure=failure,proof=proof,
             peakDelta=max(q['current']-initial['current'] for q in samples+[final]),minHeadroom=min(q['headroom'] for q in samples+[final]),peakActualRSS=max(q['VmRSS'] for q in samples+[final]),peakActualHWM=max(q['VmHWM'] for q in samples+[final]),ruMaxRSSSeparate=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
             scope='One source-only64MiB cgroup delta+actual selfRSS/HWM process/512reserve; no transaction/media bodies. Git child accounting covered by sampled cgroup delta; baseline after interpreter startup explicitly qualified.',whole=time.monotonic()-start,allOwnFDsClosed=True)
 body=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode();fd=os.open(O/'SOURCE-RECOMPUTATION.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:
  v=memoryview(body)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
 print(json.dumps(dict(sha256=h(body),checks=checks,failure=failure,samples=len(samples),peakDelta=result['peakDelta'],peakActualRSS=result['peakActualRSS'],minHeadroom=result['minHeadroom'])))
 if not all(checks.values()):raise SystemExit(1)
