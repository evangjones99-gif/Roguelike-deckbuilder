import os,json,stat,hashlib,time,resource,traceback
from pathlib import Path
OUT=Path(__file__).parent;S=Path('/workspace/scratch');TX=S/'historical-dist-media-dedup-transaction-root-r1';CG=Path('/sys/fs/cgroup')
WORK=64*1048576;RESERVE=512*1048576
START=time.monotonic();BASE=int((CG/'memory.current').read_text());MAX=int((CG/'memory.max').read_text());EV=(CG/'memory.events').read_text()
ROWS=[];PINS=[]
def save(name,x):
 with (OUT/name).open('x') as f:json.dump(x,f,separators=(',',':'));f.write('\n');f.flush();os.fsync(f.fileno())
def sample():
 c=int((CG/'memory.current').read_text());m=int((CG/'memory.max').read_text());v=os.statvfs(OUT);h=int(next(z.split()[1]for z in Path('/proc/self/status').read_text().splitlines()if z.startswith('VmHWM:')))*1024
 r=[round(time.monotonic()-START,6),c,m,m-c,c-BASE,v.f_bavail*v.f_frsize,h];ROWS.append(r)
 assert m==MAX and r[3]>=RESERVE and r[4]<=WORK and r[5]>=1048576 and h<=WORK and r[0]<=60,r
 assert (CG/'memory.events').read_text()==EV
 return r
def meta(s):return dict(dev=s.st_dev,inode=s.st_ino,mode=s.st_mode,nlink=s.st_nlink,uid=s.st_uid,gid=s.st_gid,size=s.st_size,allocated=s.st_blocks*512,atime_ns=s.st_atime_ns,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def read(path,expected=None,small=False):
 path=Path(path);fds=[]
 try:
  fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW);fds.append(fd)
  for part in path.parts[1:-1]:fd=os.open(part,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);fds.append(fd)
  fd=os.open(path.name,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW,dir_fd=fds[-1]);fds.append(fd)
  before=meta(os.fstat(fd));assert stat.S_ISREG(before['mode'])
  if small:assert before['size']<=1048576
  attrs=lambda:{k:os.getxattr(fd,k).hex()for k in sorted(os.listxattr(fd))}
  x=attrs();h=hashlib.sha256();n=0;b=bytearray()
  while True:
   q=os.read(fd,65536)
   if not q:break
   h.update(q);n+=len(q)
   if small:b.extend(q)
   sample()
  assert n==before['size'] and meta(os.fstat(fd))==before and attrs()==x and meta(os.stat(path.name,dir_fd=fds[-2],follow_symlinks=False))==before
  sha=h.hexdigest()
  if expected:assert sha==expected,(str(path),sha,expected)
  PINS.append(dict(path=str(path),sha256=sha,bytes=n))
  return dict(path=str(path),sha256=sha,bytes=n,metadata=before,xattrs=x),bytes(b)
 finally:
  for fd in reversed(fds):os.close(fd)
def obj(p,expected=None):return json.loads(read(p,expected,True)[1])
def digest(x):return hashlib.sha256(json.dumps(dict(sorted(x.items())),separators=(',',':')).encode()).hexdigest()
def run():
 first=sample();assert first[3]>=WORK+RESERVE and first[5]>=WORK
 resource.setrlimit(resource.RLIMIT_DATA,(WORK,WORK))
 save('ADMISSION.json',dict(admitted=True,workBytes=WORK,reserveBytes=RESERVE,initial=first,events=EV,rlimitDataBytes=WORK,qualification='Fresh cgroup baseline includes interpreter startup; absolute VmHWM also checked. Sampled accounting is not continuous process attribution.'))
 plan=obj(S/'standard-sol-historical-dist-media-dedup-proposal-r1/IDENTITIES-r2.json','5927df801b483e3cab163b1813502d4d761e2c225bc76318fead9a766798cbbb')
 post=obj(S/'standard-sol-historical-dist-media-dedup-post-independent-r1/POST-GATE.json','654fe8481bcfa4afdd7bdfa7194321a9364508a8de5f9256ce00be4de734c94a')
 judgment=obj(S/'historical-dist-media-backup-retirement-judgment-root-r1.json','2a12aa5e5bf79aeda997b9b0aaf09e63384a7ac2945dbb4876ddd50f0e05d567')
 gate=obj(S/'standard-sol-historical-media-backup-retirement-source-independent-r1/SOURCE-GATE.json','8f2e29f9c62eb4b2b034978a8c75162ee0b9fbd2eb2fb79379ad3b29d6d6945c')
 source=read(S/'retire-verified-historical-media-backups-root-r1.py',gate['scriptSHA256'],True)[1].decode()
 guard_source=read(judgment['boundedGuardPath'],gate['boundedGuardSHA256'],True)[1].decode()
 read(S/'historical-dist-media-dedup-root-r2.py','5ce1eb59a1a5d887107f9547cdc321628bcb2e1b5629be081268808d6f8f688c',True)
 assert judgment['decision']=='AUTHORIZE_ONLY_150_POSTVERIFIED_REDUNDANT_BACKUP_LINKS' and judgment['allKnownWritersPaused'] and judgment['acceptNoOriginalInodeOrCtimeRollback'] and judgment['currentChangesPushedBeforeCleanup']
 assert gate['decision']=='ACCEPT_EXACT_150_BACKUP_RETIREMENT_SCRIPT_FOR_SEPARATE_EXECUTION' and judgment['postGateSHA256']==gate['postGateSHA256']==PINS[1]['sha256']
 assert gate['rootHEAD']==judgment['pushedHead']=='d853e9e33b51a933c8d547ff50a692b596863fb7'
 assert 'assert not git([\'status\',\'--porcelain\'])'in source and "git(['ls-remote','origin','refs/heads/codex/lanternbound-production'])"in source
 assert 'os.unlink(name,dir_fd=parent)'in source and 'free\']>=16*1048576' in guard_source
 old=obj(TX/'RESULT.json');after=obj(TX/'AFTER.json');before=obj(TX/'RETIREMENT-BEFORE.json');result=obj(TX/'RETIREMENT-RESULT.json','f2a5b616d87308430e54a6c2e8d53d81ce7964bf06d7eac132e27d4697a59590')
 assert before['gate']==gate and before['judgment']==judgment and before['head']==judgment['pushedHead']
 assert result['normal'] and result['all200PathsAndBytesPreserved'] and result['originalInodesRetired']==150 and result['originalCtimeRollbackImpossible']
 assert len(old['replaced'])==len(before['backupFiles'])==len(result['removed'])==150
 assert before['currentFiles']==result['currentFiles']==after['files'] and len(result['currentFiles'])==200
 originals={r['path']:r for r in plan['files']};anchors={r['relative']:r for r in plan['files']if r['stage']==plan['anchor']};targets=[r for r in plan['files']if r['stage']!=plan['anchor']]
 assert len(originals)==200 and len(anchors)==50 and len(targets)==150
 maps={}
 amendment=obj(S/'historical-dist-media-dedup-judgment-root-r1.json','6fbee42d877e5d48df0b5df1d52f4cfce513a40c5776c4824bf1059f6a2966fa')['amendedControls']
 for c in plan['controls']:
  _,b=read(c['path'],amendment.get(c['path'],c['sha256']),True)
  if 'runtime-freeze-'in c['path']:
   f=json.loads(b);assert len(f['inputs'])==87 and len(f['outputs'])==56 and digest(f['inputs'])==f['sourceDigest'] and digest(f['outputs'])==f['outputsDigest'];maps[Path(f['stage']).name]=f['outputs']
 assert set(maps)=={plan['anchor'],*plan['targetStages']}
 current=[]
 for r in result['currentFiles']:
  oldrow=originals[r['path']];a=anchors[oldrow['relative']];d,_=read(r['path'],oldrow['sha256']);assert d==r and d['bytes']==oldrow['bytes'] and d['xattrs']==oldrow['xattrs']=={}
  assert maps[oldrow['stage']][oldrow['relative']]==d['sha256'] and d['metadata']['inode']==a['metadata']['inode'] and d['metadata']['nlink']==4
  for k in ['dev','mode','uid','gid','size','allocated','atime_ns','mtime_ns']:assert d['metadata'][k]==a['metadata'][k]
  current.append(d)
 assert len({(r['metadata']['dev'],r['metadata']['inode'])for r in current})==50
 retired=[]
 for i,r in enumerate(targets):
  p=obj(TX/f'RETIREMENT-PREPARED-{i:03d}.json');q=obj(TX/f'RETIREMENT-COMPLETE-{i:03d}.json');replacement=old['replaced'][i];b=before['backupFiles'][i]
  assert p['index']==q['index']==i and p['backup']==b==replacement['retainedBackup'] and p['action']=='unlink one verified redundant backup link'
  assert q==result['removed'][i]==dict(index=i,path=str(TX/'BACKUPS'/f'{i:03d}.original'),oldSHA256=r['sha256'])
  assert b['path']==q['path'] and b['sha256']==r['sha256'] and b['bytes']==r['bytes'] and b['metadata']['nlink']==1 and b['xattrs']==r['xattrs']=={}
  for k,v in r['metadata'].items():
   if k!='ctime_ns':assert b['metadata'][k]==v
  assert not os.path.lexists(q['path']);retired.append(b)
 assert sum(r['metadata']['allocated']for r in retired)==91852800
 assert len({(r['metadata']['dev'],r['metadata']['inode'])for r in retired})==150
 assert stat.S_ISDIR(os.stat(TX/'BACKUPS',follow_symlinks=False).st_mode) and os.listdir(TX/'BACKUPS')==[]
 expected=['BEFORE.json','AFTER.json','RESULT.json','BACKUPS','RETIREMENT-BEFORE.json','RETIREMENT-RESULT.json']+[f'{p}-{i:03d}.json'for p in ['PREPARED','REPLACEMENT','RETIREMENT-PREPARED','RETIREMENT-COMPLETE']for i in range(150)]
 assert sorted(os.listdir(TX))==sorted(expected)
 gr=S/'historical-media-backup-retirement-guard-root-r1';g=obj(gr/'RESULT.json');ad=obj(gr/'ADMISSION.json');_,log=read(gr/'EXECUTION.log',small=True)
 assert ad['admitted'] and ad['work']==128*1048576 and ad['reserve']==RESERVE and ad['initial']==g['initial'] and g['exit_code']==0 and g['failure']is None
 assert g['memory_events_before']==g['memory_events_after']==ad['memory_events_before']
 rows=[g['initial']]+g['samples']+[g['final']];assert len(g['samples'])==10
 for r in rows:
  assert r['maximum']==g['initial']['maximum']==MAX and r['headroom']==MAX-r['current'] and r['current']-g['initial']['current']<=128*1048576 and r['headroom']>=RESERVE and r['free']>=1048576
 assert g['initial']['headroom']>=128*1048576+RESERVE and g['initial']['free']>=16*1048576
 assert g['initial']['free']==66957312 and g['final']['free']==157171712 and b'"normal": true' in log and b'"retiredRedundantBackupLinks": 150' in log
 _,head=read('/workspace/Roguelike-deckbuilder/.git/HEAD',small=True);_,ref=read('/workspace/Roguelike-deckbuilder/.git/refs/heads/codex/lanternbound-production',small=True)
 assert head.decode().strip()=='ref: refs/heads/codex/lanternbound-production' and ref.decode().strip()==before['head']
 # Fresh producer pre-action Git checks are bound by successful exact script; source reviewer also preserved independent clean/local/remote controls.
 read(S/'standard-sol-historical-media-backup-retirement-source-independent-r1/status.stdout',small=True)
 _,remote=read(S/'standard-sol-historical-media-backup-retirement-source-independent-r1/remote.stdout',small=True);assert remote.decode().split()[0]==before['head']
 summary=dict(decision='ACCEPT_EXACT_FINITE150_BACKUP_RETIREMENT_AND_RETAINED200_MEDIA',currentPaths=200,currentSharedInodes=50,bodyReads=200,retiredBackupPaths=150,backupBodiesNotReadBecauseAbsent=True,retirementJournals=300,all4FrozenMapsExact=True,allCurrentBytesAndFullMetadataExact=True,allocatedOldCopiesRemoved=91852800,guardNetDiskGain=g['final']['free']-g['initial']['free'],guardInitialDisk=g['initial']['free'],guardFinalDisk=g['final']['free'],guardSampleCount=10,guardMaxDelta=max(r['current']-g['initial']['current']for r in rows),guardMinHeadroom=min(r['headroom']for r in rows),guardWholeSeconds=(g['final']['time_ns']-g['initial']['time_ns'])/1e9,guardEventsUnchanged=True,guardNumericChildIdentityLedgerAbsent=True,guardWaitRcZero=True,currentHEAD=before['head'],currentMediaRecordDigest=hashlib.sha256(json.dumps(current,sort_keys=True,separators=(',',':')).encode()).hexdigest(),retiredMetadataRecordDigest=hashlib.sha256(json.dumps(retired,sort_keys=True,separators=(',',':')).encode()).hexdigest(),qualifications=['Filesystem net includes retained journals and other allocation; gross removed inode allocation is not identical to net free-space gain.','No fresh remote CLI or exhaustive writer/consumer absence proof; exact pre-action source checks, retained independent readback and current direct local ref bound.','Workflow immutable/fresh-stage-only holds persist; 0600 media remains OS writable.','Original inode/ctime rollback intentionally surrendered; retained exact media paths, bytes, source, rights/provenance and historical metadata support useful reproduction.','No broader retirement or game/art/quality approval.'])
 save('INDEPENDENT-RECOMPUTATION.json',summary);save('READ-PINS.json',PINS)
 sample();save('RESOURCE.json',dict(columns=['elapsedSeconds','current','maximum','headroom','delta','free','VmHWM'],rows=ROWS,eventsBefore=EV,eventsAfter=(CG/'memory.events').read_text(),maxDelta=max(r[4]for r in ROWS),minHeadroom=min(r[3]for r in ROWS),maxVmHWM=max(r[6]for r in ROWS),method='Every 64KiB read sampled; own actual VmHWM and fixed RLIMIT_DATA64MiB. Source preparation/image tools are not included in this process measurement. Concurrent artist source work means cgroup deltas are shared observations, not exclusive attribution.'))
 report='''Independent finite retirement POST review — 1 October 2026\n\nACCEPT the exact completed removal of 150 previously independently verified redundant original-inode backup links. All 200 historical served media paths remain byte exact, full current metadata/xattrs match the replacement and retirement snapshots, and all four frozen 87-input/56-output maps remain exact. This approves no other cleanup.\n\nOne fresh 64MiB work plus 512MiB reserve admission preceded a single NOATIME/NOFOLLOW 64KiB streaming pass over all 200 current bodies. No removed backup body was read or recreated. All 150 prepared intents and 150 completion journals match the original plan, prior retained-backup identities, RETIREMENT-BEFORE and RESULT. The BACKUPS directory remains and is empty. The complete finite transaction directory membership matches all old and new journals; no failure journal is present.\n\nSource a8a83c5218601c3064ad84a933d39fdc577a7dea0b54b7fdba62f95d4b0767d2, producer judgment2a12aa5e5bf79aeda997b9b0aaf09e63384a7ac2945dbb4876ddd50f0e05d567, source gate8f2e29f9c62eb4b2b034978a8c75162ee0b9fbd2eb2fb79379ad3b29d6d6945c, resultf2a5b616d87308430e54a6c2e8d53d81ce7964bf06d7eac132e27d4697a59590 and prior full350-body POST gate654fe8481bcfa4afdd7bdfa7194321a9364508a8de5f9256ce00be4de734c94a bind this decision. Producer explicitly accepts surrender of original inode/ctime rollback, declares these physical copies unnecessary, limits action to exact backups and preserves immutable/fresh-stage-only holds. Root/public/dist, trace aliases, native/generated art, reports, releases and ML inputs are outside the literal action; no new exhaustive full-media exclusion stream or universal consumer-absence claim is made.\n\n50 retained anchor inodes each have exactly four links: all four logical stage media paths remain intact. Original150 distinct backup inodes are no longer retained at those paths. Their historical metadata and full prior byte verification remain preserved. Byte/path/source reproduction remains useful; original inode identity/ctime cannot be restored. OS mode0600 is writable; immutable holds are workflow controls, and reproduction requires fresh stages/new inodes.\n\nAll Root guard initial, ten samples and final rows were recomputed under128MiB work plus512MiB reserve, separately authorized16MiB initial disk minimum and1MiB stop minimum. Exit0/failureNone, unchanged limits/events, maximum delta11,460,608B and minimum headroom1,478,205,440B; normal sampled whole phase1.005881973s. Numeric child PID/start-tick ledger is absent, so normal owned wait/exit does not prove exhaustive descendant closure. No browser phase occurred here.\n\nGross retired allocation91,852,800B. Actual guard free space rose66,957,312 to157,171,712B, net90,214,400B; journals and other filesystem activity make net and gross differ. RESULT's adjacent observation157,327,360B precedes its own final journal allocation and is not the guard final value. These readings establish observed space recovery, not universal accounting attribution.\n\nCurrent small direct Git HEAD/ref still bindsd853e9e33b51a933c8d547ff50a692b596863fb7. Retained independent source readback plus the exact executed source's successful pre-action clean/local/remote assertions support the push prerequisite. No new Git CLI/network call was made in this review; process attribution and current remote state beyond those receipts remain qualified.\n\nMethod failure preserved: preliminary inspection guessed RETIREMENT-AFTER.json, which does not exist; source/result inspection established currentFiles resides in RETIREMENT-RESULT. That inspection error preceded the sole body verifier invocation. No transaction retry, hidden action or review-source/data rewrite followed.\n\nReviewer authored prior tactile/audio work, not this storage proposal, transaction, retirement script or producer judgment. This is a storage correctness/preservation decision, not game quality, pixel-art selection, gameplay, human fun, native-platform approval or authorization of additional retirement. All read/tool/file descriptors and own writers closed on seal.\n'''
 with (OUT/'REVIEW.md').open('x')as f:f.write(report)
 sample()
 save('FINAL-RESOURCE.json',dict(final=ROWS[-1],events=(CG/'memory.events').read_text(),maximumUnchanged=True,allObservedRowsPass=True,bodyPassCount=1,noBodyRetry=True))
 save('POST-GATE.json',dict(decision=summary['decision'],exactScope='Only150 original backup links; all200 historical served media retained',sourceGate=gate['scriptSHA256'],retirementResultSHA256='f2a5b616d87308430e54a6c2e8d53d81ce7964bf06d7eac132e27d4697a59590',retainedPaths=200,removedBackupLinks=150,all4MapsExact=True,all300RetirementJournalsExact=True,noFurtherActionAuthorized=True,toolsClosedOnSeal=True))
 files=[]
 for p in sorted(OUT.iterdir()):
  if p.is_file():files.append(dict(path=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 save('FROZEN.json',dict(files=files,scope='Independent post-retirement finite check; no media/control mutation'))
 assert sum(p.stat().st_size for p in OUT.iterdir()if p.is_file())<=500*1024
 print(json.dumps(dict(normal=True,summary=summary,ownRows=len(ROWS),ownMaxDelta=max(r[4]for r in ROWS),ownMinHeadroom=min(r[3]for r in ROWS),ownVmHWM=max(r[6]for r in ROWS),packet=str(OUT),pins={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [OUT/'POST-GATE.json',OUT/'REVIEW.md',OUT/'FROZEN.json']})))
try:run()
except BaseException as e:
 save('METHOD-FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc(),rows=ROWS,noAutomaticRetry=True));raise
