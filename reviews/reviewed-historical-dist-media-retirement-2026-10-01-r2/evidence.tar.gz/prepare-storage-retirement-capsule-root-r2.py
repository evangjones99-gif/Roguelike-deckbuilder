import pathlib,hashlib,json,tarfile,os
S=pathlib.Path('/workspace/scratch');R=pathlib.Path('/workspace/Roguelike-deckbuilder');OUT=R/'reviews/reviewed-historical-dist-media-retirement-2026-10-01-r2'
directories=['standard-sol-historical-dist-media-dedup-proposal-r1','standard-sol-historical-dist-media-dedup-independent-r1','standard-sol-historical-dist-media-dedup-script-independent-r1','standard-sol-historical-dist-media-dedup-script-independent-r2','standard-sol-historical-dist-media-dedup-git-readback-independent-r1','standard-sol-historical-dist-media-dedup-script-completion-independent-r3','standard-sol-historical-dist-media-dedup-post-independent-r1','standard-sol-historical-media-backup-retirement-source-independent-r1','standard-sol-historical-media-backup-retirement-post-independent-r1','historical-dist-media-dedup-transaction-root-r1','historical-dist-media-dedup-replacement-guard-root-r1','historical-media-backup-retirement-guard-root-r1','historical-storage-capsule-guard-root-r1']
files=['historical-dist-media-dedup-root-r1.py','historical-dist-media-dedup-root-r2.py','historical-dist-media-dedup-root-r2-source.json','historical-dist-media-dedup-judgment-root-r1.json','retire-verified-historical-media-backups-root-r1.py','historical-dist-media-backup-retirement-judgment-root-r1.json','guard-node-phase-r1.py','guard-retirement-bounded-journal-root-r1.py','root-pixel-reload-core-push-confirmation-r1.json','prepare-storage-retirement-capsule-root-r1.py','prepare-storage-retirement-capsule-root-r2.py']
paths=[]
for name in directories:
 for p in (S/name).rglob('*'):
  assert not p.is_symlink()
  if p.is_file():paths.append(p)
paths.extend(S/name for name in files)
assert len(paths)==len(set(paths));assert all(p.stat().st_size<4*1048576 for p in paths)
OUT.mkdir(exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
entries=[{'source':str(p),'member':str(p.relative_to(S)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(paths)]
archive=OUT/'evidence.tar.gz'
with tarfile.open(str(archive),'w|gz') as t:
 for e in entries:t.add(e['source'],arcname=e['member'],recursive=False)
with tarfile.open(str(archive),'r|gz') as t:
 for member,e in zip(t,entries,strict=True):
  assert member.name==e['member'] and member.size==e['bytes'];h=hashlib.sha256()
  with t.extractfile(member) as f:
   while b:=f.read(65536):h.update(b)
  assert h.hexdigest()==e['sha256']
manifest={'entries':entries,'count':len(entries),'logicalBytes':sum(e['bytes'] for e in entries),'archiveBytes':archive.stat().st_size,'archiveSHA256':sha(archive),'roundtripVerified':True,'scope':'Finite physical encoding retirement evidence, including preserved source/review-method failures, exact producer decisions, source/post gates and all journals. Media bodies excluded; all200 historical paths remain with exact frozen maps, immutable/fresh-stage-only holds.150 original-inode backup bodies removed after independent preference/post/source and pushed-before-cleanup. No game release/art promotion.','observedNetRecoveredBytes':90214400,'grossRetiredAllocationBytes':91852800,'originalInodeCtimeRollback':False}
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('count','logicalBytes','archiveBytes','archiveSHA256','roundtripVerified')}))
