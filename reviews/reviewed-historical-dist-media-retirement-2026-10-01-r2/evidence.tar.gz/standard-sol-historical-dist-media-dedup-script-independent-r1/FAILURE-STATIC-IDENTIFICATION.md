Static follow-up only; no helper or transaction rerun.

The source-plan input cap caused the verification-method refusal. verify-source.py line25 asserts os.fstat(fd).st_size≤262,144 for every read. Its line36 reads the9,520B script and2,551B judgment, then IDENTITIES-r2.json, whose observed size is581,175B. The plan necessarily fails line25 before the source hash assertions on lines37–39, full plan/control proof or Git checks inside this helper. Earlier direct SHA/Git/connector reads remain separately attributed. The recorded single sample/no-breach result is consistent with early refusal, not a media or resource violation.

This observation does not alter the original helper, SOURCE-RECOMPUTATION, REVIEW or withheld gate. A future separately authorized NEW helper may explicitly allow this exact581,175B plan beneath a fixed1MiB bound, with unchanged64MiB work+512MiB reserve/currentRSS/HWM/live guards and retained traceback/location. No such helper was created or executed here.

The transaction source limits remain: a fresh owned-output flag is needed to prevent failure publishing into a pre-existing OUT, and fsynced per-file PREPARED evidence before link/replace improves recovery when mutation precedes STATE/journal publication. Root is preparing a distinct r2 source; the old script remains unexecuted. All own tools/processes/FDs/writers CLOSED after this static addendum.
