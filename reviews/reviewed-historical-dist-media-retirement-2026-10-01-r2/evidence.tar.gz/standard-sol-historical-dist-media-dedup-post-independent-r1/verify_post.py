import os,json,stat,hashlib,time
from pathlib import Path
OUT=Path(__file__).parent;BASEP=Path('/workspace/scratch');TX=BASEP/'historical-dist-media-dedup-transaction-root-r1';CG=Path('/sys/fs/cgroup')
BASE=int((CG/'memory.current').read_text());MAX=int((CG/'memory.max').read_text());EV=(CG/'memory.events').read_text();START=time.monotonic();ROWS=[];PINS=[];MEDIA=[]
assert MAX-BASE>=603979776 and os.statvfs(OUT).f_bavail*os.statvfs(OUT).f_frsize>=67108864
def guard(label):
 c=int((CG/'memory.current').read_text());m=int((CG/'memory.max').read_text());v=os.statvfs(OUT);hwm=int(next(s.split()[1]for s in Path('/proc/self/status').read_text().splitlines()if s.startswith('VmHWM:')))*1024
 r=dict(label=label,current=c,maximum=m,headroom=m-c,delta=c-BASE,free=v.f_bavail*v.f_frsize,elapsed=time.monotonic()-START,VmHWM=hwm);ROWS.append(r)
 assert m==MAX and r['headroom']>=536870912 and r['delta']<=67108864 and hwm<=67108864 and r['free']>=1048576 and r['elapsed']<=60,r
 assert (CG/'memory.events').read_text()==EV
def meta(s):return dict(dev=s.st_dev,inode=s.st_ino,mode=s.st_mode,nlink=s.st_nlink,uid=s.st_uid,gid=s.st_gid,size=s.st_size,allocated=s.st_blocks*512,atime_ns=s.st_atime_ns,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def read(path,expected=None,small=False,media=False):
 path=Path(path);chain=[]
 try:
  fd=os.open('/',os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW);chain.append(fd)
  for p in path.parts[1:-1]:fd=os.open(p,os.O_PATH|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);chain.append(fd)
  fd=os.open(path.name,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW,dir_fd=chain[-1]);chain.append(fd);before=meta(os.fstat(fd));assert stat.S_ISREG(before['mode'])
  attrs=lambda:{k:os.getxattr(fd,k).hex()for k in sorted(os.listxattr(fd))};x=attrs();h=hashlib.sha256();n=0;b=bytearray()
  if small:assert before['size']<=1048576
  while True:
   q=os.read(fd,65536)
   if not q:break
   h.update(q);n+=len(q)
   if small:b.extend(q)
   guard('read64KiB')
  assert n==before['size'] and meta(os.fstat(fd))==before and attrs()==x and meta(os.stat(path.name,dir_fd=chain[-2],follow_symlinks=False))==before
  if expected:assert h.hexdigest()==expected,(str(path),h.hexdigest(),expected)
  pin=dict(path=str(path),sha256=h.hexdigest(),bytes=n);PINS.append(pin)
  detail=dict(**pin,metadata=before,xattrs=x)
  if media:MEDIA.append(detail)
  return detail,bytes(b)
 finally:
  for fd in reversed(chain):os.close(fd)
def obj(p,expected=None):return json.loads(read(p,expected,True)[1])
def digest(x):return hashlib.sha256(json.dumps(dict(sorted(x.items())),separators=(',',':')).encode()).hexdigest()
def run():
 guard('initial');plan=obj(BASEP/'standard-sol-historical-dist-media-dedup-proposal-r1/IDENTITIES-r2.json','5927df801b483e3cab163b1813502d4d761e2c225bc76318fead9a766798cbbb')
 judgment=obj(BASEP/'historical-dist-media-dedup-judgment-root-r1.json','6fbee42d877e5d48df0b5df1d52f4cfce513a40c5776c4824bf1059f6a2966fa');gate=obj(BASEP/'standard-sol-historical-dist-media-dedup-script-completion-independent-r3/SOURCE-GATE.json','768c8ce786fa0137318f4d8b99cc77f2b8c1a072aa3d9c998107adec05efbd14')
 read(BASEP/'historical-dist-media-dedup-root-r2.py','5ce1eb59a1a5d887107f9547cdc321628bcb2e1b5629be081268808d6f8f688c',True)
 before=obj(TX/'BEFORE.json');after=obj(TX/'AFTER.json');result=obj(TX/'RESULT.json')
 assert before['files']==plan['files'] and before['judgment']==judgment and before['gate']==gate and before['head']==judgment['pushedHead']=='d853e9e33b51a933c8d547ff50a692b596863fb7'
 assert result['normal'] and result['failure']is None and result['originalBackupsRetained'] and len(result['replaced'])==150
 assert after['allPathsAndBodiesPreserved'] and after['originalBackupsRetained'] and after['savingsNotYetRealized'] and len(after['files'])==200
 stages=[plan['anchor']]+plan['targetStages'];assert judgment['immutableFreshStageOnly']==stages and judgment['allKnownWritersPaused'] and not judgment['backupRetirementAuthorized']
 maps={}
 for c in plan['controls']:
  _,b=read(c['path'],judgment['amendedControls'].get(c['path'],c['sha256']),True)
  if 'runtime-freeze-'in c['path']:
   f=json.loads(b);assert digest(f['outputs'])==f['outputsDigest'] and digest(f['inputs'])==f['sourceDigest'] and len(f['inputs'])==87 and len(f['outputs'])==56;maps[Path(f['stage']).name]=f['outputs']
 assert set(maps)==set(stages)
 originals={r['path']:r for r in plan['files']};anchors={r['relative']:r for r in plan['files']if r['stage']==plan['anchor']};assert len(originals)==200 and len(anchors)==50
 current={}
 for r in after['files']:
  old=originals[r['path']];a=anchors[old['relative']];d,_=read(r['path'],old['sha256'],media=True);assert d==r and d['bytes']==old['bytes'] and maps[old['stage']][old['relative']]==d['sha256']
  assert d['metadata']['inode']==a['metadata']['inode'] and d['metadata']['nlink']==4 and d['xattrs']==old['xattrs']==a['xattrs']=={}
  for k in ['dev','mode','uid','gid','size','allocated','atime_ns','mtime_ns']:assert d['metadata'][k]==a['metadata'][k]
  current[r['path']]=d
 assert len(current)==200 and len({(r['metadata']['dev'],r['metadata']['inode'])for r in current.values()})==50
 targets=[r for r in plan['files']if r['stage']!=plan['anchor']];backups=[]
 for i,r in enumerate(targets):
  p=obj(TX/f'PREPARED-{i:03d}.json');q=obj(TX/f'REPLACEMENT-{i:03d}.json');assert q==result['replaced'][i]
  assert p['index']==q['index']==i and p['original']==q['original']==r and p['mutationNotYetStarted']
  assert p['anchor']==q['anchor']==anchors[r['relative']]['path'];expected=str(TX/'BACKUPS'/f'{i:03d}.original');assert p['backup']==q['backup']==expected
  assert q['replacement']['path']==r['path'] and q['replacement']['sha256']==r['sha256'] and q['replacement']['metadata']['inode']==anchors[r['relative']]['metadata']['inode'] and q['replacement']['metadata']['nlink']==i//50+2
  d,_=read(expected,r['sha256'],media=True);assert d==q['retainedBackup'] and d['bytes']==r['bytes'] and d['xattrs']==r['xattrs']=={} and d['metadata']['nlink']==1
  for k,v in r['metadata'].items():
   if k!='ctime_ns':assert d['metadata'][k]==v
  assert d['metadata']['ctime_ns']!=r['metadata']['ctime_ns'];backups.append(d)
 assert len({(r['metadata']['dev'],r['metadata']['inode'])for r in backups})==150 and not ({r['metadata']['inode']for r in backups}&{r['metadata']['inode']for r in current.values()})
 assert sorted(os.listdir(TX/'BACKUPS'))==[f'{i:03d}.original'for i in range(150)]
 assert sorted(os.listdir(TX))==sorted(['BEFORE.json','AFTER.json','RESULT.json','BACKUPS']+[f'{p}-{i:03d}.json'for p in ['PREPARED','REPLACEMENT']for i in range(150)])
 # Direct small Git control reads only; no fresh CLI/network/helper invocation.
 _,head=read('/workspace/Roguelike-deckbuilder/.git/HEAD',small=True);assert head.decode().strip()=='ref: refs/heads/codex/lanternbound-production'
 _,ref=read('/workspace/Roguelike-deckbuilder/.git/refs/heads/codex/lanternbound-production',small=True);assert ref.decode().strip()==before['head']
 prior=obj(BASEP/'standard-sol-historical-dist-media-dedup-git-readback-independent-r1/READBACK-GATE.json','1ccc22c94d474f62f2e7f44668385caee813a625bef334c7665185e4a1a96f23');assert prior['head']==before['head'] and prior['clean'] and prior['allReturnCodesZero']
 gr=BASEP/'historical-dist-media-dedup-replacement-guard-root-r1';g=obj(gr/'RESULT.json');adm=obj(gr/'ADMISSION.json');assert adm['admitted'] and adm['work']==134217728 and adm['reserve']==536870912 and g['exit_code']==0 and g['failure']is None and g['memory_events_before']==g['memory_events_after']
 allrows=[g['initial']]+g['samples']+[g['final']];initial=g['initial']['current'];assert len(g['samples'])==13
 for r in allrows:assert r['maximum']==MAX and r['headroom']==MAX-r['current'] and r['current']-initial<=134217728 and r['headroom']>=536870912 and r['free']>=1048576
 assert g['initial']['headroom']>=671088640 and g['final']['free']==68415488
 read(gr/'EXECUTION.log',small=True);guard('final')
 data=dict(decision='FULL350_POST_BYTES_PATHS_INODE_BACKUPS_VERIFIED',currentPaths=200,sharedInodes=50,originalBackups=150,preparedJournals=150,replacementJournals=150,all200BodiesAnd150BackupBodiesExact=True,all4FrozenOutputMapsMatch=True,permittedMetadataTransitionExact=True,fullOriginalCtimeRollbackPossible=False,retainedBackupAllocatedBytes=sum(r['metadata']['allocated']for r in backups),savingsRealized=False,head=before['head'],remoteReadback='Retained independent prior receipt plus transaction-before head; no new remote call',transactionGuard=dict(workBytes=134217728,reserveBytes=536870912,samples=13,final=True,maxDelta=max(r['current']-initial for r in allrows),minHeadroom=min(r['headroom']for r in allrows),wholeSeconds=(g['final']['time_ns']-g['initial']['time_ns'])/1e9,eventsUnchanged=True,finalDiskFree=g['final']['free'],numericChildIdentitiesAbsent=True),ownResource=dict(rows=ROWS,eventsBefore=EV,eventsAfter=(CG/'memory.events').read_text(),maxDelta=max(r['delta']for r in ROWS),minHeadroom=min(r['headroom']for r in ROWS),maxVmHWM=max(r['VmHWM']for r in ROWS)),allOwnFDsClosed=True,noMutations=True)
 for n,b in [('INDEPENDENT-RECOMPUTATION.json',data),('READ-PINS.json',PINS),('POST-MEDIA-OBSERVATIONS.json',MEDIA)]:
  with open(OUT/n,'x')as f:json.dump(b,f,sort_keys=True,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in data.items()if k!='ownResource'}));print('OWN',data['ownResource']['maxVmHWM'],data['ownResource']['maxDelta'],data['ownResource']['minHeadroom'])
if __name__=='__main__':
 try:run()
 except BaseException as e:
  with open(OUT/'METHOD-FAILURE.json','x')as f:json.dump(dict(error=repr(e),rows=ROWS,noTargetMutation=True,allOwnFDsClosed=True,noAutomaticRetry=True),f)
  raise
