"""Finite source/Git readback only; never import or run retirement/transaction."""
import os,json,hashlib,ast,subprocess,time,resource,traceback
from pathlib import Path
OUT=Path('/workspace/scratch/standard-sol-historical-media-backup-retirement-source-independent-r1')
REPO=Path('/workspace/Roguelike-deckbuilder')
START=time.monotonic()
FILES={
 '/workspace/scratch/retire-verified-historical-media-backups-root-r1.py':'a8a83c5218601c3064ad84a933d39fdc577a7dea0b54b7fdba62f95d4b0767d2',
 '/workspace/scratch/historical-dist-media-backup-retirement-judgment-root-r1.json':'2a12aa5e5bf79aeda997b9b0aaf09e63384a7ac2945dbb4876ddd50f0e05d567',
 '/workspace/scratch/guard-retirement-bounded-journal-root-r1.py':'9dc48ba447a0136de7d4714a6a797c700d937fc98b4e1c94ba74103993bf90b3',
 '/workspace/scratch/standard-sol-historical-dist-media-dedup-post-independent-r1/POST-GATE.json':'654fe8481bcfa4afdd7bdfa7194321a9364508a8de5f9256ce00be4de734c94a',
 '/workspace/scratch/historical-dist-media-dedup-root-r2.py':'5ce1eb59a1a5d887107f9547cdc321628bcb2e1b5629be081268808d6f8f688c',
 '/workspace/Roguelike-deckbuilder/AGENTS.md':'7407aa5f2336bd21981f7a6d484fb44fdd3dc14fcd083a8eb6982f26dae6b189'
}
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  assert os.fstat(fd).st_size<=1048576;buf=bytearray()
  while True:
   b=os.read(fd,32768)
   if not b:break
   buf.extend(b)
  return bytes(buf)
 finally:os.close(fd)
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,obj):
 b=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode();fd=os.open(OUT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:
  v=memoryview(b)
  while v:v=v[os.write(fd,v):]
  os.fsync(fd)
 finally:os.close(fd)
def rss():
 return {q.split(':')[0]:int(q.split()[1])*1024 for q in Path('/proc/self/status').read_text().splitlines() if q.startswith(('VmRSS:','VmHWM:'))}
failure=None;commands=[];pins=[]
try:
 assert resource.getrlimit(resource.RLIMIT_DATA)==(-1,-1) and resource.getrlimit(resource.RLIMIT_AS)==(-1,-1),'normal-runtime limits required, never altered'
 data={}
 for p,expected in FILES.items():
  b=read(p);data[p]=b;assert sha(b)==expected;pins.append(dict(path=p,bytes=len(b),sha256=sha(b)))
 source=data[next(iter(FILES))];ast.parse(source)
 newguard=data['/workspace/scratch/guard-retirement-bounded-journal-root-r1.py'];oldguard=read('/workspace/scratch/guard-node-phase-r1.py')
 assert newguard==oldguard.replace(b"initial['free']>=64*1048576",b"initial['free']>=16*1048576",1)
 judgment=json.loads(data['/workspace/scratch/historical-dist-media-backup-retirement-judgment-root-r1.json'])
 post=json.loads(data['/workspace/scratch/standard-sol-historical-dist-media-dedup-post-independent-r1/POST-GATE.json'])
 assert judgment['decision']=='AUTHORIZE_ONLY_150_POSTVERIFIED_REDUNDANT_BACKUP_LINKS' and judgment['acceptNoOriginalInodeOrCtimeRollback'] and judgment['allKnownWritersPaused']
 assert post['currentFullBodyVerified']==200 and post['backupFullBodyVerified']==150 and post['currentLinkCount']==4 and post['backupLinkCount']==1
 write('SOURCE-PINS.json',dict(files=pins,guardOnlyDiskAdmissionDelta=True,postCounts=[200,150],retirementSourceParsedNotExecuted=True))
 for name,args in [('status',['status','--porcelain=v1','--untracked-files=all']),('head',['rev-parse','HEAD']),('branch',['branch','--show-current']),('remote',['ls-remote','--exit-code','origin','refs/heads/codex/lanternbound-production'])]:
  argv=['git','--no-optional-locks','-c','gc.auto=0',*args]
  cp=subprocess.run(argv,cwd=REPO,capture_output=True,timeout=45,env={**os.environ,'GIT_TERMINAL_PROMPT':'0'})
  for suffix,b in [('stdout',cp.stdout),('stderr',cp.stderr)]:
   fd=os.open(OUT/f'{name}.{suffix}',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
   try:
    v=memoryview(b)
    while v:v=v[os.write(fd,v):]
    os.fsync(fd)
   finally:os.close(fd)
  rec=dict(name=name,argv=argv,rc=cp.returncode,stdoutBytes=len(cp.stdout),stderrBytes=len(cp.stderr),stdoutSHA256=sha(cp.stdout),stderrSHA256=sha(cp.stderr));write(f'{name}.RESULT.json',rec);commands.append(rec)
  assert cp.returncode==0 and not cp.stderr
  if name=='status':assert not cp.stdout
  elif name=='head':assert cp.stdout.decode().strip()==judgment['pushedHead']
  elif name=='branch':assert cp.stdout.decode().strip()=='codex/lanternbound-production'
  else:assert cp.stdout.decode().split()==[judgment['pushedHead'],'refs/heads/codex/lanternbound-production']
except BaseException:failure=traceback.format_exc()
finally:
 result=dict(scope='One finite source + current ordinary Git readback only; no retirement/source imports/media-body reads',sourcePins=pins,commands=commands,failure=failure,normal=failure is None,RLIMIT_DATA=list(resource.getrlimit(resource.RLIMIT_DATA)),RLIMIT_AS=list(resource.getrlimit(resource.RLIMIT_AS)),actualRSS=rss(),ruMaxRSSSeparate=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,whole=time.monotonic()-START,allOwnFDsClosed=True)
 write('SOURCE-READBACK-RESULT.json',result);print(json.dumps(dict(normal=result['normal'],failure=failure,commands=len(commands),whole=result['whole'])))
 if failure:raise SystemExit(1)
