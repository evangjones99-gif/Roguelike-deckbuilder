import os,json,resource,subprocess,time,signal,hashlib
from pathlib import Path
OUT=Path(__file__).parent;CG=Path('/sys/fs/cgroup');REPO='/workspace/Roguelike-deckbuilder'
EXPECTED='d853e9e33b51a933c8d547ff50a692b596863fb7';BRANCH='codex/lanternbound-production'
BASE=int((CG/'memory.current').read_text());MAX=int((CG/'memory.max').read_text());EV=(CG/'memory.events').read_text();START=time.monotonic();ROWS=[];COMMANDS=[]
def save(n,x):
 with open(OUT/n,'x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def sample(label):
 c=int((CG/'memory.current').read_text());m=int((CG/'memory.max').read_text());free=os.statvfs(OUT);hwm=int(next(x.split()[1]for x in Path('/proc/self/status').read_text().splitlines()if x.startswith('VmHWM:')))*1024
 r=dict(label=label,current=c,maximum=m,delta=c-BASE,headroom=m-c,free=free.f_bavail*free.f_frsize,elapsed=time.monotonic()-START,ownVmHWM=hwm);ROWS.append(r)
 assert m==MAX and c-BASE<=134217728 and m-c>=536870912 and hwm<=134217728 and r['free']>=1048576 and r['elapsed']<=60,r
 assert (CG/'memory.events').read_text()==EV
def identity(pid):
 raw=Path('/proc/'+str(pid)+'/stat').read_text();s=raw[raw.rfind(')')+2:].split();return dict(pid=pid,state=s[0],ppid=int(s[1]),pgrp=int(s[2]),startTicks=int(s[19]))
def run(n,args,timeout):
 cmd=['git','--no-optional-locks','-C',REPO]+args;env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0';env['NODE_OPTIONS']='--max-old-space-size=256';env['GIT_TERMINAL_PROMPT']='0'
 start=time.monotonic();p=None;reason=None;ident=None
 with open(OUT/(n+'.stdout'),'xb')as stdout,open(OUT/(n+'.stderr'),'xb')as stderr:
  try:
   sample(n+'-prelaunch');p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,env=env,start_new_session=True);ident=identity(p.pid)
   while p.poll()is None:
    sample(n+'-running')
    if time.monotonic()-start>timeout:raise TimeoutError(n+' deadline')
    time.sleep(.02)
   p.wait()
  except BaseException as e:
   reason=repr(e)
   if p is not None and p.poll()is None:
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:p.wait(timeout=2)
    except subprocess.TimeoutExpired:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     p.wait(timeout=2)
  finally:
   stdout.flush();stderr.flush();os.fsync(stdout.fileno());os.fsync(stderr.fileno())
 result=dict(name=n,argv=cmd,exitCode=p.returncode if p is not None else None,reason=reason,elapsed=time.monotonic()-start,launchIdentity=ident,ownedNormalWait=reason is None,stdoutBytes=(OUT/(n+'.stdout')).stat().st_size,stderrBytes=(OUT/(n+'.stderr')).stat().st_size)
 COMMANDS.append(result);save(n+'.RESULT.json',result) # durable raw/exit evidence BEFORE assertions
 assert reason is None and result['exitCode']==0,result
 sample(n+'-closed')
 with open(OUT/(n+'.stdout'),'rb')as f:return f.read()
def main():
 assert MAX-BASE>=671088640
 assert resource.getrlimit(resource.RLIMIT_DATA)==(-1,-1) and resource.getrlimit(resource.RLIMIT_AS)==(-1,-1)
 save('ADMISSION.json',dict(maximum=MAX,current=BASE,headroom=MAX-BASE,workBytes=134217728,reserveBytes=536870912,RLIMIT_DATA=resource.getrlimit(resource.RLIMIT_DATA),RLIMIT_AS=resource.getrlimit(resource.RLIMIT_AS),environment='Inherited proxy/CA/auth unchanged; optional locks disabled, terminal prompt disabled, NODE_OPTIONS heap256; no environment values dumped'))
 sample('initial')
 status=run('status',['status','--porcelain=v1','--untracked-files=all'],15);assert status==b'',('nonclean status; see durable raw output',len(status))
 head=run('head',['rev-parse','HEAD'],5).decode().strip();assert head==EXPECTED
 branch=run('branch',['branch','--show-current'],5).decode().strip();assert branch==BRANCH
 remote=run('remote',['ls-remote','--exit-code','origin','refs/heads/'+BRANCH],30).decode().strip();assert remote==EXPECTED+'\trefs/heads/'+BRANCH
 sample('final');save('READBACK-RESULT.json',dict(decision='PASS_CURRENT_CLEAN_HEAD_BRANCH_AND_REMOTE_EXACT',head=head,branch=branch,remote=remote,clean=True,commands=COMMANDS,allOwnFDsClosed=True,gitMutations=False,storageActionAuthorized=False))
if __name__=='__main__':
 try:main()
 except BaseException as e:save('READBACK-FAILURE.json',dict(error=repr(e),commands=COMMANDS,allOwnFDsClosed=True,gitMutations=False,noRetry=True));raise
 finally:
  final=dict(rows=ROWS,eventsBefore=EV,eventsAfter=(CG/'memory.events').read_text(),maxDelta=max((r['delta']for r in ROWS),default=0),minHeadroom=min((r['headroom']for r in ROWS),default=MAX-BASE),maximum=MAX,maxVmHWM=max((r['ownVmHWM']for r in ROWS),default=0),wholeSeconds=time.monotonic()-START,commands=COMMANDS,allOwnFDsClosed=True)
  save('RESOURCE-ROWS.json',final)
