"""Finite historical media replacement; retain all original inode backups.

No cleanup mode. Independent postverification and another explicit decision are
required before backups can be retired. This script never writes a media body.
"""
import hashlib, json, os, stat, subprocess, sys, time
from pathlib import Path

BASE = Path('/workspace/scratch')
REPO = Path('/workspace/Roguelike-deckbuilder')
PROPOSAL = BASE / 'standard-sol-historical-dist-media-dedup-proposal-r1'
OUT = BASE / 'historical-dist-media-dedup-transaction-root-r1'
NAMES = ('first-five-opening-stage-r2', 'first-five-opening-hand-cue-stage-r1',
         'first-five-opening-hand-cue-terminal-stage-r1', 'first-five-opening-readout-stage-r1')
PLAN_SHA = '5927df801b483e3cab163b1813502d4d761e2c225bc76318fead9a766798cbbb'
OWN_OUT_ID = None
STATE = {'replaced': [], 'failure': None, 'originalBackupsRetained': True,
         'scope': 'Atomic path replacement only; original inode/ctime metadata changes are recorded, not exactly reversible.'}

def metadata(s):
    return dict(dev=s.st_dev, inode=s.st_ino, mode=s.st_mode, nlink=s.st_nlink,
                uid=s.st_uid, gid=s.st_gid, size=s.st_size, allocated=s.st_blocks * 512,
                atime_ns=s.st_atime_ns, mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)

def attrs(fd):
    return {k: os.getxattr(fd, k).hex() for k in sorted(os.listxattr(fd))}

def parents(path):
    chain = [os.open('/', os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW)]
    try:
        for part in Path(path).parts[1:]:
            chain.append(os.open(part, os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW,
                                 dir_fd=chain[-1]))
        return chain
    except BaseException:
        for fd in reversed(chain): os.close(fd)
        raise

def inspect(path):
    chain = parents(Path(path).parent)
    try:
        fd = os.open(Path(path).name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME,
                     dir_fd=chain[-1])
        try:
            before = metadata(os.fstat(fd)); x = attrs(fd)
            assert stat.S_ISREG(before['mode']) and before['size'] < 8 * 1048576
            h = hashlib.sha256(); count = 0
            while block := os.read(fd, 65536):
                h.update(block); count += len(block)
            assert metadata(os.fstat(fd)) == before and attrs(fd) == x
            assert count == before['size']
            return {'path': str(path), 'metadata': before, 'xattrs': x,
                    'bytes': count, 'sha256': h.hexdigest()}
        finally: os.close(fd)
    finally:
        for fd in reversed(chain): os.close(fd)

def fsync_parent(fd):
    sync = os.open('.', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_NOATIME,
                   dir_fd=fd)
    try: os.fsync(sync)
    finally: os.close(sync)

def publish(name, data):
    observed = os.stat(OUT, follow_symlinks=False)
    assert OWN_OUT_ID is not None and (observed.st_dev, observed.st_ino) == OWN_OUT_ID
    assert stat.S_ISDIR(observed.st_mode)
    target = OUT / name
    with target.open('x') as stream:
        json.dump(data, stream, sort_keys=True, indent=2); stream.write('\n')
        stream.flush(); os.fsync(stream.fileno())
    fd = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_NOATIME)
    try: os.fsync(fd)
    finally: os.close(fd)

def git(args):
    return subprocess.run(['git', '-c', 'gc.auto=0', *args], cwd=REPO,
                          check=True, capture_output=True, text=True, timeout=45).stdout.strip()

def run():
    global OWN_OUT_ID
    # Judgment and exact source review are root-owned controls, not a grant to
    # infer an approval from merely existing files.
    judgment_path, gate_path = map(Path, sys.argv[1:])
    judgment = json.loads(judgment_path.read_text())
    gate = json.loads(gate_path.read_text())
    assert judgment['decision'] == 'AUTHORIZE_EXACT_REPLACEMENT_WITH_BACKUPS_ONLY'
    assert judgment['allKnownWritersPaused'] is True
    assert judgment['acceptIntentionalMetadataChanges'] is True
    assert judgment['immutableFreshStageOnly'] == list(NAMES)
    assert gate['decision'] == 'ACCEPT_EXACT_REPLACEMENT_SCRIPT_AND_HOLDS_FOR_SEPARATE_EXECUTION'
    assert gate['scriptSHA256'] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    assert gate['judgmentSHA256'] == hashlib.sha256(judgment_path.read_bytes()).hexdigest()
    assert gate['planSHA256'] == PLAN_SHA
    assert not git(['status', '--porcelain'])
    head = git(['rev-parse', 'HEAD'])
    assert head == judgment['pushedHead']
    assert git(['ls-remote', 'origin', 'refs/heads/codex/lanternbound-production']).split()[0] == head
    assert not OUT.exists()
    raw = (PROPOSAL / 'IDENTITIES-r2.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == PLAN_SHA
    plan = json.loads(raw); rows = plan['files']
    assert len(rows) == 200 and plan['anchor'] == NAMES[0]
    assert plan['targetStages'] == list(NAMES[1:])
    anchors = {r['relative']: r for r in rows if r['stage'] == NAMES[0]}
    assert len(anchors) == 50
    unique = set()
    for row in rows:
        relative = Path(row['relative'])
        assert len(relative.parts) == 2 and relative.parts[0] in ('art', 'audio')
        assert relative.suffix in ('.png', '.wav') and row['stage'] in NAMES
        assert Path(row['path']) == BASE / row['stage'] / 'dist' / relative
        assert row['sha256'] == anchors[row['relative']]['sha256']
        current = inspect(row['path'])
        assert current['metadata'] == row['metadata'] and current['xattrs'] == row['xattrs']
        assert current['sha256'] == row['sha256'] and current['bytes'] == row['bytes']
        assert current['metadata']['nlink'] == 1
        unique.add((current['metadata']['dev'], current['metadata']['inode']))
    assert len(unique) == 200
    # Source controls intentionally amended for persisted holds are exact-pinned
    # in the judgment; all other proposal controls remain body-identical.
    amended = judgment['amendedControls']
    for control in plan['controls']:
        current = inspect(control['path'])
        assert current['sha256'] == amended.get(control['path'], control['sha256'])
    OUT.mkdir(mode=0o700)
    owned = os.stat(OUT, follow_symlinks=False); OWN_OUT_ID = (owned.st_dev, owned.st_ino)
    (OUT / 'BACKUPS').mkdir(mode=0o700)
    publish('BEFORE.json', {'planSHA256': PLAN_SHA, 'head': head, 'files': rows,
                            'judgment': judgment, 'gate': gate})
    for index, row in enumerate(r for r in rows if r['stage'] != NAMES[0]):
        anchor = anchors[row['relative']]
        current = inspect(row['path'])
        assert current['metadata'] == row['metadata'] and current['sha256'] == row['sha256']
        backup = OUT / 'BACKUPS' / f'{index:03d}.original'
        publish(f'PREPARED-{index:03d}.json', {'index': index, 'original': row,
                'anchor': anchor['path'], 'backup': str(backup), 'mutationNotYetStarted': True})
        original_chain = parents(Path(row['path']).parent)
        anchor_chain = parents(Path(anchor['path']).parent)
        backup_chain = parents(backup.parent)
        temporary = f'.dedup-root-r1-{index:03d}'
        try:
            destination_fd = original_chain[-1]
            assert not os.path.lexists(Path(row['path']).parent / temporary)
            # Retain the original inode BEFORE replacing its historical path.
            os.link(Path(row['path']).name, backup.name, src_dir_fd=destination_fd,
                    dst_dir_fd=backup_chain[-1], follow_symlinks=False)
            fsync_parent(backup_chain[-1])
            held_backup = inspect(backup)
            assert held_backup['sha256'] == row['sha256']
            assert held_backup['metadata']['inode'] == row['metadata']['inode']
            os.link(Path(anchor['path']).name, temporary, src_dir_fd=anchor_chain[-1],
                    dst_dir_fd=destination_fd, follow_symlinks=False)
            replacement = inspect(Path(row['path']).parent / temporary)
            assert replacement['sha256'] == row['sha256']
            assert replacement['metadata']['inode'] == anchor['metadata']['inode']
            os.replace(temporary, Path(row['path']).name,
                       src_dir_fd=destination_fd, dst_dir_fd=destination_fd)
            fsync_parent(destination_fd)
            result = {'index': index, 'original': row, 'anchor': anchor['path'],
                      'backup': str(backup), 'replacement': inspect(row['path']),
                      'retainedBackup': inspect(backup)}
            STATE['replaced'].append(result)
            publish(f'REPLACEMENT-{index:03d}.json', result)
        finally:
            for chain in (backup_chain, anchor_chain, original_chain):
                for fd in reversed(chain): os.close(fd)
    assert len(STATE['replaced']) == 150
    after = [inspect(row['path']) for row in rows]
    for row, current in zip(rows, after):
        anchor = anchors[row['relative']]
        assert current['sha256'] == row['sha256'] and current['bytes'] == row['bytes']
        assert current['metadata']['inode'] == anchor['metadata']['inode']
        assert current['metadata']['nlink'] == 4
        assert current['xattrs'] == anchor['xattrs']
        for key in ('dev', 'mode', 'uid', 'gid', 'size', 'atime_ns', 'mtime_ns'):
            assert current['metadata'][key] == anchor['metadata'][key]
    publish('AFTER.json', {'files': after, 'allPathsAndBodiesPreserved': True,
                           'originalBackupsRetained': True, 'savingsNotYetRealized': True})
    publish('RESULT.json', {**STATE, 'normal': True})
    print(json.dumps({'replaced': 150, 'backups': 150, 'noRetirement': True, 'head': head}))

if __name__ == '__main__':
    try: run()
    except BaseException as error:
        STATE['failure'] = repr(error)
        # Preserve backups and any partial replacement; no unreviewed cleanup,
        # retry or silent automatic rollback. Historical paths stay atomic.
        if OWN_OUT_ID is not None: publish('FAILURE.json', STATE)
        raise
