"""Preserve every durable comparison path while sharing exact immutable stock bytes."""
from pathlib import Path
from collections import Counter
import hashlib,json,os,stat,uuid

ROOT=Path('/workspace/Roguelike-deckbuilder/reviews/root-durable-runtime-capacity-v0.8')
AUDIT=Path('/workspace/scratch/durable-runtime-capacity-independent-v08-r1/AUDIT.json')
EXPECTED='baa73b3df3105de3a10b4da3a894f4ee59349eb59d3966c9af98ac3545adbc06'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024): h.update(b)
 return h.hexdigest()
def metadata(p):
 s=p.lstat()
 return {'type':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'other',
  'size':s.st_size,'mode':oct(s.st_mode&0o7777),'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,
  'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns,'blocks':s.st_blocks,'uid':s.st_uid,'gid':s.st_gid,'xattrs':{key:os.getxattr(p,key,follow_symlinks=False).hex() for key in os.listxattr(p,follow_symlinks=False)}}
assert sha(AUDIT)==EXPECTED
audit=json.loads(AUDIT.read_text()); assert audit['regular_files_hashed']==432 and len(audit['roots'])==6
assert not audit['outside_inventory_aliases'] and not audit['mutations_performed']
roots=[Path(r) for r in audit['roots']]
assert len(set(roots))==6 and all(r.is_dir() and r.resolve().is_relative_to('/workspace/scratch') for r in roots)
rows={}; directories={}; memberships={}; before={}
stable=['type','size','mode','device','inode','nlink','mtime_ns','ctime_ns','uid','gid','xattrs']
for inventory in audit['complete_inventories']:
 r=Path(inventory['root']); expected=set()
 for row in inventory['rows']:
  p=Path(row['path']); assert p.is_relative_to(r) and p.resolve().is_relative_to('/workspace/scratch')
  m=metadata(p); assert all(m[k]==row['after_hash'][k] for k in stable),(str(p),'stale metadata')
  before[str(p)]=m; expected.add(str(p)); rows[str(p)]=row
  if m['type']=='file': assert sha(p)==row['sha256'],str(p)
  else: assert m['type']=='directory'; directories[str(p)]=m
 actual={str(r)}|{str(p) for p in r.rglob('*')}; assert actual==expected,str(r)
 memberships[str(r)]=sorted(actual)
assert len(rows)==450 and len(directories)==18
inodeAliases=Counter((m['device'],m['inode']) for m in before.values() if m['type']=='file')
for m in before.values():
 if m['type']=='file': assert inodeAliases[(m['device'],m['inode'])]==m['nlink']
groups=audit['runtime_candidate_duplicate_groups']; assert len(groups)==141
seen=set()
for group in groups:
 ownerRoots=[]
 for name in group['paths']:
  assert name not in seen; seen.add(name); row=rows[name]; assert row['eligible_runtime_only']
  assert row['sha256']==group['sha256'] and row['after_hash']['size']==group['bytes'] and row['after_hash']['mode']==group['mode']
  assert all(row['after_hash'][k]==group[k] for k in ['uid','gid','xattrs'])
  p=Path(name); owners=[r for r in roots if p.is_relative_to(r)]; assert len(owners)==1
  ownerRoots.append(str(owners[0])); relative=p.relative_to(owners[0])
  assert 'resources' not in relative.parts and 'app.asar' not in name and 'default_app.asar' not in name
 assert len(set(ownerRoots))==len(ownerRoots),'Do not introduce within-package archive hardlink members'
 assert group['canonical_path_forecast_only']==group['paths'][0]

