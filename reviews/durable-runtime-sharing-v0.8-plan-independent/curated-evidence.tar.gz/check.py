from pathlib import Path
import ast,hashlib,json,datetime,difflib,stat,os
P=Path('/workspace/scratch/durable-runtime-plan-independent-v08-r1');R=Path('/workspace/Roguelike-deckbuilder');A=R/'reviews/root-durable-runtime-capacity-v0.8'
h=lambda b:hashlib.sha256(b).hexdigest()
files={name:(A/name).read_bytes()for name in ['PLAN.md','prepare.py','consolidate.py']};assert h(files['consolidate.py'])=='4de719bd0bfd04f7dac75cf425fc29735005da48a4d4a7268f611e62a726beff'
auditPath=Path('/workspace/scratch/durable-runtime-capacity-independent-v08-r1/AUDIT.json');auditBytes=auditPath.read_bytes();assert h(auditBytes)=='baa73b3df3105de3a10b4da3a894f4ee59349eb59d3966c9af98ac3545adbc06'
old=(R/'reviews/root-tmp-runtime-capacity-v0.8/consolidate.py').read_bytes();assert h(old)=='577d71a18f3a9b45e8c9abcf20439daf2358ad98c2c687bac4297b9a7a52c283'
tree=ast.parse(files['prepare.py']);replacementNode=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='replacements'for t in n.targets));replacements=ast.literal_eval(replacementNode.value);generated=old.decode()
for a,b in replacements.items():assert a in generated;generated=generated.replace(a,b)
assert generated.encode()==files['consolidate.py']
source=files['consolidate.py'].decode();boundary='free_before=os.statvfs';assert source.count(boundary)==1;prefix=source.split(boundary)[0];assert 'os.link('not in prefix and 'os.replace('not in prefix and ".open('x')"not in prefix
# The parent authorized only the prefix, ending before the free/snapshot boundary.
ns={};exec(compile(prefix,'frozen-read-only-prefix','exec'),ns)
assert len(ns['rows'])==450 and len(ns['directories'])==18 and len(ns['groups'])==141
for root in ns['roots']:
 assert root.resolve()==root
 for parent in [root,*root.parents]:assert not parent.is_symlink()
for path in ns['seen']:
 p=Path(path);owner=next(r for r in ns['roots']if p.is_relative_to(r));relative=p.relative_to(owner)
 assert len(relative.parts)==1 or len(relative.parts)==2 and relative.parts[0]=='locales'
 assert not any(part.endswith(('.asar','.zip','.tar','.gz'))for part in relative.parts)
 assert 'resources'not in relative.parts and 'node_modules'not in relative.parts
 assert ns['before'][path]['type']=='file'
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only frozen script prefix only before free_before; no snapshot/journal/link/replacement/archive mutation executed. Independently reconstructed prepare literal transformations in memory only. Files read may update atime.','hashes':{name:h(data)for name,data in files.items()},'pinnedAuditSHA256':h(auditBytes),'acceptedPriorScriptSHA256':h(old),'prepareExactInMemory':True,'prefixSHA256':h(prefix.encode()),'prefixBytes':len(prefix.encode()),'roots':[str(r)for r in ns['roots']],'regularFilesRehashed':sum(m['type']=='file'for m in ns['before'].values()),'directoryMembers':len(ns['directories']),'groups':len(ns['groups']),'sharedEligiblePaths':len(ns['seen']),'outsideAliasCheckFresh':True,'allRootAncestorsNoSymlinks':True,'allEligibleLeavesRootOrLocalesOnly':True,'forecastAllocatedBytes':json.loads(auditBytes)['incremental_allocated_saving_bytes'],'candidateTransactionNotExecuted':True}
for name,data in files.items():(P/name).write_bytes(data)
(P/'read-only-prefix.py').write_text(prefix);(P/'TRANSFORMATION.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),source.splitlines(True),fromfile='accepted-tmp-577d',tofile='candidate-durable-4de7')));(P/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
