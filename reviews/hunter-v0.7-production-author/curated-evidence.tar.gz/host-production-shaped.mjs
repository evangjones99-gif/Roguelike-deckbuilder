import { chromium } from '/workspace/Roguelike-deckbuilder/node_modules/@playwright/test/index.mjs';
import fs from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
const base='/workspace/scratch/hunter-production-v07-r4';
const refs=JSON.parse(gunzipSync(await fs.readFile('/workspace/scratch/hunter-independent-gameplay-v07/references.json.gz')));
const growth=refs.fixtures.find(f=>f.name==='actual-bind-zero-to-six').steps[2];
const command=refs.fixtures.find(f=>f.name==='command-left').steps[0];
const lethal=refs.fixtures.find(f=>f.name==='hunter-lethal').steps[0];
const last=structuredClone(command.before);last.enemies=last.enemies.slice(0,1);last.enemies[0].hp=1;
const cases=[
  {name:'third-bind',...growth,motion:true},
  {name:'command',...command,motion:true},
  {name:'final-kill',before:last,action:{type:'attack',unit:last.allies[0].uid,target:last.enemies[0].uid},motion:true,resize:true},
  {name:'hunter-defeat',...lethal,motion:true,resize:true},
  {name:'reduced-third-bind',...growth,motion:false},
  {name:'missing-hunter-art',...growth,motion:true,missing:true},
];
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const results=[];
try{for(const c of cases){const context=await browser.newContext({viewport:{width:1280,height:720},reducedMotion:c.motion?'no-preference':'reduce'});
 await context.addInitScript(({before,motion})=>{
  localStorage.setItem('hollowpact.run.v2',JSON.stringify(before));localStorage.setItem('hollowpact.settings.v2',JSON.stringify({motion,mute:true,volume:0}));localStorage.setItem('hollowpact.tutorial.v2','yes');
  window.__draws=[];const original=CanvasRenderingContext2D.prototype.drawImage;
  CanvasRenderingContext2D.prototype.drawImage=function(...a){const ret=original.apply(this,a);if(this.canvas.id==='arena'&&a.length===9&&a[0] instanceof HTMLImageElement&&a[0].src.endsWith('/art/hunter-marek-v07-r3.png'))window.__draws.push({t:performance.now(),source:a.slice(1,5),destination:a.slice(5),matrix:{a:this.getTransform().a,e:this.getTransform().e,f:this.getTransform().f},canvas:{width:this.canvas.width,height:this.canvas.height,cssWidth:this.canvas.getBoundingClientRect().width,cssHeight:this.canvas.getBoundingClientRect().height}});return ret;};
 },{before:c.before,motion:c.motion});
 if(c.missing)await context.route('**/art/hunter-marek-v07-r3.png',r=>r.abort());const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 const r={name:c.name,motion:c.motion,errors};results.push(r);
 try{await page.goto('http://127.0.0.1:4206/');await page.locator('[data-ui=resume]').click();await page.waitForTimeout(450);
  r.noDiagnosticBridge=await page.evaluate(()=>!('__hunterProbe'in document.querySelector('#arena')));assert.ok(r.noDiagnosticBridge);
  const expected=await page.evaluate(async({before,action})=>{const e=await import('/src/engine.ts');assertValid(e.validateState(before));function assertValid(v){if(!v)throw Error('Invalid fixture');}if(!e.legalActions(before).some(a=>JSON.stringify(a)===JSON.stringify(action)))throw Error('Illegal fixture action');return e.applyActionWithEvents(before,action);},{before:c.before,action:c.action});r.expected=expected;
  await page.evaluate(()=>window.__draws=[]);
  const a=c.action;if(a.type==='attack'){await page.locator(`[data-unit="${a.unit}"]`).click();await page.locator(`[data-unit="${a.target}"]`).click();}else if(a.type==='play'){await page.locator(`[data-ui=play-card][data-index="${a.index}"]`).click();if(a.target)await page.locator(`[data-unit="${a.target}"]`).click();}else{await page.locator('[data-action=endTurn]').click();if(await page.locator('[data-ui=confirm-end]').isVisible())await page.locator('[data-ui=confirm-end]').click();}
  r.immediateRawExact=await page.evaluate(s=>localStorage.getItem('hollowpact.run.v2')===JSON.stringify(s),expected.state);assert.ok(r.immediateRawExact);
  if(c.resize)await page.setViewportSize({width:1024,height:720});
  r.during=await page.evaluate(()=>({settling:document.querySelector('#app').classList.contains('settling-combat'),hint:document.querySelector('.keyboard-hint')?.innerText,status:document.querySelector('.arena-art-status')?.innerText}));
  await page.screenshot({path:`${base}/evidence/${c.name}-during.png`});await page.waitForTimeout(1200);
  r.draws=await page.evaluate(()=>window.__draws);r.poseCells=[...new Set(r.draws.map(d=>d.source[0]/512+','+d.source[1]/512))];
  r.finalRawExact=await page.evaluate(s=>localStorage.getItem('hollowpact.run.v2')===JSON.stringify(s),expected.state);assert.ok(r.finalRawExact);
  if(c.name==='third-bind'){assert.ok(r.poseCells.includes('1,0'));assert.ok(r.poseCells.includes('2,0'));assert.ok(r.poseCells.includes('0,1'));}
  if(c.name==='hunter-defeat')assert.ok(r.poseCells.includes('2,1'));
  if(c.missing){assert.equal(r.draws.length,0);assert.match(r.during.status,/could not load/);}
  assert.deepEqual(errors,[]);r.finalSettling=await page.evaluate(()=>document.querySelector('#app').classList.contains('settling-combat'));assert.equal(r.finalSettling,false);r.pass=true;
 }catch(e){r.error=e.stack;r.pass=false;console.log({name:c.name,error:e.message});}finally{await context.close();await fs.writeFile(base+'/evidence/host-production-shaped.json',JSON.stringify({scope:'Author actual0.7host source/main/style with production-shaped hunter patch outside repository; no location flags/research diagnostic. Actual legal reducer events/custom unearned fixtures; realcontrols save and loaded full-cell image. Not final production/native/promotion/human/AAA proof.',results},null,2)+'\n');console.log({name:c.name,pass:r.pass,poseCells:r.poseCells});}
}}finally{await browser.close();}
if(results.some(r=>!r.pass))process.exitCode=1;
